// dear imgui, v1.69 WIP
// (main code and documentation)

// Call and read ImGui::ShowDemoWindow() in imgui_demo.cpp for demo code.
// Newcomers, read 'Programmer guide' below for notes on how to setup Dear ImGui in your codebase.
// Get latest version at https://github.com/ocornut/imgui
// Releases change-log at https://github.com/ocornut/imgui/releases
// Technical Support for Getting Started https://discourse.dearimgui.org/c/getting-started
// Gallery (please post your screenshots/video there!): https://github.com/ocornut/imgui/issues/1269

// Developed by Omar Cornut and every direct or indirect contributors to the GitHub.
// See LICENSE.txt for copyright and licensing details (standard MIT License).
// This library is free but I need your support to sustain development and maintenance.
// Businesses: you can support continued maintenance and development via support contracts or sponsoring, see docs/README.
// Individuals: you can support continued maintenance and development via donations or Patreon https://www.patreon.com/imgui.

// It is recommended that you don't modify imgui.cpp! It will become difficult for you to update the library.
// Note that 'ImGui::' being a namespace, you can add functions into the namespace from your own source files, without
// modifying imgui.h or imgui.cpp. You may include imgui_internal.h to access internal data structures, but it doesn't
// come with any guarantee of forward compatibility. Discussing your changes on the GitHub Issue Tracker may lead you
// to a better solution or official support for them.

/*

Index of this file:

DOCUMENTATION

- MISSION STATEMENT
- END-USER GUIDE
- PROGRAMMER GUIDE (read me!)
  - Read first.
  - How to update to a newer version of Dear ImGui.
  - Getting started with integrating Dear ImGui in your code/engine.
  - This is how a simple application may look like (2 variations).
  - This is how a simple rendering function may look like.
  - Using gamepad/keyboard navigation controls.
- API BREAKING CHANGES (read me when you update!)
- FREQUENTLY ASKED QUESTIONS (FAQ), TIPS
  - How can I tell whether to dispatch mouse/keyboard to imgui or to my application?
  - How can I display an image? What is ImTextureID, how does it works?
  - How can I have multiple widgets with the same label or with an empty label? A primer on labels and the ID Stack.
  - How can I use my own math types instead of ImVec2/ImVec4?
  - How can I load a different font than the default?
  - How can I easily use icons in my application?
  - How can I load multiple fonts?
  - How can I display and input non-latin characters such as Chinese, Japanese, Korean, Cyrillic?
  - How can I interact with standard C++ types (such as std::string and std::vector)?
  - How can I use the drawing facilities without an ImGui window? (using ImDrawList API)
  - How can I use Dear ImGui on a platform that doesn't have a mouse or a keyboard? (input share, remoting, gamepad)
  - I integrated Dear ImGui in my engine and the text or lines are blurry..
  - I integrated Dear ImGui in my engine and some elements are clipping or disappearing when I move windows around..
  - How can I help?

CODE
(search for "[SECTION]" in the code to find them)

// [SECTION] FORWARD DECLARATIONS
// [SECTION] CONTEXT AND MEMORY ALLOCATORS
// [SECTION] MAIN USER FACING STRUCTURES (ImGuiStyle, ImGuiIO)
// [SECTION] MISC HELPERS/UTILITIES (Maths, String, Format, Hash, File functions)
// [SECTION] MISC HELPERS/UTILITIES (ImText* functions)
// [SECTION] MISC HELPERS/UTILITIES (Color functions)
// [SECTION] ImGuiStorage
// [SECTION] ImGuiTextFilter
// [SECTION] ImGuiTextBuffer
// [SECTION] ImGuiListClipper
// [SECTION] RENDER HELPERS
// [SECTION] MAIN CODE (most of the code! lots of stuff, needs tidying up!)
// [SECTION] TOOLTIPS
// [SECTION] POPUPS
// [SECTION] KEYBOARD/GAMEPAD NAVIGATION
// [SECTION] COLUMNS
// [SECTION] DRAG AND DROP
// [SECTION] LOGGING/CAPTURING
// [SECTION] SETTINGS
// [SECTION] PLATFORM DEPENDENT HELPERS
// [SECTION] METRICS/DEBUG WINDOW

*/

//-----------------------------------------------------------------------------
// DOCUMENTATION
//-----------------------------------------------------------------------------

/*

 MISSION STATEMENT
 =================

 - Easy to use to create code-driven and data-driven tools.
 - Easy to use to create ad hoc short-lived tools and long-lived, more elaborate tools.
 - Easy to hack and improve.
 - Minimize screen real-estate usage.
 - Minimize setup and maintenance.
 - Minimize state storage on user side.
 - Portable, minimize dependencies, run on target (consoles, phones, etc.).
 - Efficient runtime and memory consumption (NB- we do allocate when "growing" content e.g. creating a window,.
   opening a tree node for the first time, etc. but a typical frame should not allocate anything).

 Designed for developers and content-creators, not the typical end-user! Some of the weaknesses includes:
 - Doesn't look fancy, doesn't animate.
 - Limited layout features, intricate layouts are typically crafted in code.


 END-USER GUIDE
 ==============

 - Double-click on title bar to collapse window.
 - Click upper right corner to close a window, available when 'bool* p_open' is passed to ImGui::Begin().
 - Click and drag on lower right corner to resize window (double-click to auto fit window to its contents).
 - Click and drag on any empty space to move window.
 - TAB/SHIFT+TAB to cycle through keyboard editable fields.
 - CTRL+Click on a slider or drag box to input value as text.
 - Use mouse wheel to scroll.
 - Text editor:
   - Hold SHIFT or use mouse to select text.
   - CTRL+Left/Right to word jump.
   - CTRL+Shift+Left/Right to select words.
   - CTRL+A our Double-Click to select all.
   - CTRL+X,CTRL+C,CTRL+V to use OS clipboard/
   - CTRL+Z,CTRL+Y to undo/redo.
   - ESCAPE to revert text to its original value.
   - You can apply arithmetic operators +,*,/ on numerical values. Use +- to subtract (because - would set a negative value!)
   - Controls are automatically adjusted for OSX to match standard OSX text editing operations.
 - General Keyboard controls: enable with ImGuiConfigFlags_NavEnableKeyboard.
 - General Gamepad controls: enable with ImGuiConfigFlags_NavEnableGamepad. See suggested mappings in imgui.h ImGuiNavInput_ + download PNG/PSD at http://goo.gl/9LgVZW


 PROGRAMMER GUIDE
 ================

 READ FIRST:

 - Read the FAQ below this section!
 - Your code creates the UI, if your code doesn't run the UI is gone! The UI can be highly dynamic, there are no construction
   or destruction steps, less superfluous data retention on your side, less state duplication, less state synchronization, less bugs.
 - Call and read ImGui::ShowDemoWindow() for demo code demonstrating most features.
 - The library is designed to be built from sources. Avoid pre-compiled binaries and packaged versions. See imconfig.h to configure your build.
 - Dear ImGui is an implementation of the IMGUI paradigm (immediate-mode graphical user interface, a term coined by Casey Muratori).
   You can learn about IMGUI principles at http://www.johno.se/book/imgui.html, http://mollyrocket.com/861 & more links docs/README.md.
 - Dear ImGui is a "single pass" rasterizing implementation of the IMGUI paradigm, aimed at ease of use and high-performances.
   For every application frame your UI code will be called only once. This is in contrast to e.g. Unity's own implementation of an IMGUI,
   where the UI code is called multiple times ("multiple passes") from a single entry point. There are pros and cons to both approaches.
 - Our origin are on the top-left. In axis aligned bounding boxes, Min = top-left, Max = bottom-right.
 - This codebase is also optimized to yield decent performances with typical "Debug" builds settings.
 - Please make sure you have asserts enabled (IM_ASSERT redirects to assert() by default, but can be redirected).
   If you get an assert, read the messages and comments around the assert.
 - C++: this is a very C-ish codebase: we don't rely on C++11, we don't include any C++ headers, and ImGui:: is a namespace.
 - C++: ImVec2/ImVec4 do not expose math operators by default, because it is expected that you use your own math types.
   See FAQ "How can I use my own math types instead of ImVec2/ImVec4?" for details about setting up imconfig.h for that.
   However, imgui_internal.h can optionally export math operators for ImVec2/ImVec4, which we use in this codebase.
 - C++: pay attention that ImVector<> manipulates plain-old-data and does not honor construction/destruction (avoid using it in your code!).

 HOW TO UPDATE TO A NEWER VERSION OF DEAR IMGUI:

 - Overwrite all the sources files except for imconfig.h (if you have made modification to your copy of imconfig.h)
 - Or maintain your own branch where you have imconfig.h modified.
 - Read the "API BREAKING CHANGES" section (below). This is where we list occasional API breaking changes.
   If a function/type has been renamed / or marked obsolete, try to fix the name in your code before it is permanently removed
   from the public API. If you have a problem with a missing function/symbols, search for its name in the code, there will
   likely be a comment about it. Please report any issue to the GitHub page!
 - Try to keep your copy of dear imgui reasonably up to date.

 GETTING STARTED WITH INTEGRATING DEAR IMGUI IN YOUR CODE/ENGINE:

 - Run and study the examples and demo in imgui_demo.cpp to get acquainted with the library.
 - Add the Dear ImGui source files to your projects or using your preferred build system.
   It is recommended you build and statically link the .cpp files as part of your project and not as shared library (DLL).
 - You can later customize the imconfig.h file to tweak some compile-time behavior, such as integrating imgui types with your own maths types.
 - When using Dear ImGui, your programming IDE is your friend: follow the declaration of variables, functions and types to find comments about them.
 - Dear ImGui never touches or knows about your GPU state. The only function that knows about GPU is the draw function that you provide.
   Effectively it means you can create widgets at any time in your code, regardless of considerations of being in "update" vs "render"
   phases of your own application. All rendering informatioe are stored into command-lists that you will retrieve after calling ImGui::Render().
 - Refer to the bindings and demo applications in the examples/ folder for instruction on how to setup your code.
 - If you are running over a standard OS with a common graphics API, you should be able to use unmodified imgui_impl_*** files from the examples/ folder.

 HOW A SIMPLE APPLICATION MAY LOOK LIKE:
 EXHIBIT 1: USING THE EXAMPLE BINDINGS (imgui_impl_XXX.cpp files from the examples/ folder).

     // Application init: create a dear imgui context, setup some options, load fonts
     ImGui::CreateContext();
     ImGuiIO& io = ImGui::GetIO();
     // TODO: Set optional io.ConfigFlags values, e.g. 'io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard' to enable keyboard controls.
     // TODO: Fill optional fields of the io structure later.
     // TODO: Load TTF/OTF fonts if you don't want to use the default font.

     // Initialize helper Platform and Renderer bindings (here we are using imgui_impl_win32 and imgui_impl_dx11)
     ImGui_ImplWin32_Init(hwnd);
     ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

     // Application main loop
     while (true)
     {
         // Feed inputs to dear imgui, start new frame
         ImGui_ImplDX11_NewFrame();
         ImGui_ImplWin32_NewFrame();
         ImGui::NewFrame();

         // Any application code here
         ImGui::Text("Hello, world!");

         // Render dear imgui into screen
         ImGui::Render();
         ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
         g_pSwapChain->Present(1, 0);
     }

     // Shutdown
     ImGui_ImplDX11_Shutdown();
     ImGui_ImplWin32_Shutdown();
     ImGui::DestroyContext();

 HOW A SIMPLE APPLICATION MAY LOOK LIKE:
 EXHIBIT 2: IMPLEMENTING CUSTOM BINDING / CUSTOM ENGINE.

     // Application init: create a dear imgui context, setup some options, load fonts
     ImGui::CreateContext();
     ImGuiIO& io = ImGui::GetIO();
     // TODO: Set optional io.ConfigFlags values, e.g. 'io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard' to enable keyboard controls.
     // TODO: Fill optional fields of the io structure later.
     // TODO: Load TTF/OTF fonts if you don't want to use the default font.

     // Build and load the texture atlas into a texture
     // (In the examples/ app this is usually done within the ImGui_ImplXXX_Init() function from one of the demo Renderer)
     int width, height;
     unsigned char* pixels = NULL;
     io.Fonts->GetTexDataAsRGBA32(&pixels, &width, &height);

     // At this point you've got the texture data and you need to upload that your your graphic system:
     // After we have created the texture, store its pointer/identifier (_in whichever format your engine uses_) in 'io.Fonts->TexID'.
     // This will be passed back to your via the renderer. Basically ImTextureID == void*. Read FAQ below for details about ImTextureID.
     MyTexture* texture = MyEngine::CreateTextureFromMemoryPixels(pixels, width, height, TEXTURE_TYPE_RGBA32)
     io.Fonts->TexID = (void*)texture;

     // Application main loop
     while (true)
     {
        // Setup low-level inputs, e.g. on Win32: calling GetKeyboardState(), or write to those fields from your Windows message handlers, etc.
        // (In the examples/ app this is usually done within the ImGui_ImplXXX_NewFrame() function from one of the demo Platform bindings)
        io.DeltaTime = 1.0f/60.0f;              // set the time elapsed since the previous frame (in seconds)
        io.DisplaySize.x = 1920.0f;             // set the current display width
        io.DisplaySize.y = 1280.0f;             // set the current display height here
        io.MousePos = my_mouse_pos;             // set the mouse position
        io.MouseDown[0] = my_mouse_buttons[0];  // set the mouse button states
        io.MouseDown[1] = my_mouse_buttons[1];

        // Call NewFrame(), after this point you can use ImGui::* functions anytime
        // (So you want to try calling NewFrame() as early as you can in your mainloop to be able to use imgui everywhere)
        ImGui::NewFrame();

        // Most of your application code here
        ImGui::Text("Hello, world!");
        MyGameUpdate(); // may use any ImGui functions, e.g. ImGui::Begin("My window"); ImGui::Text("Hello, world!"); ImGui::End();
        MyGameRender(); // may use any ImGui functions as well!

        // Render imgui, swap buffers
        // (You want to try calling EndFrame/Render as late as you can, to be able to use imgui in your own game rendering code)
        ImGui::EndFrame();
        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        MyImGuiRenderFunction(draw_data);
        SwapBuffers();
     }

     // Shutdown
     ImGui::DestroyContext();

 HOW A SIMPLE RENDERING FUNCTION MAY LOOK LIKE:

    void void MyImGuiRenderFunction(ImDrawData* draw_data)
    {
       // TODO: Setup render state: alpha-blending enabled, no face culling, no depth testing, scissor enabled
       // TODO: Setup viewport covering draw_data->DisplayPos to draw_data->DisplayPos + draw_data->DisplaySize
       // TODO: Setup orthographic projection matrix cover draw_data->DisplayPos to draw_data->DisplayPos + draw_data->DisplaySize
       // TODO: Setup shader: vertex { float2 pos, float2 uv, u32 color }, fragment shader sample color from 1 texture, multiply by vertex color.
       for (int n = 0; n < draw_data->CmdListsCount; n++)
       {
          const ImDrawList* cmd_list = draw_data->CmdLists[n];
          const ImDrawVert* vtx_buffer = cmd_list->VtxBuffer.Data;  // vertex buffer generated by ImGui
          const ImDrawIdx* idx_buffer = cmd_list->IdxBuffer.Data;   // index buffer generated by ImGui
          for (int cmd_i = 0; cmd_i < cmd_list->CmdBuffer.Size; cmd_i++)
          {
             const ImDrawCmd* pcmd = &cmd_list->CmdBuffer[cmd_i];
             if (pcmd->UserCallback)
             {
                 pcmd->UserCallback(cmd_list, pcmd);
             }
             else
             {
                 // The texture for the draw call is specified by pcmd->TextureId.
                 // The vast majority of draw calls will use the imgui texture atlas, which value you have set yourself during initialization.
                 MyEngineBindTexture((MyTexture*)pcmd->TextureId);

                 // We are using scissoring to clip some objects. All low-level graphics API should supports it.
                 // - If your engine doesn't support scissoring yet, you may ignore this at first. You will get some small glitches
                 //   (some elements visible outside their bounds) but you can fix that once everything else works!
                 // - Clipping coordinates are provided in imgui coordinates space (from draw_data->DisplayPos to draw_data->DisplayPos + draw_data->DisplaySize)
                 //   In a single viewport application, draw_data->DisplayPos will always be (0,0) and draw_data->DisplaySize will always be == io.DisplaySize.
                 //   However, in the interest of supporting multi-viewport applications in the future (see 'viewport' branch on github),
                 //   always subtract draw_data->DisplayPos from clipping bounds to convert them to your viewport space.
                 // - Note that pcmd->ClipRect contains Min+Max bounds. Some graphics API may use Min+Max, other may use Min+Size (size being Max-Min)
                 ImVec2 pos = draw_data->DisplayPos;
                 MyEngineScissor((int)(pcmd->ClipRect.x - pos.x), (int)(pcmd->ClipRect.y - pos.y), (int)(pcmd->ClipRect.z - pos.x), (int)(pcmd->ClipRect.w - pos.y));

                 // Render 'pcmd->ElemCount/3' indexed triangles.
                 // By default the indices ImDrawIdx are 16-bits, you can change them to 32-bits in imconfig.h if your engine doesn't support 16-bits indices.
                 MyEngineDrawIndexedTriangles(pcmd->ElemCount, sizeof(ImDrawIdx) == 2 ? GL_UNSIGNED_SHORT : GL_UNSIGNED_INT, idx_buffer, vtx_buffer);
             }
             idx_buffer += pcmd->ElemCount;
          }
       }
    }

 - The examples/ folders contains many actual implementation of the pseudo-codes above.
 - When calling NewFrame(), the 'io.WantCaptureMouse', 'io.WantCaptureKeyboard' and 'io.WantTextInput' flags are updated.
   They tell you if Dear ImGui intends to use your inputs. When a flag is set you want to hide the corresponding inputs
   from the rest of your application. In every cases you need to pass on the inputs to imgui. Refer to the FAQ for more information.
 - Please read the FAQ below!. Amusingly, it is called a FAQ because people frequently run into the same issues!

 USING GAMEPAD/KEYBOARD NAVIGATION CONTROLS

 - The gamepad/keyboard navigation is fairly functional and keeps being improved.
 - Gamepad support is particularly useful to use dear imgui on a console system (e.g. PS4, Switch, XB1) without a mouse!
 - You can ask questions and report issues at https://github.com/ocornut/imgui/issues/787
 - The initial focus was to support game controllers, but keyboard is becoming increasingly and decently usable.
 - Gamepad:
    - Set io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad to enable.
    - Backend: Set io.BackendFlags |= ImGuiBackendFlags_HasGamepad + fill the io.NavInputs[] fields before calling NewFrame().
      Note that io.NavInputs[] is cleared by EndFrame().
    - See 'enum ImGuiNavInput_' in imgui.h for a description of inputs. For each entry of io.NavInputs[], set the following values:
         0.0f= not held. 1.0f= fully held. Pass intermediate 0.0f..1.0f values for analog triggers/sticks.
    - We uses a simple >0.0f test for activation testing, and won't attempt to test for a dead-zone.
      Your code will probably need to transform your raw inputs (such as e.g. remapping your 0.2..0.9 raw input range to 0.0..1.0 imgui range, etc.).
    - You can download PNG/PSD files depicting the gamepad controls for common controllers at: http://goo.gl/9LgVZW.
    - If you need to share inputs between your game and the imgui parts, the easiest approach is to go all-or-nothing, with a buttons combo
      to toggle the target. Please reach out if you think the game vs navigation input sharing could be improved.
 - Keyboard:
    - Set io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard to enable.
      NewFrame() will automatically fill io.NavInputs[] based on your io.KeysDown[] + io.KeyMap[] arrays.
    - When keyboard navigation is active (io.NavActive + ImGuiConfigFlags_NavEnableKeyboard), the io.WantCaptureKeyboard flag
      will be set. For more advanced uses, you may want to read from:
       - io.NavActive: true when a window is focused and it doesn't have the ImGuiWindowFlags_NoNavInputs flag set.
       - io.NavVisible: true when the navigation cursor is visible (and usually goes false when mouse is used).
       - or query focus information with e.g. IsWindowFocused(ImGuiFocusedFlags_AnyWindow), IsItemFocused() etc. functions.
      Please reach out if you think the game vs navigation input sharing could be improved.
 - Mouse:
    - PS4 users: Consider emulating a mouse cursor with DualShock4 touch pad or a spare analog stick as a mouse-emulation fallback.
    - Consoles/Tablet/Phone users: Consider using a Synergy 1.x server (on your PC) + uSynergy.c (on your console/tablet/phone app) to share your PC mouse/keyboard.
    - On a TV/console system where readability may be lower or mouse inputs may be awkward, you may want to set the ImGuiConfigFlags_NavEnableSetMousePos flag.
      Enabling ImGuiConfigFlags_NavEnableSetMousePos + ImGuiBackendFlags_HasSetMousePos instructs dear imgui to move your mouse cursor along with navigation movements.
      When enabled, the NewFrame() function may alter 'io.MousePos' and set 'io.WantSetMousePos' to notify you that it wants the mouse cursor to be moved.
      When that happens your back-end NEEDS to move the OS or underlying mouse cursor on the next frame. Some of the binding in examples/ do that.
      (If you set the NavEnableSetMousePos flag but don't honor 'io.WantSetMousePos' properly, imgui will misbehave as it will see your mouse as moving back and forth!)
      (In a setup when you may not have easy control over the mouse cursor, e.g. uSynergy.c doesn't expose moving remote mouse cursor, you may want
       to set a boolean to ignore your other external mouse positions until the external source is moved again.)


 API BREAKING CHANGES
 ====================

 Occasionally introducing changes that are breaking the API. We try to make the breakage minor and easy to fix.
 Below is a change-log of API breaking changes only. If you are using one of the functions listed, expect to have to fix some code.
 When you are not sure about a old symbol or function name, try using the Search/Find function of your IDE to look for comments or references in all imgui files.
 You can read releases logs https://github.com/ocornut/imgui/releases for more details.

 - 2019/02/14 (1.68) - made it illegal/assert when io.DisplayTime == 0.0f (with an exception for the first frame). If for some reason your time step calculation gives you a zero value, replace it with a dummy small value!
 - 2019/02/01 (1.68) - removed io.DisplayVisibleMin/DisplayVisibleMax (which were marked obsolete and removed from viewport/docking branch already).
 - 2019/01/06 (1.67) - renamed io.InputCharacters[], marked internal as was always intended. Please don't access directly, and use AddInputCharacter() instead!
 - 2019/01/06 (1.67) - renamed ImFontAtlas::GlyphRangesBuilder to ImFontGlyphRangesBuilder. Keep redirection typedef (will obsolete).
 - 2018/12/20 (1.67) - made it illegal to call Begin("") with an empty string. This somehow half-worked before but had various undesirable side-effects.
 - 2018/12/10 (1.67) - renamed io.ConfigResizeWindowsFromEdges to io.ConfigWindowsResizeFromEdges as we are doing a large pass on configuration flags.
 - 2018/10/12 (1.66) - renamed misc/stl/imgui_stl.* to misc/cpp/imgui_stdlib.* in prevision for other C++ helper files.
 - 2018/09/28 (1.66) - renamed SetScrollHere() to SetScrollHereY(). Kept redirection function (will obsolete).
 - 2018/09/06 (1.65) - renamed stb_truetype.h to imstb_truetype.h, stb_textedit.h to imstb_textedit.h, and stb_rect_pack.h to imstb_rectpack.h.
                       If you were conveniently using the imgui copy of those STB headers in your project you will have to update your include paths.
 - 2018/09/05 (1.65) - renamed io.OptCursorBlink/io.ConfigCursorBlink to io.ConfigInputTextCursorBlink. (#1427)
 - 2018/08/31 (1.64) - added imgui_widgets.cpp file, extracted and moved widgets code out of imgui.cpp into imgui_widgets.cpp. Re-ordered some of the code remaining in imgui.cpp.
                       NONE OF THE FUNCTIONS HAVE CHANGED. THE CODE IS SEMANTICALLY 100% IDENTICAL, BUT _EVERY_ FUNCTION HAS BEEN MOVED.
                       Because of this, any local modifications to imgui.cpp will likely conflict when you update. Read docs/CHANGELOG.txt for suggestions.
 - 2018/08/22 (1.63) - renamed IsItemDeactivatedAfterChange() to IsItemDeactivatedAfterEdit() for consistency with new IsItemEdited() API. Kept redirection function (will obsolete soonish as IsItemDeactivatedAfterChange() is very recent).
 - 2018/08/21 (1.63) - renamed ImGuiTextEditCallback to ImGuiInputTextCallback, ImGuiTextEditCallbackData to ImGuiInputTextCallbackData for consistency. Kept redirection types (will obsolete).
 - 2018/08/21 (1.63) - removed ImGuiInputTextCallbackData::ReadOnly since it is a duplication of (ImGuiInputTextCallbackData::Flags & ImGuiInputTextFlags_ReadOnly).
 - 2018/08/01 (1.63) - removed per-window ImGuiWindowFlags_ResizeFromAnySide beta flag in favor of a global io.ConfigResizeWindowsFromEdges [update 1.67 renamed to ConfigWindowsResizeFromEdges] to enable the feature.
 - 2018/08/01 (1.63) - renamed io.OptCursorBlink to io.ConfigCursorBlink [-> io.ConfigInputTextCursorBlink in 1.65], io.OptMacOSXBehaviors to ConfigMacOSXBehaviors for consistency.
 - 2018/07/22 (1.63) - changed ImGui::GetTime() return value from float to double to avoid accumulating floating point imprecisions over time.
 - 2018/07/08 (1.63) - style: renamed ImGuiCol_ModalWindowDarkening to ImGuiCol_ModalWindowDimBg for consistency with other features. Kept redirection enum (will obsolete).
 - 2018/06/08 (1.62) - examples: the imgui_impl_xxx files have been split to separate platform (Win32, Glfw, SDL2, etc.) from renderer (DX11, OpenGL, Vulkan,  etc.).
                       old binding will still work as is, however prefer using the separated bindings as they will be updated to be multi-viewport conformant.
                       when adopting new bindings follow the main.cpp code of your preferred examples/ folder to know which functions to call.
 - 2018/06/06 (1.62) - renamed GetGlyphRangesChinese() to GetGlyphRangesChineseFull() to distinguish other variants and discourage using the full set.
 - 2018/06/06 (1.62) - TreeNodeEx()/TreeNodeBehavior(): the ImGuiTreeNodeFlags_CollapsingHeader helper now include the ImGuiTreeNodeFlags_NoTreePushOnOpen flag. See Changelog for details.
 - 2018/05/03 (1.61) - DragInt(): the default compile-time format string has been changed from "%.0f" to "%d", as we are not using integers internally any more.
                       If you used DragInt() with custom format strings, make sure you change them to use %d or an integer-compatible format.
                       To honor backward-compatibility, the DragInt() code will currently parse and modify format strings to replace %*f with %d, giving time to users to upgrade their code.
                       If you have IMGUI_DISABLE_OBSOLETE_FUNCTIONS enabled, the code will instead assert! You may run a reg-exp search on your codebase for e.g. "DragInt.*%f" to help you find them.
 - 2018/04/28 (1.61) - obsoleted InputFloat() functions taking an optional "int decimal_precision" in favor of an equivalent and more flexible "const char* format",
                       consistent with other functions. Kept redirection functions (will obsolete).
 - 2018/04/09 (1.61) - IM_DELETE() helper function added in 1.60 doesn't clear the input _pointer_ reference, more consistent with expectation and allows passing r-value.
 - 2018/03/20 (1.60) - renamed io.WantMoveMouse to io.WantSetMousePos for consistency and ease of understanding (was added in 1.52, _not_ used by core and only honored by some binding ahead of merging the Nav branch).
 - 2018/03/12 (1.60) - removed ImGuiCol_CloseButton, ImGuiCol_CloseButtonActive, ImGuiCol_CloseButtonHovered as the closing cross uses regular button colors now.
 - 2018/03/08 (1.60) - changed ImFont::DisplayOffset.y to default to 0 instead of +1. Fixed rounding of Ascent/Descent to match TrueType renderer. If you were adding or subtracting to ImFont::DisplayOffset check if your fonts are correctly aligned vertically.
 - 2018/03/03 (1.60) - renamed ImGuiStyleVar_Count_ to ImGuiStyleVar_COUNT and ImGuiMouseCursor_Count_ to ImGuiMouseCursor_COUNT for consistency with other public enums.
 - 2018/02/18 (1.60) - BeginDragDropSource(): temporarily removed the optional mouse_button=0 parameter because it is not really usable in many situations at the moment.
 - 2018/02/16 (1.60) - obsoleted the io.RenderDrawListsFn callback, you can call your graphics engine render function after ImGui::Render(). Use ImGui::GetDrawData() to retrieve the ImDrawData* to display.
 - 2018/02/07 (1.60) - reorganized context handling to be more explicit,
                       - YOU NOW NEED TO CALL ImGui::CreateContext() AT THE BEGINNING OF YOUR APP, AND CALL ImGui::DestroyContext() AT THE END.
                       - removed Shutdown() function, as DestroyContext() serve this purpose.
                       - you may pass a ImFontAtlas* pointer to CreateContext() to share a font atlas between contexts. Otherwise CreateContext() will create its own font atlas instance.
                       - removed allocator parameters from CreateContext(), they are now setup with SetAllocatorFunctions(), and shared by all contexts.
                       - removed the default global context and font atlas instance, which were confusing for users of DLL reloading and users of multiple contexts.
 - 2018/01/31 (1.60) - moved sample TTF files from extra_fonts/ to misc/fonts/. If you loaded files directly from the imgui repo you may need to update your paths.
 - 2018/01/11 (1.60) - obsoleted IsAnyWindowHovered() in favor of IsWindowHovered(ImGuiHoveredFlags_AnyWindow). Kept redirection function (will obsolete).
 - 2018/01/11 (1.60) - obsoleted IsAnyWindowFocused() in favor of IsWindowFocused(ImGuiFocusedFlags_AnyWindow). Kept redirection function (will obsolete).
 - 2018/01/03 (1.60) - renamed ImGuiSizeConstraintCallback to ImGuiSizeCallback, ImGuiSizeConstraintCallbackData to ImGuiSizeCallbackData.
 - 2017/12/29 (1.60) - removed CalcItemRectClosestPoint() which was weird and not really used by anyone except demo code. If you need it it's easy to replicate on your side.
 - 2017/12/24 (1.53) - renamed the emblematic ShowTestWindow() function to ShowDemoWindow(). Kept redirection function (will obsolete).
 - 2017/12/21 (1.53) - ImDrawList: renamed style.AntiAliasedShapes to style.AntiAliasedFill for consistency and as a way to explicitly break code that manipulate those flag at runtime. You can now manipulate ImDrawList::Flags
 - 2017/12/21 (1.53) - ImDrawList: removed 'bool anti_aliased = true' final parameter of ImDrawList::AddPolyline() and ImDrawList::AddConvexPolyFilled(). Prefer manipulating ImDrawList::Flags if you need to toggle them during the frame.
 - 2017/12/14 (1.53) - using the ImGuiWindowFlags_NoScrollWithMouse flag on a child window forwards the mouse wheel event to the parent window, unless either ImGuiWindowFlags_NoInputs or ImGuiWindowFlags_NoScrollbar are also set.
 - 2017/12/13 (1.53) - renamed GetItemsLineHeightWithSpacing() to GetFrameHeightWithSpacing(). Kept redirection function (will obsolete).
 - 2017/12/13 (1.53) - obsoleted IsRootWindowFocused() in favor of using IsWindowFocused(ImGuiFocusedFlags_RootWindow). Kept redirection function (will obsolete).
                     - obsoleted IsRootWindowOrAnyChildFocused() in favor of using IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows). Kept redirection function (will obsolete).
 - 2017/12/12 (1.53) - renamed ImGuiTreeNodeFlags_AllowOverlapMode to ImGuiTreeNodeFlags_AllowItemOverlap. Kept redirection enum (will obsolete).
 - 2017/12/10 (1.53) - removed SetNextWindowContentWidth(), prefer using SetNextWindowContentSize(). Kept redirection function (will obsolete).
 - 2017/11/27 (1.53) - renamed ImGuiTextBuffer::append() helper to appendf(), appendv() to appendfv(). If you copied the 'Log' demo in your code, it uses appendv() so that needs to be renamed.
 - 2017/11/18 (1.53) - Style, Begin: removed ImGuiWindowFlags_ShowBorders window flag. Borders are now fully set up in the ImGuiStyle structure (see e.g. style.FrameBorderSize, style.WindowBorderSize). Use ImGui::ShowStyleEditor() to look them up.
                       Please note that the style system will keep evolving (hopefully stabilizing in Q1 2018), and so custom styles will probably subtly break over time. It is recommended you use the StyleColorsClassic(), StyleColorsDark(), StyleColorsLight() functions.
 - 2017/11/18 (1.53) - Style: removed ImGuiCol_ComboBg in favor of combo boxes using ImGuiCol_PopupBg for consistency.
 - 2017/11/18 (1.53) - Style: renamed ImGuiCol_ChildWindowBg to ImGuiCol_ChildBg.
 - 2017/11/18 (1.53) - Style: renamed style.ChildWindowRounding to style.ChildRounding, ImGuiStyleVar_ChildWindowRounding to ImGuiStyleVar_ChildRounding.
 - 2017/11/02 (1.53) - obsoleted IsRootWindowOrAnyChildHovered() in favor of using IsWindowHovered(ImGuiHoveredFlags_RootAndChildWindows);
 - 2017/10/24 (1.52) - renamed IMGUI_DISABLE_WIN32_DEFAULT_CLIPBOARD_FUNCS/IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCS to IMGUI_DISABLE_WIN32_DEFAULT_CLIPBOARD_FUNCTIONS/IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS for consistency.
 - 2017/10/20 (1.52) - changed IsWindowHovered() default parameters behavior to return false if an item is active in another window (e.g. click-dragging item from another window to this window). You can use the newly introduced IsWindowHovered() flags to requests this specific behavior if you need it.
 - 2017/10/20 (1.52) - marked IsItemHoveredRect()/IsMouseHoveringWindow() as obsolete, in favor of using the newly introduced flags for IsItemHovered() and IsWindowHovered(). See https://github.com/ocornut/imgui/issues/1382 for details.
                       removed the IsItemRectHovered()/IsWindowRectHovered() names introduced in 1.51 since they were merely more consistent names for the two functions we are now obsoleting.
 - 2017/10/17 (1.52) - marked the old 5-parameters version of Begin() as obsolete (still available). Use SetNextWindowSize()+Begin() instead!
 - 2017/10/11 (1.52) - renamed AlignFirstTextHeightToWidgets() to AlignTextToFramePadding(). Kept inline redirection function (will obsolete).
 - 2017/09/26 (1.52) - renamed ImFont::Glyph to ImFontGlyph. Keep redirection typedef (will obsolete).
 - 2017/09/25 (1.52) - removed SetNextWindowPosCenter() because SetNextWindowPos() now has the optional pivot information to do the same and more. Kept redirection function (will obsolete).
 - 2017/08/25 (1.52) - io.MousePos needs to be set to ImVec2(-FLT_MAX,-FLT_MAX) when mouse is unavailable/missing. Previously ImVec2(-1,-1) was enough but we now accept negative mouse coordinates. In your binding if you need to support unavailable mouse, make sure to replace "io.MousePos = ImVec2(-1,-1)" with "io.MousePos = ImVec2(-FLT_MAX,-FLT_MAX)".
 - 2017/08/22 (1.51) - renamed IsItemHoveredRect() to IsItemRectHovered(). Kept inline redirection function (will obsolete). -> (1.52) use IsItemHovered(ImGuiHoveredFlags_RectOnly)!
                     - renamed IsMouseHoveringAnyWindow() to IsAnyWindowHovered() for consistency. Kept inline redirection function (will obsolete).
                     - renamed IsMouseHoveringWindow() to IsWindowRectHovered() for consistency. Kept inline redirection function (will obsolete).
 - 2017/08/20 (1.51) - renamed GetStyleColName() to GetStyleColorName() for consistency.
 - 2017/08/20 (1.51) - added PushStyleColor(ImGuiCol idx, ImU32 col) overload, which _might_ cause an "ambiguous call" compilation error if you are using ImColor() with implicit cast. Cast to ImU32 or ImVec4 explicily to fix.
 - 2017/08/15 (1.51) - marked the weird IMGUI_ONCE_UPON_A_FRAME helper macro as obsolete. prefer using the more explicit ImGuiOnceUponAFrame.
 - 2017/08/15 (1.51) - changed parameter order for BeginPopupContextWindow() from (const char*,int buttons,bool also_over_items) to (const char*,int buttons,bool also_over_items). Note that most calls relied on default parameters completely.
 - 2017/08/13 (1.51) - renamed ImGuiCol_Columns*** to ImGuiCol_Separator***. Kept redirection enums (will obsolete).
 - 2017/08/11 (1.51) - renamed ImGuiSetCond_*** types and flags to ImGuiCond_***. Kept redirection enums (will obsolete).
 - 2017/08/09 (1.51) - removed ValueColor() helpers, they are equivalent to calling Text(label) + SameLine() + ColorButton().
 - 2017/08/08 (1.51) - removed ColorEditMode() and ImGuiColorEditMode in favor of ImGuiColorEditFlags and parameters to the various Color*() functions. The SetColorEditOptions() allows to initialize default but the user can still change them with right-click context menu.
                     - changed prototype of 'ColorEdit4(const char* label, float col[4], bool show_alpha = true)' to 'ColorEdit4(const char* label, float col[4], ImGuiColorEditFlags flags = 0)', where passing flags = 0x01 is a safe no-op (hello dodgy backward compatibility!). - check and run the demo window, under "Color/Picker Widgets", to understand the various new options.
                     - changed prototype of rarely used 'ColorButton(ImVec4 col, bool small_height = false, bool outline_border = true)' to 'ColorButton(const char* desc_id, ImVec4 col, ImGuiColorEditFlags flags = 0, ImVec2 size = ImVec2(0,0))'
 - 2017/07/20 (1.51) - removed IsPosHoveringAnyWindow(ImVec2), which was partly broken and misleading. ASSERT + redirect user to io.WantCaptureMouse
 - 2017/05/26 (1.50) - removed ImFontConfig::MergeGlyphCenterV in favor of a more multipurpose ImFontConfig::GlyphOffset.
 - 2017/05/01 (1.50) - renamed ImDrawList::PathFill() (rarely used directly) to ImDrawList::PathFillConvex() for clarity.
 - 2016/11/06 (1.50) - BeginChild(const char*) now applies the stack id to the provided label, consistently with other functions as it should always have been. It shouldn't affect you unless (extremely unlikely) you were appending multiple times to a same child from different locations of the stack id. If that's the case, generate an id with GetId() and use it instead of passing string to BeginChild().
 - 2016/10/15 (1.50) - avoid 'void* user_data' parameter to io.SetClipboardTextFn/io.GetClipboardTextFn pointers. We pass io.ClipboardUserData to it.
 - 2016/09/25 (1.50) - style.WindowTitleAlign is now a ImVec2 (ImGuiAlign enum was removed). set to (0.5f,0.5f) for horizontal+vertical centering, (0.0f,0.0f) for upper-left, etc.
 - 2016/07/30 (1.50) - SameLine(x) with x>0.0f is now relative to left of column/group if any, and not always to left of window. This was sort of always the intent and hopefully breakage should be minimal.
 - 2016/05/12 (1.49) - title bar (using ImGuiCol_TitleBg/ImGuiCol_TitleBgActive colors) isn't rendered over a window background (ImGuiCol_WindowBg color) anymore.
                       If your TitleBg/TitleBgActive alpha was 1.0f or you are using the default theme it will not affect you.
                       If your TitleBg/TitleBgActive alpha was <1.0f you need to tweak your custom theme to readjust for the fact that we don't draw a WindowBg background behind the title bar.
                       This helper function will convert an old TitleBg/TitleBgActive color into a new one with the same visual output, given the OLD color and the OLD WindowBg color.
                           ImVec4 ConvertTitleBgCol(const ImVec4& win_bg_col, const ImVec4& title_bg_col)
                           {
                               float new_a = 1.0f - ((1.0f - win_bg_col.w) * (1.0f - title_bg_col.w)), k = title_bg_col.w / new_a;
                               return ImVec4((win_bg_col.x * win_bg_col.w + title_bg_col.x) * k, (win_bg_col.y * win_bg_col.w + title_bg_col.y) * k, (win_bg_col.z * win_bg_col.w + title_bg_col.z) * k, new_a);
                           }
                       If this is confusing, pick the RGB value from title bar from an old screenshot and apply this as TitleBg/TitleBgActive. Or you may just create TitleBgActive from a tweaked TitleBg color.
 - 2016/05/07 (1.49) - removed confusing set of GetInternalState(), GetInternalStateSize(), SetInternalState() functions. Now using CreateContext(), DestroyContext(), GetCurrentContext(), SetCurrentContext().
 - 2016/05/02 (1.49) - renamed SetNextTreeNodeOpened() to SetNextTreeNodeOpen(), no redirection.
 - 2016/05/01 (1.49) - obsoleted old signature of CollapsingHeader(const char* label, const char* str_id = NULL, bool display_frame = true, bool default_open = false) as extra parameters were badly designed and rarely used. You can replace the "default_open = true" flag in new API with CollapsingHeader(label, ImGuiTreeNodeFlags_DefaultOpen).
 - 2016/04/26 (1.49) - changed ImDrawList::PushClipRect(ImVec4 rect) to ImDrawList::PushClipRect(Imvec2 min,ImVec2 max,bool intersect_with_current_clip_rect=false). Note that higher-level ImGui::PushClipRect() is preferable because it will clip at logic/widget level, whereas ImDrawList::PushClipRect() only affect your renderer.
 - 2016/04/03 (1.48) - removed style.WindowFillAlphaDefault setting which was redundant. Bake default BG alpha inside style.Colors[ImGuiCol_WindowBg] and all other Bg color values. (ref github issue #337).
 - 2016/04/03 (1.48) - renamed ImGuiCol_TooltipBg to ImGuiCol_PopupBg, used by popups/menus and tooltips. popups/menus were previously using ImGuiCol_WindowBg. (ref github issue #337)
 - 2016/03/21 (1.48) - renamed GetWindowFont() to GetFont(), GetWindowFontSize() to GetFontSize(). Kept inline redirection function (will obsolete).
 - 2016/03/02 (1.48) - InputText() completion/history/always callbacks: if you modify the text buffer manually (without using DeleteChars()/InsertChars() helper) you need to maintain the BufTextLen field. added an assert.
 - 2016/01/23 (1.48) - fixed not honoring exact width passed to PushItemWidth(), previously it would add extra FramePadding.x*2 over that width. if you had manual pixel-perfect alignment in place it might affect you.
 - 2015/12/27 (1.48) - fixed ImDrawList::AddRect() which used to render a rectangle 1 px too large on each axis.
 - 2015/12/04 (1.47) - renamed Color() helpers to ValueColor() - dangerously named, rarely used and probably to be made obsolete.
 - 2015/08/29 (1.45) - with the addition of horizontal scrollbar we made various fixes to inconsistencies with dealing with cursor position.
                       GetCursorPos()/SetCursorPos() functions now include the scrolled amount. It shouldn't affect the majority of users, but take note that SetCursorPosX(100.0f) puts you at +100 from the starting x position which may include scrolling, not at +100 from the window left side.
                       GetContentRegionMax()/GetWindowContentRegionMin()/GetWindowContentRegionMax() functions allow include the scrolled amount. Typically those were used in cases where no scrolling would happen so it may not be a problem, but watch out!
 - 2015/08/29 (1.45) - renamed style.ScrollbarWidth to style.ScrollbarSize
 - 2015/08/05 (1.44) - split imgui.cpp into extra files: imgui_demo.cpp imgui_draw.cpp imgui_internal.h that you need to add to your project.
 - 2015/07/18 (1.44) - fixed angles in ImDrawList::PathArcTo(), PathArcToFast() (introduced in 1.43) being off by an extra PI for no justifiable reason
 - 2015/07/14 (1.43) - add new ImFontAtlas::AddFont() API. For the old AddFont***, moved the 'font_no' parameter of ImFontAtlas::AddFont** functions to the ImFontConfig structure.
                       you need to render your textured triangles with bilinear filtering to benefit from sub-pixel positioning of text.
 - 2015/07/08 (1.43) - switched rendering data to use indexed rendering. this is saving a fair amount of CPU/GPU and enables us to get anti-aliasing for a marginal cost.
                       this necessary change will break your rendering function! the fix should be very easy. sorry for that :(
                     - if you are using a vanilla copy of one of the imgui_impl_XXXX.cpp provided in the example, you just need to update your copy and you can ignore the rest.
                     - the signature of the io.RenderDrawListsFn handler has changed!
                       old: ImGui_XXXX_RenderDrawLists(ImDrawList** const cmd_lists, int cmd_lists_count)
                       new: ImGui_XXXX_RenderDrawLists(ImDrawData* draw_data).
                         parameters: 'cmd_lists' becomes 'draw_data->CmdLists', 'cmd_lists_count' becomes 'draw_data->CmdListsCount'
                         ImDrawList: 'commands' becomes 'CmdBuffer', 'vtx_buffer' becomes 'VtxBuffer', 'IdxBuffer' is new.
                         ImDrawCmd:  'vtx_count' becomes 'ElemCount', 'clip_rect' becomes 'ClipRect', 'user_callback' becomes 'UserCallback', 'texture_id' becomes 'TextureId'.
                     - each ImDrawList now contains both a vertex buffer and an index buffer. For each command, render ElemCount/3 triangles using indices from the index buffer.
                     - if you REALLY cannot render indexed primitives, you can call the draw_data->DeIndexAllBuffers() method to de-index the buffers. This is slow and a waste of CPU/GPU. Prefer using indexed rendering!
                     - refer to code in the examples/ folder or ask on the GitHub if you are unsure of how to upgrade. please upgrade!
 - 2015/07/10 (1.43) - changed SameLine() parameters from int to float.
 - 2015/07/02 (1.42) - renamed SetScrollPosHere() to SetScrollFromCursorPos(). Kept inline redirection function (will obsolete).
 - 2015/07/02 (1.42) - renamed GetScrollPosY() to GetScrollY(). Necessary to reduce confusion along with other scrolling functions, because positions (e.g. cursor position) are not equivalent to scrolling amount.
 - 2015/06/14 (1.41) - changed ImageButton() default bg_col parameter from (0,0,0,1) (black) to (0,0,0,0) (transparent) - makes a difference when texture have transparence
 - 2015/06/14 (1.41) - changed Selectable() API from (label, selected, size) to (label, selected, flags, size). Size override should have been rarely be used. Sorry!
 - 2015/05/31 (1.40) - renamed GetWindowCollapsed() to IsWindowCollapsed() for consistency. Kept inline redirection function (will obsolete).
 - 2015/05/31 (1.40) - renamed IsRectClipped() to IsRectVisible() for consistency. Note that return value is opposite! Kept inline redirection function (will obsolete).
 - 2015/05/27 (1.40) - removed the third 'repeat_if_held' parameter from Button() - sorry! it was rarely used and inconsistent. Use PushButtonRepeat(true) / PopButtonRepeat() to enable repeat on desired buttons.
 - 2015/05/11 (1.40) - changed BeginPopup() API, takes a string identifier instead of a bool. ImGui needs to manage the open/closed state of popups. Call OpenPopup() to actually set the "open" state of a popup. BeginPopup() returns true if the popup is opened.
 - 2015/05/03 (1.40) - removed style.AutoFitPadding, using style.WindowPadding makes more sense (the default values were already the same).
 - 2015/04/13 (1.38) - renamed IsClipped() to IsRectClipped(). Kept inline redirection function until 1.50.
 - 2015/04/09 (1.38) - renamed ImDrawList::AddArc() to ImDrawList::AddArcFast() for compatibility with future API
 - 2015/04/03 (1.38) - removed ImGuiCol_CheckHovered, ImGuiCol_CheckActive, replaced with the more general ImGuiCol_FrameBgHovered, ImGuiCol_FrameBgActive.
 - 2014/04/03 (1.38) - removed support for passing -FLT_MAX..+FLT_MAX as the range for a SliderFloat(). Use DragFloat() or Inputfloat() instead.
 - 2015/03/17 (1.36) - renamed GetItemBoxMin()/GetItemBoxMax()/IsMouseHoveringBox() to GetItemRectMin()/GetItemRectMax()/IsMouseHoveringRect(). Kept inline redirection function until 1.50.
 - 2015/03/15 (1.36) - renamed style.TreeNodeSpacing to style.IndentSpacing, ImGuiStyleVar_TreeNodeSpacing to ImGuiStyleVar_IndentSpacing
 - 2015/03/13 (1.36) - renamed GetWindowIsFocused() to IsWindowFocused(). Kept inline redirection function until 1.50.
 - 2015/03/08 (1.35) - renamed style.ScrollBarWidth to style.ScrollbarWidth (casing)
 - 2015/02/27 (1.34) - renamed OpenNextNode(bool) to SetNextTreeNodeOpened(bool, ImGuiSetCond). Kept inline redirection function until 1.50.
 - 2015/02/27 (1.34) - renamed ImGuiSetCondition_*** to ImGuiSetCond_***, and _FirstUseThisSession becomes _Once.
 - 2015/02/11 (1.32) - changed text input callback ImGuiTextEditCallback return type from void-->int. reserved for future use, return 0 for now.
 - 2015/02/10 (1.32) - renamed GetItemWidth() to CalcItemWidth() to clarify its evolving behavior
 - 2015/02/08 (1.31) - renamed GetTextLineSpacing() to GetTextLineHeightWithSpacing()
 - 2015/02/01 (1.31) - removed IO.MemReallocFn (unused)
 - 2015/01/19 (1.30) - renamed ImGuiStorage::GetIntPtr()/GetFloatPtr() to GetIntRef()/GetIntRef() because Ptr was conflicting with actual pointer storage functions.
 - 2015/01/11 (1.30) - big font/image API change! now loads TTF file. allow for multiple fonts. no need for a PNG loader.
              (1.30) - removed GetDefaultFontData(). uses io.Fonts->GetTextureData*() API to retrieve uncompressed pixels.
                       font init:  { const void* png_data; unsigned int png_size; ImGui::GetDefaultFontData(NULL, NULL, &png_data, &png_size); <..Upload texture to GPU..>; }
                       became:     { unsigned char* pixels; int width, height; io.Fonts->GetTexDataAsRGBA32(&pixels, &width, &height); <..Upload texture to GPU>; io.Fonts->TexId = YourTextureIdentifier; }
                       you now have more flexibility to load multiple TTF fonts and manage the texture buffer for internal needs.
                       it is now recommended that you sample the font texture with bilinear interpolation.
              (1.30) - added texture identifier in ImDrawCmd passed to your render function (we can now render images). make sure to set io.Fonts->TexID.
              (1.30) - removed IO.PixelCenterOffset (unnecessary, can be handled in user projection matrix)
              (1.30) - removed ImGui::IsItemFocused() in favor of ImGui::IsItemActive() which handles all widgets
 - 2014/12/10 (1.18) - removed SetNewWindowDefaultPos() in favor of new generic API SetNextWindowPos(pos, ImGuiSetCondition_FirstUseEver)
 - 2014/11/28 (1.17) - moved IO.Font*** options to inside the IO.Font-> structure (FontYOffset, FontTexUvForWhite, FontBaseScale, FontFallbackGlyph)
 - 2014/11/26 (1.17) - reworked syntax of IMGUI_ONCE_UPON_A_FRAME helper macro to increase compiler compatibility
 - 2014/11/07 (1.15) - renamed IsHovered() to IsItemHovered()
 - 2014/10/02 (1.14) - renamed IMGUI_INCLUDE_IMGUI_USER_CPP to IMGUI_INCLUDE_IMGUI_USER_INL and imgui_user.cpp to imgui_user.inl (more IDE friendly)
 - 2014/09/25 (1.13) - removed 'text_end' parameter from IO.SetClipboardTextFn (the string is now always zero-terminated for simplicity)
 - 2014/09/24 (1.12) - renamed SetFontScale() to SetWindowFontScale()
 - 2014/09/24 (1.12) - moved IM_MALLOC/IM_REALLOC/IM_FREE preprocessor defines to IO.MemAllocFn/IO.MemReallocFn/IO.MemFreeFn
 - 2014/08/30 (1.09) - removed IO.FontHeight (now computed automatically)
 - 2014/08/30 (1.09) - moved IMGUI_FONT_TEX_UV_FOR_WHITE preprocessor define to IO.FontTexUvForWhite
 - 2014/08/28 (1.09) - changed the behavior of IO.PixelCenterOffset following various rendering fixes


 FREQUENTLY ASKED QUESTIONS (FAQ), TIPS
 ======================================

 Q: How can I tell whether to dispatch mouse/keyboard to imgui or to my application?
 A: You can read the 'io.WantCaptureMouse', 'io.WantCaptureKeyboard' and 'io.WantTextInput' flags from the ImGuiIO structure (e.g. if (ImGui::GetIO().WantCaptureMouse) { ... } )
    - When 'io.WantCaptureMouse' is set, imgui wants to use your mouse state, and you may want to discard/hide the inputs from the rest of your application.
    - When 'io.WantCaptureKeyboard' is set, imgui wants to use your keyboard state, and you may want to discard/hide the inputs from the rest of your application.
    - When 'io.WantTextInput' is set to may want to notify your OS to popup an on-screen keyboard, if available (e.g. on a mobile phone, or console OS).
    Note: you should always pass your mouse/keyboard inputs to imgui, even when the io.WantCaptureXXX flag are set false.
     This is because imgui needs to detect that you clicked in the void to unfocus its own windows.
    Note: The 'io.WantCaptureMouse' is more accurate that any attempt to "check if the mouse is hovering a window" (don't do that!).
     It handle mouse dragging correctly (both dragging that started over your application or over an imgui window) and handle e.g. modal windows blocking inputs.
     Those flags are updated by ImGui::NewFrame(). Preferably read the flags after calling NewFrame() if you can afford it, but reading them before is also
     perfectly fine, as the bool toggle fairly rarely. If you have on a touch device, you might find use for an early call to UpdateHoveredWindowAndCaptureFlags().
    Note: Text input widget releases focus on "Return KeyDown", so the subsequent "Return KeyUp" event that your application receive will typically
     have 'io.WantCaptureKeyboard=false'. Depending on your application logic it may or not be inconvenient. You might want to track which key-downs
     were targeted for Dear ImGui, e.g. with an array of bool, and filter out the corresponding key-ups.)

 Q: How can I display an image? What is ImTextureID, how does it works?
 A: Short explanation:
    - You may use functions such as ImGui::Image(), ImGui::ImageButton() or lower-level ImDrawList::AddImage() to emit draw calls that will use your own textures.
    - Actual textures are identified in a way that is up to the user/engine. Those identifiers are stored and passed as ImTextureID (void*) value.
    - Loading image files from the disk and turning them into a texture is not within the scope of Dear ImGui (for a good reason).
      Please read documentations or tutorials on your graphics API to understand how to display textures on the screen before moving onward.

    Long explanation:
    - Dear ImGui's job is to create "meshes", defined in a renderer-agnostic format made of draw commands and vertices.
      At the end of the frame those meshes (ImDrawList) will be displayed by your rendering function. They are made up of textured polygons and the code
      to render them is generally fairly short (a few dozen lines). In the examples/ folder we provide functions for popular graphics API (OpenGL, DirectX, etc.).
    - Each rendering function decides on a data type to represent "textures". The concept of what is a "texture" is entirely tied to your underlying engine/graphics API.
      We carry the information to identify a "texture" in the ImTextureID type.
      ImTextureID is nothing more that a void*, aka 4/8 bytes worth of data: just enough to store 1 pointer or 1 integer of your choice.
      Dear ImGui doesn't know or understand what you are storing in ImTextureID, it merely pass ImTextureID values until they reach your rendering function.
    - In the examples/ bindings, for each graphics API binding we decided on a type that is likely to be a good representation for specifying
      an image from the end-user perspective. This is what the _examples_ rendering functions are using:

         OpenGL:     ImTextureID = GLuint                       (see ImGui_ImplGlfwGL3_RenderDrawData() function in imgui_impl_glfw_gl3.cpp)
         DirectX9:   ImTextureID = LPDIRECT3DTEXTURE9           (see ImGui_ImplDX9_RenderDrawData()     function in imgui_impl_dx9.cpp)
         DirectX11:  ImTextureID = ID3D11ShaderResourceView*    (see ImGui_ImplDX11_RenderDrawData()    function in imgui_impl_dx11.cpp)
         DirectX12:  ImTextureID = D3D12_GPU_DESCRIPTOR_HANDLE  (see ImGui_ImplDX12_RenderDrawData()    function in imgui_impl_dx12.cpp)

      For example, in the OpenGL example binding we store raw OpenGL texture identifier (GLuint) inside ImTextureID.
      Whereas in the DirectX11 example binding we store a pointer to ID3D11ShaderResourceView inside ImTextureID, which is a higher-level structure
      tying together both the texture and information about its format and how to read it.
    - If you have a custom engine built over e.g. OpenGL, instead of passing GLuint around you may decide to use a high-level data type to carry information about
      the texture as well as how to display it (shaders, etc.). The decision of what to use as ImTextureID can always be made better knowing how your codebase
      is designed. If your engine has high-level data types for "textures" and "material" then you may want to use them.
      If you are starting with OpenGL or DirectX or Vulkan and haven't built much of a rendering engine over them, keeping the default ImTextureID
      representation suggested by the example bindings is probably the best choice.
      (Advanced users may also decide to keep a low-level type in ImTextureID, and use ImDrawList callback and pass information to their renderer)

    User code may do:

        // Cast our texture type to ImTextureID / void*
        MyTexture* texture = g_CoffeeTableTexture;
        ImGui::Image((void*)texture, ImVec2(texture->Width, texture->Height));

    The renderer function called after ImGui::Render() will receive that same value that the user code passed:

        // Cast ImTextureID / void* stored in the draw command as our texture type
        MyTexture* texture = (MyTexture*)pcmd->TextureId;
        MyEngineBindTexture2D(texture);

    Once you understand this design you will understand that loading image files and turning them into displayable textures is not within the scope of Dear ImGui.
    This is by design and is actually a good thing, because it means your code has full control over your data types and how you display them.
    If you want to display an image file (e.g. PNG file) into the screen, please refer to documentation and tutorials for the graphics API you are using.

    Here's a simplified OpenGL example using stb_image.h:

        // Use stb_image.h to load a PNG from disk and turn it into raw RGBA pixel data:
        #define STB_IMAGE_IMPLEMENTATION
        #include <stb_image.h>
        [...]
        int my_image_width, my_image_height;
        unsigned char* my_image_data = stbi_load("my_image.png", &my_image_width, &my_image_height, NULL, 4);

        // Turn the RGBA pixel data into an OpenGL texture:
        GLuint my_opengl_texture;
        glGenTextures(1, &my_opengl_texture);
        glBindTexture(GL_TEXTURE_2D, my_opengl_texture);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image_width, image_height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);

        // Now that we have an OpenGL texture, assuming our imgui rendering function (imgui_impl_xxx.cpp file) takes GLuint as ImTextureID, we can display it:
        ImGui::Image((void*)(intptr_t)my_opengl_texture, ImVec2(my_image_width, my_image_height));

    C/C++ tip: a void* is pointer-sized storage. You may safely store any pointer or integer into it by casting your value to ImTexture / void*, and vice-versa.
    Because both end-points (user code and rendering function) are under your control, you know exactly what is stored inside the ImTexture / void*.
    Examples:

        GLuint my_tex = XXX;
        void* my_void_ptr;
        my_void_ptr = (void*)(intptr_t)my_tex;                  // cast a GLuint into a void* (we don't take its address! we literally store the value inside the pointer)
        my_tex = (GLuint)(intptr_t)my_void_ptr;                 // cast a void* into a GLuint

        ID3D11ShaderResourceView* my_dx11_srv = XXX;
        void* my_void_ptr;
        my_void_ptr = (void*)my_dx11_srv;                       // cast a ID3D11ShaderResourceView* into an opaque void*
        my_dx11_srv = (ID3D11ShaderResourceView*)my_void_ptr;   // cast a void* into a ID3D11ShaderResourceView*

    Finally, you may call ImGui::ShowMetricsWindow() to explore/visualize/understand how the ImDrawList are generated.

 Q: How can I have multiple widgets with the same label or with an empty label?
 Q: I have multiple widgets with the same label, and only the first one works. Why is that?
 A: A primer on labels and the ID Stack...

    Dear ImGui internally need to uniquely identify UI elements.
    Elements that are typically not clickable (such as calls to the Text functions) don't need an ID.
    Interactive widgets (such as calls to Button buttons) need a unique ID.
    Unique ID are used internally to track active widgets and occasionally associate state to widgets.
    Unique ID are implicitly built from the hash of multiple elements that identify the "path" to the UI element.

   - Unique ID are often derived from a string label:

       Button("OK");          // Label = "OK",     ID = hash of (..., "OK")
       Button("Cancel");      // Label = "Cancel", ID = hash of (..., "Cancel")

   - ID are uniquely scoped within windows, tree nodes, etc. which all pushes to the ID stack. Having
     two buttons labeled "OK" in different windows or different tree locations is fine.
     We used "..." above to signify whatever was already pushed to the ID stack previously:

       Begin("MyWindow");
       Button("OK");          // Label = "OK",     ID = hash of ("MyWindow", "OK")
       End();
       Begin("MyOtherWindow");
       Button("OK");          // Label = "OK",     ID = hash of ("MyOtherWindow", "OK")
       End();

   - If you have a same ID twice in the same location, you'll have a conflict:

       Button("OK");
       Button("OK");          // ID collision! Interacting with either button will trigger the first one.

     Fear not! this is easy to solve and there are many ways to solve it!

   - Solving ID conflict in a simple/local context:
     When passing a label you can optionally specify extra ID information within string itself.
     Use "##" to pass a complement to the ID that won't be visible to the end-user.
     This helps solving the simple collision cases when you know e.g. at compilation time which items
     are going to be created:

       Begin("MyWindow");
       Button("Play");        // Label = "Play",   ID = hash of ("MyWindow", "Play")
       Button("Play##foo1");  // Label = "Play",   ID = hash of ("MyWindow", "Play##foo1")  // Different from above
       Button("Play##foo2");  // Label = "Play",   ID = hash of ("MyWindow", "Play##foo2")  // Different from above
       End();

   - If you want to completely hide the label, but still need an ID:

       Checkbox("##On", &b);  // Label = "",       ID = hash of (..., "##On")   // No visible label, just a checkbox!

   - Occasionally/rarely you might want change a label while preserving a constant ID. This allows
     you to animate labels. For example you may want to include varying information in a window title bar,
     but windows are uniquely identified by their ID. Use "###" to pass a label that isn't part of ID:

       Button("Hello###ID");  // Label = "Hello",  ID = hash of (..., "###ID")
       Button("World###ID");  // Label = "World",  ID = hash of (..., "###ID")  // Same as above, even though the label looks different

       sprintf(buf, "My game (%f FPS)###MyGame", fps);
       Begin(buf);            // Variable title,   ID = hash of "MyGame"

   - Solving ID conflict in a more general manner:
     Use PushID() / PopID() to create scopes and manipulate the ID stack, as to avoid ID conflicts
     within the same window. This is the most convenient way of distinguishing ID when iterating and
     creating many UI elements programmatically.
     You can push a pointer, a string or an integer value into the ID stack.
     Remember that ID are formed from the concatenation of _everything_ pushed into the ID stack.
     At each level of the stack we store the seed used for items at this level of the ID stack.

     Begin("Window");
       for (int i = 0; i < 100; i++)
       {
         PushID(i);           // Push i to the id tack
         Button("Click");     // Label = "Click",  ID = hash of ("Window", i, "Click")
         PopID();
       }
       for (int i = 0; i < 100; i++)
       {
         MyObject* obj = Objects[i];
         PushID(obj);
         Button("Click");     // Label = "Click",  ID = hash of ("Window", obj pointer, "Click")
         PopID();
       }
       for (int i = 0; i < 100; i++)
       {
         MyObject* obj = Objects[i];
         PushID(obj->Name);
         Button("Click");     // Label = "Click",  ID = hash of ("Window", obj->Name, "Click")
         PopID();
       }
       End();

   - You can stack multiple prefixes into the ID stack:

       Button("Click");       // Label = "Click",  ID = hash of (..., "Click")
       PushID("node");
       Button("Click");       // Label = "Click",  ID = hash of (..., "node", "Click")
         PushID(my_ptr);
           Button("Click");   // Label = "Click",  ID = hash of (..., "node", my_ptr, "Click")
         PopID();
       PopID();

   - Tree nodes implicitly creates a scope for you by calling PushID().

       Button("Click");       // Label = "Click",  ID = hash of (..., "Click")
       if (TreeNode("node"))  // <-- this function call will do a PushID() for you (unless instructed not to, with a special flag)
       {
         Button("Click");     // Label = "Click",  ID = hash of (..., "node", "Click")
         TreePop();
       }

   - When working with trees, ID are used to preserve the open/close state of each tree node.
     Depending on your use cases you may want to use strings, indices or pointers as ID.
      e.g. when following a single pointer that may change over time, using a static string as ID
       will preserve your node open/closed state when the targeted object change.
      e.g. when displaying a list of objects, using indices or pointers as ID will preserve the
       node open/closed state differently. See what makes more sense in your situation!

 Q: How can I use my own math types instead of ImVec2/ImVec4?
 A: You can edit imconfig.h and setup the IM_VEC2_CLASS_EXTRA/IM_VEC4_CLASS_EXTRA macros to add implicit type conversions.
    This way you'll be able to use your own types everywhere, e.g. passsing glm::vec2 to ImGui functions instead of ImVec2.

 Q: How can I load a different font than the default?
 A: Use the font atlas to load the TTF/OTF file you want:
      ImGuiIO& io = ImGui::GetIO();
      io.Fonts->AddFontFromFileTTF("myfontfile.ttf", size_in_pixels);
      io.Fonts->GetTexDataAsRGBA32() or GetTexDataAsAlpha8()
    Default is ProggyClean.ttf, monospace, rendered at size 13, embedded in dear imgui's source code.
    (Tip: monospace fonts are convenient because they allow to facilitate horizontal alignment directly at the string level.)
    (Read the 'misc/fonts/README.txt' file for more details about font loading.)

    New programmers: remember that in C/C++ and most programming languages if you want to use a
    backslash \ within a string literal, you need to write it double backslash "\\":
      io.Fonts->AddFontFromFileTTF("MyDataFolder\MyFontFile.ttf", size_in_pixels);   // WRONG (you are escape the M here!)
      io.Fonts->AddFontFromFileTTF("MyDataFolder\\MyFontFile.ttf", size_in_pixels);  // CORRECT
      io.Fonts->AddFontFromFileTTF("MyDataFolder/MyFontFile.ttf", size_in_pixels);   // ALSO CORRECT

 Q: How can I easily use icons in my application?
 A: The most convenient and practical way is to merge an icon font such as FontAwesome inside you
    main font. Then you can refer to icons within your strings.
    You may want to see ImFontConfig::GlyphMinAdvanceX to make your icon look monospace to facilitate alignment.
    (Read the 'misc/fonts/README.txt' file for more details about icons font loading.)

 Q: How can I load multiple fonts?
 A: Use the font atlas to pack them into a single texture:
    (Read the 'misc/fonts/README.txt' file and the code in ImFontAtlas for more details.)

      ImGuiIO& io = ImGui::GetIO();
      ImFont* font0 = io.Fonts->AddFontDefault();
      ImFont* font1 = io.Fonts->AddFontFromFileTTF("myfontfile.ttf", size_in_pixels);
      ImFont* font2 = io.Fonts->AddFontFromFileTTF("myfontfile2.ttf", size_in_pixels);
      io.Fonts->GetTexDataAsRGBA32() or GetTexDataAsAlpha8()
      // the first loaded font gets used by default
      // use ImGui::PushFont()/ImGui::PopFont() to change the font at runtime

      // Options
      ImFontConfig config;
      config.OversampleH = 2;
      config.OversampleV = 1;
      config.GlyphOffset.y -= 1.0f;      // Move everything by 1 pixels up
      config.GlyphExtraSpacing.x = 1.0f; // Increase spacing between characters
      io.Fonts->AddFontFromFileTTF("myfontfile.ttf", size_pixels, &config);

      // Combine multiple fonts into one (e.g. for icon fonts)
      static ImWchar ranges[] = { 0xf000, 0xf3ff, 0 };
      ImFontConfig config;
      config.MergeMode = true;
      io.Fonts->AddFontDefault();
      io.Fonts->AddFontFromFileTTF("fontawesome-webfont.ttf", 16.0f, &config, ranges); // Merge icon font
      io.Fonts->AddFontFromFileTTF("myfontfile.ttf", size_pixels, NULL, &config, io.Fonts->GetGlyphRangesJapanese()); // Merge japanese glyphs

 Q: How can I display and input non-Latin characters such as Chinese, Japanese, Korean, Cyrillic?
 A: When loading a font, pass custom Unicode ranges to specify the glyphs to load.

      // Add default Japanese ranges
      io.Fonts->AddFontFromFileTTF("myfontfile.ttf", size_in_pixels, NULL, io.Fonts->GetGlyphRangesJapanese());

      // Or create your own custom ranges (e.g. for a game you can feed your entire game script and only build the characters the game need)
      ImVector<ImWchar> ranges;
      ImFontGlyphRangesBuilder builder;
      builder.AddText("Hello world");                        // Add a string (here "Hello world" contains 7 unique characters)
      builder.AddChar(0x7262);                               // Add a specific character
      builder.AddRanges(io.Fonts->GetGlyphRangesJapanese()); // Add one of the default ranges
      builder.BuildRanges(&ranges);                          // Build the final result (ordered ranges with all the unique characters submitted)
      io.Fonts->AddFontFromFileTTF("myfontfile.ttf", size_in_pixels, NULL, ranges.Data);

    All your strings needs to use UTF-8 encoding. In C++11 you can encode a string literal in UTF-8
    by using the u8"hello" syntax. Specifying literal in your source code using a local code page
    (such as CP-923 for Japanese or CP-1251 for Cyrillic) will NOT work!
    Otherwise you can convert yourself to UTF-8 or load text data from file already saved as UTF-8.

    Text input: it is up to your application to pass the right character code by calling io.AddInputCharacter().
    The applications in examples/ are doing that.
    Windows: you can use the WM_CHAR or WM_UNICHAR or WM_IME_CHAR message (depending if your app is built using Unicode or MultiByte mode).
    You may also use MultiByteToWideChar() or ToUnicode() to retrieve Unicode codepoints from MultiByte characters or keyboard state.
    Windows: if your language is relying on an Input Method Editor (IME), you copy the HWND of your window to io.ImeWindowHandle in order for
    the default implementation of io.ImeSetInputScreenPosFn() to set your Microsoft IME position correctly.

 Q: How can I interact with standard C++ types (such as std::string and std::vector)?
 A: - Being highly portable (bindings for several languages, frameworks, programming style, obscure or older platforms/compilers),
      and aiming for compatibility & performance suitable for every modern real-time game engines, dear imgui does not use
      any of std C++ types. We use raw types (e.g. char* instead of std::string) because they adapt to more use cases.
    - To use ImGui::InputText() with a std::string or any resizable string class, see misc/cpp/imgui_stdlib.h.
    - To use combo boxes and list boxes with std::vector or any other data structure: the BeginCombo()/EndCombo() API
      lets you iterate and submit items yourself, so does the ListBoxHeader()/ListBoxFooter() API.
      Prefer using them over the old and awkward Combo()/ListBox() api.
    - Generally for most high-level types you should be able to access the underlying data type.
      You may write your own one-liner wrappers to facilitate user code (tip: add new functions in ImGui:: namespace from your code).
    - Dear ImGui applications often need to make intensive use of strings. It is expected that many of the strings you will pass
      to the API are raw literals (free in C/C++) or allocated in a manner that won't incur a large cost on your application.
      Please bear in mind that using std::string on applications with large amount of UI may incur unsatisfactory performances.
      Modern implementations of std::string often include small-string optimization (which is often a local buffer) but those
      are not configurable and not the same across implementations.
    - If you are finding your UI traversal cost to be too large, make sure your string usage is not leading to excessive amount
      of heap allocations. Consider using literals, statically sized buffers and your own helper functions. A common pattern
      is that you will need to build lots of strings on the fly, and their maximum length can be easily be scoped ahead.
      One possible implementation of a helper to facilitate printf-style building of strings: https://github.com/ocornut/Str
      This is a small helper where you can instance strings with configurable local buffers length. Many game engines will
      provide similar or better string helpers.

 Q: How can I use the drawing facilities without an ImGui window? (using ImDrawList API)
 A: - You can create a dummy window. Call Begin() with the NoBackground | NoDecoration | NoSavedSettings | NoInputs flags.
      (The ImGuiWindowFlags_NoDecoration flag itself is a shortcut for NoTitleBar | NoResize | NoScrollbar | NoCollapse)
      Then you can retrieve the ImDrawList* via GetWindowDrawList() and draw to it in any way you like.
    - You can call ImGui::GetOverlayDrawList() and use this draw list to display contents over every other imgui windows.
    - You can create your own ImDrawList instance. You'll need to initialize them ImGui::GetDrawListSharedData(), or create
      your own ImDrawListSharedData, and then call your rendered code with your own ImDrawList or ImDrawData data.

 Q: How can I use this without a mouse, without a keyboard or without a screen? (gamepad, input share, remote display)
 A: - You can control Dear ImGui with a gamepad. Read about navigation in "Using gamepad/keyboard navigation controls".
      (short version: map gamepad inputs into the io.NavInputs[] array + set io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad)
    - You can share your computer mouse seamlessly with your console/tablet/phone using Synergy (https://symless.com/synergy)
      This is the preferred solution for developer productivity.
      In particular, the "micro-synergy-client" repository (https://github.com/symless/micro-synergy-client) has simple
      and portable source code (uSynergy.c/.h) for a small embeddable client that you can use on any platform to connect
      to your host computer, based on the Synergy 1.x protocol. Make sure you download the Synergy 1 server on your computer.
      Console SDK also sometimes provide equivalent tooling or wrapper for Synergy-like protocols.
    - You may also use a third party solution such as Remote ImGui (https://github.com/JordiRos/remoteimgui) which sends
      the vertices to render over the local network, allowing you to use Dear ImGui even on a screen-less machine.
    - For touch inputs, you can increase the hit box of widgets (via the style.TouchPadding setting) to accommodate
      for the lack of precision of touch inputs, but it is recommended you use a mouse or gamepad to allow optimizing
      for screen real-estate and precision.

 Q: I integrated Dear ImGui in my engine and the text or lines are blurry..
 A: In your Render function, try translating your projection matrix by (0.5f,0.5f) or (0.375f,0.375f).
    Also make sure your orthographic projection matrix and io.DisplaySize matches your actual framebuffer dimension.

 Q: I integrated Dear ImGui in my engine and some elements are clipping or disappearing when I move windows around..
 A: You are probably mishandling the clipping rectangles in your render function.
    Rectangles provided by ImGui are defined as (x1=left,y1=top,x2=right,y2=bottom) and NOT as (x1,y1,width,height).

 Q: How can I help?
 A: - If you are experienced with Dear ImGui and C++, look at the github issues, look at the Wiki, read docs/TODO.txt
      and see how you want to help and can help!
    - Businesses: convince your company to fund development via support contracts/sponsoring! This is among the most useful thing you can do for dear imgui.
    - Individuals: you can also become a Patron (http://www.patreon.com/imgui) or donate on PayPal! See README.
    - Disclose your usage of dear imgui via a dev blog post, a tweet, a screenshot, a mention somewhere etc.
      You may post screenshot or links in the gallery threads (github.com/ocornut/imgui/issues/1902). Visuals are ideal as they inspire other programmers.
      But even without visuals, disclosing your use of dear imgui help the library grow credibility, and help other teams and programmers with taking decisions.
    - If you have issues or if you need to hack into the library, even if you don't expect any support it is useful that you share your issues (on github or privately).

 - tip: you can call Begin() multiple times with the same name during the same frame, it will keep appending to the same window.
        this is also useful to set yourself in the context of another window (to get/set other settings)
 - tip: you can create widgets without a Begin()/End() block, they will go in an implicit window called "Debug".
 - tip: the ImGuiOnceUponAFrame helper will allow run the block of code only once a frame. You can use it to quickly add custom UI in the middle
        of a deep nested inner loop in your code.
 - tip: you can call Render() multiple times (e.g for VR renders).
 - tip: call and read the ShowDemoWindow() code in imgui_demo.cpp for more example of how to use ImGui!

*/

#if defined(_MSC_VER) && !defined(_CRT_SECURE_NO_WARNINGS)
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "imgui.h"
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "imgui_internal.h"

#include <ctype.h>      // toupper, isprint
#include <stdio.h>      // vsnprintf, sscanf, printf
#if defined(_MSC_VER) && _MSC_VER <= 1500 // MSVC 2008 or earlier
#include <stddef.h>     // intptr_t
#else
#include <stdint.h>     // intptr_t
#endif

// Debug options
#define IMGUI_DEBUG_NAV_SCORING     0   // Display navigation scoring preview when hovering items. Display last moving direction matches when holding CTRL
#define IMGUI_DEBUG_NAV_RECTS       0   // Display the reference navigation rectangle for each window

// Visual Studio warnings
#ifdef _MSC_VER
#pragma warning (disable: 4127)     // condition expression is constant
#pragma warning (disable: 4996)     // 'This function or variable may be unsafe': strcpy, strdup, sprintf, vsnprintf, sscanf, fopen
#endif

// Clang/GCC warnings with -Weverything
#ifdef __clang__
#pragma clang diagnostic ignored "-Wunknown-pragmas"        // warning : unknown warning group '-Wformat-pedantic *'        // not all warnings are known by all clang versions.. so ignoring warnings triggers new warnings on some configuration. great!
#pragma clang diagnostic ignored "-Wold-style-cast"         // warning : use of old-style cast                              // yes, they are more terse.
#pragma clang diagnostic ignored "-Wfloat-equal"            // warning : comparing floating point with == or != is unsafe   // storing and comparing against same constants (typically 0.0f) is ok.
#pragma clang diagnostic ignored "-Wformat-nonliteral"      // warning : format string is not a string literal              // passing non-literal to vsnformat(). yes, user passing incorrect format strings can crash the code.
#pragma clang diagnostic ignored "-Wexit-time-destructors"  // warning : declaration requires an exit-time destructor       // exit-time destruction order is undefined. if MemFree() leads to users code that has been disabled before exit it might cause problems. ImGui coding style welcomes static/globals.
#pragma clang diagnostic ignored "-Wglobal-constructors"    // warning : declaration requires a global destructor           // similar to above, not sure what the exact difference it.
#pragma clang diagnostic ignored "-Wsign-conversion"        // warning : implicit conversion changes signedness             //
#pragma clang diagnostic ignored "-Wformat-pedantic"        // warning : format specifies type 'void *' but the argument has type 'xxxx *' // unreasonable, would lead to casting every %p arg to void*. probably enabled by -pedantic.
#pragma clang diagnostic ignored "-Wint-to-void-pointer-cast"       // warning : cast to 'void *' from smaller integer type 'int'
#if __has_warning("-Wzero-as-null-pointer-constant")
#pragma clang diagnostic ignored "-Wzero-as-null-pointer-constant"  // warning : zero as null pointer constant              // some standard header variations use #define NULL 0
#endif
#if __has_warning("-Wdouble-promotion")
#pragma clang diagnostic ignored "-Wdouble-promotion"       // warning: implicit conversion from 'float' to 'double' when passing argument to function  // using printf() is a misery with this as C++ va_arg ellipsis changes float to double.
#endif
#elif defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wunused-function"          // warning: 'xxxx' defined but not used
#pragma GCC diagnostic ignored "-Wint-to-pointer-cast"      // warning: cast to pointer from integer of different size
#pragma GCC diagnostic ignored "-Wformat"                   // warning: format '%p' expects argument of type 'void*', but argument 6 has type 'ImGuiWindow*'
#pragma GCC diagnostic ignored "-Wdouble-promotion"         // warning: implicit conversion from 'float' to 'double' when passing argument to function
#pragma GCC diagnostic ignored "-Wconversion"               // warning: conversion to 'xxxx' from 'xxxx' may alter its value
#pragma GCC diagnostic ignored "-Wformat-nonliteral"        // warning: format not a string literal, format string not checked
#pragma GCC diagnostic ignored "-Wstrict-overflow"          // warning: assuming signed overflow does not occur when assuming that (X - c) > X is always false
#if __GNUC__ >= 8
#pragma GCC diagnostic ignored "-Wclass-memaccess"          // warning: 'memset/memcpy' clearing/writing an object of type 'xxxx' with no trivial copy-assignment; use assignment or value-initialization instead
#endif
#endif

// When using CTRL+TAB (or Gamepad Square+L/R) we delay the visual a little in order to reduce visual noise doing a fast switch.
static const float NAV_WINDOWING_HIGHLIGHT_DELAY            = 0.20f;    // Time before the highlight and screen dimming starts fading in
static const float NAV_WINDOWING_LIST_APPEAR_DELAY          = 0.15f;    // Time before the window list starts to appear

// Window resizing from edges (when io.ConfigWindowsResizeFromEdges = true and ImGuiBackendFlags_HasMouseCursors is set in io.BackendFlags by back-end)
static const float WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS = 4.0f;     // Extend outside and inside windows. Affect FindHoveredWindow().
static const float WINDOWS_RESIZE_FROM_EDGES_FEEDBACK_TIMER = 0.04f;    // Reduce visual noise by only highlighting the border after a certain time.

//-------------------------------------------------------------------------
// [SECTION] FORWARD DECLARATIONS
//-------------------------------------------------------------------------

static void             SetCurrentWindow(ImGuiWindow* window);
static void             FindHoveredWindow();
static ImGuiWindow*     CreateNewWindow(const char* name, ImVec2 size, ImGuiWindowFlags flags);
static void             CheckStacksSize(ImGuiWindow* window, bool write);
static ImVec2           CalcNextScrollFromScrollTargetAndClamp(ImGuiWindow* window, bool snap_on_edges);

static void             AddDrawListToDrawData(ImVector<ImDrawList*>* out_list, ImDrawList* draw_list);
static void             AddWindowToSortBuffer(ImVector<ImGuiWindow*>* out_sorted_windows, ImGuiWindow* window);

static ImRect           GetViewportRect();

// Settings
static void*            SettingsHandlerWindow_ReadOpen(ImGuiContext*, ImGuiSettingsHandler*, const char* name);
static void             SettingsHandlerWindow_ReadLine(ImGuiContext*, ImGuiSettingsHandler*, void* entry, const char* line);
static void             SettingsHandlerWindow_WriteAll(ImGuiContext* imgui_ctx, ImGuiSettingsHandler* handler, ImGuiTextBuffer* buf);

// Platform Dependents default implementation for IO functions
static const char*      GetClipboardTextFn_DefaultImpl(void* user_data);
static void             SetClipboardTextFn_DefaultImpl(void* user_data, const char* text);
static void             ImeSetInputScreenPosFn_DefaultImpl(int x, int y);

namespace ImGui
{
static bool             BeginChildEx(const char* name, ImGuiID id, const ImVec2& size_arg, bool border, ImGuiWindowFlags flags);

// Navigation
static void             NavUpdate();
static void             NavUpdateWindowing();
static void             NavUpdateWindowingList();
static void             NavUpdateMoveResult();
static float            NavUpdatePageUpPageDown(int allowed_dir_flags);
static inline void      NavUpdateAnyRequestFlag();
static void             NavProcessItem(ImGuiWindow* window, const ImRect& nav_bb, const ImGuiID id);
static ImVec2           NavCalcPreferredRefPos();
static void             NavSaveLastChildNavWindow(ImGuiWindow* nav_window);
static ImGuiWindow*     NavRestoreLastChildNavWindow(ImGuiWindow* window);

// Misc
static void             UpdateMouseInputs();
static void             UpdateMouseWheel();
static void             UpdateManualResize(ImGuiWindow* window, const ImVec2& size_auto_fit, int* border_held, int resize_grip_count, ImU32 resize_grip_col[4]);
static void             RenderOuterBorders(ImGuiWindow* window);

}

//-----------------------------------------------------------------------------
// [SECTION] CONTEXT AND MEMORY ALLOCATORS
//-----------------------------------------------------------------------------

// Current context pointer. Implicitly used by all Dear ImGui functions. Always assumed to be != NULL.
// ImGui::CreateContext() will automatically set this pointer if it is NULL. Change to a different context by calling ImGui::SetCurrentContext().
// 1) Important: globals are not shared across DLL boundaries! If you use DLLs or any form of hot-reloading: you will need to call
//    SetCurrentContext() (with the pointer you got from CreateContext) from each unique static/DLL boundary, and after each hot-reloading.
//    In your debugger, add GImGui to your watch window and notice how its value changes depending on which location you are currently stepping into.
// 2) Important: Dear ImGui functions are not thread-safe because of this pointer.
//    If you want thread-safety to allow N threads to access N different contexts, you can:
//    - Change this variable to use thread local storage so each thread can refer to a different context, in imconfig.h:
//          struct ImGuiContext;
//          extern thread_local ImGuiContext* MyImGuiTLS;
//          #define GImGui MyImGuiTLS
//      And then define MyImGuiTLS in one of your cpp file. Note that thread_local is a C++11 keyword, earlier C++ uses compiler-specific keyword.
//    - Future development aim to make this context pointer explicit to all calls. Also read https://github.com/ocornut/imgui/issues/586
//    - If you need a finite number of contexts, you may compile and use multiple instances of the ImGui code from different namespace.
#ifndef GImGui
ImGuiContext*   GImGui = NULL;
#endif

// Memory Allocator functions. Use SetAllocatorFunctions() to change them.
// If you use DLL hotreloading you might need to call SetAllocatorFunctions() after reloading code from this file.
// Otherwise, you probably don't want to modify them mid-program, and if you use global/static e.g. ImVector<> instances you may need to keep them accessible during program destruction.
#ifndef IMGUI_DISABLE_DEFAULT_ALLOCATORS
static void*   MallocWrapper(size_t size, void* user_data)    { IM_UNUSED(user_data); return malloc(size); }
static void    FreeWrapper(void* ptr, void* user_data)        { IM_UNUSED(user_data); free(ptr); }
#else
static void*   MallocWrapper(size_t size, void* user_data)    { IM_UNUSED(user_data); IM_UNUSED(size); IM_ASSERT(0); return NULL; }
static void    FreeWrapper(void* ptr, void* user_data)        { IM_UNUSED(user_data); IM_UNUSED(ptr); IM_ASSERT(0); }
#endif

static void*  (*GImAllocatorAllocFunc)(size_t size, void* user_data) = MallocWrapper;
static void   (*GImAllocatorFreeFunc)(void* ptr, void* user_data) = FreeWrapper;
static void*    GImAllocatorUserData = NULL;

//-----------------------------------------------------------------------------
// [SECTION] MAIN USER FACING STRUCTURES (ImGuiStyle, ImGuiIO)
//-----------------------------------------------------------------------------

ImGuiStyle::ImGuiStyle()
{
    Alpha                   = 1.0f;             // Global alpha applies to everything in ImGui
    WindowPadding           = ImVec2(8,8);      // Padding within a window
    WindowRounding          = 7.0f;             // Radius of window corners rounding. Set to 0.0f to have rectangular windows
    WindowBorderSize        = 1.0f;             // Thickness of border around windows. Generally set to 0.0f or 1.0f. Other values not well tested.
    WindowMinSize           = ImVec2(32,32);    // Minimum window size
    WindowTitleAlign        = ImVec2(0.0f,0.5f);// Alignment for title bar text
    ChildRounding           = 0.0f;             // Radius of child window corners rounding. Set to 0.0f to have rectangular child windows
    ChildBorderSize         = 1.0f;             // Thickness of border around child windows. Generally set to 0.0f or 1.0f. Other values not well tested.
    PopupRounding           = 0.0f;             // Radius of popup window corners rounding. Set to 0.0f to have rectangular child windows
    PopupBorderSize         = 1.0f;             // Thickness of border around popup or tooltip windows. Generally set to 0.0f or 1.0f. Other values not well tested.
    FramePadding            = ImVec2(4,3);      // Padding within a framed rectangle (used by most widgets)
    FrameRounding           = 0.0f;             // Radius of frame corners rounding. Set to 0.0f to have rectangular frames (used by most widgets).
    FrameBorderSize         = 0.0f;             // Thickness of border around frames. Generally set to 0.0f or 1.0f. Other values not well tested.
    ItemSpacing             = ImVec2(8,4);      // Horizontal and vertical spacing between widgets/lines
    ItemInnerSpacing        = ImVec2(4,4);      // Horizontal and vertical spacing between within elements of a composed widget (e.g. a slider and its label)
    TouchExtraPadding       = ImVec2(0,0);      // Expand reactive bounding box for touch-based system where touch position is not accurate enough. Unfortunately we don't sort widgets so priority on overlap will always be given to the first widget. So don't grow this too much!
    IndentSpacing           = 21.0f;            // Horizontal spacing when e.g. entering a tree node. Generally == (FontSize + FramePadding.x*2).
    ColumnsMinSpacing       = 6.0f;             // Minimum horizontal spacing between two columns
    ScrollbarSize           = 16.0f;            // Width of the vertical scrollbar, Height of the horizontal scrollbar
    ScrollbarRounding       = 9.0f;             // Radius of grab corners rounding for scrollbar
    GrabMinSize             = 10.0f;            // Minimum width/height of a grab box for slider/scrollbar
    GrabRounding            = 0.0f;             // Radius of grabs corners rounding. Set to 0.0f to have rectangular slider grabs.
    TabRounding             = 4.0f;             // Radius of upper corners of a tab. Set to 0.0f to have rectangular tabs.
    TabBorderSize           = 0.0f;             // Thickness of border around tabs.
    ButtonTextAlign         = ImVec2(0.5f,0.5f);// Alignment of button text when button is larger than text.
    SelectableTextAlign     = ImVec2(0.0f,0.0f);// Alignment of selectable text when button is larger than text.
    DisplayWindowPadding    = ImVec2(19,19);    // Window position are clamped to be visible within the display area by at least this amount. Only applies to regular windows.
    DisplaySafeAreaPadding  = ImVec2(3,3);      // If you cannot see the edge of your screen (e.g. on a TV) increase the safe area padding. Covers popups/tooltips as well regular windows.
    MouseCursorScale        = 1.0f;             // Scale software rendered mouse cursor (when io.MouseDrawCursor is enabled). May be removed later.
    AntiAliasedLines        = true;             // Enable anti-aliasing on lines/borders. Disable if you are really short on CPU/GPU.
    AntiAliasedFill         = true;             // Enable anti-aliasing on filled shapes (rounded rectangles, circles, etc.)
    CurveTessellationTol    = 1.25f;            // Tessellation tolerance when using PathBezierCurveTo() without a specific number of segments. Decrease for highly tessellated curves (higher quality, more polygons), increase to reduce quality.

    // Default theme
    ImGui::StyleColorsDark(this);
}

// To scale your entire UI (e.g. if you want your app to use High DPI or generally be DPI aware) you may use this helper function. Scaling the fonts is done separately and is up to you.
// Important: This operation is lossy because we round all sizes to integer. If you need to change your scale multiples, call this over a freshly initialized ImGuiStyle structure rather than scaling multiple times.
void ImGuiStyle::ScaleAllSizes(float scale_factor)
{
    WindowPadding = ImFloor(WindowPadding * scale_factor);
    WindowRounding = ImFloor(WindowRounding * scale_factor);
    WindowMinSize = ImFloor(WindowMinSize * scale_factor);
    ChildRounding = ImFloor(ChildRounding * scale_factor);
    PopupRounding = ImFloor(PopupRounding * scale_factor);
    FramePadding = ImFloor(FramePadding * scale_factor);
    FrameRounding = ImFloor(FrameRounding * scale_factor);
    ItemSpacing = ImFloor(ItemSpacing * scale_factor);
    ItemInnerSpacing = ImFloor(ItemInnerSpacing * scale_factor);
    TouchExtraPadding = ImFloor(TouchExtraPadding * scale_factor);
    IndentSpacing = ImFloor(IndentSpacing * scale_factor);
    ColumnsMinSpacing = ImFloor(ColumnsMinSpacing * scale_factor);
    ScrollbarSize = ImFloor(ScrollbarSize * scale_factor);
    ScrollbarRounding = ImFloor(ScrollbarRounding * scale_factor);
    GrabMinSize = ImFloor(GrabMinSize * scale_factor);
    GrabRounding = ImFloor(GrabRounding * scale_factor);
    TabRounding = ImFloor(TabRounding * scale_factor);
    DisplayWindowPadding = ImFloor(DisplayWindowPadding * scale_factor);
    DisplaySafeAreaPadding = ImFloor(DisplaySafeAreaPadding * scale_factor);
    MouseCursorScale = ImFloor(MouseCursorScale * scale_factor);
}

ImGuiIO::ImGuiIO()
{
    // Most fields are initialized with zero
    memset(this, 0, sizeof(*this));

    // Settings
    ConfigFlags = ImGuiConfigFlags_None;
    BackendFlags = ImGuiBackendFlags_None;
    DisplaySize = ImVec2(-1.0f, -1.0f);
    DeltaTime = 1.0f/60.0f;
    IniSavingRate = 5.0f;
    IniFilename = "imgui.ini";
    LogFilename = "imgui_log.txt";
    MouseDoubleClickTime = 0.30f;
    MouseDoubleClickMaxDist = 6.0f;
    for (int i = 0; i < ImGuiKey_COUNT; i++)
        KeyMap[i] = -1;
    KeyRepeatDelay = 0.250f;
    KeyRepeatRate = 0.050f;
    UserData = NULL;

    Fonts = NULL;
    FontGlobalScale = 1.0f;
    FontDefault = NULL;
    FontAllowUserScaling = false;
    DisplayFramebufferScale = ImVec2(1.0f, 1.0f);

    // Miscellaneous options
    MouseDrawCursor = false;
#ifdef __APPLE__
    ConfigMacOSXBehaviors = true;  // Set Mac OS X style defaults based on __APPLE__ compile time flag
#else
    ConfigMacOSXBehaviors = false;
#endif
    ConfigInputTextCursorBlink = true;
    ConfigWindowsResizeFromEdges = true;
    ConfigWindowsMoveFromTitleBarOnly = false;

    // Platform Functions
    BackendPlatformName = BackendRendererName = NULL;
    BackendPlatformUserData = BackendRendererUserData = BackendLanguageUserData = NULL;
    GetClipboardTextFn = GetClipboardTextFn_DefaultImpl;   // Platform dependent default implementations
    SetClipboardTextFn = SetClipboardTextFn_DefaultImpl;
    ClipboardUserData = NULL;
    ImeSetInputScreenPosFn = ImeSetInputScreenPosFn_DefaultImpl;
    ImeWindowHandle = NULL;

#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
    RenderDrawListsFn = NULL;
#endif

    // Input (NB: we already have memset zero the entire structure!)
    MousePos = ImVec2(-FLT_MAX, -FLT_MAX);
    MousePosPrev = ImVec2(-FLT_MAX, -FLT_MAX);
    MouseDragThreshold = 6.0f;
    for (int i = 0; i < IM_ARRAYSIZE(MouseDownDuration); i++) MouseDownDuration[i] = MouseDownDurationPrev[i] = -1.0f;
    for (int i = 0; i < IM_ARRAYSIZE(KeysDownDuration); i++) KeysDownDuration[i]  = KeysDownDurationPrev[i] = -1.0f;
    for (int i = 0; i < IM_ARRAYSIZE(NavInputsDownDuration); i++) NavInputsDownDuration[i] = -1.0f;
}

// Pass in translated ASCII characters for text input.
// - with glfw you can get those from the callback set in glfwSetCharCallback()
// - on Windows you can get those using ToAscii+keyboard state, or via the WM_CHAR message
void ImGuiIO::AddInputCharacter(ImWchar c)
{
    InputQueueCharacters.push_back(c);
}

void ImGuiIO::AddInputCharactersUTF8(const char* utf8_chars)
{
    while (*utf8_chars != 0)
    {
        unsigned int c = 0;
        utf8_chars += ImTextCharFromUtf8(&c, utf8_chars, NULL);
        if (c > 0 && c <= 0xFFFF)
            InputQueueCharacters.push_back((ImWchar)c);
    }
}

void ImGuiIO::ClearInputCharacters()
{
    InputQueueCharacters.resize(0);
}

//-----------------------------------------------------------------------------
// [SECTION] MISC HELPERS/UTILITIES (Maths, String, Format, Hash, File functions)
//-----------------------------------------------------------------------------

ImVec2 ImLineClosestPoint(const ImVec2& a, const ImVec2& b, const ImVec2& p)
{
    ImVec2 ap = p - a;
    ImVec2 ab_dir = b - a;
    float dot = ap.x * ab_dir.x + ap.y * ab_dir.y;
    if (dot < 0.0f)
        return a;
    float ab_len_sqr = ab_dir.x * ab_dir.x + ab_dir.y * ab_dir.y;
    if (dot > ab_len_sqr)
        return b;
    return a + ab_dir * dot / ab_len_sqr;
}

bool ImTriangleContainsPoint(const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& p)
{
    bool b1 = ((p.x - b.x) * (a.y - b.y) - (p.y - b.y) * (a.x - b.x)) < 0.0f;
    bool b2 = ((p.x - c.x) * (b.y - c.y) - (p.y - c.y) * (b.x - c.x)) < 0.0f;
    bool b3 = ((p.x - a.x) * (c.y - a.y) - (p.y - a.y) * (c.x - a.x)) < 0.0f;
    return ((b1 == b2) && (b2 == b3));
}

void ImTriangleBarycentricCoords(const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& p, float& out_u, float& out_v, float& out_w)
{
    ImVec2 v0 = b - a;
    ImVec2 v1 = c - a;
    ImVec2 v2 = p - a;
    const float denom = v0.x * v1.y - v1.x * v0.y;
    out_v = (v2.x * v1.y - v1.x * v2.y) / denom;
    out_w = (v0.x * v2.y - v2.x * v0.y) / denom;
    out_u = 1.0f - out_v - out_w;
}

ImVec2 ImTriangleClosestPoint(const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& p)
{
    ImVec2 proj_ab = ImLineClosestPoint(a, b, p);
    ImVec2 proj_bc = ImLineClosestPoint(b, c, p);
    ImVec2 proj_ca = ImLineClosestPoint(c, a, p);
    float dist2_ab = ImLengthSqr(p - proj_ab);
    float dist2_bc = ImLengthSqr(p - proj_bc);
    float dist2_ca = ImLengthSqr(p - proj_ca);
    float m = ImMin(dist2_ab, ImMin(dist2_bc, dist2_ca));
    if (m == dist2_ab)
        return proj_ab;
    if (m == dist2_bc)
        return proj_bc;
    return proj_ca;
}

// Consider using _stricmp/_strnicmp under Windows or strcasecmp/strncasecmp. We don't actually use either ImStricmp/ImStrnicmp in the codebase any more.
int ImStricmp(const char* str1, const char* str2)
{
    int d;
    while ((d = toupper(*str2) - toupper(*str1)) == 0 && *str1) { str1++; str2++; }
    return d;
}

int ImStrnicmp(const char* str1, const char* str2, size_t count)
{
    int d = 0;
    while (count > 0 && (d = toupper(*str2) - toupper(*str1)) == 0 && *str1) { str1++; str2++; count--; }
    return d;
}

void ImStrncpy(char* dst, const char* src, size_t count)
{
    if (count < 1) 
        return;
    if (count > 1)
        strncpy(dst, src, count - 1);
    dst[count - 1] = 0;
}

char* ImStrdup(const char* str)
{
    size_t len = strlen(str);
    void* buf = ImGui::MemAlloc(len + 1);
    return (char*)memcpy(buf, (const void*)str, len + 1);
}

char* ImStrdupcpy(char* dst, size_t* p_dst_size, const char* src)
{
    size_t dst_buf_size = p_dst_size ? *p_dst_size : strlen(dst) + 1;
    size_t src_size = strlen(src) + 1;
    if (dst_buf_size < src_size)
    {
        ImGui::MemFree(dst);
        dst = (char*)ImGui::MemAlloc(src_size);
        if (p_dst_size)
            *p_dst_size = src_size;
    }
    return (char*)memcpy(dst, (const void*)src, src_size);
}

const char* ImStrchrRange(const char* str, const char* str_end, char c)
{
    const char* p = (const char*)memchr(str, (int)c, str_end - str);
    return p;
}

int ImStrlenW(const ImWchar* str)
{
    //return (int)wcslen((const wchar_t*)str);	// FIXME-OPT: Could use this when wchar_t are 16-bits
    int n = 0;
    while (*str++) n++;
    return n;
}

// Find end-of-line. Return pointer will point to either first \n, either str_end.
const char* ImStreolRange(const char* str, const char* str_end)
{
    const char* p = (const char*)memchr(str, '\n', str_end - str);
    return p ? p : str_end;
}

const ImWchar* ImStrbolW(const ImWchar* buf_mid_line, const ImWchar* buf_begin) // find beginning-of-line
{
    while (buf_mid_line > buf_begin && buf_mid_line[-1] != '\n')
        buf_mid_line--;
    return buf_mid_line;
}

const char* ImStristr(const char* haystack, const char* haystack_end, const char* needle, const char* needle_end)
{
    if (!needle_end)
        needle_end = needle + strlen(needle);

    const char un0 = (char)toupper(*needle);
    while ((!haystack_end && *haystack) || (haystack_end && haystack < haystack_end))
    {
        if (toupper(*haystack) == un0)
        {
            const char* b = needle + 1;
            for (const char* a = haystack + 1; b < needle_end; a++, b++)
                if (toupper(*a) != toupper(*b))
                    break;
            if (b == needle_end)
                return haystack;
        }
        haystack++;
    }
    return NULL;
}

// Trim str by offsetting contents when there's leading data + writing a \0 at the trailing position. We use this in situation where the cost is negligible.
void ImStrTrimBlanks(char* buf)
{
    char* p = buf;
    while (p[0] == ' ' || p[0] == '\t')     // Leading blanks
        p++;
    char* p_start = p;
    while (*p != 0)                         // Find end of string
        p++;
    while (p > p_start && (p[-1] == ' ' || p[-1] == '\t'))  // Trailing blanks
        p--;
    if (p_start != buf)                     // Copy memory if we had leading blanks
        memmove(buf, p_start, p - p_start);
    buf[p - p_start] = 0;                   // Zero terminate
}

// A) MSVC version appears to return -1 on overflow, whereas glibc appears to return total count (which may be >= buf_size).
// Ideally we would test for only one of those limits at runtime depending on the behavior the vsnprintf(), but trying to deduct it at compile time sounds like a pandora can of worm.
// B) When buf==NULL vsnprintf() will return the output size.
#ifndef IMGUI_DISABLE_FORMAT_STRING_FUNCTIONS

//#define IMGUI_USE_STB_SPRINTF
#ifdef IMGUI_USE_STB_SPRINTF
#define STB_SPRINTF_IMPLEMENTATION
#include "imstb_sprintf.h"
#endif
#include <string>

#if defined(_MSC_VER) && !defined(vsnprintf)
#define vsnprintf _vsnprintf
#endif

int ImFormatString(char* buf, size_t buf_size, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
#ifdef IMGUI_USE_STB_SPRINTF
    int w = stbsp_vsnprintf(buf, (int)buf_size, fmt, args);
#else
    int w = vsnprintf(buf, buf_size, fmt, args);
#endif
    va_end(args);
    if (buf == NULL)
        return w;
    if (w == -1 || w >= (int)buf_size)
        w = (int)buf_size - 1;
    buf[w] = 0;
    return w;
}

int ImFormatStringV(char* buf, size_t buf_size, const char* fmt, va_list args)
{
#ifdef IMGUI_USE_STB_SPRINTF
    int w = stbsp_vsnprintf(buf, (int)buf_size, fmt, args);
#else
    int w = vsnprintf(buf, buf_size, fmt, args);
#endif
    if (buf == NULL)
        return w;
    if (w == -1 || w >= (int)buf_size)
        w = (int)buf_size - 1;
    buf[w] = 0;
    return w;
}
#endif // #ifdef IMGUI_DISABLE_FORMAT_STRING_FUNCTIONS

// CRC32 needs a 1KB lookup table (not cache friendly)
// Although the code to generate the table is simple and shorter than the table itself, using a const table allows us to easily:
// - avoid an unnecessary branch/memory tap, - keep the ImHashXXX functions usable by static constructors, - make it thread-safe.
static const ImU32 GCrc32LookupTable[256] = 
{
    0x00000000,0x77073096,0xEE0E612C,0x990951BA,0x076DC419,0x706AF48F,0xE963A535,0x9E6495A3,0x0EDB8832,0x79DCB8A4,0xE0D5E91E,0x97D2D988,0x09B64C2B,0x7EB17CBD,0xE7B82D07,0x90BF1D91,
    0x1DB71064,0x6AB020F2,0xF3B97148,0x84BE41DE,0x1ADAD47D,0x6DDDE4EB,0xF4D4B551,0x83D385C7,0x136C9856,0x646BA8C0,0xFD62F97A,0x8A65C9EC,0x14015C4F,0x63066CD9,0xFA0F3D63,0x8D080DF5,
    0x3B6E20C8,0x4C69105E,0xD56041E4,0xA2677172,0x3C03E4D1,0x4B04D447,0xD20D85FD,0xA50AB56B,0x35B5A8FA,0x42B2986C,0xDBBBC9D6,0xACBCF940,0x32D86CE3,0x45DF5C75,0xDCD60DCF,0xABD13D59,
    0x26D930AC,0x51DE003A,0xC8D75180,0xBFD06116,0x21B4F4B5,0x56B3C423,0xCFBA9599,0xB8BDA50F,0x2802B89E,0x5F058808,0xC60CD9B2,0xB10BE924,0x2F6F7C87,0x58684C11,0xC1611DAB,0xB6662D3D,
    0x76DC4190,0x01DB7106,0x98D220BC,0xEFD5102A,0x71B18589,0x06B6B51F,0x9FBFE4A5,0xE8B8D433,0x7807C9A2,0x0F00F934,0x9609A88E,0xE10E9818,0x7F6A0DBB,0x086D3D2D,0x91646C97,0xE6635C01,
    0x6B6B51F4,0x1C6C6162,0x856530D8,0xF262004E,0x6C0695ED,0x1B01A57B,0x8208F4C1,0xF50FC457,0x65B0D9C6,0x12B7E950,0x8BBEB8EA,0xFCB9887C,0x62DD1DDF,0x15DA2D49,0x8CD37CF3,0xFBD44C65,
    0x4DB26158,0x3AB551CE,0xA3BC0074,0xD4BB30E2,0x4ADFA541,0x3DD895D7,0xA4D1C46D,0xD3D6F4FB,0x4369E96A,0x346ED9FC,0xAD678846,0xDA60B8D0,0x44042D73,0x33031DE5,0xAA0A4C5F,0xDD0D7CC9,
    0x5005713C,0x270241AA,0xBE0B1010,0xC90C2086,0x5768B525,0x206F85B3,0xB966D409,0xCE61E49F,0x5EDEF90E,0x29D9C998,0xB0D09822,0xC7D7A8B4,0x59B33D17,0x2EB40D81,0xB7BD5C3B,0xC0BA6CAD,
    0xEDB88320,0x9ABFB3B6,0x03B6E20C,0x74B1D29A,0xEAD54739,0x9DD277AF,0x04DB2615,0x73DC1683,0xE3630B12,0x94643B84,0x0D6D6A3E,0x7A6A5AA8,0xE40ECF0B,0x9309FF9D,0x0A00AE27,0x7D079EB1,
    0xF00F9344,0x8708A3D2,0x1E01F268,0x6906C2FE,0xF762575D,0x806567CB,0x196C3671,0x6E6B06E7,0xFED41B76,0x89D32BE0,0x10DA7A5A,0x67DD4ACC,0xF9B9DF6F,0x8EBEEFF9,0x17B7BE43,0x60B08ED5,
    0xD6D6A3E8,0xA1D1937E,0x38D8C2C4,0x4FDFF252,0xD1BB67F1,0xA6BC5767,0x3FB506DD,0x48B2364B,0xD80D2BDA,0xAF0A1B4C,0x36034AF6,0x41047A60,0xDF60EFC3,0xA867DF55,0x316E8EEF,0x4669BE79,
    0xCB61B38C,0xBC66831A,0x256FD2A0,0x5268E236,0xCC0C7795,0xBB0B4703,0x220216B9,0x5505262F,0xC5BA3BBE,0xB2BD0B28,0x2BB45A92,0x5CB36A04,0xC2D7FFA7,0xB5D0CF31,0x2CD99E8B,0x5BDEAE1D,
    0x9B64C2B0,0xEC63F226,0x756AA39C,0x026D930A,0x9C0906A9,0xEB0E363F,0x72076785,0x05005713,0x95BF4A82,0xE2B87A14,0x7BB12BAE,0x0CB61B38,0x92D28E9B,0xE5D5BE0D,0x7CDCEFB7,0x0BDBDF21,
    0x86D3D2D4,0xF1D4E242,0x68DDB3F8,0x1FDA836E,0x81BE16CD,0xF6B9265B,0x6FB077E1,0x18B74777,0x88085AE6,0xFF0F6A70,0x66063BCA,0x11010B5C,0x8F659EFF,0xF862AE69,0x616BFFD3,0x166CCF45,
    0xA00AE278,0xD70DD2EE,0x4E048354,0x3903B3C2,0xA7672661,0xD06016F7,0x4969474D,0x3E6E77DB,0xAED16A4A,0xD9D65ADC,0x40DF0B66,0x37D83BF0,0xA9BCAE53,0xDEBB9EC5,0x47B2CF7F,0x30B5FFE9,
    0xBDBDF21C,0xCABAC28A,0x53B39330,0x24B4A3A6,0xBAD03605,0xCDD70693,0x54DE5729,0x23D967BF,0xB3667A2E,0xC4614AB8,0x5D681B02,0x2A6F2B94,0xB40BBE37,0xC30C8EA1,0x5A05DF1B,0x2D02EF8D,
};

// Known size hash
// It is ok to call ImHashData on a string with known length but the ### operator won't be supported.
// FIXME-OPT: Replace with e.g. FNV1a hash? CRC32 pretty much randomly access 1KB. Need to do proper measurements.
ImU32 ImHashData(const void* data_p, size_t data_size, ImU32 seed)
{
    ImU32 crc = ~seed;
    const unsigned char* data = (const unsigned char*)data_p;
    const ImU32* crc32_lut = GCrc32LookupTable;
    while (data_size-- != 0)
        crc = (crc >> 8) ^ crc32_lut[(crc & 0xFF) ^ *data++];
    return ~crc;
}

// Zero-terminated string hash, with support for ### to reset back to seed value
// We support a syntax of "label###id" where only "###id" is included in the hash, and only "label" gets displayed.
// Because this syntax is rarely used we are optimizing for the common case.
// - If we reach ### in the string we discard the hash so far and reset to the seed.
// - We don't do 'current += 2; continue;' after handling ### to keep the code smaller/faster (measured ~10% diff in Debug build)
// FIXME-OPT: Replace with e.g. FNV1a hash? CRC32 pretty much randomly access 1KB. Need to do proper measurements.
ImU32 ImHashStr(const char* data, size_t data_size, ImU32 seed)
{
    seed = ~seed;
    ImU32 crc = seed;
    const unsigned char* src = (const unsigned char*)data;
    const ImU32* crc32_lut = GCrc32LookupTable;
    if (data_size != 0)
    {
        while (data_size-- != 0)
        {
            unsigned char c = *src++;
            if (c == '#' && src[0] == '#' && src[1] == '#')
                crc = seed;
            crc = (crc >> 8) ^ crc32_lut[(crc & 0xFF) ^ c];
        }
    }
    else
    {
        while (unsigned char c = *src++)
        {
            if (c == '#' && src[0] == '#' && src[1] == '#')
                crc = seed;
            crc = (crc >> 8) ^ crc32_lut[(crc & 0xFF) ^ c];
        }
    }
    return ~crc;
}

FILE* ImFileOpen(const char* filename, const char* mode)
{
#if defined(_WIN32) && !defined(__CYGWIN__) && !defined(__GNUC__)
    // We need a fopen() wrapper because MSVC/Windows fopen doesn't handle UTF-8 filenames. Converting both strings from UTF-8 to wchar format (using a single allocation, because we can)
    const int filename_wsize = ImTextCountCharsFromUtf8(filename, NULL) + 1;
    const int mode_wsize = ImTextCountCharsFromUtf8(mode, NULL) + 1;
    ImVector<ImWchar> buf;
    buf.resize(filename_wsize + mode_wsize);
    ImTextStrFromUtf8(&buf[0], filename_wsize, filename, NULL);
    ImTextStrFromUtf8(&buf[filename_wsize], mode_wsize, mode, NULL);
    return _wfopen((wchar_t*)&buf[0], (wchar_t*)&buf[filename_wsize]);
#else
    return fopen(filename, mode);
#endif
}

// Load file content into memory
// Memory allocated with ImGui::MemAlloc(), must be freed by user using ImGui::MemFree()
void* ImFileLoadToMemory(const char* filename, const char* file_open_mode, size_t* out_file_size, int padding_bytes)
{
    IM_ASSERT(filename && file_open_mode);
    if (out_file_size)
        *out_file_size = 0;

    FILE* f;
    if ((f = ImFileOpen(filename, file_open_mode)) == NULL)
        return NULL;

    long file_size_signed;
    if (fseek(f, 0, SEEK_END) || (file_size_signed = ftell(f)) == -1 || fseek(f, 0, SEEK_SET))
    {
        fclose(f);
        return NULL;
    }

    size_t file_size = (size_t)file_size_signed;
    void* file_data = ImGui::MemAlloc(file_size + padding_bytes);
    if (file_data == NULL)
    {
        fclose(f);
        return NULL;
    }
    if (fread(file_data, 1, file_size, f) != file_size)
    {
        fclose(f);
        ImGui::MemFree(file_data);
        return NULL;
    }
    if (padding_bytes > 0)
        memset((void*)(((char*)file_data) + file_size), 0, (size_t)padding_bytes);

    fclose(f);
    if (out_file_size)
        *out_file_size = file_size;

    return file_data;
}

//-----------------------------------------------------------------------------
// [SECTION] MISC HELPERS/UTILITIES (ImText* functions)
//-----------------------------------------------------------------------------

// Convert UTF-8 to 32-bits character, process single character input.
// Based on stb_from_utf8() from github.com/nothings/stb/
// We handle UTF-8 decoding error by skipping forward.
int ImTextCharFromUtf8(unsigned int* out_char, const char* in_text, const char* in_text_end)
{
    unsigned int c = (unsigned int)-1;
    const unsigned char* str = (const unsigned char*)in_text;
    if (!(*str & 0x80))
    {
        c = (unsigned int)(*str++);
        *out_char = c;
        return 1;
    }
    if ((*str & 0xe0) == 0xc0)
    {
        *out_char = 0xFFFD; // will be invalid but not end of string
        if (in_text_end && in_text_end - (const char*)str < 2) return 1;
        if (*str < 0xc2) return 2;
        c = (unsigned int)((*str++ & 0x1f) << 6);
        if ((*str & 0xc0) != 0x80) return 2;
        c += (*str++ & 0x3f);
        *out_char = c;
        return 2;
    }
    if ((*str & 0xf0) == 0xe0)
    {
        *out_char = 0xFFFD; // will be invalid but not end of string
        if (in_text_end && in_text_end - (const char*)str < 3) return 1;
        if (*str == 0xe0 && (str[1] < 0xa0 || str[1] > 0xbf)) return 3;
        if (*str == 0xed && str[1] > 0x9f) return 3; // str[1] < 0x80 is checked below
        c = (unsigned int)((*str++ & 0x0f) << 12);
        if ((*str & 0xc0) != 0x80) return 3;
        c += (unsigned int)((*str++ & 0x3f) << 6);
        if ((*str & 0xc0) != 0x80) return 3;
        c += (*str++ & 0x3f);
        *out_char = c;
        return 3;
    }
    if ((*str & 0xf8) == 0xf0)
    {
        *out_char = 0xFFFD; // will be invalid but not end of string
        if (in_text_end && in_text_end - (const char*)str < 4) return 1;
        if (*str > 0xf4) return 4;
        if (*str == 0xf0 && (str[1] < 0x90 || str[1] > 0xbf)) return 4;
        if (*str == 0xf4 && str[1] > 0x8f) return 4; // str[1] < 0x80 is checked below
        c = (unsigned int)((*str++ & 0x07) << 18);
        if ((*str & 0xc0) != 0x80) return 4;
        c += (unsigned int)((*str++ & 0x3f) << 12);
        if ((*str & 0xc0) != 0x80) return 4;
        c += (unsigned int)((*str++ & 0x3f) << 6);
        if ((*str & 0xc0) != 0x80) return 4;
        c += (*str++ & 0x3f);
        // utf-8 encodings of values used in surrogate pairs are invalid
        if ((c & 0xFFFFF800) == 0xD800) return 4;
        *out_char = c;
        return 4;
    }
    *out_char = 0;
    return 0;
}

int ImTextStrFromUtf8(ImWchar* buf, int buf_size, const char* in_text, const char* in_text_end, const char** in_text_remaining)
{
    ImWchar* buf_out = buf;
    ImWchar* buf_end = buf + buf_size;
    while (buf_out < buf_end-1 && (!in_text_end || in_text < in_text_end) && *in_text)
    {
        unsigned int c;
        in_text += ImTextCharFromUtf8(&c, in_text, in_text_end);
        if (c == 0)
            break;
        if (c < 0x10000)    // FIXME: Losing characters that don't fit in 2 bytes
            *buf_out++ = (ImWchar)c;
    }
    *buf_out = 0;
    if (in_text_remaining)
        *in_text_remaining = in_text;
    return (int)(buf_out - buf);
}

int ImTextCountCharsFromUtf8(const char* in_text, const char* in_text_end)
{
    int char_count = 0;
    while ((!in_text_end || in_text < in_text_end) && *in_text)
    {
        unsigned int c;
        in_text += ImTextCharFromUtf8(&c, in_text, in_text_end);
        if (c == 0)
            break;
        if (c < 0x10000)
            char_count++;
    }
    return char_count;
}

// Based on stb_to_utf8() from github.com/nothings/stb/
static inline int ImTextCharToUtf8(char* buf, int buf_size, unsigned int c)
{
    if (c < 0x80)
    {
        buf[0] = (char)c;
        return 1;
    }
    if (c < 0x800)
    {
        if (buf_size < 2) return 0;
        buf[0] = (char)(0xc0 + (c >> 6));
        buf[1] = (char)(0x80 + (c & 0x3f));
        return 2;
    }
    if (c >= 0xdc00 && c < 0xe000)
    {
        return 0;
    }
    if (c >= 0xd800 && c < 0xdc00)
    {
        if (buf_size < 4) return 0;
        buf[0] = (char)(0xf0 + (c >> 18));
        buf[1] = (char)(0x80 + ((c >> 12) & 0x3f));
        buf[2] = (char)(0x80 + ((c >> 6) & 0x3f));
        buf[3] = (char)(0x80 + ((c ) & 0x3f));
        return 4;
    }
    //else if (c < 0x10000)
    {
        if (buf_size < 3) return 0;
        buf[0] = (char)(0xe0 + (c >> 12));
        buf[1] = (char)(0x80 + ((c>> 6) & 0x3f));
        buf[2] = (char)(0x80 + ((c ) & 0x3f));
        return 3;
    }
}

// Not optimal but we very rarely use this function.
int ImTextCountUtf8BytesFromChar(const char* in_text, const char* in_text_end)
{
    unsigned int dummy = 0;
    return ImTextCharFromUtf8(&dummy, in_text, in_text_end);
}

static inline int ImTextCountUtf8BytesFromChar(unsigned int c)
{
    if (c < 0x80) return 1;
    if (c < 0x800) return 2;
    if (c >= 0xdc00 && c < 0xe000) return 0;
    if (c >= 0xd800 && c < 0xdc00) return 4;
    return 3;
}

int ImTextStrToUtf8(char* buf, int buf_size, const ImWchar* in_text, const ImWchar* in_text_end)
{
    char* buf_out = buf;
    const char* buf_end = buf + buf_size;
    while (buf_out < buf_end-1 && (!in_text_end || in_text < in_text_end) && *in_text)
    {
        unsigned int c = (unsigned int)(*in_text++);
        if (c < 0x80)
            *buf_out++ = (char)c;
        else
            buf_out += ImTextCharToUtf8(buf_out, (int)(buf_end-buf_out-1), c);
    }
    *buf_out = 0;
    return (int)(buf_out - buf);
}

int ImTextCountUtf8BytesFromStr(const ImWchar* in_text, const ImWchar* in_text_end)
{
    int bytes_count = 0;
    while ((!in_text_end || in_text < in_text_end) && *in_text)
    {
        unsigned int c = (unsigned int)(*in_text++);
        if (c < 0x80)
            bytes_count++;
        else
            bytes_count += ImTextCountUtf8BytesFromChar(c);
    }
    return bytes_count;
}

//-----------------------------------------------------------------------------
// [SECTION] MISC HELPERS/UTILTIES (Color functions)
// Note: The Convert functions are early design which are not consistent with other API.
//-----------------------------------------------------------------------------

ImVec4 ImGui::ColorConvertU32ToFloat4(ImU32 in)
{
    float s = 1.0f/255.0f;
    return ImVec4(
        ((in >> IM_COL32_R_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_G_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_B_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_A_SHIFT) & 0xFF) * s);
}

ImU32 ImGui::ColorConvertFloat4ToU32(const ImVec4& in)
{
    ImU32 out;
    out  = ((ImU32)IM_F32_TO_INT8_SAT(in.x)) << IM_COL32_R_SHIFT;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.y)) << IM_COL32_G_SHIFT;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.z)) << IM_COL32_B_SHIFT;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.w)) << IM_COL32_A_SHIFT;
    return out;
}

// Convert rgb floats ([0-1],[0-1],[0-1]) to hsv floats ([0-1],[0-1],[0-1]), from Foley & van Dam p592
// Optimized http://lolengine.net/blog/2013/01/13/fast-rgb-to-hsv
void ImGui::ColorConvertRGBtoHSV(float r, float g, float b, float& out_h, float& out_s, float& out_v)
{
    float K = 0.f;
    if (g < b)
    {
        ImSwap(g, b);
        K = -1.f;
    }
    if (r < g)
    {
        ImSwap(r, g);
        K = -2.f / 6.f - K;
    }

    const float chroma = r - (g < b ? g : b);
    out_h = ImFabs(K + (g - b) / (6.f * chroma + 1e-20f));
    out_s = chroma / (r + 1e-20f);
    out_v = r;
}

// Convert hsv floats ([0-1],[0-1],[0-1]) to rgb floats ([0-1],[0-1],[0-1]), from Foley & van Dam p593
// also http://en.wikipedia.org/wiki/HSL_and_HSV
void ImGui::ColorConvertHSVtoRGB(float h, float s, float v, float& out_r, float& out_g, float& out_b)
{
    if (s == 0.0f)
    {
        // gray
        out_r = out_g = out_b = v;
        return;
    }

    h = ImFmod(h, 1.0f) / (60.0f/360.0f);
    int   i = (int)h;
    float f = h - (float)i;
    float p = v * (1.0f - s);
    float q = v * (1.0f - s * f);
    float t = v * (1.0f - s * (1.0f - f));

    switch (i)
    {
    case 0: out_r = v; out_g = t; out_b = p; break;
    case 1: out_r = q; out_g = v; out_b = p; break;
    case 2: out_r = p; out_g = v; out_b = t; break;
    case 3: out_r = p; out_g = q; out_b = v; break;
    case 4: out_r = t; out_g = p; out_b = v; break;
    case 5: default: out_r = v; out_g = p; out_b = q; break;
    }
}

ImU32 ImGui::GetColorU32(ImGuiCol idx, float alpha_mul)
{
    ImGuiStyle& style = GImGui->Style;
    ImVec4 c = style.Colors[idx];
    c.w *= style.Alpha * alpha_mul;
    return ColorConvertFloat4ToU32(c);
}

ImU32 ImGui::GetColorU32(const ImVec4& col)
{
    ImGuiStyle& style = GImGui->Style;
    ImVec4 c = col;
    c.w *= style.Alpha;
    return ColorConvertFloat4ToU32(c);
}

const ImVec4& ImGui::GetStyleColorVec4(ImGuiCol idx)
{
    ImGuiStyle& style = GImGui->Style;
    return style.Colors[idx];
}

ImU32 ImGui::GetColorU32(ImU32 col)
{
    float style_alpha = GImGui->Style.Alpha;
    if (style_alpha >= 1.0f)
        return col;
    ImU32 a = (col & IM_COL32_A_MASK) >> IM_COL32_A_SHIFT;
    a = (ImU32)(a * style_alpha); // We don't need to clamp 0..255 because Style.Alpha is in 0..1 range.
    return (col & ~IM_COL32_A_MASK) | (a << IM_COL32_A_SHIFT);
}

//-----------------------------------------------------------------------------
// [SECTION] ImGuiStorage
// Helper: Key->value storage
//-----------------------------------------------------------------------------

// std::lower_bound but without the bullshit
static ImGuiStorage::Pair* LowerBound(ImVector<ImGuiStorage::Pair>& data, ImGuiID key)
{
    ImGuiStorage::Pair* first = data.Data;
    ImGuiStorage::Pair* last = data.Data + data.Size;
    size_t count = (size_t)(last - first);
    while (count > 0)
    {
        size_t count2 = count >> 1;
        ImGuiStorage::Pair* mid = first + count2;
        if (mid->key < key)
        {
            first = ++mid;
            count -= count2 + 1;
        }
        else
        {
            count = count2;
        }
    }
    return first;
}

// For quicker full rebuild of a storage (instead of an incremental one), you may add all your contents and then sort once.
void ImGuiStorage::BuildSortByKey()
{
    struct StaticFunc
    {
        static int IMGUI_CDECL PairCompareByID(const void* lhs, const void* rhs)
        {
            // We can't just do a subtraction because qsort uses signed integers and subtracting our ID doesn't play well with that.
            if (((const Pair*)lhs)->key > ((const Pair*)rhs)->key) return +1;
            if (((const Pair*)lhs)->key < ((const Pair*)rhs)->key) return -1;
            return 0;
        }
    };
    if (Data.Size > 1)
        ImQsort(Data.Data, (size_t)Data.Size, sizeof(Pair), StaticFunc::PairCompareByID);
}

int ImGuiStorage::GetInt(ImGuiID key, int default_val) const
{
    ImGuiStorage::Pair* it = LowerBound(const_cast<ImVector<ImGuiStorage::Pair>&>(Data), key);
    if (it == Data.end() || it->key != key)
        return default_val;
    return it->val_i;
}

bool ImGuiStorage::GetBool(ImGuiID key, bool default_val) const
{
    return GetInt(key, default_val ? 1 : 0) != 0;
}

float ImGuiStorage::GetFloat(ImGuiID key, float default_val) const
{
    ImGuiStorage::Pair* it = LowerBound(const_cast<ImVector<ImGuiStorage::Pair>&>(Data), key);
    if (it == Data.end() || it->key != key)
        return default_val;
    return it->val_f;
}

void* ImGuiStorage::GetVoidPtr(ImGuiID key) const
{
    ImGuiStorage::Pair* it = LowerBound(const_cast<ImVector<ImGuiStorage::Pair>&>(Data), key);
    if (it == Data.end() || it->key != key)
        return NULL;
    return it->val_p;
}

// References are only valid until a new value is added to the storage. Calling a Set***() function or a Get***Ref() function invalidates the pointer.
int* ImGuiStorage::GetIntRef(ImGuiID key, int default_val)
{
    ImGuiStorage::Pair* it = LowerBound(Data, key);
    if (it == Data.end() || it->key != key)
        it = Data.insert(it, Pair(key, default_val));
    return &it->val_i;
}

bool* ImGuiStorage::GetBoolRef(ImGuiID key, bool default_val)
{
    return (bool*)GetIntRef(key, default_val ? 1 : 0);
}

float* ImGuiStorage::GetFloatRef(ImGuiID key, float default_val)
{
    ImGuiStorage::Pair* it = LowerBound(Data, key);
    if (it == Data.end() || it->key != key)
        it = Data.insert(it, Pair(key, default_val));
    return &it->val_f;
}

void** ImGuiStorage::GetVoidPtrRef(ImGuiID key, void* default_val)
{
    ImGuiStorage::Pair* it = LowerBound(Data, key);
    if (it == Data.end() || it->key != key)
        it = Data.insert(it, Pair(key, default_val));
    return &it->val_p;
}

// FIXME-OPT: Need a way to reuse the result of lower_bound when doing GetInt()/SetInt() - not too bad because it only happens on explicit interaction (maximum one a frame)
void ImGuiStorage::SetInt(ImGuiID key, int val)
{
    ImGuiStorage::Pair* it = LowerBound(Data, key);
    if (it == Data.end() || it->key != key)
    {
        Data.insert(it, Pair(key, val));
        return;
    }
    it->val_i = val;
}

void ImGuiStorage::SetBool(ImGuiID key, bool val)
{
    SetInt(key, val ? 1 : 0);
}

void ImGuiStorage::SetFloat(ImGuiID key, float val)
{
    ImGuiStorage::Pair* it = LowerBound(Data, key);
    if (it == Data.end() || it->key != key)
    {
        Data.insert(it, Pair(key, val));
        return;
    }
    it->val_f = val;
}

void ImGuiStorage::SetVoidPtr(ImGuiID key, void* val)
{
    ImGuiStorage::Pair* it = LowerBound(Data, key);
    if (it == Data.end() || it->key != key)
    {
        Data.insert(it, Pair(key, val));
        return;
    }
    it->val_p = val;
}

void ImGuiStorage::SetAllInt(int v)
{
    for (int i = 0; i < Data.Size; i++)
        Data[i].val_i = v;
}

//-----------------------------------------------------------------------------
// [SECTION] ImGuiTextFilter
//-----------------------------------------------------------------------------

// Helper: Parse and apply text filters. In format "aaaaa[,bbbb][,ccccc]"
ImGuiTextFilter::ImGuiTextFilter(const char* default_filter)
{
    if (default_filter)
    {
        ImStrncpy(InputBuf, default_filter, IM_ARRAYSIZE(InputBuf));
        Build();
    }
    else
    {
        InputBuf[0] = 0;
        CountGrep = 0;
    }
}

bool ImGuiTextFilter::Draw(const char* label, float width)
{
    if (width != 0.0f)
        ImGui::PushItemWidth(width);
    bool value_changed = ImGui::InputText(label, InputBuf, IM_ARRAYSIZE(InputBuf));
    if (width != 0.0f)
        ImGui::PopItemWidth();
    if (value_changed)
        Build();
    return value_changed;
}

void ImGuiTextFilter::TextRange::split(char separator, ImVector<TextRange>* out) const
{
    out->resize(0);
    const char* wb = b;
    const char* we = wb;
    while (we < e)
    {
        if (*we == separator)
        {
            out->push_back(TextRange(wb, we));
            wb = we + 1;
        }
        we++;
    }
    if (wb != we)
        out->push_back(TextRange(wb, we));
}

void ImGuiTextFilter::Build()
{
    Filters.resize(0);
    TextRange input_range(InputBuf, InputBuf+strlen(InputBuf));
    input_range.split(',', &Filters);

    CountGrep = 0;
    for (int i = 0; i != Filters.Size; i++)
    {
        TextRange& f = Filters[i];
        while (f.b < f.e && ImCharIsBlankA(f.b[0]))
            f.b++;
        while (f.e > f.b && ImCharIsBlankA(f.e[-1]))
            f.e--;
        if (f.empty())
            continue;
        if (Filters[i].b[0] != '-')
            CountGrep += 1;
    }
}

bool ImGuiTextFilter::PassFilter(const char* text, const char* text_end) const
{
    if (Filters.empty())
        return true;

    if (text == NULL)
        text = "";

    for (int i = 0; i != Filters.Size; i++)
    {
        const TextRange& f = Filters[i];
        if (f.empty())
            continue;
        if (f.b[0] == '-')
        {
            // Subtract
            if (ImStristr(text, text_end, f.begin()+1, f.end()) != NULL)
                return false;
        }
        else
        {
            // Grep
            if (ImStristr(text, text_end, f.begin(), f.end()) != NULL)
                return true;
        }
    }

    // Implicit * grep
    if (CountGrep == 0)
        return true;

    return false;
}

//-----------------------------------------------------------------------------
// [SECTION] ImGuiTextBuffer
//-----------------------------------------------------------------------------

// On some platform vsnprintf() takes va_list by reference and modifies it.
// va_copy is the 'correct' way to copy a va_list but Visual Studio prior to 2013 doesn't have it.
#ifndef va_copy
#if defined(__GNUC__) || defined(__clang__)
#define va_copy(dest, src) __builtin_va_copy(dest, src)
#else
#define va_copy(dest, src) (dest = src)
#endif
#endif

char ImGuiTextBuffer::EmptyString[1] = { 0 };

void ImGuiTextBuffer::append(const char* str, const char* str_end)
{
    int len = str_end ? (int)(str_end - str) : (int)strlen(str);

    // Add zero-terminator the first time
    const int write_off = (Buf.Size != 0) ? Buf.Size : 1;
    const int needed_sz = write_off + len;
    if (write_off + len >= Buf.Capacity)
    {
        int new_capacity = Buf.Capacity * 2;
        Buf.reserve(needed_sz > new_capacity ? needed_sz : new_capacity);
    }

    Buf.resize(needed_sz);
    memcpy(&Buf[write_off - 1], str, (size_t)len);
    Buf[write_off - 1 + len] = 0;
}

void ImGuiTextBuffer::appendf(const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    appendfv(fmt, args);
    va_end(args);
}

// Helper: Text buffer for logging/accumulating text
void ImGuiTextBuffer::appendfv(const char* fmt, va_list args)
{
    va_list args_copy;
    va_copy(args_copy, args);

    int len = ImFormatStringV(NULL, 0, fmt, args);         // FIXME-OPT: could do a first pass write attempt, likely successful on first pass.
    if (len <= 0)
    {
        va_end(args_copy);
        return;
    }

    // Add zero-terminator the first time
    const int write_off = (Buf.Size != 0) ? Buf.Size : 1;
    const int needed_sz = write_off + len;
    if (write_off + len >= Buf.Capacity)
    {
        int new_capacity = Buf.Capacity * 2;
        Buf.reserve(needed_sz > new_capacity ? needed_sz : new_capacity);
    }

    Buf.resize(needed_sz);
    ImFormatStringV(&Buf[write_off - 1], (size_t)len + 1, fmt, args_copy);
    va_end(args_copy);
}

//-----------------------------------------------------------------------------
// [SECTION] ImGuiListClipper
// This is currently not as flexible/powerful as it should be, needs some rework (see TODO)
//-----------------------------------------------------------------------------

static void SetCursorPosYAndSetupDummyPrevLine(float pos_y, float line_height)
{
    // Set cursor position and a few other things so that SetScrollHereY() and Columns() can work when seeking cursor.
    // FIXME: It is problematic that we have to do that here, because custom/equivalent end-user code would stumble on the same issue.
    // The clipper should probably have a 4th step to display the last item in a regular manner.
    ImGui::SetCursorPosY(pos_y);
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    window->DC.CursorPosPrevLine.y = window->DC.CursorPos.y - line_height;      // Setting those fields so that SetScrollHereY() can properly function after the end of our clipper usage.
    window->DC.PrevLineSize.y = (line_height - GImGui->Style.ItemSpacing.y);    // If we end up needing more accurate data (to e.g. use SameLine) we may as well make the clipper have a fourth step to let user process and display the last item in their list.
    if (window->DC.ColumnsSet)
        window->DC.ColumnsSet->LineMinY = window->DC.CursorPos.y;           // Setting this so that cell Y position are set properly
}

// Use case A: Begin() called from constructor with items_height<0, then called again from Sync() in StepNo 1
// Use case B: Begin() called from constructor with items_height>0
// FIXME-LEGACY: Ideally we should remove the Begin/End functions but they are part of the legacy API we still support. This is why some of the code in Step() calling Begin() and reassign some fields, spaghetti style.
void ImGuiListClipper::Begin(int count, float items_height)
{
    StartPosY = ImGui::GetCursorPosY();
    ItemsHeight = items_height;
    ItemsCount = count;
    StepNo = 0;
    DisplayEnd = DisplayStart = -1;
    if (ItemsHeight > 0.0f)
    {
        ImGui::CalcListClipping(ItemsCount, ItemsHeight, &DisplayStart, &DisplayEnd); // calculate how many to clip/display
        if (DisplayStart > 0)
            SetCursorPosYAndSetupDummyPrevLine(StartPosY + DisplayStart * ItemsHeight, ItemsHeight); // advance cursor
        StepNo = 2;
    }
}

void ImGuiListClipper::End()
{
    if (ItemsCount < 0)
        return;
    // In theory here we should assert that ImGui::GetCursorPosY() == StartPosY + DisplayEnd * ItemsHeight, but it feels saner to just seek at the end and not assert/crash the user.
    if (ItemsCount < INT_MAX)
        SetCursorPosYAndSetupDummyPrevLine(StartPosY + ItemsCount * ItemsHeight, ItemsHeight); // advance cursor
    ItemsCount = -1;
    StepNo = 3;
}

bool ImGuiListClipper::Step()
{
    if (ItemsCount == 0 || ImGui::GetCurrentWindowRead()->SkipItems)
    {
        ItemsCount = -1;
        return false;
    }
    if (StepNo == 0) // Step 0: the clipper let you process the first element, regardless of it being visible or not, so we can measure the element height.
    {
        DisplayStart = 0;
        DisplayEnd = 1;
        StartPosY = ImGui::GetCursorPosY();
        StepNo = 1;
        return true;
    }
    if (StepNo == 1) // Step 1: the clipper infer height from first element, calculate the actual range of elements to display, and position the cursor before the first element.
    {
        if (ItemsCount == 1) { ItemsCount = -1; return false; }
        float items_height = ImGui::GetCursorPosY() - StartPosY;
        IM_ASSERT(items_height > 0.0f);   // If this triggers, it means Item 0 hasn't moved the cursor vertically
        Begin(ItemsCount-1, items_height);
        DisplayStart++;
        DisplayEnd++;
        StepNo = 3;
        return true;
    }
    if (StepNo == 2) // Step 2: dummy step only required if an explicit items_height was passed to constructor or Begin() and user still call Step(). Does nothing and switch to Step 3.
    {
        IM_ASSERT(DisplayStart >= 0 && DisplayEnd >= 0);
        StepNo = 3;
        return true;
    }
    if (StepNo == 3) // Step 3: the clipper validate that we have reached the expected Y position (corresponding to element DisplayEnd), advance the cursor to the end of the list and then returns 'false' to end the loop.
        End();
    return false;
}

//-----------------------------------------------------------------------------
// [SECTION] RENDER HELPERS
// Those (internal) functions are currently quite a legacy mess - their signature and behavior will change.
// Also see imgui_draw.cpp for some more which have been reworked to not rely on ImGui:: state.
//-----------------------------------------------------------------------------

const char* ImGui::FindRenderedTextEnd(const char* text, const char* text_end)
{
    const char* text_display_end = text;
    if (!text_end)
        text_end = (const char*)-1;

    while (text_display_end < text_end && *text_display_end != '\0' && (text_display_end[0] != '#' || text_display_end[1] != '#'))
        text_display_end++;
    return text_display_end;
}

// Internal ImGui functions to render text
// RenderText***() functions calls ImDrawList::AddText() calls ImBitmapFont::RenderText()
void ImGui::RenderText(ImVec2 pos, const char* text, const char* text_end, bool hide_text_after_hash)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    // Hide anything after a '##' string
    const char* text_display_end;
    if (hide_text_after_hash)
    {
        text_display_end = FindRenderedTextEnd(text, text_end);
    }
    else
    {
        if (!text_end)
            text_end = text + strlen(text); // FIXME-OPT
        text_display_end = text_end;
    }

    if (text != text_display_end)
    {
        window->DrawList->AddText(g.Font, g.FontSize, pos, GetColorU32(ImGuiCol_Text), text, text_display_end);
        if (g.LogEnabled)
            LogRenderedText(&pos, text, text_display_end);
    }
}

void ImGui::RenderTextWrapped(ImVec2 pos, const char* text, const char* text_end, float wrap_width)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    if (!text_end)
        text_end = text + strlen(text); // FIXME-OPT

    if (text != text_end)
    {
        window->DrawList->AddText(g.Font, g.FontSize, pos, GetColorU32(ImGuiCol_Text), text, text_end, wrap_width);
        if (g.LogEnabled)
            LogRenderedText(&pos, text, text_end);
    }
}

// Default clip_rect uses (pos_min,pos_max)
// Handle clipping on CPU immediately (vs typically let the GPU clip the triangles that are overlapping the clipping rectangle edges)
void ImGui::RenderTextClippedEx(ImDrawList* draw_list, const ImVec2& pos_min, const ImVec2& pos_max, const char* text, const char* text_display_end, const ImVec2* text_size_if_known, const ImVec2& align, const ImRect* clip_rect)
{
    // Perform CPU side clipping for single clipped element to avoid using scissor state
    ImVec2 pos = pos_min;
    const ImVec2 text_size = text_size_if_known ? *text_size_if_known : CalcTextSize(text, text_display_end, false, 0.0f);

    const ImVec2* clip_min = clip_rect ? &clip_rect->Min : &pos_min;
    const ImVec2* clip_max = clip_rect ? &clip_rect->Max : &pos_max;
    bool need_clipping = (pos.x + text_size.x >= clip_max->x) || (pos.y + text_size.y >= clip_max->y);
    if (clip_rect) // If we had no explicit clipping rectangle then pos==clip_min
        need_clipping |= (pos.x < clip_min->x) || (pos.y < clip_min->y);

    // Align whole block. We should defer that to the better rendering function when we'll have support for individual line alignment.
    if (align.x > 0.0f) pos.x = ImMax(pos.x, pos.x + (pos_max.x - pos.x - text_size.x) * align.x);
    if (align.y > 0.0f) pos.y = ImMax(pos.y, pos.y + (pos_max.y - pos.y - text_size.y) * align.y);

    // Render
    if (need_clipping)
    {
        ImVec4 fine_clip_rect(clip_min->x, clip_min->y, clip_max->x, clip_max->y);
        draw_list->AddText(NULL, 0.0f, pos, GetColorU32(ImGuiCol_Text), text, text_display_end, 0.0f, &fine_clip_rect);
    }
    else
    {
        draw_list->AddText(NULL, 0.0f, pos, GetColorU32(ImGuiCol_Text), text, text_display_end, 0.0f, NULL);
    }
}

void ImGui::RenderTextClipped(const ImVec2& pos_min, const ImVec2& pos_max, const char* text, const char* text_end, const ImVec2* text_size_if_known, const ImVec2& align, const ImRect* clip_rect)
{
    // Hide anything after a '##' string
    const char* text_display_end = FindRenderedTextEnd(text, text_end);
    const int text_len = (int)(text_display_end - text);
    if (text_len == 0)
        return;

    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    RenderTextClippedEx(window->DrawList, pos_min, pos_max, text, text_display_end, text_size_if_known, align, clip_rect);
    if (g.LogEnabled)
        LogRenderedText(&pos_min, text, text_display_end);
}

// Render a rectangle shaped with optional rounding and borders
void ImGui::RenderFrame(ImVec2 p_min, ImVec2 p_max, ImU32 fill_col, bool border, float rounding)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    window->DrawList->AddRectFilled(p_min, p_max, fill_col, rounding);
    const float border_size = g.Style.FrameBorderSize;
    if (border && border_size > 0.0f)
    {
        window->DrawList->AddRect(p_min+ImVec2(1,1), p_max+ImVec2(1,1), GetColorU32(ImGuiCol_BorderShadow), rounding, ImDrawCornerFlags_All, border_size);
        window->DrawList->AddRect(p_min, p_max, GetColorU32(ImGuiCol_Border), rounding, ImDrawCornerFlags_All, border_size);
    }
}

void ImGui::RenderFrameBorder(ImVec2 p_min, ImVec2 p_max, float rounding)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    const float border_size = g.Style.FrameBorderSize;
    if (border_size > 0.0f)
    {
        window->DrawList->AddRect(p_min+ImVec2(1,1), p_max+ImVec2(1,1), GetColorU32(ImGuiCol_BorderShadow), rounding, ImDrawCornerFlags_All, border_size);
        window->DrawList->AddRect(p_min, p_max, GetColorU32(ImGuiCol_Border), rounding, ImDrawCornerFlags_All, border_size);
    }
}

// Render an arrow aimed to be aligned with text (p_min is a position in the same space text would be positioned). To e.g. denote expanded/collapsed state
void ImGui::RenderArrow(ImVec2 p_min, ImGuiDir dir, float scale)
{
    ImGuiContext& g = *GImGui;

    const float h = g.FontSize * 1.00f;
    float r = h * 0.40f * scale;
    ImVec2 center = p_min + ImVec2(h * 0.50f, h * 0.50f * scale);

    ImVec2 a, b, c;
    switch (dir)
    {
    case ImGuiDir_Up:
    case ImGuiDir_Down:
        if (dir == ImGuiDir_Up) r = -r;
        a = ImVec2(+0.000f,+0.750f) * r;
        b = ImVec2(-0.866f,-0.750f) * r;
        c = ImVec2(+0.866f,-0.750f) * r;
        break;
    case ImGuiDir_Left:
    case ImGuiDir_Right:
        if (dir == ImGuiDir_Left) r = -r;
        a = ImVec2(+0.750f,+0.000f) * r;
        b = ImVec2(-0.750f,+0.866f) * r;
        c = ImVec2(-0.750f,-0.866f) * r;
        break;
    case ImGuiDir_None:
    case ImGuiDir_COUNT:
        IM_ASSERT(0);
        break;
    }

    g.CurrentWindow->DrawList->AddTriangleFilled(center + a, center + b, center + c, GetColorU32(ImGuiCol_Text));
}

void ImGui::RenderBullet(ImVec2 pos)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    window->DrawList->AddCircleFilled(pos, g.FontSize*0.20f, GetColorU32(ImGuiCol_Text), 8);
}

void ImGui::RenderCheckMark(ImVec2 pos, ImU32 col, float sz)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    float thickness = ImMax(sz / 5.0f, 1.0f);
    sz -= thickness*0.5f;
    pos += ImVec2(thickness*0.25f, thickness*0.25f);

    float third = sz / 3.0f;
    float bx = pos.x + third;
    float by = pos.y + sz - third*0.5f;
    window->DrawList->PathLineTo(ImVec2(bx - third, by - third));
    window->DrawList->PathLineTo(ImVec2(bx, by));
    window->DrawList->PathLineTo(ImVec2(bx + third*2, by - third*2));
    window->DrawList->PathStroke(col, false, thickness);
}

void ImGui::RenderNavHighlight(const ImRect& bb, ImGuiID id, ImGuiNavHighlightFlags flags)
{
    ImGuiContext& g = *GImGui;
    if (id != g.NavId)
        return;
    if (g.NavDisableHighlight && !(flags & ImGuiNavHighlightFlags_AlwaysDraw))
        return;
    ImGuiWindow* window = g.CurrentWindow;
    if (window->DC.NavHideHighlightOneFrame)
        return;

    float rounding = (flags & ImGuiNavHighlightFlags_NoRounding) ? 0.0f : g.Style.FrameRounding;
    ImRect display_rect = bb;
    display_rect.ClipWith(window->ClipRect);
    if (flags & ImGuiNavHighlightFlags_TypeDefault)
    {
        const float THICKNESS = 2.0f;
        const float DISTANCE = 3.0f + THICKNESS * 0.5f;
        display_rect.Expand(ImVec2(DISTANCE,DISTANCE));
        bool fully_visible = window->ClipRect.Contains(display_rect);
        if (!fully_visible)
            window->DrawList->PushClipRect(display_rect.Min, display_rect.Max);
        window->DrawList->AddRect(display_rect.Min + ImVec2(THICKNESS*0.5f,THICKNESS*0.5f), display_rect.Max - ImVec2(THICKNESS*0.5f,THICKNESS*0.5f), GetColorU32(ImGuiCol_NavHighlight), rounding, ImDrawCornerFlags_All, THICKNESS);
        if (!fully_visible)
            window->DrawList->PopClipRect();
    }
    if (flags & ImGuiNavHighlightFlags_TypeThin)
    {
        window->DrawList->AddRect(display_rect.Min, display_rect.Max, GetColorU32(ImGuiCol_NavHighlight), rounding, ~0, 1.0f);
    }
}

//-----------------------------------------------------------------------------
// [SECTION] MAIN CODE (most of the code! lots of stuff, needs tidying up!)
//-----------------------------------------------------------------------------

// ImGuiWindow is mostly a dumb struct. It merely has a constructor and a few helper methods
ImGuiWindow::ImGuiWindow(ImGuiContext* context, const char* name)
    : DrawListInst(&context->DrawListSharedData)
{
    Name = ImStrdup(name);
    ID = ImHashStr(name, 0);
    IDStack.push_back(ID);
    Flags = ImGuiWindowFlags_None;
    Pos = ImVec2(0.0f, 0.0f);
    Size = SizeFull = ImVec2(0.0f, 0.0f);
    SizeContents = SizeContentsExplicit = ImVec2(0.0f, 0.0f);
    WindowPadding = ImVec2(0.0f, 0.0f);
    WindowRounding = 0.0f;
    WindowBorderSize = 0.0f;
    NameBufLen = (int)strlen(name) + 1;
    MoveId = GetID("#MOVE");
    ChildId = 0;
    Scroll = ImVec2(0.0f, 0.0f);
    ScrollTarget = ImVec2(FLT_MAX, FLT_MAX);
    ScrollTargetCenterRatio = ImVec2(0.5f, 0.5f);
    ScrollbarSizes = ImVec2(0.0f, 0.0f);
    ScrollbarX = ScrollbarY = false;
    Active = WasActive = false;
    WriteAccessed = false;
    Collapsed = false;
    WantCollapseToggle = false;
    SkipItems = false;
    Appearing = false;
    Hidden = false;
    HasCloseButton = false;
    ResizeBorderHeld = -1;
    BeginCount = 0;
    BeginOrderWithinParent = -1;
    BeginOrderWithinContext = -1;
    PopupId = 0;
    AutoFitFramesX = AutoFitFramesY = -1;
    AutoFitOnlyGrows = false;
    AutoFitChildAxises = 0x00;
    AutoPosLastDirection = ImGuiDir_None;
    HiddenFramesRegular = HiddenFramesForResize = 0;
    SetWindowPosAllowFlags = SetWindowSizeAllowFlags = SetWindowCollapsedAllowFlags = ImGuiCond_Always | ImGuiCond_Once | ImGuiCond_FirstUseEver | ImGuiCond_Appearing;
    SetWindowPosVal = SetWindowPosPivot = ImVec2(FLT_MAX, FLT_MAX);

    LastFrameActive = -1;
    ItemWidthDefault = 0.0f;
    FontWindowScale = 1.0f;
    SettingsIdx = -1;

    DrawList = &DrawListInst;
    DrawList->_OwnerName = Name;
    ParentWindow = NULL;
    RootWindow = NULL;
    RootWindowForTitleBarHighlight = NULL;
    RootWindowForNav = NULL;

    NavLastIds[0] = NavLastIds[1] = 0;
    NavRectRel[0] = NavRectRel[1] = ImRect();
    NavLastChildNavWindow = NULL;

    FocusIdxAllCounter = FocusIdxTabCounter = -1;
    FocusIdxAllRequestCurrent = FocusIdxTabRequestCurrent = INT_MAX;
    FocusIdxAllRequestNext = FocusIdxTabRequestNext = INT_MAX;
}

ImGuiWindow::~ImGuiWindow()
{
    IM_ASSERT(DrawList == &DrawListInst);
    IM_DELETE(Name);
    for (int i = 0; i != ColumnsStorage.Size; i++)
        ColumnsStorage[i].~ImGuiColumnsSet();
}

ImGuiID ImGuiWindow::GetID(const char* str, const char* str_end)
{
    ImGuiID seed = IDStack.back();
    ImGuiID id = ImHashStr(str, str_end ? (str_end - str) : 0, seed);
    ImGui::KeepAliveID(id);
    return id;
}

ImGuiID ImGuiWindow::GetID(const void* ptr)
{
    ImGuiID seed = IDStack.back();
    ImGuiID id = ImHashData(&ptr, sizeof(void*), seed);
    ImGui::KeepAliveID(id);
    return id;
}

ImGuiID ImGuiWindow::GetIDNoKeepAlive(const char* str, const char* str_end)
{
    ImGuiID seed = IDStack.back();
    return ImHashStr(str, str_end ? (str_end - str) : 0, seed);
}

ImGuiID ImGuiWindow::GetIDNoKeepAlive(const void* ptr)
{
    ImGuiID seed = IDStack.back();
    return ImHashData(&ptr, sizeof(void*), seed);
}

// This is only used in rare/specific situations to manufacture an ID out of nowhere.
ImGuiID ImGuiWindow::GetIDFromRectangle(const ImRect& r_abs)
{
    ImGuiID seed = IDStack.back();
    const int r_rel[4] = { (int)(r_abs.Min.x - Pos.x), (int)(r_abs.Min.y - Pos.y), (int)(r_abs.Max.x - Pos.x), (int)(r_abs.Max.y - Pos.y) };
    ImGuiID id = ImHashData(&r_rel, sizeof(r_rel), seed);
    ImGui::KeepAliveID(id);
    return id;
}

static void SetCurrentWindow(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    g.CurrentWindow = window;
    if (window)
        g.FontSize = g.DrawListSharedData.FontSize = window->CalcFontSize();
}

void ImGui::SetNavID(ImGuiID id, int nav_layer)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.NavWindow);
    IM_ASSERT(nav_layer == 0 || nav_layer == 1);
    g.NavId = id;
    g.NavWindow->NavLastIds[nav_layer] = id;
}

void ImGui::SetNavIDWithRectRel(ImGuiID id, int nav_layer, const ImRect& rect_rel)
{
    ImGuiContext& g = *GImGui;
    SetNavID(id, nav_layer);
    g.NavWindow->NavRectRel[nav_layer] = rect_rel;
    g.NavMousePosDirty = true;
    g.NavDisableHighlight = false;
    g.NavDisableMouseHover = true;
}

void ImGui::SetActiveID(ImGuiID id, ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    g.ActiveIdIsJustActivated = (g.ActiveId != id);
    if (g.ActiveIdIsJustActivated)
    {
        g.ActiveIdTimer = 0.0f;
        g.ActiveIdHasBeenPressed = false;
        g.ActiveIdHasBeenEdited = false;
        if (id != 0)
        {
            g.LastActiveId = id;
            g.LastActiveIdTimer = 0.0f;
        }
    }
    g.ActiveId = id;
    g.ActiveIdAllowNavDirFlags = 0;
    g.ActiveIdBlockNavInputFlags = 0;
    g.ActiveIdAllowOverlap = false;
    g.ActiveIdWindow = window;
    if (id)
    {
        g.ActiveIdIsAlive = id;
        g.ActiveIdSource = (g.NavActivateId == id || g.NavInputId == id || g.NavJustTabbedId == id || g.NavJustMovedToId == id) ? ImGuiInputSource_Nav : ImGuiInputSource_Mouse;
    }
}

// FIXME-NAV: The existence of SetNavID/SetNavIDWithRectRel/SetFocusID is incredibly messy and confusing and needs some explanation or refactoring.
void ImGui::SetFocusID(ImGuiID id, ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(id != 0);

    // Assume that SetFocusID() is called in the context where its NavLayer is the current layer, which is the case everywhere we call it.
    const ImGuiNavLayer nav_layer = window->DC.NavLayerCurrent;
    if (g.NavWindow != window)
        g.NavInitRequest = false;
    g.NavId = id;
    g.NavWindow = window;
    g.NavLayer = nav_layer;
    window->NavLastIds[nav_layer] = id;
    if (window->DC.LastItemId == id)
        window->NavRectRel[nav_layer] = ImRect(window->DC.LastItemRect.Min - window->Pos, window->DC.LastItemRect.Max - window->Pos);

    if (g.ActiveIdSource == ImGuiInputSource_Nav)
        g.NavDisableMouseHover = true;
    else
        g.NavDisableHighlight = true;
}

void ImGui::ClearActiveID()
{
    SetActiveID(0, NULL);
}

void ImGui::SetHoveredID(ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    g.HoveredId = id;
    g.HoveredIdAllowOverlap = false;
    if (id != 0 && g.HoveredIdPreviousFrame != id)
        g.HoveredIdTimer = g.HoveredIdNotActiveTimer = 0.0f;
}

ImGuiID ImGui::GetHoveredID()
{
    ImGuiContext& g = *GImGui;
    return g.HoveredId ? g.HoveredId : g.HoveredIdPreviousFrame;
}

void ImGui::KeepAliveID(ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    if (g.ActiveId == id)
        g.ActiveIdIsAlive = id;
    if (g.ActiveIdPreviousFrame == id)
        g.ActiveIdPreviousFrameIsAlive = true;
}

void ImGui::MarkItemEdited(ImGuiID id)
{
    // This marking is solely to be able to provide info for IsItemDeactivatedAfterEdit().
    // ActiveId might have been released by the time we call this (as in the typical press/release button behavior) but still need need to fill the data.
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.ActiveId == id || g.ActiveId == 0 || g.DragDropActive);
    IM_UNUSED(id); // Avoid unused variable warnings when asserts are compiled out.
    //IM_ASSERT(g.CurrentWindow->DC.LastItemId == id);
    g.ActiveIdHasBeenEdited = true;
    g.CurrentWindow->DC.LastItemStatusFlags |= ImGuiItemStatusFlags_Edited;
}

static inline bool IsWindowContentHoverable(ImGuiWindow* window, ImGuiHoveredFlags flags)
{
    // An active popup disable hovering on other windows (apart from its own children)
    // FIXME-OPT: This could be cached/stored within the window.
    ImGuiContext& g = *GImGui;
    if (g.NavWindow)
        if (ImGuiWindow* focused_root_window = g.NavWindow->RootWindow)
            if (focused_root_window->WasActive && focused_root_window != window->RootWindow)
            {
                // For the purpose of those flags we differentiate "standard popup" from "modal popup"
                // NB: The order of those two tests is important because Modal windows are also Popups.
                if (focused_root_window->Flags & ImGuiWindowFlags_Modal)
                    return false;
                if ((focused_root_window->Flags & ImGuiWindowFlags_Popup) && !(flags & ImGuiHoveredFlags_AllowWhenBlockedByPopup))
                    return false;
            }

    return true;
}

// Advance cursor given item size for layout.
void ImGui::ItemSize(const ImVec2& size, float text_offset_y)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (window->SkipItems)
        return;

    // Always align ourselves on pixel boundaries
    const float line_height = ImMax(window->DC.CurrentLineSize.y, size.y);
    const float text_base_offset = ImMax(window->DC.CurrentLineTextBaseOffset, text_offset_y);
    //if (g.IO.KeyAlt) window->DrawList->AddRect(window->DC.CursorPos, window->DC.CursorPos + ImVec2(size.x, line_height), IM_COL32(255,0,0,200)); // [DEBUG]
    window->DC.CursorPosPrevLine = ImVec2(window->DC.CursorPos.x + size.x, window->DC.CursorPos.y);
    window->DC.CursorPos.x = (float)(int)(window->Pos.x + window->DC.Indent.x + window->DC.ColumnsOffset.x);
    window->DC.CursorPos.y = (float)(int)(window->DC.CursorPos.y + line_height + g.Style.ItemSpacing.y);
    window->DC.CursorMaxPos.x = ImMax(window->DC.CursorMaxPos.x, window->DC.CursorPosPrevLine.x);
    window->DC.CursorMaxPos.y = ImMax(window->DC.CursorMaxPos.y, window->DC.CursorPos.y - g.Style.ItemSpacing.y);
    //if (g.IO.KeyAlt) window->DrawList->AddCircle(window->DC.CursorMaxPos, 3.0f, IM_COL32(255,0,0,255), 4); // [DEBUG]

    window->DC.PrevLineSize.y = line_height;
    window->DC.PrevLineTextBaseOffset = text_base_offset;
    window->DC.CurrentLineSize.y = window->DC.CurrentLineTextBaseOffset = 0.0f;

    // Horizontal layout mode
    if (window->DC.LayoutType == ImGuiLayoutType_Horizontal)
        SameLine();
}

void ImGui::ItemSize(const ImRect& bb, float text_offset_y)
{
    ItemSize(bb.GetSize(), text_offset_y);
}

// Declare item bounding box for clipping and interaction.
// Note that the size can be different than the one provided to ItemSize(). Typically, widgets that spread over available surface
// declare their minimum size requirement to ItemSize() and then use a larger region for drawing/interaction, which is passed to ItemAdd().
bool ImGui::ItemAdd(const ImRect& bb, ImGuiID id, const ImRect* nav_bb_arg)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    if (id != 0)
    {
        // Navigation processing runs prior to clipping early-out
        //  (a) So that NavInitRequest can be honored, for newly opened windows to select a default widget
        //  (b) So that we can scroll up/down past clipped items. This adds a small O(N) cost to regular navigation requests unfortunately, but it is still limited to one window.
        //      it may not scale very well for windows with ten of thousands of item, but at least NavMoveRequest is only set on user interaction, aka maximum once a frame.
        //      We could early out with "if (is_clipped && !g.NavInitRequest) return false;" but when we wouldn't be able to reach unclipped widgets. This would work if user had explicit scrolling control (e.g. mapped on a stick)
        window->DC.NavLayerActiveMaskNext |= window->DC.NavLayerCurrentMask;
        if (g.NavId == id || g.NavAnyRequest)
            if (g.NavWindow->RootWindowForNav == window->RootWindowForNav)
                if (window == g.NavWindow || ((window->Flags | g.NavWindow->Flags) & ImGuiWindowFlags_NavFlattened))
                    NavProcessItem(window, nav_bb_arg ? *nav_bb_arg : bb, id);
    }

    window->DC.LastItemId = id;
    window->DC.LastItemRect = bb;
    window->DC.LastItemStatusFlags = ImGuiItemStatusFlags_None;

#ifdef IMGUI_ENABLE_TEST_ENGINE
    if (id != 0)
        ImGuiTestEngineHook_ItemAdd(&g, nav_bb_arg ? *nav_bb_arg : bb, id);
#endif

    // Clipping test
    const bool is_clipped = IsClippedEx(bb, id, false);
    if (is_clipped)
        return false;
    //if (g.IO.KeyAlt) window->DrawList->AddRect(bb.Min, bb.Max, IM_COL32(255,255,0,120)); // [DEBUG]

    // We need to calculate this now to take account of the current clipping rectangle (as items like Selectable may change them)
    if (IsMouseHoveringRect(bb.Min, bb.Max))
        window->DC.LastItemStatusFlags |= ImGuiItemStatusFlags_HoveredRect;
    return true;
}

// This is roughly matching the behavior of internal-facing ItemHoverable()
// - we allow hovering to be true when ActiveId==window->MoveID, so that clicking on non-interactive items such as a Text() item still returns true with IsItemHovered()
// - this should work even for non-interactive items that have no ID, so we cannot use LastItemId
bool ImGui::IsItemHovered(ImGuiHoveredFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (g.NavDisableMouseHover && !g.NavDisableHighlight)
        return IsItemFocused();

    // Test for bounding box overlap, as updated as ItemAdd()
    if (!(window->DC.LastItemStatusFlags & ImGuiItemStatusFlags_HoveredRect))
        return false;
    IM_ASSERT((flags & (ImGuiHoveredFlags_RootWindow | ImGuiHoveredFlags_ChildWindows)) == 0);   // Flags not supported by this function

    // Test if we are hovering the right window (our window could be behind another window)
    // [2017/10/16] Reverted commit 344d48be3 and testing RootWindow instead. I believe it is correct to NOT test for RootWindow but this leaves us unable to use IsItemHovered() after EndChild() itself.
    // Until a solution is found I believe reverting to the test from 2017/09/27 is safe since this was the test that has been running for a long while.
    //if (g.HoveredWindow != window)
    //    return false;
    if (g.HoveredRootWindow != window->RootWindow && !(flags & ImGuiHoveredFlags_AllowWhenOverlapped))
        return false;

    // Test if another item is active (e.g. being dragged)
    if (!(flags & ImGuiHoveredFlags_AllowWhenBlockedByActiveItem))
        if (g.ActiveId != 0 && g.ActiveId != window->DC.LastItemId && !g.ActiveIdAllowOverlap && g.ActiveId != window->MoveId)
            return false;

    // Test if interactions on this window are blocked by an active popup or modal
    if (!IsWindowContentHoverable(window, flags))
        return false;

    // Test if the item is disabled
    if ((window->DC.ItemFlags & ImGuiItemFlags_Disabled) && !(flags & ImGuiHoveredFlags_AllowWhenDisabled))
        return false;

    // Special handling for the dummy item after Begin() which represent the title bar or tab. 
    // When the window is collapsed (SkipItems==true) that last item will never be overwritten so we need to detect the case.
    if (window->DC.LastItemId == window->MoveId && window->WriteAccessed)
        return false;
    return true;
}

// Internal facing ItemHoverable() used when submitting widgets. Differs slightly from IsItemHovered().
bool ImGui::ItemHoverable(const ImRect& bb, ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    if (g.HoveredId != 0 && g.HoveredId != id && !g.HoveredIdAllowOverlap)
        return false;

    ImGuiWindow* window = g.CurrentWindow;
    if (g.HoveredWindow != window)
        return false;
    if (g.ActiveId != 0 && g.ActiveId != id && !g.ActiveIdAllowOverlap)
        return false;
    if (!IsMouseHoveringRect(bb.Min, bb.Max))
        return false;
    if (g.NavDisableMouseHover || !IsWindowContentHoverable(window, ImGuiHoveredFlags_None))
        return false;
    if (window->DC.ItemFlags & ImGuiItemFlags_Disabled)
        return false;

    SetHoveredID(id);
    return true;
}

bool ImGui::IsClippedEx(const ImRect& bb, ImGuiID id, bool clip_even_when_logged)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (!bb.Overlaps(window->ClipRect))
        if (id == 0 || id != g.ActiveId)
            if (clip_even_when_logged || !g.LogEnabled)
                return true;
    return false;
}

bool ImGui::FocusableItemRegister(ImGuiWindow* window, ImGuiID id, bool tab_stop)
{
    ImGuiContext& g = *GImGui;

    const bool is_tab_stop = (window->DC.ItemFlags & (ImGuiItemFlags_NoTabStop | ImGuiItemFlags_Disabled)) == 0;
    window->FocusIdxAllCounter++;
    if (is_tab_stop)
        window->FocusIdxTabCounter++;

    // Process keyboard input at this point: TAB/Shift-TAB to tab out of the currently focused item.
    // Note that we can always TAB out of a widget that doesn't allow tabbing in.
    if (tab_stop && (g.ActiveId == id) && window->FocusIdxAllRequestNext == INT_MAX && window->FocusIdxTabRequestNext == INT_MAX && !g.IO.KeyCtrl && IsKeyPressedMap(ImGuiKey_Tab))
        window->FocusIdxTabRequestNext = window->FocusIdxTabCounter + (g.IO.KeyShift ? (is_tab_stop ? -1 : 0) : +1); // Modulo on index will be applied at the end of frame once we've got the total counter of items.

    if (window->FocusIdxAllCounter == window->FocusIdxAllRequestCurrent)
        return true;
    if (is_tab_stop && window->FocusIdxTabCounter == window->FocusIdxTabRequestCurrent)
    {
        g.NavJustTabbedId = id;
        return true;
    }

    return false;
}

void ImGui::FocusableItemUnregister(ImGuiWindow* window)
{
    window->FocusIdxAllCounter--;
    window->FocusIdxTabCounter--;
}

ImVec2 ImGui::CalcItemSize(ImVec2 size, float default_x, float default_y)
{
    ImGuiContext& g = *GImGui;
    ImVec2 content_max;
    if (size.x < 0.0f || size.y < 0.0f)
        content_max = g.CurrentWindow->Pos + GetContentRegionMax();
    if (size.x <= 0.0f)
        size.x = (size.x == 0.0f) ? default_x : ImMax(content_max.x - g.CurrentWindow->DC.CursorPos.x, 4.0f) + size.x;
    if (size.y <= 0.0f)
        size.y = (size.y == 0.0f) ? default_y : ImMax(content_max.y - g.CurrentWindow->DC.CursorPos.y, 4.0f) + size.y;
    return size;
}

float ImGui::CalcWrapWidthForPos(const ImVec2& pos, float wrap_pos_x)
{
    if (wrap_pos_x < 0.0f)
        return 0.0f;

    ImGuiWindow* window = GetCurrentWindowRead();
    if (wrap_pos_x == 0.0f)
        wrap_pos_x = GetContentRegionMax().x + window->Pos.x;
    else if (wrap_pos_x > 0.0f)
        wrap_pos_x += window->Pos.x - window->Scroll.x; // wrap_pos_x is provided is window local space

    return ImMax(wrap_pos_x - pos.x, 1.0f);
}

void* ImGui::MemAlloc(size_t size)
{
    if (ImGuiContext* ctx = GImGui)
        ctx->IO.MetricsActiveAllocations++;
    return GImAllocatorAllocFunc(size, GImAllocatorUserData);
}

void ImGui::MemFree(void* ptr)
{
    if (ptr)
        if (ImGuiContext* ctx = GImGui)
            ctx->IO.MetricsActiveAllocations--;
    return GImAllocatorFreeFunc(ptr, GImAllocatorUserData);
}

const char* ImGui::GetClipboardText()
{
    return GImGui->IO.GetClipboardTextFn ? GImGui->IO.GetClipboardTextFn(GImGui->IO.ClipboardUserData) : "";
}
void ImGui::ShowFontSelector(const char* label)
{
	ImGuiIO& io = ImGui::GetIO();
	ImFont* font_current = ImGui::GetFont();
	if (ImGui::BeginCombo(label, font_current->GetDebugName()))
	{
		for (int n = 0; n < io.Fonts->Fonts.Size; n++)
		{
			ImFont* font = io.Fonts->Fonts[n];
			ImGui::PushID((void*)font);
			if (ImGui::Selectable(font->GetDebugName(), font == font_current))
				io.FontDefault = font;
			ImGui::PopID();
		}
		ImGui::EndCombo();
	}
	/*ImGui::SameLine();
	HelpMarker(
		"- Load additional fonts with io.Fonts->AddFontFromFileTTF().\n"
		"- The font atlas is built when calling io.Fonts->GetTexDataAsXXXX() or io.Fonts->Build().\n"
		"- Read FAQ and documentation in misc/fonts/ for more details.\n"
		"- If you need to add/remove fonts at runtime (e.g. for DPI change), do it before calling NewFrame().");*/
}

void ImGui::SetClipboardText(const char* text)
{
    if (GImGui->IO.SetClipboardTextFn)
        GImGui->IO.SetClipboardTextFn(GImGui->IO.ClipboardUserData, text);
}

const char* ImGui::GetVersion()
{
    return IMGUI_VERSION;
}

// Internal state access - if you want to share ImGui state between modules (e.g. DLL) or allocate it yourself
// Note that we still point to some static data and members (such as GFontAtlas), so the state instance you end up using will point to the static data within its module
ImGuiContext* ImGui::GetCurrentContext()
{
    return GImGui;
}

void ImGui::SetCurrentContext(ImGuiContext* ctx)
{
#ifdef IMGUI_SET_CURRENT_CONTEXT_FUNC
    IMGUI_SET_CURRENT_CONTEXT_FUNC(ctx); // For custom thread-based hackery you may want to have control over this.
#else
    GImGui = ctx;
#endif
}

// Helper function to verify that the type sizes are matching between the calling file's compilation unit and imgui.cpp's compilation unit
// If the user has inconsistent compilation settings, imgui configuration #define, packing pragma, etc. you may see different structures from what imgui.cpp sees which is highly problematic.
bool ImGui::DebugCheckVersionAndDataLayout(const char* version, size_t sz_io, size_t sz_style, size_t sz_vec2, size_t sz_vec4, size_t sz_vert)
{
    bool error = false;
    if (strcmp(version, IMGUI_VERSION)!=0) { error = true; IM_ASSERT(strcmp(version,IMGUI_VERSION)==0 && "Mismatched version string!");  }
    if (sz_io    != sizeof(ImGuiIO))       { error = true; IM_ASSERT(sz_io    == sizeof(ImGuiIO)      && "Mismatched struct layout!"); }
    if (sz_style != sizeof(ImGuiStyle))    { error = true; IM_ASSERT(sz_style == sizeof(ImGuiStyle)   && "Mismatched struct layout!"); }
    if (sz_vec2  != sizeof(ImVec2))        { error = true; IM_ASSERT(sz_vec2  == sizeof(ImVec2)       && "Mismatched struct layout!"); }
    if (sz_vec4  != sizeof(ImVec4))        { error = true; IM_ASSERT(sz_vec4  == sizeof(ImVec4)       && "Mismatched struct layout!"); }
    if (sz_vert  != sizeof(ImDrawVert))    { error = true; IM_ASSERT(sz_vert  == sizeof(ImDrawVert)   && "Mismatched struct layout!"); }
    return !error;
}

void ImGui::SetAllocatorFunctions(void* (*alloc_func)(size_t sz, void* user_data), void (*free_func)(void* ptr, void* user_data), void* user_data)
{
    GImAllocatorAllocFunc = alloc_func;
    GImAllocatorFreeFunc = free_func;
    GImAllocatorUserData = user_data;
}

ImGuiContext* ImGui::CreateContext(ImFontAtlas* shared_font_atlas)
{
    ImGuiContext* ctx = IM_NEW(ImGuiContext)(shared_font_atlas);
    if (GImGui == NULL)
        SetCurrentContext(ctx);
    Initialize(ctx);
    return ctx;
}

void ImGui::DestroyContext(ImGuiContext* ctx)
{
    if (ctx == NULL)
        ctx = GImGui;
    Shutdown(ctx);
    if (GImGui == ctx)
        SetCurrentContext(NULL);
    IM_DELETE(ctx);
}

ImGuiIO& ImGui::GetIO()
{
    IM_ASSERT(GImGui != NULL && "No current context. Did you call ImGui::CreateContext() or ImGui::SetCurrentContext()?");
    return GImGui->IO;
}

ImGuiStyle& ImGui::GetStyle()
{
    IM_ASSERT(GImGui != NULL && "No current context. Did you call ImGui::CreateContext() or ImGui::SetCurrentContext()?");
    return GImGui->Style;
}

// Same value as passed to the old io.RenderDrawListsFn function. Valid after Render() and until the next call to NewFrame()
ImDrawData* ImGui::GetDrawData()
{
    ImGuiContext& g = *GImGui;
    return g.DrawData.Valid ? &g.DrawData : NULL;
}

double ImGui::GetTime()
{
    return GImGui->Time;
}

int ImGui::GetFrameCount()
{
    return GImGui->FrameCount;
}

static ImDrawList* GetOverlayDrawList(ImGuiWindow*)
{
    // This seemingly unnecessary wrapper simplifies compatibility between the 'master' and 'viewport' branches.
    return &GImGui->OverlayDrawList;
}

ImDrawList* ImGui::GetOverlayDrawList()
{
    return &GImGui->OverlayDrawList;
}

ImDrawListSharedData* ImGui::GetDrawListSharedData()
{
    return &GImGui->DrawListSharedData;
}

void ImGui::StartMouseMovingWindow(ImGuiWindow* window)
{
    // Set ActiveId even if the _NoMove flag is set. Without it, dragging away from a window with _NoMove would activate hover on other windows.
    // We _also_ call this when clicking in a window empty space when io.ConfigWindowsMoveFromTitleBarOnly is set, but clear g.MovingWindow afterward.
    // This is because we want ActiveId to be set even when the window is not permitted to move.
    ImGuiContext& g = *GImGui;
    FocusWindow(window);
    SetActiveID(window->MoveId, window);
    g.NavDisableHighlight = true;
    g.ActiveIdClickOffset = g.IO.MousePos - window->RootWindow->Pos;

    bool can_move_window = true;
    if ((window->Flags & ImGuiWindowFlags_NoMove) || (window->RootWindow->Flags & ImGuiWindowFlags_NoMove))
        can_move_window = false;
    if (can_move_window)
        g.MovingWindow = window;
}

// Handle mouse moving window
// Note: moving window with the navigation keys (Square + d-pad / CTRL+TAB + Arrows) are processed in NavUpdateWindowing()
void ImGui::UpdateMouseMovingWindowNewFrame()
{
    ImGuiContext& g = *GImGui;
    if (g.MovingWindow != NULL)
    {
        // We actually want to move the root window. g.MovingWindow == window we clicked on (could be a child window).
        // We track it to preserve Focus and so that generally ActiveIdWindow == MovingWindow and ActiveId == MovingWindow->MoveId for consistency.
        KeepAliveID(g.ActiveId);
        IM_ASSERT(g.MovingWindow && g.MovingWindow->RootWindow);
        ImGuiWindow* moving_window = g.MovingWindow->RootWindow;
        if (g.IO.MouseDown[0] && IsMousePosValid(&g.IO.MousePos))
        {
            ImVec2 pos = g.IO.MousePos - g.ActiveIdClickOffset;
            if (moving_window->Pos.x != pos.x || moving_window->Pos.y != pos.y)
            {
                MarkIniSettingsDirty(moving_window);
                SetWindowPos(moving_window, pos, ImGuiCond_Always);
            }
            FocusWindow(g.MovingWindow);
        }
        else
        {
            ClearActiveID();
            g.MovingWindow = NULL;
        }
    }
    else
    {
        // When clicking/dragging from a window that has the _NoMove flag, we still set the ActiveId in order to prevent hovering others.
        if (g.ActiveIdWindow && g.ActiveIdWindow->MoveId == g.ActiveId)
        {
            KeepAliveID(g.ActiveId);
            if (!g.IO.MouseDown[0])
                ClearActiveID();
        }
    }
}

// Initiate moving window, handle left-click and right-click focus
void ImGui::UpdateMouseMovingWindowEndFrame()
{
    // Initiate moving window
    ImGuiContext& g = *GImGui;
    if (g.ActiveId != 0 || g.HoveredId != 0)
        return;

    // Unless we just made a window/popup appear
    if (g.NavWindow && g.NavWindow->Appearing)
        return;

    // Click to focus window and start moving (after we're done with all our widgets)
    if (g.IO.MouseClicked[0])
    {
        if (g.HoveredRootWindow != NULL)
        {
            StartMouseMovingWindow(g.HoveredWindow);
            if (g.IO.ConfigWindowsMoveFromTitleBarOnly && !(g.HoveredRootWindow->Flags & ImGuiWindowFlags_NoTitleBar))
                if (!g.HoveredRootWindow->TitleBarRect().Contains(g.IO.MouseClickedPos[0]))
                    g.MovingWindow = NULL;
        }
        else if (g.NavWindow != NULL && GetFrontMostPopupModal() == NULL)
        {
            // Clicking on void disable focus
            FocusWindow(NULL);
        }
    }

    // With right mouse button we close popups without changing focus
    // (The left mouse button path calls FocusWindow which will lead NewFrame->ClosePopupsOverWindow to trigger)
    if (g.IO.MouseClicked[1])
    {
        // Find the top-most window between HoveredWindow and the front most Modal Window.
        // This is where we can trim the popup stack.
        ImGuiWindow* modal = GetFrontMostPopupModal();
        bool hovered_window_above_modal = false;
        if (modal == NULL)
            hovered_window_above_modal = true;
        for (int i = g.Windows.Size - 1; i >= 0 && hovered_window_above_modal == false; i--)
        {
            ImGuiWindow* window = g.Windows[i];
            if (window == modal)
                break;
            if (window == g.HoveredWindow)
                hovered_window_above_modal = true;
        }
        ClosePopupsOverWindow(hovered_window_above_modal ? g.HoveredWindow : modal);
    }
}

static bool IsWindowActiveAndVisible(ImGuiWindow* window)
{
    return (window->Active) && (!window->Hidden);
}

static void ImGui::UpdateMouseInputs()
{
    ImGuiContext& g = *GImGui;

    // Round mouse position to avoid spreading non-rounded position (e.g. UpdateManualResize doesn't support them well)
    if (IsMousePosValid(&g.IO.MousePos))
        g.IO.MousePos = g.LastValidMousePos = ImFloor(g.IO.MousePos);

    // If mouse just appeared or disappeared (usually denoted by -FLT_MAX components) we cancel out movement in MouseDelta
    if (IsMousePosValid(&g.IO.MousePos) && IsMousePosValid(&g.IO.MousePosPrev))
        g.IO.MouseDelta = g.IO.MousePos - g.IO.MousePosPrev;
    else
        g.IO.MouseDelta = ImVec2(0.0f, 0.0f);
    if (g.IO.MouseDelta.x != 0.0f || g.IO.MouseDelta.y != 0.0f)
        g.NavDisableMouseHover = false;

    g.IO.MousePosPrev = g.IO.MousePos;
    for (int i = 0; i < IM_ARRAYSIZE(g.IO.MouseDown); i++)
    {
        g.IO.MouseClicked[i] = g.IO.MouseDown[i] && g.IO.MouseDownDuration[i] < 0.0f;
        g.IO.MouseReleased[i] = !g.IO.MouseDown[i] && g.IO.MouseDownDuration[i] >= 0.0f;
        g.IO.MouseDownDurationPrev[i] = g.IO.MouseDownDuration[i];
        g.IO.MouseDownDuration[i] = g.IO.MouseDown[i] ? (g.IO.MouseDownDuration[i] < 0.0f ? 0.0f : g.IO.MouseDownDuration[i] + g.IO.DeltaTime) : -1.0f;
        g.IO.MouseDoubleClicked[i] = false;
        if (g.IO.MouseClicked[i])
        {
            if ((float)(g.Time - g.IO.MouseClickedTime[i]) < g.IO.MouseDoubleClickTime)
            {
                ImVec2 delta_from_click_pos = IsMousePosValid(&g.IO.MousePos) ? (g.IO.MousePos - g.IO.MouseClickedPos[i]) : ImVec2(0.0f, 0.0f);
                if (ImLengthSqr(delta_from_click_pos) < g.IO.MouseDoubleClickMaxDist * g.IO.MouseDoubleClickMaxDist)
                    g.IO.MouseDoubleClicked[i] = true;
                g.IO.MouseClickedTime[i] = -FLT_MAX;    // so the third click isn't turned into a double-click
            }
            else
            {
                g.IO.MouseClickedTime[i] = g.Time;
            }
            g.IO.MouseClickedPos[i] = g.IO.MousePos;
            g.IO.MouseDragMaxDistanceAbs[i] = ImVec2(0.0f, 0.0f);
            g.IO.MouseDragMaxDistanceSqr[i] = 0.0f;
        }
        else if (g.IO.MouseDown[i])
        {
            // Maintain the maximum distance we reaching from the initial click position, which is used with dragging threshold
            ImVec2 delta_from_click_pos = IsMousePosValid(&g.IO.MousePos) ? (g.IO.MousePos - g.IO.MouseClickedPos[i]) : ImVec2(0.0f, 0.0f);
            g.IO.MouseDragMaxDistanceSqr[i] = ImMax(g.IO.MouseDragMaxDistanceSqr[i], ImLengthSqr(delta_from_click_pos));
            g.IO.MouseDragMaxDistanceAbs[i].x = ImMax(g.IO.MouseDragMaxDistanceAbs[i].x, delta_from_click_pos.x < 0.0f ? -delta_from_click_pos.x : delta_from_click_pos.x);
            g.IO.MouseDragMaxDistanceAbs[i].y = ImMax(g.IO.MouseDragMaxDistanceAbs[i].y, delta_from_click_pos.y < 0.0f ? -delta_from_click_pos.y : delta_from_click_pos.y);
        }
        if (g.IO.MouseClicked[i]) // Clicking any mouse button reactivate mouse hovering which may have been deactivated by gamepad/keyboard navigation
            g.NavDisableMouseHover = false;
    }
}

void ImGui::UpdateMouseWheel()
{
    ImGuiContext& g = *GImGui;
    if (!g.HoveredWindow || g.HoveredWindow->Collapsed)
        return;
    if (g.IO.MouseWheel == 0.0f && g.IO.MouseWheelH == 0.0f)
        return;

    // If a child window has the ImGuiWindowFlags_NoScrollWithMouse flag, we give a chance to scroll its parent (unless either ImGuiWindowFlags_NoInputs or ImGuiWindowFlags_NoScrollbar are also set).
    ImGuiWindow* window = g.HoveredWindow;
    ImGuiWindow* scroll_window = window;
    while ((scroll_window->Flags & ImGuiWindowFlags_ChildWindow) && (scroll_window->Flags & ImGuiWindowFlags_NoScrollWithMouse) && !(scroll_window->Flags & ImGuiWindowFlags_NoScrollbar) && !(scroll_window->Flags & ImGuiWindowFlags_NoMouseInputs) && scroll_window->ParentWindow)
        scroll_window = scroll_window->ParentWindow;
    const bool scroll_allowed = !(scroll_window->Flags & ImGuiWindowFlags_NoScrollWithMouse) && !(scroll_window->Flags & ImGuiWindowFlags_NoMouseInputs);

    if (g.IO.MouseWheel != 0.0f)
    {
        if (g.IO.KeyCtrl && g.IO.FontAllowUserScaling)
        {
            // Zoom / Scale window
            const float new_font_scale = ImClamp(window->FontWindowScale + g.IO.MouseWheel * 0.10f, 0.50f, 2.50f);
            const float scale = new_font_scale / window->FontWindowScale;
            window->FontWindowScale = new_font_scale;

            const ImVec2 offset = window->Size * (1.0f - scale) * (g.IO.MousePos - window->Pos) / window->Size;
            window->Pos += offset;
            window->Size *= scale;
            window->SizeFull *= scale;
        }
        else if (!g.IO.KeyCtrl && scroll_allowed)
        {
            // Mouse wheel vertical scrolling
            float scroll_amount = 5 * scroll_window->CalcFontSize();
            scroll_amount = (float)(int)ImMin(scroll_amount, (scroll_window->ContentsRegionRect.GetHeight() + scroll_window->WindowPadding.y * 2.0f) * 0.67f);
            SetWindowScrollY(scroll_window, scroll_window->Scroll.y - g.IO.MouseWheel * scroll_amount);
        }
    }
    if (g.IO.MouseWheelH != 0.0f && scroll_allowed && !g.IO.KeyCtrl)
    {
        // Mouse wheel horizontal scrolling (for hardware that supports it)
        float scroll_amount = scroll_window->CalcFontSize();
        SetWindowScrollX(scroll_window, scroll_window->Scroll.x - g.IO.MouseWheelH * scroll_amount);
    }
}

// The reason this is exposed in imgui_internal.h is: on touch-based system that don't have hovering, we want to dispatch inputs to the right target (imgui vs imgui+app)
void ImGui::UpdateHoveredWindowAndCaptureFlags()
{
    ImGuiContext& g = *GImGui;

    // Find the window hovered by mouse:
    // - Child windows can extend beyond the limit of their parent so we need to derive HoveredRootWindow from HoveredWindow.
    // - When moving a window we can skip the search, which also conveniently bypasses the fact that window->WindowRectClipped is lagging as this point of the frame.
    // - We also support the moved window toggling the NoInputs flag after moving has started in order to be able to detect windows below it, which is useful for e.g. docking mechanisms.
    FindHoveredWindow();

    // Modal windows prevents cursor from hovering behind them.
    ImGuiWindow* modal_window = GetFrontMostPopupModal();
    if (modal_window)
        if (g.HoveredRootWindow && !IsWindowChildOf(g.HoveredRootWindow, modal_window))
            g.HoveredRootWindow = g.HoveredWindow = NULL;

    // Disabled mouse?
    if (g.IO.ConfigFlags & ImGuiConfigFlags_NoMouse)
        g.HoveredWindow = g.HoveredRootWindow = NULL;

    // We track click ownership. When clicked outside of a window the click is owned by the application and won't report hovering nor request capture even while dragging over our windows afterward.
    int mouse_earliest_button_down = -1;
    bool mouse_any_down = false;
    for (int i = 0; i < IM_ARRAYSIZE(g.IO.MouseDown); i++)
    {
        if (g.IO.MouseClicked[i])
            g.IO.MouseDownOwned[i] = (g.HoveredWindow != NULL) || (!g.OpenPopupStack.empty());
        mouse_any_down |= g.IO.MouseDown[i];
        if (g.IO.MouseDown[i])
            if (mouse_earliest_button_down == -1 || g.IO.MouseClickedTime[i] < g.IO.MouseClickedTime[mouse_earliest_button_down])
                mouse_earliest_button_down = i;
    }
    const bool mouse_avail_to_imgui = (mouse_earliest_button_down == -1) || g.IO.MouseDownOwned[mouse_earliest_button_down];

    // If mouse was first clicked outside of ImGui bounds we also cancel out hovering.
    // FIXME: For patterns of drag and drop across OS windows, we may need to rework/remove this test (first committed 311c0ca9 on 2015/02)
    const bool mouse_dragging_extern_payload = g.DragDropActive && (g.DragDropSourceFlags & ImGuiDragDropFlags_SourceExtern) != 0;
    if (!mouse_avail_to_imgui && !mouse_dragging_extern_payload)
        g.HoveredWindow = g.HoveredRootWindow = NULL;

    // Update io.WantCaptureMouse for the user application (true = dispatch mouse info to imgui, false = dispatch mouse info to imgui + app)
    if (g.WantCaptureMouseNextFrame != -1)
        g.IO.WantCaptureMouse = (g.WantCaptureMouseNextFrame != 0);
    else
        g.IO.WantCaptureMouse = (mouse_avail_to_imgui && (g.HoveredWindow != NULL || mouse_any_down)) || (!g.OpenPopupStack.empty());

    // Update io.WantCaptureKeyboard for the user application (true = dispatch keyboard info to imgui, false = dispatch keyboard info to imgui + app)
    if (g.WantCaptureKeyboardNextFrame != -1)
        g.IO.WantCaptureKeyboard = (g.WantCaptureKeyboardNextFrame != 0);
    else
        g.IO.WantCaptureKeyboard = (g.ActiveId != 0) || (modal_window != NULL);
    if (g.IO.NavActive && (g.IO.ConfigFlags & ImGuiConfigFlags_NavEnableKeyboard) && !(g.IO.ConfigFlags & ImGuiConfigFlags_NavNoCaptureKeyboard))
        g.IO.WantCaptureKeyboard = true;

    // Update io.WantTextInput flag, this is to allow systems without a keyboard (e.g. mobile, hand-held) to show a software keyboard if possible
    g.IO.WantTextInput = (g.WantTextInputNextFrame != -1) ? (g.WantTextInputNextFrame != 0) : false;
}

void ImGui::NewFrame()
{
    IM_ASSERT(GImGui != NULL && "No current context. Did you call ImGui::CreateContext() or ImGui::SetCurrentContext()?");
    ImGuiContext& g = *GImGui;

#ifdef IMGUI_ENABLE_TEST_ENGINE
    ImGuiTestEngineHook_PreNewFrame(&g);
#endif

    // Check user data
    // (We pass an error message in the assert expression to make it visible to programmers who are not using a debugger, as most assert handlers display their argument)
    IM_ASSERT(g.Initialized);
    IM_ASSERT((g.IO.DeltaTime > 0.0f || g.FrameCount == 0)              && "Need a positive DeltaTime!");
    IM_ASSERT(g.IO.DisplaySize.x >= 0.0f && g.IO.DisplaySize.y >= 0.0f  && "Invalid DisplaySize value!");
    IM_ASSERT(g.IO.Fonts->Fonts.Size > 0                                && "Font Atlas not built. Did you call io.Fonts->GetTexDataAsRGBA32() / GetTexDataAsAlpha8() ?");
    IM_ASSERT(g.IO.Fonts->Fonts[0]->IsLoaded()                          && "Font Atlas not built. Did you call io.Fonts->GetTexDataAsRGBA32() / GetTexDataAsAlpha8() ?");
    IM_ASSERT(g.Style.CurveTessellationTol > 0.0f                       && "Invalid style setting!");
    IM_ASSERT(g.Style.Alpha >= 0.0f && g.Style.Alpha <= 1.0f            && "Invalid style setting. Alpha cannot be negative (allows us to avoid a few clamps in color computations)!");
    IM_ASSERT((g.FrameCount == 0 || g.FrameCountEnded == g.FrameCount)  && "Forgot to call Render() or EndFrame() at the end of the previous frame?");
    for (int n = 0; n < ImGuiKey_COUNT; n++)
        IM_ASSERT(g.IO.KeyMap[n] >= -1 && g.IO.KeyMap[n] < IM_ARRAYSIZE(g.IO.KeysDown) && "io.KeyMap[] contains an out of bound value (need to be 0..512, or -1 for unmapped key)");

    // Perform simple check: required key mapping (we intentionally do NOT check all keys to not pressure user into setting up everything, but Space is required and was only recently added in 1.60 WIP)
    if (g.IO.ConfigFlags & ImGuiConfigFlags_NavEnableKeyboard)
        IM_ASSERT(g.IO.KeyMap[ImGuiKey_Space] != -1 && "ImGuiKey_Space is not mapped, required for keyboard navigation.");

    // Perform simple check: the beta io.ConfigWindowsResizeFromEdges option requires back-end to honor mouse cursor changes and set the ImGuiBackendFlags_HasMouseCursors flag accordingly.
    if (g.IO.ConfigWindowsResizeFromEdges && !(g.IO.BackendFlags & ImGuiBackendFlags_HasMouseCursors))
        g.IO.ConfigWindowsResizeFromEdges = false;

    // Load settings on first frame (if not explicitly loaded manually before)
    if (!g.SettingsLoaded)
    {
        IM_ASSERT(g.SettingsWindows.empty());
        if (g.IO.IniFilename)
            LoadIniSettingsFromDisk(g.IO.IniFilename);
        g.SettingsLoaded = true;
    }

    // Save settings (with a delay after the last modification, so we don't spam disk too much)
    if (g.SettingsDirtyTimer > 0.0f)
    {
        g.SettingsDirtyTimer -= g.IO.DeltaTime;
        if (g.SettingsDirtyTimer <= 0.0f)
        {
            if (g.IO.IniFilename != NULL)
                SaveIniSettingsToDisk(g.IO.IniFilename);
            else
                g.IO.WantSaveIniSettings = true;  // Let user know they can call SaveIniSettingsToMemory(). user will need to clear io.WantSaveIniSettings themselves.
            g.SettingsDirtyTimer = 0.0f;
        }
    }

    g.Time += g.IO.DeltaTime;
    g.FrameScopeActive = true;
    g.FrameCount += 1;
    g.TooltipOverrideCount = 0;
    g.WindowsActiveCount = 0;

    // Setup current font and draw list shared data
    g.IO.Fonts->Locked = true;
    SetCurrentFont(GetDefaultFont());
    IM_ASSERT(g.Font->IsLoaded());
    g.DrawListSharedData.ClipRectFullscreen = ImVec4(0.0f, 0.0f, g.IO.DisplaySize.x, g.IO.DisplaySize.y);
    g.DrawListSharedData.CurveTessellationTol = g.Style.CurveTessellationTol;

    g.OverlayDrawList.Clear();
    g.OverlayDrawList.PushTextureID(g.IO.Fonts->TexID);
    g.OverlayDrawList.PushClipRectFullScreen();
    g.OverlayDrawList.Flags = (g.Style.AntiAliasedLines ? ImDrawListFlags_AntiAliasedLines : 0) | (g.Style.AntiAliasedFill ? ImDrawListFlags_AntiAliasedFill : 0);

    // Mark rendering data as invalid to prevent user who may have a handle on it to use it.
    g.DrawData.Clear();

    // Drag and drop keep the source ID alive so even if the source disappear our state is consistent
    if (g.DragDropActive && g.DragDropPayload.SourceId == g.ActiveId)
        KeepAliveID(g.DragDropPayload.SourceId);

    // Clear reference to active widget if the widget isn't alive anymore
    if (!g.HoveredIdPreviousFrame)
        g.HoveredIdTimer = 0.0f;
    if (!g.HoveredIdPreviousFrame || (g.HoveredId && g.ActiveId == g.HoveredId))
        g.HoveredIdNotActiveTimer = 0.0f;
    if (g.HoveredId)
        g.HoveredIdTimer += g.IO.DeltaTime;
    if (g.HoveredId && g.ActiveId != g.HoveredId)
        g.HoveredIdNotActiveTimer += g.IO.DeltaTime;
    g.HoveredIdPreviousFrame = g.HoveredId;
    g.HoveredId = 0;
    g.HoveredIdAllowOverlap = false;
    if (g.ActiveIdIsAlive != g.ActiveId && g.ActiveIdPreviousFrame == g.ActiveId && g.ActiveId != 0)
        ClearActiveID();
    if (g.ActiveId)
        g.ActiveIdTimer += g.IO.DeltaTime;
    g.LastActiveIdTimer += g.IO.DeltaTime;
    g.ActiveIdPreviousFrame = g.ActiveId;
    g.ActiveIdPreviousFrameWindow = g.ActiveIdWindow;
    g.ActiveIdPreviousFrameHasBeenEdited = g.ActiveIdHasBeenEdited;
    g.ActiveIdIsAlive = 0;
    g.ActiveIdPreviousFrameIsAlive = false;
    g.ActiveIdIsJustActivated = false;
    if (g.ScalarAsInputTextId && g.ActiveId != g.ScalarAsInputTextId)
        g.ScalarAsInputTextId = 0;

    // Drag and drop
    g.DragDropAcceptIdPrev = g.DragDropAcceptIdCurr;
    g.DragDropAcceptIdCurr = 0;
    g.DragDropAcceptIdCurrRectSurface = FLT_MAX;
    g.DragDropWithinSourceOrTarget = false;

    // Update keyboard input state
    memcpy(g.IO.KeysDownDurationPrev, g.IO.KeysDownDuration, sizeof(g.IO.KeysDownDuration));
    for (int i = 0; i < IM_ARRAYSIZE(g.IO.KeysDown); i++)
        g.IO.KeysDownDuration[i] = g.IO.KeysDown[i] ? (g.IO.KeysDownDuration[i] < 0.0f ? 0.0f : g.IO.KeysDownDuration[i] + g.IO.DeltaTime) : -1.0f;

    // Update gamepad/keyboard directional navigation
    NavUpdate();

    // Update mouse input state
    UpdateMouseInputs();

    // Calculate frame-rate for the user, as a purely luxurious feature
    g.FramerateSecPerFrameAccum += g.IO.DeltaTime - g.FramerateSecPerFrame[g.FramerateSecPerFrameIdx];
    g.FramerateSecPerFrame[g.FramerateSecPerFrameIdx] = g.IO.DeltaTime;
    g.FramerateSecPerFrameIdx = (g.FramerateSecPerFrameIdx + 1) % IM_ARRAYSIZE(g.FramerateSecPerFrame);
    g.IO.Framerate = (g.FramerateSecPerFrameAccum > 0.0f) ? (1.0f / (g.FramerateSecPerFrameAccum / (float)IM_ARRAYSIZE(g.FramerateSecPerFrame))) : FLT_MAX;

    // Handle user moving window with mouse (at the beginning of the frame to avoid input lag or sheering)
    UpdateMouseMovingWindowNewFrame();
    UpdateHoveredWindowAndCaptureFlags();

    // Background darkening/whitening
    if (GetFrontMostPopupModal() != NULL || (g.NavWindowingTarget != NULL && g.NavWindowingHighlightAlpha > 0.0f))
        g.DimBgRatio = ImMin(g.DimBgRatio + g.IO.DeltaTime * 6.0f, 1.0f);
    else
        g.DimBgRatio = ImMax(g.DimBgRatio - g.IO.DeltaTime * 10.0f, 0.0f);

    g.MouseCursor = ImGuiMouseCursor_Arrow;
    g.WantCaptureMouseNextFrame = g.WantCaptureKeyboardNextFrame = g.WantTextInputNextFrame = -1;
    g.PlatformImePos = ImVec2(1.0f, 1.0f); // OS Input Method Editor showing on top-left of our window by default

    // Mouse wheel scrolling, scale
    UpdateMouseWheel();

    // Pressing TAB activate widget focus
    if (g.ActiveId == 0 && g.NavWindow != NULL && g.NavWindow->Active && !(g.NavWindow->Flags & ImGuiWindowFlags_NoNavInputs) && !g.IO.KeyCtrl && IsKeyPressedMap(ImGuiKey_Tab, false))
    {
        if (g.NavId != 0 && g.NavIdTabCounter != INT_MAX)
            g.NavWindow->FocusIdxTabRequestNext = g.NavIdTabCounter + 1 + (g.IO.KeyShift ? -1 : 1);
        else
            g.NavWindow->FocusIdxTabRequestNext = g.IO.KeyShift ? -1 : 0;
    }
    g.NavIdTabCounter = INT_MAX;

    // Mark all windows as not visible
    IM_ASSERT(g.WindowsFocusOrder.Size == g.Windows.Size);
    for (int i = 0; i != g.Windows.Size; i++)
    {
        ImGuiWindow* window = g.Windows[i];
        window->WasActive = window->Active;
        window->Active = false;
        window->WriteAccessed = false;
    }

    // Closing the focused window restore focus to the first active root window in descending z-order
    if (g.NavWindow && !g.NavWindow->WasActive)
        FocusPreviousWindowIgnoringOne(NULL);

    // No window should be open at the beginning of the frame.
    // But in order to allow the user to call NewFrame() multiple times without calling Render(), we are doing an explicit clear.
    g.CurrentWindowStack.resize(0);
    g.BeginPopupStack.resize(0);
    ClosePopupsOverWindow(g.NavWindow);

    // Create implicit/fallback window - which we will only render it if the user has added something to it.
    // We don't use "Debug" to avoid colliding with user trying to create a "Debug" window with custom flags.
    // This fallback is particularly important as it avoid ImGui:: calls from crashing.
    SetNextWindowSize(ImVec2(400,400), ImGuiCond_FirstUseEver);
    Begin("Debug##Default");
    g.FrameScopePushedImplicitWindow = true;

#ifdef IMGUI_ENABLE_TEST_ENGINE
    ImGuiTestEngineHook_PostNewFrame(&g);
#endif
}

void ImGui::Initialize(ImGuiContext* context)
{
    ImGuiContext& g = *context;
    IM_ASSERT(!g.Initialized && !g.SettingsLoaded);

    // Add .ini handle for ImGuiWindow type
    ImGuiSettingsHandler ini_handler;
    ini_handler.TypeName = "Window";
    ini_handler.TypeHash = ImHashStr("Window", 0);
    ini_handler.ReadOpenFn = SettingsHandlerWindow_ReadOpen;
    ini_handler.ReadLineFn = SettingsHandlerWindow_ReadLine;
    ini_handler.WriteAllFn = SettingsHandlerWindow_WriteAll;
    g.SettingsHandlers.push_back(ini_handler);

    g.Initialized = true;
}

// This function is merely here to free heap allocations.
void ImGui::Shutdown(ImGuiContext* context)
{
    // The fonts atlas can be used prior to calling NewFrame(), so we clear it even if g.Initialized is FALSE (which would happen if we never called NewFrame)
    ImGuiContext& g = *context;
    if (g.IO.Fonts && g.FontAtlasOwnedByContext)
    {
        g.IO.Fonts->Locked = false;
        IM_DELETE(g.IO.Fonts);
    }
    g.IO.Fonts = NULL;

    // Cleanup of other data are conditional on actually having initialized ImGui.
    if (!g.Initialized)
        return;

    // Save settings (unless we haven't attempted to load them: CreateContext/DestroyContext without a call to NewFrame shouldn't save an empty file)
    if (g.SettingsLoaded && g.IO.IniFilename != NULL)
    {
        ImGuiContext* backup_context = GImGui;
        SetCurrentContext(context);
        SaveIniSettingsToDisk(g.IO.IniFilename);
        SetCurrentContext(backup_context);
    }

    // Clear everything else
    for (int i = 0; i < g.Windows.Size; i++)
        IM_DELETE(g.Windows[i]);
    g.Windows.clear();
    g.WindowsFocusOrder.clear();
    g.WindowsSortBuffer.clear();
    g.CurrentWindow = NULL;
    g.CurrentWindowStack.clear();
    g.WindowsById.Clear();
    g.NavWindow = NULL;
    g.HoveredWindow = g.HoveredRootWindow = NULL;
    g.ActiveIdWindow = g.ActiveIdPreviousFrameWindow = NULL;
    g.MovingWindow = NULL;
    g.ColorModifiers.clear();
    g.StyleModifiers.clear();
    g.FontStack.clear();
    g.OpenPopupStack.clear();
    g.BeginPopupStack.clear();
    g.DrawDataBuilder.ClearFreeMemory();
    g.OverlayDrawList.ClearFreeMemory();
    g.PrivateClipboard.clear();
    g.InputTextState.ClearFreeMemory();

    for (int i = 0; i < g.SettingsWindows.Size; i++)
        IM_DELETE(g.SettingsWindows[i].Name);
    g.SettingsWindows.clear();
    g.SettingsHandlers.clear();

    if (g.LogFile && g.LogFile != stdout)
    {
        fclose(g.LogFile);
        g.LogFile = NULL;
    }
    g.LogClipboard.clear();

    g.Initialized = false;
}

// FIXME: Add a more explicit sort order in the window structure.
static int IMGUI_CDECL ChildWindowComparer(const void* lhs, const void* rhs)
{
    const ImGuiWindow* const a = *(const ImGuiWindow* const *)lhs;
    const ImGuiWindow* const b = *(const ImGuiWindow* const *)rhs;
    if (int d = (a->Flags & ImGuiWindowFlags_Popup) - (b->Flags & ImGuiWindowFlags_Popup))
        return d;
    if (int d = (a->Flags & ImGuiWindowFlags_Tooltip) - (b->Flags & ImGuiWindowFlags_Tooltip))
        return d;
    return (a->BeginOrderWithinParent - b->BeginOrderWithinParent);
}

static void AddWindowToSortBuffer(ImVector<ImGuiWindow*>* out_sorted_windows, ImGuiWindow* window)
{
    out_sorted_windows->push_back(window);
    if (window->Active)
    {
        int count = window->DC.ChildWindows.Size;
        if (count > 1)
            ImQsort(window->DC.ChildWindows.begin(), (size_t)count, sizeof(ImGuiWindow*), ChildWindowComparer);
        for (int i = 0; i < count; i++)
        {
            ImGuiWindow* child = window->DC.ChildWindows[i];
            if (child->Active)
                AddWindowToSortBuffer(out_sorted_windows, child);
        }
    }
}

static void AddDrawListToDrawData(ImVector<ImDrawList*>* out_list, ImDrawList* draw_list)
{
    if (draw_list->CmdBuffer.empty())
        return;

    // Remove trailing command if unused
    ImDrawCmd& last_cmd = draw_list->CmdBuffer.back();
    if (last_cmd.ElemCount == 0 && last_cmd.UserCallback == NULL)
    {
        draw_list->CmdBuffer.pop_back();
        if (draw_list->CmdBuffer.empty())
            return;
    }

    // Draw list sanity check. Detect mismatch between PrimReserve() calls and incrementing _VtxCurrentIdx, _VtxWritePtr etc. May trigger for you if you are using PrimXXX functions incorrectly.
    //IM_ASSERT(draw_list->VtxBuffer.Size == 0 || draw_list->_VtxWritePtr == draw_list->VtxBuffer.Data + draw_list->VtxBuffer.Size);
    //IM_ASSERT(draw_list->IdxBuffer.Size == 0 || draw_list->_IdxWritePtr == draw_list->IdxBuffer.Data + draw_list->IdxBuffer.Size);
   
	// Commented this asserts because they dont like our custom drawlist
	
	IM_ASSERT((int)draw_list->_VtxCurrentIdx == draw_list->VtxBuffer.Size);

    // Check that draw_list doesn't use more vertices than indexable (default ImDrawIdx = unsigned short = 2 bytes = 64K vertices per ImDrawList = per window)
    // If this assert triggers because you are drawing lots of stuff manually:
    // A) Make sure you are coarse clipping, because ImDrawList let all your vertices pass. You can use the Metrics window to inspect draw list contents.
    // B) If you need/want meshes with more than 64K vertices, uncomment the '#define ImDrawIdx unsigned int' line in imconfig.h to set the index size to 4 bytes.
    //    You'll need to handle the 4-bytes indices to your renderer. For example, the OpenGL example code detect index size at compile-time by doing:
    //      glDrawElements(GL_TRIANGLES, (GLsizei)pcmd->ElemCount, sizeof(ImDrawIdx) == 2 ? GL_UNSIGNED_SHORT : GL_UNSIGNED_INT, idx_buffer_offset);
    //    Your own engine or render API may use different parameters or function calls to specify index sizes. 2 and 4 bytes indices are generally supported by most API.
    // C) If for some reason you cannot use 4 bytes indices or don't want to, a workaround is to call BeginChild()/EndChild() before reaching the 64K limit to split your draw commands in multiple draw lists.
    if (sizeof(ImDrawIdx) == 2)
        IM_ASSERT(draw_list->_VtxCurrentIdx < (1 << 16) && "Too many vertices in ImDrawList using 16-bit indices. Read comment above");

    out_list->push_back(draw_list);
}

static void AddWindowToDrawData(ImVector<ImDrawList*>* out_render_list, ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    g.IO.MetricsRenderWindows++;
    AddDrawListToDrawData(out_render_list, window->DrawList);
    for (int i = 0; i < window->DC.ChildWindows.Size; i++)
    {
        ImGuiWindow* child = window->DC.ChildWindows[i];
        if (IsWindowActiveAndVisible(child)) // clipped children may have been marked not active
            AddWindowToDrawData(out_render_list, child);
    }
}

static void AddRootWindowToDrawData(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    if (window->Flags & ImGuiWindowFlags_Tooltip)
        AddWindowToDrawData(&g.DrawDataBuilder.Layers[1], window);
    else
        AddWindowToDrawData(&g.DrawDataBuilder.Layers[0], window);
}

void ImDrawDataBuilder::FlattenIntoSingleLayer()
{
    int n = Layers[0].Size;
    int size = n;
    for (int i = 1; i < IM_ARRAYSIZE(Layers); i++)
        size += Layers[i].Size;
    Layers[0].resize(size);
    for (int layer_n = 1; layer_n < IM_ARRAYSIZE(Layers); layer_n++)
    {
        ImVector<ImDrawList*>& layer = Layers[layer_n];
        if (layer.empty())
            continue;
        memcpy(&Layers[0][n], &layer[0], layer.Size * sizeof(ImDrawList*));
        n += layer.Size;
        layer.resize(0);
    }
}

static void SetupDrawData(ImVector<ImDrawList*>* draw_lists, ImDrawData* draw_data)
{
    ImGuiIO& io = ImGui::GetIO();
    draw_data->Valid = true;
    draw_data->CmdLists = (draw_lists->Size > 0) ? draw_lists->Data : NULL;
    draw_data->CmdListsCount = draw_lists->Size;
    draw_data->TotalVtxCount = draw_data->TotalIdxCount = 0;
    draw_data->DisplayPos = ImVec2(0.0f, 0.0f);
    draw_data->DisplaySize = io.DisplaySize;
    draw_data->FramebufferScale = io.DisplayFramebufferScale;
    for (int n = 0; n < draw_lists->Size; n++)
    {
        draw_data->TotalVtxCount += draw_lists->Data[n]->VtxBuffer.Size;
        draw_data->TotalIdxCount += draw_lists->Data[n]->IdxBuffer.Size;
    }
}

// When using this function it is sane to ensure that float are perfectly rounded to integer values, to that e.g. (int)(max.x-min.x) in user's render produce correct result.
void ImGui::PushClipRect(const ImVec2& clip_rect_min, const ImVec2& clip_rect_max, bool intersect_with_current_clip_rect)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DrawList->PushClipRect(clip_rect_min, clip_rect_max, intersect_with_current_clip_rect);
    window->ClipRect = window->DrawList->_ClipRectStack.back();
}

void ImGui::PopClipRect()
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DrawList->PopClipRect();
    window->ClipRect = window->DrawList->_ClipRectStack.back();
}

// This is normally called by Render(). You may want to call it directly if you want to avoid calling Render() but the gain will be very minimal.
void ImGui::EndFrame()
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.Initialized);
    if (g.FrameCountEnded == g.FrameCount)          // Don't process EndFrame() multiple times.
        return;
    IM_ASSERT(g.FrameScopeActive && "Forgot to call ImGui::NewFrame()?");

    // Notify OS when our Input Method Editor cursor has moved (e.g. CJK inputs using Microsoft IME)
    if (g.IO.ImeSetInputScreenPosFn && (g.PlatformImeLastPos.x == FLT_MAX || ImLengthSqr(g.PlatformImeLastPos - g.PlatformImePos) > 0.0001f))
    {
        g.IO.ImeSetInputScreenPosFn((int)g.PlatformImePos.x, (int)g.PlatformImePos.y);
        g.PlatformImeLastPos = g.PlatformImePos;
    }

    // Report when there is a mismatch of Begin/BeginChild vs End/EndChild calls. Important: Remember that the Begin/BeginChild API requires you
    // to always call End/EndChild even if Begin/BeginChild returns false! (this is unfortunately inconsistent with most other Begin* API).
    if (g.CurrentWindowStack.Size != 1)
    {
        if (g.CurrentWindowStack.Size > 1)
        {
            IM_ASSERT(g.CurrentWindowStack.Size == 1 && "Mismatched Begin/BeginChild vs End/EndChild calls: did you forget to call End/EndChild?");
            while (g.CurrentWindowStack.Size > 1) // FIXME-ERRORHANDLING
                End();
        }
        else
        {
            IM_ASSERT(g.CurrentWindowStack.Size == 1 && "Mismatched Begin/BeginChild vs End/EndChild calls: did you call End/EndChild too much?");
        }
    }

    // Hide implicit/fallback "Debug" window if it hasn't been used
    g.FrameScopePushedImplicitWindow = false;
    if (g.CurrentWindow && !g.CurrentWindow->WriteAccessed)
        g.CurrentWindow->Active = false;
    End();

    // Show CTRL+TAB list window
    if (g.NavWindowingTarget)
        NavUpdateWindowingList();

    // Drag and Drop: Elapse payload (if delivered, or if source stops being submitted)
    if (g.DragDropActive)
    {
        bool is_delivered = g.DragDropPayload.Delivery;
        bool is_elapsed = (g.DragDropPayload.DataFrameCount + 1 < g.FrameCount) && ((g.DragDropSourceFlags & ImGuiDragDropFlags_SourceAutoExpirePayload) || !IsMouseDown(g.DragDropMouseButton));
        if (is_delivered || is_elapsed)
            ClearDragDrop();
    }

    // Drag and Drop: Fallback for source tooltip. This is not ideal but better than nothing.
    if (g.DragDropActive && g.DragDropSourceFrameCount < g.FrameCount)
    {
        g.DragDropWithinSourceOrTarget = true;
        SetTooltip("...");
        g.DragDropWithinSourceOrTarget = false;
    }

    // End frame
    g.FrameScopeActive = false;
    g.FrameCountEnded = g.FrameCount;

    // Initiate moving window + handle left-click and right-click focus
    UpdateMouseMovingWindowEndFrame();

    // Sort the window list so that all child windows are after their parent
    // We cannot do that on FocusWindow() because childs may not exist yet
    g.WindowsSortBuffer.resize(0);
    g.WindowsSortBuffer.reserve(g.Windows.Size);
    for (int i = 0; i != g.Windows.Size; i++)
    {
        ImGuiWindow* window = g.Windows[i];
        if (window->Active && (window->Flags & ImGuiWindowFlags_ChildWindow))       // if a child is active its parent will add it
            continue;
        AddWindowToSortBuffer(&g.WindowsSortBuffer, window);
    }

    // This usually assert if there is a mismatch between the ImGuiWindowFlags_ChildWindow / ParentWindow values and DC.ChildWindows[] in parents, aka we've done something wrong.
    IM_ASSERT(g.Windows.Size == g.WindowsSortBuffer.Size);
    g.Windows.swap(g.WindowsSortBuffer);
    g.IO.MetricsActiveWindows = g.WindowsActiveCount;

    // Unlock font atlas
    g.IO.Fonts->Locked = false;

    // Clear Input data for next frame
    g.IO.MouseWheel = g.IO.MouseWheelH = 0.0f;
    g.IO.InputQueueCharacters.resize(0);
    memset(g.IO.NavInputs, 0, sizeof(g.IO.NavInputs));
}

void ImGui::Render(ImDrawList* our_list)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.Initialized);

    if (g.FrameCountEnded != g.FrameCount)
        EndFrame();
    g.FrameCountRendered = g.FrameCount;

    // Gather ImDrawList to render (for each active window)
    g.IO.MetricsRenderVertices = g.IO.MetricsRenderIndices = g.IO.MetricsRenderWindows = 0;
    g.DrawDataBuilder.Clear();

	// Adding our custom drawlist to imgui's drawdata
	if (our_list && !our_list->VtxBuffer.empty())
		AddDrawListToDrawData(&g.DrawDataBuilder.Layers[0], our_list);



    ImGuiWindow* windows_to_render_front_most[2];
    windows_to_render_front_most[0] = (g.NavWindowingTarget && !(g.NavWindowingTarget->Flags & ImGuiWindowFlags_NoBringToFrontOnFocus)) ? g.NavWindowingTarget->RootWindow : NULL;
    windows_to_render_front_most[1] = g.NavWindowingTarget ? g.NavWindowingList : NULL;
    for (int n = 0; n != g.Windows.Size; n++)
    {
        ImGuiWindow* window = g.Windows[n];
        if (IsWindowActiveAndVisible(window) && (window->Flags & ImGuiWindowFlags_ChildWindow) == 0 && window != windows_to_render_front_most[0] && window != windows_to_render_front_most[1])
            AddRootWindowToDrawData(window);
    }
    for (int n = 0; n < IM_ARRAYSIZE(windows_to_render_front_most); n++)
        if (windows_to_render_front_most[n] && IsWindowActiveAndVisible(windows_to_render_front_most[n])) // NavWindowingTarget is always temporarily displayed as the front-most window
            AddRootWindowToDrawData(windows_to_render_front_most[n]);
    g.DrawDataBuilder.FlattenIntoSingleLayer();

    // Draw software mouse cursor if requested
    if (g.IO.MouseDrawCursor)
        RenderMouseCursor(&g.OverlayDrawList, g.IO.MousePos, g.Style.MouseCursorScale, g.MouseCursor);

    if (!g.OverlayDrawList.VtxBuffer.empty())
        AddDrawListToDrawData(&g.DrawDataBuilder.Layers[0], &g.OverlayDrawList);

    // Setup ImDrawData structure for end-user
    SetupDrawData(&g.DrawDataBuilder.Layers[0], &g.DrawData);
    g.IO.MetricsRenderVertices = g.DrawData.TotalVtxCount;
    g.IO.MetricsRenderIndices = g.DrawData.TotalIdxCount;

    // (Legacy) Call the Render callback function. The current prefer way is to let the user retrieve GetDrawData() and call the render function themselves.
#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
    if (g.DrawData.CmdListsCount > 0 && g.IO.RenderDrawListsFn != NULL)
        g.IO.RenderDrawListsFn(&g.DrawData);
#endif
}
using namespace std;

void ImGui::SelectTabs(int* selected, const char* items[], int item_count, ImVec2 size)
{
	auto color_grayblue = GetColorU32(ImVec4(0.48, 0.48, 0.48, 0.20));
	auto color_deepblue = GetColorU32(ImVec4(0.12, 0.12, 0.12, 0.15));
	auto color_shade_hover = GetColorU32(ImVec4(0.8, 0.8, 0.8, 0.05));
	auto color_shade_clicked = GetColorU32(ImVec4(0.1, 0.1, 0.1, 0.1));
	auto color_black_outlines = GetColorU32(ImVec4(0, 0, 0, 1));

	ImGuiStyle& style = GetStyle();
	ImGuiWindow* window = GetCurrentWindow();
	if (window->SkipItems)
		return;

	std::string names;
	for (size_t i = 0; i < item_count; i++)
		names += items[i];

	ImGuiContext* g = GImGui;
	const ImGuiID id = window->GetID(names.c_str());
	const ImVec2 label_size = CalcTextSize(names.c_str(), NULL, true);

	ImVec2 Min = window->DC.CursorPos;
	ImVec2 Max = ((size.x <= 0 || size.y <= 0) ? ImVec2(Min.x + GetContentRegionMax().x - style.WindowPadding.x, Min.y + label_size.y * 2) : Min + size);

	ImRect bb(Min, Max);
	ItemSize(bb, style.FramePadding.y);
	if (!ItemAdd(bb, id))
		return;

	PushClipRect(ImVec2(Min.x, Min.y - 1), ImVec2(Max.x, Max.y + 1), false);

	window->DrawList->AddRectFilledMultiColor(Min, Max, color_grayblue, color_grayblue, color_deepblue, color_deepblue); // Main gradient.

	ImVec2 mouse_pos = GetMousePos();
	bool mouse_click = g->IO.MouseClicked[0];

	float TabSize = ceil((Max.x - Min.x) / item_count);

	for (size_t i = 0; i < item_count; i++)
	{
		ImVec2 Min_cur_label = ImVec2(Min.x + (int)TabSize * i, Min.y);
		ImVec2 Max_cur_label = ImVec2(Min.x + (int)TabSize * i + (int)TabSize, Max.y);

		// Imprecision clamping. gay but works :^)
		Max_cur_label.x = (Max_cur_label.x >= Max.x ? Max.x : Max_cur_label.x);

		if (mouse_pos.x > Min_cur_label.x&& mouse_pos.x < Max_cur_label.x &&
			mouse_pos.y > Min_cur_label.y&& mouse_pos.y < Max_cur_label.y)
		{
			if (mouse_click)
				*selected = i;
			else if (i != *selected)
				window->DrawList->AddRectFilled(Min_cur_label, Max_cur_label, color_shade_hover);
		}

		if (i == *selected) {
			window->DrawList->AddRectFilled(Min_cur_label, Max_cur_label, color_shade_clicked);
			window->DrawList->AddRectFilledMultiColor(Min_cur_label, Max_cur_label, color_deepblue, color_deepblue, color_grayblue, color_grayblue);
			window->DrawList->AddLine(ImVec2(Min_cur_label.x - 1.5f, Min_cur_label.y - 1), ImVec2(Max_cur_label.x - 0.5f, Min_cur_label.y - 1), color_black_outlines);
		}
		else
			window->DrawList->AddLine(ImVec2(Min_cur_label.x - 1, Min_cur_label.y), ImVec2(Max_cur_label.x, Min_cur_label.y), color_black_outlines);
		window->DrawList->AddLine(ImVec2(Max_cur_label.x - 1, Max_cur_label.y), ImVec2(Max_cur_label.x - 1, Min_cur_label.y - 0.5f), color_black_outlines);

		const ImVec2 text_size = CalcTextSize(items[i], NULL, true);
		float pad_ = style.FramePadding.x + g->FontSize + style.ItemInnerSpacing.x;
		ImRect tab_rect(Min_cur_label, Max_cur_label);
		RenderTextClipped(Min_cur_label, Max_cur_label, items[i], NULL, &text_size, style.WindowTitleAlign, &tab_rect);
	}

	window->DrawList->AddLine(ImVec2(Min.x, Min.y - 0.5f), ImVec2(Min.x, Max.y), color_black_outlines);
	window->DrawList->AddLine(ImVec2(Min.x, Max.y), Max, color_black_outlines);
	PopClipRect();
}

// Calculate text size. Text can be multi-line. Optionally ignore text after a ## marker.
// CalcTextSize("") should return ImVec2(0.0f, GImGui->FontSize)
ImVec2 ImGui::CalcTextSize(const char* text, const char* text_end, bool hide_text_after_double_hash, float wrap_width)
{
    ImGuiContext& g = *GImGui;

    const char* text_display_end;
    if (hide_text_after_double_hash)
        text_display_end = FindRenderedTextEnd(text, text_end);      // Hide anything after a '##' string
    else
        text_display_end = text_end;

    ImFont* font = g.Font;
    const float font_size = g.FontSize;
    if (text == text_display_end)
        return ImVec2(0.0f, font_size);
    ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, wrap_width, text, text_display_end, NULL);

    // Round
    text_size.x = (float)(int)(text_size.x + 0.95f);

    return text_size;
}

// Helper to calculate coarse clipping of large list of evenly sized items.
// NB: Prefer using the ImGuiListClipper higher-level helper if you can! Read comments and instructions there on how those use this sort of pattern.
// NB: 'items_count' is only used to clamp the result, if you don't know your count you can use INT_MAX
void ImGui::CalcListClipping(int items_count, float items_height, int* out_items_display_start, int* out_items_display_end)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (g.LogEnabled)
    {
        // If logging is active, do not perform any clipping
        *out_items_display_start = 0;
        *out_items_display_end = items_count;
        return;
    }
    if (window->SkipItems)
    {
        *out_items_display_start = *out_items_display_end = 0;
        return;
    }

    // We create the union of the ClipRect and the NavScoringRect which at worst should be 1 page away from ClipRect
    ImRect unclipped_rect = window->ClipRect;
    if (g.NavMoveRequest)
        unclipped_rect.Add(g.NavScoringRectScreen);

    const ImVec2 pos = window->DC.CursorPos;
    int start = (int)((unclipped_rect.Min.y - pos.y) / items_height);
    int end = (int)((unclipped_rect.Max.y - pos.y) / items_height);

    // When performing a navigation request, ensure we have one item extra in the direction we are moving to
    if (g.NavMoveRequest && g.NavMoveClipDir == ImGuiDir_Up)
        start--;
    if (g.NavMoveRequest && g.NavMoveClipDir == ImGuiDir_Down)
        end++;

    start = ImClamp(start, 0, items_count);
    end = ImClamp(end + 1, start, items_count);
    *out_items_display_start = start;
    *out_items_display_end = end;
}

// Find window given position, search front-to-back
// FIXME: Note that we have an inconsequential lag here: OuterRectClipped is updated in Begin(), so windows moved programatically
// with SetWindowPos() and not SetNextWindowPos() will have that rectangle lagging by a frame at the time FindHoveredWindow() is
// called, aka before the next Begin(). Moving window isn't affected.
static void FindHoveredWindow()
{
    ImGuiContext& g = *GImGui;

    ImGuiWindow* hovered_window = NULL;
    if (g.MovingWindow && !(g.MovingWindow->Flags & ImGuiWindowFlags_NoMouseInputs))
        hovered_window = g.MovingWindow;

    ImVec2 padding_regular = g.Style.TouchExtraPadding;
    ImVec2 padding_for_resize_from_edges = g.IO.ConfigWindowsResizeFromEdges ? ImMax(g.Style.TouchExtraPadding, ImVec2(WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS, WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS)) : padding_regular;
    for (int i = g.Windows.Size - 1; i >= 0; i--)
    {
        ImGuiWindow* window = g.Windows[i];
        if (!window->Active || window->Hidden)
            continue;
        if (window->Flags & ImGuiWindowFlags_NoMouseInputs)
            continue;

        // Using the clipped AABB, a child window will typically be clipped by its parent (not always)
        ImRect bb(window->OuterRectClipped);
        if ((window->Flags & ImGuiWindowFlags_ChildWindow) || (window->Flags & ImGuiWindowFlags_NoResize))
            bb.Expand(padding_regular);
        else
            bb.Expand(padding_for_resize_from_edges);
        if (!bb.Contains(g.IO.MousePos))
            continue;

        // Those seemingly unnecessary extra tests are because the code here is a little different in viewport/docking branches.
        if (hovered_window == NULL)
            hovered_window = window;
        if (hovered_window)
            break;
    }

    g.HoveredWindow = hovered_window;
    g.HoveredRootWindow = g.HoveredWindow ? g.HoveredWindow->RootWindow : NULL;

}

// Test if mouse cursor is hovering given rectangle
// NB- Rectangle is clipped by our current clip setting
// NB- Expand the rectangle to be generous on imprecise inputs systems (g.Style.TouchExtraPadding)
bool ImGui::IsMouseHoveringRect(const ImVec2& r_min, const ImVec2& r_max, bool clip)
{
    ImGuiContext& g = *GImGui;

    // Clip
    ImRect rect_clipped(r_min, r_max);
    if (clip)
        rect_clipped.ClipWith(g.CurrentWindow->ClipRect);

    // Expand for touch input
    const ImRect rect_for_touch(rect_clipped.Min - g.Style.TouchExtraPadding, rect_clipped.Max + g.Style.TouchExtraPadding);
    if (!rect_for_touch.Contains(g.IO.MousePos))
        return false;
    return true;
}

int ImGui::GetKeyIndex(ImGuiKey imgui_key)
{
    IM_ASSERT(imgui_key >= 0 && imgui_key < ImGuiKey_COUNT);
    return GImGui->IO.KeyMap[imgui_key];
}

// Note that imgui doesn't know the semantic of each entry of io.KeysDown[]. Use your own indices/enums according to how your back-end/engine stored them into io.KeysDown[]!
bool ImGui::IsKeyDown(int user_key_index)
{
    if (user_key_index < 0) return false;
    IM_ASSERT(user_key_index >= 0 && user_key_index < IM_ARRAYSIZE(GImGui->IO.KeysDown));
    return GImGui->IO.KeysDown[user_key_index];
}

int ImGui::CalcTypematicPressedRepeatAmount(float t, float t_prev, float repeat_delay, float repeat_rate)
{
    if (t == 0.0f)
        return 1;
    if (t <= repeat_delay || repeat_rate <= 0.0f)
        return 0;
    const int count = (int)((t - repeat_delay) / repeat_rate) - (int)((t_prev - repeat_delay) / repeat_rate);
    return (count > 0) ? count : 0;
}

int ImGui::GetKeyPressedAmount(int key_index, float repeat_delay, float repeat_rate)
{
    ImGuiContext& g = *GImGui;
    if (key_index < 0) 
        return 0;
    IM_ASSERT(key_index >= 0 && key_index < IM_ARRAYSIZE(g.IO.KeysDown));
    const float t = g.IO.KeysDownDuration[key_index];
    return CalcTypematicPressedRepeatAmount(t, t - g.IO.DeltaTime, repeat_delay, repeat_rate);
}

bool ImGui::IsKeyPressed(int user_key_index, bool repeat)
{
    ImGuiContext& g = *GImGui;
    if (user_key_index < 0) 
        return false;
    IM_ASSERT(user_key_index >= 0 && user_key_index < IM_ARRAYSIZE(g.IO.KeysDown));
    const float t = g.IO.KeysDownDuration[user_key_index];
    if (t == 0.0f)
        return true;
    if (repeat && t > g.IO.KeyRepeatDelay)
        return GetKeyPressedAmount(user_key_index, g.IO.KeyRepeatDelay, g.IO.KeyRepeatRate) > 0;
    return false;
}

bool ImGui::IsKeyReleased(int user_key_index)
{
    ImGuiContext& g = *GImGui;
    if (user_key_index < 0) return false;
    IM_ASSERT(user_key_index >= 0 && user_key_index < IM_ARRAYSIZE(g.IO.KeysDown));
    return g.IO.KeysDownDurationPrev[user_key_index] >= 0.0f && !g.IO.KeysDown[user_key_index];
}

bool ImGui::IsMouseDown(int button)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(button >= 0 && button < IM_ARRAYSIZE(g.IO.MouseDown));
    return g.IO.MouseDown[button];
}

bool ImGui::IsAnyMouseDown()
{
    ImGuiContext& g = *GImGui;
    for (int n = 0; n < IM_ARRAYSIZE(g.IO.MouseDown); n++)
        if (g.IO.MouseDown[n])
            return true;
    return false;
}

bool ImGui::IsMouseClicked(int button, bool repeat)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(button >= 0 && button < IM_ARRAYSIZE(g.IO.MouseDown));
    const float t = g.IO.MouseDownDuration[button];
    if (t == 0.0f)
        return true;

    if (repeat && t > g.IO.KeyRepeatDelay)
    {
        float delay = g.IO.KeyRepeatDelay, rate = g.IO.KeyRepeatRate;
        if ((ImFmod(t - delay, rate) > rate*0.5f) != (ImFmod(t - delay - g.IO.DeltaTime, rate) > rate*0.5f))
            return true;
    }

    return false;
}

bool ImGui::IsMouseReleased(int button)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(button >= 0 && button < IM_ARRAYSIZE(g.IO.MouseDown));
    return g.IO.MouseReleased[button];
}

bool ImGui::IsMouseDoubleClicked(int button)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(button >= 0 && button < IM_ARRAYSIZE(g.IO.MouseDown));
    return g.IO.MouseDoubleClicked[button];
}

bool ImGui::IsMouseDragging(int button, float lock_threshold)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(button >= 0 && button < IM_ARRAYSIZE(g.IO.MouseDown));
    if (!g.IO.MouseDown[button])
        return false;
    if (lock_threshold < 0.0f)
        lock_threshold = g.IO.MouseDragThreshold;
    return g.IO.MouseDragMaxDistanceSqr[button] >= lock_threshold * lock_threshold;
}

ImVec2 ImGui::GetMousePos()
{
    return GImGui->IO.MousePos;
}

// NB: prefer to call right after BeginPopup(). At the time Selectable/MenuItem is activated, the popup is already closed!
ImVec2 ImGui::GetMousePosOnOpeningCurrentPopup()
{
    ImGuiContext& g = *GImGui;
    if (g.BeginPopupStack.Size > 0)
        return g.OpenPopupStack[g.BeginPopupStack.Size-1].OpenMousePos;
    return g.IO.MousePos;
}

// We typically use ImVec2(-FLT_MAX,-FLT_MAX) to denote an invalid mouse position.
bool ImGui::IsMousePosValid(const ImVec2* mouse_pos)
{
    // The assert is only to silence a false-positive in XCode Static Analysis.
    // Because GImGui is not dereferenced in every code path, the static analyzer assume that it may be NULL (which it doesn't for other functions).
    IM_ASSERT(GImGui != NULL);
    const float MOUSE_INVALID = -256000.0f;
    ImVec2 p = mouse_pos ? *mouse_pos : GImGui->IO.MousePos;
    return p.x >= MOUSE_INVALID && p.y >= MOUSE_INVALID;
}

// Return the delta from the initial clicking position.
// This is locked and return 0.0f until the mouse moves past a distance threshold at least once.
// NB: This is only valid if IsMousePosValid(). Back-ends in theory should always keep mouse position valid when dragging even outside the client window.
ImVec2 ImGui::GetMouseDragDelta(int button, float lock_threshold)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(button >= 0 && button < IM_ARRAYSIZE(g.IO.MouseDown));
    if (lock_threshold < 0.0f)
        lock_threshold = g.IO.MouseDragThreshold;
    if (g.IO.MouseDown[button])
        if (g.IO.MouseDragMaxDistanceSqr[button] >= lock_threshold * lock_threshold)
            return g.IO.MousePos - g.IO.MouseClickedPos[button];     // Assume we can only get active with left-mouse button (at the moment).
    return ImVec2(0.0f, 0.0f);
}

void ImGui::ResetMouseDragDelta(int button)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(button >= 0 && button < IM_ARRAYSIZE(g.IO.MouseDown));
    // NB: We don't need to reset g.IO.MouseDragMaxDistanceSqr
    g.IO.MouseClickedPos[button] = g.IO.MousePos;
}

ImGuiMouseCursor ImGui::GetMouseCursor()
{
    return GImGui->MouseCursor;
}

void ImGui::SetMouseCursor(ImGuiMouseCursor cursor_type)
{
    GImGui->MouseCursor = cursor_type;
}

void ImGui::CaptureKeyboardFromApp(bool capture)
{
    GImGui->WantCaptureKeyboardNextFrame = capture ? 1 : 0;
}

void ImGui::CaptureMouseFromApp(bool capture)
{
    GImGui->WantCaptureMouseNextFrame = capture ? 1 : 0;
}

bool ImGui::IsItemActive()
{
    ImGuiContext& g = *GImGui;
    if (g.ActiveId)
    {
        ImGuiWindow* window = g.CurrentWindow;
        return g.ActiveId == window->DC.LastItemId;
    }
    return false;
}

bool ImGui::IsItemActivated()
{
    ImGuiContext& g = *GImGui;
    if (g.ActiveId)
    {
        ImGuiWindow* window = g.CurrentWindow;
        if (g.ActiveId == window->DC.LastItemId && g.ActiveIdPreviousFrame != window->DC.LastItemId)
            return true;
    }
    return false;
}

bool ImGui::IsItemDeactivated()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    return (g.ActiveIdPreviousFrame == window->DC.LastItemId && g.ActiveIdPreviousFrame != 0 && g.ActiveId != window->DC.LastItemId);
}

bool ImGui::IsItemDeactivatedAfterEdit()
{
    ImGuiContext& g = *GImGui;
    return IsItemDeactivated() && (g.ActiveIdPreviousFrameHasBeenEdited || (g.ActiveId == 0 && g.ActiveIdHasBeenEdited));
}

bool ImGui::IsItemFocused()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    if (g.NavId == 0 || g.NavDisableHighlight || g.NavId != window->DC.LastItemId)
        return false;
    return true;
}

bool ImGui::IsItemClicked(int mouse_button)
{
    return IsMouseClicked(mouse_button) && IsItemHovered(ImGuiHoveredFlags_None);
}

bool ImGui::IsAnyItemHovered()
{
    ImGuiContext& g = *GImGui;
    return g.HoveredId != 0 || g.HoveredIdPreviousFrame != 0;
}

bool ImGui::IsAnyItemActive()
{
    ImGuiContext& g = *GImGui;
    return g.ActiveId != 0;
}

bool ImGui::IsAnyItemFocused()
{
    ImGuiContext& g = *GImGui;
    return g.NavId != 0 && !g.NavDisableHighlight;
}

bool ImGui::IsItemVisible()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->ClipRect.Overlaps(window->DC.LastItemRect);
}

bool ImGui::IsItemEdited()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return (window->DC.LastItemStatusFlags & ImGuiItemStatusFlags_Edited) != 0;
}

// Allow last item to be overlapped by a subsequent item. Both may be activated during the same frame before the later one takes priority.
void ImGui::SetItemAllowOverlap()
{
    ImGuiContext& g = *GImGui;
    if (g.HoveredId == g.CurrentWindow->DC.LastItemId)
        g.HoveredIdAllowOverlap = true;
    if (g.ActiveId == g.CurrentWindow->DC.LastItemId)
        g.ActiveIdAllowOverlap = true;
}

ImVec2 ImGui::GetItemRectMin()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.LastItemRect.Min;
}

ImVec2 ImGui::GetItemRectMax()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.LastItemRect.Max;
}

ImVec2 ImGui::GetItemRectSize()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.LastItemRect.GetSize();
}

static ImRect GetViewportRect()
{
    ImGuiContext& g = *GImGui;
    return ImRect(0.0f, 0.0f, g.IO.DisplaySize.x, g.IO.DisplaySize.y);
}

static bool ImGui::BeginChildEx(const char* name, ImGuiID id, const ImVec2& size_arg, bool border, ImGuiWindowFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* parent_window = g.CurrentWindow;

    flags |= ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_ChildWindow;
    flags |= (parent_window->Flags & ImGuiWindowFlags_NoMove);  // Inherit the NoMove flag

    // Size
    const ImVec2 content_avail = GetContentRegionAvail();
    ImVec2 size = ImFloor(size_arg);
    const int auto_fit_axises = ((size.x == 0.0f) ? (1 << ImGuiAxis_X) : 0x00) | ((size.y == 0.0f) ? (1 << ImGuiAxis_Y) : 0x00);
    if (size.x <= 0.0f)
        size.x = ImMax(content_avail.x + size.x, 4.0f); // Arbitrary minimum child size (0.0f causing too much issues)
    if (size.y <= 0.0f)
        size.y = ImMax(content_avail.y + size.y, 4.0f);
    SetNextWindowSize(size);

    // Build up name. If you need to append to a same child from multiple location in the ID stack, use BeginChild(ImGuiID id) with a stable value.
    char title[256];
    if (name)
        ImFormatString(title, IM_ARRAYSIZE(title), "%s/%s_%08X", parent_window->Name, name, id);
    else
        ImFormatString(title, IM_ARRAYSIZE(title), "%s/%08X", parent_window->Name, id);

    const float backup_border_size = g.Style.ChildBorderSize;
    if (!border)
        g.Style.ChildBorderSize = 0.0f;
    bool ret = Begin(title, NULL, flags);
    g.Style.ChildBorderSize = backup_border_size;

    ImGuiWindow* child_window = g.CurrentWindow;
    child_window->ChildId = id;
    child_window->AutoFitChildAxises = auto_fit_axises;

    // Set the cursor to handle case where the user called SetNextWindowPos()+BeginChild() manually.
    // While this is not really documented/defined, it seems that the expected thing to do.
    if (child_window->BeginCount == 1)
        parent_window->DC.CursorPos = child_window->Pos;

    // Process navigation-in immediately so NavInit can run on first frame
    if (g.NavActivateId == id && !(flags & ImGuiWindowFlags_NavFlattened) && (child_window->DC.NavLayerActiveMask != 0 || child_window->DC.NavHasScroll))
    {
        FocusWindow(child_window);
        NavInitWindow(child_window, false);
        SetActiveID(id+1, child_window); // Steal ActiveId with a dummy id so that key-press won't activate child item
        g.ActiveIdSource = ImGuiInputSource_Nav;
    }
    return ret;
}

bool ImGui::BeginChild(const char* str_id, const ImVec2& size_arg, bool border, ImGuiWindowFlags extra_flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    return BeginChildEx(str_id, window->GetID(str_id), size_arg, border, extra_flags);
}

bool ImGui::BeginChild(ImGuiID id, const ImVec2& size_arg, bool border, ImGuiWindowFlags extra_flags)
{
    IM_ASSERT(id != 0);
    return BeginChildEx(NULL, id, size_arg, border, extra_flags);
}

void ImGui::EndChild()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    IM_ASSERT(window->Flags & ImGuiWindowFlags_ChildWindow);   // Mismatched BeginChild()/EndChild() callss
    if (window->BeginCount > 1)
    {
        End();
    }
    else
    {
        ImVec2 sz = window->Size;
        if (window->AutoFitChildAxises & (1 << ImGuiAxis_X)) // Arbitrary minimum zero-ish child size of 4.0f causes less trouble than a 0.0f
            sz.x = ImMax(4.0f, sz.x);
        if (window->AutoFitChildAxises & (1 << ImGuiAxis_Y))
            sz.y = ImMax(4.0f, sz.y);
        End();

        ImGuiWindow* parent_window = g.CurrentWindow;
        ImRect bb(parent_window->DC.CursorPos, parent_window->DC.CursorPos + sz);
        ItemSize(sz);
        if ((window->DC.NavLayerActiveMask != 0 || window->DC.NavHasScroll) && !(window->Flags & ImGuiWindowFlags_NavFlattened))
        {
            ItemAdd(bb, window->ChildId);
            RenderNavHighlight(bb, window->ChildId);

            // When browsing a window that has no activable items (scroll only) we keep a highlight on the child
            if (window->DC.NavLayerActiveMask == 0 && window == g.NavWindow)
                RenderNavHighlight(ImRect(bb.Min - ImVec2(2,2), bb.Max + ImVec2(2,2)), g.NavId, ImGuiNavHighlightFlags_TypeThin);
        }
        else
        {
            // Not navigable into
            ItemAdd(bb, 0);
        }
    }
}

// Helper to create a child window / scrolling region that looks like a normal widget frame.
bool ImGui::BeginChildFrame(ImGuiID id, const ImVec2& size, ImGuiWindowFlags extra_flags)
{
    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    PushStyleColor(ImGuiCol_ChildBg, style.Colors[ImGuiCol_FrameBg]);
    PushStyleVar(ImGuiStyleVar_ChildRounding, style.FrameRounding);
    PushStyleVar(ImGuiStyleVar_ChildBorderSize, style.FrameBorderSize);
    PushStyleVar(ImGuiStyleVar_WindowPadding, style.FramePadding);
    bool ret = BeginChild(id, size, true, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysUseWindowPadding | extra_flags);
    PopStyleVar(3);
    PopStyleColor();
    return ret;
}

void ImGui::EndChildFrame()
{
    EndChild();
}

// Save and compare stack sizes on Begin()/End() to detect usage errors
static void CheckStacksSize(ImGuiWindow* window, bool write)
{
    // NOT checking: DC.ItemWidth, DC.AllowKeyboardFocus, DC.ButtonRepeat, DC.TextWrapPos (per window) to allow user to conveniently push once and not pop (they are cleared on Begin)
    ImGuiContext& g = *GImGui;
    short* p_backup = &window->DC.StackSizesBackup[0];
    { int current = window->IDStack.Size;       if (write) *p_backup = (short)current; else IM_ASSERT(*p_backup == current && "PushID/PopID or TreeNode/TreePop Mismatch!");   p_backup++; }    // Too few or too many PopID()/TreePop()
    { int current = window->DC.GroupStack.Size; if (write) *p_backup = (short)current; else IM_ASSERT(*p_backup == current && "BeginGroup/EndGroup Mismatch!");                p_backup++; }    // Too few or too many EndGroup()
    { int current = g.BeginPopupStack.Size;     if (write) *p_backup = (short)current; else IM_ASSERT(*p_backup == current && "BeginMenu/EndMenu or BeginPopup/EndPopup Mismatch"); p_backup++;}// Too few or too many EndMenu()/EndPopup()
    // For color, style and font stacks there is an incentive to use Push/Begin/Pop/.../End patterns, so we relax our checks a little to allow them.
    { int current = g.ColorModifiers.Size;      if (write) *p_backup = (short)current; else IM_ASSERT(*p_backup >= current && "PushStyleColor/PopStyleColor Mismatch!");       p_backup++; }    // Too few or too many PopStyleColor()
    { int current = g.StyleModifiers.Size;      if (write) *p_backup = (short)current; else IM_ASSERT(*p_backup >= current && "PushStyleVar/PopStyleVar Mismatch!");           p_backup++; }    // Too few or too many PopStyleVar()
    { int current = g.FontStack.Size;           if (write) *p_backup = (short)current; else IM_ASSERT(*p_backup >= current && "PushFont/PopFont Mismatch!");                   p_backup++; }    // Too few or too many PopFont()
    IM_ASSERT(p_backup == window->DC.StackSizesBackup + IM_ARRAYSIZE(window->DC.StackSizesBackup));
}

static void SetWindowConditionAllowFlags(ImGuiWindow* window, ImGuiCond flags, bool enabled)
{
    window->SetWindowPosAllowFlags       = enabled ? (window->SetWindowPosAllowFlags       | flags) : (window->SetWindowPosAllowFlags       & ~flags);
    window->SetWindowSizeAllowFlags      = enabled ? (window->SetWindowSizeAllowFlags      | flags) : (window->SetWindowSizeAllowFlags      & ~flags);
    window->SetWindowCollapsedAllowFlags = enabled ? (window->SetWindowCollapsedAllowFlags | flags) : (window->SetWindowCollapsedAllowFlags & ~flags);
}

ImGuiWindow* ImGui::FindWindowByID(ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    return (ImGuiWindow*)g.WindowsById.GetVoidPtr(id);
}

ImGuiWindow* ImGui::FindWindowByName(const char* name)
{
    ImGuiID id = ImHashStr(name, 0);
    return FindWindowByID(id);
}

static ImGuiWindow* CreateNewWindow(const char* name, ImVec2 size, ImGuiWindowFlags flags)
{
    ImGuiContext& g = *GImGui;

    // Create window the first time
    ImGuiWindow* window = IM_NEW(ImGuiWindow)(&g, name);
    window->Flags = flags;
    g.WindowsById.SetVoidPtr(window->ID, window);

    // Default/arbitrary window position. Use SetNextWindowPos() with the appropriate condition flag to change the initial position of a window.
    window->Pos = ImVec2(60, 60);

    // User can disable loading and saving of settings. Tooltip and child windows also don't store settings.
    if (!(flags & ImGuiWindowFlags_NoSavedSettings))
        if (ImGuiWindowSettings* settings = ImGui::FindWindowSettings(window->ID))
        {
            // Retrieve settings from .ini file
            window->SettingsIdx = g.SettingsWindows.index_from_ptr(settings);
            SetWindowConditionAllowFlags(window, ImGuiCond_FirstUseEver, false);
            window->Pos = ImFloor(settings->Pos);
            window->Collapsed = settings->Collapsed;
            if (ImLengthSqr(settings->Size) > 0.00001f)
                size = ImFloor(settings->Size);
        }
    window->Size = window->SizeFull = window->SizeFullAtLastBegin = ImFloor(size);
    window->DC.CursorMaxPos = window->Pos; // So first call to CalcSizeContents() doesn't return crazy values

    if ((flags & ImGuiWindowFlags_AlwaysAutoResize) != 0)
    {
        window->AutoFitFramesX = window->AutoFitFramesY = 2;
        window->AutoFitOnlyGrows = false;
    }
    else
    {
        if (window->Size.x <= 0.0f)
            window->AutoFitFramesX = 2;
        if (window->Size.y <= 0.0f)
            window->AutoFitFramesY = 2;
        window->AutoFitOnlyGrows = (window->AutoFitFramesX > 0) || (window->AutoFitFramesY > 0);
    }

    g.WindowsFocusOrder.push_back(window);
    if (flags & ImGuiWindowFlags_NoBringToFrontOnFocus)
        g.Windows.push_front(window); // Quite slow but rare and only once
    else
        g.Windows.push_back(window);
    return window;
}

static ImVec2 CalcSizeAfterConstraint(ImGuiWindow* window, ImVec2 new_size)
{
    ImGuiContext& g = *GImGui;
    if (g.NextWindowData.SizeConstraintCond != 0)
    {
        // Using -1,-1 on either X/Y axis to preserve the current size.
        ImRect cr = g.NextWindowData.SizeConstraintRect;
        new_size.x = (cr.Min.x >= 0 && cr.Max.x >= 0) ? ImClamp(new_size.x, cr.Min.x, cr.Max.x) : window->SizeFull.x;
        new_size.y = (cr.Min.y >= 0 && cr.Max.y >= 0) ? ImClamp(new_size.y, cr.Min.y, cr.Max.y) : window->SizeFull.y;
        if (g.NextWindowData.SizeCallback)
        {
            ImGuiSizeCallbackData data;
            data.UserData = g.NextWindowData.SizeCallbackUserData;
            data.Pos = window->Pos;
            data.CurrentSize = window->SizeFull;
            data.DesiredSize = new_size;
            g.NextWindowData.SizeCallback(&data);
            new_size = data.DesiredSize;
        }
    }

    // Minimum size
    if (!(window->Flags & (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_AlwaysAutoResize)))
    {
        new_size = ImMax(new_size, g.Style.WindowMinSize);
        new_size.y = ImMax(new_size.y, window->TitleBarHeight() + window->MenuBarHeight() + ImMax(0.0f, g.Style.WindowRounding - 1.0f)); // Reduce artifacts with very small windows
    }
    return new_size;
}

static ImVec2 CalcSizeContents(ImGuiWindow* window)
{
    if (window->Collapsed)
        if (window->AutoFitFramesX <= 0 && window->AutoFitFramesY <= 0)
            return window->SizeContents;
    if (window->Hidden && window->HiddenFramesForResize == 0 && window->HiddenFramesRegular > 0)
        return window->SizeContents;

    ImVec2 sz;
    sz.x = (float)(int)((window->SizeContentsExplicit.x != 0.0f) ? window->SizeContentsExplicit.x : (window->DC.CursorMaxPos.x - window->Pos.x + window->Scroll.x));
    sz.y = (float)(int)((window->SizeContentsExplicit.y != 0.0f) ? window->SizeContentsExplicit.y : (window->DC.CursorMaxPos.y - window->Pos.y + window->Scroll.y));
    return sz + window->WindowPadding;
}

static ImVec2 CalcSizeAutoFit(ImGuiWindow* window, const ImVec2& size_contents)
{
    ImGuiContext& g = *GImGui;
    ImGuiStyle& style = g.Style;
    if (window->Flags & ImGuiWindowFlags_Tooltip)
    {
        // Tooltip always resize
        return size_contents;
    }
    else
    {
        // Maximum window size is determined by the display size
        const bool is_popup = (window->Flags & ImGuiWindowFlags_Popup) != 0;
        const bool is_menu = (window->Flags & ImGuiWindowFlags_ChildMenu) != 0;
        ImVec2 size_min = style.WindowMinSize;
        if (is_popup || is_menu) // Popups and menus bypass style.WindowMinSize by default, but we give then a non-zero minimum size to facilitate understanding problematic cases (e.g. empty popups)
            size_min = ImMin(size_min, ImVec2(4.0f, 4.0f));
        ImVec2 size_auto_fit = ImClamp(size_contents, size_min, ImMax(size_min, g.IO.DisplaySize - style.DisplaySafeAreaPadding * 2.0f));

        // When the window cannot fit all contents (either because of constraints, either because screen is too small),
        // we are growing the size on the other axis to compensate for expected scrollbar. FIXME: Might turn bigger than ViewportSize-WindowPadding.
        ImVec2 size_auto_fit_after_constraint = CalcSizeAfterConstraint(window, size_auto_fit);
        if (size_auto_fit_after_constraint.x < size_contents.x && !(window->Flags & ImGuiWindowFlags_NoScrollbar) && (window->Flags & ImGuiWindowFlags_HorizontalScrollbar))
            size_auto_fit.y += style.ScrollbarSize;
        if (size_auto_fit_after_constraint.y < size_contents.y && !(window->Flags & ImGuiWindowFlags_NoScrollbar))
            size_auto_fit.x += style.ScrollbarSize;
        return size_auto_fit;
    }
}

ImVec2 ImGui::CalcWindowExpectedSize(ImGuiWindow* window)
{
    ImVec2 size_contents = CalcSizeContents(window);
    return CalcSizeAfterConstraint(window, CalcSizeAutoFit(window, size_contents));
}

float ImGui::GetWindowScrollMaxX(ImGuiWindow* window)
{
    return ImMax(0.0f, window->SizeContents.x - (window->SizeFull.x - window->ScrollbarSizes.x));
}

float ImGui::GetWindowScrollMaxY(ImGuiWindow* window)
{
    return ImMax(0.0f, window->SizeContents.y - (window->SizeFull.y - window->ScrollbarSizes.y));
}

static ImVec2 CalcNextScrollFromScrollTargetAndClamp(ImGuiWindow* window, bool snap_on_edges)
{
    ImGuiContext& g = *GImGui;
    ImVec2 scroll = window->Scroll;
    if (window->ScrollTarget.x < FLT_MAX)
    {
        float cr_x = window->ScrollTargetCenterRatio.x;
        scroll.x = window->ScrollTarget.x - cr_x * (window->SizeFull.x - window->ScrollbarSizes.x);
    }
    if (window->ScrollTarget.y < FLT_MAX)
    {
        // 'snap_on_edges' allows for a discontinuity at the edge of scrolling limits to take account of WindowPadding so that scrolling to make the last item visible scroll far enough to see the padding.
        float cr_y = window->ScrollTargetCenterRatio.y;
        float target_y = window->ScrollTarget.y;
        if (snap_on_edges && cr_y <= 0.0f && target_y <= window->WindowPadding.y)
            target_y = 0.0f;
        if (snap_on_edges && cr_y >= 1.0f && target_y >= window->SizeContents.y - window->WindowPadding.y + g.Style.ItemSpacing.y)
            target_y = window->SizeContents.y;
        scroll.y = target_y - (1.0f - cr_y) * (window->TitleBarHeight() + window->MenuBarHeight()) - cr_y * (window->SizeFull.y - window->ScrollbarSizes.y);
    }
    scroll = ImMax(scroll, ImVec2(0.0f, 0.0f));
    if (!window->Collapsed && !window->SkipItems)
    {
        scroll.x = ImMin(scroll.x, ImGui::GetWindowScrollMaxX(window));
        scroll.y = ImMin(scroll.y, ImGui::GetWindowScrollMaxY(window));
    }
    return scroll;
}

static ImGuiCol GetWindowBgColorIdxFromFlags(ImGuiWindowFlags flags)
{
    if (flags & (ImGuiWindowFlags_Tooltip | ImGuiWindowFlags_Popup))
        return ImGuiCol_PopupBg;
    if (flags & ImGuiWindowFlags_ChildWindow)
        return ImGuiCol_ChildBg;
    return ImGuiCol_WindowBg;
}

static void CalcResizePosSizeFromAnyCorner(ImGuiWindow* window, const ImVec2& corner_target, const ImVec2& corner_norm, ImVec2* out_pos, ImVec2* out_size)
{
    ImVec2 pos_min = ImLerp(corner_target, window->Pos, corner_norm);                // Expected window upper-left
    ImVec2 pos_max = ImLerp(window->Pos + window->Size, corner_target, corner_norm); // Expected window lower-right
    ImVec2 size_expected = pos_max - pos_min;
    ImVec2 size_constrained = CalcSizeAfterConstraint(window, size_expected);
    *out_pos = pos_min;
    if (corner_norm.x == 0.0f)
        out_pos->x -= (size_constrained.x - size_expected.x);
    if (corner_norm.y == 0.0f)
        out_pos->y -= (size_constrained.y - size_expected.y);
    *out_size = size_constrained;
}

struct ImGuiResizeGripDef
{
    ImVec2  CornerPosN;
    ImVec2  InnerDir;
    int     AngleMin12, AngleMax12;
};

static const ImGuiResizeGripDef resize_grip_def[4] =
{
    { ImVec2(1,1), ImVec2(-1,-1), 0, 3 }, // Lower right
    { ImVec2(0,1), ImVec2(+1,-1), 3, 6 }, // Lower left
    { ImVec2(0,0), ImVec2(+1,+1), 6, 9 }, // Upper left
    { ImVec2(1,0), ImVec2(-1,+1), 9,12 }, // Upper right
};

static ImRect GetResizeBorderRect(ImGuiWindow* window, int border_n, float perp_padding, float thickness)
{
    ImRect rect = window->Rect();
    if (thickness == 0.0f) rect.Max -= ImVec2(1,1);
    if (border_n == 0) return ImRect(rect.Min.x + perp_padding, rect.Min.y - thickness,    rect.Max.x - perp_padding, rect.Min.y + thickness);      // Top
    if (border_n == 1) return ImRect(rect.Max.x - thickness,    rect.Min.y + perp_padding, rect.Max.x + thickness,    rect.Max.y - perp_padding);   // Right
    if (border_n == 2) return ImRect(rect.Min.x + perp_padding, rect.Max.y - thickness,    rect.Max.x - perp_padding, rect.Max.y + thickness);      // Bottom
    if (border_n == 3) return ImRect(rect.Min.x - thickness,    rect.Min.y + perp_padding, rect.Min.x + thickness,    rect.Max.y - perp_padding);   // Left
    IM_ASSERT(0);
    return ImRect();
}

// Handle resize for: Resize Grips, Borders, Gamepad
static void ImGui::UpdateManualResize(ImGuiWindow* window, const ImVec2& size_auto_fit, int* border_held, int resize_grip_count, ImU32 resize_grip_col[4])
{
    ImGuiContext& g = *GImGui;
    ImGuiWindowFlags flags = window->Flags;
    if ((flags & ImGuiWindowFlags_NoResize) || (flags & ImGuiWindowFlags_AlwaysAutoResize) || window->AutoFitFramesX > 0 || window->AutoFitFramesY > 0)
        return;
    if (window->WasActive == false) // Early out to avoid running this code for e.g. an hidden implicit/fallback Debug window.
        return;

    const int resize_border_count = g.IO.ConfigWindowsResizeFromEdges ? 4 : 0;
    const float grip_draw_size = (float)(int)ImMax(g.FontSize * 1.35f, window->WindowRounding + 1.0f + g.FontSize * 0.2f);
    const float grip_hover_inner_size = (float)(int)(grip_draw_size * 0.75f);
    const float grip_hover_outer_size = g.IO.ConfigWindowsResizeFromEdges ? WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS : 0.0f;

    ImVec2 pos_target(FLT_MAX, FLT_MAX);
    ImVec2 size_target(FLT_MAX, FLT_MAX);

    // Manual resize grips
    PushID("#RESIZE");
    for (int resize_grip_n = 0; resize_grip_n < resize_grip_count; resize_grip_n++)
    {
        const ImGuiResizeGripDef& grip = resize_grip_def[resize_grip_n];
        const ImVec2 corner = ImLerp(window->Pos, window->Pos + window->Size, grip.CornerPosN);

        // Using the FlattenChilds button flag we make the resize button accessible even if we are hovering over a child window
        ImRect resize_rect(corner - grip.InnerDir * grip_hover_outer_size, corner + grip.InnerDir * grip_hover_inner_size);
        if (resize_rect.Min.x > resize_rect.Max.x) ImSwap(resize_rect.Min.x, resize_rect.Max.x);
        if (resize_rect.Min.y > resize_rect.Max.y) ImSwap(resize_rect.Min.y, resize_rect.Max.y);
        bool hovered, held;
        ButtonBehavior(resize_rect, window->GetID((void*)(intptr_t)resize_grip_n), &hovered, &held, ImGuiButtonFlags_FlattenChildren | ImGuiButtonFlags_NoNavFocus);
        //GetOverlayDrawList(window)->AddRect(resize_rect.Min, resize_rect.Max, IM_COL32(255, 255, 0, 255));
        if (hovered || held)
            g.MouseCursor = (resize_grip_n & 1) ? ImGuiMouseCursor_ResizeNESW : ImGuiMouseCursor_ResizeNWSE;

        if (held && g.IO.MouseDoubleClicked[0] && resize_grip_n == 0)
        {
            // Manual auto-fit when double-clicking
            size_target = CalcSizeAfterConstraint(window, size_auto_fit);
            ClearActiveID();
        }
        else if (held)
        {
            // Resize from any of the four corners
            // We don't use an incremental MouseDelta but rather compute an absolute target size based on mouse position
            ImVec2 corner_target = g.IO.MousePos - g.ActiveIdClickOffset + ImLerp(grip.InnerDir * grip_hover_outer_size, grip.InnerDir * -grip_hover_inner_size, grip.CornerPosN); // Corner of the window corresponding to our corner grip
            CalcResizePosSizeFromAnyCorner(window, corner_target, grip.CornerPosN, &pos_target, &size_target);
        }
        if (resize_grip_n == 0 || held || hovered)
            resize_grip_col[resize_grip_n] = GetColorU32(held ? ImGuiCol_ResizeGripActive : hovered ? ImGuiCol_ResizeGripHovered : ImGuiCol_ResizeGrip);
    }
    for (int border_n = 0; border_n < resize_border_count; border_n++)
    {
        bool hovered, held;
        ImRect border_rect = GetResizeBorderRect(window, border_n, grip_hover_inner_size, WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS);
        ButtonBehavior(border_rect, window->GetID((void*)(intptr_t)(border_n + 4)), &hovered, &held, ImGuiButtonFlags_FlattenChildren);
        //GetOverlayDrawList(window)->AddRect(border_rect.Min, border_rect.Max, IM_COL32(255, 255, 0, 255));
        if ((hovered && g.HoveredIdTimer > WINDOWS_RESIZE_FROM_EDGES_FEEDBACK_TIMER) || held)
        {
            g.MouseCursor = (border_n & 1) ? ImGuiMouseCursor_ResizeEW : ImGuiMouseCursor_ResizeNS;
            if (held) 
                *border_held = border_n;
        }
        if (held)
        {
            ImVec2 border_target = window->Pos;
            ImVec2 border_posn;
            if (border_n == 0) { border_posn = ImVec2(0, 0); border_target.y = (g.IO.MousePos.y - g.ActiveIdClickOffset.y + WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS); } // Top
            if (border_n == 1) { border_posn = ImVec2(1, 0); border_target.x = (g.IO.MousePos.x - g.ActiveIdClickOffset.x + WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS); } // Right
            if (border_n == 2) { border_posn = ImVec2(0, 1); border_target.y = (g.IO.MousePos.y - g.ActiveIdClickOffset.y + WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS); } // Bottom
            if (border_n == 3) { border_posn = ImVec2(0, 0); border_target.x = (g.IO.MousePos.x - g.ActiveIdClickOffset.x + WINDOWS_RESIZE_FROM_EDGES_HALF_THICKNESS); } // Left
            CalcResizePosSizeFromAnyCorner(window, border_target, border_posn, &pos_target, &size_target);
        }
    }
    PopID();

    // Navigation resize (keyboard/gamepad)
    if (g.NavWindowingTarget && g.NavWindowingTarget->RootWindow == window)
    {
        ImVec2 nav_resize_delta;
        if (g.NavInputSource == ImGuiInputSource_NavKeyboard && g.IO.KeyShift)
            nav_resize_delta = GetNavInputAmount2d(ImGuiNavDirSourceFlags_Keyboard, ImGuiInputReadMode_Down);
        if (g.NavInputSource == ImGuiInputSource_NavGamepad)
            nav_resize_delta = GetNavInputAmount2d(ImGuiNavDirSourceFlags_PadDPad, ImGuiInputReadMode_Down);
        if (nav_resize_delta.x != 0.0f || nav_resize_delta.y != 0.0f)
        {
            const float NAV_RESIZE_SPEED = 600.0f;
            nav_resize_delta *= ImFloor(NAV_RESIZE_SPEED * g.IO.DeltaTime * ImMin(g.IO.DisplayFramebufferScale.x, g.IO.DisplayFramebufferScale.y));
            g.NavWindowingToggleLayer = false;
            g.NavDisableMouseHover = true;
            resize_grip_col[0] = GetColorU32(ImGuiCol_ResizeGripActive);
            // FIXME-NAV: Should store and accumulate into a separate size buffer to handle sizing constraints properly, right now a constraint will make us stuck.
            size_target = CalcSizeAfterConstraint(window, window->SizeFull + nav_resize_delta);
        }
    }

    // Apply back modified position/size to window
    if (size_target.x != FLT_MAX)
    {
        window->SizeFull = size_target;
        MarkIniSettingsDirty(window);
    }
    if (pos_target.x != FLT_MAX)
    {
        window->Pos = ImFloor(pos_target);
        MarkIniSettingsDirty(window);
    }

    window->Size = window->SizeFull;
}

static void ImGui::RenderOuterBorders(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    float rounding = window->WindowRounding;
    float border_size = window->WindowBorderSize;
    if (border_size > 0.0f && !(window->Flags & ImGuiWindowFlags_NoBackground))
        window->DrawList->AddRect(window->Pos, window->Pos + window->Size, GetColorU32(ImGuiCol_Border), rounding, ImDrawCornerFlags_All, border_size);

    int border_held = window->ResizeBorderHeld;
    if (border_held != -1)
    {
        struct ImGuiResizeBorderDef
        {
            ImVec2 InnerDir;
            ImVec2 CornerPosN1, CornerPosN2;
            float  OuterAngle;
        };
        static const ImGuiResizeBorderDef resize_border_def[4] =
        {
            { ImVec2(0,+1), ImVec2(0,0), ImVec2(1,0), IM_PI*1.50f }, // Top
            { ImVec2(-1,0), ImVec2(1,0), ImVec2(1,1), IM_PI*0.00f }, // Right
            { ImVec2(0,-1), ImVec2(1,1), ImVec2(0,1), IM_PI*0.50f }, // Bottom
            { ImVec2(+1,0), ImVec2(0,1), ImVec2(0,0), IM_PI*1.00f }  // Left
        };
        const ImGuiResizeBorderDef& def = resize_border_def[border_held];
        ImRect border_r = GetResizeBorderRect(window, border_held, rounding, 0.0f);
        window->DrawList->PathArcTo(ImLerp(border_r.Min, border_r.Max, def.CornerPosN1) + ImVec2(0.5f, 0.5f) + def.InnerDir * rounding, rounding, def.OuterAngle - IM_PI*0.25f, def.OuterAngle);
        window->DrawList->PathArcTo(ImLerp(border_r.Min, border_r.Max, def.CornerPosN2) + ImVec2(0.5f, 0.5f) + def.InnerDir * rounding, rounding, def.OuterAngle, def.OuterAngle + IM_PI*0.25f);
        window->DrawList->PathStroke(GetColorU32(ImGuiCol_SeparatorActive), false, ImMax(2.0f, border_size)); // Thicker than usual
    }
    if (g.Style.FrameBorderSize > 0 && !(window->Flags & ImGuiWindowFlags_NoTitleBar))
    {
        float y = window->Pos.y + window->TitleBarHeight() - 1;
        window->DrawList->AddLine(ImVec2(window->Pos.x + border_size, y), ImVec2(window->Pos.x + window->Size.x - border_size, y), GetColorU32(ImGuiCol_Border), g.Style.FrameBorderSize);
    }
}

void ImGui::UpdateWindowParentAndRootLinks(ImGuiWindow* window, ImGuiWindowFlags flags, ImGuiWindow* parent_window)
{
    window->ParentWindow = parent_window;
    window->RootWindow = window->RootWindowForTitleBarHighlight = window->RootWindowForNav = window;
    if (parent_window && (flags & ImGuiWindowFlags_ChildWindow) && !(flags & ImGuiWindowFlags_Tooltip))
        window->RootWindow = parent_window->RootWindow;
    if (parent_window && !(flags & ImGuiWindowFlags_Modal) && (flags & (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_Popup)))
        window->RootWindowForTitleBarHighlight = parent_window->RootWindowForTitleBarHighlight;
    while (window->RootWindowForNav->Flags & ImGuiWindowFlags_NavFlattened)
    {
        IM_ASSERT(window->RootWindowForNav->ParentWindow != NULL);
        window->RootWindowForNav = window->RootWindowForNav->ParentWindow;
    }
}

// Push a new ImGui window to add widgets to.
// - A default window called "Debug" is automatically stacked at the beginning of every frame so you can use widgets without explicitly calling a Begin/End pair.
// - Begin/End can be called multiple times during the frame with the same window name to append content.
// - The window name is used as a unique identifier to preserve window information across frames (and save rudimentary information to the .ini file).
//   You can use the "##" or "###" markers to use the same label with different id, or same id with different label. See documentation at the top of this file.
// - Return false when window is collapsed, so you can early out in your code. You always need to call ImGui::End() even if false is returned.
// - Passing 'bool* p_open' displays a Close button on the upper-right corner of the window, the pointed value will be set to false when the button is pressed.
bool ImGui::Begin(const char* name, bool* p_open, ImGuiWindowFlags flags)
{
    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    IM_ASSERT(name != NULL && name[0] != '\0');     // Window name required
    IM_ASSERT(g.FrameScopeActive);                  // Forgot to call ImGui::NewFrame()
    IM_ASSERT(g.FrameCountEnded != g.FrameCount);   // Called ImGui::Render() or ImGui::EndFrame() and haven't called ImGui::NewFrame() again yet

    // Find or create
    ImGuiWindow* window = FindWindowByName(name);
    const bool window_just_created = (window == NULL);
    if (window_just_created)
    {
        ImVec2 size_on_first_use = (g.NextWindowData.SizeCond != 0) ? g.NextWindowData.SizeVal : ImVec2(0.0f, 0.0f); // Any condition flag will do since we are creating a new window here.
        window = CreateNewWindow(name, size_on_first_use, flags);
    }

    // Automatically disable manual moving/resizing when NoInputs is set
    if ((flags & ImGuiWindowFlags_NoInputs) == ImGuiWindowFlags_NoInputs)
        flags |= ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize;

    if (flags & ImGuiWindowFlags_NavFlattened)
        IM_ASSERT(flags & ImGuiWindowFlags_ChildWindow);

    const int current_frame = g.FrameCount;
    const bool first_begin_of_the_frame = (window->LastFrameActive != current_frame);

    // Update Flags, LastFrameActive, BeginOrderXXX fields
    if (first_begin_of_the_frame)
        window->Flags = (ImGuiWindowFlags)flags;
    else
        flags = window->Flags;

    // Parent window is latched only on the first call to Begin() of the frame, so further append-calls can be done from a different window stack
    ImGuiWindow* parent_window_in_stack = g.CurrentWindowStack.empty() ? NULL : g.CurrentWindowStack.back();
    ImGuiWindow* parent_window = first_begin_of_the_frame ? ((flags & (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_Popup)) ? parent_window_in_stack : NULL) : window->ParentWindow;
    IM_ASSERT(parent_window != NULL || !(flags & ImGuiWindowFlags_ChildWindow));
    window->HasCloseButton = (p_open != NULL);

    // Update the Appearing flag
    bool window_just_activated_by_user = (window->LastFrameActive < current_frame - 1);   // Not using !WasActive because the implicit "Debug" window would always toggle off->on
    const bool window_just_appearing_after_hidden_for_resize = (window->HiddenFramesForResize > 0);
    if (flags & ImGuiWindowFlags_Popup)
    {
        ImGuiPopupRef& popup_ref = g.OpenPopupStack[g.BeginPopupStack.Size];
        window_just_activated_by_user |= (window->PopupId != popup_ref.PopupId); // We recycle popups so treat window as activated if popup id changed
        window_just_activated_by_user |= (window != popup_ref.Window);
    }
    window->Appearing = (window_just_activated_by_user || window_just_appearing_after_hidden_for_resize);
    if (window->Appearing)
        SetWindowConditionAllowFlags(window, ImGuiCond_Appearing, true);

    // Add to stack
    g.CurrentWindowStack.push_back(window);
    SetCurrentWindow(window);
    CheckStacksSize(window, true);
    if (flags & ImGuiWindowFlags_Popup)
    {
        ImGuiPopupRef& popup_ref = g.OpenPopupStack[g.BeginPopupStack.Size];
        popup_ref.Window = window;
        g.BeginPopupStack.push_back(popup_ref);
        window->PopupId = popup_ref.PopupId;
    }

    if (window_just_appearing_after_hidden_for_resize && !(flags & ImGuiWindowFlags_ChildWindow))
        window->NavLastIds[0] = 0;

    // Process SetNextWindow***() calls
    bool window_pos_set_by_api = false;
    bool window_size_x_set_by_api = false, window_size_y_set_by_api = false;
    if (g.NextWindowData.PosCond)
    {
        window_pos_set_by_api = (window->SetWindowPosAllowFlags & g.NextWindowData.PosCond) != 0;
        if (window_pos_set_by_api && ImLengthSqr(g.NextWindowData.PosPivotVal) > 0.00001f)
        {
            // May be processed on the next frame if this is our first frame and we are measuring size
            // FIXME: Look into removing the branch so everything can go through this same code path for consistency.
            window->SetWindowPosVal = g.NextWindowData.PosVal;
            window->SetWindowPosPivot = g.NextWindowData.PosPivotVal;
            window->SetWindowPosAllowFlags &= ~(ImGuiCond_Once | ImGuiCond_FirstUseEver | ImGuiCond_Appearing);
        }
        else
        {
            SetWindowPos(window, g.NextWindowData.PosVal, g.NextWindowData.PosCond);
        }
    }
    if (g.NextWindowData.SizeCond)
    {
        window_size_x_set_by_api = (window->SetWindowSizeAllowFlags & g.NextWindowData.SizeCond) != 0 && (g.NextWindowData.SizeVal.x > 0.0f);
        window_size_y_set_by_api = (window->SetWindowSizeAllowFlags & g.NextWindowData.SizeCond) != 0 && (g.NextWindowData.SizeVal.y > 0.0f);
        SetWindowSize(window, g.NextWindowData.SizeVal, g.NextWindowData.SizeCond);
    }
    if (g.NextWindowData.ContentSizeCond)
    {
        // Adjust passed "client size" to become a "window size"
        window->SizeContentsExplicit = g.NextWindowData.ContentSizeVal;
        if (window->SizeContentsExplicit.y != 0.0f)
            window->SizeContentsExplicit.y += window->TitleBarHeight() + window->MenuBarHeight();
    }
    else if (first_begin_of_the_frame)
    {
        window->SizeContentsExplicit = ImVec2(0.0f, 0.0f);
    }
    if (g.NextWindowData.CollapsedCond)
        SetWindowCollapsed(window, g.NextWindowData.CollapsedVal, g.NextWindowData.CollapsedCond);
    if (g.NextWindowData.FocusCond)
        FocusWindow(window);
    if (window->Appearing)
        SetWindowConditionAllowFlags(window, ImGuiCond_Appearing, false);

    // When reusing window again multiple times a frame, just append content (don't need to setup again)
    if (first_begin_of_the_frame)
    {
        // Initialize
        const bool window_is_child_tooltip = (flags & ImGuiWindowFlags_ChildWindow) && (flags & ImGuiWindowFlags_Tooltip); // FIXME-WIP: Undocumented behavior of Child+Tooltip for pinned tooltip (#1345)
        UpdateWindowParentAndRootLinks(window, flags, parent_window);

        window->Active = true;
        window->BeginOrderWithinParent = 0;
        window->BeginOrderWithinContext = (short)(g.WindowsActiveCount++);
        window->BeginCount = 0;
        window->ClipRect = ImVec4(-FLT_MAX,-FLT_MAX,+FLT_MAX,+FLT_MAX);
        window->LastFrameActive = current_frame;
        window->IDStack.resize(1);

        // Update stored window name when it changes (which can _only_ happen with the "###" operator, so the ID would stay unchanged).
        // The title bar always display the 'name' parameter, so we only update the string storage if it needs to be visible to the end-user elsewhere.
        bool window_title_visible_elsewhere = false;
        if (g.NavWindowingList != NULL && (window->Flags & ImGuiWindowFlags_NoNavFocus) == 0)   // Window titles visible when using CTRL+TAB
            window_title_visible_elsewhere = true;
        if (window_title_visible_elsewhere && !window_just_created && strcmp(name, window->Name) != 0)
        {
            size_t buf_len = (size_t)window->NameBufLen;
            window->Name = ImStrdupcpy(window->Name, &buf_len, name);
            window->NameBufLen = (int)buf_len;
        }

        // UPDATE CONTENTS SIZE, UPDATE HIDDEN STATUS

        // Update contents size from last frame for auto-fitting (or use explicit size)
        window->SizeContents = CalcSizeContents(window);
        if (window->HiddenFramesRegular > 0)
            window->HiddenFramesRegular--;
        if (window->HiddenFramesForResize > 0)
            window->HiddenFramesForResize--;

        // Hide new windows for one frame until they calculate their size
        if (window_just_created && (!window_size_x_set_by_api || !window_size_y_set_by_api))
            window->HiddenFramesForResize = 1;

        // Hide popup/tooltip window when re-opening while we measure size (because we recycle the windows)
        // We reset Size/SizeContents for reappearing popups/tooltips early in this function, so further code won't be tempted to use the old size.
        if (window_just_activated_by_user && (flags & (ImGuiWindowFlags_Popup | ImGuiWindowFlags_Tooltip)) != 0)
        {
            window->HiddenFramesForResize = 1;
            if (flags & ImGuiWindowFlags_AlwaysAutoResize)
            {
                if (!window_size_x_set_by_api)
                    window->Size.x = window->SizeFull.x = 0.f;
                if (!window_size_y_set_by_api)
                    window->Size.y = window->SizeFull.y = 0.f;
                window->SizeContents = ImVec2(0.f, 0.f);
            }
        }

        SetCurrentWindow(window);

        // Lock border size and padding for the frame (so that altering them doesn't cause inconsistencies)
        window->WindowBorderSize = (flags & ImGuiWindowFlags_ChildWindow) ? style.ChildBorderSize : ((flags & (ImGuiWindowFlags_Popup | ImGuiWindowFlags_Tooltip)) && !(flags & ImGuiWindowFlags_Modal)) ? style.PopupBorderSize : style.WindowBorderSize;
        window->WindowPadding = style.WindowPadding;
        if ((flags & ImGuiWindowFlags_ChildWindow) && !(flags & (ImGuiWindowFlags_AlwaysUseWindowPadding | ImGuiWindowFlags_Popup)) && window->WindowBorderSize == 0.0f)
            window->WindowPadding = ImVec2(0.0f, (flags & ImGuiWindowFlags_MenuBar) ? style.WindowPadding.y : 0.0f);
        window->DC.MenuBarOffset.x = ImMax(ImMax(window->WindowPadding.x, style.ItemSpacing.x), g.NextWindowData.MenuBarOffsetMinVal.x);
        window->DC.MenuBarOffset.y = g.NextWindowData.MenuBarOffsetMinVal.y;

        // Collapse window by double-clicking on title bar
        // At this point we don't have a clipping rectangle setup yet, so we can use the title bar area for hit detection and drawing
        if (!(flags & ImGuiWindowFlags_NoTitleBar) && !(flags & ImGuiWindowFlags_NoCollapse))
        {
            // We don't use a regular button+id to test for double-click on title bar (mostly due to legacy reason, could be fixed), so verify that we don't have items over the title bar.
            ImRect title_bar_rect = window->TitleBarRect();
            if (g.HoveredWindow == window && g.HoveredId == 0 && g.HoveredIdPreviousFrame == 0 && IsMouseHoveringRect(title_bar_rect.Min, title_bar_rect.Max) && g.IO.MouseDoubleClicked[0])
                window->WantCollapseToggle = true;
            if (window->WantCollapseToggle)
            {
                window->Collapsed = !window->Collapsed;
                MarkIniSettingsDirty(window);
                FocusWindow(window);
            }
        }
        else
        {
            window->Collapsed = false;
        }
        window->WantCollapseToggle = false;

        // SIZE

        // Calculate auto-fit size, handle automatic resize
        const ImVec2 size_auto_fit = CalcSizeAutoFit(window, window->SizeContents);
        ImVec2 size_full_modified(FLT_MAX, FLT_MAX);
        if ((flags & ImGuiWindowFlags_AlwaysAutoResize) && !window->Collapsed)
        {
            // Using SetNextWindowSize() overrides ImGuiWindowFlags_AlwaysAutoResize, so it can be used on tooltips/popups, etc.
            if (!window_size_x_set_by_api)
                window->SizeFull.x = size_full_modified.x = size_auto_fit.x;
            if (!window_size_y_set_by_api)
                window->SizeFull.y = size_full_modified.y = size_auto_fit.y;
        }
        else if (window->AutoFitFramesX > 0 || window->AutoFitFramesY > 0)
        {
            // Auto-fit may only grow window during the first few frames
            // We still process initial auto-fit on collapsed windows to get a window width, but otherwise don't honor ImGuiWindowFlags_AlwaysAutoResize when collapsed.
            if (!window_size_x_set_by_api && window->AutoFitFramesX > 0)
                window->SizeFull.x = size_full_modified.x = window->AutoFitOnlyGrows ? ImMax(window->SizeFull.x, size_auto_fit.x) : size_auto_fit.x;
            if (!window_size_y_set_by_api && window->AutoFitFramesY > 0)
                window->SizeFull.y = size_full_modified.y = window->AutoFitOnlyGrows ? ImMax(window->SizeFull.y, size_auto_fit.y) : size_auto_fit.y;
            if (!window->Collapsed)
                MarkIniSettingsDirty(window);
        }

        // Apply minimum/maximum window size constraints and final size
        window->SizeFull = CalcSizeAfterConstraint(window, window->SizeFull);
        window->Size = window->Collapsed && !(flags & ImGuiWindowFlags_ChildWindow) ? window->TitleBarRect().GetSize() : window->SizeFull;

        // SCROLLBAR STATUS

        // Update scrollbar status (based on the Size that was effective during last frame or the auto-resized Size).
        if (!window->Collapsed)
        {
            // When reading the current size we need to read it after size constraints have been applied
            float size_x_for_scrollbars = size_full_modified.x != FLT_MAX ? window->SizeFull.x : window->SizeFullAtLastBegin.x;
            float size_y_for_scrollbars = size_full_modified.y != FLT_MAX ? window->SizeFull.y : window->SizeFullAtLastBegin.y;
            window->ScrollbarY = (flags & ImGuiWindowFlags_AlwaysVerticalScrollbar) || ((window->SizeContents.y > size_y_for_scrollbars) && !(flags & ImGuiWindowFlags_NoScrollbar));
            window->ScrollbarX = (flags & ImGuiWindowFlags_AlwaysHorizontalScrollbar) || ((window->SizeContents.x > size_x_for_scrollbars - (window->ScrollbarY ? style.ScrollbarSize : 0.0f)) && !(flags & ImGuiWindowFlags_NoScrollbar) && (flags & ImGuiWindowFlags_HorizontalScrollbar));
            if (window->ScrollbarX && !window->ScrollbarY)
                window->ScrollbarY = (window->SizeContents.y > size_y_for_scrollbars - style.ScrollbarSize) && !(flags & ImGuiWindowFlags_NoScrollbar);
            window->ScrollbarSizes = ImVec2(window->ScrollbarY ? style.ScrollbarSize : 0.0f, window->ScrollbarX ? style.ScrollbarSize : 0.0f);
        }

        // POSITION

        // Popup latch its initial position, will position itself when it appears next frame
        if (window_just_activated_by_user)
        {
            window->AutoPosLastDirection = ImGuiDir_None;
            if ((flags & ImGuiWindowFlags_Popup) != 0 && !window_pos_set_by_api)
                window->Pos = g.BeginPopupStack.back().OpenPopupPos;
        }

        // Position child window
        if (flags & ImGuiWindowFlags_ChildWindow)
        {
            IM_ASSERT(parent_window && parent_window->Active);
            window->BeginOrderWithinParent = (short)parent_window->DC.ChildWindows.Size;
            parent_window->DC.ChildWindows.push_back(window);
            if (!(flags & ImGuiWindowFlags_Popup) && !window_pos_set_by_api && !window_is_child_tooltip)
                window->Pos = parent_window->DC.CursorPos;
        }

        const bool window_pos_with_pivot = (window->SetWindowPosVal.x != FLT_MAX && window->HiddenFramesForResize == 0);
        if (window_pos_with_pivot)
            SetWindowPos(window, ImMax(style.DisplaySafeAreaPadding, window->SetWindowPosVal - window->SizeFull * window->SetWindowPosPivot), 0); // Position given a pivot (e.g. for centering)
        else if ((flags & ImGuiWindowFlags_ChildMenu) != 0)
            window->Pos = FindBestWindowPosForPopup(window);
        else if ((flags & ImGuiWindowFlags_Popup) != 0 && !window_pos_set_by_api && window_just_appearing_after_hidden_for_resize)
            window->Pos = FindBestWindowPosForPopup(window);
        else if ((flags & ImGuiWindowFlags_Tooltip) != 0 && !window_pos_set_by_api && !window_is_child_tooltip)
            window->Pos = FindBestWindowPosForPopup(window);

        // Clamp position so it stays visible
        // Ignore zero-sized display explicitly to avoid losing positions if a window manager reports zero-sized window when initializing or minimizing.
        if (!window_pos_set_by_api && !(flags & ImGuiWindowFlags_ChildWindow) && window->AutoFitFramesX <= 0 && window->AutoFitFramesY <= 0)
        {
            if (g.IO.DisplaySize.x > 0.0f && g.IO.DisplaySize.y > 0.0f) // Ignore zero-sized display explicitly to avoid losing positions if a window manager reports zero-sized window when initializing or minimizing.
            {
                ImVec2 padding = ImMax(style.DisplayWindowPadding, style.DisplaySafeAreaPadding);
                ImVec2 size_for_clamping = ((g.IO.ConfigWindowsMoveFromTitleBarOnly) && !(window->Flags & ImGuiWindowFlags_NoTitleBar)) ? ImVec2(window->Size.x, window->TitleBarHeight()) : window->Size;
                window->Pos = ImMax(window->Pos + size_for_clamping, padding) - size_for_clamping;
                window->Pos = ImMin(window->Pos, g.IO.DisplaySize - padding);
            }
        }
        window->Pos = ImFloor(window->Pos);

        // Lock window rounding for the frame (so that altering them doesn't cause inconsistencies)
        window->WindowRounding = (flags & ImGuiWindowFlags_ChildWindow) ? style.ChildRounding : ((flags & ImGuiWindowFlags_Popup) && !(flags & ImGuiWindowFlags_Modal)) ? style.PopupRounding : style.WindowRounding;

        // Prepare for item focus requests
        window->FocusIdxAllRequestCurrent = (window->FocusIdxAllRequestNext == INT_MAX || window->FocusIdxAllCounter == -1) ? INT_MAX : (window->FocusIdxAllRequestNext + (window->FocusIdxAllCounter+1)) % (window->FocusIdxAllCounter+1);
        window->FocusIdxTabRequestCurrent = (window->FocusIdxTabRequestNext == INT_MAX || window->FocusIdxTabCounter == -1) ? INT_MAX : (window->FocusIdxTabRequestNext + (window->FocusIdxTabCounter+1)) % (window->FocusIdxTabCounter+1);
        window->FocusIdxAllCounter = window->FocusIdxTabCounter = -1;
        window->FocusIdxAllRequestNext = window->FocusIdxTabRequestNext = INT_MAX;

        // Apply scrolling
        window->Scroll = CalcNextScrollFromScrollTargetAndClamp(window, true);
        window->ScrollTarget = ImVec2(FLT_MAX, FLT_MAX);

        // Apply window focus (new and reactivated windows are moved to front)
        bool want_focus = false;
        if (window_just_activated_by_user && !(flags & ImGuiWindowFlags_NoFocusOnAppearing))
        {
            if (flags & ImGuiWindowFlags_Popup)
                want_focus = true;
            else if ((flags & (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_Tooltip)) == 0)
                want_focus = true;
        }

        // Handle manual resize: Resize Grips, Borders, Gamepad
        int border_held = -1;
        ImU32 resize_grip_col[4] = { 0 };
        const int resize_grip_count = g.IO.ConfigWindowsResizeFromEdges ? 2 : 1; // 4
        const float grip_draw_size = (float)(int)ImMax(g.FontSize * 1.35f, window->WindowRounding + 1.0f + g.FontSize * 0.2f);
        if (!window->Collapsed)
            UpdateManualResize(window, size_auto_fit, &border_held, resize_grip_count, &resize_grip_col[0]);
        window->ResizeBorderHeld = (signed char)border_held;

        // Default item width. Make it proportional to window size if window manually resizes
        if (window->Size.x > 0.0f && !(flags & ImGuiWindowFlags_Tooltip) && !(flags & ImGuiWindowFlags_AlwaysAutoResize))
            window->ItemWidthDefault = (float)(int)(window->Size.x * 0.65f);
        else
            window->ItemWidthDefault = (float)(int)(g.FontSize * 16.0f);

        // DRAWING

        // Setup draw list and outer clipping rectangle
        window->DrawList->Clear();
        window->DrawList->Flags = (g.Style.AntiAliasedLines ? ImDrawListFlags_AntiAliasedLines : 0) | (g.Style.AntiAliasedFill ? ImDrawListFlags_AntiAliasedFill : 0);
        window->DrawList->PushTextureID(g.Font->ContainerAtlas->TexID);
        ImRect viewport_rect(GetViewportRect());
        if ((flags & ImGuiWindowFlags_ChildWindow) && !(flags & ImGuiWindowFlags_Popup) && !window_is_child_tooltip)
            PushClipRect(parent_window->ClipRect.Min, parent_window->ClipRect.Max, true);
        else
            PushClipRect(viewport_rect.Min, viewport_rect.Max, true);

        // Draw modal window background (darkens what is behind them, all viewports)
        const bool dim_bg_for_modal = (flags & ImGuiWindowFlags_Modal) && window == GetFrontMostPopupModal() && window->HiddenFramesForResize <= 0;
        const bool dim_bg_for_window_list = g.NavWindowingTargetAnim && (window == g.NavWindowingTargetAnim->RootWindow);
        if (dim_bg_for_modal || dim_bg_for_window_list)
        {
            const ImU32 dim_bg_col = GetColorU32(dim_bg_for_modal ? ImGuiCol_ModalWindowDimBg : ImGuiCol_NavWindowingDimBg, g.DimBgRatio);
            window->DrawList->AddRectFilled(viewport_rect.Min, viewport_rect.Max, dim_bg_col);
        }

        // Draw navigation selection/windowing rectangle background
        if (dim_bg_for_window_list && window == g.NavWindowingTargetAnim)
        {
            ImRect bb = window->Rect();
            bb.Expand(g.FontSize);
            if (!bb.Contains(viewport_rect)) // Avoid drawing if the window covers all the viewport anyway
                window->DrawList->AddRectFilled(bb.Min, bb.Max, GetColorU32(ImGuiCol_NavWindowingHighlight, g.NavWindowingHighlightAlpha * 0.25f), g.Style.WindowRounding);
        }

        // Draw window + handle manual resize
        // As we highlight the title bar when want_focus is set, multiple reappearing windows will have have their title bar highlighted on their reappearing frame.
        const float window_rounding = window->WindowRounding;
        const float window_border_size = window->WindowBorderSize;
        const ImGuiWindow* window_to_highlight = g.NavWindowingTarget ? g.NavWindowingTarget : g.NavWindow;
        const bool title_bar_is_highlight = want_focus || (window_to_highlight && window->RootWindowForTitleBarHighlight == window_to_highlight->RootWindowForTitleBarHighlight);
        const ImRect title_bar_rect = window->TitleBarRect();
        if (window->Collapsed)
        {
            // Title bar only
            float backup_border_size = style.FrameBorderSize;
            g.Style.FrameBorderSize = window->WindowBorderSize;
            ImU32 title_bar_col = GetColorU32((title_bar_is_highlight && !g.NavDisableHighlight) ? ImGuiCol_TitleBgActive : ImGuiCol_TitleBgCollapsed);
            RenderFrame(title_bar_rect.Min, title_bar_rect.Max, title_bar_col, true, window_rounding);
            g.Style.FrameBorderSize = backup_border_size;
        }
        else
        {
            // Window background
            if (!(flags & ImGuiWindowFlags_NoBackground))
            {
                ImU32 bg_col = GetColorU32(GetWindowBgColorIdxFromFlags(flags));
                float alpha = 1.0f;
                if (g.NextWindowData.BgAlphaCond != 0)
                    alpha = g.NextWindowData.BgAlphaVal;
                if (alpha != 1.0f)
                    bg_col = (bg_col & ~IM_COL32_A_MASK) | (IM_F32_TO_INT8_SAT(alpha) << IM_COL32_A_SHIFT);
                window->DrawList->AddRectFilled(window->Pos + ImVec2(0, window->TitleBarHeight()), window->Pos + window->Size, bg_col, window_rounding, (flags & ImGuiWindowFlags_NoTitleBar) ? ImDrawCornerFlags_All : ImDrawCornerFlags_Bot);
            }
            g.NextWindowData.BgAlphaCond = 0;

            // Title bar
            if (!(flags & ImGuiWindowFlags_NoTitleBar))
            {
                ImU32 title_bar_col = GetColorU32(title_bar_is_highlight ? ImGuiCol_TitleBgActive : ImGuiCol_TitleBg);
                window->DrawList->AddRectFilled(title_bar_rect.Min, title_bar_rect.Max, title_bar_col, window_rounding, ImDrawCornerFlags_Top);
            }

            // Menu bar
            if (flags & ImGuiWindowFlags_MenuBar)
            {
                ImRect menu_bar_rect = window->MenuBarRect();
                menu_bar_rect.ClipWith(window->Rect());  // Soft clipping, in particular child window don't have minimum size covering the menu bar so this is useful for them.
                window->DrawList->AddRectFilled(menu_bar_rect.Min, menu_bar_rect.Max, GetColorU32(ImGuiCol_MenuBarBg), (flags & ImGuiWindowFlags_NoTitleBar) ? window_rounding : 0.0f, ImDrawCornerFlags_Top);
                if (style.FrameBorderSize > 0.0f && menu_bar_rect.Max.y < window->Pos.y + window->Size.y)
                    window->DrawList->AddLine(menu_bar_rect.GetBL(), menu_bar_rect.GetBR(), GetColorU32(ImGuiCol_Border), style.FrameBorderSize);
            }

            // Scrollbars
            if (window->ScrollbarX)
                Scrollbar(ImGuiAxis_X);
            if (window->ScrollbarY)
                Scrollbar(ImGuiAxis_Y);

            // Render resize grips (after their input handling so we don't have a frame of latency)
            if (!(flags & ImGuiWindowFlags_NoResize))
            {
                for (int resize_grip_n = 0; resize_grip_n < resize_grip_count; resize_grip_n++)
                {
                    const ImGuiResizeGripDef& grip = resize_grip_def[resize_grip_n];
                    const ImVec2 corner = ImLerp(window->Pos, window->Pos + window->Size, grip.CornerPosN);
                    window->DrawList->PathLineTo(corner + grip.InnerDir * ((resize_grip_n & 1) ? ImVec2(window_border_size, grip_draw_size) : ImVec2(grip_draw_size, window_border_size)));
                    window->DrawList->PathLineTo(corner + grip.InnerDir * ((resize_grip_n & 1) ? ImVec2(grip_draw_size, window_border_size) : ImVec2(window_border_size, grip_draw_size)));
                    window->DrawList->PathArcToFast(ImVec2(corner.x + grip.InnerDir.x * (window_rounding + window_border_size), corner.y + grip.InnerDir.y * (window_rounding + window_border_size)), window_rounding, grip.AngleMin12, grip.AngleMax12);
                    window->DrawList->PathFillConvex(resize_grip_col[resize_grip_n]);
                }
            }

            // Borders
            RenderOuterBorders(window);
        }

        // Draw navigation selection/windowing rectangle border
        if (g.NavWindowingTargetAnim == window)
        {
            float rounding = ImMax(window->WindowRounding, g.Style.WindowRounding);
            ImRect bb = window->Rect();
            bb.Expand(g.FontSize);
            if (bb.Contains(viewport_rect)) // If a window fits the entire viewport, adjust its highlight inward
            {
                bb.Expand(-g.FontSize - 1.0f);
                rounding = window->WindowRounding;
            }
            window->DrawList->AddRect(bb.Min, bb.Max, GetColorU32(ImGuiCol_NavWindowingHighlight, g.NavWindowingHighlightAlpha), rounding, ~0, 3.0f);
        }

        // Store a backup of SizeFull which we will use next frame to decide if we need scrollbars.
        window->SizeFullAtLastBegin = window->SizeFull;

        // Update various regions. Variables they depends on are set above in this function.
        // FIXME: window->ContentsRegionRect.Max is currently very misleading / partly faulty, but some BeginChild() patterns relies on it.
        window->ContentsRegionRect.Min.x = window->Pos.x - window->Scroll.x + window->WindowPadding.x;
        window->ContentsRegionRect.Min.y = window->Pos.y - window->Scroll.y + window->WindowPadding.y + window->TitleBarHeight() + window->MenuBarHeight();
        window->ContentsRegionRect.Max.x = window->Pos.x - window->Scroll.x - window->WindowPadding.x + (window->SizeContentsExplicit.x != 0.0f ? window->SizeContentsExplicit.x : (window->Size.x - window->ScrollbarSizes.x));
        window->ContentsRegionRect.Max.y = window->Pos.y - window->Scroll.y - window->WindowPadding.y + (window->SizeContentsExplicit.y != 0.0f ? window->SizeContentsExplicit.y : (window->Size.y - window->ScrollbarSizes.y));

        // Setup drawing context
        // (NB: That term "drawing context / DC" lost its meaning a long time ago. Initially was meant to hold transient data only. Nowadays difference between window-> and window->DC-> is dubious.)
        window->DC.Indent.x = 0.0f + window->WindowPadding.x - window->Scroll.x;
        window->DC.GroupOffset.x = 0.0f;
        window->DC.ColumnsOffset.x = 0.0f;
        window->DC.CursorStartPos = window->Pos + ImVec2(window->DC.Indent.x + window->DC.ColumnsOffset.x, window->TitleBarHeight() + window->MenuBarHeight() + window->WindowPadding.y - window->Scroll.y);
        window->DC.CursorPos = window->DC.CursorStartPos;
        window->DC.CursorPosPrevLine = window->DC.CursorPos;
        window->DC.CursorMaxPos = window->DC.CursorStartPos;
        window->DC.CurrentLineSize = window->DC.PrevLineSize = ImVec2(0.0f, 0.0f);
        window->DC.CurrentLineTextBaseOffset = window->DC.PrevLineTextBaseOffset = 0.0f;
        window->DC.NavHideHighlightOneFrame = false;
        window->DC.NavHasScroll = (GetWindowScrollMaxY(window) > 0.0f);
        window->DC.NavLayerActiveMask = window->DC.NavLayerActiveMaskNext;
        window->DC.NavLayerActiveMaskNext = 0x00;
        window->DC.MenuBarAppending = false;
        window->DC.LogLinePosY = window->DC.CursorPos.y - 9999.0f;
        window->DC.ChildWindows.resize(0);
        window->DC.LayoutType = ImGuiLayoutType_Vertical;
        window->DC.ParentLayoutType = parent_window ? parent_window->DC.LayoutType : ImGuiLayoutType_Vertical;
        window->DC.ItemFlags = parent_window ? parent_window->DC.ItemFlags : ImGuiItemFlags_Default_;
        window->DC.ItemWidth = window->ItemWidthDefault;
        window->DC.TextWrapPos = -1.0f; // disabled
        window->DC.ItemFlagsStack.resize(0);
        window->DC.ItemWidthStack.resize(0);
        window->DC.TextWrapPosStack.resize(0);
        window->DC.ColumnsSet = NULL;
        window->DC.TreeDepth = 0;
        window->DC.TreeDepthMayJumpToParentOnPop = 0x00;
        window->DC.StateStorage = &window->StateStorage;
        window->DC.GroupStack.resize(0);
        window->MenuColumns.Update(3, style.ItemSpacing.x, window_just_activated_by_user);

        if ((flags & ImGuiWindowFlags_ChildWindow) && (window->DC.ItemFlags != parent_window->DC.ItemFlags))
        {
            window->DC.ItemFlags = parent_window->DC.ItemFlags;
            window->DC.ItemFlagsStack.push_back(window->DC.ItemFlags);
        }

        if (window->AutoFitFramesX > 0)
            window->AutoFitFramesX--;
        if (window->AutoFitFramesY > 0)
            window->AutoFitFramesY--;

        // Apply focus (we need to call FocusWindow() AFTER setting DC.CursorStartPos so our initial navigation reference rectangle can start around there)
        if (want_focus)
        {
            FocusWindow(window);
            NavInitWindow(window, false);
        }

        // Title bar
        if (!(flags & ImGuiWindowFlags_NoTitleBar))
        {
            // Close & collapse button are on layer 1 (same as menus) and don't default focus
            const ImGuiItemFlags item_flags_backup = window->DC.ItemFlags;
            window->DC.ItemFlags |= ImGuiItemFlags_NoNavDefaultFocus;
            window->DC.NavLayerCurrent = ImGuiNavLayer_Menu;
            window->DC.NavLayerCurrentMask = (1 << ImGuiNavLayer_Menu);

            // Collapse button
            if (!(flags & ImGuiWindowFlags_NoCollapse))
                if (CollapseButton(window->GetID("#COLLAPSE"), window->Pos))
                    window->WantCollapseToggle = true; // Defer collapsing to next frame as we are too far in the Begin() function

            // Close button
            if (p_open != NULL)
            {
                const float pad = style.FramePadding.y;
                const float rad = g.FontSize * 0.5f;
                if (CloseButton(window->GetID("#CLOSE"), window->Rect().GetTR() + ImVec2(-pad - rad, pad + rad), rad + 1))
                    *p_open = false;
            }

            window->DC.NavLayerCurrent = ImGuiNavLayer_Main;
            window->DC.NavLayerCurrentMask = (1 << ImGuiNavLayer_Main);
            window->DC.ItemFlags = item_flags_backup;

            // Title bar text (with: horizontal alignment, avoiding collapse/close button, optional "unsaved document" marker)
            // FIXME: Refactor text alignment facilities along with RenderText helpers, this is too much code..
            const char* UNSAVED_DOCUMENT_MARKER = "*";
            float marker_size_x = (flags & ImGuiWindowFlags_UnsavedDocument) ? CalcTextSize(UNSAVED_DOCUMENT_MARKER, NULL, false).x : 0.0f;
            ImVec2 text_size = CalcTextSize(name, NULL, true) + ImVec2(marker_size_x, 0.0f);
            ImRect text_r = title_bar_rect;
            float pad_left = (flags & ImGuiWindowFlags_NoCollapse) ? style.FramePadding.x : (style.FramePadding.x + g.FontSize + style.ItemInnerSpacing.x);
            float pad_right = (p_open == NULL)                     ? style.FramePadding.x : (style.FramePadding.x + g.FontSize + style.ItemInnerSpacing.x);
            if (style.WindowTitleAlign.x > 0.0f)
                pad_right = ImLerp(pad_right, pad_left, style.WindowTitleAlign.x);
            text_r.Min.x += pad_left;
            text_r.Max.x -= pad_right;
            ImRect clip_rect = text_r;
            clip_rect.Max.x = window->Pos.x + window->Size.x - (p_open ? title_bar_rect.GetHeight() - 3 : style.FramePadding.x); // Match the size of CloseButton()
            RenderTextClipped(text_r.Min, text_r.Max, name, NULL, &text_size, style.WindowTitleAlign, &clip_rect);
            if (flags & ImGuiWindowFlags_UnsavedDocument)
            {
                ImVec2 marker_pos = ImVec2(ImMax(text_r.Min.x, text_r.Min.x + (text_r.GetWidth() - text_size.x) * style.WindowTitleAlign.x) + text_size.x, text_r.Min.y) + ImVec2(2 - marker_size_x, 0.0f);
                ImVec2 off = ImVec2(0.0f, (float)(int)(-g.FontSize * 0.25f));
                RenderTextClipped(marker_pos + off, text_r.Max + off, UNSAVED_DOCUMENT_MARKER, NULL, NULL, ImVec2(0, style.WindowTitleAlign.y), &clip_rect);
            }
        }

        // Save clipped aabb so we can access it in constant-time in FindHoveredWindow()
        window->OuterRectClipped = window->Rect();
        window->OuterRectClipped.ClipWith(window->ClipRect);

        // Pressing CTRL+C while holding on a window copy its content to the clipboard
        // This works but 1. doesn't handle multiple Begin/End pairs, 2. recursing into another Begin/End pair - so we need to work that out and add better logging scope.
        // Maybe we can support CTRL+C on every element?
        /*
        if (g.ActiveId == move_id)
            if (g.IO.KeyCtrl && IsKeyPressedMap(ImGuiKey_C))
                LogToClipboard();
        */

        // Inner rectangle
        // We set this up after processing the resize grip so that our clip rectangle doesn't lag by a frame
        // Note that if our window is collapsed we will end up with an inverted (~null) clipping rectangle which is the correct behavior.
        window->InnerMainRect.Min.x = title_bar_rect.Min.x + window->WindowBorderSize;
        window->InnerMainRect.Min.y = title_bar_rect.Max.y + window->MenuBarHeight() + (((flags & ImGuiWindowFlags_MenuBar) || !(flags & ImGuiWindowFlags_NoTitleBar)) ? style.FrameBorderSize : window->WindowBorderSize);
        window->InnerMainRect.Max.x = window->Pos.x + window->Size.x - window->ScrollbarSizes.x - window->WindowBorderSize;
        window->InnerMainRect.Max.y = window->Pos.y + window->Size.y - window->ScrollbarSizes.y - window->WindowBorderSize;
        //window->DrawList->AddRect(window->InnerRect.Min, window->InnerRect.Max, IM_COL32_WHITE);

        // Inner clipping rectangle
        // Force round operator last to ensure that e.g. (int)(max.x-min.x) in user's render code produce correct result.
        window->InnerClipRect.Min.x = ImFloor(0.5f + window->InnerMainRect.Min.x + ImMax(0.0f, ImFloor(window->WindowPadding.x*0.5f - window->WindowBorderSize)));
        window->InnerClipRect.Min.y = ImFloor(0.5f + window->InnerMainRect.Min.y);
        window->InnerClipRect.Max.x = ImFloor(0.5f + window->InnerMainRect.Max.x - ImMax(0.0f, ImFloor(window->WindowPadding.x*0.5f - window->WindowBorderSize)));
        window->InnerClipRect.Max.y = ImFloor(0.5f + window->InnerMainRect.Max.y);

        // We fill last item data based on Title Bar, in order for IsItemHovered() and IsItemActive() to be usable after Begin().
        // This is useful to allow creating context menus on title bar only, etc.
        window->DC.LastItemId = window->MoveId;
        window->DC.LastItemStatusFlags = IsMouseHoveringRect(title_bar_rect.Min, title_bar_rect.Max, false) ? ImGuiItemStatusFlags_HoveredRect : 0;
        window->DC.LastItemRect = title_bar_rect;
    }

    PushClipRect(window->InnerClipRect.Min, window->InnerClipRect.Max, true);

    // Clear 'accessed' flag last thing (After PushClipRect which will set the flag. We want the flag to stay false when the default "Debug" window is unused)
    if (first_begin_of_the_frame)
        window->WriteAccessed = false;

    window->BeginCount++;
    g.NextWindowData.Clear();

    if (flags & ImGuiWindowFlags_ChildWindow)
    {
        // Child window can be out of sight and have "negative" clip windows.
        // Mark them as collapsed so commands are skipped earlier (we can't manually collapse them because they have no title bar).
        IM_ASSERT((flags & ImGuiWindowFlags_NoTitleBar) != 0);
        if (!(flags & ImGuiWindowFlags_AlwaysAutoResize) && window->AutoFitFramesX <= 0 && window->AutoFitFramesY <= 0)
            if (window->OuterRectClipped.Min.x >= window->OuterRectClipped.Max.x || window->OuterRectClipped.Min.y >= window->OuterRectClipped.Max.y)
                window->HiddenFramesRegular = 1;

        // Completely hide along with parent or if parent is collapsed
        if (parent_window && (parent_window->Collapsed || parent_window->Hidden))
            window->HiddenFramesRegular = 1;
    }

    // Don't render if style alpha is 0.0 at the time of Begin(). This is arbitrary and inconsistent but has been there for a long while (may remove at some point)
    if (style.Alpha <= 0.0f)
        window->HiddenFramesRegular = 1;

    // Update the Hidden flag
    window->Hidden = (window->HiddenFramesRegular > 0) || (window->HiddenFramesForResize > 0);

    // Return false if we don't intend to display anything to allow user to perform an early out optimization
    window->SkipItems = (window->Collapsed || !window->Active || window->Hidden) && window->AutoFitFramesX <= 0 && window->AutoFitFramesY <= 0 && window->HiddenFramesForResize <= 0;

    return !window->SkipItems;
}

// Old Begin() API with 5 parameters, avoid calling this version directly! Use SetNextWindowSize()/SetNextWindowBgAlpha() + Begin() instead.
#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
bool ImGui::Begin(const char* name, bool* p_open, const ImVec2& size_first_use, float bg_alpha_override, ImGuiWindowFlags flags)
{
    // Old API feature: we could pass the initial window size as a parameter. This was misleading because it only had an effect if the window didn't have data in the .ini file.
    if (size_first_use.x != 0.0f || size_first_use.y != 0.0f)
        SetNextWindowSize(size_first_use, ImGuiCond_FirstUseEver);

    // Old API feature: override the window background alpha with a parameter.
    if (bg_alpha_override >= 0.0f)
        SetNextWindowBgAlpha(bg_alpha_override);

    return Begin(name, p_open, flags);
}
#endif // IMGUI_DISABLE_OBSOLETE_FUNCTIONS

void ImGui::End()
{
    ImGuiContext& g = *GImGui;

    if (g.CurrentWindowStack.Size <= 1 && g.FrameScopePushedImplicitWindow)
    {
        IM_ASSERT(g.CurrentWindowStack.Size > 1 && "Calling End() too many times!");
        return; // FIXME-ERRORHANDLING
    }
    IM_ASSERT(g.CurrentWindowStack.Size > 0);

    ImGuiWindow* window = g.CurrentWindow;

    if (window->DC.ColumnsSet != NULL)
        EndColumns();
    PopClipRect();   // Inner window clip rectangle

    // Stop logging
    if (!(window->Flags & ImGuiWindowFlags_ChildWindow))    // FIXME: add more options for scope of logging
        LogFinish();

    // Pop from window stack
    g.CurrentWindowStack.pop_back();
    if (window->Flags & ImGuiWindowFlags_Popup)
        g.BeginPopupStack.pop_back();
    CheckStacksSize(window, false);
    SetCurrentWindow(g.CurrentWindowStack.empty() ? NULL : g.CurrentWindowStack.back());
}

void ImGui::BringWindowToFocusFront(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    if (g.WindowsFocusOrder.back() == window)
        return;
    for (int i = g.WindowsFocusOrder.Size - 2; i >= 0; i--) // We can ignore the front most window
        if (g.WindowsFocusOrder[i] == window)
        {
            memmove(&g.WindowsFocusOrder[i], &g.WindowsFocusOrder[i + 1], (size_t)(g.WindowsFocusOrder.Size - i - 1) * sizeof(ImGuiWindow*));
            g.WindowsFocusOrder[g.WindowsFocusOrder.Size - 1] = window;
            break;
        }
}

void ImGui::BringWindowToDisplayFront(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* current_front_window = g.Windows.back();
    if (current_front_window == window || current_front_window->RootWindow == window)
        return;
    for (int i = g.Windows.Size - 2; i >= 0; i--) // We can ignore the front most window
        if (g.Windows[i] == window)
        {
            memmove(&g.Windows[i], &g.Windows[i + 1], (size_t)(g.Windows.Size - i - 1) * sizeof(ImGuiWindow*));
            g.Windows[g.Windows.Size - 1] = window;
            break;
        }
}

void ImGui::BringWindowToDisplayBack(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    if (g.Windows[0] == window)
        return;
    for (int i = 0; i < g.Windows.Size; i++)
        if (g.Windows[i] == window)
        {
            memmove(&g.Windows[1], &g.Windows[0], (size_t)i * sizeof(ImGuiWindow*));
            g.Windows[0] = window;
            break;
        }
}

// Moving window to front of display and set focus (which happens to be back of our sorted list)
void ImGui::FocusWindow(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;

    if (g.NavWindow != window)
    {
        g.NavWindow = window;
        if (window && g.NavDisableMouseHover)
            g.NavMousePosDirty = true;
        g.NavInitRequest = false;
        g.NavId = window ? window->NavLastIds[0] : 0; // Restore NavId
        g.NavIdIsAlive = false;
        g.NavLayer = ImGuiNavLayer_Main;
        //IMGUI_DEBUG_LOG("FocusWindow(\"%s\")\n", window ? window->Name : NULL);
    }

    // Passing NULL allow to disable keyboard focus
    if (!window)
        return;

    // Move the root window to the top of the pile
    if (window->RootWindow)
        window = window->RootWindow;

    // Steal focus on active widgets
    if (window->Flags & ImGuiWindowFlags_Popup) // FIXME: This statement should be unnecessary. Need further testing before removing it..
        if (g.ActiveId != 0 && g.ActiveIdWindow && g.ActiveIdWindow->RootWindow != window)
            ClearActiveID();

    // Bring to front
    BringWindowToFocusFront(window);
    if (!(window->Flags & ImGuiWindowFlags_NoBringToFrontOnFocus))
        BringWindowToDisplayFront(window);
}

void ImGui::FocusPreviousWindowIgnoringOne(ImGuiWindow* ignore_window)
{
    ImGuiContext& g = *GImGui;
    for (int i = g.WindowsFocusOrder.Size - 1; i >= 0; i--)
    {
        // We may later decide to test for different NoXXXInputs based on the active navigation input (mouse vs nav) but that may feel more confusing to the user.
        ImGuiWindow* window = g.WindowsFocusOrder[i];
        if (window != ignore_window && window->WasActive && !(window->Flags & ImGuiWindowFlags_ChildWindow))
            if ((window->Flags & (ImGuiWindowFlags_NoMouseInputs | ImGuiWindowFlags_NoNavInputs)) != (ImGuiWindowFlags_NoMouseInputs | ImGuiWindowFlags_NoNavInputs))
            {
                ImGuiWindow* focus_window = NavRestoreLastChildNavWindow(window);
                FocusWindow(focus_window);
                return;
            }
    }
}

void ImGui::PushItemWidth(float item_width)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.ItemWidth = (item_width == 0.0f ? window->ItemWidthDefault : item_width);
    window->DC.ItemWidthStack.push_back(window->DC.ItemWidth);
}

void ImGui::PushMultiItemsWidths(int components, float w_full)
{
    ImGuiWindow* window = GetCurrentWindow();
    const ImGuiStyle& style = GImGui->Style;
    if (w_full <= 0.0f)
        w_full = CalcItemWidth();
    const float w_item_one  = ImMax(1.0f, (float)(int)((w_full - (style.ItemInnerSpacing.x) * (components-1)) / (float)components));
    const float w_item_last = ImMax(1.0f, (float)(int)(w_full - (w_item_one + style.ItemInnerSpacing.x) * (components-1)));
    window->DC.ItemWidthStack.push_back(w_item_last);
    for (int i = 0; i < components-1; i++)
        window->DC.ItemWidthStack.push_back(w_item_one);
    window->DC.ItemWidth = window->DC.ItemWidthStack.back();
}

void ImGui::PopItemWidth()
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.ItemWidthStack.pop_back();
    window->DC.ItemWidth = window->DC.ItemWidthStack.empty() ? window->ItemWidthDefault : window->DC.ItemWidthStack.back();
}

float ImGui::CalcItemWidth()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    float w = window->DC.ItemWidth;
    if (w < 0.0f)
    {
        // Align to a right-side limit. We include 1 frame padding in the calculation because this is how the width is always used (we add 2 frame padding to it), but we could move that responsibility to the widget as well.
        float width_to_right_edge = GetContentRegionAvail().x;
        w = ImMax(1.0f, width_to_right_edge + w);
    }
    w = (float)(int)w;
    return w;
}

void ImGui::SetCurrentFont(ImFont* font)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(font && font->IsLoaded());    // Font Atlas not created. Did you call io.Fonts->GetTexDataAsRGBA32 / GetTexDataAsAlpha8 ?
    IM_ASSERT(font->Scale > 0.0f);
    g.Font = font;
    g.FontBaseSize = ImMax(1.0f, g.IO.FontGlobalScale * g.Font->FontSize * g.Font->Scale);
    g.FontSize = g.CurrentWindow ? g.CurrentWindow->CalcFontSize() : 0.0f;

    ImFontAtlas* atlas = g.Font->ContainerAtlas;
    g.DrawListSharedData.TexUvWhitePixel = atlas->TexUvWhitePixel;
    g.DrawListSharedData.Font = g.Font;
    g.DrawListSharedData.FontSize = g.FontSize;
}

void ImGui::PushFont(ImFont* font)
{
    ImGuiContext& g = *GImGui;
    if (!font)
        font = GetDefaultFont();
    SetCurrentFont(font);
    g.FontStack.push_back(font);
    g.CurrentWindow->DrawList->PushTextureID(font->ContainerAtlas->TexID);
}

void  ImGui::PopFont()
{
    ImGuiContext& g = *GImGui;
    g.CurrentWindow->DrawList->PopTextureID();
    g.FontStack.pop_back();
    SetCurrentFont(g.FontStack.empty() ? GetDefaultFont() : g.FontStack.back());
}

void ImGui::PushItemFlag(ImGuiItemFlags option, bool enabled)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (enabled)
        window->DC.ItemFlags |= option;
    else
        window->DC.ItemFlags &= ~option;
    window->DC.ItemFlagsStack.push_back(window->DC.ItemFlags);
}

void ImGui::PopItemFlag()
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.ItemFlagsStack.pop_back();
    window->DC.ItemFlags = window->DC.ItemFlagsStack.empty() ? ImGuiItemFlags_Default_ : window->DC.ItemFlagsStack.back();
}

// FIXME: Look into renaming this once we have settled the new Focus/Activation/TabStop system.
void ImGui::PushAllowKeyboardFocus(bool allow_keyboard_focus)
{
    PushItemFlag(ImGuiItemFlags_NoTabStop, !allow_keyboard_focus);
}

void ImGui::PopAllowKeyboardFocus()
{
    PopItemFlag();
}

void ImGui::PushButtonRepeat(bool repeat)
{
    PushItemFlag(ImGuiItemFlags_ButtonRepeat, repeat);
}

void ImGui::PopButtonRepeat()
{
    PopItemFlag();
}

void ImGui::PushTextWrapPos(float wrap_pos_x)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.TextWrapPos = wrap_pos_x;
    window->DC.TextWrapPosStack.push_back(wrap_pos_x);
}

void ImGui::PopTextWrapPos()
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.TextWrapPosStack.pop_back();
    window->DC.TextWrapPos = window->DC.TextWrapPosStack.empty() ? -1.0f : window->DC.TextWrapPosStack.back();
}

// FIXME: This may incur a round-trip (if the end user got their data from a float4) but eventually we aim to store the in-flight colors as ImU32
void ImGui::PushStyleColor(ImGuiCol idx, ImU32 col)
{
    ImGuiContext& g = *GImGui;
    ImGuiColorMod backup;
    backup.Col = idx;
    backup.BackupValue = g.Style.Colors[idx];
    g.ColorModifiers.push_back(backup);
    g.Style.Colors[idx] = ColorConvertU32ToFloat4(col);
}

void ImGui::PushStyleColor(ImGuiCol idx, const ImVec4& col)
{
    ImGuiContext& g = *GImGui;
    ImGuiColorMod backup;
    backup.Col = idx;
    backup.BackupValue = g.Style.Colors[idx];
    g.ColorModifiers.push_back(backup);
    g.Style.Colors[idx] = col;
}

void ImGui::PopStyleColor(int count)
{
    ImGuiContext& g = *GImGui;
    while (count > 0)
    {
        ImGuiColorMod& backup = g.ColorModifiers.back();
        g.Style.Colors[backup.Col] = backup.BackupValue;
        g.ColorModifiers.pop_back();
        count--;
    }
}

struct ImGuiStyleVarInfo
{
    ImGuiDataType   Type;
    ImU32           Count;
    ImU32           Offset;
    void*           GetVarPtr(ImGuiStyle* style) const { return (void*)((unsigned char*)style + Offset); }
};

static const ImGuiStyleVarInfo GStyleVarInfo[] =
{
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, Alpha) },               // ImGuiStyleVar_Alpha
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, WindowPadding) },       // ImGuiStyleVar_WindowPadding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, WindowRounding) },      // ImGuiStyleVar_WindowRounding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, WindowBorderSize) },    // ImGuiStyleVar_WindowBorderSize
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, WindowMinSize) },       // ImGuiStyleVar_WindowMinSize
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, WindowTitleAlign) },    // ImGuiStyleVar_WindowTitleAlign
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, ChildRounding) },       // ImGuiStyleVar_ChildRounding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, ChildBorderSize) },     // ImGuiStyleVar_ChildBorderSize
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, PopupRounding) },       // ImGuiStyleVar_PopupRounding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, PopupBorderSize) },     // ImGuiStyleVar_PopupBorderSize
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, FramePadding) },        // ImGuiStyleVar_FramePadding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, FrameRounding) },       // ImGuiStyleVar_FrameRounding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, FrameBorderSize) },     // ImGuiStyleVar_FrameBorderSize
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, ItemSpacing) },         // ImGuiStyleVar_ItemSpacing
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, ItemInnerSpacing) },    // ImGuiStyleVar_ItemInnerSpacing
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, IndentSpacing) },       // ImGuiStyleVar_IndentSpacing
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, ScrollbarSize) },       // ImGuiStyleVar_ScrollbarSize
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, ScrollbarRounding) },   // ImGuiStyleVar_ScrollbarRounding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, GrabMinSize) },         // ImGuiStyleVar_GrabMinSize
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, GrabRounding) },        // ImGuiStyleVar_GrabRounding
    { ImGuiDataType_Float, 1, (ImU32)IM_OFFSETOF(ImGuiStyle, TabRounding) },         // ImGuiStyleVar_TabRounding
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, ButtonTextAlign) },     // ImGuiStyleVar_ButtonTextAlign
    { ImGuiDataType_Float, 2, (ImU32)IM_OFFSETOF(ImGuiStyle, SelectableTextAlign) }, // ImGuiStyleVar_SelectableTextAlign
};

static const ImGuiStyleVarInfo* GetStyleVarInfo(ImGuiStyleVar idx)
{
    IM_ASSERT(idx >= 0 && idx < ImGuiStyleVar_COUNT);
    IM_ASSERT(IM_ARRAYSIZE(GStyleVarInfo) == ImGuiStyleVar_COUNT);
    return &GStyleVarInfo[idx];
}

void ImGui::PushStyleVar(ImGuiStyleVar idx, float val)
{
    const ImGuiStyleVarInfo* var_info = GetStyleVarInfo(idx);
    if (var_info->Type == ImGuiDataType_Float && var_info->Count == 1)
    {
        ImGuiContext& g = *GImGui;
        float* pvar = (float*)var_info->GetVarPtr(&g.Style);
        g.StyleModifiers.push_back(ImGuiStyleMod(idx, *pvar));
        *pvar = val;
        return;
    }
    IM_ASSERT(0); // Called function with wrong-type? Variable is not a float.
}

void ImGui::PushStyleVar(ImGuiStyleVar idx, const ImVec2& val)
{
    const ImGuiStyleVarInfo* var_info = GetStyleVarInfo(idx);
    if (var_info->Type == ImGuiDataType_Float && var_info->Count == 2)
    {
        ImGuiContext& g = *GImGui;
        ImVec2* pvar = (ImVec2*)var_info->GetVarPtr(&g.Style);
        g.StyleModifiers.push_back(ImGuiStyleMod(idx, *pvar));
        *pvar = val;
        return;
    }
    IM_ASSERT(0); // Called function with wrong-type? Variable is not a ImVec2.
}

void ImGui::PopStyleVar(int count)
{
    ImGuiContext& g = *GImGui;
    while (count > 0)
    {
        // We avoid a generic memcpy(data, &backup.Backup.., GDataTypeSize[info->Type] * info->Count), the overhead in Debug is not worth it.
        ImGuiStyleMod& backup = g.StyleModifiers.back();
        const ImGuiStyleVarInfo* info = GetStyleVarInfo(backup.VarIdx);
        void* data = info->GetVarPtr(&g.Style);
        if (info->Type == ImGuiDataType_Float && info->Count == 1)      { ((float*)data)[0] = backup.BackupFloat[0]; }
        else if (info->Type == ImGuiDataType_Float && info->Count == 2) { ((float*)data)[0] = backup.BackupFloat[0]; ((float*)data)[1] = backup.BackupFloat[1]; }
        g.StyleModifiers.pop_back();
        count--;
    }
}

const char* ImGui::GetStyleColorName(ImGuiCol idx)
{
    // Create switch-case from enum with regexp: ImGuiCol_{.*}, --> case ImGuiCol_\1: return "\1";
    switch (idx)
    {
    case ImGuiCol_Text: return "Text";
    case ImGuiCol_TextDisabled: return "TextDisabled";
    case ImGuiCol_WindowBg: return "WindowBg";
    case ImGuiCol_ChildBg: return "ChildBg";
    case ImGuiCol_PopupBg: return "PopupBg";
    case ImGuiCol_Border: return "Border";
    case ImGuiCol_BorderShadow: return "BorderShadow";
    case ImGuiCol_FrameBg: return "FrameBg";
    case ImGuiCol_FrameBgHovered: return "FrameBgHovered";
    case ImGuiCol_FrameBgActive: return "FrameBgActive";
    case ImGuiCol_TitleBg: return "TitleBg";
    case ImGuiCol_TitleBgActive: return "TitleBgActive";
    case ImGuiCol_TitleBgCollapsed: return "TitleBgCollapsed";
    case ImGuiCol_MenuBarBg: return "MenuBarBg";
    case ImGuiCol_ScrollbarBg: return "ScrollbarBg";
    case ImGuiCol_ScrollbarGrab: return "ScrollbarGrab";
    case ImGuiCol_ScrollbarGrabHovered: return "ScrollbarGrabHovered";
    case ImGuiCol_ScrollbarGrabActive: return "ScrollbarGrabActive";
    case ImGuiCol_CheckMark: return "CheckMark";
    case ImGuiCol_SliderGrab: return "SliderGrab";
    case ImGuiCol_SliderGrabActive: return "SliderGrabActive";
    case ImGuiCol_Button: return "Button";
    case ImGuiCol_ButtonHovered: return "ButtonHovered";
    case ImGuiCol_ButtonActive: return "ButtonActive";
    case ImGuiCol_Header: return "Header";
    case ImGuiCol_HeaderHovered: return "HeaderHovered";
    case ImGuiCol_HeaderActive: return "HeaderActive";
    case ImGuiCol_Separator: return "Separator";
    case ImGuiCol_SeparatorHovered: return "SeparatorHovered";
    case ImGuiCol_SeparatorActive: return "SeparatorActive";
    case ImGuiCol_ResizeGrip: return "ResizeGrip";
    case ImGuiCol_ResizeGripHovered: return "ResizeGripHovered";
    case ImGuiCol_ResizeGripActive: return "ResizeGripActive";
    case ImGuiCol_Tab: return "Tab";
    case ImGuiCol_TabHovered: return "TabHovered";
    case ImGuiCol_TabActive: return "TabActive";
    case ImGuiCol_TabUnfocused: return "TabUnfocused";
    case ImGuiCol_TabUnfocusedActive: return "TabUnfocusedActive";
    case ImGuiCol_PlotLines: return "PlotLines";
    case ImGuiCol_PlotLinesHovered: return "PlotLinesHovered";
    case ImGuiCol_PlotHistogram: return "PlotHistogram";
    case ImGuiCol_PlotHistogramHovered: return "PlotHistogramHovered";
    case ImGuiCol_TextSelectedBg: return "TextSelectedBg";
    case ImGuiCol_DragDropTarget: return "DragDropTarget";
    case ImGuiCol_NavHighlight: return "NavHighlight";
    case ImGuiCol_NavWindowingHighlight: return "NavWindowingHighlight";
    case ImGuiCol_NavWindowingDimBg: return "NavWindowingDimBg";
    case ImGuiCol_ModalWindowDimBg: return "ModalWindowDimBg";
    }
    IM_ASSERT(0);
    return "Unknown";
}

bool ImGui::IsWindowChildOf(ImGuiWindow* window, ImGuiWindow* potential_parent)
{
    if (window->RootWindow == potential_parent)
        return true;
    while (window != NULL)
    {
        if (window == potential_parent)
            return true;
        window = window->ParentWindow;
    }
    return false;
}

bool ImGui::IsWindowHovered(ImGuiHoveredFlags flags)
{
    IM_ASSERT((flags & ImGuiHoveredFlags_AllowWhenOverlapped) == 0);   // Flags not supported by this function
    ImGuiContext& g = *GImGui;

    if (flags & ImGuiHoveredFlags_AnyWindow)
    {
        if (g.HoveredWindow == NULL)
            return false;
    }
    else
    {
        switch (flags & (ImGuiHoveredFlags_RootWindow | ImGuiHoveredFlags_ChildWindows))
        {
        case ImGuiHoveredFlags_RootWindow | ImGuiHoveredFlags_ChildWindows:
            if (g.HoveredRootWindow != g.CurrentWindow->RootWindow)
                return false;
            break;
        case ImGuiHoveredFlags_RootWindow:
            if (g.HoveredWindow != g.CurrentWindow->RootWindow)
                return false;
            break;
        case ImGuiHoveredFlags_ChildWindows:
            if (g.HoveredWindow == NULL || !IsWindowChildOf(g.HoveredWindow, g.CurrentWindow))
                return false;
            break;
        default:
            if (g.HoveredWindow != g.CurrentWindow)
                return false;
            break;
        }
    }

    if (!IsWindowContentHoverable(g.HoveredRootWindow, flags))
        return false;
    if (!(flags & ImGuiHoveredFlags_AllowWhenBlockedByActiveItem))
        if (g.ActiveId != 0 && !g.ActiveIdAllowOverlap && g.ActiveId != g.HoveredWindow->MoveId)
            return false;
    return true;
}

bool ImGui::IsWindowFocused(ImGuiFocusedFlags flags)
{
    ImGuiContext& g = *GImGui;

    if (flags & ImGuiFocusedFlags_AnyWindow)
        return g.NavWindow != NULL;

    IM_ASSERT(g.CurrentWindow);     // Not inside a Begin()/End()
    switch (flags & (ImGuiFocusedFlags_RootWindow | ImGuiFocusedFlags_ChildWindows))
    {
    case ImGuiFocusedFlags_RootWindow | ImGuiFocusedFlags_ChildWindows:
        return g.NavWindow && g.NavWindow->RootWindow == g.CurrentWindow->RootWindow;
    case ImGuiFocusedFlags_RootWindow:
        return g.NavWindow == g.CurrentWindow->RootWindow;
    case ImGuiFocusedFlags_ChildWindows:
        return g.NavWindow && IsWindowChildOf(g.NavWindow, g.CurrentWindow);
    default:
        return g.NavWindow == g.CurrentWindow;
    }
}

// Can we focus this window with CTRL+TAB (or PadMenu + PadFocusPrev/PadFocusNext)
// Note that NoNavFocus makes the window not reachable with CTRL+TAB but it can still be focused with mouse or programmaticaly.
// If you want a window to never be focused, you may use the e.g. NoInputs flag.
bool ImGui::IsWindowNavFocusable(ImGuiWindow* window)
{
    return window->Active && window == window->RootWindow && !(window->Flags & ImGuiWindowFlags_NoNavFocus);
}

float ImGui::GetWindowWidth()
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->Size.x;
}

float ImGui::GetWindowHeight()
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->Size.y;
}

ImVec2 ImGui::GetWindowPos()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    return window->Pos;
}

void ImGui::SetWindowScrollX(ImGuiWindow* window, float new_scroll_x)
{
    window->DC.CursorMaxPos.x += window->Scroll.x; // SizeContents is generally computed based on CursorMaxPos which is affected by scroll position, so we need to apply our change to it.
    window->Scroll.x = new_scroll_x;
    window->DC.CursorMaxPos.x -= window->Scroll.x;
}

void ImGui::SetWindowScrollY(ImGuiWindow* window, float new_scroll_y)
{
    window->DC.CursorMaxPos.y += window->Scroll.y; // SizeContents is generally computed based on CursorMaxPos which is affected by scroll position, so we need to apply our change to it.
    window->Scroll.y = new_scroll_y;
    window->DC.CursorMaxPos.y -= window->Scroll.y;
}

void ImGui::SetWindowPos(ImGuiWindow* window, const ImVec2& pos, ImGuiCond cond)
{
    // Test condition (NB: bit 0 is always true) and clear flags for next time
    if (cond && (window->SetWindowPosAllowFlags & cond) == 0)
        return;

    IM_ASSERT(cond == 0 || ImIsPowerOfTwo(cond)); // Make sure the user doesn't attempt to combine multiple condition flags.
    window->SetWindowPosAllowFlags &= ~(ImGuiCond_Once | ImGuiCond_FirstUseEver | ImGuiCond_Appearing);
    window->SetWindowPosVal = ImVec2(FLT_MAX, FLT_MAX);

    // Set
    const ImVec2 old_pos = window->Pos;
    window->Pos = ImFloor(pos);
    window->DC.CursorPos += (window->Pos - old_pos);    // As we happen to move the window while it is being appended to (which is a bad idea - will smear) let's at least offset the cursor
    window->DC.CursorMaxPos += (window->Pos - old_pos); // And more importantly we need to adjust this so size calculation doesn't get affected.
}

void ImGui::SetWindowPos(const ImVec2& pos, ImGuiCond cond)
{
    ImGuiWindow* window = GetCurrentWindowRead();
    SetWindowPos(window, pos, cond);
}

void ImGui::SetWindowPos(const char* name, const ImVec2& pos, ImGuiCond cond)
{
    if (ImGuiWindow* window = FindWindowByName(name))
        SetWindowPos(window, pos, cond);
}

ImVec2 ImGui::GetWindowSize()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->Size;
}

void ImGui::SetWindowSize(ImGuiWindow* window, const ImVec2& size, ImGuiCond cond)
{
    // Test condition (NB: bit 0 is always true) and clear flags for next time
    if (cond && (window->SetWindowSizeAllowFlags & cond) == 0)
        return;

    IM_ASSERT(cond == 0 || ImIsPowerOfTwo(cond)); // Make sure the user doesn't attempt to combine multiple condition flags.
    window->SetWindowSizeAllowFlags &= ~(ImGuiCond_Once | ImGuiCond_FirstUseEver | ImGuiCond_Appearing);

    // Set
    if (size.x > 0.0f)
    {
        window->AutoFitFramesX = 0;
        window->SizeFull.x = ImFloor(size.x);
    }
    else
    {
        window->AutoFitFramesX = 2;
        window->AutoFitOnlyGrows = false;
    }
    if (size.y > 0.0f)
    {
        window->AutoFitFramesY = 0;
        window->SizeFull.y = ImFloor(size.y);
    }
    else
    {
        window->AutoFitFramesY = 2;
        window->AutoFitOnlyGrows = false;
    }
}

void ImGui::SetWindowSize(const ImVec2& size, ImGuiCond cond)
{
    SetWindowSize(GImGui->CurrentWindow, size, cond);
}

void ImGui::SetWindowSize(const char* name, const ImVec2& size, ImGuiCond cond)
{
    if (ImGuiWindow* window = FindWindowByName(name))
        SetWindowSize(window, size, cond);
}

void ImGui::SetWindowCollapsed(ImGuiWindow* window, bool collapsed, ImGuiCond cond)
{
    // Test condition (NB: bit 0 is always true) and clear flags for next time
    if (cond && (window->SetWindowCollapsedAllowFlags & cond) == 0)
        return;
    window->SetWindowCollapsedAllowFlags &= ~(ImGuiCond_Once | ImGuiCond_FirstUseEver | ImGuiCond_Appearing);

    // Set
    window->Collapsed = collapsed;
}

void ImGui::SetWindowCollapsed(bool collapsed, ImGuiCond cond)
{
    SetWindowCollapsed(GImGui->CurrentWindow, collapsed, cond);
}

bool ImGui::IsWindowCollapsed()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->Collapsed;
}

bool ImGui::IsWindowAppearing()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->Appearing;
}

void ImGui::SetWindowCollapsed(const char* name, bool collapsed, ImGuiCond cond)
{
    if (ImGuiWindow* window = FindWindowByName(name))
        SetWindowCollapsed(window, collapsed, cond);
}

void ImGui::SetWindowFocus()
{
    FocusWindow(GImGui->CurrentWindow);
}

void ImGui::SetWindowFocus(const char* name)
{
    if (name)
    {
        if (ImGuiWindow* window = FindWindowByName(name))
            FocusWindow(window);
    }
    else
    {
        FocusWindow(NULL);
    }
}

void ImGui::SetNextWindowPos(const ImVec2& pos, ImGuiCond cond, const ImVec2& pivot)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(cond == 0 || ImIsPowerOfTwo(cond)); // Make sure the user doesn't attempt to combine multiple condition flags.
    g.NextWindowData.PosVal = pos;
    g.NextWindowData.PosPivotVal = pivot;
    g.NextWindowData.PosCond = cond ? cond : ImGuiCond_Always;
}

void ImGui::SetNextWindowSize(const ImVec2& size, ImGuiCond cond)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(cond == 0 || ImIsPowerOfTwo(cond)); // Make sure the user doesn't attempt to combine multiple condition flags.
    g.NextWindowData.SizeVal = size;
    g.NextWindowData.SizeCond = cond ? cond : ImGuiCond_Always;
}

void ImGui::SetNextWindowSizeConstraints(const ImVec2& size_min, const ImVec2& size_max, ImGuiSizeCallback custom_callback, void* custom_callback_user_data)
{
    ImGuiContext& g = *GImGui;
    g.NextWindowData.SizeConstraintCond = ImGuiCond_Always;
    g.NextWindowData.SizeConstraintRect = ImRect(size_min, size_max);
    g.NextWindowData.SizeCallback = custom_callback;
    g.NextWindowData.SizeCallbackUserData = custom_callback_user_data;
}

void ImGui::SetNextWindowContentSize(const ImVec2& size)
{
    ImGuiContext& g = *GImGui;
    g.NextWindowData.ContentSizeVal = size;  // In Begin() we will add the size of window decorations (title bar, menu etc.) to that to form a SizeContents value.
    g.NextWindowData.ContentSizeCond = ImGuiCond_Always;
}

void ImGui::SetNextWindowCollapsed(bool collapsed, ImGuiCond cond)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(cond == 0 || ImIsPowerOfTwo(cond)); // Make sure the user doesn't attempt to combine multiple condition flags.
    g.NextWindowData.CollapsedVal = collapsed;
    g.NextWindowData.CollapsedCond = cond ? cond : ImGuiCond_Always;
}

void ImGui::SetNextWindowFocus()
{
    ImGuiContext& g = *GImGui;
    g.NextWindowData.FocusCond = ImGuiCond_Always;   // Using a Cond member for consistency (may transition all of them to single flag set for fast Clear() op)
}

void ImGui::SetNextWindowBgAlpha(float alpha)
{
    ImGuiContext& g = *GImGui;
    g.NextWindowData.BgAlphaVal = alpha;
    g.NextWindowData.BgAlphaCond = ImGuiCond_Always; // Using a Cond member for consistency (may transition all of them to single flag set for fast Clear() op)
}

// FIXME: This is in window space (not screen space!)
ImVec2 ImGui::GetContentRegionMax()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    ImVec2 mx = window->ContentsRegionRect.Max - window->Pos;
    if (window->DC.ColumnsSet)
        mx.x = GetColumnOffset(window->DC.ColumnsSet->Current + 1) - window->WindowPadding.x;
    return mx;
}

ImVec2 ImGui::GetContentRegionAvail()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return GetContentRegionMax() - (window->DC.CursorPos - window->Pos);
}

float ImGui::GetContentRegionAvailWidth()
{
    return GetContentRegionAvail().x;
}

// In window space (not screen space!)
ImVec2 ImGui::GetWindowContentRegionMin()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->ContentsRegionRect.Min - window->Pos;
}

ImVec2 ImGui::GetWindowContentRegionMax()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->ContentsRegionRect.Max - window->Pos;
}

float ImGui::GetWindowContentRegionWidth()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->ContentsRegionRect.GetWidth();
}

float ImGui::GetTextLineHeight()
{
    ImGuiContext& g = *GImGui;
    return g.FontSize;
}

float ImGui::GetTextLineHeightWithSpacing()
{
    ImGuiContext& g = *GImGui;
    return g.FontSize + g.Style.ItemSpacing.y;
}

float ImGui::GetFrameHeight()
{
    ImGuiContext& g = *GImGui;
    return g.FontSize + g.Style.FramePadding.y * 2.0f;
}

float ImGui::GetFrameHeightWithSpacing()
{
    ImGuiContext& g = *GImGui;
    return g.FontSize + g.Style.FramePadding.y * 2.0f + g.Style.ItemSpacing.y;
}

ImDrawList* ImGui::GetWindowDrawList()
{
    ImGuiWindow* window = GetCurrentWindow();
    return window->DrawList;
}

ImFont* ImGui::GetFont()
{
    return GImGui->Font;
}

float ImGui::GetFontSize()
{
    return GImGui->FontSize;
}

ImVec2 ImGui::GetFontTexUvWhitePixel()
{
    return GImGui->DrawListSharedData.TexUvWhitePixel;
}

void ImGui::SetWindowFontScale(float scale)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();
    window->FontWindowScale = scale;
    g.FontSize = g.DrawListSharedData.FontSize = window->CalcFontSize();
}

// User generally sees positions in window coordinates. Internally we store CursorPos in absolute screen coordinates because it is more convenient.
// Conversion happens as we pass the value to user, but it makes our naming convention confusing because GetCursorPos() == (DC.CursorPos - window.Pos). May want to rename 'DC.CursorPos'.
ImVec2 ImGui::GetCursorPos()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.CursorPos - window->Pos + window->Scroll;
}

float ImGui::GetCursorPosX()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.CursorPos.x - window->Pos.x + window->Scroll.x;
}

float ImGui::GetCursorPosY()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.CursorPos.y - window->Pos.y + window->Scroll.y;
}

void ImGui::SetCursorPos(const ImVec2& local_pos)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.CursorPos = window->Pos - window->Scroll + local_pos;
    window->DC.CursorMaxPos = ImMax(window->DC.CursorMaxPos, window->DC.CursorPos);
}

void ImGui::SetCursorPosX(float x)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.CursorPos.x = window->Pos.x - window->Scroll.x + x;
    window->DC.CursorMaxPos.x = ImMax(window->DC.CursorMaxPos.x, window->DC.CursorPos.x);
}

void ImGui::SetCursorPosY(float y)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.CursorPos.y = window->Pos.y - window->Scroll.y + y;
    window->DC.CursorMaxPos.y = ImMax(window->DC.CursorMaxPos.y, window->DC.CursorPos.y);
}

ImVec2 ImGui::GetCursorStartPos()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.CursorStartPos - window->Pos;
}

ImVec2 ImGui::GetCursorScreenPos()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.CursorPos;
}

void ImGui::SetCursorScreenPos(const ImVec2& pos)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.CursorPos = pos;
    window->DC.CursorMaxPos = ImMax(window->DC.CursorMaxPos, window->DC.CursorPos);
}

float ImGui::GetScrollX()
{
    return GImGui->CurrentWindow->Scroll.x;
}

float ImGui::GetScrollY()
{
    return GImGui->CurrentWindow->Scroll.y;
}

float ImGui::GetScrollMaxX()
{
    return GetWindowScrollMaxX(GImGui->CurrentWindow);
}

float ImGui::GetScrollMaxY()
{
    return GetWindowScrollMaxY(GImGui->CurrentWindow);
}

void ImGui::SetScrollX(float scroll_x)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->ScrollTarget.x = scroll_x;
    window->ScrollTargetCenterRatio.x = 0.0f;
}

void ImGui::SetScrollY(float scroll_y)
{
    ImGuiWindow* window = GetCurrentWindow();
    window->ScrollTarget.y = scroll_y + window->TitleBarHeight() + window->MenuBarHeight(); // title bar height canceled out when using ScrollTargetRelY
    window->ScrollTargetCenterRatio.y = 0.0f;
}

void ImGui::SetScrollFromPosY(float local_y, float center_y_ratio)
{
    // We store a target position so centering can occur on the next frame when we are guaranteed to have a known window size
    ImGuiWindow* window = GetCurrentWindow();
    IM_ASSERT(center_y_ratio >= 0.0f && center_y_ratio <= 1.0f);
    window->ScrollTarget.y = (float)(int)(local_y + window->Scroll.y);
    window->ScrollTargetCenterRatio.y = center_y_ratio;
}

// center_y_ratio: 0.0f top of last item, 0.5f vertical center of last item, 1.0f bottom of last item.
void ImGui::SetScrollHereY(float center_y_ratio)
{
    ImGuiWindow* window = GetCurrentWindow();
    float target_y = window->DC.CursorPosPrevLine.y - window->Pos.y; // Top of last item, in window space
    target_y += (window->DC.PrevLineSize.y * center_y_ratio) + (GImGui->Style.ItemSpacing.y * (center_y_ratio - 0.5f) * 2.0f); // Precisely aim above, in the middle or below the last line.
    SetScrollFromPosY(target_y, center_y_ratio);
}

void ImGui::ActivateItem(ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    g.NavNextActivateId = id;
}

void ImGui::SetKeyboardFocusHere(int offset)
{
    IM_ASSERT(offset >= -1);    // -1 is allowed but not below
    ImGuiWindow* window = GetCurrentWindow();
    window->FocusIdxAllRequestNext = window->FocusIdxAllCounter + 1 + offset;
    window->FocusIdxTabRequestNext = INT_MAX;
}

void ImGui::SetItemDefaultFocus()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (!window->Appearing)
        return;
    if (g.NavWindow == window->RootWindowForNav && (g.NavInitRequest || g.NavInitResultId != 0) && g.NavLayer == g.NavWindow->DC.NavLayerCurrent)
    {
        g.NavInitRequest = false;
        g.NavInitResultId = g.NavWindow->DC.LastItemId;
        g.NavInitResultRectRel = ImRect(g.NavWindow->DC.LastItemRect.Min - g.NavWindow->Pos, g.NavWindow->DC.LastItemRect.Max - g.NavWindow->Pos);
        NavUpdateAnyRequestFlag();
        if (!IsItemVisible())
            SetScrollHereY();
    }
}

void ImGui::SetStateStorage(ImGuiStorage* tree)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    window->DC.StateStorage = tree ? tree : &window->StateStorage;
}

ImGuiStorage* ImGui::GetStateStorage()
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->DC.StateStorage;
}

void ImGui::PushID(const char* str_id)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    window->IDStack.push_back(window->GetIDNoKeepAlive(str_id));
}

void ImGui::PushID(const char* str_id_begin, const char* str_id_end)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    window->IDStack.push_back(window->GetIDNoKeepAlive(str_id_begin, str_id_end));
}

void ImGui::PushID(const void* ptr_id)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    window->IDStack.push_back(window->GetIDNoKeepAlive(ptr_id));
}

void ImGui::PushID(int int_id)
{
    const void* ptr_id = (void*)(intptr_t)int_id;
    ImGuiWindow* window = GImGui->CurrentWindow;
    window->IDStack.push_back(window->GetIDNoKeepAlive(ptr_id));
}

void ImGui::PopID()
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    window->IDStack.pop_back();
}

ImGuiID ImGui::GetID(const char* str_id)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->GetID(str_id);
}

ImGuiID ImGui::GetID(const char* str_id_begin, const char* str_id_end)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->GetID(str_id_begin, str_id_end);
}

ImGuiID ImGui::GetID(const void* ptr_id)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->GetID(ptr_id);
}

bool ImGui::IsRectVisible(const ImVec2& size)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->ClipRect.Overlaps(ImRect(window->DC.CursorPos, window->DC.CursorPos + size));
}

bool ImGui::IsRectVisible(const ImVec2& rect_min, const ImVec2& rect_max)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    return window->ClipRect.Overlaps(ImRect(rect_min, rect_max));
}

// Lock horizontal starting position + capture group bounding box into one "item" (so you can use IsItemHovered() or layout primitives such as SameLine() on whole group, etc.)
void ImGui::BeginGroup()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();

    window->DC.GroupStack.resize(window->DC.GroupStack.Size + 1);
    ImGuiGroupData& group_data = window->DC.GroupStack.back();
    group_data.BackupCursorPos = window->DC.CursorPos;
    group_data.BackupCursorMaxPos = window->DC.CursorMaxPos;
    group_data.BackupIndent = window->DC.Indent;
    group_data.BackupGroupOffset = window->DC.GroupOffset;
    group_data.BackupCurrentLineSize = window->DC.CurrentLineSize;
    group_data.BackupCurrentLineTextBaseOffset = window->DC.CurrentLineTextBaseOffset;
    group_data.BackupLogLinePosY = window->DC.LogLinePosY;
    group_data.BackupActiveIdIsAlive = g.ActiveIdIsAlive;
    group_data.BackupActiveIdPreviousFrameIsAlive = g.ActiveIdPreviousFrameIsAlive;
    group_data.AdvanceCursor = true;

    window->DC.GroupOffset.x = window->DC.CursorPos.x - window->Pos.x - window->DC.ColumnsOffset.x;
    window->DC.Indent = window->DC.GroupOffset;
    window->DC.CursorMaxPos = window->DC.CursorPos;
    window->DC.CurrentLineSize = ImVec2(0.0f, 0.0f);
    window->DC.LogLinePosY = window->DC.CursorPos.y - 9999.0f; // To enforce Log carriage return
}

void ImGui::EndGroup()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();
    IM_ASSERT(!window->DC.GroupStack.empty());    // Mismatched BeginGroup()/EndGroup() calls

    ImGuiGroupData& group_data = window->DC.GroupStack.back();

    ImRect group_bb(group_data.BackupCursorPos, window->DC.CursorMaxPos);
    group_bb.Max = ImMax(group_bb.Min, group_bb.Max);

    window->DC.CursorPos = group_data.BackupCursorPos;
    window->DC.CursorMaxPos = ImMax(group_data.BackupCursorMaxPos, window->DC.CursorMaxPos);
    window->DC.Indent = group_data.BackupIndent;
    window->DC.GroupOffset = group_data.BackupGroupOffset;
    window->DC.CurrentLineSize = group_data.BackupCurrentLineSize;
    window->DC.CurrentLineTextBaseOffset = group_data.BackupCurrentLineTextBaseOffset;
    window->DC.LogLinePosY = window->DC.CursorPos.y - 9999.0f; // To enforce Log carriage return

    if (group_data.AdvanceCursor)
    {
        window->DC.CurrentLineTextBaseOffset = ImMax(window->DC.PrevLineTextBaseOffset, group_data.BackupCurrentLineTextBaseOffset);      // FIXME: Incorrect, we should grab the base offset from the *first line* of the group but it is hard to obtain now.
        ItemSize(group_bb.GetSize(), 0.0f);
        ItemAdd(group_bb, 0);
    }

    // If the current ActiveId was declared within the boundary of our group, we copy it to LastItemId so IsItemActive(), IsItemDeactivated() etc. will be functional on the entire group.
    // It would be be neater if we replaced window.DC.LastItemId by e.g. 'bool LastItemIsActive', but would put a little more burden on individual widgets.
    // (and if you grep for LastItemId you'll notice it is only used in that context.
    if ((group_data.BackupActiveIdIsAlive != g.ActiveId) && (g.ActiveIdIsAlive == g.ActiveId) && g.ActiveId) // && g.ActiveIdWindow->RootWindow == window->RootWindow)
        window->DC.LastItemId = g.ActiveId;
    else if (!group_data.BackupActiveIdPreviousFrameIsAlive && g.ActiveIdPreviousFrameIsAlive) // && g.ActiveIdPreviousFrameWindow->RootWindow == window->RootWindow)
        window->DC.LastItemId = g.ActiveIdPreviousFrame;
    window->DC.LastItemRect = group_bb;

    window->DC.GroupStack.pop_back();

    //window->DrawList->AddRect(group_bb.Min, group_bb.Max, IM_COL32(255,0,255,255));   // [Debug]
}

// Gets back to previous line and continue with horizontal layout
//      pos_x == 0      : follow right after previous item
//      pos_x != 0      : align to specified x position (relative to window/group left)
//      spacing_w < 0   : use default spacing if pos_x == 0, no spacing if pos_x != 0
//      spacing_w >= 0  : enforce spacing amount
void ImGui::SameLine(float pos_x, float spacing_w)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    if (pos_x != 0.0f)
    {
        if (spacing_w < 0.0f) spacing_w = 0.0f;
        window->DC.CursorPos.x = window->Pos.x - window->Scroll.x + pos_x + spacing_w + window->DC.GroupOffset.x + window->DC.ColumnsOffset.x;
        window->DC.CursorPos.y = window->DC.CursorPosPrevLine.y;
    }
    else
    {
        if (spacing_w < 0.0f) spacing_w = g.Style.ItemSpacing.x;
        window->DC.CursorPos.x = window->DC.CursorPosPrevLine.x + spacing_w;
        window->DC.CursorPos.y = window->DC.CursorPosPrevLine.y;
    }
    window->DC.CurrentLineSize = window->DC.PrevLineSize;
    window->DC.CurrentLineTextBaseOffset = window->DC.PrevLineTextBaseOffset;
}

void ImGui::Indent(float indent_w)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.Indent.x += (indent_w != 0.0f) ? indent_w : g.Style.IndentSpacing;
    window->DC.CursorPos.x = window->Pos.x + window->DC.Indent.x + window->DC.ColumnsOffset.x;
}

void ImGui::Unindent(float indent_w)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();
    window->DC.Indent.x -= (indent_w != 0.0f) ? indent_w : g.Style.IndentSpacing;
    window->DC.CursorPos.x = window->Pos.x + window->DC.Indent.x + window->DC.ColumnsOffset.x;
}

//-----------------------------------------------------------------------------
// [SECTION] TOOLTIPS
//-----------------------------------------------------------------------------

void ImGui::BeginTooltip()
{
    ImGuiContext& g = *GImGui;
    if (g.DragDropWithinSourceOrTarget)
    {
        // The default tooltip position is a little offset to give space to see the context menu (it's also clamped within the current viewport/monitor)
        // In the context of a dragging tooltip we try to reduce that offset and we enforce following the cursor.
        // Whatever we do we want to call SetNextWindowPos() to enforce a tooltip position and disable clipping the tooltip without our display area, like regular tooltip do.
        //ImVec2 tooltip_pos = g.IO.MousePos - g.ActiveIdClickOffset - g.Style.WindowPadding;
        ImVec2 tooltip_pos = g.IO.MousePos + ImVec2(16 * g.Style.MouseCursorScale, 8 * g.Style.MouseCursorScale);
        SetNextWindowPos(tooltip_pos);
        SetNextWindowBgAlpha(g.Style.Colors[ImGuiCol_PopupBg].w * 0.60f);
        //PushStyleVar(ImGuiStyleVar_Alpha, g.Style.Alpha * 0.60f); // This would be nice but e.g ColorButton with checkboard has issue with transparent colors :(
        BeginTooltipEx(0, true);
    }
    else
    {
        BeginTooltipEx(0, false);
    }
}

// Not exposed publicly as BeginTooltip() because bool parameters are evil. Let's see if other needs arise first.
void ImGui::BeginTooltipEx(ImGuiWindowFlags extra_flags, bool override_previous_tooltip)
{
    ImGuiContext& g = *GImGui;
    char window_name[16];
    ImFormatString(window_name, IM_ARRAYSIZE(window_name), "##Tooltip_%02d", g.TooltipOverrideCount);
    if (override_previous_tooltip)
        if (ImGuiWindow* window = FindWindowByName(window_name))
            if (window->Active)
            {
                // Hide previous tooltip from being displayed. We can't easily "reset" the content of a window so we create a new one.
                window->Hidden = true;
                window->HiddenFramesRegular = 1;
                ImFormatString(window_name, IM_ARRAYSIZE(window_name), "##Tooltip_%02d", ++g.TooltipOverrideCount);
            }
    ImGuiWindowFlags flags = ImGuiWindowFlags_Tooltip|ImGuiWindowFlags_NoInputs|ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_AlwaysAutoResize;
    Begin(window_name, NULL, flags | extra_flags);
}

void ImGui::EndTooltip()
{
    IM_ASSERT(GetCurrentWindowRead()->Flags & ImGuiWindowFlags_Tooltip);   // Mismatched BeginTooltip()/EndTooltip() calls
    End();
}

void ImGui::SetTooltipV(const char* fmt, va_list args)
{
    ImGuiContext& g = *GImGui;
    if (g.DragDropWithinSourceOrTarget)
        BeginTooltip();
    else
        BeginTooltipEx(0, true);
    TextV(fmt, args);
    EndTooltip();
}

void ImGui::SetTooltip(const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    SetTooltipV(fmt, args);
    va_end(args);
}

//-----------------------------------------------------------------------------
// [SECTION] POPUPS
//-----------------------------------------------------------------------------

bool ImGui::IsPopupOpen(ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    return g.OpenPopupStack.Size > g.BeginPopupStack.Size && g.OpenPopupStack[g.BeginPopupStack.Size].PopupId == id;
}

bool ImGui::IsPopupOpen(const char* str_id)
{
    ImGuiContext& g = *GImGui;
    return g.OpenPopupStack.Size > g.BeginPopupStack.Size && g.OpenPopupStack[g.BeginPopupStack.Size].PopupId == g.CurrentWindow->GetID(str_id);
}

ImGuiWindow* ImGui::GetFrontMostPopupModal()
{
    ImGuiContext& g = *GImGui;
    for (int n = g.OpenPopupStack.Size-1; n >= 0; n--)
        if (ImGuiWindow* popup = g.OpenPopupStack.Data[n].Window)
            if (popup->Flags & ImGuiWindowFlags_Modal)
                return popup;
    return NULL;
}

void ImGui::OpenPopup(const char* str_id)
{
    ImGuiContext& g = *GImGui;
    OpenPopupEx(g.CurrentWindow->GetID(str_id));
}

// Mark popup as open (toggle toward open state).
// Popups are closed when user click outside, or activate a pressable item, or CloseCurrentPopup() is called within a BeginPopup()/EndPopup() block.
// Popup identifiers are relative to the current ID-stack (so OpenPopup and BeginPopup needs to be at the same level).
// One open popup per level of the popup hierarchy (NB: when assigning we reset the Window member of ImGuiPopupRef to NULL)
void ImGui::OpenPopupEx(ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* parent_window = g.CurrentWindow;
    int current_stack_size = g.BeginPopupStack.Size;
    ImGuiPopupRef popup_ref; // Tagged as new ref as Window will be set back to NULL if we write this into OpenPopupStack.
    popup_ref.PopupId = id;
    popup_ref.Window = NULL;
    popup_ref.ParentWindow = parent_window;
    popup_ref.OpenFrameCount = g.FrameCount;
    popup_ref.OpenParentId = parent_window->IDStack.back();
    popup_ref.OpenPopupPos = NavCalcPreferredRefPos();
    popup_ref.OpenMousePos = IsMousePosValid(&g.IO.MousePos) ? g.IO.MousePos : popup_ref.OpenPopupPos;

    //IMGUI_DEBUG_LOG("OpenPopupEx(0x%08X)\n", g.FrameCount, id);
    if (g.OpenPopupStack.Size < current_stack_size + 1)
    {
        g.OpenPopupStack.push_back(popup_ref);
    }
    else
    {
        // Gently handle the user mistakenly calling OpenPopup() every frame. It is a programming mistake! However, if we were to run the regular code path, the ui
        // would become completely unusable because the popup will always be in hidden-while-calculating-size state _while_ claiming focus. Which would be a very confusing
        // situation for the programmer. Instead, we silently allow the popup to proceed, it will keep reappearing and the programming error will be more obvious to understand.
        if (g.OpenPopupStack[current_stack_size].PopupId == id && g.OpenPopupStack[current_stack_size].OpenFrameCount == g.FrameCount - 1)
        {
            g.OpenPopupStack[current_stack_size].OpenFrameCount = popup_ref.OpenFrameCount;
        }
        else
        {
            // Close child popups if any, then flag popup for open/reopen
            g.OpenPopupStack.resize(current_stack_size + 1);
            g.OpenPopupStack[current_stack_size] = popup_ref;
        }

        // When reopening a popup we first refocus its parent, otherwise if its parent is itself a popup it would get closed by ClosePopupsOverWindow().
        // This is equivalent to what ClosePopupToLevel() does.
        //if (g.OpenPopupStack[current_stack_size].PopupId == id)
        //    FocusWindow(parent_window);
    }
}

bool ImGui::OpenPopupOnItemClick(const char* str_id, int mouse_button)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    if (IsMouseReleased(mouse_button) && IsItemHovered(ImGuiHoveredFlags_AllowWhenBlockedByPopup))
    {
        ImGuiID id = str_id ? window->GetID(str_id) : window->DC.LastItemId; // If user hasn't passed an ID, we can use the LastItemID. Using LastItemID as a Popup ID won't conflict!
        IM_ASSERT(id != 0);                                                  // You cannot pass a NULL str_id if the last item has no identifier (e.g. a Text() item)
        OpenPopupEx(id);
        return true;
    }
    return false;
}

void ImGui::ClosePopupsOverWindow(ImGuiWindow* ref_window)
{
    ImGuiContext& g = *GImGui;
    if (g.OpenPopupStack.empty())
        return;

    // When popups are stacked, clicking on a lower level popups puts focus back to it and close popups above it.
    // Don't close our own child popup windows.
    int popup_count_to_keep = 0;
    if (ref_window)
    {
        // Find the highest popup which is a descendant of the reference window (generally reference window = NavWindow)
        for (; popup_count_to_keep < g.OpenPopupStack.Size; popup_count_to_keep++)
        {
            ImGuiPopupRef& popup = g.OpenPopupStack[popup_count_to_keep];
            if (!popup.Window)
                continue;
            IM_ASSERT((popup.Window->Flags & ImGuiWindowFlags_Popup) != 0);
            if (popup.Window->Flags & ImGuiWindowFlags_ChildWindow)
                continue;

            // Trim the stack if popups are not direct descendant of the reference window (which is often the NavWindow)
            bool popup_or_descendent_has_focus = false;
            for (int m = popup_count_to_keep; m < g.OpenPopupStack.Size && !popup_or_descendent_has_focus; m++)
                if (g.OpenPopupStack[m].Window && g.OpenPopupStack[m].Window->RootWindow == ref_window->RootWindow)
                    popup_or_descendent_has_focus = true;
            if (!popup_or_descendent_has_focus)
                break;
        }
    }
    if (popup_count_to_keep < g.OpenPopupStack.Size) // This test is not required but it allows to set a convenient breakpoint on the statement below
    {
        //IMGUI_DEBUG_LOG("ClosePopupsOverWindow(%s) -> ClosePopupToLevel(%d)\n", ref_window->Name, popup_count_to_keep);
        ClosePopupToLevel(popup_count_to_keep, false);
    }
}

void ImGui::ClosePopupToLevel(int remaining, bool apply_focus_to_window_under)
{
    IM_ASSERT(remaining >= 0);
    ImGuiContext& g = *GImGui;
    ImGuiWindow* focus_window = (remaining > 0) ? g.OpenPopupStack[remaining-1].Window : g.OpenPopupStack[0].ParentWindow;
    g.OpenPopupStack.resize(remaining);

    // FIXME: This code is faulty and we may want to eventually to replace or remove the 'apply_focus_to_window_under=true' path completely.
    // Instead of using g.OpenPopupStack[remaining-1].Window etc. we should find the highest root window that is behind the popups we are closing.
    // The current code will set focus to the parent of the popup window which is incorrect.
    // It rarely manifested until now because UpdateMouseMovingWindowNewFrame() would call FocusWindow() again on the clicked window,
    // leading to a chain of focusing A (clicked window) then B (parent window of the popup) then A again.
    // However if the clicked window has the _NoMove flag set we would be left with B focused.
    // For now, we have disabled this path when called from ClosePopupsOverWindow() because the users of ClosePopupsOverWindow() don't need to alter focus anyway,
    // but we should inspect and fix this properly.
    if (apply_focus_to_window_under)
    {
        if (g.NavLayer == 0)
            focus_window = NavRestoreLastChildNavWindow(focus_window);
        FocusWindow(focus_window);
    }
}

// Close the popup we have begin-ed into.
void ImGui::CloseCurrentPopup()
{
    ImGuiContext& g = *GImGui;
    int popup_idx = g.BeginPopupStack.Size - 1;
    if (popup_idx < 0 || popup_idx >= g.OpenPopupStack.Size || g.BeginPopupStack[popup_idx].PopupId != g.OpenPopupStack[popup_idx].PopupId)
        return;

    // Closing a menu closes its top-most parent popup (unless a modal)
    while (popup_idx > 0)
    {
        ImGuiWindow* popup_window = g.OpenPopupStack[popup_idx].Window;
        ImGuiWindow* parent_popup_window = g.OpenPopupStack[popup_idx - 1].Window;
        bool close_parent = false;
        if (popup_window && (popup_window->Flags & ImGuiWindowFlags_ChildMenu))
            if (parent_popup_window == NULL || !(parent_popup_window->Flags & ImGuiWindowFlags_Modal))
                close_parent = true;
        if (!close_parent)
            break;
        popup_idx--;
    }
    //IMGUI_DEBUG_LOG("CloseCurrentPopup %d -> %d\n", g.BeginPopupStack.Size - 1, popup_idx);
    ClosePopupToLevel(popup_idx, true);

    // A common pattern is to close a popup when selecting a menu item/selectable that will open another window.
    // To improve this usage pattern, we avoid nav highlight for a single frame in the parent window.
    // Similarly, we could avoid mouse hover highlight in this window but it is less visually problematic.
    if (ImGuiWindow* window = g.NavWindow)
        window->DC.NavHideHighlightOneFrame = true;
}

bool ImGui::BeginPopupEx(ImGuiID id, ImGuiWindowFlags extra_flags)
{
    ImGuiContext& g = *GImGui;
    if (!IsPopupOpen(id))
    {
        g.NextWindowData.Clear(); // We behave like Begin() and need to consume those values
        return false;
    }

    char name[20];
    if (extra_flags & ImGuiWindowFlags_ChildMenu)
        ImFormatString(name, IM_ARRAYSIZE(name), "##Menu_%02d", g.BeginPopupStack.Size); // Recycle windows based on depth
    else
        ImFormatString(name, IM_ARRAYSIZE(name), "##Popup_%08x", id); // Not recycling, so we can close/open during the same frame

    bool is_open = Begin(name, NULL, extra_flags | ImGuiWindowFlags_Popup);
    if (!is_open) // NB: Begin can return false when the popup is completely clipped (e.g. zero size display)
        EndPopup();

    return is_open;
}

bool ImGui::BeginPopup(const char* str_id, ImGuiWindowFlags flags)
{
    ImGuiContext& g = *GImGui;
    if (g.OpenPopupStack.Size <= g.BeginPopupStack.Size) // Early out for performance
    {
        g.NextWindowData.Clear(); // We behave like Begin() and need to consume those values
        return false;
    }
    flags |= ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings;
    return BeginPopupEx(g.CurrentWindow->GetID(str_id), flags);
}

// If 'p_open' is specified for a modal popup window, the popup will have a regular close button which will close the popup.
// Note that popup visibility status is owned by imgui (and manipulated with e.g. OpenPopup) so the actual value of *p_open is meaningless here.
bool ImGui::BeginPopupModal(const char* name, bool* p_open, ImGuiWindowFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    const ImGuiID id = window->GetID(name);
    if (!IsPopupOpen(id))
    {
        g.NextWindowData.Clear(); // We behave like Begin() and need to consume those values
        return false;
    }

    // Center modal windows by default
    // FIXME: Should test for (PosCond & window->SetWindowPosAllowFlags) with the upcoming window.
    if (g.NextWindowData.PosCond == 0)
        SetNextWindowPos(g.IO.DisplaySize * 0.5f, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));

    flags |= ImGuiWindowFlags_Popup | ImGuiWindowFlags_Modal | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings;
    const bool is_open = Begin(name, p_open, flags);
    if (!is_open || (p_open && !*p_open)) // NB: is_open can be 'false' when the popup is completely clipped (e.g. zero size display)
    {
        EndPopup();
        if (is_open)
            ClosePopupToLevel(g.BeginPopupStack.Size, true);
        return false;
    }
    return is_open;
}

void ImGui::EndPopup()
{
    ImGuiContext& g = *GImGui; 
    IM_ASSERT(g.CurrentWindow->Flags & ImGuiWindowFlags_Popup);  // Mismatched BeginPopup()/EndPopup() calls
    IM_ASSERT(g.BeginPopupStack.Size > 0);

    // Make all menus and popups wrap around for now, may need to expose that policy.
    NavMoveRequestTryWrapping(g.CurrentWindow, ImGuiNavMoveFlags_LoopY);

    End();
}

// This is a helper to handle the simplest case of associating one named popup to one given widget.
// You may want to handle this on user side if you have specific needs (e.g. tweaking IsItemHovered() parameters).
// You can pass a NULL str_id to use the identifier of the last item.
bool ImGui::BeginPopupContextItem(const char* str_id, int mouse_button)
{
    ImGuiWindow* window = GImGui->CurrentWindow;
    ImGuiID id = str_id ? window->GetID(str_id) : window->DC.LastItemId; // If user hasn't passed an ID, we can use the LastItemID. Using LastItemID as a Popup ID won't conflict!
    IM_ASSERT(id != 0);                                                  // You cannot pass a NULL str_id if the last item has no identifier (e.g. a Text() item)
    if (IsMouseReleased(mouse_button) && IsItemHovered(ImGuiHoveredFlags_AllowWhenBlockedByPopup))
        OpenPopupEx(id);
    return BeginPopupEx(id, ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoSavedSettings);
}

bool ImGui::BeginPopupContextWindow(const char* str_id, int mouse_button, bool also_over_items)
{
    if (!str_id)
        str_id = "window_context";
    ImGuiID id = GImGui->CurrentWindow->GetID(str_id);
    if (IsMouseReleased(mouse_button) && IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByPopup))
        if (also_over_items || !IsAnyItemHovered())
            OpenPopupEx(id);
    return BeginPopupEx(id, ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoSavedSettings);
}

bool ImGui::BeginPopupContextVoid(const char* str_id, int mouse_button)
{
    if (!str_id)
        str_id = "void_context";
    ImGuiID id = GImGui->CurrentWindow->GetID(str_id);
    if (IsMouseReleased(mouse_button) && !IsWindowHovered(ImGuiHoveredFlags_AnyWindow))
        OpenPopupEx(id);
    return BeginPopupEx(id, ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoSavedSettings);
}

ImRect ImGui::GetWindowAllowedExtentRect(ImGuiWindow*)
{
    ImVec2 padding = GImGui->Style.DisplaySafeAreaPadding;
    ImRect r_screen = GetViewportRect();
    r_screen.Expand(ImVec2((r_screen.GetWidth() > padding.x * 2) ? -padding.x : 0.0f, (r_screen.GetHeight() > padding.y * 2) ? -padding.y : 0.0f));
    return r_screen;
}

// r_avoid = the rectangle to avoid (e.g. for tooltip it is a rectangle around the mouse cursor which we want to avoid. for popups it's a small point around the cursor.)
// r_outer = the visible area rectangle, minus safe area padding. If our popup size won't fit because of safe area padding we ignore it.
ImVec2 ImGui::FindBestWindowPosForPopupEx(const ImVec2& ref_pos, const ImVec2& size, ImGuiDir* last_dir, const ImRect& r_outer, const ImRect& r_avoid, ImGuiPopupPositionPolicy policy)
{
    ImVec2 base_pos_clamped = ImClamp(ref_pos, r_outer.Min, r_outer.Max - size);
    //GImGui->OverlayDrawList.AddRect(r_avoid.Min, r_avoid.Max, IM_COL32(255,0,0,255));
    //GImGui->OverlayDrawList.AddRect(r_outer.Min, r_outer.Max, IM_COL32(0,255,0,255));

    // Combo Box policy (we want a connecting edge)
    if (policy == ImGuiPopupPositionPolicy_ComboBox)
    {
        const ImGuiDir dir_prefered_order[ImGuiDir_COUNT] = { ImGuiDir_Down, ImGuiDir_Right, ImGuiDir_Left, ImGuiDir_Up };
        for (int n = (*last_dir != ImGuiDir_None) ? -1 : 0; n < ImGuiDir_COUNT; n++)
        {
            const ImGuiDir dir = (n == -1) ? *last_dir : dir_prefered_order[n];
            if (n != -1 && dir == *last_dir) // Already tried this direction?
                continue;
            ImVec2 pos;
            if (dir == ImGuiDir_Down)  pos = ImVec2(r_avoid.Min.x, r_avoid.Max.y);          // Below, Toward Right (default)
            if (dir == ImGuiDir_Right) pos = ImVec2(r_avoid.Min.x, r_avoid.Min.y - size.y); // Above, Toward Right
            if (dir == ImGuiDir_Left)  pos = ImVec2(r_avoid.Max.x - size.x, r_avoid.Max.y); // Below, Toward Left
            if (dir == ImGuiDir_Up)    pos = ImVec2(r_avoid.Max.x - size.x, r_avoid.Min.y - size.y); // Above, Toward Left
            if (!r_outer.Contains(ImRect(pos, pos + size)))
                continue;
            *last_dir = dir;
            return pos;
        }
    }

    // Default popup policy
    const ImGuiDir dir_prefered_order[ImGuiDir_COUNT] = { ImGuiDir_Right, ImGuiDir_Down, ImGuiDir_Up, ImGuiDir_Left };
    for (int n = (*last_dir != ImGuiDir_None) ? -1 : 0; n < ImGuiDir_COUNT; n++)
    {
        const ImGuiDir dir = (n == -1) ? *last_dir : dir_prefered_order[n];
        if (n != -1 && dir == *last_dir) // Already tried this direction?
            continue;
        float avail_w = (dir == ImGuiDir_Left ? r_avoid.Min.x : r_outer.Max.x) - (dir == ImGuiDir_Right ? r_avoid.Max.x : r_outer.Min.x);
        float avail_h = (dir == ImGuiDir_Up ? r_avoid.Min.y : r_outer.Max.y) - (dir == ImGuiDir_Down ? r_avoid.Max.y : r_outer.Min.y);
        if (avail_w < size.x || avail_h < size.y)
            continue;
        ImVec2 pos;
        pos.x = (dir == ImGuiDir_Left) ? r_avoid.Min.x - size.x : (dir == ImGuiDir_Right) ? r_avoid.Max.x : base_pos_clamped.x;
        pos.y = (dir == ImGuiDir_Up)   ? r_avoid.Min.y - size.y : (dir == ImGuiDir_Down)  ? r_avoid.Max.y : base_pos_clamped.y;
        *last_dir = dir;
        return pos;
    }

    // Fallback, try to keep within display
    *last_dir = ImGuiDir_None;
    ImVec2 pos = ref_pos;
    pos.x = ImMax(ImMin(pos.x + size.x, r_outer.Max.x) - size.x, r_outer.Min.x);
    pos.y = ImMax(ImMin(pos.y + size.y, r_outer.Max.y) - size.y, r_outer.Min.y);
    return pos;
}

ImVec2 ImGui::FindBestWindowPosForPopup(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;

    ImRect r_outer = GetWindowAllowedExtentRect(window);
    if (window->Flags & ImGuiWindowFlags_ChildMenu)
    {
        // Child menus typically request _any_ position within the parent menu item, and then we move the new menu outside the parent bounds.
        // This is how we end up with child menus appearing (most-commonly) on the right of the parent menu.
        IM_ASSERT(g.CurrentWindow == window);
        ImGuiWindow* parent_window = g.CurrentWindowStack[g.CurrentWindowStack.Size - 2];
        float horizontal_overlap = g.Style.ItemInnerSpacing.x; // We want some overlap to convey the relative depth of each menu (currently the amount of overlap is hard-coded to style.ItemSpacing.x).
        ImRect r_avoid;
        if (parent_window->DC.MenuBarAppending)
            r_avoid = ImRect(-FLT_MAX, parent_window->Pos.y + parent_window->TitleBarHeight(), FLT_MAX, parent_window->Pos.y + parent_window->TitleBarHeight() + parent_window->MenuBarHeight());
        else
            r_avoid = ImRect(parent_window->Pos.x + horizontal_overlap, -FLT_MAX, parent_window->Pos.x + parent_window->Size.x - horizontal_overlap - parent_window->ScrollbarSizes.x, FLT_MAX);
        return FindBestWindowPosForPopupEx(window->Pos, window->Size, &window->AutoPosLastDirection, r_outer, r_avoid);
    }
    if (window->Flags & ImGuiWindowFlags_Popup)
    {
        ImRect r_avoid = ImRect(window->Pos.x - 1, window->Pos.y - 1, window->Pos.x + 1, window->Pos.y + 1);
        return FindBestWindowPosForPopupEx(window->Pos, window->Size, &window->AutoPosLastDirection, r_outer, r_avoid);
    }
    if (window->Flags & ImGuiWindowFlags_Tooltip)
    {
        // Position tooltip (always follows mouse)
        float sc = g.Style.MouseCursorScale;
        ImVec2 ref_pos = NavCalcPreferredRefPos();
        ImRect r_avoid;
        if (!g.NavDisableHighlight && g.NavDisableMouseHover && !(g.IO.ConfigFlags & ImGuiConfigFlags_NavEnableSetMousePos))
            r_avoid = ImRect(ref_pos.x - 16, ref_pos.y - 8, ref_pos.x + 16, ref_pos.y + 8);
        else
            r_avoid = ImRect(ref_pos.x - 16, ref_pos.y - 8, ref_pos.x + 24 * sc, ref_pos.y + 24 * sc); // FIXME: Hard-coded based on mouse cursor shape expectation. Exact dimension not very important.
        ImVec2 pos = FindBestWindowPosForPopupEx(ref_pos, window->Size, &window->AutoPosLastDirection, r_outer, r_avoid);
        if (window->AutoPosLastDirection == ImGuiDir_None)
            pos = ref_pos + ImVec2(2, 2); // If there's not enough room, for tooltip we prefer avoiding the cursor at all cost even if it means that part of the tooltip won't be visible.
        return pos;
    }
    IM_ASSERT(0);
    return window->Pos;
}

//-----------------------------------------------------------------------------
// [SECTION] VIEWPORTS, PLATFORM WINDOWS
//-----------------------------------------------------------------------------

// (this section is filled in the 'viewport' and 'docking' branches)

//-----------------------------------------------------------------------------
// [SECTION] KEYBOARD/GAMEPAD NAVIGATION
//-----------------------------------------------------------------------------

ImGuiDir ImGetDirQuadrantFromDelta(float dx, float dy)
{
    if (ImFabs(dx) > ImFabs(dy))
        return (dx > 0.0f) ? ImGuiDir_Right : ImGuiDir_Left;
    return (dy > 0.0f) ? ImGuiDir_Down : ImGuiDir_Up;
}

static float inline NavScoreItemDistInterval(float a0, float a1, float b0, float b1)
{
    if (a1 < b0)
        return a1 - b0;
    if (b1 < a0)
        return a0 - b1;
    return 0.0f;
}

static void inline NavClampRectToVisibleAreaForMoveDir(ImGuiDir move_dir, ImRect& r, const ImRect& clip_rect)
{
    if (move_dir == ImGuiDir_Left || move_dir == ImGuiDir_Right)
    {
        r.Min.y = ImClamp(r.Min.y, clip_rect.Min.y, clip_rect.Max.y);
        r.Max.y = ImClamp(r.Max.y, clip_rect.Min.y, clip_rect.Max.y);
    }
    else
    {
        r.Min.x = ImClamp(r.Min.x, clip_rect.Min.x, clip_rect.Max.x);
        r.Max.x = ImClamp(r.Max.x, clip_rect.Min.x, clip_rect.Max.x);
    }
}

// Scoring function for directional navigation. Based on https://gist.github.com/rygorous/6981057
static bool NavScoreItem(ImGuiNavMoveResult* result, ImRect cand)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (g.NavLayer != window->DC.NavLayerCurrent)
        return false;

    const ImRect& curr = g.NavScoringRectScreen; // Current modified source rect (NB: we've applied Max.x = Min.x in NavUpdate() to inhibit the effect of having varied item width)
    g.NavScoringCount++;

    // When entering through a NavFlattened border, we consider child window items as fully clipped for scoring
    if (window->ParentWindow == g.NavWindow)
    {
        IM_ASSERT((window->Flags | g.NavWindow->Flags) & ImGuiWindowFlags_NavFlattened);
        if (!window->ClipRect.Contains(cand))
            return false;
        cand.ClipWithFull(window->ClipRect); // This allows the scored item to not overlap other candidates in the parent window
    }

    // We perform scoring on items bounding box clipped by the current clipping rectangle on the other axis (clipping on our movement axis would give us equal scores for all clipped items)
    // For example, this ensure that items in one column are not reached when moving vertically from items in another column.
    NavClampRectToVisibleAreaForMoveDir(g.NavMoveClipDir, cand, window->ClipRect);

    // Compute distance between boxes
    // FIXME-NAV: Introducing biases for vertical navigation, needs to be removed.
    float dbx = NavScoreItemDistInterval(cand.Min.x, cand.Max.x, curr.Min.x, curr.Max.x);
    float dby = NavScoreItemDistInterval(ImLerp(cand.Min.y, cand.Max.y, 0.2f), ImLerp(cand.Min.y, cand.Max.y, 0.8f), ImLerp(curr.Min.y, curr.Max.y, 0.2f), ImLerp(curr.Min.y, curr.Max.y, 0.8f)); // Scale down on Y to keep using box-distance for vertically touching items
    if (dby != 0.0f && dbx != 0.0f)
       dbx = (dbx/1000.0f) + ((dbx > 0.0f) ? +1.0f : -1.0f);
    float dist_box = ImFabs(dbx) + ImFabs(dby);

    // Compute distance between centers (this is off by a factor of 2, but we only compare center distances with each other so it doesn't matter)
    float dcx = (cand.Min.x + cand.Max.x) - (curr.Min.x + curr.Max.x);
    float dcy = (cand.Min.y + cand.Max.y) - (curr.Min.y + curr.Max.y);
    float dist_center = ImFabs(dcx) + ImFabs(dcy); // L1 metric (need this for our connectedness guarantee)

    // Determine which quadrant of 'curr' our candidate item 'cand' lies in based on distance
    ImGuiDir quadrant;
    float dax = 0.0f, day = 0.0f, dist_axial = 0.0f;
    if (dbx != 0.0f || dby != 0.0f)
    {
        // For non-overlapping boxes, use distance between boxes
        dax = dbx;
        day = dby;
        dist_axial = dist_box;
        quadrant = ImGetDirQuadrantFromDelta(dbx, dby);
    }
    else if (dcx != 0.0f || dcy != 0.0f)
    {
        // For overlapping boxes with different centers, use distance between centers
        dax = dcx;
        day = dcy;
        dist_axial = dist_center;
        quadrant = ImGetDirQuadrantFromDelta(dcx, dcy);
    }
    else
    {
        // Degenerate case: two overlapping buttons with same center, break ties arbitrarily (note that LastItemId here is really the _previous_ item order, but it doesn't matter)
        quadrant = (window->DC.LastItemId < g.NavId) ? ImGuiDir_Left : ImGuiDir_Right;
    }

#if IMGUI_DEBUG_NAV_SCORING
    char buf[128];
    if (ImGui::IsMouseHoveringRect(cand.Min, cand.Max))
    {
        ImFormatString(buf, IM_ARRAYSIZE(buf), "dbox (%.2f,%.2f->%.4f)\ndcen (%.2f,%.2f->%.4f)\nd (%.2f,%.2f->%.4f)\nnav %c, quadrant %c", dbx, dby, dist_box, dcx, dcy, dist_center, dax, day, dist_axial, "WENS"[g.NavMoveDir], "WENS"[quadrant]);
        ImDrawList* draw_list = ImGui::GetOverlayDrawList(window);
        draw_list->AddRect(curr.Min, curr.Max, IM_COL32(255,200,0,100));
        draw_list->AddRect(cand.Min, cand.Max, IM_COL32(255,255,0,200));
        draw_list->AddRectFilled(cand.Max-ImVec2(4,4), cand.Max+ImGui::CalcTextSize(buf)+ImVec2(4,4), IM_COL32(40,0,0,150));
        draw_list->AddText(g.IO.FontDefault, 13.0f, cand.Max, ~0U, buf);
    }
    else if (g.IO.KeyCtrl) // Hold to preview score in matching quadrant. Press C to rotate.
    {
        if (ImGui::IsKeyPressedMap(ImGuiKey_C)) { g.NavMoveDirLast = (ImGuiDir)((g.NavMoveDirLast + 1) & 3); g.IO.KeysDownDuration[g.IO.KeyMap[ImGuiKey_C]] = 0.01f; }
        if (quadrant == g.NavMoveDir)
        {
            ImFormatString(buf, IM_ARRAYSIZE(buf), "%.0f/%.0f", dist_box, dist_center);
            ImDrawList* draw_list = ImGui::GetOverlayDrawList(window);
            draw_list->AddRectFilled(cand.Min, cand.Max, IM_COL32(255, 0, 0, 200));
            draw_list->AddText(g.IO.FontDefault, 13.0f, cand.Min, IM_COL32(255, 255, 255, 255), buf);
        }
    }
 #endif

    // Is it in the quadrant we're interesting in moving to?
    bool new_best = false;
    if (quadrant == g.NavMoveDir)
    {
        // Does it beat the current best candidate?
        if (dist_box < result->DistBox)
        {
            result->DistBox = dist_box;
            result->DistCenter = dist_center;
            return true;
        }
        if (dist_box == result->DistBox)
        {
            // Try using distance between center points to break ties
            if (dist_center < result->DistCenter)
            {
                result->DistCenter = dist_center;
                new_best = true;
            }
            else if (dist_center == result->DistCenter)
            {
                // Still tied! we need to be extra-careful to make sure everything gets linked properly. We consistently break ties by symbolically moving "later" items
                // (with higher index) to the right/downwards by an infinitesimal amount since we the current "best" button already (so it must have a lower index),
                // this is fairly easy. This rule ensures that all buttons with dx==dy==0 will end up being linked in order of appearance along the x axis.
                if (((g.NavMoveDir == ImGuiDir_Up || g.NavMoveDir == ImGuiDir_Down) ? dby : dbx) < 0.0f) // moving bj to the right/down decreases distance
                    new_best = true;
            }
        }
    }

    // Axial check: if 'curr' has no link at all in some direction and 'cand' lies roughly in that direction, add a tentative link. This will only be kept if no "real" matches
    // are found, so it only augments the graph produced by the above method using extra links. (important, since it doesn't guarantee strong connectedness)
    // This is just to avoid buttons having no links in a particular direction when there's a suitable neighbor. you get good graphs without this too.
    // 2017/09/29: FIXME: This now currently only enabled inside menu bars, ideally we'd disable it everywhere. Menus in particular need to catch failure. For general navigation it feels awkward.
    // Disabling it may lead to disconnected graphs when nodes are very spaced out on different axis. Perhaps consider offering this as an option?
    if (result->DistBox == FLT_MAX && dist_axial < result->DistAxial)  // Check axial match
        if (g.NavLayer == 1 && !(g.NavWindow->Flags & ImGuiWindowFlags_ChildMenu))
            if ((g.NavMoveDir == ImGuiDir_Left && dax < 0.0f) || (g.NavMoveDir == ImGuiDir_Right && dax > 0.0f) || (g.NavMoveDir == ImGuiDir_Up && day < 0.0f) || (g.NavMoveDir == ImGuiDir_Down && day > 0.0f))
            {
                result->DistAxial = dist_axial;
                new_best = true;
            }

    return new_best;
}

// We get there when either NavId == id, or when g.NavAnyRequest is set (which is updated by NavUpdateAnyRequestFlag above)
static void ImGui::NavProcessItem(ImGuiWindow* window, const ImRect& nav_bb, const ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    //if (!g.IO.NavActive)  // [2017/10/06] Removed this possibly redundant test but I am not sure of all the side-effects yet. Some of the feature here will need to work regardless of using a _NoNavInputs flag.
    //    return;

    const ImGuiItemFlags item_flags = window->DC.ItemFlags;
    const ImRect nav_bb_rel(nav_bb.Min - window->Pos, nav_bb.Max - window->Pos);

    // Process Init Request
    if (g.NavInitRequest && g.NavLayer == window->DC.NavLayerCurrent)
    {
        // Even if 'ImGuiItemFlags_NoNavDefaultFocus' is on (typically collapse/close button) we record the first ResultId so they can be used as a fallback
        if (!(item_flags & ImGuiItemFlags_NoNavDefaultFocus) || g.NavInitResultId == 0)
        {
            g.NavInitResultId = id;
            g.NavInitResultRectRel = nav_bb_rel;
        }
        if (!(item_flags & ImGuiItemFlags_NoNavDefaultFocus))
        {
            g.NavInitRequest = false; // Found a match, clear request
            NavUpdateAnyRequestFlag();
        }
    }

    // Process Move Request (scoring for navigation)
    // FIXME-NAV: Consider policy for double scoring (scoring from NavScoringRectScreen + scoring from a rect wrapped according to current wrapping policy)
    if ((g.NavId != id || (g.NavMoveRequestFlags & ImGuiNavMoveFlags_AllowCurrentNavId)) && !(item_flags & ImGuiItemFlags_NoNav))
    {
        ImGuiNavMoveResult* result = (window == g.NavWindow) ? &g.NavMoveResultLocal : &g.NavMoveResultOther;
#if IMGUI_DEBUG_NAV_SCORING
        // [DEBUG] Score all items in NavWindow at all times
        if (!g.NavMoveRequest)
            g.NavMoveDir = g.NavMoveDirLast;
        bool new_best = NavScoreItem(result, nav_bb) && g.NavMoveRequest;
#else
        bool new_best = g.NavMoveRequest && NavScoreItem(result, nav_bb);
#endif
        if (new_best)
        {
            result->ID = id;
            result->SelectScopeId = g.MultiSelectScopeId;
            result->Window = window;
            result->RectRel = nav_bb_rel;
        }

        const float VISIBLE_RATIO = 0.70f;
        if ((g.NavMoveRequestFlags & ImGuiNavMoveFlags_AlsoScoreVisibleSet) && window->ClipRect.Overlaps(nav_bb))
            if (ImClamp(nav_bb.Max.y, window->ClipRect.Min.y, window->ClipRect.Max.y) - ImClamp(nav_bb.Min.y, window->ClipRect.Min.y, window->ClipRect.Max.y) >= (nav_bb.Max.y - nav_bb.Min.y) * VISIBLE_RATIO)
                if (NavScoreItem(&g.NavMoveResultLocalVisibleSet, nav_bb))
                {
                    result = &g.NavMoveResultLocalVisibleSet;
                    result->ID = id;
                    result->SelectScopeId = g.MultiSelectScopeId;
                    result->Window = window;
                    result->RectRel = nav_bb_rel;
                }
    }

    // Update window-relative bounding box of navigated item
    if (g.NavId == id)
    {
        g.NavWindow = window;                                           // Always refresh g.NavWindow, because some operations such as FocusItem() don't have a window.
        g.NavLayer = window->DC.NavLayerCurrent;
        g.NavIdIsAlive = true;
        g.NavIdTabCounter = window->FocusIdxTabCounter;
        window->NavRectRel[window->DC.NavLayerCurrent] = nav_bb_rel;    // Store item bounding box (relative to window position)
    }
}

bool ImGui::NavMoveRequestButNoResultYet()
{
    ImGuiContext& g = *GImGui;
    return g.NavMoveRequest && g.NavMoveResultLocal.ID == 0 && g.NavMoveResultOther.ID == 0;
}

void ImGui::NavMoveRequestCancel()
{
    ImGuiContext& g = *GImGui;
    g.NavMoveRequest = false;
    NavUpdateAnyRequestFlag();
}

void ImGui::NavMoveRequestForward(ImGuiDir move_dir, ImGuiDir clip_dir, const ImRect& bb_rel, ImGuiNavMoveFlags move_flags)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.NavMoveRequestForward == ImGuiNavForward_None);
    ImGui::NavMoveRequestCancel();
    g.NavMoveDir = move_dir;
    g.NavMoveClipDir = clip_dir;
    g.NavMoveRequestForward = ImGuiNavForward_ForwardQueued;
    g.NavMoveRequestFlags = move_flags;
    g.NavWindow->NavRectRel[g.NavLayer] = bb_rel;
}

void ImGui::NavMoveRequestTryWrapping(ImGuiWindow* window, ImGuiNavMoveFlags move_flags)
{
    ImGuiContext& g = *GImGui;
    if (g.NavWindow != window || !NavMoveRequestButNoResultYet() || g.NavMoveRequestForward != ImGuiNavForward_None || g.NavLayer != 0)
        return;
    IM_ASSERT(move_flags != 0); // No points calling this with no wrapping
    ImRect bb_rel = window->NavRectRel[0];

    ImGuiDir clip_dir = g.NavMoveDir;
    if (g.NavMoveDir == ImGuiDir_Left && (move_flags & (ImGuiNavMoveFlags_WrapX | ImGuiNavMoveFlags_LoopX)))
    {
        bb_rel.Min.x = bb_rel.Max.x = ImMax(window->SizeFull.x, window->SizeContents.x) - window->Scroll.x;
        if (move_flags & ImGuiNavMoveFlags_WrapX) { bb_rel.TranslateY(-bb_rel.GetHeight()); clip_dir = ImGuiDir_Up; }
        NavMoveRequestForward(g.NavMoveDir, clip_dir, bb_rel, move_flags);
    }
    if (g.NavMoveDir == ImGuiDir_Right && (move_flags & (ImGuiNavMoveFlags_WrapX | ImGuiNavMoveFlags_LoopX)))
    {
        bb_rel.Min.x = bb_rel.Max.x = -window->Scroll.x;
        if (move_flags & ImGuiNavMoveFlags_WrapX) { bb_rel.TranslateY(+bb_rel.GetHeight()); clip_dir = ImGuiDir_Down; }
        NavMoveRequestForward(g.NavMoveDir, clip_dir, bb_rel, move_flags);
    }
    if (g.NavMoveDir == ImGuiDir_Up && (move_flags & (ImGuiNavMoveFlags_WrapY | ImGuiNavMoveFlags_LoopY)))
    {
        bb_rel.Min.y = bb_rel.Max.y = ImMax(window->SizeFull.y, window->SizeContents.y) - window->Scroll.y;
        if (move_flags & ImGuiNavMoveFlags_WrapY) { bb_rel.TranslateX(-bb_rel.GetWidth()); clip_dir = ImGuiDir_Left; }
        NavMoveRequestForward(g.NavMoveDir, clip_dir, bb_rel, move_flags);
    }
    if (g.NavMoveDir == ImGuiDir_Down && (move_flags & (ImGuiNavMoveFlags_WrapY | ImGuiNavMoveFlags_LoopY)))
    {
        bb_rel.Min.y = bb_rel.Max.y = -window->Scroll.y;
        if (move_flags & ImGuiNavMoveFlags_WrapY) { bb_rel.TranslateX(+bb_rel.GetWidth()); clip_dir = ImGuiDir_Right; }
        NavMoveRequestForward(g.NavMoveDir, clip_dir, bb_rel, move_flags);
    }
}

static void ImGui::NavSaveLastChildNavWindow(ImGuiWindow* nav_window)
{
    ImGuiWindow* parent_window = nav_window;
    while (parent_window && (parent_window->Flags & ImGuiWindowFlags_ChildWindow) != 0 && (parent_window->Flags & (ImGuiWindowFlags_Popup | ImGuiWindowFlags_ChildMenu)) == 0)
        parent_window = parent_window->ParentWindow;
    if (parent_window && parent_window != nav_window)
        parent_window->NavLastChildNavWindow = nav_window;
}

// Call when we are expected to land on Layer 0 after FocusWindow()
static ImGuiWindow* ImGui::NavRestoreLastChildNavWindow(ImGuiWindow* window)
{
    return window->NavLastChildNavWindow ? window->NavLastChildNavWindow : window;
}

static void NavRestoreLayer(ImGuiNavLayer layer)
{
    ImGuiContext& g = *GImGui;
    g.NavLayer = layer;
    if (layer == 0)
        g.NavWindow = ImGui::NavRestoreLastChildNavWindow(g.NavWindow);
    if (layer == 0 && g.NavWindow->NavLastIds[0] != 0)
        ImGui::SetNavIDWithRectRel(g.NavWindow->NavLastIds[0], layer, g.NavWindow->NavRectRel[0]);
    else
        ImGui::NavInitWindow(g.NavWindow, true);
}

static inline void ImGui::NavUpdateAnyRequestFlag()
{
    ImGuiContext& g = *GImGui;
    g.NavAnyRequest = g.NavMoveRequest || g.NavInitRequest || (IMGUI_DEBUG_NAV_SCORING && g.NavWindow != NULL);
    if (g.NavAnyRequest)
        IM_ASSERT(g.NavWindow != NULL);
}

// This needs to be called before we submit any widget (aka in or before Begin)
void ImGui::NavInitWindow(ImGuiWindow* window, bool force_reinit)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(window == g.NavWindow);
    bool init_for_nav = false;
    if (!(window->Flags & ImGuiWindowFlags_NoNavInputs))
        if (!(window->Flags & ImGuiWindowFlags_ChildWindow) || (window->Flags & ImGuiWindowFlags_Popup) || (window->NavLastIds[0] == 0) || force_reinit)
            init_for_nav = true;
    if (init_for_nav)
    {
        SetNavID(0, g.NavLayer);
        g.NavInitRequest = true;
        g.NavInitRequestFromMove = false;
        g.NavInitResultId = 0;
        g.NavInitResultRectRel = ImRect();
        NavUpdateAnyRequestFlag();
    }
    else
    {
        g.NavId = window->NavLastIds[0];
    }
}

static ImVec2 ImGui::NavCalcPreferredRefPos()
{
    ImGuiContext& g = *GImGui;
    if (g.NavDisableHighlight || !g.NavDisableMouseHover || !g.NavWindow)
    {
        // Mouse (we need a fallback in case the mouse becomes invalid after being used)
        if (IsMousePosValid(&g.IO.MousePos))
            return g.IO.MousePos;
        return g.LastValidMousePos;
    }
    else
    {
        // When navigation is active and mouse is disabled, decide on an arbitrary position around the bottom left of the currently navigated item.
        const ImRect& rect_rel = g.NavWindow->NavRectRel[g.NavLayer];
        ImVec2 pos = g.NavWindow->Pos + ImVec2(rect_rel.Min.x + ImMin(g.Style.FramePadding.x * 4, rect_rel.GetWidth()), rect_rel.Max.y - ImMin(g.Style.FramePadding.y, rect_rel.GetHeight()));
        ImRect visible_rect = GetViewportRect();
        return ImFloor(ImClamp(pos, visible_rect.Min, visible_rect.Max));   // ImFloor() is important because non-integer mouse position application in back-end might be lossy and result in undesirable non-zero delta.
    }
}

float ImGui::GetNavInputAmount(ImGuiNavInput n, ImGuiInputReadMode mode)
{
    ImGuiContext& g = *GImGui;
    if (mode == ImGuiInputReadMode_Down)
        return g.IO.NavInputs[n];                         // Instant, read analog input (0.0f..1.0f, as provided by user)

    const float t = g.IO.NavInputsDownDuration[n];
    if (t < 0.0f && mode == ImGuiInputReadMode_Released)  // Return 1.0f when just released, no repeat, ignore analog input.
        return (g.IO.NavInputsDownDurationPrev[n] >= 0.0f ? 1.0f : 0.0f);
    if (t < 0.0f)
        return 0.0f;
    if (mode == ImGuiInputReadMode_Pressed)               // Return 1.0f when just pressed, no repeat, ignore analog input.
        return (t == 0.0f) ? 1.0f : 0.0f;
    if (mode == ImGuiInputReadMode_Repeat)
        return (float)CalcTypematicPressedRepeatAmount(t, t - g.IO.DeltaTime, g.IO.KeyRepeatDelay * 0.80f, g.IO.KeyRepeatRate * 0.80f);
    if (mode == ImGuiInputReadMode_RepeatSlow)
        return (float)CalcTypematicPressedRepeatAmount(t, t - g.IO.DeltaTime, g.IO.KeyRepeatDelay * 1.00f, g.IO.KeyRepeatRate * 2.00f);
    if (mode == ImGuiInputReadMode_RepeatFast)
        return (float)CalcTypematicPressedRepeatAmount(t, t - g.IO.DeltaTime, g.IO.KeyRepeatDelay * 0.80f, g.IO.KeyRepeatRate * 0.30f);
    return 0.0f;
}

ImVec2 ImGui::GetNavInputAmount2d(ImGuiNavDirSourceFlags dir_sources, ImGuiInputReadMode mode, float slow_factor, float fast_factor)
{
    ImVec2 delta(0.0f, 0.0f);
    if (dir_sources & ImGuiNavDirSourceFlags_Keyboard)
        delta += ImVec2(GetNavInputAmount(ImGuiNavInput_KeyRight_, mode)   - GetNavInputAmount(ImGuiNavInput_KeyLeft_,   mode), GetNavInputAmount(ImGuiNavInput_KeyDown_,   mode) - GetNavInputAmount(ImGuiNavInput_KeyUp_,   mode));
    if (dir_sources & ImGuiNavDirSourceFlags_PadDPad)
        delta += ImVec2(GetNavInputAmount(ImGuiNavInput_DpadRight, mode)   - GetNavInputAmount(ImGuiNavInput_DpadLeft,   mode), GetNavInputAmount(ImGuiNavInput_DpadDown,   mode) - GetNavInputAmount(ImGuiNavInput_DpadUp,   mode));
    if (dir_sources & ImGuiNavDirSourceFlags_PadLStick)
        delta += ImVec2(GetNavInputAmount(ImGuiNavInput_LStickRight, mode) - GetNavInputAmount(ImGuiNavInput_LStickLeft, mode), GetNavInputAmount(ImGuiNavInput_LStickDown, mode) - GetNavInputAmount(ImGuiNavInput_LStickUp, mode));
    if (slow_factor != 0.0f && IsNavInputDown(ImGuiNavInput_TweakSlow))
        delta *= slow_factor;
    if (fast_factor != 0.0f && IsNavInputDown(ImGuiNavInput_TweakFast))
        delta *= fast_factor;
    return delta;
}

// Scroll to keep newly navigated item fully into view
// NB: We modify rect_rel by the amount we scrolled for, so it is immediately updated.
static void NavScrollToBringItemIntoView(ImGuiWindow* window, const ImRect& item_rect)
{
    ImRect window_rect(window->InnerMainRect.Min - ImVec2(1, 1), window->InnerMainRect.Max + ImVec2(1, 1));
    //GetOverlayDrawList(window)->AddRect(window_rect.Min, window_rect.Max, IM_COL32_WHITE); // [DEBUG]
    if (window_rect.Contains(item_rect))
        return;

    ImGuiContext& g = *GImGui;
    if (window->ScrollbarX && item_rect.Min.x < window_rect.Min.x)
    {
        window->ScrollTarget.x = item_rect.Min.x - window->Pos.x + window->Scroll.x - g.Style.ItemSpacing.x;
        window->ScrollTargetCenterRatio.x = 0.0f;
    }
    else if (window->ScrollbarX && item_rect.Max.x >= window_rect.Max.x)
    {
        window->ScrollTarget.x = item_rect.Max.x - window->Pos.x + window->Scroll.x + g.Style.ItemSpacing.x;
        window->ScrollTargetCenterRatio.x = 1.0f;
    }
    if (item_rect.Min.y < window_rect.Min.y)
    {
        window->ScrollTarget.y = item_rect.Min.y - window->Pos.y + window->Scroll.y - g.Style.ItemSpacing.y;
        window->ScrollTargetCenterRatio.y = 0.0f;
    }
    else if (item_rect.Max.y >= window_rect.Max.y)
    {
        window->ScrollTarget.y = item_rect.Max.y - window->Pos.y + window->Scroll.y + g.Style.ItemSpacing.y;
        window->ScrollTargetCenterRatio.y = 1.0f;
    }
}

static void ImGui::NavUpdate()
{
    ImGuiContext& g = *GImGui;
    g.IO.WantSetMousePos = false;
#if 0
    if (g.NavScoringCount > 0) IMGUI_DEBUG_LOG("NavScoringCount %d for '%s' layer %d (Init:%d, Move:%d)\n", g.FrameCount, g.NavScoringCount, g.NavWindow ? g.NavWindow->Name : "NULL", g.NavLayer, g.NavInitRequest || g.NavInitResultId != 0, g.NavMoveRequest);
#endif

    // Set input source as Gamepad when buttons are pressed before we map Keyboard (some features differs when used with Gamepad vs Keyboard)
    bool nav_keyboard_active = (g.IO.ConfigFlags & ImGuiConfigFlags_NavEnableKeyboard) != 0;
    bool nav_gamepad_active = (g.IO.ConfigFlags & ImGuiConfigFlags_NavEnableGamepad) != 0 && (g.IO.BackendFlags & ImGuiBackendFlags_HasGamepad) != 0;
    if (nav_gamepad_active)
        if (g.IO.NavInputs[ImGuiNavInput_Activate] > 0.0f || g.IO.NavInputs[ImGuiNavInput_Input] > 0.0f || g.IO.NavInputs[ImGuiNavInput_Cancel] > 0.0f || g.IO.NavInputs[ImGuiNavInput_Menu] > 0.0f)
            g.NavInputSource = ImGuiInputSource_NavGamepad;

    // Update Keyboard->Nav inputs mapping
    if (nav_keyboard_active)
    {
        #define NAV_MAP_KEY(_KEY, _NAV_INPUT) if (IsKeyDown(g.IO.KeyMap[_KEY])) { g.IO.NavInputs[_NAV_INPUT] = 1.0f; g.NavInputSource = ImGuiInputSource_NavKeyboard; }
        NAV_MAP_KEY(ImGuiKey_Space,     ImGuiNavInput_Activate );
        NAV_MAP_KEY(ImGuiKey_Enter,     ImGuiNavInput_Input    );
        NAV_MAP_KEY(ImGuiKey_Escape,    ImGuiNavInput_Cancel   );
        NAV_MAP_KEY(ImGuiKey_LeftArrow, ImGuiNavInput_KeyLeft_ );
        NAV_MAP_KEY(ImGuiKey_RightArrow,ImGuiNavInput_KeyRight_);
        NAV_MAP_KEY(ImGuiKey_UpArrow,   ImGuiNavInput_KeyUp_   );
        NAV_MAP_KEY(ImGuiKey_DownArrow, ImGuiNavInput_KeyDown_ );
        if (g.IO.KeyCtrl)   g.IO.NavInputs[ImGuiNavInput_TweakSlow] = 1.0f;
        if (g.IO.KeyShift)  g.IO.NavInputs[ImGuiNavInput_TweakFast] = 1.0f;
        if (g.IO.KeyAlt)    g.IO.NavInputs[ImGuiNavInput_KeyMenu_]  = 1.0f;
        #undef NAV_MAP_KEY
    }
    memcpy(g.IO.NavInputsDownDurationPrev, g.IO.NavInputsDownDuration, sizeof(g.IO.NavInputsDownDuration));
    for (int i = 0; i < IM_ARRAYSIZE(g.IO.NavInputs); i++)
        g.IO.NavInputsDownDuration[i] = (g.IO.NavInputs[i] > 0.0f) ? (g.IO.NavInputsDownDuration[i] < 0.0f ? 0.0f : g.IO.NavInputsDownDuration[i] + g.IO.DeltaTime) : -1.0f;

    // Process navigation init request (select first/default focus)
    if (g.NavInitResultId != 0 && (!g.NavDisableHighlight || g.NavInitRequestFromMove))
    {
        // Apply result from previous navigation init request (will typically select the first item, unless SetItemDefaultFocus() has been called)
        IM_ASSERT(g.NavWindow);
        if (g.NavInitRequestFromMove)
            SetNavIDWithRectRel(g.NavInitResultId, g.NavLayer, g.NavInitResultRectRel);
        else
            SetNavID(g.NavInitResultId, g.NavLayer);
        g.NavWindow->NavRectRel[g.NavLayer] = g.NavInitResultRectRel;
    }
    g.NavInitRequest = false;
    g.NavInitRequestFromMove = false;
    g.NavInitResultId = 0;
    g.NavJustMovedToId = 0;

    // Process navigation move request
    if (g.NavMoveRequest)
        NavUpdateMoveResult();

    // When a forwarded move request failed, we restore the highlight that we disabled during the forward frame
    if (g.NavMoveRequestForward == ImGuiNavForward_ForwardActive)
    {
        IM_ASSERT(g.NavMoveRequest);
        if (g.NavMoveResultLocal.ID == 0 && g.NavMoveResultOther.ID == 0)
            g.NavDisableHighlight = false;
        g.NavMoveRequestForward = ImGuiNavForward_None;
    }

    // Apply application mouse position movement, after we had a chance to process move request result.
    if (g.NavMousePosDirty && g.NavIdIsAlive)
    {
        // Set mouse position given our knowledge of the navigated item position from last frame
        if ((g.IO.ConfigFlags & ImGuiConfigFlags_NavEnableSetMousePos) && (g.IO.BackendFlags & ImGuiBackendFlags_HasSetMousePos))
        {
            if (!g.NavDisableHighlight && g.NavDisableMouseHover && g.NavWindow)
            {
                g.IO.MousePos = g.IO.MousePosPrev = NavCalcPreferredRefPos();
                g.IO.WantSetMousePos = true;
            }
        }
        g.NavMousePosDirty = false;
    }
    g.NavIdIsAlive = false;
    g.NavJustTabbedId = 0;
    IM_ASSERT(g.NavLayer == 0 || g.NavLayer == 1);

    // Store our return window (for returning from Layer 1 to Layer 0) and clear it as soon as we step back in our own Layer 0
    if (g.NavWindow)
        NavSaveLastChildNavWindow(g.NavWindow);
    if (g.NavWindow && g.NavWindow->NavLastChildNavWindow != NULL && g.NavLayer == 0)
        g.NavWindow->NavLastChildNavWindow = NULL;

    // Update CTRL+TAB and Windowing features (hold Square to move/resize/etc.)
    NavUpdateWindowing();

    // Set output flags for user application
    g.IO.NavActive = (nav_keyboard_active || nav_gamepad_active) && g.NavWindow && !(g.NavWindow->Flags & ImGuiWindowFlags_NoNavInputs);
    g.IO.NavVisible = (g.IO.NavActive && g.NavId != 0 && !g.NavDisableHighlight) || (g.NavWindowingTarget != NULL);

    // Process NavCancel input (to close a popup, get back to parent, clear focus)
    if (IsNavInputPressed(ImGuiNavInput_Cancel, ImGuiInputReadMode_Pressed))
    {
        if (g.ActiveId != 0)
        {
            if (!(g.ActiveIdBlockNavInputFlags & (1 << ImGuiNavInput_Cancel)))
                ClearActiveID();
        }
        else if (g.NavWindow && (g.NavWindow->Flags & ImGuiWindowFlags_ChildWindow) && !(g.NavWindow->Flags & ImGuiWindowFlags_Popup) && g.NavWindow->ParentWindow)
        {
            // Exit child window
            ImGuiWindow* child_window = g.NavWindow;
            ImGuiWindow* parent_window = g.NavWindow->ParentWindow;
            IM_ASSERT(child_window->ChildId != 0);
            FocusWindow(parent_window);
            SetNavID(child_window->ChildId, 0);
            g.NavIdIsAlive = false;
            if (g.NavDisableMouseHover)
                g.NavMousePosDirty = true;
        }
        else if (g.OpenPopupStack.Size > 0)
        {
            // Close open popup/menu
            if (!(g.OpenPopupStack.back().Window->Flags & ImGuiWindowFlags_Modal))
                ClosePopupToLevel(g.OpenPopupStack.Size - 1, true);
        }
        else if (g.NavLayer != 0)
        {
            // Leave the "menu" layer
            NavRestoreLayer(ImGuiNavLayer_Main);
        }
        else
        {
            // Clear NavLastId for popups but keep it for regular child window so we can leave one and come back where we were
            if (g.NavWindow && ((g.NavWindow->Flags & ImGuiWindowFlags_Popup) || !(g.NavWindow->Flags & ImGuiWindowFlags_ChildWindow)))
                g.NavWindow->NavLastIds[0] = 0;
            g.NavId = 0;
        }
    }

    // Process manual activation request
    g.NavActivateId = g.NavActivateDownId = g.NavActivatePressedId = g.NavInputId = 0;
    if (g.NavId != 0 && !g.NavDisableHighlight && !g.NavWindowingTarget && g.NavWindow && !(g.NavWindow->Flags & ImGuiWindowFlags_NoNavInputs))
    {
        bool activate_down = IsNavInputDown(ImGuiNavInput_Activate);
        bool activate_pressed = activate_down && IsNavInputPressed(ImGuiNavInput_Activate, ImGuiInputReadMode_Pressed);
        if (g.ActiveId == 0 && activate_pressed)
            g.NavActivateId = g.NavId;
        if ((g.ActiveId == 0 || g.ActiveId == g.NavId) && activate_down)
            g.NavActivateDownId = g.NavId;
        if ((g.ActiveId == 0 || g.ActiveId == g.NavId) && activate_pressed)
            g.NavActivatePressedId = g.NavId;
        if ((g.ActiveId == 0 || g.ActiveId == g.NavId) && IsNavInputPressed(ImGuiNavInput_Input, ImGuiInputReadMode_Pressed))
            g.NavInputId = g.NavId;
    }
    if (g.NavWindow && (g.NavWindow->Flags & ImGuiWindowFlags_NoNavInputs))
        g.NavDisableHighlight = true;
    if (g.NavActivateId != 0)
        IM_ASSERT(g.NavActivateDownId == g.NavActivateId);
    g.NavMoveRequest = false;

    // Process programmatic activation request
    if (g.NavNextActivateId != 0)
        g.NavActivateId = g.NavActivateDownId = g.NavActivatePressedId = g.NavInputId = g.NavNextActivateId;
    g.NavNextActivateId = 0;

    // Initiate directional inputs request
    const int allowed_dir_flags = (g.ActiveId == 0) ? ~0 : g.ActiveIdAllowNavDirFlags;
    if (g.NavMoveRequestForward == ImGuiNavForward_None)
    {
        g.NavMoveDir = ImGuiDir_None;
        g.NavMoveRequestFlags = ImGuiNavMoveFlags_None;
        if (g.NavWindow && !g.NavWindowingTarget && allowed_dir_flags && !(g.NavWindow->Flags & ImGuiWindowFlags_NoNavInputs))
        {
            if ((allowed_dir_flags & (1<<ImGuiDir_Left))  && IsNavInputPressedAnyOfTwo(ImGuiNavInput_DpadLeft, ImGuiNavInput_KeyLeft_, ImGuiInputReadMode_Repeat)) g.NavMoveDir = ImGuiDir_Left;
            if ((allowed_dir_flags & (1<<ImGuiDir_Right)) && IsNavInputPressedAnyOfTwo(ImGuiNavInput_DpadRight,ImGuiNavInput_KeyRight_,ImGuiInputReadMode_Repeat)) g.NavMoveDir = ImGuiDir_Right;
            if ((allowed_dir_flags & (1<<ImGuiDir_Up))    && IsNavInputPressedAnyOfTwo(ImGuiNavInput_DpadUp,   ImGuiNavInput_KeyUp_,   ImGuiInputReadMode_Repeat)) g.NavMoveDir = ImGuiDir_Up;
            if ((allowed_dir_flags & (1<<ImGuiDir_Down))  && IsNavInputPressedAnyOfTwo(ImGuiNavInput_DpadDown, ImGuiNavInput_KeyDown_, ImGuiInputReadMode_Repeat)) g.NavMoveDir = ImGuiDir_Down;
        }
        g.NavMoveClipDir = g.NavMoveDir;
    }
    else
    {
        // Forwarding previous request (which has been modified, e.g. wrap around menus rewrite the requests with a starting rectangle at the other side of the window)
        // (Preserve g.NavMoveRequestFlags, g.NavMoveClipDir which were set by the NavMoveRequestForward() function)
        IM_ASSERT(g.NavMoveDir != ImGuiDir_None && g.NavMoveClipDir != ImGuiDir_None);
        IM_ASSERT(g.NavMoveRequestForward == ImGuiNavForward_ForwardQueued);
        g.NavMoveRequestForward = ImGuiNavForward_ForwardActive;
    }

    // Update PageUp/PageDown scroll
    float nav_scoring_rect_offset_y = 0.0f;
    if (nav_keyboard_active)
        nav_scoring_rect_offset_y = NavUpdatePageUpPageDown(allowed_dir_flags);

    // If we initiate a movement request and have no current NavId, we initiate a InitDefautRequest that will be used as a fallback if the direction fails to find a match
    if (g.NavMoveDir != ImGuiDir_None)
    {
        g.NavMoveRequest = true;
        g.NavMoveDirLast = g.NavMoveDir;
    }
    if (g.NavMoveRequest && g.NavId == 0)
    {
        g.NavInitRequest = g.NavInitRequestFromMove = true;
        g.NavInitResultId = 0;
        g.NavDisableHighlight = false;
    }
    NavUpdateAnyRequestFlag();

    // Scrolling
    if (g.NavWindow && !(g.NavWindow->Flags & ImGuiWindowFlags_NoNavInputs) && !g.NavWindowingTarget)
    {
        // *Fallback* manual-scroll with Nav directional keys when window has no navigable item
        ImGuiWindow* window = g.NavWindow;
        const float scroll_speed = ImFloor(window->CalcFontSize() * 100 * g.IO.DeltaTime + 0.5f); // We need round the scrolling speed because sub-pixel scroll isn't reliably supported.
        if (window->DC.NavLayerActiveMask == 0x00 && window->DC.NavHasScroll && g.NavMoveRequest)
        {
            if (g.NavMoveDir == ImGuiDir_Left || g.NavMoveDir == ImGuiDir_Right)
                SetWindowScrollX(window, ImFloor(window->Scroll.x + ((g.NavMoveDir == ImGuiDir_Left) ? -1.0f : +1.0f) * scroll_speed));
            if (g.NavMoveDir == ImGuiDir_Up || g.NavMoveDir == ImGuiDir_Down)
                SetWindowScrollY(window, ImFloor(window->Scroll.y + ((g.NavMoveDir == ImGuiDir_Up) ? -1.0f : +1.0f) * scroll_speed));
        }

        // *Normal* Manual scroll with NavScrollXXX keys
        // Next movement request will clamp the NavId reference rectangle to the visible area, so navigation will resume within those bounds.
        ImVec2 scroll_dir = GetNavInputAmount2d(ImGuiNavDirSourceFlags_PadLStick, ImGuiInputReadMode_Down, 1.0f/10.0f, 10.0f);
        if (scroll_dir.x != 0.0f && window->ScrollbarX)
        {
            SetWindowScrollX(window, ImFloor(window->Scroll.x + scroll_dir.x * scroll_speed));
            g.NavMoveFromClampedRefRect = true;
        }
        if (scroll_dir.y != 0.0f)
        {
            SetWindowScrollY(window, ImFloor(window->Scroll.y + scroll_dir.y * scroll_speed));
            g.NavMoveFromClampedRefRect = true;
        }
    }

    // Reset search results
    g.NavMoveResultLocal.Clear();
    g.NavMoveResultLocalVisibleSet.Clear();
    g.NavMoveResultOther.Clear();

    // When we have manually scrolled (without using navigation) and NavId becomes out of bounds, we project its bounding box to the visible area to restart navigation within visible items
    if (g.NavMoveRequest && g.NavMoveFromClampedRefRect && g.NavLayer == 0)
    {
        ImGuiWindow* window = g.NavWindow;
        ImRect window_rect_rel(window->InnerMainRect.Min - window->Pos - ImVec2(1,1), window->InnerMainRect.Max - window->Pos + ImVec2(1,1));
        if (!window_rect_rel.Contains(window->NavRectRel[g.NavLayer]))
        {
            float pad = window->CalcFontSize() * 0.5f;
            window_rect_rel.Expand(ImVec2(-ImMin(window_rect_rel.GetWidth(), pad), -ImMin(window_rect_rel.GetHeight(), pad))); // Terrible approximation for the intent of starting navigation from first fully visible item
            window->NavRectRel[g.NavLayer].ClipWith(window_rect_rel);
            g.NavId = 0;
        }
        g.NavMoveFromClampedRefRect = false;
    }

    // For scoring we use a single segment on the left side our current item bounding box (not touching the edge to avoid box overlap with zero-spaced items)
    ImRect nav_rect_rel = (g.NavWindow && !g.NavWindow->NavRectRel[g.NavLayer].IsInverted()) ? g.NavWindow->NavRectRel[g.NavLayer] : ImRect(0,0,0,0);
    g.NavScoringRectScreen = g.NavWindow ? ImRect(g.NavWindow->Pos + nav_rect_rel.Min, g.NavWindow->Pos + nav_rect_rel.Max) : GetViewportRect();
    g.NavScoringRectScreen.TranslateY(nav_scoring_rect_offset_y);
    g.NavScoringRectScreen.Min.x = ImMin(g.NavScoringRectScreen.Min.x + 1.0f, g.NavScoringRectScreen.Max.x);
    g.NavScoringRectScreen.Max.x = g.NavScoringRectScreen.Min.x;
    IM_ASSERT(!g.NavScoringRectScreen.IsInverted()); // Ensure if we have a finite, non-inverted bounding box here will allows us to remove extraneous ImFabs() calls in NavScoreItem().
    //g.OverlayDrawList.AddRect(g.NavScoringRectScreen.Min, g.NavScoringRectScreen.Max, IM_COL32(255,200,0,255)); // [DEBUG]
    g.NavScoringCount = 0;
#if IMGUI_DEBUG_NAV_RECTS
    if (g.NavWindow) { for (int layer = 0; layer < 2; layer++) GetOverlayDrawList(g.NavWindow)->AddRect(g.NavWindow->Pos + g.NavWindow->NavRectRel[layer].Min, g.NavWindow->Pos + g.NavWindow->NavRectRel[layer].Max, IM_COL32(255,200,0,255)); } // [DEBUG]
    if (g.NavWindow) { ImU32 col = (!g.NavWindow->Hidden) ? IM_COL32(255,0,255,255) : IM_COL32(255,0,0,255); ImVec2 p = NavCalcPreferredRefPos(); char buf[32]; ImFormatString(buf, 32, "%d", g.NavLayer); GetOverlayDrawList(g.NavWindow)->AddCircleFilled(p, 3.0f, col); GetOverlayDrawList(g.NavWindow)->AddText(NULL, 13.0f, p + ImVec2(8,-4), col, buf); }
#endif
}

// Apply result from previous frame navigation directional move request
static void ImGui::NavUpdateMoveResult()
{
    ImGuiContext& g = *GImGui;
    if (g.NavMoveResultLocal.ID == 0 && g.NavMoveResultOther.ID == 0)
    {
        // In a situation when there is no results but NavId != 0, re-enable the Navigation highlight (because g.NavId is not considered as a possible result)
        if (g.NavId != 0)
        {
            g.NavDisableHighlight = false;
            g.NavDisableMouseHover = true;
        }
        return;
    }

    // Select which result to use
    ImGuiNavMoveResult* result = (g.NavMoveResultLocal.ID != 0) ? &g.NavMoveResultLocal : &g.NavMoveResultOther;

    // PageUp/PageDown behavior first jumps to the bottom/top mostly visible item, _otherwise_ use the result from the previous/next page.
    if (g.NavMoveRequestFlags & ImGuiNavMoveFlags_AlsoScoreVisibleSet)
        if (g.NavMoveResultLocalVisibleSet.ID != 0 && g.NavMoveResultLocalVisibleSet.ID != g.NavId)
            result = &g.NavMoveResultLocalVisibleSet;

    // Maybe entering a flattened child from the outside? In this case solve the tie using the regular scoring rules.
    if (result != &g.NavMoveResultOther && g.NavMoveResultOther.ID != 0 && g.NavMoveResultOther.Window->ParentWindow == g.NavWindow)
        if ((g.NavMoveResultOther.DistBox < result->DistBox) || (g.NavMoveResultOther.DistBox == result->DistBox && g.NavMoveResultOther.DistCenter < result->DistCenter))
            result = &g.NavMoveResultOther;
    IM_ASSERT(g.NavWindow && result->Window);

    // Scroll to keep newly navigated item fully into view.
    if (g.NavLayer == 0)
    {
        ImRect rect_abs = ImRect(result->RectRel.Min + result->Window->Pos, result->RectRel.Max + result->Window->Pos);
        NavScrollToBringItemIntoView(result->Window, rect_abs);

        // Estimate upcoming scroll so we can offset our result position so mouse position can be applied immediately after in NavUpdate()
        ImVec2 next_scroll = CalcNextScrollFromScrollTargetAndClamp(result->Window, false);
        ImVec2 delta_scroll = result->Window->Scroll - next_scroll;
        result->RectRel.Translate(delta_scroll);

        // Also scroll parent window to keep us into view if necessary (we could/should technically recurse back the whole the parent hierarchy).
        if (result->Window->Flags & ImGuiWindowFlags_ChildWindow)
            NavScrollToBringItemIntoView(result->Window->ParentWindow, ImRect(rect_abs.Min + delta_scroll, rect_abs.Max + delta_scroll));
    }

    ClearActiveID();
    g.NavWindow = result->Window;
    if (g.NavId != result->ID)
    {
        // Don't set NavJustMovedToId if just landed on the same spot (which may happen with ImGuiNavMoveFlags_AllowCurrentNavId)
        g.NavJustMovedToId = result->ID;
        g.NavJustMovedToSelectScopeId = result->SelectScopeId;
    }
    SetNavIDWithRectRel(result->ID, g.NavLayer, result->RectRel);
    g.NavMoveFromClampedRefRect = false;
}

static float ImGui::NavUpdatePageUpPageDown(int allowed_dir_flags)
{
    ImGuiContext& g = *GImGui;
    if (g.NavMoveDir == ImGuiDir_None && g.NavWindow && !(g.NavWindow->Flags & ImGuiWindowFlags_NoNavInputs) && !g.NavWindowingTarget && g.NavLayer == 0)
    {
        ImGuiWindow* window = g.NavWindow;
        bool page_up_held = IsKeyDown(g.IO.KeyMap[ImGuiKey_PageUp]) && (allowed_dir_flags & (1 << ImGuiDir_Up));
        bool page_down_held = IsKeyDown(g.IO.KeyMap[ImGuiKey_PageDown]) && (allowed_dir_flags & (1 << ImGuiDir_Down));
        if (page_up_held != page_down_held) // If either (not both) are pressed
        {
            if (window->DC.NavLayerActiveMask == 0x00 && window->DC.NavHasScroll)
            {
                // Fallback manual-scroll when window has no navigable item
                if (IsKeyPressed(g.IO.KeyMap[ImGuiKey_PageUp], true))
                    SetWindowScrollY(window, window->Scroll.y - window->InnerClipRect.GetHeight());
                else if (IsKeyPressed(g.IO.KeyMap[ImGuiKey_PageDown], true))
                    SetWindowScrollY(window, window->Scroll.y + window->InnerClipRect.GetHeight());
            }
            else
            {
                const ImRect& nav_rect_rel = window->NavRectRel[g.NavLayer];
                const float page_offset_y = ImMax(0.0f, window->InnerClipRect.GetHeight() - window->CalcFontSize() * 1.0f + nav_rect_rel.GetHeight());
                float nav_scoring_rect_offset_y = 0.0f;
                if (IsKeyPressed(g.IO.KeyMap[ImGuiKey_PageUp], true))
                {
                    nav_scoring_rect_offset_y = -page_offset_y;
                    g.NavMoveDir = ImGuiDir_Down; // Because our scoring rect is offset, we intentionally request the opposite direction (so we can always land on the last item)
                    g.NavMoveClipDir = ImGuiDir_Up;
                    g.NavMoveRequestFlags = ImGuiNavMoveFlags_AllowCurrentNavId | ImGuiNavMoveFlags_AlsoScoreVisibleSet;
                }
                else if (IsKeyPressed(g.IO.KeyMap[ImGuiKey_PageDown], true))
                {
                    nav_scoring_rect_offset_y = +page_offset_y;
                    g.NavMoveDir = ImGuiDir_Up; // Because our scoring rect is offset, we intentionally request the opposite direction (so we can always land on the last item)
                    g.NavMoveClipDir = ImGuiDir_Down;
                    g.NavMoveRequestFlags = ImGuiNavMoveFlags_AllowCurrentNavId | ImGuiNavMoveFlags_AlsoScoreVisibleSet;
                }
                return nav_scoring_rect_offset_y;
            }
        }
    }
    return 0.0f;
}

static int FindWindowFocusIndex(ImGuiWindow* window) // FIXME-OPT O(N)
{
    ImGuiContext& g = *GImGui;
    for (int i = g.WindowsFocusOrder.Size-1; i >= 0; i--)
        if (g.WindowsFocusOrder[i] == window)
            return i;
    return -1;
}

static ImGuiWindow* FindWindowNavFocusable(int i_start, int i_stop, int dir) // FIXME-OPT O(N)
{
    ImGuiContext& g = *GImGui;
    for (int i = i_start; i >= 0 && i < g.WindowsFocusOrder.Size && i != i_stop; i += dir)
        if (ImGui::IsWindowNavFocusable(g.WindowsFocusOrder[i]))
            return g.WindowsFocusOrder[i];
    return NULL;
}

static void NavUpdateWindowingHighlightWindow(int focus_change_dir)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.NavWindowingTarget);
    if (g.NavWindowingTarget->Flags & ImGuiWindowFlags_Modal)
        return;

    const int i_current = FindWindowFocusIndex(g.NavWindowingTarget);
    ImGuiWindow* window_target = FindWindowNavFocusable(i_current + focus_change_dir, -INT_MAX, focus_change_dir);
    if (!window_target)
        window_target = FindWindowNavFocusable((focus_change_dir < 0) ? (g.WindowsFocusOrder.Size - 1) : 0, i_current, focus_change_dir);
    if (window_target) // Don't reset windowing target if there's a single window in the list
        g.NavWindowingTarget = g.NavWindowingTargetAnim = window_target;
    g.NavWindowingToggleLayer = false;
}

// Window management mode (hold to: change focus/move/resize, tap to: toggle menu layer)
static void ImGui::NavUpdateWindowing()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* apply_focus_window = NULL;
    bool apply_toggle_layer = false;

    ImGuiWindow* modal_window = GetFrontMostPopupModal();
    if (modal_window != NULL)
    {
        g.NavWindowingTarget = NULL;
        return;
    }

    // Fade out
    if (g.NavWindowingTargetAnim && g.NavWindowingTarget == NULL)
    {
        g.NavWindowingHighlightAlpha = ImMax(g.NavWindowingHighlightAlpha - g.IO.DeltaTime * 10.0f, 0.0f);
        if (g.DimBgRatio <= 0.0f && g.NavWindowingHighlightAlpha <= 0.0f)
            g.NavWindowingTargetAnim = NULL;
    }

    // Start CTRL-TAB or Square+L/R window selection
    bool start_windowing_with_gamepad = !g.NavWindowingTarget && IsNavInputPressed(ImGuiNavInput_Menu, ImGuiInputReadMode_Pressed);
    bool start_windowing_with_keyboard = !g.NavWindowingTarget && g.IO.KeyCtrl && IsKeyPressedMap(ImGuiKey_Tab) && (g.IO.ConfigFlags & ImGuiConfigFlags_NavEnableKeyboard);
    if (start_windowing_with_gamepad || start_windowing_with_keyboard)
        if (ImGuiWindow* window = g.NavWindow ? g.NavWindow : FindWindowNavFocusable(g.WindowsFocusOrder.Size - 1, -INT_MAX, -1))
        {
            g.NavWindowingTarget = g.NavWindowingTargetAnim = window;
            g.NavWindowingTimer = g.NavWindowingHighlightAlpha = 0.0f;
            g.NavWindowingToggleLayer = start_windowing_with_keyboard ? false : true;
            g.NavInputSource = start_windowing_with_keyboard ? ImGuiInputSource_NavKeyboard : ImGuiInputSource_NavGamepad;
        }

    // Gamepad update
    g.NavWindowingTimer += g.IO.DeltaTime;
    if (g.NavWindowingTarget && g.NavInputSource == ImGuiInputSource_NavGamepad)
    {
        // Highlight only appears after a brief time holding the button, so that a fast tap on PadMenu (to toggle NavLayer) doesn't add visual noise
        g.NavWindowingHighlightAlpha = ImMax(g.NavWindowingHighlightAlpha, ImSaturate((g.NavWindowingTimer - NAV_WINDOWING_HIGHLIGHT_DELAY) / 0.05f));

        // Select window to focus
        const int focus_change_dir = (int)IsNavInputPressed(ImGuiNavInput_FocusPrev, ImGuiInputReadMode_RepeatSlow) - (int)IsNavInputPressed(ImGuiNavInput_FocusNext, ImGuiInputReadMode_RepeatSlow);
        if (focus_change_dir != 0)
        {
            NavUpdateWindowingHighlightWindow(focus_change_dir);
            g.NavWindowingHighlightAlpha = 1.0f;
        }

        // Single press toggles NavLayer, long press with L/R apply actual focus on release (until then the window was merely rendered front-most)
        if (!IsNavInputDown(ImGuiNavInput_Menu))
        {
            g.NavWindowingToggleLayer &= (g.NavWindowingHighlightAlpha < 1.0f); // Once button was held long enough we don't consider it a tap-to-toggle-layer press anymore.
            if (g.NavWindowingToggleLayer && g.NavWindow)
                apply_toggle_layer = true;
            else if (!g.NavWindowingToggleLayer)
                apply_focus_window = g.NavWindowingTarget;
            g.NavWindowingTarget = NULL;
        }
    }

    // Keyboard: Focus
    if (g.NavWindowingTarget && g.NavInputSource == ImGuiInputSource_NavKeyboard)
    {
        // Visuals only appears after a brief time after pressing TAB the first time, so that a fast CTRL+TAB doesn't add visual noise
        g.NavWindowingHighlightAlpha = ImMax(g.NavWindowingHighlightAlpha, ImSaturate((g.NavWindowingTimer - NAV_WINDOWING_HIGHLIGHT_DELAY) / 0.05f)); // 1.0f
        if (IsKeyPressedMap(ImGuiKey_Tab, true))
            NavUpdateWindowingHighlightWindow(g.IO.KeyShift ? +1 : -1);
        if (!g.IO.KeyCtrl)
            apply_focus_window = g.NavWindowingTarget;
    }

    // Keyboard: Press and Release ALT to toggle menu layer
    // FIXME: We lack an explicit IO variable for "is the imgui window focused", so compare mouse validity to detect the common case of back-end clearing releases all keys on ALT-TAB
    if ((g.ActiveId == 0 || g.ActiveIdAllowOverlap) && IsNavInputPressed(ImGuiNavInput_KeyMenu_, ImGuiInputReadMode_Released))
        if (IsMousePosValid(&g.IO.MousePos) == IsMousePosValid(&g.IO.MousePosPrev))
            apply_toggle_layer = true;

    // Move window
    if (g.NavWindowingTarget && !(g.NavWindowingTarget->Flags & ImGuiWindowFlags_NoMove))
    {
        ImVec2 move_delta;
        if (g.NavInputSource == ImGuiInputSource_NavKeyboard && !g.IO.KeyShift)
            move_delta = GetNavInputAmount2d(ImGuiNavDirSourceFlags_Keyboard, ImGuiInputReadMode_Down);
        if (g.NavInputSource == ImGuiInputSource_NavGamepad)
            move_delta = GetNavInputAmount2d(ImGuiNavDirSourceFlags_PadLStick, ImGuiInputReadMode_Down);
        if (move_delta.x != 0.0f || move_delta.y != 0.0f)
        {
            const float NAV_MOVE_SPEED = 800.0f;
            const float move_speed = ImFloor(NAV_MOVE_SPEED * g.IO.DeltaTime * ImMin(g.IO.DisplayFramebufferScale.x, g.IO.DisplayFramebufferScale.y)); // FIXME: Doesn't code variable framerate very well
            g.NavWindowingTarget->RootWindow->Pos += move_delta * move_speed;
            g.NavDisableMouseHover = true;
            MarkIniSettingsDirty(g.NavWindowingTarget);
        }
    }

    // Apply final focus
    if (apply_focus_window && (g.NavWindow == NULL || apply_focus_window != g.NavWindow->RootWindow))
    {
        g.NavDisableHighlight = false;
        g.NavDisableMouseHover = true;
        apply_focus_window = NavRestoreLastChildNavWindow(apply_focus_window);
        ClosePopupsOverWindow(apply_focus_window);
        FocusWindow(apply_focus_window);
        if (apply_focus_window->NavLastIds[0] == 0)
            NavInitWindow(apply_focus_window, false);

        // If the window only has a menu layer, select it directly
        if (apply_focus_window->DC.NavLayerActiveMask == (1 << ImGuiNavLayer_Menu))
            g.NavLayer = ImGuiNavLayer_Menu;
    }
    if (apply_focus_window)
        g.NavWindowingTarget = NULL;

    // Apply menu/layer toggle
    if (apply_toggle_layer && g.NavWindow)
    {
        // Move to parent menu if necessary
        ImGuiWindow* new_nav_window = g.NavWindow;
        while ((new_nav_window->DC.NavLayerActiveMask & (1 << 1)) == 0
            && (new_nav_window->Flags & ImGuiWindowFlags_ChildWindow) != 0
            && (new_nav_window->Flags & (ImGuiWindowFlags_Popup | ImGuiWindowFlags_ChildMenu)) == 0)
            new_nav_window = new_nav_window->ParentWindow;
        if (new_nav_window != g.NavWindow)
        {
            ImGuiWindow* old_nav_window = g.NavWindow;
            FocusWindow(new_nav_window);
            new_nav_window->NavLastChildNavWindow = old_nav_window;
        }
        g.NavDisableHighlight = false;
        g.NavDisableMouseHover = true;
        NavRestoreLayer((g.NavWindow->DC.NavLayerActiveMask & (1 << ImGuiNavLayer_Menu)) ? (ImGuiNavLayer)((int)g.NavLayer ^ 1) : ImGuiNavLayer_Main);
    }
}

// Window has already passed the IsWindowNavFocusable()
static const char* GetFallbackWindowNameForWindowingList(ImGuiWindow* window)
{
    if (window->Flags & ImGuiWindowFlags_Popup)
        return "(Popup)";
    if ((window->Flags & ImGuiWindowFlags_MenuBar) && strcmp(window->Name, "##MainMenuBar") == 0)
        return "(Main menu bar)";
    return "(Untitled)";
}

// Overlay displayed when using CTRL+TAB. Called by EndFrame().
void ImGui::NavUpdateWindowingList()
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.NavWindowingTarget != NULL);

    if (g.NavWindowingTimer < NAV_WINDOWING_LIST_APPEAR_DELAY)
        return;

    if (g.NavWindowingList == NULL)
        g.NavWindowingList = FindWindowByName("###NavWindowingList");
    SetNextWindowSizeConstraints(ImVec2(g.IO.DisplaySize.x * 0.20f, g.IO.DisplaySize.y * 0.20f), ImVec2(FLT_MAX, FLT_MAX));
    SetNextWindowPos(g.IO.DisplaySize * 0.5f, ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    PushStyleVar(ImGuiStyleVar_WindowPadding, g.Style.WindowPadding * 2.0f);
    Begin("###NavWindowingList", NULL, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings);
    for (int n = g.WindowsFocusOrder.Size - 1; n >= 0; n--)
    {
        ImGuiWindow* window = g.WindowsFocusOrder[n];
        if (!IsWindowNavFocusable(window))
            continue;
        const char* label = window->Name;
        if (label == FindRenderedTextEnd(label))
            label = GetFallbackWindowNameForWindowingList(window);
        Selectable(label, g.NavWindowingTarget == window);
    }
    End();
    PopStyleVar();
}

//-----------------------------------------------------------------------------
// [SECTION] COLUMNS
// In the current version, Columns are very weak. Needs to be replaced with a more full-featured system.
//-----------------------------------------------------------------------------

void ImGui::NextColumn()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems || window->DC.ColumnsSet == NULL)
        return;

    ImGuiContext& g = *GImGui;
    PopItemWidth();
    PopClipRect();

    ImGuiColumnsSet* columns = window->DC.ColumnsSet;
    columns->LineMaxY = ImMax(columns->LineMaxY, window->DC.CursorPos.y);
    if (++columns->Current < columns->Count)
    {
        // Columns 1+ cancel out IndentX
        window->DC.ColumnsOffset.x = GetColumnOffset(columns->Current) - window->DC.Indent.x + g.Style.ItemSpacing.x;
        window->DrawList->ChannelsSetCurrent(columns->Current);
    }
    else
    {
        window->DC.ColumnsOffset.x = 0.0f;
        window->DrawList->ChannelsSetCurrent(0);
        columns->Current = 0;
        columns->LineMinY = columns->LineMaxY;
    }
    window->DC.CursorPos.x = (float)(int)(window->Pos.x + window->DC.Indent.x + window->DC.ColumnsOffset.x);
    window->DC.CursorPos.y = columns->LineMinY;
    window->DC.CurrentLineSize = ImVec2(0.0f, 0.0f);
    window->DC.CurrentLineTextBaseOffset = 0.0f;

    PushColumnClipRect();
    PushItemWidth(GetColumnWidth() * 0.65f);  // FIXME: Move on columns setup
}

int ImGui::GetColumnIndex()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.ColumnsSet ? window->DC.ColumnsSet->Current : 0;
}

int ImGui::GetColumnsCount()
{
    ImGuiWindow* window = GetCurrentWindowRead();
    return window->DC.ColumnsSet ? window->DC.ColumnsSet->Count : 1;
}

static float OffsetNormToPixels(const ImGuiColumnsSet* columns, float offset_norm)
{
    return offset_norm * (columns->MaxX - columns->MinX);
}

static float PixelsToOffsetNorm(const ImGuiColumnsSet* columns, float offset)
{
    return offset / (columns->MaxX - columns->MinX);
}

static inline float GetColumnsRectHalfWidth() { return 4.0f; }

static float GetDraggedColumnOffset(ImGuiColumnsSet* columns, int column_index)
{
    // Active (dragged) column always follow mouse. The reason we need this is that dragging a column to the right edge of an auto-resizing
    // window creates a feedback loop because we store normalized positions. So while dragging we enforce absolute positioning.
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    IM_ASSERT(column_index > 0); // We are not supposed to drag column 0.
    IM_ASSERT(g.ActiveId == columns->ID + ImGuiID(column_index));

    float x = g.IO.MousePos.x - g.ActiveIdClickOffset.x + GetColumnsRectHalfWidth() - window->Pos.x;
    x = ImMax(x, ImGui::GetColumnOffset(column_index - 1) + g.Style.ColumnsMinSpacing);
    if ((columns->Flags & ImGuiColumnsFlags_NoPreserveWidths))
        x = ImMin(x, ImGui::GetColumnOffset(column_index + 1) - g.Style.ColumnsMinSpacing);

    return x;
}

float ImGui::GetColumnOffset(int column_index)
{
    ImGuiWindow* window = GetCurrentWindowRead();
    ImGuiColumnsSet* columns = window->DC.ColumnsSet;
    IM_ASSERT(columns != NULL);

    if (column_index < 0)
        column_index = columns->Current;
    IM_ASSERT(column_index < columns->Columns.Size);

    const float t = columns->Columns[column_index].OffsetNorm;
    const float x_offset = ImLerp(columns->MinX, columns->MaxX, t);
    return x_offset;
}

static float GetColumnWidthEx(ImGuiColumnsSet* columns, int column_index, bool before_resize = false)
{
    if (column_index < 0)
        column_index = columns->Current;

    float offset_norm;
    if (before_resize)
        offset_norm = columns->Columns[column_index + 1].OffsetNormBeforeResize - columns->Columns[column_index].OffsetNormBeforeResize;
    else
        offset_norm = columns->Columns[column_index + 1].OffsetNorm - columns->Columns[column_index].OffsetNorm;
    return OffsetNormToPixels(columns, offset_norm);
}

float ImGui::GetColumnWidth(int column_index)
{
    ImGuiWindow* window = GetCurrentWindowRead();
    ImGuiColumnsSet* columns = window->DC.ColumnsSet;
    IM_ASSERT(columns != NULL);

    if (column_index < 0)
        column_index = columns->Current;
    return OffsetNormToPixels(columns, columns->Columns[column_index + 1].OffsetNorm - columns->Columns[column_index].OffsetNorm);
}

void ImGui::SetColumnOffset(int column_index, float offset)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    ImGuiColumnsSet* columns = window->DC.ColumnsSet;
    IM_ASSERT(columns != NULL);

    if (column_index < 0)
        column_index = columns->Current;
    IM_ASSERT(column_index < columns->Columns.Size);

    const bool preserve_width = !(columns->Flags & ImGuiColumnsFlags_NoPreserveWidths) && (column_index < columns->Count-1);
    const float width = preserve_width ? GetColumnWidthEx(columns, column_index, columns->IsBeingResized) : 0.0f;

    if (!(columns->Flags & ImGuiColumnsFlags_NoForceWithinWindow))
        offset = ImMin(offset, columns->MaxX - g.Style.ColumnsMinSpacing * (columns->Count - column_index));
    columns->Columns[column_index].OffsetNorm = PixelsToOffsetNorm(columns, offset - columns->MinX);

    if (preserve_width)
        SetColumnOffset(column_index + 1, offset + ImMax(g.Style.ColumnsMinSpacing, width));
}

void ImGui::SetColumnWidth(int column_index, float width)
{
    ImGuiWindow* window = GetCurrentWindowRead();
    ImGuiColumnsSet* columns = window->DC.ColumnsSet;
    IM_ASSERT(columns != NULL);

    if (column_index < 0)
        column_index = columns->Current;
    SetColumnOffset(column_index + 1, GetColumnOffset(column_index) + width);
}

void ImGui::PushColumnClipRect(int column_index)
{
    ImGuiWindow* window = GetCurrentWindowRead();
    ImGuiColumnsSet* columns = window->DC.ColumnsSet;
    if (column_index < 0)
        column_index = columns->Current;

    PushClipRect(columns->Columns[column_index].ClipRect.Min, columns->Columns[column_index].ClipRect.Max, false);
}

static ImGuiColumnsSet* FindOrAddColumnsSet(ImGuiWindow* window, ImGuiID id)
{
    for (int n = 0; n < window->ColumnsStorage.Size; n++)
        if (window->ColumnsStorage[n].ID == id)
            return &window->ColumnsStorage[n];

    window->ColumnsStorage.push_back(ImGuiColumnsSet());
    ImGuiColumnsSet* columns = &window->ColumnsStorage.back();
    columns->ID = id;
    return columns;
}

void ImGui::BeginColumns(const char* str_id, int columns_count, ImGuiColumnsFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();

    IM_ASSERT(columns_count > 1);
    IM_ASSERT(window->DC.ColumnsSet == NULL); // Nested columns are currently not supported

    // Differentiate column ID with an arbitrary prefix for cases where users name their columns set the same as another widget.
    // In addition, when an identifier isn't explicitly provided we include the number of columns in the hash to make it uniquer.
    PushID(0x11223347 + (str_id ? 0 : columns_count));
    ImGuiID id = window->GetID(str_id ? str_id : "columns");
    PopID();

    // Acquire storage for the columns set
    ImGuiColumnsSet* columns = FindOrAddColumnsSet(window, id);
    IM_ASSERT(columns->ID == id);
    columns->Current = 0;
    columns->Count = columns_count;
    columns->Flags = flags;
    window->DC.ColumnsSet = columns;

    // Set state for first column
    const float content_region_width = (window->SizeContentsExplicit.x != 0.0f) ? (window->SizeContentsExplicit.x) : (window->InnerClipRect.Max.x - window->Pos.x);
    columns->MinX = window->DC.Indent.x - g.Style.ItemSpacing.x; // Lock our horizontal range
    columns->MaxX = ImMax(content_region_width - window->Scroll.x, columns->MinX + 1.0f);
    columns->StartPosY = window->DC.CursorPos.y;
    columns->StartMaxPosX = window->DC.CursorMaxPos.x;
    columns->LineMinY = columns->LineMaxY = window->DC.CursorPos.y;
    window->DC.ColumnsOffset.x = 0.0f;
    window->DC.CursorPos.x = (float)(int)(window->Pos.x + window->DC.Indent.x + window->DC.ColumnsOffset.x);

    // Clear data if columns count changed
    if (columns->Columns.Size != 0 && columns->Columns.Size != columns_count + 1)
        columns->Columns.resize(0);

    // Initialize defaults
    columns->IsFirstFrame = (columns->Columns.Size == 0);
    if (columns->Columns.Size == 0)
    {
        columns->Columns.reserve(columns_count + 1);
        for (int n = 0; n < columns_count + 1; n++)
        {
            ImGuiColumnData column;
            column.OffsetNorm = n / (float)columns_count;
            columns->Columns.push_back(column);
        }
    }

    for (int n = 0; n < columns_count; n++)
    {
        // Compute clipping rectangle
        ImGuiColumnData* column = &columns->Columns[n];
        float clip_x1 = ImFloor(0.5f + window->Pos.x + GetColumnOffset(n) - 1.0f);
        float clip_x2 = ImFloor(0.5f + window->Pos.x + GetColumnOffset(n + 1) - 1.0f);
        column->ClipRect = ImRect(clip_x1, -FLT_MAX, clip_x2, +FLT_MAX);
        column->ClipRect.ClipWith(window->ClipRect);
    }

    window->DrawList->ChannelsSplit(columns->Count);
    PushColumnClipRect();
    PushItemWidth(GetColumnWidth() * 0.65f);
}

void ImGui::EndColumns()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();
    ImGuiColumnsSet* columns = window->DC.ColumnsSet;
    IM_ASSERT(columns != NULL);

    PopItemWidth();
    PopClipRect();
    window->DrawList->ChannelsMerge();

    columns->LineMaxY = ImMax(columns->LineMaxY, window->DC.CursorPos.y);
    window->DC.CursorPos.y = columns->LineMaxY;
    if (!(columns->Flags & ImGuiColumnsFlags_GrowParentContentsSize))
        window->DC.CursorMaxPos.x = columns->StartMaxPosX;  // Restore cursor max pos, as columns don't grow parent

    // Draw columns borders and handle resize
    bool is_being_resized = false;
    if (!(columns->Flags & ImGuiColumnsFlags_NoBorder) && !window->SkipItems)
    {
        const float y1 = columns->StartPosY;
        const float y2 = window->DC.CursorPos.y;
        int dragging_column = -1;
        for (int n = 1; n < columns->Count; n++)
        {
            float x = window->Pos.x + GetColumnOffset(n);
            const ImGuiID column_id = columns->ID + ImGuiID(n);
            const float column_hw = GetColumnsRectHalfWidth(); // Half-width for interaction
            const ImRect column_rect(ImVec2(x - column_hw, y1), ImVec2(x + column_hw, y2));
            KeepAliveID(column_id);
            if (IsClippedEx(column_rect, column_id, false))
                continue;

            bool hovered = false, held = false;
            if (!(columns->Flags & ImGuiColumnsFlags_NoResize))
            {
                ButtonBehavior(column_rect, column_id, &hovered, &held);
                if (hovered || held)
                    g.MouseCursor = ImGuiMouseCursor_ResizeEW;
                if (held && !(columns->Columns[n].Flags & ImGuiColumnsFlags_NoResize))
                    dragging_column = n;
            }

            // Draw column (we clip the Y boundaries CPU side because very long triangles are mishandled by some GPU drivers.)
            const ImU32 col = GetColorU32(held ? ImGuiCol_SeparatorActive : hovered ? ImGuiCol_SeparatorHovered : ImGuiCol_Separator);
            const float xi = (float)(int)x;
            window->DrawList->AddLine(ImVec2(xi, ImMax(y1 + 1.0f, window->ClipRect.Min.y)), ImVec2(xi, ImMin(y2, window->ClipRect.Max.y)), col);
        }

        // Apply dragging after drawing the column lines, so our rendered lines are in sync with how items were displayed during the frame.
        if (dragging_column != -1)
        {
            if (!columns->IsBeingResized)
                for (int n = 0; n < columns->Count + 1; n++)
                    columns->Columns[n].OffsetNormBeforeResize = columns->Columns[n].OffsetNorm;
            columns->IsBeingResized = is_being_resized = true;
            float x = GetDraggedColumnOffset(columns, dragging_column);
            SetColumnOffset(dragging_column, x);
        }
    }
    columns->IsBeingResized = is_being_resized;

    window->DC.ColumnsSet = NULL;
    window->DC.ColumnsOffset.x = 0.0f;
    window->DC.CursorPos.x = (float)(int)(window->Pos.x + window->DC.Indent.x + window->DC.ColumnsOffset.x);
}

// [2018-03: This is currently the only public API, while we are working on making BeginColumns/EndColumns user-facing]
void ImGui::Columns(int columns_count, const char* id, bool border)
{
    ImGuiWindow* window = GetCurrentWindow();
    IM_ASSERT(columns_count >= 1);

    ImGuiColumnsFlags flags = (border ? 0 : ImGuiColumnsFlags_NoBorder);
    //flags |= ImGuiColumnsFlags_NoPreserveWidths; // NB: Legacy behavior
    if (window->DC.ColumnsSet != NULL && window->DC.ColumnsSet->Count == columns_count && window->DC.ColumnsSet->Flags == flags)
        return;

    if (window->DC.ColumnsSet != NULL)
        EndColumns();

    if (columns_count != 1)
        BeginColumns(id, columns_count, flags);
}

//-----------------------------------------------------------------------------
// [SECTION] DRAG AND DROP
//-----------------------------------------------------------------------------

void ImGui::ClearDragDrop()
{
    ImGuiContext& g = *GImGui;
    g.DragDropActive = false;
    g.DragDropPayload.Clear();
    g.DragDropAcceptFlags = ImGuiDragDropFlags_None;
    g.DragDropAcceptIdCurr = g.DragDropAcceptIdPrev = 0;
    g.DragDropAcceptIdCurrRectSurface = FLT_MAX;
    g.DragDropAcceptFrameCount = -1;

    g.DragDropPayloadBufHeap.clear();
    memset(&g.DragDropPayloadBufLocal, 0, sizeof(g.DragDropPayloadBufLocal));
}

// Call when current ID is active.
// When this returns true you need to: a) call SetDragDropPayload() exactly once, b) you may render the payload visual/description, c) call EndDragDropSource()
bool ImGui::BeginDragDropSource(ImGuiDragDropFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    bool source_drag_active = false;
    ImGuiID source_id = 0;
    ImGuiID source_parent_id = 0;
    int mouse_button = 0;
    if (!(flags & ImGuiDragDropFlags_SourceExtern))
    {
        source_id = window->DC.LastItemId;
        if (source_id != 0 && g.ActiveId != source_id) // Early out for most common case
            return false;
        if (g.IO.MouseDown[mouse_button] == false)
            return false;

        if (source_id == 0)
        {
            // If you want to use BeginDragDropSource() on an item with no unique identifier for interaction, such as Text() or Image(), you need to:
            // A) Read the explanation below, B) Use the ImGuiDragDropFlags_SourceAllowNullID flag, C) Swallow your programmer pride.
            if (!(flags & ImGuiDragDropFlags_SourceAllowNullID))
            {
                IM_ASSERT(0);
                return false;
            }

            // Magic fallback (=somehow reprehensible) to handle items with no assigned ID, e.g. Text(), Image()
            // We build a throwaway ID based on current ID stack + relative AABB of items in window.
            // THE IDENTIFIER WON'T SURVIVE ANY REPOSITIONING OF THE WIDGET, so if your widget moves your dragging operation will be canceled.
            // We don't need to maintain/call ClearActiveID() as releasing the button will early out this function and trigger !ActiveIdIsAlive.
            bool is_hovered = (window->DC.LastItemStatusFlags & ImGuiItemStatusFlags_HoveredRect) != 0;
            if (!is_hovered && (g.ActiveId == 0 || g.ActiveIdWindow != window))
                return false;
            source_id = window->DC.LastItemId = window->GetIDFromRectangle(window->DC.LastItemRect);
            if (is_hovered)
                SetHoveredID(source_id);
            if (is_hovered && g.IO.MouseClicked[mouse_button])
            {
                SetActiveID(source_id, window);
                FocusWindow(window);
            }
            if (g.ActiveId == source_id) // Allow the underlying widget to display/return hovered during the mouse release frame, else we would get a flicker.
                g.ActiveIdAllowOverlap = is_hovered;
        }
        else
        {
            g.ActiveIdAllowOverlap = false;
        }
        if (g.ActiveId != source_id)
            return false;
        source_parent_id = window->IDStack.back();
        source_drag_active = IsMouseDragging(mouse_button);
    }
    else
    {
        window = NULL;
        source_id = ImHashStr("#SourceExtern", 0);
        source_drag_active = true;
    }

    if (source_drag_active)
    {
        if (!g.DragDropActive)
        {
            IM_ASSERT(source_id != 0);
            ClearDragDrop();
            ImGuiPayload& payload = g.DragDropPayload;
            payload.SourceId = source_id;
            payload.SourceParentId = source_parent_id;
            g.DragDropActive = true;
            g.DragDropSourceFlags = flags;
            g.DragDropMouseButton = mouse_button;
        }
        g.DragDropSourceFrameCount = g.FrameCount;
        g.DragDropWithinSourceOrTarget = true;

        if (!(flags & ImGuiDragDropFlags_SourceNoPreviewTooltip))
        {
            // Target can request the Source to not display its tooltip (we use a dedicated flag to make this request explicit)
            // We unfortunately can't just modify the source flags and skip the call to BeginTooltip, as caller may be emitting contents.
            BeginTooltip();
            if (g.DragDropAcceptIdPrev && (g.DragDropAcceptFlags & ImGuiDragDropFlags_AcceptNoPreviewTooltip))
            {
                ImGuiWindow* tooltip_window = g.CurrentWindow;
                tooltip_window->SkipItems = true;
                tooltip_window->HiddenFramesRegular = 1;
            }
        }

        if (!(flags & ImGuiDragDropFlags_SourceNoDisableHover) && !(flags & ImGuiDragDropFlags_SourceExtern))
            window->DC.LastItemStatusFlags &= ~ImGuiItemStatusFlags_HoveredRect;

        return true;
    }
    return false;
}

void ImGui::EndDragDropSource()
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.DragDropActive);
    IM_ASSERT(g.DragDropWithinSourceOrTarget && "Not after a BeginDragDropSource()?");

    if (!(g.DragDropSourceFlags & ImGuiDragDropFlags_SourceNoPreviewTooltip))
        EndTooltip();

    // Discard the drag if have not called SetDragDropPayload()
    if (g.DragDropPayload.DataFrameCount == -1)
        ClearDragDrop();
    g.DragDropWithinSourceOrTarget = false;
}

// Use 'cond' to choose to submit payload on drag start or every frame
bool ImGui::SetDragDropPayload(const char* type, const void* data, size_t data_size, ImGuiCond cond)
{
    ImGuiContext& g = *GImGui;
    ImGuiPayload& payload = g.DragDropPayload;
    if (cond == 0)
        cond = ImGuiCond_Always;

    IM_ASSERT(type != NULL);
    IM_ASSERT(strlen(type) < IM_ARRAYSIZE(payload.DataType) && "Payload type can be at most 32 characters long");
    IM_ASSERT((data != NULL && data_size > 0) || (data == NULL && data_size == 0));
    IM_ASSERT(cond == ImGuiCond_Always || cond == ImGuiCond_Once);
    IM_ASSERT(payload.SourceId != 0);                               // Not called between BeginDragDropSource() and EndDragDropSource()

    if (cond == ImGuiCond_Always || payload.DataFrameCount == -1)
    {
        // Copy payload
        ImStrncpy(payload.DataType, type, IM_ARRAYSIZE(payload.DataType));
        g.DragDropPayloadBufHeap.resize(0);
        if (data_size > sizeof(g.DragDropPayloadBufLocal))
        {
            // Store in heap
            g.DragDropPayloadBufHeap.resize((int)data_size);
            payload.Data = g.DragDropPayloadBufHeap.Data;
            memcpy(payload.Data, data, data_size);
        }
        else if (data_size > 0)
        {
            // Store locally
            memset(&g.DragDropPayloadBufLocal, 0, sizeof(g.DragDropPayloadBufLocal));
            payload.Data = g.DragDropPayloadBufLocal;
            memcpy(payload.Data, data, data_size);
        }
        else
        {
            payload.Data = NULL;
        }
        payload.DataSize = (int)data_size;
    }
    payload.DataFrameCount = g.FrameCount;

    return (g.DragDropAcceptFrameCount == g.FrameCount) || (g.DragDropAcceptFrameCount == g.FrameCount - 1);
}

bool ImGui::BeginDragDropTargetCustom(const ImRect& bb, ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    if (!g.DragDropActive)
        return false;

    ImGuiWindow* window = g.CurrentWindow;
    if (g.HoveredWindow == NULL || window->RootWindow != g.HoveredWindow->RootWindow)
        return false;
    IM_ASSERT(id != 0);
    if (!IsMouseHoveringRect(bb.Min, bb.Max) || (id == g.DragDropPayload.SourceId))
        return false;
    if (window->SkipItems)
        return false;

    IM_ASSERT(g.DragDropWithinSourceOrTarget == false);
    g.DragDropTargetRect = bb;
    g.DragDropTargetId = id;
    g.DragDropWithinSourceOrTarget = true;
    return true;
}

// We don't use BeginDragDropTargetCustom() and duplicate its code because:
// 1) we use LastItemRectHoveredRect which handles items that pushes a temporarily clip rectangle in their code. Calling BeginDragDropTargetCustom(LastItemRect) would not handle them.
// 2) and it's faster. as this code may be very frequently called, we want to early out as fast as we can.
// Also note how the HoveredWindow test is positioned differently in both functions (in both functions we optimize for the cheapest early out case)
bool ImGui::BeginDragDropTarget()
{
    ImGuiContext& g = *GImGui;
    if (!g.DragDropActive)
        return false;

    ImGuiWindow* window = g.CurrentWindow;
    if (!(window->DC.LastItemStatusFlags & ImGuiItemStatusFlags_HoveredRect))
        return false;
    if (g.HoveredWindow == NULL || window->RootWindow != g.HoveredWindow->RootWindow)
        return false;

    const ImRect& display_rect = (window->DC.LastItemStatusFlags & ImGuiItemStatusFlags_HasDisplayRect) ? window->DC.LastItemDisplayRect : window->DC.LastItemRect;
    ImGuiID id = window->DC.LastItemId;
    if (id == 0)
        id = window->GetIDFromRectangle(display_rect);
    if (g.DragDropPayload.SourceId == id)
        return false;

    IM_ASSERT(g.DragDropWithinSourceOrTarget == false);
    g.DragDropTargetRect = display_rect;
    g.DragDropTargetId = id;
    g.DragDropWithinSourceOrTarget = true;
    return true;
}

bool ImGui::IsDragDropPayloadBeingAccepted()
{
    ImGuiContext& g = *GImGui;
    return g.DragDropActive && g.DragDropAcceptIdPrev != 0;
}

const ImGuiPayload* ImGui::AcceptDragDropPayload(const char* type, ImGuiDragDropFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    ImGuiPayload& payload = g.DragDropPayload;
    IM_ASSERT(g.DragDropActive);                        // Not called between BeginDragDropTarget() and EndDragDropTarget() ?
    IM_ASSERT(payload.DataFrameCount != -1);            // Forgot to call EndDragDropTarget() ?
    if (type != NULL && !payload.IsDataType(type))
        return NULL;

    // Accept smallest drag target bounding box, this allows us to nest drag targets conveniently without ordering constraints.
    // NB: We currently accept NULL id as target. However, overlapping targets requires a unique ID to function!
    const bool was_accepted_previously = (g.DragDropAcceptIdPrev == g.DragDropTargetId);
    ImRect r = g.DragDropTargetRect;
    float r_surface = r.GetWidth() * r.GetHeight();
    if (r_surface < g.DragDropAcceptIdCurrRectSurface)
    {
        g.DragDropAcceptFlags = flags;
        g.DragDropAcceptIdCurr = g.DragDropTargetId;
        g.DragDropAcceptIdCurrRectSurface = r_surface;
    }

    // Render default drop visuals
    payload.Preview = was_accepted_previously;
    flags |= (g.DragDropSourceFlags & ImGuiDragDropFlags_AcceptNoDrawDefaultRect); // Source can also inhibit the preview (useful for external sources that lives for 1 frame)
    if (!(flags & ImGuiDragDropFlags_AcceptNoDrawDefaultRect) && payload.Preview)
    {
        // FIXME-DRAG: Settle on a proper default visuals for drop target.
        r.Expand(3.5f);
        bool push_clip_rect = !window->ClipRect.Contains(r);
        if (push_clip_rect) window->DrawList->PushClipRect(r.Min-ImVec2(1,1), r.Max+ImVec2(1,1));
        window->DrawList->AddRect(r.Min, r.Max, GetColorU32(ImGuiCol_DragDropTarget), 0.0f, ~0, 2.0f);
        if (push_clip_rect) window->DrawList->PopClipRect();
    }

    g.DragDropAcceptFrameCount = g.FrameCount;
    payload.Delivery = was_accepted_previously && !IsMouseDown(g.DragDropMouseButton); // For extern drag sources affecting os window focus, it's easier to just test !IsMouseDown() instead of IsMouseReleased()
    if (!payload.Delivery && !(flags & ImGuiDragDropFlags_AcceptBeforeDelivery))
        return NULL;

    return &payload;
}

const ImGuiPayload* ImGui::GetDragDropPayload()
{
    ImGuiContext& g = *GImGui;
    return g.DragDropActive ? &g.DragDropPayload : NULL;
}

// We don't really use/need this now, but added it for the sake of consistency and because we might need it later.
void ImGui::EndDragDropTarget()
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.DragDropActive);
    IM_ASSERT(g.DragDropWithinSourceOrTarget);
    g.DragDropWithinSourceOrTarget = false;
}

//-----------------------------------------------------------------------------
// [SECTION] DOCKING
//-----------------------------------------------------------------------------

// (this section is filled in the 'docking' branch)

//-----------------------------------------------------------------------------
// [SECTION] LOGGING/CAPTURING
//-----------------------------------------------------------------------------
// All text output from the interface can be captured into tty/file/clipboard. 
// By default, tree nodes are automatically opened during logging.
//-----------------------------------------------------------------------------

// Pass text data straight to log (without being displayed)
void ImGui::LogText(const char* fmt, ...)
{
    ImGuiContext& g = *GImGui;
    if (!g.LogEnabled)
        return;

    va_list args;
    va_start(args, fmt);
    if (g.LogFile)
        vfprintf(g.LogFile, fmt, args);
    else
        g.LogClipboard.appendfv(fmt, args);
    va_end(args);
}

// Internal version that takes a position to decide on newline placement and pad items according to their depth.
// We split text into individual lines to add current tree level padding
void ImGui::LogRenderedText(const ImVec2* ref_pos, const char* text, const char* text_end)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    if (!text_end)
        text_end = FindRenderedTextEnd(text, text_end);

    const bool log_new_line = ref_pos && (ref_pos->y > window->DC.LogLinePosY + 1);
    if (ref_pos)
        window->DC.LogLinePosY = ref_pos->y;

    const char* text_remaining = text;
    if (g.LogStartDepth > window->DC.TreeDepth)  // Re-adjust padding if we have popped out of our starting depth
        g.LogStartDepth = window->DC.TreeDepth;
    const int tree_depth = (window->DC.TreeDepth - g.LogStartDepth);
    for (;;)
    {
        // Split the string. Each new line (after a '\n') is followed by spacing corresponding to the current depth of our log entry.
        const char* line_start = text_remaining;
        const char* line_end = ImStreolRange(line_start, text_end);
        const bool is_first_line = (line_start == text);
        const bool is_last_line = (line_end == text_end);
        if (!is_last_line || (line_start != line_end))
        {
            const int char_count = (int)(line_end - line_start);
            if (log_new_line || !is_first_line)
                LogText(IM_NEWLINE "%*s%.*s", tree_depth*4, "", char_count, line_start);
            else
                LogText(" %.*s", char_count, line_start);
        }

        if (is_last_line)
            break;
        text_remaining = line_end + 1;
    }
}

// Start logging ImGui output to TTY
void ImGui::LogToTTY(int max_depth)
{
    ImGuiContext& g = *GImGui;
    if (g.LogEnabled)
        return;
    ImGuiWindow* window = g.CurrentWindow;

    IM_ASSERT(g.LogFile == NULL);
    g.LogFile = stdout;
    g.LogEnabled = true;
    g.LogStartDepth = window->DC.TreeDepth;
    if (max_depth >= 0)
        g.LogAutoExpandMaxDepth = max_depth;
}

// Start logging ImGui output to given file
void ImGui::LogToFile(int max_depth, const char* filename)
{
    ImGuiContext& g = *GImGui;
    if (g.LogEnabled)
        return;
    ImGuiWindow* window = g.CurrentWindow;

    if (!filename)
    {
        filename = g.IO.LogFilename;
        if (!filename)
            return;
    }

    IM_ASSERT(g.LogFile == NULL);
    g.LogFile = ImFileOpen(filename, "ab");
    if (!g.LogFile)
    {
        IM_ASSERT(0);
        return;
    }
    g.LogEnabled = true;
    g.LogStartDepth = window->DC.TreeDepth;
    if (max_depth >= 0)
        g.LogAutoExpandMaxDepth = max_depth;
}

// Start logging ImGui output to clipboard
void ImGui::LogToClipboard(int max_depth)
{
    ImGuiContext& g = *GImGui;
    if (g.LogEnabled)
        return;
    ImGuiWindow* window = g.CurrentWindow;

    IM_ASSERT(g.LogFile == NULL);
    g.LogFile = NULL;
    g.LogEnabled = true;
    g.LogStartDepth = window->DC.TreeDepth;
    if (max_depth >= 0)
        g.LogAutoExpandMaxDepth = max_depth;
}

void ImGui::LogFinish()
{
    ImGuiContext& g = *GImGui;
    if (!g.LogEnabled)
        return;

    LogText(IM_NEWLINE);
    if (g.LogFile != NULL)
    {
        if (g.LogFile == stdout)
            fflush(g.LogFile);
        else
            fclose(g.LogFile);
        g.LogFile = NULL;
    }
    if (g.LogClipboard.size() > 1)
    {
        SetClipboardText(g.LogClipboard.begin());
        g.LogClipboard.clear();
    }
    g.LogEnabled = false;
}

// Helper to display logging buttons
void ImGui::LogButtons()
{
    ImGuiContext& g = *GImGui;

    PushID("LogButtons");
    const bool log_to_tty = Button("Log To TTY"); SameLine();
    const bool log_to_file = Button("Log To File"); SameLine();
    const bool log_to_clipboard = Button("Log To Clipboard"); SameLine();
    PushItemWidth(80.0f);
    PushAllowKeyboardFocus(false);
    SliderInt("Depth", &g.LogAutoExpandMaxDepth, 0, 9, NULL);
    PopAllowKeyboardFocus();
    PopItemWidth();
    PopID();

    // Start logging at the end of the function so that the buttons don't appear in the log
    if (log_to_tty)
        LogToTTY(g.LogAutoExpandMaxDepth);
    if (log_to_file)
        LogToFile(g.LogAutoExpandMaxDepth, g.IO.LogFilename);
    if (log_to_clipboard)
        LogToClipboard(g.LogAutoExpandMaxDepth);
}

//-----------------------------------------------------------------------------
// [SECTION] SETTINGS
//-----------------------------------------------------------------------------

void ImGui::MarkIniSettingsDirty()
{
    ImGuiContext& g = *GImGui;
    if (g.SettingsDirtyTimer <= 0.0f)
        g.SettingsDirtyTimer = g.IO.IniSavingRate;
}

void ImGui::MarkIniSettingsDirty(ImGuiWindow* window)
{
    ImGuiContext& g = *GImGui;
    if (!(window->Flags & ImGuiWindowFlags_NoSavedSettings))
        if (g.SettingsDirtyTimer <= 0.0f)
            g.SettingsDirtyTimer = g.IO.IniSavingRate;
}

ImGuiWindowSettings* ImGui::CreateNewWindowSettings(const char* name)
{
    ImGuiContext& g = *GImGui;
    g.SettingsWindows.push_back(ImGuiWindowSettings());
    ImGuiWindowSettings* settings = &g.SettingsWindows.back();
    settings->Name = ImStrdup(name);
    settings->ID = ImHashStr(name, 0);
    return settings;
}

ImGuiWindowSettings* ImGui::FindWindowSettings(ImGuiID id)
{
    ImGuiContext& g = *GImGui;
    for (int i = 0; i != g.SettingsWindows.Size; i++)
        if (g.SettingsWindows[i].ID == id)
            return &g.SettingsWindows[i];
    return NULL;
}

ImGuiWindowSettings* ImGui::FindOrCreateWindowSettings(const char* name)
{
    if (ImGuiWindowSettings* settings = FindWindowSettings(ImHashStr(name, 0)))
        return settings;
    return CreateNewWindowSettings(name);
}

void ImGui::LoadIniSettingsFromDisk(const char* ini_filename)
{
    size_t file_data_size = 0;
    char* file_data = (char*)ImFileLoadToMemory(ini_filename, "rb", &file_data_size);
    if (!file_data)
        return;
    LoadIniSettingsFromMemory(file_data, (size_t)file_data_size);
    ImGui::MemFree(file_data);
}

ImGuiSettingsHandler* ImGui::FindSettingsHandler(const char* type_name)
{
    ImGuiContext& g = *GImGui;
    const ImGuiID type_hash = ImHashStr(type_name, 0);
    for (int handler_n = 0; handler_n < g.SettingsHandlers.Size; handler_n++)
        if (g.SettingsHandlers[handler_n].TypeHash == type_hash)
            return &g.SettingsHandlers[handler_n];
    return NULL;
}

// Zero-tolerance, no error reporting, cheap .ini parsing
void ImGui::LoadIniSettingsFromMemory(const char* ini_data, size_t ini_size)
{
    ImGuiContext& g = *GImGui;
    IM_ASSERT(g.Initialized);
    IM_ASSERT(g.SettingsLoaded == false && g.FrameCount == 0);

    // For user convenience, we allow passing a non zero-terminated string (hence the ini_size parameter).
    // For our convenience and to make the code simpler, we'll also write zero-terminators within the buffer. So let's create a writable copy..
    if (ini_size == 0)
        ini_size = strlen(ini_data);
    char* buf = (char*)ImGui::MemAlloc(ini_size + 1);
    char* buf_end = buf + ini_size;
    memcpy(buf, ini_data, ini_size);
    buf[ini_size] = 0;

    void* entry_data = NULL;
    ImGuiSettingsHandler* entry_handler = NULL;

    char* line_end = NULL;
    for (char* line = buf; line < buf_end; line = line_end + 1)
    {
        // Skip new lines markers, then find end of the line
        while (*line == '\n' || *line == '\r')
            line++;
        line_end = line;
        while (line_end < buf_end && *line_end != '\n' && *line_end != '\r')
            line_end++;
        line_end[0] = 0;
        if (line[0] == ';')
            continue;
        if (line[0] == '[' && line_end > line && line_end[-1] == ']')
        {
            // Parse "[Type][Name]". Note that 'Name' can itself contains [] characters, which is acceptable with the current format and parsing code.
            line_end[-1] = 0;
            const char* name_end = line_end - 1;
            const char* type_start = line + 1;
            char* type_end = (char*)(intptr_t)ImStrchrRange(type_start, name_end, ']');
            const char* name_start = type_end ? ImStrchrRange(type_end + 1, name_end, '[') : NULL;
            if (!type_end || !name_start)
            {
                name_start = type_start; // Import legacy entries that have no type
                type_start = "Window";
            }
            else
            {
                *type_end = 0; // Overwrite first ']'
                name_start++;  // Skip second '['
            }
            entry_handler = FindSettingsHandler(type_start);
            entry_data = entry_handler ? entry_handler->ReadOpenFn(&g, entry_handler, name_start) : NULL;
        }
        else if (entry_handler != NULL && entry_data != NULL)
        {
            // Let type handler parse the line
            entry_handler->ReadLineFn(&g, entry_handler, entry_data, line);
        }
    }
    ImGui::MemFree(buf);
    g.SettingsLoaded = true;
}

void ImGui::SaveIniSettingsToDisk(const char* ini_filename)
{
    ImGuiContext& g = *GImGui;
    g.SettingsDirtyTimer = 0.0f;
    if (!ini_filename)
        return;

    size_t ini_data_size = 0;
    const char* ini_data = SaveIniSettingsToMemory(&ini_data_size);
    FILE* f = ImFileOpen(ini_filename, "wt");
    if (!f)
        return;
    fwrite(ini_data, sizeof(char), ini_data_size, f);
    fclose(f);
}

// Call registered handlers (e.g. SettingsHandlerWindow_WriteAll() + custom handlers) to write their stuff into a text buffer
const char* ImGui::SaveIniSettingsToMemory(size_t* out_size)
{
    ImGuiContext& g = *GImGui;
    g.SettingsDirtyTimer = 0.0f;
    g.SettingsIniData.Buf.resize(0);
    g.SettingsIniData.Buf.push_back(0);
    for (int handler_n = 0; handler_n < g.SettingsHandlers.Size; handler_n++)
    {
        ImGuiSettingsHandler* handler = &g.SettingsHandlers[handler_n];
        handler->WriteAllFn(&g, handler, &g.SettingsIniData);
    }
    if (out_size)
        *out_size = (size_t)g.SettingsIniData.size();
    return g.SettingsIniData.c_str();
}

static void* SettingsHandlerWindow_ReadOpen(ImGuiContext*, ImGuiSettingsHandler*, const char* name)
{
    ImGuiWindowSettings* settings = ImGui::FindWindowSettings(ImHashStr(name, 0));
    if (!settings)
        settings = ImGui::CreateNewWindowSettings(name);
    return (void*)settings;
}

static void SettingsHandlerWindow_ReadLine(ImGuiContext*, ImGuiSettingsHandler*, void* entry, const char* line)
{
    ImGuiWindowSettings* settings = (ImGuiWindowSettings*)entry;
    float x, y;
    int i;
    if (sscanf(line, "Pos=%f,%f", &x, &y) == 2)         settings->Pos = ImVec2(x, y);
    else if (sscanf(line, "Size=%f,%f", &x, &y) == 2)   settings->Size = ImMax(ImVec2(x, y), GImGui->Style.WindowMinSize);
    else if (sscanf(line, "Collapsed=%d", &i) == 1)     settings->Collapsed = (i != 0);
}

static void SettingsHandlerWindow_WriteAll(ImGuiContext* imgui_ctx, ImGuiSettingsHandler* handler, ImGuiTextBuffer* buf)
{
    // Gather data from windows that were active during this session
    // (if a window wasn't opened in this session we preserve its settings)
    ImGuiContext& g = *imgui_ctx;
    for (int i = 0; i != g.Windows.Size; i++)
    {
        ImGuiWindow* window = g.Windows[i];
        if (window->Flags & ImGuiWindowFlags_NoSavedSettings)
            continue;

        ImGuiWindowSettings* settings = (window->SettingsIdx != -1) ? &g.SettingsWindows[window->SettingsIdx] : ImGui::FindWindowSettings(window->ID);
        if (!settings)
        {
            settings = ImGui::CreateNewWindowSettings(window->Name);
            window->SettingsIdx = g.SettingsWindows.index_from_ptr(settings);
        }
        IM_ASSERT(settings->ID == window->ID);
        settings->Pos = window->Pos;
        settings->Size = window->SizeFull;
        settings->Collapsed = window->Collapsed;
    }

    // Write to text buffer
    buf->reserve(buf->size() + g.SettingsWindows.Size * 96); // ballpark reserve
    for (int i = 0; i != g.SettingsWindows.Size; i++)
    {
        const ImGuiWindowSettings* settings = &g.SettingsWindows[i];
        if (settings->Pos.x == FLT_MAX)
            continue;
        const char* name = settings->Name;
        if (const char* p = strstr(name, "###"))  // Skip to the "###" marker if any. We don't skip past to match the behavior of GetID()
            name = p;
        buf->appendf("[%s][%s]\n", handler->TypeName, name);
        buf->appendf("Pos=%d,%d\n", (int)settings->Pos.x, (int)settings->Pos.y);
        buf->appendf("Size=%d,%d\n", (int)settings->Size.x, (int)settings->Size.y);
        buf->appendf("Collapsed=%d\n", settings->Collapsed);
        buf->appendf("\n");
    }
}

//-----------------------------------------------------------------------------
// [SECTION] PLATFORM DEPENDENT HELPERS
//-----------------------------------------------------------------------------

#if defined(_WIN32) && !defined(_WINDOWS_) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS) && (!defined(IMGUI_DISABLE_WIN32_DEFAULT_CLIPBOARD_FUNCTIONS) || !defined(IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS))
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef __MINGW32__
#include <Windows.h>
#else
#include <windows.h>
#endif
#endif

// Win32 API clipboard implementation
#if defined(_WIN32) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS) && !defined(IMGUI_DISABLE_WIN32_DEFAULT_CLIPBOARD_FUNCTIONS)

#ifdef _MSC_VER
#pragma comment(lib, "user32")
#endif

static const char* GetClipboardTextFn_DefaultImpl(void*)
{
    static ImVector<char> buf_local;
    buf_local.clear();
    if (!::OpenClipboard(NULL))
        return NULL;
    HANDLE wbuf_handle = ::GetClipboardData(CF_UNICODETEXT);
    if (wbuf_handle == NULL)
    {
        ::CloseClipboard();
        return NULL;
    }
    if (ImWchar* wbuf_global = (ImWchar*)::GlobalLock(wbuf_handle))
    {
        int buf_len = ImTextCountUtf8BytesFromStr(wbuf_global, NULL) + 1;
        buf_local.resize(buf_len);
        ImTextStrToUtf8(buf_local.Data, buf_len, wbuf_global, NULL);
    }
    ::GlobalUnlock(wbuf_handle);
    ::CloseClipboard();
    return buf_local.Data;
}

static void SetClipboardTextFn_DefaultImpl(void*, const char* text)
{
    if (!::OpenClipboard(NULL))
        return;
    const int wbuf_length = ImTextCountCharsFromUtf8(text, NULL) + 1;
    HGLOBAL wbuf_handle = ::GlobalAlloc(GMEM_MOVEABLE, (SIZE_T)wbuf_length * sizeof(ImWchar));
    if (wbuf_handle == NULL)
    {
        ::CloseClipboard();
        return;
    }
    ImWchar* wbuf_global = (ImWchar*)::GlobalLock(wbuf_handle);
    ImTextStrFromUtf8(wbuf_global, wbuf_length, text, NULL);
    ::GlobalUnlock(wbuf_handle);
    ::EmptyClipboard();
    if (::SetClipboardData(CF_UNICODETEXT, wbuf_handle) == NULL)
        ::GlobalFree(wbuf_handle);
    ::CloseClipboard();
}

#else

// Local ImGui-only clipboard implementation, if user hasn't defined better clipboard handlers
static const char* GetClipboardTextFn_DefaultImpl(void*)
{
    ImGuiContext& g = *GImGui;
    return g.PrivateClipboard.empty() ? NULL : g.PrivateClipboard.begin();
}

// Local ImGui-only clipboard implementation, if user hasn't defined better clipboard handlers
static void SetClipboardTextFn_DefaultImpl(void*, const char* text)
{
    ImGuiContext& g = *GImGui;
    g.PrivateClipboard.clear();
    const char* text_end = text + strlen(text);
    g.PrivateClipboard.resize((int)(text_end - text) + 1);
    memcpy(&g.PrivateClipboard[0], text, (size_t)(text_end - text));
    g.PrivateClipboard[(int)(text_end - text)] = 0;
}

#endif

// Win32 API IME support (for Asian languages, etc.)
#if defined(_WIN32) && !defined(__GNUC__) && !defined(IMGUI_DISABLE_WIN32_DEFAULT_IME_FUNCTIONS)

#include <imm.h>
#ifdef _MSC_VER
#pragma comment(lib, "imm32")
#endif

static void ImeSetInputScreenPosFn_DefaultImpl(int x, int y)
{
    // Notify OS Input Method Editor of text input position
    if (HWND hwnd = (HWND)GImGui->IO.ImeWindowHandle)
        if (HIMC himc = ::ImmGetContext(hwnd))
        {
            COMPOSITIONFORM cf;
            cf.ptCurrentPos.x = x;
            cf.ptCurrentPos.y = y;
            cf.dwStyle = CFS_FORCE_POSITION;
            ::ImmSetCompositionWindow(himc, &cf);
            ::ImmReleaseContext(hwnd, himc);
        }
}

#else

static void ImeSetInputScreenPosFn_DefaultImpl(int, int) {}

#endif

//-----------------------------------------------------------------------------
// [SECTION] METRICS/DEBUG WINDOW
//-----------------------------------------------------------------------------

void ImGui::ShowMetricsWindow(bool* p_open)
{
    if (!ImGui::Begin("ImGui Metrics", p_open))
    {
        ImGui::End();
        return;
    }

    static bool show_draw_cmd_clip_rects = true;
    static bool show_window_begin_order = false;
    ImGuiIO& io = ImGui::GetIO();
    ImGui::Text("Dear ImGui %s", ImGui::GetVersion());
    ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / io.Framerate, io.Framerate);
    ImGui::Text("%d vertices, %d indices (%d triangles)", io.MetricsRenderVertices, io.MetricsRenderIndices, io.MetricsRenderIndices / 3);
    ImGui::Text("%d active windows (%d visible)", io.MetricsActiveWindows, io.MetricsRenderWindows);
    ImGui::Text("%d allocations", io.MetricsActiveAllocations);
    ImGui::Checkbox("Show clipping rectangles when hovering draw commands", &show_draw_cmd_clip_rects);
    ImGui::Checkbox("Ctrl shows window begin order", &show_window_begin_order);
    ImGui::Separator();

    struct Funcs
    {
        static void NodeDrawList(ImGuiWindow* window, ImDrawList* draw_list, const char* label)
        {
            bool node_open = ImGui::TreeNode(draw_list, "%s: '%s' %d vtx, %d indices, %d cmds", label, draw_list->_OwnerName ? draw_list->_OwnerName : "", draw_list->VtxBuffer.Size, draw_list->IdxBuffer.Size, draw_list->CmdBuffer.Size);
            if (draw_list == ImGui::GetWindowDrawList())
            {
                ImGui::SameLine();
                ImGui::TextColored(ImVec4(1.0f,0.4f,0.4f,1.0f), "CURRENTLY APPENDING"); // Can't display stats for active draw list! (we don't have the data double-buffered)
                if (node_open) ImGui::TreePop();
                return;
            }

            ImDrawList* overlay_draw_list = GetOverlayDrawList(window); // Render additional visuals into the top-most draw list
            if (window && IsItemHovered())
                overlay_draw_list->AddRect(window->Pos, window->Pos + window->Size, IM_COL32(255, 255, 0, 255));
            if (!node_open)
                return;

            int elem_offset = 0;
            for (const ImDrawCmd* pcmd = draw_list->CmdBuffer.begin(); pcmd < draw_list->CmdBuffer.end(); elem_offset += pcmd->ElemCount, pcmd++)
            {
                if (pcmd->UserCallback == NULL && pcmd->ElemCount == 0)
                    continue;
                if (pcmd->UserCallback)
                {
                    ImGui::BulletText("Callback %p, user_data %p", pcmd->UserCallback, pcmd->UserCallbackData);
                    continue;
                }
                ImDrawIdx* idx_buffer = (draw_list->IdxBuffer.Size > 0) ? draw_list->IdxBuffer.Data : NULL;
                bool pcmd_node_open = ImGui::TreeNode((void*)(pcmd - draw_list->CmdBuffer.begin()), "Draw %4d %s vtx, tex 0x%p, clip_rect (%4.0f,%4.0f)-(%4.0f,%4.0f)", pcmd->ElemCount, draw_list->IdxBuffer.Size > 0 ? "indexed" : "non-indexed", pcmd->TextureId, pcmd->ClipRect.x, pcmd->ClipRect.y, pcmd->ClipRect.z, pcmd->ClipRect.w);
                if (show_draw_cmd_clip_rects && ImGui::IsItemHovered())
                {
                    ImRect clip_rect = pcmd->ClipRect;
                    ImRect vtxs_rect;
                    for (int i = elem_offset; i < elem_offset + (int)pcmd->ElemCount; i++)
                        vtxs_rect.Add(draw_list->VtxBuffer[idx_buffer ? idx_buffer[i] : i].pos);
                    clip_rect.Floor(); overlay_draw_list->AddRect(clip_rect.Min, clip_rect.Max, IM_COL32(255,255,0,255));
                    vtxs_rect.Floor(); overlay_draw_list->AddRect(vtxs_rect.Min, vtxs_rect.Max, IM_COL32(255,0,255,255));
                }
                if (!pcmd_node_open)
                    continue;

                // Display individual triangles/vertices. Hover on to get the corresponding triangle highlighted.
                ImGuiListClipper clipper(pcmd->ElemCount/3); // Manually coarse clip our print out of individual vertices to save CPU, only items that may be visible.
                while (clipper.Step())
                    for (int prim = clipper.DisplayStart, idx_i = elem_offset + clipper.DisplayStart*3; prim < clipper.DisplayEnd; prim++)
                    {
                        char buf[300];
                        char *buf_p = buf, *buf_end = buf + IM_ARRAYSIZE(buf);
                        ImVec2 triangles_pos[3];
                        for (int n = 0; n < 3; n++, idx_i++)
                        {
                            int vtx_i = idx_buffer ? idx_buffer[idx_i] : idx_i;
                            ImDrawVert& v = draw_list->VtxBuffer[vtx_i];
                            triangles_pos[n] = v.pos;
                            buf_p += ImFormatString(buf_p, buf_end - buf_p, "%s %04d: pos (%8.2f,%8.2f), uv (%.6f,%.6f), col %08X\n",
                                (n == 0) ? "idx" : "   ", idx_i, v.pos.x, v.pos.y, v.uv.x, v.uv.y, v.col);
                        }
                        ImGui::Selectable(buf, false);
                        if (ImGui::IsItemHovered())
                        {
                            ImDrawListFlags backup_flags = overlay_draw_list->Flags;
                            overlay_draw_list->Flags &= ~ImDrawListFlags_AntiAliasedLines; // Disable AA on triangle outlines at is more readable for very large and thin triangles.
                            overlay_draw_list->AddPolyline(triangles_pos, 3, IM_COL32(255,255,0,255), true, 1.0f);
                            overlay_draw_list->Flags = backup_flags;
                        }
                    }
                ImGui::TreePop();
            }
            ImGui::TreePop();
        }

        static void NodeWindows(ImVector<ImGuiWindow*>& windows, const char* label)
        {
            if (!ImGui::TreeNode(label, "%s (%d)", label, windows.Size))
                return;
            for (int i = 0; i < windows.Size; i++)
                Funcs::NodeWindow(windows[i], "Window");
            ImGui::TreePop();
        }

        static void NodeWindow(ImGuiWindow* window, const char* label)
        {
            if (!ImGui::TreeNode(window, "%s '%s', %d @ 0x%p", label, window->Name, window->Active || window->WasActive, window))
                return;
            ImGuiWindowFlags flags = window->Flags;
            NodeDrawList(window, window->DrawList, "DrawList");
            ImGui::BulletText("Pos: (%.1f,%.1f), Size: (%.1f,%.1f), SizeContents (%.1f,%.1f)", window->Pos.x, window->Pos.y, window->Size.x, window->Size.y, window->SizeContents.x, window->SizeContents.y);
            ImGui::BulletText("Flags: 0x%08X (%s%s%s%s%s%s%s%s%s..)", flags,
                (flags & ImGuiWindowFlags_ChildWindow)  ? "Child " : "",      (flags & ImGuiWindowFlags_Tooltip)     ? "Tooltip "   : "",  (flags & ImGuiWindowFlags_Popup) ? "Popup " : "",
                (flags & ImGuiWindowFlags_Modal)        ? "Modal " : "",      (flags & ImGuiWindowFlags_ChildMenu)   ? "ChildMenu " : "",  (flags & ImGuiWindowFlags_NoSavedSettings) ? "NoSavedSettings " : "",
                (flags & ImGuiWindowFlags_NoMouseInputs)? "NoMouseInputs":"", (flags & ImGuiWindowFlags_NoNavInputs) ? "NoNavInputs" : "", (flags & ImGuiWindowFlags_AlwaysAutoResize) ? "AlwaysAutoResize" : "");
            ImGui::BulletText("Scroll: (%.2f/%.2f,%.2f/%.2f)", window->Scroll.x, GetWindowScrollMaxX(window), window->Scroll.y, GetWindowScrollMaxY(window));
            ImGui::BulletText("Active: %d/%d, WriteAccessed: %d, BeginOrderWithinContext: %d", window->Active, window->WasActive, window->WriteAccessed, (window->Active || window->WasActive) ? window->BeginOrderWithinContext : -1);
            ImGui::BulletText("Appearing: %d, Hidden: %d (Reg %d Resize %d), SkipItems: %d", window->Appearing, window->Hidden, window->HiddenFramesRegular, window->HiddenFramesForResize, window->SkipItems);
            ImGui::BulletText("NavLastIds: 0x%08X,0x%08X, NavLayerActiveMask: %X", window->NavLastIds[0], window->NavLastIds[1], window->DC.NavLayerActiveMask);
            ImGui::BulletText("NavLastChildNavWindow: %s", window->NavLastChildNavWindow ? window->NavLastChildNavWindow->Name : "NULL");
            if (!window->NavRectRel[0].IsInverted())
                ImGui::BulletText("NavRectRel[0]: (%.1f,%.1f)(%.1f,%.1f)", window->NavRectRel[0].Min.x, window->NavRectRel[0].Min.y, window->NavRectRel[0].Max.x, window->NavRectRel[0].Max.y);
            else
                ImGui::BulletText("NavRectRel[0]: <None>");
            if (window->RootWindow != window) NodeWindow(window->RootWindow, "RootWindow");
            if (window->ParentWindow != NULL) NodeWindow(window->ParentWindow, "ParentWindow");
            if (window->DC.ChildWindows.Size > 0) NodeWindows(window->DC.ChildWindows, "ChildWindows");
            if (window->ColumnsStorage.Size > 0 && ImGui::TreeNode("Columns", "Columns sets (%d)", window->ColumnsStorage.Size))
            {
                for (int n = 0; n < window->ColumnsStorage.Size; n++)
                {
                    const ImGuiColumnsSet* columns = &window->ColumnsStorage[n];
                    if (ImGui::TreeNode((void*)(uintptr_t)columns->ID, "Columns Id: 0x%08X, Count: %d, Flags: 0x%04X", columns->ID, columns->Count, columns->Flags))
                    {
                        ImGui::BulletText("Width: %.1f (MinX: %.1f, MaxX: %.1f)", columns->MaxX - columns->MinX, columns->MinX, columns->MaxX);
                        for (int column_n = 0; column_n < columns->Columns.Size; column_n++)
                            ImGui::BulletText("Column %02d: OffsetNorm %.3f (= %.1f px)", column_n, columns->Columns[column_n].OffsetNorm, OffsetNormToPixels(columns, columns->Columns[column_n].OffsetNorm));
                        ImGui::TreePop();
                    }
                }
                ImGui::TreePop();
            }
            ImGui::BulletText("Storage: %d bytes", window->StateStorage.Data.Size * (int)sizeof(ImGuiStorage::Pair));
            ImGui::TreePop();
        }

        static void NodeTabBar(ImGuiTabBar* tab_bar)
        {
            // Standalone tab bars (not associated to docking/windows functionality) currently hold no discernible strings.
            char buf[256];
            char* p = buf;
            const char* buf_end = buf + IM_ARRAYSIZE(buf);
            ImFormatString(p, buf_end - p, "TabBar (%d tabs)%s", tab_bar->Tabs.Size, (tab_bar->PrevFrameVisible < ImGui::GetFrameCount() - 2) ? " *Inactive*" : "");
            if (ImGui::TreeNode(tab_bar, "%s", buf))
            {
                for (int tab_n = 0; tab_n < tab_bar->Tabs.Size; tab_n++)
                {
                    const ImGuiTabItem* tab = &tab_bar->Tabs[tab_n];
                    ImGui::PushID(tab);
                    if (ImGui::SmallButton("<")) { TabBarQueueChangeTabOrder(tab_bar, tab, -1); } ImGui::SameLine(0, 2);
                    if (ImGui::SmallButton(">")) { TabBarQueueChangeTabOrder(tab_bar, tab, +1); } ImGui::SameLine();
                    ImGui::Text("%02d%c Tab 0x%08X", tab_n, (tab->ID == tab_bar->SelectedTabId) ? '*' : ' ', tab->ID);
                    ImGui::PopID();
                }
                ImGui::TreePop();
            }
        }
    };

    // Access private state, we are going to display the draw lists from last frame
    ImGuiContext& g = *GImGui;
    Funcs::NodeWindows(g.Windows, "Windows");
    if (ImGui::TreeNode("DrawList", "Active DrawLists (%d)", g.DrawDataBuilder.Layers[0].Size))
    {
        for (int i = 0; i < g.DrawDataBuilder.Layers[0].Size; i++)
            Funcs::NodeDrawList(NULL, g.DrawDataBuilder.Layers[0][i], "DrawList");
        ImGui::TreePop();
    }
    if (ImGui::TreeNode("Popups", "Popups (%d)", g.OpenPopupStack.Size))
    {
        for (int i = 0; i < g.OpenPopupStack.Size; i++)
        {
            ImGuiWindow* window = g.OpenPopupStack[i].Window;
            ImGui::BulletText("PopupID: %08x, Window: '%s'%s%s", g.OpenPopupStack[i].PopupId, window ? window->Name : "NULL", window && (window->Flags & ImGuiWindowFlags_ChildWindow) ? " ChildWindow" : "", window && (window->Flags & ImGuiWindowFlags_ChildMenu) ? " ChildMenu" : "");
        }
        ImGui::TreePop();
    }
    if (ImGui::TreeNode("TabBars", "Tab Bars (%d)", g.TabBars.Data.Size))
    {
        for (int n = 0; n < g.TabBars.Data.Size; n++)
            Funcs::NodeTabBar(g.TabBars.GetByIndex(n));
        ImGui::TreePop();
    }
    if (ImGui::TreeNode("Internal state"))
    {
        const char* input_source_names[] = { "None", "Mouse", "Nav", "NavKeyboard", "NavGamepad" }; IM_ASSERT(IM_ARRAYSIZE(input_source_names) == ImGuiInputSource_COUNT);
        ImGui::Text("HoveredWindow: '%s'", g.HoveredWindow ? g.HoveredWindow->Name : "NULL");
        ImGui::Text("HoveredRootWindow: '%s'", g.HoveredRootWindow ? g.HoveredRootWindow->Name : "NULL");
        ImGui::Text("HoveredId: 0x%08X/0x%08X (%.2f sec), AllowOverlap: %d", g.HoveredId, g.HoveredIdPreviousFrame, g.HoveredIdTimer, g.HoveredIdAllowOverlap); // Data is "in-flight" so depending on when the Metrics window is called we may see current frame information or not
        ImGui::Text("ActiveId: 0x%08X/0x%08X (%.2f sec), AllowOverlap: %d, Source: %s", g.ActiveId, g.ActiveIdPreviousFrame, g.ActiveIdTimer, g.ActiveIdAllowOverlap, input_source_names[g.ActiveIdSource]);
        ImGui::Text("ActiveIdWindow: '%s'", g.ActiveIdWindow ? g.ActiveIdWindow->Name : "NULL");
        ImGui::Text("MovingWindow: '%s'", g.MovingWindow ? g.MovingWindow->Name : "NULL");
        ImGui::Text("NavWindow: '%s'", g.NavWindow ? g.NavWindow->Name : "NULL");
        ImGui::Text("NavId: 0x%08X, NavLayer: %d", g.NavId, g.NavLayer);
        ImGui::Text("NavInputSource: %s", input_source_names[g.NavInputSource]);
        ImGui::Text("NavActive: %d, NavVisible: %d", g.IO.NavActive, g.IO.NavVisible);
        ImGui::Text("NavActivateId: 0x%08X, NavInputId: 0x%08X", g.NavActivateId, g.NavInputId);
        ImGui::Text("NavDisableHighlight: %d, NavDisableMouseHover: %d", g.NavDisableHighlight, g.NavDisableMouseHover);
        ImGui::Text("NavWindowingTarget: '%s'", g.NavWindowingTarget ? g.NavWindowingTarget->Name : "NULL");
        ImGui::Text("DragDrop: %d, SourceId = 0x%08X, Payload \"%s\" (%d bytes)", g.DragDropActive, g.DragDropPayload.SourceId, g.DragDropPayload.DataType, g.DragDropPayload.DataSize);
        ImGui::TreePop();
    }


    if (g.IO.KeyCtrl && show_window_begin_order)
    {
        for (int n = 0; n < g.Windows.Size; n++)
        {
            ImGuiWindow* window = g.Windows[n];
            if ((window->Flags & ImGuiWindowFlags_ChildWindow) || !window->WasActive)
                continue;
            char buf[32];
            ImFormatString(buf, IM_ARRAYSIZE(buf), "%d", window->BeginOrderWithinContext);
            float font_size = ImGui::GetFontSize() * 2;
            ImDrawList* overlay_draw_list = GetOverlayDrawList(window);
            overlay_draw_list->AddRectFilled(window->Pos, window->Pos + ImVec2(font_size, font_size), IM_COL32(200, 100, 100, 255));
            overlay_draw_list->AddText(NULL, font_size, window->Pos, IM_COL32(255, 255, 255, 255), buf);
        }
    }
    ImGui::End();
}

//-----------------------------------------------------------------------------

// Include imgui_user.inl at the end of imgui.cpp to access private data/functions that aren't exposed.
// Prefer just including imgui_internal.h from your code rather than using this define. If a declaration is missing from imgui_internal.h add it or request it on the github.
#ifdef IMGUI_INCLUDE_IMGUI_USER_INL
#include "imgui_user.inl"
#endif

//-----------------------------------------------------------------------------



/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XbVsV
{
public:
    int SYZqzZSHYCXWVZ;
    double WDwqopgzrOI;

    XbVsV();
    double zoArtpQl(double PPKtPzCOukbGCig, int xcbYLqV);
    bool OhigpPqyEQkN(double pTokimoMSPzo, int SVocJTS, int npvWRRRinyXV, string toPBIOTuAP, double hJPEu);
    bool UYoaXIU(string qvTkVCiHQQANQ);
protected:
    int TnEWwbhVenwFWuoQ;
    int TZunj;
    bool MCDJCEbyIMs;
    string gXBENty;
    double PlqIXoGn;
    bool etAbn;

    void oMifgfZsAsHFA(int ARfITRYMg, int COtLF);
private:
    string VCFLaCjOySgx;
    string hSquOtRA;
    double lcUOAeMnmgcq;
    int oIPdZWdXGjAsCCi;
    string YDTDbCCFhXH;
    double CAePpjwoviL;

    int ovNma(int EwTdXrQKnlcaWM, int yLGHWhBwVfDuK, bool ynnstiGyKoxNHIQp, bool aoysR, double gpDuALjBmNVI);
    string UMmZLtvmkCXRQuo(double zokcuRCvaN, string LYSnWePrLStb);
    string qTmnqCRw(double TAKemdfKTgwd, bool ZxigeyRks, bool SIIzSQYO, int KEAexBmvjAoir);
    string ovCqCZjleYOKr();
    double ETNAWegMNzIMDf(int leehs, string tJtENqHllfkNH, double dxSPUDwWS);
};

double XbVsV::zoArtpQl(double PPKtPzCOukbGCig, int xcbYLqV)
{
    double MZbFgwGMIbCH = -985217.035247505;
    string vjLOzgk = string("hYoFkvmJOHeRXuUcRTtvTitHnwybLRaQYuKgLrHzthhiLuVKhDxipQJtEFANkMQwqzFHZWKxVpcWPpwedTwsVWY");
    bool QOUniMh = false;
    string lZlqZfdGcajZo = string("qbzHBaKOtdeaKSGbLdUViAjbAKLJxCuMhTLyOxNVUWoHmOeNAFiwMnDsnOxCORZunvaJTlYFiiLFsoksJnuZtGamSipvTrcFAafYZDofakmfAttNbLftiumURaTQXAtmjyEXpjNYiohAyrRhePEMOKhNojSUrdJhXrAAglMJZHLzARwifWLYVbhIbMqxvKSpmycVSSqkHbJnaMWtgHXGijStvJKgjaDWrpGknN");
    bool TMpDhZReEztrflrm = false;
    string WKnbWiq = string("agrklqVGQrfjThbMJLPnAYIEYQndKKfxDahEOrwiXVsxpLZrZrEwCwJusMSEcBqfLnmcwknwkMoYUCQYEvdOERBrpxFPMasFydDEAjSurRmorWGGradYRcMSmBegRUbozlQTJWvaQvkrRkZgpUuzkMEBMGnEFFQGleH");
    double uIMZKi = -837256.1275215241;
    double LZLpxsiBQL = -393533.5347268506;

    if (uIMZKi != -393533.5347268506) {
        for (int QaztuRYvNnck = 846020695; QaztuRYvNnck > 0; QaztuRYvNnck--) {
            lZlqZfdGcajZo = WKnbWiq;
        }
    }

    for (int pkdQtdkUBwnGq = 1232333556; pkdQtdkUBwnGq > 0; pkdQtdkUBwnGq--) {
        continue;
    }

    return LZLpxsiBQL;
}

bool XbVsV::OhigpPqyEQkN(double pTokimoMSPzo, int SVocJTS, int npvWRRRinyXV, string toPBIOTuAP, double hJPEu)
{
    string ynmOsO = string("qqOZrxoAGmaHdKtoGpkhYFWrVAnCEuwhgw");
    string aHlhLlztE = string("ZmQWQMuMdDipWAYtn");
    int zMFnbolbMT = 713007133;
    bool XoKrH = true;
    string fZPVjkesWIZNmsW = string("eaZLeAhoCjAlzcRUmviQBqYwCXRtWJQpovfULHzeqXwydjmgrLPOzXumbrGYsfLizBlgZneERZjIZmhGrZiJiBvcdoASUAtWJQdbaGRUTkAVROGNGLTrFuGiKHwTYsjXRZwESIBzllaCAqoYuYaVeHyPiMGTZNUFwWsXCzYDyxGwjzHMHIngxeO");

    for (int FCgsP = 2069261558; FCgsP > 0; FCgsP--) {
        fZPVjkesWIZNmsW = aHlhLlztE;
        pTokimoMSPzo -= hJPEu;
    }

    for (int nUxkt = 2101828198; nUxkt > 0; nUxkt--) {
        fZPVjkesWIZNmsW = ynmOsO;
        SVocJTS += npvWRRRinyXV;
    }

    for (int vepfXmsfDV = 1119958854; vepfXmsfDV > 0; vepfXmsfDV--) {
        fZPVjkesWIZNmsW += toPBIOTuAP;
        aHlhLlztE = toPBIOTuAP;
        zMFnbolbMT *= npvWRRRinyXV;
    }

    return XoKrH;
}

bool XbVsV::UYoaXIU(string qvTkVCiHQQANQ)
{
    int oxeJbc = 283861846;
    string asBastBWBfhWwNcx = string("VDQYwTdhtVoPIPdOmPnzMXUhuwhXUbTrfgCGKIZYeepzmDLpjPAwCHQokUfJJnPxewYCmuphzncNWGUFAFJUH");
    string nWHEQfSe = string("VmEiWzGmHrlFbAuKDbGZFVQgUYAsHXqPWsBgdGVZcJqyDDNoqirZGnUFBrcfBuxsLftrIkDHdUgbMVivseNbMXtNGggUbqEnutLhdukekniNnKFSigVZqqTFYLxHDRQJcfvdHOmGWxRUxUousUyOSqPrPAalBbZTzuforzPyAnxyoZWJQOJxF");
    bool ZIxDuHdQu = false;

    return ZIxDuHdQu;
}

void XbVsV::oMifgfZsAsHFA(int ARfITRYMg, int COtLF)
{
    double YZkEZwHRdLqO = -276201.96220692724;
    int YMPtdOVCgZsrY = 1745691667;
    int yIbNsXYUcy = 520826186;

    if (YMPtdOVCgZsrY <= 1745691667) {
        for (int MyzXsVi = 1223810995; MyzXsVi > 0; MyzXsVi--) {
            yIbNsXYUcy -= YMPtdOVCgZsrY;
            COtLF /= ARfITRYMg;
        }
    }

    for (int FNDWEkdUGiR = 347129714; FNDWEkdUGiR > 0; FNDWEkdUGiR--) {
        yIbNsXYUcy += YMPtdOVCgZsrY;
        YZkEZwHRdLqO -= YZkEZwHRdLqO;
        ARfITRYMg += COtLF;
        yIbNsXYUcy = ARfITRYMg;
        YMPtdOVCgZsrY += YMPtdOVCgZsrY;
        ARfITRYMg = COtLF;
    }

    if (COtLF >= 1745691667) {
        for (int MBNXUhjngs = 1751436273; MBNXUhjngs > 0; MBNXUhjngs--) {
            YMPtdOVCgZsrY /= COtLF;
            COtLF /= COtLF;
            yIbNsXYUcy -= yIbNsXYUcy;
            COtLF /= ARfITRYMg;
            YMPtdOVCgZsrY /= COtLF;
        }
    }

    for (int kPHXa = 402496810; kPHXa > 0; kPHXa--) {
        continue;
    }

    for (int XOfYgqlfxhcotjL = 99987541; XOfYgqlfxhcotjL > 0; XOfYgqlfxhcotjL--) {
        YMPtdOVCgZsrY = yIbNsXYUcy;
        ARfITRYMg -= yIbNsXYUcy;
        YMPtdOVCgZsrY *= yIbNsXYUcy;
        ARfITRYMg = yIbNsXYUcy;
        yIbNsXYUcy -= ARfITRYMg;
        COtLF -= COtLF;
    }

    if (COtLF <= -1896853958) {
        for (int TaPvKI = 1154819302; TaPvKI > 0; TaPvKI--) {
            COtLF = yIbNsXYUcy;
            YMPtdOVCgZsrY = YMPtdOVCgZsrY;
            YMPtdOVCgZsrY = YMPtdOVCgZsrY;
            YZkEZwHRdLqO -= YZkEZwHRdLqO;
        }
    }
}

int XbVsV::ovNma(int EwTdXrQKnlcaWM, int yLGHWhBwVfDuK, bool ynnstiGyKoxNHIQp, bool aoysR, double gpDuALjBmNVI)
{
    string uHbfBC = string("POAgRITUEFQlWqemQkBaVSvQjUOsHWcDfvOxsidsvuZcwzBIagcXlCoOjVxeisbiFjgMAblWuHShnDiEEQDblKFKbuWeke");
    string YIuNgTdVKokdFy = string("bPHvsqyQkHMHZXxzjDcmHsBRsQjRQbCMFIoQRGbMNqJCecUFgKfjFPNhyJPoOdVCzgXn");
    bool jpWFIDPnoqfVgc = true;
    string cbwRZkK = string("fHGzSYGSvkPMEKzxGNjlwhfkHRoEiZOhuOtznKhmMaNEiiWadkbiprpWKCzdmdjshifdxGXIRUBFfAlXIShdSfKbmlKxIBWLBrPPWZyMTCuRoGepnYRCzuQMNQKGNfYTiIfCdNfscNB");
    double yetWowZpPBrusa = -548837.0727053253;
    int pJFIfvhNeeeJXic = -301902431;
    double SXQBKsnJoRf = -215832.86964575452;
    double YiXwdA = -55565.43488780608;

    for (int oGQInqgrQuJTrPXc = 952855996; oGQInqgrQuJTrPXc > 0; oGQInqgrQuJTrPXc--) {
        cbwRZkK += cbwRZkK;
    }

    if (yLGHWhBwVfDuK > 542926178) {
        for (int OhPNcovZkH = 1625917237; OhPNcovZkH > 0; OhPNcovZkH--) {
            continue;
        }
    }

    for (int VUnXXz = 1924470044; VUnXXz > 0; VUnXXz--) {
        EwTdXrQKnlcaWM -= pJFIfvhNeeeJXic;
        YIuNgTdVKokdFy += YIuNgTdVKokdFy;
        ynnstiGyKoxNHIQp = ! aoysR;
        aoysR = ! jpWFIDPnoqfVgc;
    }

    return pJFIfvhNeeeJXic;
}

string XbVsV::UMmZLtvmkCXRQuo(double zokcuRCvaN, string LYSnWePrLStb)
{
    double pxDIk = -85862.72164506475;
    bool LOtcWepedh = false;
    double gHoiDldOXIknnH = -385335.61785543617;
    double buejZmB = -525244.8310875436;
    bool frjrSoKphMmyZCJi = false;
    double OZocJITMZq = 566374.9479113416;

    if (zokcuRCvaN <= -510106.0841180709) {
        for (int bCYQSMksOFGiK = 1755824742; bCYQSMksOFGiK > 0; bCYQSMksOFGiK--) {
            LOtcWepedh = LOtcWepedh;
        }
    }

    for (int dGFdVFAiNDDxw = 1982654935; dGFdVFAiNDDxw > 0; dGFdVFAiNDDxw--) {
        continue;
    }

    return LYSnWePrLStb;
}

string XbVsV::qTmnqCRw(double TAKemdfKTgwd, bool ZxigeyRks, bool SIIzSQYO, int KEAexBmvjAoir)
{
    bool vfsTNCKGWiI = false;
    int vqipuMaNyTlgDTp = 2084602869;
    bool TmbfPo = false;
    int UxkXtrtBaW = -1882737585;

    for (int DvJmqhABLRG = 1558986211; DvJmqhABLRG > 0; DvJmqhABLRG--) {
        continue;
    }

    for (int LQnkgOIu = 2036057250; LQnkgOIu > 0; LQnkgOIu--) {
        vqipuMaNyTlgDTp -= KEAexBmvjAoir;
        vqipuMaNyTlgDTp += UxkXtrtBaW;
        UxkXtrtBaW += vqipuMaNyTlgDTp;
    }

    if (TmbfPo == false) {
        for (int KondoUWPdWXAwX = 1405955227; KondoUWPdWXAwX > 0; KondoUWPdWXAwX--) {
            vqipuMaNyTlgDTp = vqipuMaNyTlgDTp;
            ZxigeyRks = TmbfPo;
            ZxigeyRks = ! TmbfPo;
            TmbfPo = ZxigeyRks;
            vfsTNCKGWiI = ! vfsTNCKGWiI;
        }
    }

    for (int wOKOKTqJj = 1201691276; wOKOKTqJj > 0; wOKOKTqJj--) {
        continue;
    }

    return string("xDIcXDGZUDArtiQKiprpJIkHLFrDrjbkuDmQIEQGkXUqTIEHTmSYLATWGeqBwLfshPIwILHbPLdBHwAQyfNHfTFCecgfrlTgvvBfdvyrSjcJMcwHFmilMALIGLjjVommIbEeBzcWPktDLaScsekIkWdUQzwiuGmEWwuHBIeGzRVAWkYWGFOzNSbekEDpXseiXcaj");
}

string XbVsV::ovCqCZjleYOKr()
{
    bool oVrhKlx = true;
    string OpahhAAZ = string("FVfHDeqvrJHnSxvgIBSzobCqsFyNCdGiyzqlakhiHQLoRflcpHvaIanQLygvPlijqcbCjhYpWXyNnPZOFRckIPqHzOSvuVRHtuLpHPvQwfpyAijggILyrGjKxqUTEntWtVSpfpJfZgHyuXMDwqqJlKDVAGVKhpabRQwZdEBTeruXhNydZmxTGxCfpxOLwzotuQzyRLFanPjrgElVDTmynOFEGJjqgQyoiNR");
    double KEwpWleKazrnf = 395767.93379176;
    string EfzAvUXsuQ = string("ZtXgIzSbzUGKwWXiUIuSXIIFdrjWrlTpQyopkOFENEFaNESQDsNpBFEMAciEjlHAtvvMaqZBpZIXotaOBVDfpIooZlrDodgegkgbNVkUjNLgbkvgIUdZvoQcCzHrjdOWTFHZlZEwSXwtZgIWVjKBTqgtsmTOfcSNqlZLIUwHlUKTQAKkpJEknA");
    double hiBUxWYRP = -519860.3633952135;
    double QCCXpTEQla = 1015007.2508586898;
    bool ndqKtgU = true;
    int hfXoAHJhKYk = -128355778;

    if (EfzAvUXsuQ < string("ZtXgIzSbzUGKwWXiUIuSXIIFdrjWrlTpQyopkOFENEFaNESQDsNpBFEMAciEjlHAtvvMaqZBpZIXotaOBVDfpIooZlrDodgegkgbNVkUjNLgbkvgIUdZvoQcCzHrjdOWTFHZlZEwSXwtZgIWVjKBTqgtsmTOfcSNqlZLIUwHlUKTQAKkpJEknA")) {
        for (int zZAernSabxPV = 1651784441; zZAernSabxPV > 0; zZAernSabxPV--) {
            OpahhAAZ = OpahhAAZ;
            hiBUxWYRP -= KEwpWleKazrnf;
        }
    }

    for (int GKyBywuu = 212316619; GKyBywuu > 0; GKyBywuu--) {
        KEwpWleKazrnf -= QCCXpTEQla;
    }

    if (QCCXpTEQla >= 1015007.2508586898) {
        for (int zXMxmNGxsPgicZZ = 1856464876; zXMxmNGxsPgicZZ > 0; zXMxmNGxsPgicZZ--) {
            oVrhKlx = oVrhKlx;
            EfzAvUXsuQ = EfzAvUXsuQ;
        }
    }

    for (int PyoCRTlNs = 1707309718; PyoCRTlNs > 0; PyoCRTlNs--) {
        continue;
    }

    return EfzAvUXsuQ;
}

double XbVsV::ETNAWegMNzIMDf(int leehs, string tJtENqHllfkNH, double dxSPUDwWS)
{
    double EdXGbXRSBazm = -756009.9088845403;
    bool OcpynqCdczd = true;

    for (int iNctank = 2103290643; iNctank > 0; iNctank--) {
        continue;
    }

    if (dxSPUDwWS <= -756009.9088845403) {
        for (int yoDHAwherxkENmEU = 151471007; yoDHAwherxkENmEU > 0; yoDHAwherxkENmEU--) {
            OcpynqCdczd = ! OcpynqCdczd;
            dxSPUDwWS *= dxSPUDwWS;
            EdXGbXRSBazm -= dxSPUDwWS;
            OcpynqCdczd = ! OcpynqCdczd;
        }
    }

    if (dxSPUDwWS > -756009.9088845403) {
        for (int GIPDmWQRHPI = 1165801923; GIPDmWQRHPI > 0; GIPDmWQRHPI--) {
            EdXGbXRSBazm *= dxSPUDwWS;
        }
    }

    for (int fiHLGSshZD = 386987419; fiHLGSshZD > 0; fiHLGSshZD--) {
        EdXGbXRSBazm *= dxSPUDwWS;
    }

    return EdXGbXRSBazm;
}

XbVsV::XbVsV()
{
    this->zoArtpQl(-125796.63477971211, -942281721);
    this->OhigpPqyEQkN(-254690.56486637032, -1587536880, 982489067, string("RzRhFdYudxwfodXvPvOFDNReeIwPLqJbBwCWmgnPBeVDIkAOZCaZQUScmjhrZklgUKhLyFOHAyJzV"), -1031904.8078386768);
    this->UYoaXIU(string("ioGTwprxVNmfzjMKqCWdIGZlHnEhQSxKbupQEQXmzrrxlRfPgUpchbyaPfZsbUedCsXVkxheFBEPaRxeLvoPiZytLZQciUWhlzGoQxRAcxNUMnYIiOxfAExddPqyzgjGNfGiDDCDSkJUuhAjosELWMdfbrcEOrHTgxXDJYaopiorwhhPPhIdemZ"));
    this->oMifgfZsAsHFA(-1895056816, -1896853958);
    this->ovNma(542926178, -218568292, false, false, 517090.26912624994);
    this->UMmZLtvmkCXRQuo(-510106.0841180709, string("ZtrcNYTxWuuYurSjvwvtsDLtfUwyoOlJykKEvEOugQKoCazMNOqoOfUDQLaQlojfVSQwHqIUkHhIdwbxQOBstAlnIAPyYCnGzUVeVKdwyHClzNQkecNrPJMDUcTBVZzRgaSGEFlWJIVcCVQNTa"));
    this->qTmnqCRw(350856.57984550315, false, false, -1156089424);
    this->ovCqCZjleYOKr();
    this->ETNAWegMNzIMDf(-496836464, string("ZVcSdVKrrEkAmthzLfCwnUFJhymHoYKdkCvuoCjxbvT"), 387588.34659470594);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FYIJsjepKjHLj
{
public:
    bool VEdoPVIOARvhlI;
    string OqNREjuV;
    string KFlFoVMAGNv;
    double DtqZhEHlkodsD;

    FYIJsjepKjHLj();
protected:
    string EJKHJcRr;
    double WKpVlP;
    string CYLzbPWzMEJk;
    bool AKfYgy;
    int BKcvOyize;
    int hygwBMvYGQqwe;

    void vZSIw(int oyVTPITZowrgbCj, double VDpDchoiGTNN);
    double GhPtsSeMOvyJ(double lXpJYMAxmlc, bool ofGcIuNejp);
    void PbXJpxeOMkbQtmqi(string nGqMyQvfY);
private:
    double UIPxQYCqvWnHJrv;
    int AWyJFHuOFhz;
    int XLWDVyiJVxSE;
    double GMVPHAEe;
    string FJNDJI;

    void TKuNrgIh(int WbOydiLpTExzwjx, string vsaHvGJfXIiCFdV, bool jFLByqUWmqAdVl);
    double YGcwTWIU(int GgfLPC, string YsJHfWHJdMEcy, double bvxrsDN);
    bool lZnNRb();
};

void FYIJsjepKjHLj::vZSIw(int oyVTPITZowrgbCj, double VDpDchoiGTNN)
{
    double uMsqOmwou = 445817.49128090154;
    int qGEVcSuseLWvCEJD = -62983841;
    double uHifr = 164197.19049311;
    bool OvhAl = false;
    double SSfTqGygyAsYPbZO = -728593.92982937;
    double meEpHvbq = 15695.287792737201;
    double GsLHEncao = 139312.13244619005;
    double iPRQGYFWXBrKcB = -549692.9738808989;

    for (int SDdEsOElnqbY = 1376080909; SDdEsOElnqbY > 0; SDdEsOElnqbY--) {
        SSfTqGygyAsYPbZO += uMsqOmwou;
        SSfTqGygyAsYPbZO = meEpHvbq;
        meEpHvbq *= VDpDchoiGTNN;
        meEpHvbq -= meEpHvbq;
        qGEVcSuseLWvCEJD /= oyVTPITZowrgbCj;
        uHifr = SSfTqGygyAsYPbZO;
        qGEVcSuseLWvCEJD *= qGEVcSuseLWvCEJD;
        uHifr *= uHifr;
    }
}

double FYIJsjepKjHLj::GhPtsSeMOvyJ(double lXpJYMAxmlc, bool ofGcIuNejp)
{
    bool SqhkOQikwWtRJxe = false;
    bool SxkRorvvVf = false;
    bool SCyFyWuJhdhUFI = true;
    double tIUwi = -525538.0259449948;
    double uMGaqsxN = -719611.965175935;
    int hbrEefouc = 666443139;
    bool yeLbla = false;
    bool GuZKAHtEmPkjxkv = false;

    for (int FjfzwPvKvepw = 1364391219; FjfzwPvKvepw > 0; FjfzwPvKvepw--) {
        tIUwi -= tIUwi;
        SqhkOQikwWtRJxe = SqhkOQikwWtRJxe;
        SqhkOQikwWtRJxe = ! GuZKAHtEmPkjxkv;
        uMGaqsxN *= lXpJYMAxmlc;
    }

    for (int ZyAKAnHSnKsAYHZ = 1972999456; ZyAKAnHSnKsAYHZ > 0; ZyAKAnHSnKsAYHZ--) {
        yeLbla = ! SqhkOQikwWtRJxe;
        tIUwi /= lXpJYMAxmlc;
    }

    for (int SvWOY = 562360257; SvWOY > 0; SvWOY--) {
        ofGcIuNejp = ! ofGcIuNejp;
        GuZKAHtEmPkjxkv = ! yeLbla;
        SCyFyWuJhdhUFI = ! GuZKAHtEmPkjxkv;
        SxkRorvvVf = ! GuZKAHtEmPkjxkv;
        ofGcIuNejp = SCyFyWuJhdhUFI;
    }

    if (yeLbla != false) {
        for (int FuLvtBZ = 1560180841; FuLvtBZ > 0; FuLvtBZ--) {
            lXpJYMAxmlc /= tIUwi;
            SCyFyWuJhdhUFI = GuZKAHtEmPkjxkv;
            ofGcIuNejp = SqhkOQikwWtRJxe;
            yeLbla = ! SCyFyWuJhdhUFI;
        }
    }

    for (int nkxIrHUg = 194386276; nkxIrHUg > 0; nkxIrHUg--) {
        ofGcIuNejp = ! yeLbla;
        GuZKAHtEmPkjxkv = ! GuZKAHtEmPkjxkv;
    }

    for (int cdyHLu = 1458672744; cdyHLu > 0; cdyHLu--) {
        SqhkOQikwWtRJxe = SCyFyWuJhdhUFI;
        SCyFyWuJhdhUFI = ! yeLbla;
        lXpJYMAxmlc *= uMGaqsxN;
    }

    if (GuZKAHtEmPkjxkv == false) {
        for (int NGPtWrzBfVyfZzd = 1720609062; NGPtWrzBfVyfZzd > 0; NGPtWrzBfVyfZzd--) {
            GuZKAHtEmPkjxkv = SxkRorvvVf;
            SCyFyWuJhdhUFI = ! SqhkOQikwWtRJxe;
            tIUwi /= lXpJYMAxmlc;
            lXpJYMAxmlc += tIUwi;
        }
    }

    return uMGaqsxN;
}

void FYIJsjepKjHLj::PbXJpxeOMkbQtmqi(string nGqMyQvfY)
{
    int OkUdp = 197009758;
    bool jMbfAFepY = false;
    bool kidlLQv = false;
    string LfEmiKQlzNhv = string("sbZcikERLzfwgrGdGzGfDshdwSXPvAMlGNhfKwcrDauuDbZALC");
    string MxMDMFwsiS = string("fzyoQFLLjqTRglwykjSYcQOVfaDQNRoNWCnswUhMFRoNVbxeGwWvsPOeFDxWXM");
    double lqFenMxqmmaHOJn = 172380.7045308205;

    for (int duIQbySLTJBmjHHv = 1221114219; duIQbySLTJBmjHHv > 0; duIQbySLTJBmjHHv--) {
        nGqMyQvfY = nGqMyQvfY;
        MxMDMFwsiS = LfEmiKQlzNhv;
    }

    for (int GgCjjWnHCyLZBeF = 1801863259; GgCjjWnHCyLZBeF > 0; GgCjjWnHCyLZBeF--) {
        nGqMyQvfY = LfEmiKQlzNhv;
        MxMDMFwsiS = LfEmiKQlzNhv;
        kidlLQv = ! kidlLQv;
    }
}

void FYIJsjepKjHLj::TKuNrgIh(int WbOydiLpTExzwjx, string vsaHvGJfXIiCFdV, bool jFLByqUWmqAdVl)
{
    string mMCuDC = string("FEKYYfUUNHGZwLhwmrfioABPPYzCIfQGqfR");
    int JYOpPiTq = 1888844360;
    double HKFJggEySHOa = -960836.1443644988;
    double kZxhEAFWYft = -523420.7809335127;
    double GYHcVysLnI = -1005117.1054367577;
    bool VJyiqGiOGZYVpvX = false;
    bool ALsayQLYRJmIQ = true;

    for (int uPQwzbAIdMrcsNu = 1720323128; uPQwzbAIdMrcsNu > 0; uPQwzbAIdMrcsNu--) {
        kZxhEAFWYft = HKFJggEySHOa;
        mMCuDC = mMCuDC;
    }

    for (int IGzbokLCvvyue = 1128793245; IGzbokLCvvyue > 0; IGzbokLCvvyue--) {
        GYHcVysLnI /= HKFJggEySHOa;
        mMCuDC += mMCuDC;
    }
}

double FYIJsjepKjHLj::YGcwTWIU(int GgfLPC, string YsJHfWHJdMEcy, double bvxrsDN)
{
    double XeJHHIDKQOLOanGz = -137793.80570276844;
    double eaDRNHjrGlxIe = -241924.27964276358;
    double OGnjexbdLn = -17515.936714947034;
    bool xvDZYjKSMb = false;
    bool btiMuVakFtnXcB = false;
    double qGeVwnzRvhNF = -909637.8544806947;
    string VdWjRFlqsh = string("pItzHTryOPcKfZaoosFQmQFRfddTTTclDpRhL");
    string bfEqJdmvxyQMPfg = string("gGwEPupeAOPiAsaWFDvdEvCQWeVIeaNJMzABmgKOUEigbRfWxgEeaEXGVeFxRiEKqXUxnNFfEbWEYCVnTauCmAPplSfNvpRPqIuvgAFknPEJcLCCggGzMoIusiqRKMROqvxcsRMJFCmnziqdzgxzImgHnWUegbCzUJJUxzVTaxKhuLsEYkAlkbRamThxuyFgKTdk");
    int EhYoLmISwHguA = 1563014729;

    if (VdWjRFlqsh != string("gGwEPupeAOPiAsaWFDvdEvCQWeVIeaNJMzABmgKOUEigbRfWxgEeaEXGVeFxRiEKqXUxnNFfEbWEYCVnTauCmAPplSfNvpRPqIuvgAFknPEJcLCCggGzMoIusiqRKMROqvxcsRMJFCmnziqdzgxzImgHnWUegbCzUJJUxzVTaxKhuLsEYkAlkbRamThxuyFgKTdk")) {
        for (int ScoLCyBLtR = 303585134; ScoLCyBLtR > 0; ScoLCyBLtR--) {
            continue;
        }
    }

    return qGeVwnzRvhNF;
}

bool FYIJsjepKjHLj::lZnNRb()
{
    int uODxUAOWuZsNVV = 1902464255;
    int PcKjTYDKIGVMuW = -1088151042;
    string kuTRWwVkzEfV = string("vwnrFfKyTVWAaqcySxpUdLkasihWQzHYfLRVrnbLruGpIWWZVyzdSUdXBhTtrWMEXWDkZouXmsUoleHcuWTRsyBNAytSAPHIVSOGvDfaxFjRWnoVKlvnRNkfKEjSUfXjLcZdZoqfGvgInXsSBarrL");
    bool zaXyurbHnLh = true;

    for (int EfTitwtisOvqsH = 968725812; EfTitwtisOvqsH > 0; EfTitwtisOvqsH--) {
        PcKjTYDKIGVMuW -= PcKjTYDKIGVMuW;
        uODxUAOWuZsNVV -= PcKjTYDKIGVMuW;
        PcKjTYDKIGVMuW *= PcKjTYDKIGVMuW;
        zaXyurbHnLh = zaXyurbHnLh;
    }

    if (PcKjTYDKIGVMuW == -1088151042) {
        for (int qXrYIQ = 797304518; qXrYIQ > 0; qXrYIQ--) {
            uODxUAOWuZsNVV /= PcKjTYDKIGVMuW;
        }
    }

    return zaXyurbHnLh;
}

FYIJsjepKjHLj::FYIJsjepKjHLj()
{
    this->vZSIw(-340939983, 885239.3366216036);
    this->GhPtsSeMOvyJ(124878.55013827767, true);
    this->PbXJpxeOMkbQtmqi(string("CHFzuijrLqcjQNTJiMBruAWvtrULvZctRiMXIBpLkRfUQiqkXgDofZkvfUDdtpBBxwIsouQsDGzPqvEdvfNhRJTPJTexRGfKnBFUMjTZstGgyPlzkmqKpbiDoCLWlQTHnGMwAgJKydFYz"));
    this->TKuNrgIh(-339984815, string("hICPScTqvspxDfVgkLAYuglaHLLcAFUAprVVMWygDlQYfGxpPpVTpVzKPGHvpibWIVUKRtYBqAElykTXGlCUKKGjvsZeqbpVqlEmmHoTuZLlmssFmYyPPYmueReSMlydAduQpEjhVKBMfZFdvXbXUwbxNMqEnGrwvulx"), false);
    this->YGcwTWIU(1060977995, string("BWnfUcHDNaGyoOwDhzFQzmHGGqiwgbBdiqejLkVNaVzEEYoHzhnoFzlwPyDuFJBmwONRfxxtqdLYqMziwRWzStcWXKu"), -173580.64305923996);
    this->lZnNRb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wuTotgQEmNDpR
{
public:
    string HDqnJG;
    int hAZIxJcw;
    bool EUxZrWlxuy;
    bool OUvtQhDlPZALfUbt;
    int rNEKsSP;

    wuTotgQEmNDpR();
    int qaaTH(string MznsN, double aeONhBe, string UtVijrvBMv, string ayOghEdMBcqp, bool IyQUglrkWC);
    int fwjRKRXFfUYB(bool eWfoIUoEmRRvI, double AktzPxaNJIC, double FalaQWtJT, double oDGCKnrTXlGrCe, bool JpWlJoZbjqj);
    double eAtfIVgG(bool KMEoCOxjNjShB, double rpPXD, int kWGyzTU, string oDoCcnjVSMwM);
protected:
    double qpVOTBidjX;

    string OcQROkpPn(string bsQhSaIWuhOGYY, string rMptIvBVUiTslzmE, bool spVHVNec, string KtmNmSRUWHIx, double ODZgwaCy);
    string LJJwKiecUjDaCBaJ();
    double ouqWARgqaIREQke(string JfRWrTbAybKDaW, bool WcvSQ, string JKgreN);
    bool lZFevnbJgNNrk(string oEVrysVLHjKIF, bool TTQnJBaXD);
    int XrLaamTvlySnwLm();
private:
    double IGCSVmsdRP;
    double zlBGaiFhqRh;
    int KgAcYgnVC;
    int HUdjIjFpYGXSUyh;

    bool zTsLdvRQ();
    void NFnRoEqGXYoCtcPI(bool VkfQPQbXXhZfJ);
    void BYJaUKQCFgn(int lJReXLoIWjUPiyTa, double YXVlbysvUJAgEeZ, bool rEHsOF);
};

int wuTotgQEmNDpR::qaaTH(string MznsN, double aeONhBe, string UtVijrvBMv, string ayOghEdMBcqp, bool IyQUglrkWC)
{
    string VgIzjRTXdhx = string("YNKFR");
    bool jyYFId = false;
    bool TZimYrjoYKq = false;
    double mrzFEjcgz = 505542.5291020015;
    bool kOpktsBEi = true;
    bool QfwbONCIut = false;
    int SbAHLbqbyy = -454102016;
    string GoHlTnsgilsPoFic = string("PZbFSCMktJI");

    for (int UEdqi = 198794506; UEdqi > 0; UEdqi--) {
        mrzFEjcgz -= mrzFEjcgz;
    }

    if (IyQUglrkWC == false) {
        for (int yXkUnK = 852741465; yXkUnK > 0; yXkUnK--) {
            QfwbONCIut = ! kOpktsBEi;
        }
    }

    return SbAHLbqbyy;
}

int wuTotgQEmNDpR::fwjRKRXFfUYB(bool eWfoIUoEmRRvI, double AktzPxaNJIC, double FalaQWtJT, double oDGCKnrTXlGrCe, bool JpWlJoZbjqj)
{
    int ZsCJMrPjzehHdqiY = 318151013;
    int fVWAViEsfHUpltc = -1450600881;
    double diWymMzLhR = -501105.823071885;
    string uIDgulKDIoDsCV = string("fniypvOaIvgjLflMkuBBvSOXyXBISDYjOhdnJtyHpkDmjxwNwDhGgAVcskLmQDircMElGhwEUyHNCKkKBGsVVXnSSiLSZONsDSSsldRGoagOltneKKdbzGZpluBvsxavBQjFdVXOBbOREpDjymQDHWzsXgUmkxgDZRDnmRuhtdsIIKwgLXCHdcyyLIK");
    int hDmCEdw = 770579704;
    string dRihWKypVf = string("sDinNtpmvSDMWvfEqaaziXhWaieYqvdfdryvGWBXAnsfGYKCCQQvRtEVUBKuliJNnnitizYcIwxNaZlwuUzrjkKDtAvmLYqGjx");
    bool mfxTcDf = false;

    for (int iUEvkPgCj = 1228002870; iUEvkPgCj > 0; iUEvkPgCj--) {
        ZsCJMrPjzehHdqiY /= hDmCEdw;
        mfxTcDf = ! JpWlJoZbjqj;
    }

    for (int tbGRTuGZYtH = 1343106665; tbGRTuGZYtH > 0; tbGRTuGZYtH--) {
        eWfoIUoEmRRvI = eWfoIUoEmRRvI;
    }

    for (int qNETScGxEYJbZQM = 1594052358; qNETScGxEYJbZQM > 0; qNETScGxEYJbZQM--) {
        FalaQWtJT -= oDGCKnrTXlGrCe;
        FalaQWtJT += AktzPxaNJIC;
        oDGCKnrTXlGrCe = FalaQWtJT;
    }

    if (diWymMzLhR > 236693.11373231973) {
        for (int HAfATrtZoPj = 1227896428; HAfATrtZoPj > 0; HAfATrtZoPj--) {
            FalaQWtJT += oDGCKnrTXlGrCe;
        }
    }

    if (diWymMzLhR == 937757.1779919832) {
        for (int gHLfcayrSBbKm = 1230437855; gHLfcayrSBbKm > 0; gHLfcayrSBbKm--) {
            AktzPxaNJIC /= FalaQWtJT;
        }
    }

    return hDmCEdw;
}

double wuTotgQEmNDpR::eAtfIVgG(bool KMEoCOxjNjShB, double rpPXD, int kWGyzTU, string oDoCcnjVSMwM)
{
    int FOgTdGymLFn = 1551827498;
    string rbdpp = string("FIqSOZNBosESdgwCLPuJarEqfrevKwlhrAr");
    double MPFFTLBDLxL = -1009457.6262757793;
    string mLNbKDCreGU = string("FCSajDtPEytOyjELaTrCILIZDhiiNGBMT");

    for (int DmEwK = 279675570; DmEwK > 0; DmEwK--) {
        mLNbKDCreGU += mLNbKDCreGU;
        mLNbKDCreGU += mLNbKDCreGU;
    }

    for (int fdMRVLSLaWyIGgeL = 423862097; fdMRVLSLaWyIGgeL > 0; fdMRVLSLaWyIGgeL--) {
        rbdpp += oDoCcnjVSMwM;
    }

    return MPFFTLBDLxL;
}

string wuTotgQEmNDpR::OcQROkpPn(string bsQhSaIWuhOGYY, string rMptIvBVUiTslzmE, bool spVHVNec, string KtmNmSRUWHIx, double ODZgwaCy)
{
    bool HoJuByakSrCg = false;

    return KtmNmSRUWHIx;
}

string wuTotgQEmNDpR::LJJwKiecUjDaCBaJ()
{
    double cLSrepLllGGTv = 1009329.5606929329;
    bool ajOtubYwSC = false;
    string BXLQtQg = string("YuTBBylRwJBGrbPVzybZlMJztydVQvFhnfwvDqOiYplyFCunaHlzohzAUWFzdbocQAnMzeCcZKeBNFHgBfOPWsjKOZaDPVMpNDNkdnphHhntlTjISAqmTetDnSjFoNXMYUOmAMseD");

    for (int hynFJe = 699693560; hynFJe > 0; hynFJe--) {
        BXLQtQg += BXLQtQg;
    }

    for (int xhYbsrxzXayCuE = 2046186964; xhYbsrxzXayCuE > 0; xhYbsrxzXayCuE--) {
        ajOtubYwSC = ! ajOtubYwSC;
        cLSrepLllGGTv *= cLSrepLllGGTv;
        BXLQtQg += BXLQtQg;
    }

    if (cLSrepLllGGTv > 1009329.5606929329) {
        for (int LfkquvSMybJQj = 836520591; LfkquvSMybJQj > 0; LfkquvSMybJQj--) {
            continue;
        }
    }

    if (ajOtubYwSC == false) {
        for (int bgeNhzfkgswBLidt = 1050492851; bgeNhzfkgswBLidt > 0; bgeNhzfkgswBLidt--) {
            cLSrepLllGGTv = cLSrepLllGGTv;
            cLSrepLllGGTv = cLSrepLllGGTv;
            ajOtubYwSC = ajOtubYwSC;
        }
    }

    for (int wpurljkrbaEf = 577817153; wpurljkrbaEf > 0; wpurljkrbaEf--) {
        continue;
    }

    for (int YGXUAprA = 1329261579; YGXUAprA > 0; YGXUAprA--) {
        BXLQtQg = BXLQtQg;
    }

    return BXLQtQg;
}

double wuTotgQEmNDpR::ouqWARgqaIREQke(string JfRWrTbAybKDaW, bool WcvSQ, string JKgreN)
{
    double kUqnIVtosfOrX = -704805.9807290646;
    int RrTnnvFFkqZIN = -1556725745;
    double pkQLZQLcT = -641146.4610581661;
    string YcXyeSWcEUdrujf = string("mQXAoVLVMtlvUXeUNrKrxWQVIwkMuqNGHEYeSHwnNLosCpZWmLyaUWyfOvtklnksYAuItAkVUSrdpJVROApjjaaHoAxdbiaHJfnvOcRzkReAlvthdaFbQrPoVuCBoYukVsEHjNYLsDQddAOeEP");
    string mZVaUpQrnh = string("cIULEljZSzcsFwIZHPVLGVoeHGBJuxpWTKeIFmwrPJlCjIJzdPXNIin");
    string jGYJRLQtE = string("EioAQAiALRlumDvkxgbWSuDfbFyBqPEyNCPNCRuatSQlkONHQYAkOgxVIZDAHaRHVafDWQyTXDSIGCmqisAMiFmEAFLWME");
    bool RWVwfnXC = false;
    string SLysG = string("ZWTzVuzhtsMIQfkZQSxkGJVgwjEWmlWuNcJUqPGhUxLGMSOakXmcyQmbTRszCyhdOFpVrjBVdrqViZsYDaeKWftJDlVUSWKkIqJBvricjJNBuWoRtcM");
    double KdJdxyvLIYijC = -591985.8250382151;

    for (int PSoByNj = 1842035196; PSoByNj > 0; PSoByNj--) {
        JKgreN += mZVaUpQrnh;
    }

    if (jGYJRLQtE >= string("mQXAoVLVMtlvUXeUNrKrxWQVIwkMuqNGHEYeSHwnNLosCpZWmLyaUWyfOvtklnksYAuItAkVUSrdpJVROApjjaaHoAxdbiaHJfnvOcRzkReAlvthdaFbQrPoVuCBoYukVsEHjNYLsDQddAOeEP")) {
        for (int OQqNvkmDK = 1694214310; OQqNvkmDK > 0; OQqNvkmDK--) {
            JKgreN += mZVaUpQrnh;
            YcXyeSWcEUdrujf = SLysG;
            JfRWrTbAybKDaW += jGYJRLQtE;
        }
    }

    return KdJdxyvLIYijC;
}

bool wuTotgQEmNDpR::lZFevnbJgNNrk(string oEVrysVLHjKIF, bool TTQnJBaXD)
{
    double NcJxsqDyeeU = -585463.1692703874;

    if (oEVrysVLHjKIF >= string("OZtjgQPqHjsQtyNzyEpzByNQwsRpuFUlFJiqYTfZnfhWNsEutefZJqcgXKvoxwUugUMccGvSCxshfhqtZFCsNYlgtzDA")) {
        for (int HaiTFPyn = 1247352401; HaiTFPyn > 0; HaiTFPyn--) {
            TTQnJBaXD = TTQnJBaXD;
            TTQnJBaXD = ! TTQnJBaXD;
        }
    }

    return TTQnJBaXD;
}

int wuTotgQEmNDpR::XrLaamTvlySnwLm()
{
    double hAdLZNC = -595907.3023794637;
    double bwmZrNLssGM = -398758.0841497978;
    bool xBcEZOZWkbxzp = false;
    bool jHcyiJ = true;
    string LgkQtE = string("HeViwSKdIZsqSWbfUDhNfRVltLCpKYPSJnbOjuwXYhVBhBdKfQEIuoQKZEYNZtlOlVZnvSnQBjYVoeGPAZuXEQVokprrSHfbyXdyANrsCwbwcEjmEztnqAqrRLWaws");
    bool GREMIUdTj = false;
    double LqeuzVvUo = -818542.1502699463;
    string hSEfc = string("YsvDPejUfjhuVStmXMcEZKfJeimXlNKAahphfcCIzFnFAGwsoFRSsfdgSlzoWkETdxJvhYtghkfEfcGcKoxyEKdpFlpLcdGbayfzltoWolwzgopKNlvPCrZcrttaiPHhKfMUIXxNUSPacuRdDaaxivqBsVtvRugTGLhgcv");
    bool vCrOuVOfvQiE = true;

    if (jHcyiJ != true) {
        for (int nPgLkUqpt = 542099212; nPgLkUqpt > 0; nPgLkUqpt--) {
            hAdLZNC *= LqeuzVvUo;
            bwmZrNLssGM += hAdLZNC;
            jHcyiJ = jHcyiJ;
            GREMIUdTj = vCrOuVOfvQiE;
            LqeuzVvUo *= bwmZrNLssGM;
            hAdLZNC -= hAdLZNC;
            bwmZrNLssGM -= bwmZrNLssGM;
        }
    }

    for (int uhAqXIFDkEvSuu = 445309279; uhAqXIFDkEvSuu > 0; uhAqXIFDkEvSuu--) {
        jHcyiJ = ! xBcEZOZWkbxzp;
    }

    return -1988618178;
}

bool wuTotgQEmNDpR::zTsLdvRQ()
{
    int uXGQdlUtRmyqVn = 259772066;
    string VqsBhgGPeQtEDvH = string("AWVILtEqFGHoOkiQOgkkPGlDXrgDdGTGWWjnuXDvHUuqZCdySMlEmZpsqjftBGGCTHepFSALDYgwXaTyKRiOsUFQZNoxvPDNnYPJJLBTxLVdDbbRLjpNHIkBvfzdyGBaiWzJxa");
    string OInZygIKKZ = string("rByEPNwqnRcmJOXLxyRQDhkdpVxOmNoRMvyOlmReYOsbLBwQhbTeqtMYKJGEPHBXfHkLYRfztlciXvUFpUOKtmoQLDajmTtXRioodtPfdsrklnrVZixDYPNWkwGxybRQqzXPucOtqkYBcnTDfXtG");
    bool DZsvWhLtIorDgst = false;
    int PTSRKrANJvxTR = 1986330887;
    int TXODUO = -160251562;

    for (int cWSaAohVWDn = 1631984412; cWSaAohVWDn > 0; cWSaAohVWDn--) {
        PTSRKrANJvxTR = uXGQdlUtRmyqVn;
        TXODUO -= TXODUO;
    }

    if (DZsvWhLtIorDgst != false) {
        for (int jwavrsBSBgcAiKR = 1836378117; jwavrsBSBgcAiKR > 0; jwavrsBSBgcAiKR--) {
            PTSRKrANJvxTR = TXODUO;
        }
    }

    return DZsvWhLtIorDgst;
}

void wuTotgQEmNDpR::NFnRoEqGXYoCtcPI(bool VkfQPQbXXhZfJ)
{
    int lyNheyGFeLVZwNAi = 804544431;
    string vOanYcSzZFVvy = string("noXDONkgEgXtqXqCuIwSoWGMDNjVaSlqqpmIhBLIBsUnKopyHriwVEkBFkOigq");
    double cnPPxzoCHLAmcbJr = -568538.4632924137;
    double bjoykUC = -169623.86044232533;
}

void wuTotgQEmNDpR::BYJaUKQCFgn(int lJReXLoIWjUPiyTa, double YXVlbysvUJAgEeZ, bool rEHsOF)
{
    bool xFJuYSKGNqvLyoEJ = false;
    string mngyo = string("EBBElHXTKNPewUgsTbvNeBcqoHYAPVVaNlzJizCEmDLMDznVFwoaHWVHyJWiQmTXWjUPQlDGJAMClDxHwBXlknGRDQRARKTsbwbLQSPZoqToYUFKGdfRHmwhHOpMYzbQrBlcoOdevMaKbUGXPhxbWjsgVjiTFPpJBTQTIAgaSjzsHTsesHYthMahAEVnjffzCzZyKfoGpvgKBmqmHdPMOneXllfRZjpKALIHMTXQDgmIHmkEGYB");
    double hyZnKkrFEceZIrRs = -312387.3953220623;

    for (int NMVqhANsyOFNJ = 1388262844; NMVqhANsyOFNJ > 0; NMVqhANsyOFNJ--) {
        continue;
    }

    if (mngyo != string("EBBElHXTKNPewUgsTbvNeBcqoHYAPVVaNlzJizCEmDLMDznVFwoaHWVHyJWiQmTXWjUPQlDGJAMClDxHwBXlknGRDQRARKTsbwbLQSPZoqToYUFKGdfRHmwhHOpMYzbQrBlcoOdevMaKbUGXPhxbWjsgVjiTFPpJBTQTIAgaSjzsHTsesHYthMahAEVnjffzCzZyKfoGpvgKBmqmHdPMOneXllfRZjpKALIHMTXQDgmIHmkEGYB")) {
        for (int eMlqPZGpnkbGG = 35949873; eMlqPZGpnkbGG > 0; eMlqPZGpnkbGG--) {
            YXVlbysvUJAgEeZ += hyZnKkrFEceZIrRs;
            YXVlbysvUJAgEeZ -= YXVlbysvUJAgEeZ;
        }
    }

    for (int DPAZsFcJHmc = 1424349698; DPAZsFcJHmc > 0; DPAZsFcJHmc--) {
        YXVlbysvUJAgEeZ /= YXVlbysvUJAgEeZ;
        YXVlbysvUJAgEeZ -= YXVlbysvUJAgEeZ;
    }

    for (int bKSTSmgjQthP = 20566229; bKSTSmgjQthP > 0; bKSTSmgjQthP--) {
        YXVlbysvUJAgEeZ /= hyZnKkrFEceZIrRs;
        hyZnKkrFEceZIrRs *= YXVlbysvUJAgEeZ;
    }
}

wuTotgQEmNDpR::wuTotgQEmNDpR()
{
    this->qaaTH(string("gcoecbwPbvoewTETugsyjTEmbwSfKjEQhDAmtLLgvHavLCDEeoXpGDXgvsBiXsNTrfLfsFpcRFMvETrhYUJJInVneZoLdDKBfmwIzHFjfwmxGRmZNGGXtGRBLCUkEfyxWGX"), -154104.37918658153, string("lJHWcbVMetzKSprQngrgjqAhbijzrzzuToVVjidobfIdCshRzbxCtbEWVxYYqAsUYqeRxVgpjkdqJnxMdJGFPECEhmVJY"), string("VCmfvrbhCkczd"), false);
    this->fwjRKRXFfUYB(true, -397524.194323331, 236693.11373231973, 937757.1779919832, false);
    this->eAtfIVgG(false, 358017.2406061792, -1793873600, string("GrrtIWTCMgTwpDGJDcmvwrBsAeWrRGRwyGHlEpdPfmBhIhROTXHpFj"));
    this->OcQROkpPn(string("WWOdDextsIcAyVMRJeZbkgLLtSYhlWZATuqeWrXNifiYMhprislVnshDDlXgtQrocAyWwMLiYyptEjOcEnbrDvkSUqqRoBcgnryYTdNiDWOhCOYUFDBrTsnhtBGFQmpuiVMSNFfyXhllyHSZOlZyvxsNlIJWLSWPXkNYTkvBQXfcWPLvuyQaNzFqGBDLqAyncAkteAqjXKOsNQA"), string("brSDdCFyxglcBnHBHUZTwJuRDnNDrpYMLObVUWxPLKJxgxBpUwBNvvTNhscuagwJHZGDgckJudurENkOdaxSHVTYoalwTTjPLBIPEjlozKrZXnozquymmPxsHKslqewPuGInLFVIyAHWBCQLHPrkWmXcnLI"), true, string("ZMZFTEXvYZkrKYyioXZStjWImbsJJIiinaNfZCUUFNTrwUndGWJiG"), -623556.9752532953);
    this->LJJwKiecUjDaCBaJ();
    this->ouqWARgqaIREQke(string("OmTSHbNuOnwSPRRqyIlcJOgBRIkwEahdKpxYMChHjFHIAZANxFhjrgTJNpFzTPzUIhuKlqXDUoxTeLpCncqBDcYEadjTcLFHjBhoAXxJuVnZDHFyjMLfEcxWxaBZGKGuyDmXbcthzWAJWvLVnLcYzGFmHRAloUuKPKXXyAjfZWYVAkXfCrkeqONsBSeUSGgzkSTfFaYYogKTwIQVWdvrdDAYqGNU"), true, string("hLKdYOeeExuppdsCvAkTqkzVmueQKspyjNOWdluAaoCEasGdfhTDIBLgBtoecdhSgJQWSkRBLOYFqbfEflerTRwIccGpruOtPCWQURUKWVtngCYGdUYMxAhvbnvXNGoUAcSnDTKqJhcZOUniQXSTmcuOKtPfQXanmFPDhhCocmtEnoGBFKyvYDMWCYpNRtVSMyGnCYnVqjCOdt"));
    this->lZFevnbJgNNrk(string("OZtjgQPqHjsQtyNzyEpzByNQwsRpuFUlFJiqYTfZnfhWNsEutefZJqcgXKvoxwUugUMccGvSCxshfhqtZFCsNYlgtzDA"), true);
    this->XrLaamTvlySnwLm();
    this->zTsLdvRQ();
    this->NFnRoEqGXYoCtcPI(true);
    this->BYJaUKQCFgn(1360269976, -92589.93323910862, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wZvLRHFvmoYlFIo
{
public:
    int kCZqrnGeul;
    double nmFnDbPc;
    double qmoHqpLqg;
    bool JBLyMlImjKMPPlO;
    int eLVfJLt;

    wZvLRHFvmoYlFIo();
protected:
    bool TninaxDTtp;
    double aoCtEye;
    double VNQxnisDaqCeyfVn;
    int KrGtTmQ;

    int mXVpG(bool KzVwmnvs);
    bool aihTFshHI(string uwolyEZXzMZ, bool iIQyJKbfPkMVvB, int JGBSuzvIEvnCZYm, string iDlXpHLZIwnUTXyp, string QzLTF);
    bool lPBgvTtJv(bool DORWCurxtT);
    void NVSxjQpYAxVgVd(double mzLLzFbKBa, string uZitmxjbTlWiYcrA, string KTYCPbakhQByRK, bool HsbPNlhUhRvRRAuM, bool CJammWPmxvDlJ);
    int rOPoqMbJCSqnVk(double BHLvCipq, string gHXFAbwXyGLvmVV);
    void ZsXjqxQOIHWGz(double tzCghdiDdS, bool pSysUQVeZQWraA);
    double uajwetk(int xMkxoCNsYwKK, bool DDnhQZmrioVqc, int QGUiouWqUMmXF);
    void kWpNBW(double jKeiT, int HyqtAgAheDUNxeax, bool CvbvPYvQmaQ);
private:
    double isSqlyRLeUYLn;
    double eVCmRDzNr;
    bool IszVHE;
    int OUKED;
    string IXbILhhXPmcChWaB;

    double ohqBaOSKGs(double uQBPxyr, bool eyFHOzWMfOhmnIjT, string MUhtfNDsvDMyFw, bool bPphumeovk);
    bool Uigbjt(string RaoSsYf, bool FiJiRNcrFZvqO, string NbQEWoFDYv, int VhjMBYlqu);
};

int wZvLRHFvmoYlFIo::mXVpG(bool KzVwmnvs)
{
    double KspGCnOzGZbgvbqG = 282484.42267854646;
    int qVhOVmlzAB = 1828924829;
    string HLrUWOrEKFtMB = string("vfwvBSJghyklLYLTpDsWJcNGdu");
    int TCSmLwxniRFaRC = 428567321;
    int EjvGGrHIMGfBd = -56421530;

    for (int imkfBDfmuVZBKETv = 1064946523; imkfBDfmuVZBKETv > 0; imkfBDfmuVZBKETv--) {
        TCSmLwxniRFaRC += qVhOVmlzAB;
        EjvGGrHIMGfBd -= TCSmLwxniRFaRC;
        qVhOVmlzAB += qVhOVmlzAB;
        qVhOVmlzAB /= EjvGGrHIMGfBd;
    }

    for (int qLjcdGkJJtDcEA = 460969205; qLjcdGkJJtDcEA > 0; qLjcdGkJJtDcEA--) {
        TCSmLwxniRFaRC -= qVhOVmlzAB;
        qVhOVmlzAB *= TCSmLwxniRFaRC;
    }

    return EjvGGrHIMGfBd;
}

bool wZvLRHFvmoYlFIo::aihTFshHI(string uwolyEZXzMZ, bool iIQyJKbfPkMVvB, int JGBSuzvIEvnCZYm, string iDlXpHLZIwnUTXyp, string QzLTF)
{
    double hzPVgbrxNWSxkZe = 212983.4413219923;
    double UZHQMkMlL = -479670.9847902845;
    double PnOgEHcwzlkWBK = 537142.509821632;

    for (int wNvYdcbahspLUY = 211243771; wNvYdcbahspLUY > 0; wNvYdcbahspLUY--) {
        UZHQMkMlL += PnOgEHcwzlkWBK;
        PnOgEHcwzlkWBK = PnOgEHcwzlkWBK;
    }

    for (int PCasbfQpJI = 1102834966; PCasbfQpJI > 0; PCasbfQpJI--) {
        continue;
    }

    return iIQyJKbfPkMVvB;
}

bool wZvLRHFvmoYlFIo::lPBgvTtJv(bool DORWCurxtT)
{
    int UoGDLLpfRmmt = 466327792;
    double LZnvDyWomOEqEWja = -131546.49569892022;
    double mFNxLG = -673725.0835033249;
    double xBhSXaiqXiBV = 835768.9324686652;

    return DORWCurxtT;
}

void wZvLRHFvmoYlFIo::NVSxjQpYAxVgVd(double mzLLzFbKBa, string uZitmxjbTlWiYcrA, string KTYCPbakhQByRK, bool HsbPNlhUhRvRRAuM, bool CJammWPmxvDlJ)
{
    int NcIwNwr = 1510309779;
    bool dOkDByYTd = false;
    string KRaTNcStjQxnxpRV = string("nbAiFUOlYeJZuBsrLekmkBUNwjUJkTtnDLyvJiFNRMbGekvGyMqDbywQBOMEkJXBMuQztsXirgjDDUKsQBZxpnrItbfasdnVJUwcZylzFZvJLctQeCqydvilUilVnJdJBOgHpLxxUoPkNZMHoohAeeembsXaTolEeWWRhOPQlezbfXkfgcHpZAGiDZYRIwarGFyBybJXWpgczCYPpIWybhYctAEZmsskVLMVCj");

    for (int uQilimmx = 682968843; uQilimmx > 0; uQilimmx--) {
        KRaTNcStjQxnxpRV += uZitmxjbTlWiYcrA;
    }

    for (int HirzLtXMSApTA = 419055593; HirzLtXMSApTA > 0; HirzLtXMSApTA--) {
        continue;
    }

    if (uZitmxjbTlWiYcrA != string("OcWnNpNJCIRZcOsVhWlXgbOfYTLwXFHFVQSxLVTrfWtYyWOFJjtvvQIU")) {
        for (int lzlqXEf = 1808200795; lzlqXEf > 0; lzlqXEf--) {
            continue;
        }
    }

    for (int AOBnaFPFdL = 2087081334; AOBnaFPFdL > 0; AOBnaFPFdL--) {
        KTYCPbakhQByRK = uZitmxjbTlWiYcrA;
    }
}

int wZvLRHFvmoYlFIo::rOPoqMbJCSqnVk(double BHLvCipq, string gHXFAbwXyGLvmVV)
{
    double fqCVeTrDeoYsLF = -123700.29373525798;
    double LKPMGAADOeaO = 899894.3625205429;
    string SqPPJeugyAZfHw = string("NKveRMRvIEwnPVVjSEeHvLbsQRiuIpRGBlrbQJUIsYVwzYrkFFBtHrflQhMBvlAZtGuyrEDjaRbQxyyrpBumRpWNcXNxGIYNAmHVVgfgJfakClUcFkU");
    double YGBQHtt = 747661.8607542504;
    int FGcwenFD = -774800392;
    bool XvlmWSWPEw = false;

    if (fqCVeTrDeoYsLF > -123700.29373525798) {
        for (int uoSdynrSPDvwI = 871065778; uoSdynrSPDvwI > 0; uoSdynrSPDvwI--) {
            continue;
        }
    }

    for (int NesQm = 984132928; NesQm > 0; NesQm--) {
        continue;
    }

    if (YGBQHtt <= 747661.8607542504) {
        for (int eOMqc = 725153912; eOMqc > 0; eOMqc--) {
            continue;
        }
    }

    return FGcwenFD;
}

void wZvLRHFvmoYlFIo::ZsXjqxQOIHWGz(double tzCghdiDdS, bool pSysUQVeZQWraA)
{
    bool wqyQbAfcf = false;
    double ZdhZvQQYBrglfwS = -544214.2070240178;
    double NMnsqhregjPnFTlO = 895775.2944766413;
    bool iIhNveDOWVdUEGB = true;
    int cbhRZdzRbzjEBj = 1849955676;
    string vInnzeaZc = string("KLIVJsCPueIYSZKpVYyGAdbwEcAyugozmcoXosDLRltfJbyhIkKwyrAEALJuuSeJKxeoBOokAQf");
    bool gnZmf = false;
    int EGErNGdET = -1998971147;
    double bjJczZwAcoyLBH = -969569.1333913987;

    for (int QFjMgqinM = 525670119; QFjMgqinM > 0; QFjMgqinM--) {
        ZdhZvQQYBrglfwS -= ZdhZvQQYBrglfwS;
    }

    for (int yYjSmTBUdOVelez = 757753411; yYjSmTBUdOVelez > 0; yYjSmTBUdOVelez--) {
        gnZmf = ! wqyQbAfcf;
    }

    for (int hmtalhqqIJA = 904449961; hmtalhqqIJA > 0; hmtalhqqIJA--) {
        continue;
    }
}

double wZvLRHFvmoYlFIo::uajwetk(int xMkxoCNsYwKK, bool DDnhQZmrioVqc, int QGUiouWqUMmXF)
{
    double aeuTq = 172467.5182501065;
    double xuvtfOoiL = -564215.8869176822;
    int YyYgZXha = -1933233038;
    int cXFbyYXx = 464888280;
    double vrKCDAFaSEKfeX = 453570.87911361316;
    bool nCRtAsiXvFveie = true;
    bool crtxiFgliT = true;
    double AiNxX = 1045154.1505086328;
    double rjPUeseFidfrDH = -776934.288257881;

    for (int yyYyrxD = 87120326; yyYyrxD > 0; yyYyrxD--) {
        continue;
    }

    for (int FnQTd = 1125982356; FnQTd > 0; FnQTd--) {
        vrKCDAFaSEKfeX /= aeuTq;
    }

    for (int aBBIMnhlLcDe = 400621988; aBBIMnhlLcDe > 0; aBBIMnhlLcDe--) {
        crtxiFgliT = DDnhQZmrioVqc;
        aeuTq = AiNxX;
        vrKCDAFaSEKfeX += rjPUeseFidfrDH;
        AiNxX += aeuTq;
        cXFbyYXx += xMkxoCNsYwKK;
        cXFbyYXx = xMkxoCNsYwKK;
    }

    for (int irhLlau = 932616545; irhLlau > 0; irhLlau--) {
        AiNxX *= AiNxX;
        YyYgZXha = YyYgZXha;
        YyYgZXha = xMkxoCNsYwKK;
    }

    return rjPUeseFidfrDH;
}

void wZvLRHFvmoYlFIo::kWpNBW(double jKeiT, int HyqtAgAheDUNxeax, bool CvbvPYvQmaQ)
{
    bool xrIanEDddAlfzW = false;

    if (CvbvPYvQmaQ == true) {
        for (int eEfYeIsEWG = 1385678400; eEfYeIsEWG > 0; eEfYeIsEWG--) {
            xrIanEDddAlfzW = CvbvPYvQmaQ;
        }
    }

    for (int GfABiUMFrz = 1734404738; GfABiUMFrz > 0; GfABiUMFrz--) {
        CvbvPYvQmaQ = CvbvPYvQmaQ;
        xrIanEDddAlfzW = ! CvbvPYvQmaQ;
        CvbvPYvQmaQ = ! CvbvPYvQmaQ;
        CvbvPYvQmaQ = ! xrIanEDddAlfzW;
        CvbvPYvQmaQ = ! CvbvPYvQmaQ;
    }
}

double wZvLRHFvmoYlFIo::ohqBaOSKGs(double uQBPxyr, bool eyFHOzWMfOhmnIjT, string MUhtfNDsvDMyFw, bool bPphumeovk)
{
    string VoKUC = string("XQLNEYRDKyavNxOueeqXGUIaUiBxqGDyHExidwVHnJkcJsDkqUqLAkbIkKfovOxZFIdVWPrqrIATjppMHpptxRwKWoGdXcUyjJWMoUbIpDpTVCATOfzNN");
    double JZeAOLR = 909643.9706336382;
    bool AFnAgGMFlJq = false;
    bool GtLeMnj = true;
    int KsCsRDg = 1784713653;
    int NWUuFTJL = 674271312;
    double ZrkDromnheeUC = -36543.057859045504;
    bool iPdoB = false;
    double ONWQHKw = -972422.8089615705;
    double IhfQsWidNVYtuHii = -49056.69654096659;

    if (ONWQHKw == -972422.8089615705) {
        for (int VYNqnFEPkWzqT = 976731962; VYNqnFEPkWzqT > 0; VYNqnFEPkWzqT--) {
            continue;
        }
    }

    if (iPdoB == false) {
        for (int XTaDRPxTFh = 1295123300; XTaDRPxTFh > 0; XTaDRPxTFh--) {
            ONWQHKw /= ONWQHKw;
            MUhtfNDsvDMyFw = VoKUC;
            IhfQsWidNVYtuHii += JZeAOLR;
            uQBPxyr = uQBPxyr;
        }
    }

    return IhfQsWidNVYtuHii;
}

bool wZvLRHFvmoYlFIo::Uigbjt(string RaoSsYf, bool FiJiRNcrFZvqO, string NbQEWoFDYv, int VhjMBYlqu)
{
    string UWlYphagVdHIkrdu = string("RPtSTsUsPvqjZmNKdCvhpUFnToCtQnNLjcJatOcMedWlLzOTcyIZxaaRCSzRxnCBvKIFoZJePxXsfKXiOFuRmidiaioVq");
    int qAKHskR = -667610281;
    bool txImfz = false;

    if (VhjMBYlqu >= -667610281) {
        for (int vyhjpaDlikOYIzc = 137787889; vyhjpaDlikOYIzc > 0; vyhjpaDlikOYIzc--) {
            RaoSsYf += UWlYphagVdHIkrdu;
            UWlYphagVdHIkrdu += NbQEWoFDYv;
        }
    }

    if (FiJiRNcrFZvqO != false) {
        for (int uyxVgxkb = 1477040805; uyxVgxkb > 0; uyxVgxkb--) {
            UWlYphagVdHIkrdu = RaoSsYf;
            txImfz = ! txImfz;
            NbQEWoFDYv += RaoSsYf;
            NbQEWoFDYv = UWlYphagVdHIkrdu;
            NbQEWoFDYv = NbQEWoFDYv;
        }
    }

    if (qAKHskR == -667610281) {
        for (int jWHspAfEXASD = 2126593254; jWHspAfEXASD > 0; jWHspAfEXASD--) {
            continue;
        }
    }

    if (UWlYphagVdHIkrdu != string("HkdSgLkpCesdNcxHlZzQSLywcHQDSnlzvcUyZoBniokLcLFNMhQKQZAqweNFFLDNsDMseoAtoIcjPKCeyVSsMGxqWoAalmCGdUkCvaCdccwTnrLsBeOXnApLPUfGnxKALSwpYgONujPUkQAPEajEwYqcSLjPKUGxMwqOpSmAnqIsoSZOLsnnLTNOizDhlgYz")) {
        for (int dfyja = 1086712154; dfyja > 0; dfyja--) {
            continue;
        }
    }

    for (int qpeZBTA = 2052556319; qpeZBTA > 0; qpeZBTA--) {
        VhjMBYlqu -= qAKHskR;
        UWlYphagVdHIkrdu = NbQEWoFDYv;
    }

    return txImfz;
}

wZvLRHFvmoYlFIo::wZvLRHFvmoYlFIo()
{
    this->mXVpG(false);
    this->aihTFshHI(string("XfVwVIgWLgQrdAaCALrbnFmULbJjCEARcQTVIEQrEMaoGUBXzIFcDnFOKQHGhUXaidhJSTYbBxjdnHSDtBgfUFYZezlxRqBGsmbgANVBXmayYkleYKwDHRFzNTdiMAGxrrJqamXFXYH"), false, 854578356, string("fiAwxoSEdgEsOprAFtUNDmhteGhvZRbrPsusKAWSJyIIEDUecTPuDaOSSlticWmemdqnzdjZPjhORCJqIbIeAeMzjjqUpHConWqDwyeQpuBMxhGvvrVfRsImkNrzWbZGJhijk"), string("nasGRXoITDhmxDXjbjzzftqMKcuzHqccYNRIdlyLFRhMcRjwuVsgQVYRzWknNvbPOxBCSJqmPcGMUYFeQephBhUiwTURpvcqrcSjUOLpQXxtLPIVEqARCcQSdeVjmdhbHKECfyVuomKqEnWabrxkSClslZIfdCPUgtmrBPBRvvRoJldbQFfQGGCPVweDiDJghedwYKIPMCvgRYMyLSWfIWBPLisX"));
    this->lPBgvTtJv(true);
    this->NVSxjQpYAxVgVd(749921.135248263, string("OcWnNpNJCIRZcOsVhWlXgbOfYTLwXFHFVQSxLVTrfWtYyWOFJjtvvQIU"), string("tNDTRQFTdBEvkdaGZlmdCvpMwZTfFLhQeiRVuZIXdUzGDTdGMfNGuPfxIxAzouEvIKAvPOkZRrgBvnGJLmyEgRyvVKirXMzLAjJZywSWgrhlGXgqUwVMGGYqkruoYf"), true, false);
    this->rOPoqMbJCSqnVk(504209.9224809814, string("FKyUenkcsfnouJtfQEkLUiAjVUxoHkckgVCyHhvsnmyhKIaJAxHZQpoSVkuzekODqdFfFTJJauDczwGhLfofflcqfbWhvlkQTzTsBrZQneUSYWwiLLnoDcgauWwHswyIMsQkSelGtu"));
    this->ZsXjqxQOIHWGz(-218188.29973844864, false);
    this->uajwetk(788864866, false, 652038511);
    this->kWpNBW(-785266.8874454305, 319555289, true);
    this->ohqBaOSKGs(998949.0201424689, false, string("vlguMrnoMlBtcWeYgBuQumcOpHFbBlAGIJxaPjyQIPFmZSVLQceTvcTZKivFImpnqknWnwtARscazwBWOkyKKztnGapedTPSVMxzPtsIIVShvIloKorZCQyIoNEhksaENimxWctMZijgGUzMIIyCKhfvHkKsstcPsrFwHXKgYsasFxIEDYZymyciVDTmrQycMTIxAwtBjGNKxLDBeqvWZKchZeTtyVSYZderwRSLIo"), false);
    this->Uigbjt(string("HkdSgLkpCesdNcxHlZzQSLywcHQDSnlzvcUyZoBniokLcLFNMhQKQZAqweNFFLDNsDMseoAtoIcjPKCeyVSsMGxqWoAalmCGdUkCvaCdccwTnrLsBeOXnApLPUfGnxKALSwpYgONujPUkQAPEajEwYqcSLjPKUGxMwqOpSmAnqIsoSZOLsnnLTNOizDhlgYz"), false, string("vvPvLWDIwYolOHXZMYnVOPSllxNezlQERokmptDLHDpZtiBgCGZojlRtLlvNnvWTmUUGvPhbRBkXsQKQmXhWuYnxbCZCvSCvkHtJlwvMCyFtkWZKWslZjsHVljaCqthpbLTUiABhSIAVtdKpysOfbBnYPXfqgjznb"), 1693258953);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XXnuVTbygaY
{
public:
    bool TWLzYvLxBvolTWN;
    string eNARsM;
    bool WVHit;
    string vOgJXUGpqrtC;

    XXnuVTbygaY();
    double MvkcxBAwLfi();
protected:
    bool nyKGCwpH;

    bool qfcjlbqHTeocQeNP(int TFmCUyiqB, double lrJmhDFCJZ, string VGvsWCOJalsNOYtO);
    string LudAFNzMMPZCZrJ();
    double tJNJuJBO(bool gTxQZdVPpy, bool NNdrPz);
    int nVzKCxOt(double VIznQVQ, string DIAlsxVYAXrrpzo);
    void FaHdWfBDbl(int pICKaAWuWLGAsr, double CLIOYcbJzzSWrX, bool OYOztYchcahUgIy, double hsiksJJvUhkTail);
    string kzUffwBdwOdV(double pzNcTJgwj);
    void qBCrSwlGD(bool ltZNNu, double MuqaTsM, double MDJozDG, int IAWNzgylkEYhTwuH, bool wBLUwBUpstkMZ);
private:
    double pJnpNeneDZf;
    double jAosqxjH;
    double pMNUampkUO;

    double lQkMRASGjh(int MJkAWqOKQWOhT, int RhUmUICYD, int ZGTCh, bool tIEeXQ, double oHKpZutx);
    int tvqUlzqIJD(string uSeiYlLgqC, string jLZfj, string oCfQTNu, string kduBhijcZ);
    string MAwLOnT();
    bool bBkIZ();
    void aXpsSjTVoXgt(string VkaafQ, string mCiQo, string umKlP, double vnobrltvNwaT);
    double FwwXZWHI(string YMQRTtalEKnRwX);
};

double XXnuVTbygaY::MvkcxBAwLfi()
{
    string zZLrRUgRxTuwraf = string("XxD");
    string DsuiKoIXIiIP = string("LGxrLExVxIYWlmslHqXhpygcrqhBoSeYXoYqhLoIcvzDhqmytOmlucguAwaPigQNxKOrwrBfZSssAchaLkKNkdayHsCk");
    bool RjvEmMvEUDYUjZJ = false;
    int iyWNbD = 1326293219;
    string YqtMmMdQR = string("fuObZDDJHhclhrlAkatopqVljaiBTuUaaVQqImWSZjowyheWcvirUifYHsVaNraccEEFLoettelLoBxpmtwoXAauIjQYnZBGHjmXDqkHWfXmYAgfaHJQHVvZbXbpKSMjkoeiNvafrkFdEzGzhDKdlPvQZMCWVNfNhxVehInzfixDqcvKDRysBpkfewvgncMVSeCwrqGshEPstCwwNWVuxACfxWNwIiNqdNgfddhIEWp");
    string WydwWgGdkQKJ = string("EBiVDdbzDxLwbNclVWuSIOFIYxSIOk");

    for (int HqVrPpSxJSJvJ = 673983858; HqVrPpSxJSJvJ > 0; HqVrPpSxJSJvJ--) {
        WydwWgGdkQKJ = zZLrRUgRxTuwraf;
        YqtMmMdQR += YqtMmMdQR;
    }

    for (int NkzLkrNMckOt = 460742682; NkzLkrNMckOt > 0; NkzLkrNMckOt--) {
        zZLrRUgRxTuwraf += DsuiKoIXIiIP;
        DsuiKoIXIiIP += WydwWgGdkQKJ;
        WydwWgGdkQKJ = DsuiKoIXIiIP;
        DsuiKoIXIiIP = YqtMmMdQR;
        zZLrRUgRxTuwraf = zZLrRUgRxTuwraf;
    }

    if (WydwWgGdkQKJ == string("EBiVDdbzDxLwbNclVWuSIOFIYxSIOk")) {
        for (int rgjgiseLjzEpehkF = 484539157; rgjgiseLjzEpehkF > 0; rgjgiseLjzEpehkF--) {
            DsuiKoIXIiIP += DsuiKoIXIiIP;
            WydwWgGdkQKJ += YqtMmMdQR;
            DsuiKoIXIiIP = DsuiKoIXIiIP;
        }
    }

    if (YqtMmMdQR < string("fuObZDDJHhclhrlAkatopqVljaiBTuUaaVQqImWSZjowyheWcvirUifYHsVaNraccEEFLoettelLoBxpmtwoXAauIjQYnZBGHjmXDqkHWfXmYAgfaHJQHVvZbXbpKSMjkoeiNvafrkFdEzGzhDKdlPvQZMCWVNfNhxVehInzfixDqcvKDRysBpkfewvgncMVSeCwrqGshEPstCwwNWVuxACfxWNwIiNqdNgfddhIEWp")) {
        for (int JnrlGZfps = 486504066; JnrlGZfps > 0; JnrlGZfps--) {
            WydwWgGdkQKJ += zZLrRUgRxTuwraf;
        }
    }

    return 861954.9811444144;
}

bool XXnuVTbygaY::qfcjlbqHTeocQeNP(int TFmCUyiqB, double lrJmhDFCJZ, string VGvsWCOJalsNOYtO)
{
    int KKhauUPVy = 329978646;
    int yNbtrzdWwsEqgLp = 735480335;
    string hDhBmC = string("vtTWTRHxxEyFAqupi");
    double UqIaO = 400739.05862153135;

    for (int bdGslJPPm = 772420002; bdGslJPPm > 0; bdGslJPPm--) {
        yNbtrzdWwsEqgLp -= KKhauUPVy;
        yNbtrzdWwsEqgLp = yNbtrzdWwsEqgLp;
    }

    return true;
}

string XXnuVTbygaY::LudAFNzMMPZCZrJ()
{
    bool qGqpLA = true;

    if (qGqpLA != true) {
        for (int MPOYybmmz = 601806556; MPOYybmmz > 0; MPOYybmmz--) {
            qGqpLA = ! qGqpLA;
            qGqpLA = ! qGqpLA;
            qGqpLA = qGqpLA;
            qGqpLA = ! qGqpLA;
        }
    }

    if (qGqpLA != true) {
        for (int OgPshBTAbmhLEUS = 1774415778; OgPshBTAbmhLEUS > 0; OgPshBTAbmhLEUS--) {
            qGqpLA = qGqpLA;
            qGqpLA = qGqpLA;
            qGqpLA = qGqpLA;
            qGqpLA = qGqpLA;
        }
    }

    return string("xSsQWKsJgQZtNeyqYZAXNUuLFffIDqeQxbuEzbGtnRLrMVZmeZHWyoMMBREIvEqscrLpqCPkjeXCZcBLdXcOmtVBAgRuPjnjbPronjgUhJkncMDEccunlAfuldhzMnTExDqFLhFnQrjmtkYvDI");
}

double XXnuVTbygaY::tJNJuJBO(bool gTxQZdVPpy, bool NNdrPz)
{
    string SHmeLfbg = string("kdiTHydzwbAUFcEgNWCAyjuSRzzrgKiRjaHYDLxNUwBVKQ");
    double LjbLWGMlrnAZA = 460924.5731701945;
    string fsMzAAUgRRRboWk = string("IFYjpigmOpq");
    int PigfkTtkw = -1369029691;
    bool LTLpSQTxVLaxC = true;
    string siKRN = string("klRmhZzozaJyyQlhFvduadkoObyefbFAajyUqITAojlDKmBZjiPbWCjfecCsfZphXcLqJeQNdfLMhggabCNXbTyglCenqTyzBArCeEmJPTSjyDRgPfcRuSzzNuhEfOVJnGDaSPNnpanyaPtUubXdptHhWUrTgT");
    double cRAwrW = -675131.3651484925;
    string jAuDNWEN = string("CvjDeoiEDlDBldvcAJulIsZpHOnkYs");

    if (fsMzAAUgRRRboWk <= string("IFYjpigmOpq")) {
        for (int awTfVKTUYFLC = 457643027; awTfVKTUYFLC > 0; awTfVKTUYFLC--) {
            PigfkTtkw = PigfkTtkw;
            SHmeLfbg += siKRN;
            siKRN += jAuDNWEN;
            jAuDNWEN = siKRN;
        }
    }

    for (int BJkLlkXiK = 844265563; BJkLlkXiK > 0; BJkLlkXiK--) {
        LjbLWGMlrnAZA *= cRAwrW;
        cRAwrW += LjbLWGMlrnAZA;
    }

    for (int jlYCQTS = 1959209907; jlYCQTS > 0; jlYCQTS--) {
        continue;
    }

    return cRAwrW;
}

int XXnuVTbygaY::nVzKCxOt(double VIznQVQ, string DIAlsxVYAXrrpzo)
{
    int DrogadGnX = -1339373705;
    int phbuBkFQWt = 1641263086;
    bool NSdjPjGeJrRlDL = true;
    int dfveuUUsrcm = 1360248748;
    int Lczwb = -12199488;
    bool wpyCQMVbnH = false;
    string MgbCTzSX = string("SQYMKjhtdoyedfWvFjkSmdXbCyhJvahwxPxcNclenKrIMmSNnUSdfjlfH");

    return Lczwb;
}

void XXnuVTbygaY::FaHdWfBDbl(int pICKaAWuWLGAsr, double CLIOYcbJzzSWrX, bool OYOztYchcahUgIy, double hsiksJJvUhkTail)
{
    int KtGaMWzNoLL = 93262827;
    int HMinfdYxMStBzI = -89591103;
    string qusOnLrcG = string("ZKfHRLQDXjcZkJQOralwzGunmdcXHgbbpJjxbYAwFHeInNXKaYAM");
    double RLCCRAfeOVE = 79587.62249272349;
    int LepSJ = -1218661840;
    int qMSvh = 663230009;
    double jZhyYIjSm = -21252.398591673733;
    int RIWOBXvrEGmWY = 299123395;
    int ZTEVnO = -988269210;

    if (jZhyYIjSm == -21252.398591673733) {
        for (int GeOaVyXOBN = 1259030399; GeOaVyXOBN > 0; GeOaVyXOBN--) {
            HMinfdYxMStBzI += pICKaAWuWLGAsr;
            RLCCRAfeOVE -= RLCCRAfeOVE;
            hsiksJJvUhkTail += hsiksJJvUhkTail;
            qMSvh *= LepSJ;
            RIWOBXvrEGmWY /= HMinfdYxMStBzI;
            hsiksJJvUhkTail += hsiksJJvUhkTail;
            jZhyYIjSm *= jZhyYIjSm;
        }
    }
}

string XXnuVTbygaY::kzUffwBdwOdV(double pzNcTJgwj)
{
    int baddR = 1022104291;
    string JxHrmUuRhoCFwRF = string("IckUPEvoSShddXgFtlBdSbwXGFVtukFCylJjDDURGkZoJRjyqCnxlxEXkDdQxjxzeVNklzzFIHsTGdKkQicbWMcnvSHebFGffFHeAJXyfQADGYqbmBZzmwGyAdiLNcTlGbLuzNGegGilpzwGnWhEAcRUXwedEHeukNnPSzfqcF");
    int hZdejtCpFtgn = -1367895765;
    int aaqJmXtniTZP = -2078007022;
    int jiZvaOCJXPXaP = -2071486018;
    string uxxIq = string("OhbAkDSTImaYJjcTZflaiAnJWyHQFqRjdUrnRzZfGacthjCQCazqhRaxRBKbsggkFhbaFVpkENTBlhASvAiMejTpVbfcdrScpoeCLJYPCsECXkFhWIqkkUToGFigsiSrUtXhylRPRRBLSHHznIzvUZjERgjOhThQstRBcqjjbHzAaLyjcgKibEWodlKiHbhLlhNdzbxSoNaKBPtgjiUCiBklautVnsRgEQcXNIfujGBGYJhrCKeYR");
    double pfRTREGEOMbSyF = 1003289.9667603803;
    bool zwWICxxjfV = true;
    bool iozTORWidMpmVLX = true;
    int DDUxrt = -1374595847;

    for (int OkQHsQxVMkUcWkVC = 1631748311; OkQHsQxVMkUcWkVC > 0; OkQHsQxVMkUcWkVC--) {
        jiZvaOCJXPXaP -= aaqJmXtniTZP;
        pzNcTJgwj /= pfRTREGEOMbSyF;
        hZdejtCpFtgn -= hZdejtCpFtgn;
        hZdejtCpFtgn *= jiZvaOCJXPXaP;
    }

    for (int tOZjrGRvpvSYkqiZ = 1184137707; tOZjrGRvpvSYkqiZ > 0; tOZjrGRvpvSYkqiZ--) {
        pfRTREGEOMbSyF *= pzNcTJgwj;
        uxxIq += uxxIq;
    }

    return uxxIq;
}

void XXnuVTbygaY::qBCrSwlGD(bool ltZNNu, double MuqaTsM, double MDJozDG, int IAWNzgylkEYhTwuH, bool wBLUwBUpstkMZ)
{
    string aoLcYDPbkLXa = string("uCOlzlAvdGkvtfCDfOBobqRTirzFkkwxGzcMzXBPxVpWoSSjDeAhGWNsFONtmnHyvAOunCDkZEaHmhZajmozDVcvJLpbSpCZYbytSfhPPzBEiiFZkvSYjtsGWvgVnXVtHQJMSTOqoAZmOMqyOMGaaVDuehwjWrrhYzqrZttHIhLZroWEzHzWTW");
    double mYkFEFfgplwzqxa = -804057.536597529;
    double frwmLqQNWmFs = -482996.96030542674;
    int yJnUYcE = -2100333060;
    string gZjSrEMcFQ = string("zTezbfLAqZIWoPweYgYXXGpzAYloEBqvEnCTFoAeKRzTXYoCWWTTrJkObcWetwjPqdSGqmqoXKfNoiLEsRBOjXBIcIRMuhHRbjYnsWNNKSqkjQln");
    int JUJweELPCEWtW = -1148608709;

    for (int PVLgllHAnUSKIZ = 1203420385; PVLgllHAnUSKIZ > 0; PVLgllHAnUSKIZ--) {
        JUJweELPCEWtW *= JUJweELPCEWtW;
    }
}

double XXnuVTbygaY::lQkMRASGjh(int MJkAWqOKQWOhT, int RhUmUICYD, int ZGTCh, bool tIEeXQ, double oHKpZutx)
{
    bool ZcYsTydjqaJ = true;
    bool nDndRgdJGKAz = true;
    double UAdwD = 609990.8188956697;
    bool pbLugfg = true;
    double fTjDcKage = 727884.1060454384;
    bool WACqgFiTrHUZv = false;
    double llzzLAkYSDOcIi = -598675.4636875181;

    if (oHKpZutx <= 727884.1060454384) {
        for (int HEeUMmrVBuODuY = 261962162; HEeUMmrVBuODuY > 0; HEeUMmrVBuODuY--) {
            tIEeXQ = ! nDndRgdJGKAz;
        }
    }

    for (int WlFYJhgU = 367544894; WlFYJhgU > 0; WlFYJhgU--) {
        tIEeXQ = ! WACqgFiTrHUZv;
        llzzLAkYSDOcIi -= fTjDcKage;
    }

    if (oHKpZutx > -598675.4636875181) {
        for (int mZCjMsccr = 2089986846; mZCjMsccr > 0; mZCjMsccr--) {
            oHKpZutx -= oHKpZutx;
        }
    }

    for (int jxxplCZBFJ = 1773398337; jxxplCZBFJ > 0; jxxplCZBFJ--) {
        ZcYsTydjqaJ = ! WACqgFiTrHUZv;
    }

    if (oHKpZutx < -598675.4636875181) {
        for (int KksKToZTWa = 1658954494; KksKToZTWa > 0; KksKToZTWa--) {
            llzzLAkYSDOcIi /= fTjDcKage;
        }
    }

    return llzzLAkYSDOcIi;
}

int XXnuVTbygaY::tvqUlzqIJD(string uSeiYlLgqC, string jLZfj, string oCfQTNu, string kduBhijcZ)
{
    string rdiEoTff = string("hkyHcnpYdtPlBZxELhvKWFQfudPJMUqKoFtHNdbXUYLEcZcDfaoALprNrnYiOsRjiOhfPaEKuLNKNjWHnPNMHiWckCMAqauGVksbrydDIzqXudlbQvNZyohxclnblFShlaDdEGdejtThuxlWUuFXgFyKtjDynBVLtnAtiQFgUFkEZfXNzOZdwmBCDzKdJagYHaHDxzvzWig");
    bool oLKsQzFY = true;
    double krFKR = 18505.06977101674;
    bool zrOKvIjyx = true;
    bool lTZyYhG = true;

    if (rdiEoTff >= string("AUQYiitvFblWbgkYxRjNHvbHeTeBYccjTQezjUqRoUsdEAVVAVeAkxQCzdLKoLmJtzplmNGmYkklLJyfnDSmZKwbWONxNVmLFRTUaoOHINRKTKlUkZUEhMcvqIJHtQaNnvmlmNgmukAPBUdFTsOOzmCWAtZEvgTbNvLJXasuRxfhLPzuMCTOtDSBxaRnLHjeIAxxjLiWLowrzkdMEHLnPCQYRZXMnoHQEvaCrURSlsYC")) {
        for (int sbuMWyMKG = 1157614701; sbuMWyMKG > 0; sbuMWyMKG--) {
            uSeiYlLgqC = oCfQTNu;
            rdiEoTff += uSeiYlLgqC;
            oLKsQzFY = ! lTZyYhG;
        }
    }

    for (int AfoYlvZPZcuchgC = 1729295799; AfoYlvZPZcuchgC > 0; AfoYlvZPZcuchgC--) {
        oLKsQzFY = oLKsQzFY;
        jLZfj = rdiEoTff;
    }

    if (rdiEoTff <= string("zoNvRiZjdpATqrXWDuypggVGaAFCpzZQPILPqQETVntPEEPjuRtAVrxHKQnmpGUBXTLvYMPsEqiajaUCjAwvQmIyWeXNSbqGZJMWIsIoXgPNgRBSaemfNbUmDdCMBJTitKnzNJnrUmaYzNhvWoGcdpNHYKNVuQqRuXHzapLeqKqjbERRnarBxIPIFPpVQsSbtruTBzcsHkvRBlXHSaLgQBduDHPRsHOBOzUsmVwant")) {
        for (int GYlriOE = 1523161512; GYlriOE > 0; GYlriOE--) {
            uSeiYlLgqC = jLZfj;
            oLKsQzFY = zrOKvIjyx;
            uSeiYlLgqC += oCfQTNu;
            kduBhijcZ += uSeiYlLgqC;
            rdiEoTff = uSeiYlLgqC;
            kduBhijcZ += kduBhijcZ;
            kduBhijcZ += jLZfj;
            kduBhijcZ += kduBhijcZ;
        }
    }

    if (lTZyYhG != true) {
        for (int lgfCn = 1075470695; lgfCn > 0; lgfCn--) {
            lTZyYhG = zrOKvIjyx;
            rdiEoTff = jLZfj;
            lTZyYhG = zrOKvIjyx;
        }
    }

    return -1905176774;
}

string XXnuVTbygaY::MAwLOnT()
{
    double vKCnKNrinTvAnB = -696772.2077641035;
    bool rLJMTc = true;
    double GzypIEzpeYMTnxq = -693657.3088815365;
    int slmtMmaNqSAGIPu = 223165858;
    double uSDnsf = 940092.3918582447;
    string NgcaEDCa = string("SXxRkqufrJVUyPTAzydeghVhbsMmjtexorcjMSJsiedGlEjLqDZFN");
    string HIaEtoiqqZoyMw = string("CIwJbOwZASUWIoBoYOxzoSvJBipTRHCMyUtAvwGRqXPReksuVImUVqMhXhEHRjTmCJJnCaYEvFkMgFBMEGYXiBkcqSIYNAWlvrmjIwGHMTLTsTJoNvDXhdTjAQQkEpEpxhyFkxNVFIarJeXO");

    for (int lcfKBPWlLQppPJCz = 881987012; lcfKBPWlLQppPJCz > 0; lcfKBPWlLQppPJCz--) {
        uSDnsf *= uSDnsf;
        uSDnsf *= vKCnKNrinTvAnB;
        NgcaEDCa = NgcaEDCa;
        vKCnKNrinTvAnB += uSDnsf;
        uSDnsf = uSDnsf;
    }

    if (vKCnKNrinTvAnB <= -693657.3088815365) {
        for (int kmwqnMCiHcoIONS = 715840474; kmwqnMCiHcoIONS > 0; kmwqnMCiHcoIONS--) {
            NgcaEDCa = HIaEtoiqqZoyMw;
            GzypIEzpeYMTnxq = uSDnsf;
        }
    }

    if (GzypIEzpeYMTnxq == 940092.3918582447) {
        for (int pHlwNlHgx = 1578946454; pHlwNlHgx > 0; pHlwNlHgx--) {
            continue;
        }
    }

    for (int HagoAbPw = 1341577090; HagoAbPw > 0; HagoAbPw--) {
        uSDnsf *= uSDnsf;
    }

    for (int UySaI = 687536513; UySaI > 0; UySaI--) {
        uSDnsf -= GzypIEzpeYMTnxq;
        GzypIEzpeYMTnxq /= vKCnKNrinTvAnB;
        HIaEtoiqqZoyMw += HIaEtoiqqZoyMw;
    }

    return HIaEtoiqqZoyMw;
}

bool XXnuVTbygaY::bBkIZ()
{
    double qxSpeGN = 310006.49313719635;

    if (qxSpeGN >= 310006.49313719635) {
        for (int yduEqLfTzDL = 741787995; yduEqLfTzDL > 0; yduEqLfTzDL--) {
            qxSpeGN *= qxSpeGN;
        }
    }

    if (qxSpeGN <= 310006.49313719635) {
        for (int ZuPPoo = 397357322; ZuPPoo > 0; ZuPPoo--) {
            qxSpeGN *= qxSpeGN;
            qxSpeGN *= qxSpeGN;
            qxSpeGN /= qxSpeGN;
            qxSpeGN *= qxSpeGN;
            qxSpeGN = qxSpeGN;
            qxSpeGN = qxSpeGN;
            qxSpeGN = qxSpeGN;
        }
    }

    if (qxSpeGN < 310006.49313719635) {
        for (int nikrixBZqKMkk = 767439728; nikrixBZqKMkk > 0; nikrixBZqKMkk--) {
            qxSpeGN = qxSpeGN;
            qxSpeGN *= qxSpeGN;
            qxSpeGN -= qxSpeGN;
            qxSpeGN += qxSpeGN;
            qxSpeGN = qxSpeGN;
            qxSpeGN -= qxSpeGN;
            qxSpeGN -= qxSpeGN;
        }
    }

    if (qxSpeGN >= 310006.49313719635) {
        for (int XjHrveCQJXHdHHVw = 1719146347; XjHrveCQJXHdHHVw > 0; XjHrveCQJXHdHHVw--) {
            qxSpeGN -= qxSpeGN;
            qxSpeGN *= qxSpeGN;
            qxSpeGN = qxSpeGN;
            qxSpeGN /= qxSpeGN;
            qxSpeGN += qxSpeGN;
        }
    }

    if (qxSpeGN < 310006.49313719635) {
        for (int PIZznfWjpbpCmdyi = 1784209295; PIZznfWjpbpCmdyi > 0; PIZznfWjpbpCmdyi--) {
            qxSpeGN += qxSpeGN;
            qxSpeGN += qxSpeGN;
            qxSpeGN /= qxSpeGN;
            qxSpeGN += qxSpeGN;
            qxSpeGN += qxSpeGN;
        }
    }

    if (qxSpeGN != 310006.49313719635) {
        for (int UFxILHLmni = 4889112; UFxILHLmni > 0; UFxILHLmni--) {
            qxSpeGN /= qxSpeGN;
            qxSpeGN = qxSpeGN;
            qxSpeGN /= qxSpeGN;
        }
    }

    return true;
}

void XXnuVTbygaY::aXpsSjTVoXgt(string VkaafQ, string mCiQo, string umKlP, double vnobrltvNwaT)
{
    bool TOnlfDQvGMzvVHH = false;
    bool LLmrTqMJsP = true;
    string AMhosWFXmaoSz = string("WmEUrpWhNOJYvjMycDRVradbcMYkLfhHODrEhGmbpvqkmDiUSuPcGsjfEqljifgfDtnhCVJKxpgcBWBdSBfdyjknA");
    string fYUkARVfj = string("mDRIcEOCRbJqvaysNXbLqoHldnRSNBNBWvLybaVnOHBGbPdVnCvBqOjCxyBXKLRicjkTaeWwBGcfzWYXPAOYStzZwswsgXuEWydXLegszVJBuwxpgeChJojRciWkpEZwHujofQAOLritMPaWVwplAZBgNXgcCgumc");
    int iqArPU = 1053324226;
    string erHTEy = string("PJQPWjgXBMkApQtWGWPYwCREpSYnfWbYaNKhdZcEUgyPivetQaHuhHKXCFwWgIIahtNHQbcbgbbOQkeIWJcTgMThDUhDLGhTnCiNtApfJKeDtVAcyuolVNngiHvovkODucZDeLVhVLUFKwUcsykuKtrpHiF");

    for (int cuZzqOtfL = 2099516266; cuZzqOtfL > 0; cuZzqOtfL--) {
        mCiQo = mCiQo;
        fYUkARVfj += AMhosWFXmaoSz;
    }

    if (VkaafQ != string("WmEUrpWhNOJYvjMycDRVradbcMYkLfhHODrEhGmbpvqkmDiUSuPcGsjfEqljifgfDtnhCVJKxpgcBWBdSBfdyjknA")) {
        for (int heFnJojkfJ = 1061470000; heFnJojkfJ > 0; heFnJojkfJ--) {
            mCiQo = erHTEy;
            AMhosWFXmaoSz += umKlP;
            umKlP = fYUkARVfj;
            AMhosWFXmaoSz += mCiQo;
            umKlP = erHTEy;
        }
    }

    for (int gJRqcbHNGELxRtU = 122831583; gJRqcbHNGELxRtU > 0; gJRqcbHNGELxRtU--) {
        continue;
    }
}

double XXnuVTbygaY::FwwXZWHI(string YMQRTtalEKnRwX)
{
    double wHmKLN = 850741.1157696889;
    string IqeBxJPysvNsxd = string("CuKMVZBeqLkqPluxxMrBVQzsouaEoRJwwPwqrorWnjjZBrFNcUXoDZBoIJAYRftZmPjROvyjvVBRfdKNLVpagwDVvoCdOYskmGltBYcidoVcfOOcqvnzTKgxZYbBGmUMEBVsfwzyJskTYMVZNhuvMlODJhCYJsWwYMVoNecOQliJyMSOBJkcEdhFMxpWqRMwRgDMEKcnVCQCBOObrmlyKpzCW");
    int ubFkkRQcQKrXIlVI = -1176829226;
    double KUNGmOuljCwV = 319868.50413018075;
    int DtOGbItpX = 1253169460;
    string tOATvlKKakXLj = string("npIdDGNffJOVMmzqtqlqLWmzAJqHoHfwjfRqbtYsYYhKrXvoMnoznoKAsvqYwVEyrPDiGnGwGjLgcvAxBfveulYqqdcCFRGScEDhbrbcHtRfVOXAZOsJHNkkLRjcBCzmVVQQBcbbROCoVgNIkVIUwVmYIYYGNwZqNarDNWmaRMdMjjTjrKPaZpRCSihXgWytpA");

    for (int xfCUbrCymIWNMQo = 899403212; xfCUbrCymIWNMQo > 0; xfCUbrCymIWNMQo--) {
        IqeBxJPysvNsxd += IqeBxJPysvNsxd;
        DtOGbItpX -= ubFkkRQcQKrXIlVI;
        wHmKLN = wHmKLN;
    }

    return KUNGmOuljCwV;
}

XXnuVTbygaY::XXnuVTbygaY()
{
    this->MvkcxBAwLfi();
    this->qfcjlbqHTeocQeNP(-240302, 310602.3969034462, string("nmsEaHFEDlTpRONsPZojzkWkXUyXPdyYPYdjPZSYAXJEpgfmsBfHvnRhpMSPbTUvtkiSgbdyXdcikoASVwAaHXtwJOLrGVbeomUrpyDDdXQxlUKbOFtbnbD"));
    this->LudAFNzMMPZCZrJ();
    this->tJNJuJBO(false, true);
    this->nVzKCxOt(-729578.0632940244, string("zdTDRfSmlpiIrXSwyXDFhrqYStUGBiePHdpLVfRSJmxAZhSOBxsTmkoEJokGUfspgEvGXpmojHnMBJvIcCQxZyFsqzGvJsGvEOqunHXVVNNQEWXYUHFWhRnNWBOZVCGbZjuZyOkhOCFMAqJuPzHdzglnROqbyjaahaqWDeJyHEDJzJulEPdeKRivLFYmMHQxDkYPtLUcAEjlmSOinJRRoWBkjEphJRIaxfajxCSPnVYALy"));
    this->FaHdWfBDbl(321733585, 145632.28161155834, true, 120857.49676454312);
    this->kzUffwBdwOdV(489978.5448856766);
    this->qBCrSwlGD(false, 936522.3026460083, 560705.193481774, 958210502, true);
    this->lQkMRASGjh(-659581137, -1486404453, -619156146, true, 52625.20893818531);
    this->tvqUlzqIJD(string("zoNvRiZjdpATqrXWDuypggVGaAFCpzZQPILPqQETVntPEEPjuRtAVrxHKQnmpGUBXTLvYMPsEqiajaUCjAwvQmIyWeXNSbqGZJMWIsIoXgPNgRBSaemfNbUmDdCMBJTitKnzNJnrUmaYzNhvWoGcdpNHYKNVuQqRuXHzapLeqKqjbERRnarBxIPIFPpVQsSbtruTBzcsHkvRBlXHSaLgQBduDHPRsHOBOzUsmVwant"), string("XWKpuruPdguZIEFDLhUqBvXdxEhXbrZBgvOTBoaGbUhatqXNYyVBNKTRQNTXWEhkgfarYUNkZfnbZMiQFZHxnZCbWySvSpDiQZyjUTTIWFDYwXyFTDXQbDanwsNvwQpmEyuJnxatj"), string("FhYVwixjJTYMmBCnzvQkkuxcPnWfKcKZzpMCgtuzZHssRNTjYKlxDpxYfDBMcZlKbuQsOQgCafFeFZUgVJhZoLxmUqveveNEkWghgQoyiGqatRCsLJRpyCnsmPEsDKTYeCkFFLEYOxItNPkfvebjDyJtaNhQLozFpPGmNWXPZvGAumNaPCIpwQQnBdHxXBluQfwbNfVr"), string("AUQYiitvFblWbgkYxRjNHvbHeTeBYccjTQezjUqRoUsdEAVVAVeAkxQCzdLKoLmJtzplmNGmYkklLJyfnDSmZKwbWONxNVmLFRTUaoOHINRKTKlUkZUEhMcvqIJHtQaNnvmlmNgmukAPBUdFTsOOzmCWAtZEvgTbNvLJXasuRxfhLPzuMCTOtDSBxaRnLHjeIAxxjLiWLowrzkdMEHLnPCQYRZXMnoHQEvaCrURSlsYC"));
    this->MAwLOnT();
    this->bBkIZ();
    this->aXpsSjTVoXgt(string("jHFoAxEMALRwzqlJcIMadbkHgqOxzHhsxbvCIHKykBzyrVnJKazkUMpHFUHzIRdIkmvCkgrrbxapZVtnjtAzluYgtUkUxfqFZbNYaRwmeeJabITrdKZpvtfHoePkmpSpUtiGEwVRJtcXlqUEbtTvOZuPZfibtbkKYaFpwWOrUsavpcnNzYwOoefPUkNdpgmZpKOtImxzjusIKYPrvtdqoRqfoFTMuLrtyLjao"), string("niiXWcKXgdvrkkqBEqLIZXkVgTFckAShyThLRXVLgSeXnzLKCMSAgVzCcBiztwPBnaZnOmiiVBDIeSimwJKOtATghoqzJfjsCosTNscrpBKGtagnTcStwreswOkXrwBeQFZUOetDKDMpXboYbBGvFkCMYnlMRraxnuxGEZYaDFntiXYTDAAyncgJCRTBTYChlqdTZldpMJhVhTrCMXgxRaiUxXtqZUgqEp"), string("wDQdzzigtIZAGqGOZedMarVCtSftPJXWAFcMyArdNsgcqYSMcnlFZvqFpSkVBCTEulUXMfbWHebuiHrksSixMhVJlkdkGXfFLqJLdumgcivOAbEmfnbpRtvlejvuMTptzBZFDmABxFiOcCVnqjtjNPyHVnqZaHfmkZiGNLgfNNxtgMavEfUDNcYDHJafzUBRyrkwKuTIsGZsegLuLABwjcbmmsibpHLwthqhLxLsvcBnMuNuIUmSzZ"), -52963.09651323474);
    this->FwwXZWHI(string("WJwhxnfFiHGAScvRCBPXqOMMZlmvdxdiSWzOKepksmqHcjhONBNoGmgktGxlfIFbRBfkfUVtYfpluESPHlIWjQDRybkDfsuiCRWLWajfzfzFFfflyLHvZGGEMEhuDSbQIZTNZwacimMZtqZLVjzWVGvzaJtFIRCmHTkLpcVBlHTDwjLpdzNdVrPdetkoTBsUKdnKQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class upoPLAhMjdFa
{
public:
    bool sWjYqLQoc;
    int kwwliJFhYCyUGS;

    upoPLAhMjdFa();
    int rhjInfbNDZFmtM();
protected:
    bool DBaiy;
    double taZRkwB;
    string PxCstYhESXUZ;
    bool tuwFFiE;
    double JKgHAhPCvwUQaR;

    int NEpSDdCXHsSVGVY(bool hFPhqkda, bool GdnbfNEdhKSV);
    double yzQdiusJAXeM();
    string INngefr(bool kGZkcDctRRtHOMt);
private:
    int jHeFJByFvMKKju;
    bool EssDDtWyPhWQupTQ;
    int DWLyfBoQpbJqCZ;
    string GqaHhTxcvex;

    int QuwHqTbaKKYHJp(bool DRJRekVRtDZaM);
    bool PoskTBYf(string rHUatBgWeO);
    string jYYBcQ(double iYihwWtlQFGW, double zdvRDnvgOvhPh, int VOnHLyNzOJki, double UXpgJqKeyiLjT);
    string BuOEdbuOMC();
    void HerZWNCjfODoCL(int OEwDpTFdapDU, double ntfiOvRRAcnnc);
    string maEenSJqM(string LcHwxMYVi, double dzRpPxBPK, double ExQEGvKj, double WkAlwpGxiJ, double tOWYIlLjT);
};

int upoPLAhMjdFa::rhjInfbNDZFmtM()
{
    int TSEqg = 708414353;
    double zPiWO = -198763.78679432295;
    string RUlJf = string("QljtgfeEULRBlAUMWlwjsZsyajofEgwIinYYSGGspqGnnUbjexwYKMSuyJtjUCgwoxPDUaRlCZZbfxddewBrzgeBvuompidurhK");
    bool SJBQkKPh = true;
    string mJWAyvyu = string("zZax");
    int cvYLlNfueEfaDgI = 1879440447;
    string gopwjJVuAFKcM = string("GBxDwtBeYLWfxoLoLUacHiaZVPKDTsOULlETsxvpOJHujMXrBBQASuslpCClXxwBxNBlGkMcITZGXKfkxSdMvTrISOvklZnUkrFDPKmEQmmjiyLJKujJxpZraMZReSZQQlwGwpGPxGrweUEzavxaVAQAjeLriycXHNAGWoMBiDpvtMvbgKFKgOdrzgDmhMRHtQRjRbsYlIoDBRlpVDoabJbonahPOWceeOtXXlZk");
    bool gPISSsoEnbXQxr = true;
    bool cJUGnmuGGhSNMA = false;

    for (int YapRTKXsM = 1045078903; YapRTKXsM > 0; YapRTKXsM--) {
        gopwjJVuAFKcM += RUlJf;
        gPISSsoEnbXQxr = gPISSsoEnbXQxr;
        gopwjJVuAFKcM = gopwjJVuAFKcM;
        TSEqg -= TSEqg;
        cvYLlNfueEfaDgI += TSEqg;
    }

    for (int xdXOVGf = 1110967077; xdXOVGf > 0; xdXOVGf--) {
        gPISSsoEnbXQxr = ! SJBQkKPh;
        mJWAyvyu = RUlJf;
        TSEqg -= cvYLlNfueEfaDgI;
    }

    for (int ybQqCYX = 135656696; ybQqCYX > 0; ybQqCYX--) {
        continue;
    }

    return cvYLlNfueEfaDgI;
}

int upoPLAhMjdFa::NEpSDdCXHsSVGVY(bool hFPhqkda, bool GdnbfNEdhKSV)
{
    string wPHGvdT = string("zIvHwZzvBIaKhfZDeeFgtmCwUsOJmiqXhGYJfwGwiXNupaFhFlwMOMpHVzMAhmrJnmdatLYnNpFpOlEuAuMqcvQBegHmUfoPTldNQziLXoqoCWprbwtDkUnfsVDuOrEmTiDXaYWcFjnePdUlBRQfnZNXsGhNTTNYnnnCyLglPyoktODkvLFQ");
    int SOoLhkWVVq = -280212526;
    string CmniAbnaehuI = string("YjtgYANrocKCZpdlPJImWrmGDOPjpMXTKJsxpEnXyfmOslNduiliTB");
    double VPAmPXzetWHCAa = -336493.5409215362;

    if (CmniAbnaehuI < string("zIvHwZzvBIaKhfZDeeFgtmCwUsOJmiqXhGYJfwGwiXNupaFhFlwMOMpHVzMAhmrJnmdatLYnNpFpOlEuAuMqcvQBegHmUfoPTldNQziLXoqoCWprbwtDkUnfsVDuOrEmTiDXaYWcFjnePdUlBRQfnZNXsGhNTTNYnnnCyLglPyoktODkvLFQ")) {
        for (int OIJaz = 922545139; OIJaz > 0; OIJaz--) {
            hFPhqkda = hFPhqkda;
            wPHGvdT += wPHGvdT;
        }
    }

    for (int mLFFOHHJFyegr = 1696304524; mLFFOHHJFyegr > 0; mLFFOHHJFyegr--) {
        hFPhqkda = hFPhqkda;
    }

    if (GdnbfNEdhKSV != true) {
        for (int Tkmva = 250998496; Tkmva > 0; Tkmva--) {
            CmniAbnaehuI = CmniAbnaehuI;
            SOoLhkWVVq *= SOoLhkWVVq;
            wPHGvdT = wPHGvdT;
            CmniAbnaehuI += wPHGvdT;
            SOoLhkWVVq -= SOoLhkWVVq;
        }
    }

    return SOoLhkWVVq;
}

double upoPLAhMjdFa::yzQdiusJAXeM()
{
    double PRgoej = 309726.72691075155;
    int gJRMtAoOWImwTvg = -2100629838;
    string eguKuIwKz = string("RGTTeLJHsdMiBBwBubUSHGeuRpCpKfmNrWkPNkXWmDmaKULheSAhwrPBjggIQfgwCqMisbbtgwm");
    bool VnOxavYkRxwmeP = false;

    for (int AHDdMqDeINqaE = 1154800451; AHDdMqDeINqaE > 0; AHDdMqDeINqaE--) {
        PRgoej /= PRgoej;
        eguKuIwKz = eguKuIwKz;
        VnOxavYkRxwmeP = VnOxavYkRxwmeP;
    }

    for (int uXcDuASIJhZo = 283331261; uXcDuASIJhZo > 0; uXcDuASIJhZo--) {
        VnOxavYkRxwmeP = VnOxavYkRxwmeP;
    }

    for (int uXtSs = 1932762570; uXtSs > 0; uXtSs--) {
        gJRMtAoOWImwTvg += gJRMtAoOWImwTvg;
        eguKuIwKz += eguKuIwKz;
        VnOxavYkRxwmeP = ! VnOxavYkRxwmeP;
    }

    for (int QWwJy = 2041735737; QWwJy > 0; QWwJy--) {
        eguKuIwKz += eguKuIwKz;
        gJRMtAoOWImwTvg = gJRMtAoOWImwTvg;
        eguKuIwKz = eguKuIwKz;
        eguKuIwKz = eguKuIwKz;
    }

    return PRgoej;
}

string upoPLAhMjdFa::INngefr(bool kGZkcDctRRtHOMt)
{
    double hlJhzzi = 26511.25367240592;
    bool puLvBb = true;
    bool WrWabJBKtSQ = false;
    bool iPWfiI = false;
    string iuqYufDI = string("qVZqfnnJMIAzFMICmiYqyVQGdFwqBztUrgZYzEIZAReXbGbapDchBCvxwsIapuMfkpajKJucKoO");
    int JMTtfAK = 514922961;
    string oAFzIxjKsGdKB = string("YRkLMFmUeuollPygNcgdZHpXWAOIzKiocgFeFxjTDmaxwDhmhthuMgbezFOkMFGbjpbyulKfhOrzkUWkEWZRdRljs");
    bool HRHYZcLy = true;
    int OvihZN = 1931647528;
    bool zMVfgwCwLos = false;

    if (HRHYZcLy == false) {
        for (int yCNCHLOGP = 615825040; yCNCHLOGP > 0; yCNCHLOGP--) {
            zMVfgwCwLos = ! WrWabJBKtSQ;
        }
    }

    for (int keBbNDYecmDJmf = 224386415; keBbNDYecmDJmf > 0; keBbNDYecmDJmf--) {
        continue;
    }

    return oAFzIxjKsGdKB;
}

int upoPLAhMjdFa::QuwHqTbaKKYHJp(bool DRJRekVRtDZaM)
{
    double DmaBoVoEcE = -555508.4860042613;
    int vaFkSAVMUjAzcl = 1380660212;
    string tQxdMAAnE = string("kIlaRnjCkNpGyxCZdXBQDIOupwfFOHRVHAYpamdmnxDcRyKapCalYEmzMgzZNACHFXkwYTjTkZhCybDdKyOCYQTdCYnYPFXlKQDSnGbinMyycccJbEHavwZZtabScjgbyPiuZLLTaBUqOFGAFepBWFYlfiyukFZEtPzuWJhWFqnKsyQDwGXVlvrikQFAWoqNYhoxaXGzuofh");
    bool LaAjzWxFTzMeF = false;
    double bbkybKQ = 972236.2733086987;

    for (int BweUgtxJKdclCJRc = 275506876; BweUgtxJKdclCJRc > 0; BweUgtxJKdclCJRc--) {
        bbkybKQ *= DmaBoVoEcE;
        bbkybKQ /= DmaBoVoEcE;
    }

    return vaFkSAVMUjAzcl;
}

bool upoPLAhMjdFa::PoskTBYf(string rHUatBgWeO)
{
    string hzGhDUBwfYfqwN = string("ekZCtDNFISSkYwCvnCCyXbeTvDGGPnrdjfaYkiKKTgMpFcmfcXLzuCSvpOqgKOUwAEieyiCCNStTedgfWVkkTpXiDZxZjJTJsaqMtLtzRxNBbvLARVNabeDluRxGHLXIhGeLTIadLIjFamuQMNGcwxKIYdnCUGYHfyrXNYaLJ");
    int RWInUpGO = -209963563;
    bool OxisacdSgHnSo = false;
    string oRvhWVyrIHs = string("TQVPGXADUwSmORxWWrxlqwFKcSBxjGitmOmPtRZOJIZkNwcBKuAWoYzNVysecnDvEJTSMUvKsFZwVzaMyMnmuQhbZyXkgcWsPdeyCBoBFbVHYIUTwxDmGNeCTpkHfUQsIAQByOHra");

    if (OxisacdSgHnSo == false) {
        for (int QImKiFKnV = 1561239309; QImKiFKnV > 0; QImKiFKnV--) {
            hzGhDUBwfYfqwN = hzGhDUBwfYfqwN;
        }
    }

    for (int toOCmUw = 671803441; toOCmUw > 0; toOCmUw--) {
        continue;
    }

    if (hzGhDUBwfYfqwN < string("ekZCtDNFISSkYwCvnCCyXbeTvDGGPnrdjfaYkiKKTgMpFcmfcXLzuCSvpOqgKOUwAEieyiCCNStTedgfWVkkTpXiDZxZjJTJsaqMtLtzRxNBbvLARVNabeDluRxGHLXIhGeLTIadLIjFamuQMNGcwxKIYdnCUGYHfyrXNYaLJ")) {
        for (int SXrRxeYLdo = 1626506817; SXrRxeYLdo > 0; SXrRxeYLdo--) {
            oRvhWVyrIHs += oRvhWVyrIHs;
            oRvhWVyrIHs += oRvhWVyrIHs;
            hzGhDUBwfYfqwN = oRvhWVyrIHs;
            RWInUpGO *= RWInUpGO;
        }
    }

    for (int tgIht = 1995263198; tgIht > 0; tgIht--) {
        rHUatBgWeO = oRvhWVyrIHs;
    }

    for (int IJBmTUclYnZa = 864362645; IJBmTUclYnZa > 0; IJBmTUclYnZa--) {
        rHUatBgWeO += hzGhDUBwfYfqwN;
    }

    for (int oTIvkEZRCaS = 245360577; oTIvkEZRCaS > 0; oTIvkEZRCaS--) {
        continue;
    }

    return OxisacdSgHnSo;
}

string upoPLAhMjdFa::jYYBcQ(double iYihwWtlQFGW, double zdvRDnvgOvhPh, int VOnHLyNzOJki, double UXpgJqKeyiLjT)
{
    bool GuxYUpPlaTwCYWD = false;
    double UcnAcLleccLnFmJ = -907574.103125652;
    int YHGfmMtJTBTm = 712079269;
    double QGOOrpVnynBUx = -506337.8467114279;
    double hpwGXU = -477610.5388296074;
    int kbzvdQCpZsDlyLT = 1091356341;
    double vxcGCRzFAbxMtu = 978974.710103538;
    double elyTjDtEEuCyWWsh = 152009.466306466;
    string QrLLk = string("dFCqYVZYLHLbhcdPPBSBkaScfZkChhdCrnqOseHcHpeiBAnSJD");
    bool fmVBYLZOkmmMbgkH = true;

    if (iYihwWtlQFGW <= 465741.71149676334) {
        for (int hpRkhhQHpf = 168130992; hpRkhhQHpf > 0; hpRkhhQHpf--) {
            GuxYUpPlaTwCYWD = ! fmVBYLZOkmmMbgkH;
            elyTjDtEEuCyWWsh *= zdvRDnvgOvhPh;
            vxcGCRzFAbxMtu -= iYihwWtlQFGW;
            vxcGCRzFAbxMtu = hpwGXU;
            UcnAcLleccLnFmJ = zdvRDnvgOvhPh;
            fmVBYLZOkmmMbgkH = ! GuxYUpPlaTwCYWD;
        }
    }

    return QrLLk;
}

string upoPLAhMjdFa::BuOEdbuOMC()
{
    double bHRiyFPvWAbhSq = 582324.2284675721;
    bool jTycmdGiFPKx = false;
    double NaKfIG = -122939.09473006718;

    for (int DeLLprp = 21286835; DeLLprp > 0; DeLLprp--) {
        bHRiyFPvWAbhSq = bHRiyFPvWAbhSq;
        NaKfIG /= bHRiyFPvWAbhSq;
    }

    return string("rqZPCYCUdbFcfEoWlhIIlPgUJkiJuCSktQUPwCToHPjEyEHMjrkhLPsiIrroZieSfYqobjuhKXvFfycVYUDQQBkJuXHBFVTLMbKJefIBqvhxFyMpCNyaDAHkGTJwkVQByEjVtCaUVcsXYiuGSyQwemYWiPwrLMGqNfYCEbjLtwhjxfniQGlfsmtgwOblQDvcxVAfDayJehCYKPLajHEypGvvMwNxyOcnNwtpLnvnYHRlnADFXcqIqbExwPu");
}

void upoPLAhMjdFa::HerZWNCjfODoCL(int OEwDpTFdapDU, double ntfiOvRRAcnnc)
{
    string hHElIFnqucnV = string("dZxSQginGRyXJorTRokHobisECKGWrapDcapaUAaUPrZVdnUlZUzoEaYivmZEiKlimZLNIPuvDrkmZUMHwPErW");

    for (int HkMSKLuJdcUD = 1360476503; HkMSKLuJdcUD > 0; HkMSKLuJdcUD--) {
        hHElIFnqucnV = hHElIFnqucnV;
    }

    for (int aYrBdzvlUcUoRb = 1678072731; aYrBdzvlUcUoRb > 0; aYrBdzvlUcUoRb--) {
        hHElIFnqucnV += hHElIFnqucnV;
        OEwDpTFdapDU += OEwDpTFdapDU;
    }

    if (ntfiOvRRAcnnc >= 522514.7569878931) {
        for (int mvOUNOywKQ = 259123539; mvOUNOywKQ > 0; mvOUNOywKQ--) {
            continue;
        }
    }
}

string upoPLAhMjdFa::maEenSJqM(string LcHwxMYVi, double dzRpPxBPK, double ExQEGvKj, double WkAlwpGxiJ, double tOWYIlLjT)
{
    string sOcaYIXSYNubsjs = string("ZhnaqegMRvMBKKiHOBqbCClRjbodJvEdnvnxOemqLakFvhYTwlIAxmIeLPAPKbnZbeWcRZLXILnYAQQQbiXtczugaUTQWzihxDvrSsyRodtcFKAGjcUvZuBMlqoEILkzrTLJMdEmjpOZCtYuoYnvfsKNAautoqEERlsDkbBLCSbipvZWtlmjEspWZnmmUiCLcToQEbliUakBTPLeelYIzjwDSGTXHvXMHhXmEHjFNhBIIlLfrHXW");
    string AXfjPBgVy = string("YrwpjdecsIHmHtCdcKtbCYSteQWRXKeDotmXkaOijlCFCwLFtxBLPpAcbLkHnxUykVPorCKkqRYMWwsdBrtSEiOybzvjuMlaLrsWQAFOFfuGADRjRYKdJzdYgDOVAFXTvpgnhKqeoHzudQYwROnxbpAuNXWwlFgrLprjwIuPdjCbfHdDfIYFlckSNVnGtnyonFCsjp");
    double efrGPSLqYFo = 629508.8634484968;
    string IyynIZmtEfCMxul = string("JYLGbHrPHpVijK");
    double BZeLxIsghUZFFcXB = -547728.4229253638;
    double lrAldgkuj = 1042405.3719622643;
    double MsmZCnyHqF = 676762.4104839866;
    int PfXsAzmrIfcfsgC = 326127208;
    int cYSknyGYWghnYZFw = 1890364216;

    for (int yNuYGvxy = 228497821; yNuYGvxy > 0; yNuYGvxy--) {
        efrGPSLqYFo += lrAldgkuj;
        WkAlwpGxiJ /= BZeLxIsghUZFFcXB;
    }

    for (int idsJZCjGroRpspX = 1748233339; idsJZCjGroRpspX > 0; idsJZCjGroRpspX--) {
        lrAldgkuj = ExQEGvKj;
    }

    for (int LkfDkFVWNPBlDQ = 853260085; LkfDkFVWNPBlDQ > 0; LkfDkFVWNPBlDQ--) {
        tOWYIlLjT -= BZeLxIsghUZFFcXB;
        ExQEGvKj *= lrAldgkuj;
        tOWYIlLjT *= tOWYIlLjT;
        WkAlwpGxiJ -= WkAlwpGxiJ;
        ExQEGvKj /= MsmZCnyHqF;
    }

    return IyynIZmtEfCMxul;
}

upoPLAhMjdFa::upoPLAhMjdFa()
{
    this->rhjInfbNDZFmtM();
    this->NEpSDdCXHsSVGVY(false, true);
    this->yzQdiusJAXeM();
    this->INngefr(false);
    this->QuwHqTbaKKYHJp(true);
    this->PoskTBYf(string("dtpmmCBEVHsvGoqHxmYxwMnZijyUgSVwkbWTxGUZHgDaJRHpeAudOiErpSQtHHmWMHjtvgm"));
    this->jYYBcQ(465741.71149676334, 1021584.7238514319, 355976848, 279568.8582699381);
    this->BuOEdbuOMC();
    this->HerZWNCjfODoCL(1148623505, 522514.7569878931);
    this->maEenSJqM(string("BsafCKvDWeKabGldafBgurKWNAhSsBhUbvwkPFpXoeVBpTKSCHosRSTEDlMuytrPDGDxlDdpFZDtyMyWlAoxCHDjPacweDChgcOhjngBGGPRRnzXNrZIIqaAwoBSwxdoSi"), -632302.0843014229, -498917.58088502416, 715748.8540668326, -1020097.6584212924);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JtbdtebSkfXBB
{
public:
    int wdvwKWKt;
    int pvfNyEdVyBaB;

    JtbdtebSkfXBB();
    double uQXCKWZnXWnjDOTA(int QYeojtDzTkkJqNuf, string DOZghdWAcvfa, double ZOuOE, double SweTSadASUyET, string nxzkCHwFwr);
    void KvTKT(double MIOKvNggynha, int pGAXcuEdZ);
    int VCRIo(int eUABGUdP);
    bool VQAcEIXZcJzWyX(bool GbizNTeV);
    string FuAdDRvFiP(string nEZit);
    void KMOtQGhkchwc(string mUFOOsKFdawHfhI);
    void naAFD();
    int hwBJMeMdVWpgO(double ZnxzIDMJJ, double OEQwP, int gqLffHIWnQG, double PKPdBEBI);
protected:
    int tcQsM;
    double WJWolWFf;
    bool FMxOHYdYPq;

    int czIucIypVRYUFcB(bool wgRasgFPwoymTHjm, bool AqLuWWTB, double CdpXkHo, bool UPEtBmb);
private:
    string SWYlbytQI;
    double wYyOdLVgiwzjJUbT;
    bool UhsGHjczGXI;

    double ZkPRDIhhZEYdnZQ(double mqRuhYtmCcLpJD, string tGgBFvVm, double mLleOt, double knWMlLDKRSa, double wvrvbDm);
    void IMmlQjxLqAVh(double SltLI, double aKRkIznNjUweu, int zQCdlLFfvFkoyicg, bool vHOoRwwQxXMff);
    void VCECCwbdwmno(double ajvULm, string SsrMvuZdaSeblZX, string PsoZOylGvWoQCVXs);
    bool ePLgcnHrLeiH();
};

double JtbdtebSkfXBB::uQXCKWZnXWnjDOTA(int QYeojtDzTkkJqNuf, string DOZghdWAcvfa, double ZOuOE, double SweTSadASUyET, string nxzkCHwFwr)
{
    bool ZGQjknBoCo = false;
    bool jywtN = true;
    bool SNIBeSLuL = true;
    int JvnErfZv = 1554515890;
    double iGpJbEvLCXNU = -884358.2827765077;
    bool gkFVhXzyFkeuIXqn = false;
    double WbVWwPkyZCIQDNk = 4487.6812211278875;

    for (int OToSO = 1977292529; OToSO > 0; OToSO--) {
        jywtN = jywtN;
        WbVWwPkyZCIQDNk *= ZOuOE;
    }

    if (iGpJbEvLCXNU == 4487.6812211278875) {
        for (int xMJNJYzHhUptzea = 1324345817; xMJNJYzHhUptzea > 0; xMJNJYzHhUptzea--) {
            ZOuOE += iGpJbEvLCXNU;
            WbVWwPkyZCIQDNk += WbVWwPkyZCIQDNk;
        }
    }

    for (int OPtpDAzCbqrRkiT = 622816364; OPtpDAzCbqrRkiT > 0; OPtpDAzCbqrRkiT--) {
        continue;
    }

    if (DOZghdWAcvfa > string("dMWxOWYuuDuNerMvTaGDTDqpQWuTMphLofvGtHpABvlOiaVWDUeYlieKcyhCPPLouQVCnyyXMzszJBNDMMazOIkAaoQXLuZhOGpZZDPWSVJGzmkVgI")) {
        for (int kfIdkB = 762254616; kfIdkB > 0; kfIdkB--) {
            ZGQjknBoCo = gkFVhXzyFkeuIXqn;
        }
    }

    return WbVWwPkyZCIQDNk;
}

void JtbdtebSkfXBB::KvTKT(double MIOKvNggynha, int pGAXcuEdZ)
{
    bool sCMCxur = true;
    string NMkCSdUQAFuUg = string("GWISOikRWPkLBCyCwfnkSWYsrdVOwgWECfSEdKhoidMumgyuHvgwfPVykfEvjaRufnljkARMaFwtgGAYbTICZTPSLAGRADXUXnRyKrxRcthnSzezXAEaQdkVUCRuPyWvihotaWibEALRwtEIlyuGvFPSMtwmHRGunvsOkWWHyCSRolubazDfZfwVvpDhBxwrYkPDOBATUkptVSRxIrkYunrOhqGeRvvyHJgmspFGbHlsU");
    int KJNHExfYeMViky = -247042921;

    if (pGAXcuEdZ == 1353504077) {
        for (int yTlvmKxGjeYiaVMp = 564304312; yTlvmKxGjeYiaVMp > 0; yTlvmKxGjeYiaVMp--) {
            MIOKvNggynha += MIOKvNggynha;
            sCMCxur = ! sCMCxur;
            MIOKvNggynha /= MIOKvNggynha;
        }
    }
}

int JtbdtebSkfXBB::VCRIo(int eUABGUdP)
{
    int PPPXe = -2010432643;
    double WCQcLbdnnfWXPN = -356208.1787111729;
    int FbLUSvYvKQ = 1746959768;
    double nNvAn = 282795.00932171755;
    bool SMvUCDB = true;
    int zDpLrGRWvHT = 2106452484;
    bool NKzvNOHUzt = false;
    string BRboOmBn = string("pjYAzDMeaAEuMrCjlHECJXDIxhUwIejI");
    int JRjCTTnbgOWkalQ = -1193706665;
    double xaxNsknEFBRSQC = 73018.08432706306;

    for (int NewHYrGyjamsW = 1869035744; NewHYrGyjamsW > 0; NewHYrGyjamsW--) {
        FbLUSvYvKQ = PPPXe;
        NKzvNOHUzt = ! SMvUCDB;
        nNvAn *= xaxNsknEFBRSQC;
        xaxNsknEFBRSQC -= nNvAn;
        NKzvNOHUzt = ! SMvUCDB;
    }

    for (int LhPFnPrsGwuED = 132190660; LhPFnPrsGwuED > 0; LhPFnPrsGwuED--) {
        continue;
    }

    for (int GZskKRgHYu = 99207381; GZskKRgHYu > 0; GZskKRgHYu--) {
        FbLUSvYvKQ *= eUABGUdP;
    }

    if (PPPXe >= -2010432643) {
        for (int FjSlzck = 2106786568; FjSlzck > 0; FjSlzck--) {
            continue;
        }
    }

    return JRjCTTnbgOWkalQ;
}

bool JtbdtebSkfXBB::VQAcEIXZcJzWyX(bool GbizNTeV)
{
    bool stGaBXdjljP = true;
    int UsKliG = 43240054;
    bool aKyPXyiHcBRA = true;
    double zJQQUNHn = 405997.0208452865;
    int KBrzADaW = 10374856;
    double ggbKVnOkNVNx = 181166.69162998884;
    string efXsvBljeOOAW = string("DHjsLzJxZWSqUBQyRNrlpYFMGnvHenyRwhLcEwPOURdwQvuCPaPDxshWdzkwRFslTlJZrCDChFHlULRiwVkmb");

    for (int VhgVquNgZ = 649979524; VhgVquNgZ > 0; VhgVquNgZ--) {
        GbizNTeV = GbizNTeV;
        stGaBXdjljP = aKyPXyiHcBRA;
        aKyPXyiHcBRA = ! stGaBXdjljP;
    }

    for (int PJFWdciK = 1048848275; PJFWdciK > 0; PJFWdciK--) {
        efXsvBljeOOAW = efXsvBljeOOAW;
        GbizNTeV = GbizNTeV;
    }

    for (int BPuvlZNVNLDGM = 1385205595; BPuvlZNVNLDGM > 0; BPuvlZNVNLDGM--) {
        continue;
    }

    if (aKyPXyiHcBRA == true) {
        for (int UrGgXoDYQYlYMWG = 562467146; UrGgXoDYQYlYMWG > 0; UrGgXoDYQYlYMWG--) {
            aKyPXyiHcBRA = ! GbizNTeV;
            aKyPXyiHcBRA = aKyPXyiHcBRA;
        }
    }

    return aKyPXyiHcBRA;
}

string JtbdtebSkfXBB::FuAdDRvFiP(string nEZit)
{
    bool zcpaQrKwkHybPe = false;

    if (zcpaQrKwkHybPe != false) {
        for (int KnRlfBiUXLG = 319631259; KnRlfBiUXLG > 0; KnRlfBiUXLG--) {
            nEZit += nEZit;
            zcpaQrKwkHybPe = ! zcpaQrKwkHybPe;
        }
    }

    for (int jUpGZSOmKkm = 318868032; jUpGZSOmKkm > 0; jUpGZSOmKkm--) {
        zcpaQrKwkHybPe = ! zcpaQrKwkHybPe;
        nEZit = nEZit;
        nEZit += nEZit;
        nEZit += nEZit;
        zcpaQrKwkHybPe = ! zcpaQrKwkHybPe;
        zcpaQrKwkHybPe = ! zcpaQrKwkHybPe;
    }

    for (int qHJCNikogtB = 1811079569; qHJCNikogtB > 0; qHJCNikogtB--) {
        nEZit += nEZit;
        zcpaQrKwkHybPe = ! zcpaQrKwkHybPe;
    }

    for (int MrrpGDNNLFD = 62441216; MrrpGDNNLFD > 0; MrrpGDNNLFD--) {
        nEZit = nEZit;
        nEZit = nEZit;
        nEZit = nEZit;
        zcpaQrKwkHybPe = zcpaQrKwkHybPe;
        nEZit = nEZit;
        zcpaQrKwkHybPe = zcpaQrKwkHybPe;
    }

    return nEZit;
}

void JtbdtebSkfXBB::KMOtQGhkchwc(string mUFOOsKFdawHfhI)
{
    int bHkBF = 467900026;

    if (bHkBF <= 467900026) {
        for (int vNwJaghUyUkjraPK = 1579273979; vNwJaghUyUkjraPK > 0; vNwJaghUyUkjraPK--) {
            bHkBF -= bHkBF;
            bHkBF /= bHkBF;
            bHkBF = bHkBF;
        }
    }

    if (mUFOOsKFdawHfhI != string("tLessevVjwIsEuNjIpRysZFqmEHxbuBcocPNuVfkKRtOpJKmWBXuINajmkerMcIZIzJLSuWDDvVzHjIQSrTpTtZZMBAXIgdOpnakmdLyyIzkgXqXSBAZlizajIyCT")) {
        for (int hwfTxMWSww = 1277103324; hwfTxMWSww > 0; hwfTxMWSww--) {
            mUFOOsKFdawHfhI += mUFOOsKFdawHfhI;
            bHkBF *= bHkBF;
        }
    }
}

void JtbdtebSkfXBB::naAFD()
{
    int lbMfJECvve = -1213111486;
    int fxKpCMxfSxvks = -957280849;
    bool MZjAmQFSbsiFah = false;
    string ynVRukr = string("ehwHZZHPquiNHZZPtqtNJlJcDobJEpAdghbGnjaRKGCaofmzfIgHrVdcQkUgpMlyZuFygaswDKdfCiuwXLoRrrjANYQAfDVzlZXzweeORnqpWNGROseMFGgaGjFMxIcNFmpQKDYjbvlTPGYiPhbEzdyBZINXEfXYthEEpeixkQBVUvrTqUvRXuibQquQB");
    int vaotCJQsCzJzaq = 723577010;
    int joXwReUu = -1546235380;
    int ylnWfcYlxCxspbDI = -898850111;
    bool xMhjGr = false;
    int chZiGHJCKbinDK = 1230822357;

    for (int NWgSv = 655603892; NWgSv > 0; NWgSv--) {
        fxKpCMxfSxvks += vaotCJQsCzJzaq;
        vaotCJQsCzJzaq /= lbMfJECvve;
        ylnWfcYlxCxspbDI = vaotCJQsCzJzaq;
        joXwReUu /= vaotCJQsCzJzaq;
    }

    if (ylnWfcYlxCxspbDI > 723577010) {
        for (int HJafkktzKrUW = 651649482; HJafkktzKrUW > 0; HJafkktzKrUW--) {
            vaotCJQsCzJzaq *= ylnWfcYlxCxspbDI;
            joXwReUu += joXwReUu;
        }
    }
}

int JtbdtebSkfXBB::hwBJMeMdVWpgO(double ZnxzIDMJJ, double OEQwP, int gqLffHIWnQG, double PKPdBEBI)
{
    string bjurpASWS = string("uWknctrjIBtEzgnWjCKOtyIdDMxHWYexqcMAMwKbDwKJhfFpiOT");
    int fdyMRzQ = 1182694112;
    bool gsbIeDmNAGw = false;
    string JFBDdMW = string("NSFngvpXKHkSlDURnJYhZMmDLFeBEoCBzBayRDfEvutDzgUHVeKokkttSJteKLcJMvHDtSFrXLMvxRMvWYalADZ");
    int tEFEqZJFg = -64262481;
    double tHsqrRLJoQ = 21427.510030357113;
    string ZFmGbkPLWXZX = string("oYUUHyBJJIHaltCThMJOMpksmYTkYSyCJliIrlUKldXPKdyjqoBOmwstZXLnqIzpgokvqAktVttjqEeMLTOuxbTKgEEuLmXFdEAhdAbpQrJXJHraMhOTtBeZHiNXRxUpIKlnYkuWeiLgVwuuXcwylCfpLCekhardWrtHwOFpXCePDFiYUTJtxShwqjElqmwaspWwGjtgcdjxOXIQjlmoKHXYgySrVNggxMzhzGOSnScyJDHM");
    int VJhMPlCHJjnC = -583082138;
    bool JwpLB = true;

    return VJhMPlCHJjnC;
}

int JtbdtebSkfXBB::czIucIypVRYUFcB(bool wgRasgFPwoymTHjm, bool AqLuWWTB, double CdpXkHo, bool UPEtBmb)
{
    int EkKAXqxtrGapg = -1083332237;
    bool ZByFellYl = true;
    int yQXEASqQTxGHGFj = -1836397742;
    double yJbKlUteYkwJar = -669261.1462812261;
    string lbrlKgDDfHkGkMm = string("SINpmCatrvuDzVWXMliIAaxGKByYrMHhUiDQQokddyAEbhVeQtCJRYrghWINkNcZWiaEcajxbCdgOYqAOJfGySDPFeHlJbKVcrGnvBBrViXrKyJqFIrkmNtXrWaJPRqIOcvBbpwYYuHpPFyzJYRegWCxjUojOZGvTRdMzTDfMVcneXilquwDgUCDNxXzWMNABFuCQyVUDwBTxBFMplLrIncpuJembzzCzLehKBNbSNrcSE");
    int mqfqTKpE = 29277098;
    bool ehMuuHriOHmUINnT = false;
    int JARQVPPgXGblsvp = 2014617745;
    bool jhaofFwdEzkh = false;

    if (AqLuWWTB != false) {
        for (int fVnRXouKnGd = 195470256; fVnRXouKnGd > 0; fVnRXouKnGd--) {
            mqfqTKpE += mqfqTKpE;
            UPEtBmb = ehMuuHriOHmUINnT;
        }
    }

    for (int VtQVlqYR = 1743847183; VtQVlqYR > 0; VtQVlqYR--) {
        EkKAXqxtrGapg *= yQXEASqQTxGHGFj;
        JARQVPPgXGblsvp -= JARQVPPgXGblsvp;
    }

    for (int HcmPRfXgl = 1788386572; HcmPRfXgl > 0; HcmPRfXgl--) {
        mqfqTKpE = yQXEASqQTxGHGFj;
    }

    for (int wcMmFghAYLaCYztB = 1247415740; wcMmFghAYLaCYztB > 0; wcMmFghAYLaCYztB--) {
        mqfqTKpE -= mqfqTKpE;
        CdpXkHo += yJbKlUteYkwJar;
        ZByFellYl = UPEtBmb;
        AqLuWWTB = ! AqLuWWTB;
        jhaofFwdEzkh = ! AqLuWWTB;
    }

    return JARQVPPgXGblsvp;
}

double JtbdtebSkfXBB::ZkPRDIhhZEYdnZQ(double mqRuhYtmCcLpJD, string tGgBFvVm, double mLleOt, double knWMlLDKRSa, double wvrvbDm)
{
    bool kthojtCl = false;
    string tmRntwhujPLDir = string("qrVonVvApEsbKMxEGtQJQAOtQRXz");

    for (int iQVuo = 1960945393; iQVuo > 0; iQVuo--) {
        knWMlLDKRSa -= mLleOt;
    }

    return wvrvbDm;
}

void JtbdtebSkfXBB::IMmlQjxLqAVh(double SltLI, double aKRkIznNjUweu, int zQCdlLFfvFkoyicg, bool vHOoRwwQxXMff)
{
    bool gzhsBuLEITSG = true;
    int ajxmuSfS = -822702315;
    int oAgbmExr = 267599161;
    int CcRRqLO = -763909156;
    int ybRhEliGyIxhp = 1100705232;
    int yAofssaMxL = 427017743;

    if (CcRRqLO >= -822702315) {
        for (int BzsSnxjlVIvAbh = 1341792388; BzsSnxjlVIvAbh > 0; BzsSnxjlVIvAbh--) {
            zQCdlLFfvFkoyicg /= ybRhEliGyIxhp;
            oAgbmExr += yAofssaMxL;
            zQCdlLFfvFkoyicg -= zQCdlLFfvFkoyicg;
            gzhsBuLEITSG = gzhsBuLEITSG;
        }
    }

    if (gzhsBuLEITSG == true) {
        for (int FpUECRnpniiD = 1059573615; FpUECRnpniiD > 0; FpUECRnpniiD--) {
            yAofssaMxL /= yAofssaMxL;
        }
    }

    if (vHOoRwwQxXMff != true) {
        for (int mfTMcvcYcX = 1091640348; mfTMcvcYcX > 0; mfTMcvcYcX--) {
            ajxmuSfS /= ybRhEliGyIxhp;
            aKRkIznNjUweu *= aKRkIznNjUweu;
        }
    }

    for (int CLAzmBHhpyjNXv = 692808037; CLAzmBHhpyjNXv > 0; CLAzmBHhpyjNXv--) {
        CcRRqLO += ajxmuSfS;
        ybRhEliGyIxhp = yAofssaMxL;
        ybRhEliGyIxhp += CcRRqLO;
        ybRhEliGyIxhp /= zQCdlLFfvFkoyicg;
        ybRhEliGyIxhp /= ajxmuSfS;
        aKRkIznNjUweu -= SltLI;
        zQCdlLFfvFkoyicg /= oAgbmExr;
    }

    if (yAofssaMxL <= -957231355) {
        for (int bkuVZORrPKstyMGR = 953203530; bkuVZORrPKstyMGR > 0; bkuVZORrPKstyMGR--) {
            ajxmuSfS /= CcRRqLO;
            aKRkIznNjUweu /= SltLI;
        }
    }

    for (int EpSnNngcpMF = 1112401167; EpSnNngcpMF > 0; EpSnNngcpMF--) {
        CcRRqLO *= ybRhEliGyIxhp;
        zQCdlLFfvFkoyicg /= ybRhEliGyIxhp;
        gzhsBuLEITSG = ! vHOoRwwQxXMff;
    }

    if (oAgbmExr == 267599161) {
        for (int xyFWSp = 982559903; xyFWSp > 0; xyFWSp--) {
            ybRhEliGyIxhp += zQCdlLFfvFkoyicg;
            gzhsBuLEITSG = vHOoRwwQxXMff;
        }
    }
}

void JtbdtebSkfXBB::VCECCwbdwmno(double ajvULm, string SsrMvuZdaSeblZX, string PsoZOylGvWoQCVXs)
{
    double UuWPCNkKEvHFxI = 804739.6632669226;
    string vKVEVDjRrGG = string("MgcguhyNrlWhJqGrEMQkdvjqKlchkfmPPlyCWTHebyMNsoaOSEFswqTpjiNInNKnDQOfDJexUqDmCVOOgXuEKrHiaJsEuVzWRRlQPnCoSaHOWbzIONVPnzlUVTYsuHPyfKEXTSOOEKlRRZbDnQNOVuNsdoOhnPFeFzrPlElmTMuvVCDspRqxixtUDBDQSAEDMAtPSjAAeMgIxVqAqZBoJoxXudRHlDTDEgrwIjCrtTYa");
    string FdCXiAiAyTdEIdw = string("myqmOSCvmWAxHuSnTzrQoYnQdIjLrTFELRhXcVGzebMxyHBZVDMNfKiGiXDDFXRKBkMbrrGGVdtkzOMnColDiyBQcTYUFNfAHiqSoxnWXGMWTovrRMSTohMgcXReWtGlRsAGmirnMMJPCKVRdGDrtvtEKefheQKbVREUpjv");
    bool geqBcixwFwN = true;
    int dyWJKlJOddEayD = 1434960115;

    for (int UmpFWspUPiXJ = 1697283570; UmpFWspUPiXJ > 0; UmpFWspUPiXJ--) {
        continue;
    }

    for (int YtAqKRprtpzjPA = 1140741431; YtAqKRprtpzjPA > 0; YtAqKRprtpzjPA--) {
        vKVEVDjRrGG = SsrMvuZdaSeblZX;
        FdCXiAiAyTdEIdw += PsoZOylGvWoQCVXs;
    }
}

bool JtbdtebSkfXBB::ePLgcnHrLeiH()
{
    int jAjExSnHElmc = -89012317;
    int MRWAxxkCPqafus = 1576653159;

    if (MRWAxxkCPqafus != -89012317) {
        for (int sMtxvfupnte = 43072286; sMtxvfupnte > 0; sMtxvfupnte--) {
            jAjExSnHElmc /= MRWAxxkCPqafus;
            MRWAxxkCPqafus = MRWAxxkCPqafus;
        }
    }

    if (MRWAxxkCPqafus < -89012317) {
        for (int Ojyyj = 650054468; Ojyyj > 0; Ojyyj--) {
            MRWAxxkCPqafus = MRWAxxkCPqafus;
            MRWAxxkCPqafus += jAjExSnHElmc;
            jAjExSnHElmc -= jAjExSnHElmc;
            MRWAxxkCPqafus = jAjExSnHElmc;
        }
    }

    return false;
}

JtbdtebSkfXBB::JtbdtebSkfXBB()
{
    this->uQXCKWZnXWnjDOTA(1013720385, string("dMWxOWYuuDuNerMvTaGDTDqpQWuTMphLofvGtHpABvlOiaVWDUeYlieKcyhCPPLouQVCnyyXMzszJBNDMMazOIkAaoQXLuZhOGpZZDPWSVJGzmkVgI"), -950012.0508756319, 366631.6655122043, string("RdgQEUtQoXkYWzcLzoDQjnJOxKWWFSKXHFvhQpNuIYrQufYlJyMKrXqHmaqHGEJORJpKNZOoGdlrwCARiWxLoVMwfXOgzkdNtHBTJYWxXtZEyCjPOXWSIJiNmIyVFdtbpKQrxMEEPXcrBmpsdpDPZIflSwXC"));
    this->KvTKT(-1033947.3665628083, 1353504077);
    this->VCRIo(-448549916);
    this->VQAcEIXZcJzWyX(true);
    this->FuAdDRvFiP(string("wfgoOUfZxBqPNpqCQjgmITXjdPlKObhrOCQLwrDbMwWbrhsYyaTXXWrextLPudqwRAzWSwoZWkgwBG"));
    this->KMOtQGhkchwc(string("tLessevVjwIsEuNjIpRysZFqmEHxbuBcocPNuVfkKRtOpJKmWBXuINajmkerMcIZIzJLSuWDDvVzHjIQSrTpTtZZMBAXIgdOpnakmdLyyIzkgXqXSBAZlizajIyCT"));
    this->naAFD();
    this->hwBJMeMdVWpgO(691881.0942324002, 411401.2720305042, -1712456871, -295944.6235845464);
    this->czIucIypVRYUFcB(false, false, -793851.161339584, false);
    this->ZkPRDIhhZEYdnZQ(791483.4030908999, string("wKCjOnJyUcms"), 718951.9100444915, 389811.4094262919, -198735.34604466116);
    this->IMmlQjxLqAVh(-1027663.7492503257, -77559.8794669143, -957231355, true);
    this->VCECCwbdwmno(513306.434492086, string("jqSxZCLGDPqgZkmZZBCUAVmyeRbhXZoguXkaRZzIGnnFvKrudSuuVYVYuIUrPoJIujkORAlxvHqGZJfZltiNclPvmFXLntkfwAVGLfyfqupppLKvHHRheVUkmEpYFHhnsXfzCVhIeWVyTBLmhmpgezQTrfrDoAzxqUlXLhGdnqsriHZuMJiBZhfLqqHqtfoNlLkmQpAPTdtBZWxbeK"), string("XPijeUkBMenxNdFwvpfTYYWNNnxCwhEJCyUXceaLRihKVwZCcTDtBxcenMUUENVlbBxOrrorYGMkrRLksqbhuqkSRHXKSQXJWGvfzvpYacWxRMOJHamRrGxDKbkTZUjCKCySZSdydTTcqkqqhzPcyNTOmUucYbbkmkByGDwyJxPUhxkPTYIJrSxYjDoMvXIYCEoutTRuvfznlHexonqOWWLbrsfwmsZmOKcGBH"));
    this->ePLgcnHrLeiH();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hBCWyaCoNm
{
public:
    bool SwxIfNjResy;
    int EatnglYwxfw;
    double qSefYYwfN;

    hBCWyaCoNm();
protected:
    string lJXzRXytjRSlZFF;
    int Lqhrqmw;
    double URCPHPHsAHez;
    int dmOcrsMghAUmG;
    string JKdalV;
    string dCDsD;

    int cTbxH();
    string hDAGlBUfg(bool uBpTCNeAfq, string lPWHnNm, bool KkWYp, bool ZTEcsAotykjhVRKt, int izUmyVBpttEl);
    double gWqZXLrZhKs(double ewSztRNSNrwUYn, string UIfriqhGrxonF, string wQNSKiLKedFPGZYg, string pJxRpnKx, string DzrFwyYbXF);
    double wTpMmALKuJmKsGWh();
    string aWMIHsHe(double pAhnSwMxervBwVwU, bool TrQAbTMcVTitmJVp);
    double buvgYvhkGCxtl(bool lvseizgvRPCp, bool qyvwpCEy, double NMkuQO);
    bool BwejAAfCDlAO(string qctIfaPNQkebfNw, double kJCxVOBELvXQ, string ERZbrYMr, int tOHWMAzNJI, bool KBMPpzIacdPym);
    void jccUlrO(string vWTCg, string VUMUwHjXZxF, int nMrsMFtJG, bool iwmKdCmcU, bool ZeqmF);
private:
    double unfevzRVtlDiH;
    bool MkNTiQXeG;
    string ijeerLwkidXUWB;
    string bvJFToyXzXn;

    void GPgPscCpzHyr(int tDKAaduH);
    string DIXvJwyzYqjYgphI(int dwALYNWjODEm, double rZNkGoXGo, double CDqshQzTA, bool hoFnZRLZJiGcw);
    string TwvfOcTf(string PdynKa);
    void CZDDV(int rivJEBsGGaY);
    bool YDdKqwaCNFZboe(double WdKxGTeMIgeLXfx, double NCgJdVI, double PkddQzjXEbmYb, bool wjioeh);
    string sHbjHsDqPzSzz(double cQYOIDlFj, string jHpIePOdizG, double ZNMAGcfQnePpBTlg, int IAoSGamUGrHhqw);
};

int hBCWyaCoNm::cTbxH()
{
    bool IwcgwkcCtyGoJB = true;
    string aptiirllKsAYfhfm = string("KZEPnZbRAZayObBDKIeqZHaLBYTzRjhqpFQozGJbwzuZjDPPwDTtknMnhnhzLilkuznIGXXEGAgtLFcIEdhyydBgaULtVKpggHdbbQxDsOTgTuzEuWhufgCiFoqFzLgehySVUOEzBMSbdCsJxvMwHNVFCgmNrvacMdUuLUCsLphHtMHVXksZhpHNBpIJKmCKPDWgTTlbyfXCUIAyybFxrgc");
    bool WXleaN = true;
    int bMNPWIQarI = 1647930643;
    double TdPYc = 631931.4451107378;

    for (int FeePQHuPiZQPsRc = 1176136574; FeePQHuPiZQPsRc > 0; FeePQHuPiZQPsRc--) {
        IwcgwkcCtyGoJB = ! WXleaN;
    }

    for (int uXrpBDDtSnenyUnp = 1345499383; uXrpBDDtSnenyUnp > 0; uXrpBDDtSnenyUnp--) {
        continue;
    }

    for (int qBAYhqwrECje = 223482760; qBAYhqwrECje > 0; qBAYhqwrECje--) {
        WXleaN = IwcgwkcCtyGoJB;
        bMNPWIQarI = bMNPWIQarI;
        TdPYc /= TdPYc;
        bMNPWIQarI *= bMNPWIQarI;
    }

    return bMNPWIQarI;
}

string hBCWyaCoNm::hDAGlBUfg(bool uBpTCNeAfq, string lPWHnNm, bool KkWYp, bool ZTEcsAotykjhVRKt, int izUmyVBpttEl)
{
    string tPtmicXjCfDPGueA = string("tfXpolafpqywztGCdxCEKVXFxonqPZYhOosADwixKHPPFdhtXIkhdyGAwsBcRflgLdPXENkrVjfAEmXnEVvnRHIGRTLPCsclCnmakYyystXXXkOCaQQwnIjXcpcavSxFyreZQdLaLtdBdyTbezsNRmIMeprOvtuCapKnusLuunSYjiHevlYiwohuYnTtIbwGyKYadeUdWSK");
    string gSkHMdqRkaO = string("AdCexSXdqpYdDoavvvTWpubuCmKykpzgFVaFisgVT");
    double BAMXtXHvtHytLKkG = -128730.6253207502;
    bool zbOOpBgdJjUWNQyz = true;
    int UPMKU = -1591542623;
    double SqcGGiTqx = 582696.6956699837;
    bool olvaSX = true;
    double uRmmt = 914123.7037680362;
    int LrGPkIzeGitjIDfE = -1979588539;

    for (int cXpyNMYxfeeNtKL = 1623237681; cXpyNMYxfeeNtKL > 0; cXpyNMYxfeeNtKL--) {
        SqcGGiTqx /= BAMXtXHvtHytLKkG;
        UPMKU /= UPMKU;
    }

    return gSkHMdqRkaO;
}

double hBCWyaCoNm::gWqZXLrZhKs(double ewSztRNSNrwUYn, string UIfriqhGrxonF, string wQNSKiLKedFPGZYg, string pJxRpnKx, string DzrFwyYbXF)
{
    string IinpBdpTH = string("VsLtZcnPqDrYIhBFiVTXimVAgdadAklocUeclmyxocekRRhHeHBNezYrRz");
    string tLFzsHttLJdit = string("IKudXeNoORRThORgViETtuPdWwYdtWIyzANwImIfjHKcdYVuPDXjaktuatmZctNJQKAvcVUkAcfRSpYaHrCgfONTmpkKIkOEUxEkcyj");
    string dRYChClUQ = string("RqSKXRLYXwkVLbaDGRmoiDKBkpmlVRaULKLZLzNMvWtmeErIpZQrEEzLjhKiqtcWdwlnLhkcctmumiTcntElJhACzVkbsymjCfcWABZAQXtUKesShQRrdJSQ");
    double XaqVDtusrFkvXh = 898483.6089276029;
    bool dZbJvlfc = true;

    if (DzrFwyYbXF == string("pINIDyjebXBndhUKAKKFuTWZhoqctnQbxEUujahFcBQmUFhjkfmVujTPzuPThmwMJRLDJtQRSoOVGZsreTemwrvWzlQltNedypClnbZwtJXfDdVIaHvtfHimqFfPio")) {
        for (int cPdlP = 771168417; cPdlP > 0; cPdlP--) {
            ewSztRNSNrwUYn += XaqVDtusrFkvXh;
            dRYChClUQ += UIfriqhGrxonF;
            IinpBdpTH = UIfriqhGrxonF;
            dRYChClUQ += dRYChClUQ;
        }
    }

    for (int PyjlktCiIR = 1490860699; PyjlktCiIR > 0; PyjlktCiIR--) {
        continue;
    }

    return XaqVDtusrFkvXh;
}

double hBCWyaCoNm::wTpMmALKuJmKsGWh()
{
    double mRLTDHswpzVfS = -605177.93101212;
    bool IkVatVOq = false;
    string gOxlZZlKlQnIaNJk = string("YMCWHxIysukZhvNCXzObRpKVwjNtFVvvXHAyUkiGMfeccuADUxQisnnuoUQehMIWVrmRBDLtkrYTJeohaIKgoN");
    string nMwqQtLAA = string("WzgTUFjgugaSQAxsGaRocLHIKvxTWUhXDbrHFlDwcxghNXiZuIkWVnCQsbucCorpqVQcHywYoomqbyFPqaucpwQwFYPmaSHGNTRyxxtgaLxZYbHrogwbIaeHSZE");
    bool PsWjIX = false;
    bool TFJuw = false;
    int sUgOjtEMKghiLt = 103475034;

    if (IkVatVOq != false) {
        for (int AwclMD = 1057752926; AwclMD > 0; AwclMD--) {
            nMwqQtLAA += nMwqQtLAA;
        }
    }

    return mRLTDHswpzVfS;
}

string hBCWyaCoNm::aWMIHsHe(double pAhnSwMxervBwVwU, bool TrQAbTMcVTitmJVp)
{
    bool VNbzwRmIeyFYZcD = false;
    double qhDEdCBmVmazw = 601818.0363951003;
    int yWyyFoxazOIJpJK = 724550446;
    string GNtWAVMMOO = string("MEAvMqElKZXXxAIbWdpyqZejwOGbVnWATtnO");
    int syJEHnRUBQ = -1339575839;
    double KMIVZgGkSZ = 662188.6183168257;
    int STsNjtllgmvn = -31341018;
    int BBIpvywB = -1228599796;
    bool dAdKn = false;

    for (int xLsRRZgvVGSYVlaJ = 382521200; xLsRRZgvVGSYVlaJ > 0; xLsRRZgvVGSYVlaJ--) {
        syJEHnRUBQ += STsNjtllgmvn;
        yWyyFoxazOIJpJK *= STsNjtllgmvn;
        TrQAbTMcVTitmJVp = ! dAdKn;
    }

    for (int oVqlv = 1268737393; oVqlv > 0; oVqlv--) {
        STsNjtllgmvn += BBIpvywB;
        TrQAbTMcVTitmJVp = ! TrQAbTMcVTitmJVp;
    }

    for (int ylvyQlnoL = 438080469; ylvyQlnoL > 0; ylvyQlnoL--) {
        dAdKn = ! dAdKn;
    }

    return GNtWAVMMOO;
}

double hBCWyaCoNm::buvgYvhkGCxtl(bool lvseizgvRPCp, bool qyvwpCEy, double NMkuQO)
{
    double TmRjizPBUO = 629448.8260214993;
    double tRxOlacOiy = 632753.4313659783;
    double mKOIaxn = -907462.4148650517;
    string vIcuvYvvbrFGyB = string("relqXBQyoetcBZQrzreHJyxtdQRuhNMialSlTbUmjxEHcjCnhslcIGVbDKxnOLRYlEVjTztLycIxWLAyFpEvulFvzsdlsJUbOac");
    double hXZfZiRbpAQ = 263044.73641713895;
    double mjOLuZKNJsJaMmXY = -500518.1559236719;

    for (int dPRILUitEcyGQVf = 243248055; dPRILUitEcyGQVf > 0; dPRILUitEcyGQVf--) {
        hXZfZiRbpAQ -= TmRjizPBUO;
    }

    return mjOLuZKNJsJaMmXY;
}

bool hBCWyaCoNm::BwejAAfCDlAO(string qctIfaPNQkebfNw, double kJCxVOBELvXQ, string ERZbrYMr, int tOHWMAzNJI, bool KBMPpzIacdPym)
{
    int zaVuLGOqw = 1577841141;
    int qAiSLqOIdMaCjUwf = -494856431;
    double wKYuuEHLZWlnmkna = 258381.92541596264;
    int eRyXWp = -742663434;
    int sQPAYDPnqmWCpWc = -265977689;

    if (zaVuLGOqw > -1947438150) {
        for (int ZcyHYozeCAkL = 24033284; ZcyHYozeCAkL > 0; ZcyHYozeCAkL--) {
            eRyXWp /= qAiSLqOIdMaCjUwf;
            eRyXWp += qAiSLqOIdMaCjUwf;
            tOHWMAzNJI /= tOHWMAzNJI;
        }
    }

    if (tOHWMAzNJI < -265977689) {
        for (int IXqoUYKTTBmq = 935648266; IXqoUYKTTBmq > 0; IXqoUYKTTBmq--) {
            sQPAYDPnqmWCpWc /= qAiSLqOIdMaCjUwf;
        }
    }

    return KBMPpzIacdPym;
}

void hBCWyaCoNm::jccUlrO(string vWTCg, string VUMUwHjXZxF, int nMrsMFtJG, bool iwmKdCmcU, bool ZeqmF)
{
    double gSUHl = -613700.9067565261;
    string kGttOePOEywckjY = string("nAPJssBWcopbLwbjPdmYtBRdIXUBlyELflzbfWvzJZKNjEvBLUXjdiTaTJlbtndsjeMMllLGpYMkZuCVrPATNZEQbOJWrhooOgQXnXrsmhBJyGBhRoXIMlbAwULHHXVskbRRtxIqYZiCukXoEYWRZZmtQCcoFXqTldJldGUntiVWeILzzNo");
    int SQhiaNTwCAPW = 776104874;
    string eXKTCTlLaIvlK = string("IAyCUWypbRqWCtbilqNHAbAURlcBalyRNFDiooUEMOFRuDZrPAVhNKyokAjjgeTLdEUxfvxNqCFSmMVguYmBcbVOQhWsNFbRTXMwUlbvYdWHxhYrSYEIYwjO");
    int UUawf = 2045257838;
    bool RAiUnOY = false;
    string ovCDePMpTFleV = string("gtpjkgOdVuRpzOEoMnLVbRiaWarVyAOsDxONuUDEYqIQpBcLXpSjVyqjnYESHHmEGpWxUwJpCKllNdVwVmEmqdBgAQPGYqxKyPpEbngEhKphRKgOhfrRraLDjeknfUlXKxPmlZfbVPMuSSUotCNcDPrXUrCHBbhJFDFHwVLOyvawlktHiyaCZNJDjenhLRAAfhUnXlLuKihAtZBLbUtcFFBscOnDmEUQKgdghiAwReA");

    for (int DgYzhMIlVetU = 417697968; DgYzhMIlVetU > 0; DgYzhMIlVetU--) {
        RAiUnOY = iwmKdCmcU;
        ovCDePMpTFleV = eXKTCTlLaIvlK;
        SQhiaNTwCAPW *= nMrsMFtJG;
        vWTCg = ovCDePMpTFleV;
        ovCDePMpTFleV = VUMUwHjXZxF;
    }
}

void hBCWyaCoNm::GPgPscCpzHyr(int tDKAaduH)
{
    bool NJMKAYTmPmEHBL = true;
    int EMPasZhgSGNVyjDP = -1961425647;
    int okGTsW = -461642911;
    double qkgff = 281478.0548498213;

    if (okGTsW <= -1961425647) {
        for (int JWFQKARARUUot = 962139031; JWFQKARARUUot > 0; JWFQKARARUUot--) {
            okGTsW = tDKAaduH;
        }
    }

    for (int nKVaPGIhyZicZbDR = 1788185204; nKVaPGIhyZicZbDR > 0; nKVaPGIhyZicZbDR--) {
        okGTsW /= okGTsW;
        tDKAaduH /= okGTsW;
        tDKAaduH += EMPasZhgSGNVyjDP;
    }

    for (int RDgHMEoFNfHYD = 1639851278; RDgHMEoFNfHYD > 0; RDgHMEoFNfHYD--) {
        EMPasZhgSGNVyjDP = tDKAaduH;
    }

    for (int tDTuOEvjzHx = 888605325; tDTuOEvjzHx > 0; tDTuOEvjzHx--) {
        okGTsW *= EMPasZhgSGNVyjDP;
        okGTsW *= tDKAaduH;
    }
}

string hBCWyaCoNm::DIXvJwyzYqjYgphI(int dwALYNWjODEm, double rZNkGoXGo, double CDqshQzTA, bool hoFnZRLZJiGcw)
{
    bool eCecK = true;
    int FffkeeLsOV = 697926238;
    bool nwQWgVGWXHx = false;

    for (int BUncAypvNuSsJ = 1625491337; BUncAypvNuSsJ > 0; BUncAypvNuSsJ--) {
        continue;
    }

    if (nwQWgVGWXHx == false) {
        for (int bbxbyjV = 1011501877; bbxbyjV > 0; bbxbyjV--) {
            rZNkGoXGo += rZNkGoXGo;
            eCecK = ! eCecK;
            hoFnZRLZJiGcw = ! eCecK;
        }
    }

    for (int LirIO = 82985725; LirIO > 0; LirIO--) {
        eCecK = hoFnZRLZJiGcw;
    }

    return string("eetDcGYOOUCPDCJKmlJdFBCOBTvbbwWOVHOizXrGkdtoJodtaxbBePTIjvmGMlCdJOsYNouflOIkDHiMqjPxcXxaJIRLLOTaROytuvnURlJXkACkrgeEWE");
}

string hBCWyaCoNm::TwvfOcTf(string PdynKa)
{
    bool VvhWDGYP = true;
    int REZoWziwHxsnbSO = 178832466;
    string KEveaoguQEXTNQTs = string("zQxfEcqfGtgjBszPYDZGDdNgzcVRDtVytpGbfzhdspjYiRIKESLR");
    double FRHLYburBfP = -977532.0520687469;
    int WumOtiDLUJ = -1217547773;
    bool TNwKLEAKgzbZey = true;
    bool zVXemYyMGuH = false;
    int xMeKnZ = -157590270;
    bool PlkTErsWJWxPuU = true;
    bool ehgGxLBrUJfFJvm = false;

    return KEveaoguQEXTNQTs;
}

void hBCWyaCoNm::CZDDV(int rivJEBsGGaY)
{
    int XRYqphRY = 913450651;
    bool QRdPM = false;
    double ZDmeAToQrDloJ = 505871.75060399127;
    double JqOYuOtoxtW = -618830.0295550488;

    if (XRYqphRY != 913450651) {
        for (int DEyweqBhEoESfBi = 1530504291; DEyweqBhEoESfBi > 0; DEyweqBhEoESfBi--) {
            ZDmeAToQrDloJ /= ZDmeAToQrDloJ;
        }
    }
}

bool hBCWyaCoNm::YDdKqwaCNFZboe(double WdKxGTeMIgeLXfx, double NCgJdVI, double PkddQzjXEbmYb, bool wjioeh)
{
    double iDkjNFUmhGLQfgR = 198472.15952416052;
    int EBBArjAQCepJqO = 459866434;

    return wjioeh;
}

string hBCWyaCoNm::sHbjHsDqPzSzz(double cQYOIDlFj, string jHpIePOdizG, double ZNMAGcfQnePpBTlg, int IAoSGamUGrHhqw)
{
    double KyJPpxKOqO = 511017.1355916654;
    string YfOhYXpFBfGd = string("uFJWGqmwDyNFLpxAImkxsVGbNYuUacoAtUKsxpFkESVoJNBdZSMVXIllLxnvttheqgqfXSMPaOsGsvZOmXQcaQrvmLBbrvQAsSgtBSbGRbTblcLcSdWgOhGJjRqgcynqkqBKldUsUcOzlmJuuFOSaSQzHkWemBnmxzxLNHymrCJhxmcJTQqVWLUPFcxsGnQQEFPcvxaDhcYBtRtNNAypSfJYSsdNqtSsEiLwDALrMCMsdKDVXjcEjXUiz");
    string xyYjnijr = string("GXOunpZWUudzyo");
    string xlJyEgxas = string("haHpnEubrNtvYRgsZhTmHYykaIrZktwrRFgkXJTgDrnomwiaJoijiUOUwFXyIWBkEWiCFUYvRbDACKfXkqaVAUNQNZjQyicxRPxFEpNjHNGYEnFhCEmlYW");
    bool iEyPcKdnAXfgKXY = true;
    double mXwVIsU = -999496.9838645998;
    string yQVyV = string("vIMIkJGrLBKAMTInaZWBWlzmmcHwRxeeOxDYleDzoOnMnlbIsOmfIrDquzxYfoXNfPZKweDwhkhltAXSZHuUdnhuPMEInnaEEvcAownOOuSkuRQzEvLFhBpYxNNMsoePbMZgUBxsgVvwIjcUS");
    int ogqAhFjvu = 615583272;

    for (int htXijZLRuTOj = 81089859; htXijZLRuTOj > 0; htXijZLRuTOj--) {
        continue;
    }

    for (int QANPYBMXeSguzVQe = 1407097590; QANPYBMXeSguzVQe > 0; QANPYBMXeSguzVQe--) {
        ZNMAGcfQnePpBTlg *= KyJPpxKOqO;
        YfOhYXpFBfGd += yQVyV;
    }

    for (int XGeixXV = 556980510; XGeixXV > 0; XGeixXV--) {
        ogqAhFjvu /= ogqAhFjvu;
        IAoSGamUGrHhqw += ogqAhFjvu;
        jHpIePOdizG = jHpIePOdizG;
    }

    for (int iIWJgIdLqic = 1040718539; iIWJgIdLqic > 0; iIWJgIdLqic--) {
        xlJyEgxas += xlJyEgxas;
    }

    return yQVyV;
}

hBCWyaCoNm::hBCWyaCoNm()
{
    this->cTbxH();
    this->hDAGlBUfg(true, string("PFsvdewBPdtpuCWBuYXnHtrwevQJBxKldQXLXvyEmqJPnTrTFMsHRgjEdHByHxUaXRUMgESzuDgOdrMDDltjtzHVOUswrUuOKBonfMcYKPDlBfztZUOyyMVrmyEZduumIPPc"), true, true, -1864215911);
    this->gWqZXLrZhKs(115875.59464803262, string("pINIDyjebXBndhUKAKKFuTWZhoqctnQbxEUujahFcBQmUFhjkfmVujTPzuPThmwMJRLDJtQRSoOVGZsreTemwrvWzlQltNedypClnbZwtJXfDdVIaHvtfHimqFfPio"), string("dommzVkbanbaRhfgMSzeeVAUzBwxSepwasXKRjPJLdDfQSGcdyiRQqMdVBdSiZJbwiYOEBEXQIbePMUpsrCmK"), string("IqbEqpYNbmIrIITpRGrYGyFpoefoYraVtVcCGQANRWJcXrxmuPPNHOrOpkQQLjZeOrNKAakXIVGgIwRcQvXJzTgmTPlsNLSrgXcBzMHPhsMuBkRsrwAXLjHJjYTrbEWtalclgSEIqDGvElDEqFLxOa"), string("liSwCMKtmFqjBEuucndGSEjDEFEsULUCYosTrRAVhLg"));
    this->wTpMmALKuJmKsGWh();
    this->aWMIHsHe(547366.311147464, true);
    this->buvgYvhkGCxtl(false, true, -388141.2894381228);
    this->BwejAAfCDlAO(string("uxHIigfZnMcbgnqpMVvjcDYGmAErXLazWPGRqQhROSoaKgFlmxrcsmgVshMCOwKALTYgoNpTUxZssCByCJtFbECBISmNDVNoEqgqKrWQHansRkXpjHZxUdtQfpZHmetlNHGziMLeZSriV"), 342635.60081359226, string("aiOYPapGenWqouZTasMDTkpRShTgxwhpSdUohmzkWYbbHOFjcHwmjUGhyjJOMRVZlMEwEpRdFLAAcPxitTfsOLXpWhlMWnxkKpuSlpktHTKcpWTCnHALxuOSwnjrdLLdEacbamQNMHfhylzeaHJpnDxRdfSsBaQiyTOoifors"), -1947438150, true);
    this->jccUlrO(string("AGzIOnZnceinCtLTnBNNVRrQZwGrBouKgsDObmGdpoRNReelLEpVBZJNtzPjRHGfiaPxXILvbkeMknmWyIFXhIGDOesxvgqVCYrXNopzWSdrIbbXbzzkzGVjN"), string("XXxgyNIFcXBCqfvDOALUEOiMMIaadXTVbVumPyBuGCYuuNvWLAsIcQnGsQJqolJwUKkARJIpaExcNigVNxZcyIioSORsTwEcYzjFFIXDxZiSmLwwgPBGTzhSFalzThbwzGhvkYKFneTuhBtoQddVVKl"), -237538831, true, true);
    this->GPgPscCpzHyr(-1906425444);
    this->DIXvJwyzYqjYgphI(-1510823235, -903169.1679628306, 441435.75979332876, false);
    this->TwvfOcTf(string("r"));
    this->CZDDV(493541697);
    this->YDdKqwaCNFZboe(-328074.72918208584, 312708.58898343676, -963532.5312857828, true);
    this->sHbjHsDqPzSzz(649746.0157825263, string("aGWBkccKrdBKyohDRMeXJ"), -522609.3921784696, -1991744139);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cfbdBZvPbuRNWBYx
{
public:
    bool ZwClYQ;
    double bvsDUHRsJT;

    cfbdBZvPbuRNWBYx();
    string svFBmWZK(double wDBlOK, string qRXLr, double nwToGxtozKxsRRnA, bool Wdoywe, string TEWgsbNcIog);
    void BMeoUl(string juYikNykjWQOBA, string hvZCPKlHkOY);
    bool AmOZipUdKt(bool bhpdlmL, string dVUiLlxLBQCQYE, int VNhaYrJn, int OxBsTUYGv);
    int ZZfKJp();
    bool UCtYqkrECOocct(string ywBNZipHAaj, string DrePQLkDYpHr);
    void KGVabbbOZLFHT(double VtZVUucFMferWRQq, string FfGIccfXgwGOYqcN);
protected:
    string nFSqal;

    double vTkSzrFaM(double pVrmEwMOfiYONU);
    bool kHbpGqnrIyT(int rMbpOPsVHsMoZUGx, bool LFCFMwxvAI, string nSnzHccsLgo, int GgKIJ);
private:
    string QoRowe;

};

string cfbdBZvPbuRNWBYx::svFBmWZK(double wDBlOK, string qRXLr, double nwToGxtozKxsRRnA, bool Wdoywe, string TEWgsbNcIog)
{
    int fYsUnVKdGkL = -123958836;
    bool MmwDTEBABoNT = false;
    string bMVDBwQtgH = string("FvpIbBtdIWkMpWTnnJEdJqTmeVueegoypSHDdDRyYQPLMHNAWTRjtGGUJeUAtWzjIjsvmrdRJxKbPpCvXSJGhiCedqdGIwXIuBasbahQjUjuLYTkTKEzxaBMhxbDJo");
    bool HPlaL = false;
    string VxPmqmGqkWGpww = string("kWWbKgDSnNpaRUeNtakcYOrNudeHRQhVXcBwHeAXOuDGZYNAClskObNGUoqQdcfxqHlABXqVEyNlyOuotbVsfeGJOnFpatdHfPAuUGXdlKatHBoyxDHgJvQKRvOLIKtZkRaygNPHnFdkkQMNwJodHBGFKmKerwnncEBgfiOZsFdkYsYsOHntnFCxHeCGdOuRadJKMjAvTRGhUikIUEdhknhIrNbPFwczkeejMjZaFhkcXZH");
    bool xFdhchg = false;
    bool QPAvUmhnyOt = false;
    int ftgxzfEGI = 738432940;
    bool oURnUQ = false;
    int YYsjmWz = 2085616758;

    for (int CPykDYVFloMLsVY = 1463480674; CPykDYVFloMLsVY > 0; CPykDYVFloMLsVY--) {
        TEWgsbNcIog = VxPmqmGqkWGpww;
    }

    return VxPmqmGqkWGpww;
}

void cfbdBZvPbuRNWBYx::BMeoUl(string juYikNykjWQOBA, string hvZCPKlHkOY)
{
    double qBcQLCDqsHcl = 578583.6655655806;
    string iBSHmKI = string("QOcxmqEQPOLxcUBSaqlpHnuyBLieCdxWvTUNZqGEeXowbNxRoIQbdkZOaZjCVeUQsoOpkaDWHuorNMVapXKmfuRrByVxPoUmcMEnojigJfNUO");
    int MRnoxwMgmH = -268800236;
    int XDyCHicwF = 1894792854;
    string kGOTtZKkpZmKq = string("QBVqOPlxgpWUBEtLpcZyOPngtprkGSiHPEXatcANKJnAsoighQWqKMynBOcoguRhsnIauJFTQurFTMIPbjoPWdZeqlpPSgKkYzRflqlrjuxaFRKaJMXLpQkCahWlDOmrJlyJEIbAzvxZkRZDApSXFnZuZqQRnRMjDcWCSOQewbkhrrpcUosUeqVPMTRbWBJuQQDOacLOtMaOhuRlueDfwJmZyWbQcMqHHkUyJGv");
    int ZMcHRrZyT = -1554823387;

    if (MRnoxwMgmH >= -268800236) {
        for (int ThHVFRfd = 1532130626; ThHVFRfd > 0; ThHVFRfd--) {
            XDyCHicwF += XDyCHicwF;
            hvZCPKlHkOY = kGOTtZKkpZmKq;
        }
    }
}

bool cfbdBZvPbuRNWBYx::AmOZipUdKt(bool bhpdlmL, string dVUiLlxLBQCQYE, int VNhaYrJn, int OxBsTUYGv)
{
    bool PXDbRhGzyQhLX = true;
    string DIyxZVollDQOxDrI = string("ghJAHcvoOkCsCLQTzZxRiqbGxMAfvdBPtAViBPDhmTmoAMNvyCXFKPQZtByGDmvqzimfDIypBJULnavmgay");
    string quiMqBYm = string("BnVtBAo");
    double GJchA = 730283.6587154098;
    string IdqsEvgIOMIZxH = string("SJHoxZeNAtoScidYqKLHZqbgSzxaAOZgDRODyXwnGKPkPgjJjvyadTmcofSZHWKHOhtnXQpcsITNDkmctxutaachGaQQeGUENFQmqETKGemjnZVAxMdsgvHtKuZasvictjfSBTTokuhjLQskMpRGCrfhAlPqJNpgeaZQuXatLUsiNjFetZdTXNmElkkpmdDmuqrSFzJFFNYXhYXXRgJnFkYFSWjyMVzftPiCxpcdMdmqjWHCUg");
    bool xxsLICUKxmipLl = false;
    bool kSFkTQMAuVxqYbsY = false;
    double wPmMime = -320470.73299772386;
    int NGFmqllBfSMOZn = -1252644955;

    for (int ZQYvoBaTaUrdL = 582379244; ZQYvoBaTaUrdL > 0; ZQYvoBaTaUrdL--) {
        PXDbRhGzyQhLX = PXDbRhGzyQhLX;
        IdqsEvgIOMIZxH = DIyxZVollDQOxDrI;
    }

    for (int jFqtSAatYhZ = 9891298; jFqtSAatYhZ > 0; jFqtSAatYhZ--) {
        VNhaYrJn *= NGFmqllBfSMOZn;
    }

    return kSFkTQMAuVxqYbsY;
}

int cfbdBZvPbuRNWBYx::ZZfKJp()
{
    bool eRTkzIazZFfkVK = true;

    if (eRTkzIazZFfkVK == true) {
        for (int cYDMGQNZkoFtcu = 2038054109; cYDMGQNZkoFtcu > 0; cYDMGQNZkoFtcu--) {
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
        }
    }

    if (eRTkzIazZFfkVK != true) {
        for (int EdJTYyDlM = 887418061; EdJTYyDlM > 0; EdJTYyDlM--) {
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
        }
    }

    if (eRTkzIazZFfkVK == true) {
        for (int yPajRUCDipeeJL = 1362592127; yPajRUCDipeeJL > 0; yPajRUCDipeeJL--) {
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
        }
    }

    if (eRTkzIazZFfkVK != true) {
        for (int rHnWWna = 1058502830; rHnWWna > 0; rHnWWna--) {
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
        }
    }

    if (eRTkzIazZFfkVK == true) {
        for (int ubmHtodOkeQNOTk = 1761846972; ubmHtodOkeQNOTk > 0; ubmHtodOkeQNOTk--) {
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
        }
    }

    if (eRTkzIazZFfkVK != true) {
        for (int RgJsnZAdSTgQIw = 1542644768; RgJsnZAdSTgQIw > 0; RgJsnZAdSTgQIw--) {
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
        }
    }

    if (eRTkzIazZFfkVK == true) {
        for (int dnNDxDVKs = 2081787956; dnNDxDVKs > 0; dnNDxDVKs--) {
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
            eRTkzIazZFfkVK = ! eRTkzIazZFfkVK;
        }
    }

    return -1632637942;
}

bool cfbdBZvPbuRNWBYx::UCtYqkrECOocct(string ywBNZipHAaj, string DrePQLkDYpHr)
{
    bool tzlWkWklIt = false;
    bool ELkXiIPpyjbYWT = false;
    int EIrNw = -1739636825;
    string ANjGjv = string("lcJutXqKNqrbqSIPSPjdZYCgAssJpeayvLPjDZxlgzWyQSsSOBPSaziIOeAusLebbMFGGJYr");
    string MQcNIpGI = string("yCTENViLdOwwhbpfq");
    int lxUyf = -274634678;
    bool twgrPOnn = true;
    int zwJQBnTePDirltfU = -1172960033;
    string HWmsYexv = string("miFLZUFklQgThhaiLxLgHJzSYjAflGYylQDTUVVxOIlFJodZdPDZTMtnEbNwLloWyMxHWZlBoPmovhBafzQvtvYIIkngWcnhLxgeYWJAwrKNUvUXlQNNiTupZDiCwfuZYmaDvXaRwVDKgmJXQBTrwjOWWbuYBDMRVCqNeTfuEHLpepFUqkDBstfVVmWqXfmuoUpb");
    int EhWrfGqMzdZy = 429180176;

    for (int AYgSq = 1828080128; AYgSq > 0; AYgSq--) {
        continue;
    }

    for (int gueUrjh = 671934667; gueUrjh > 0; gueUrjh--) {
        twgrPOnn = twgrPOnn;
        lxUyf *= EhWrfGqMzdZy;
        MQcNIpGI += MQcNIpGI;
        ANjGjv = DrePQLkDYpHr;
    }

    return twgrPOnn;
}

void cfbdBZvPbuRNWBYx::KGVabbbOZLFHT(double VtZVUucFMferWRQq, string FfGIccfXgwGOYqcN)
{
    string fwSSvxuqkc = string("TrZRsgOuozDIHAWqVTHGZyWjgGbFUApXCMOZuUfewEvzxQVjfCrFWCLsdrtJbfQpFOJQajHQprFVfbrfWWXdxWQhKrHSqnQFiqrd");
    bool GmtGihPE = false;
    int NkkLiNVTwtTHK = 1378563105;
    bool UrqsnrnwLXml = false;
    double xpLlXAvUolHzGTEW = -817459.948080542;

    for (int ievewIufzFWmRJoY = 998553525; ievewIufzFWmRJoY > 0; ievewIufzFWmRJoY--) {
        UrqsnrnwLXml = ! GmtGihPE;
        GmtGihPE = ! GmtGihPE;
    }

    if (VtZVUucFMferWRQq <= -1028277.3641445475) {
        for (int zjnqEoQmFgQsv = 1630953080; zjnqEoQmFgQsv > 0; zjnqEoQmFgQsv--) {
            NkkLiNVTwtTHK -= NkkLiNVTwtTHK;
            fwSSvxuqkc += fwSSvxuqkc;
        }
    }

    for (int opNgSzqxMaIJBCc = 1057682033; opNgSzqxMaIJBCc > 0; opNgSzqxMaIJBCc--) {
        continue;
    }

    for (int VPKpCjFzSbHLh = 1916404987; VPKpCjFzSbHLh > 0; VPKpCjFzSbHLh--) {
        xpLlXAvUolHzGTEW = VtZVUucFMferWRQq;
        GmtGihPE = GmtGihPE;
    }
}

double cfbdBZvPbuRNWBYx::vTkSzrFaM(double pVrmEwMOfiYONU)
{
    double IugEvHnT = 227467.57767631693;
    double AUCAWbF = -445903.436132461;
    string YuNgTDAdhv = string("cTGcsegTLAwpNWBkzKeDetjwOFQABybirMosXTsbygcNsTgyanioBBGrGqaJdcwXltjHpeMzpAHqxSnLgmNUXRphgUqRSkjiHXiJcvrqGLiYxlYttnVUWDHDZjNqUfRlBaGsPOVrbkcPoTBiqUMBHANcRqYtrfBHVKIpexixyJBqXGffMbpEFIpwfdeqTHQT");
    string lhmWqWdSaJAI = string("KnEbwIhynPgPQhlIBxfQiISpQEvaldZeHWhmmxTrJUyLIMeJFFMjmOFxIsRcHwVbUPnpNoHMZMMcnukunHukrbNnhiAKhkWlehsqmzelJYvbbEvyUuIsAJhZUrxlrOEpHYFTgNvNCNAXjxoVYDBjtHYLsVVYFHHkyBbxBwetbKwynStlQDZPAxIGgagzOqAexHWsNQoeswnmQKhyqGnkpdsZXpNVNZN");
    bool uWBdAGvCPkppUcB = false;
    double kCKEWtKRw = 341407.464662355;
    int duEsCLILC = 2059913175;
    double tLZFgtgRPq = 533786.8548245628;
    string DPcwJFUJiNwXcE = string("kHPuFPRihZDkYDkcvwHuXQTAhmFwgoNpbBsRAVVRNkELRcDCsAfpYDanqlsIQbVbBonkvTXFPiudeCCxrimePGSkAoEfHKUzCpoLxTNtrCAXHdYvuWriemVAwIXpcIwdMlyKxhUBiSFCnBEirHUgqtyeEszxPRxrWoTdyYUfBakCbSRbeqjIjABMjyFgfmdERsjJhhfmLLSMSOLGWcnSWRQwHNxg");
    bool cZdcx = true;

    return tLZFgtgRPq;
}

bool cfbdBZvPbuRNWBYx::kHbpGqnrIyT(int rMbpOPsVHsMoZUGx, bool LFCFMwxvAI, string nSnzHccsLgo, int GgKIJ)
{
    bool ZNTXiBSeNgP = true;
    int OQscvwtecl = 211603755;
    int JXYMvydpqBun = -1235314143;

    for (int nynjsMdsWG = 1351266837; nynjsMdsWG > 0; nynjsMdsWG--) {
        continue;
    }

    for (int iJuRZQpahKJNW = 1943403766; iJuRZQpahKJNW > 0; iJuRZQpahKJNW--) {
        GgKIJ = rMbpOPsVHsMoZUGx;
        rMbpOPsVHsMoZUGx *= GgKIJ;
        GgKIJ *= GgKIJ;
        JXYMvydpqBun /= GgKIJ;
    }

    if (GgKIJ != -2092257494) {
        for (int XuMJbbpgFKUFlJ = 1689937426; XuMJbbpgFKUFlJ > 0; XuMJbbpgFKUFlJ--) {
            nSnzHccsLgo = nSnzHccsLgo;
        }
    }

    if (GgKIJ >= 211603755) {
        for (int ZyhBlBniN = 976077673; ZyhBlBniN > 0; ZyhBlBniN--) {
            nSnzHccsLgo = nSnzHccsLgo;
            rMbpOPsVHsMoZUGx -= OQscvwtecl;
            GgKIJ /= OQscvwtecl;
            OQscvwtecl *= JXYMvydpqBun;
            ZNTXiBSeNgP = LFCFMwxvAI;
        }
    }

    if (OQscvwtecl == 211603755) {
        for (int LIEmPZv = 607796728; LIEmPZv > 0; LIEmPZv--) {
            JXYMvydpqBun /= OQscvwtecl;
            ZNTXiBSeNgP = LFCFMwxvAI;
            rMbpOPsVHsMoZUGx = OQscvwtecl;
        }
    }

    return ZNTXiBSeNgP;
}

cfbdBZvPbuRNWBYx::cfbdBZvPbuRNWBYx()
{
    this->svFBmWZK(-513333.8102923303, string("TeITBaTlShqDElhWnDtIFPTIdbjliIiCaOatXGwJNFuDMjocPuHUeSRsEhsHMMuMkTXoBlguHbWDbBsHXDmFazYZMEaZVwFKQNnLrGhAFPTZrNiBgupCFSCMmPcgtcbRukcxJkLterlEGIkvHHxaJGcVzUfzjfJWolFoJxMIalVZwwYbzxvxnzVRbnhcbnWJnsKKQzWsagQuMgQsfxOYWwTKZEKwQaQsKtJQwzGHtJgBgpTiRQE"), 990726.9340291618, false, string("vAseoQFJaSCdHFcXwoKczYDvbIyorsISxjClWRpaXHPsCkxHGDBVBHtOHZnDAwlHYMBivEMPtxkixUJIZlfXcKGSmSBqNGMIFDMWMmmUzlMMeEJMIy"));
    this->BMeoUl(string("kGJkvhSrwCiZCMKnOaNYtfVzeVNYekrgCShRvQtIzXDAardEyiwWV"), string("ZVUwwomhmRbMgjTMIHwTZSnZQDtnlFsvTrruKCOfRXBrdDCPiWPBySqJuEYZptPKgFwAYgoSdiEQGunBQKvvJcwxTchNtteyonTqyrvKZcVzEEmfOkcvKoThSwodgXZMPUAUHfGyqUXbmiHhlaMOKGxmFYDiYjxZlKwOPgKwNlITnLhxRRsFYncCutAxVwBmBpuQCXyRamMMhUubWpAOPmPboAngxaHRJmlOwzCUuELAHKRSOxb"));
    this->AmOZipUdKt(false, string("tipIKTSTTlhoaLxzYJDVpHXmcLGvNClXSJGsxPeumigNZfXTdAdhHzIkgSbIzADRlbxcrQAXKKzWOpECDNfisiYuovXszBwvyUmRMZfOuOedwbgVezoDpCVDpuRirLVUswqOrvMYriDCuKBxcqpIvhbIvSIBQKZoPIghOuRB"), -1234955523, -618779932);
    this->ZZfKJp();
    this->UCtYqkrECOocct(string("jSZLEnIJNHdiJFalDuIAFoelJqUusKKbgWUenYJDphpCGDGmAddzLXUUdRNxXfDiecubDLpNaqgOFhxfiYGdqfVVKVymGoyeLawGnTSpbkIFUlhKHPkby"), string("UwmkmVCkAMsxxGwOLtLAEstCbRmBGPQDyDleCkODDZeULyUZYhSKfdMfmyJqxMFPVpcPYMaehitgdcHoOCAZxKEFNNKedaLFXqquMoUpkZyZXwPEdzMCPyNotAshelAeUGisrvFkjRhHAFontrXkwEeTcpjysPntZFR"));
    this->KGVabbbOZLFHT(-1028277.3641445475, string("nWqcMwfoBRLFHwJPaaTQTOzZgjAcKDbydrJHpKDgGAUJLWymnRzNeDCYeWcqEkXcGYpAvgiDSJhpJkutlSeJVKppJXRVxyCKMbemBwLXnrfbmtasrCByFBafzrLghWJMAhIeMVECjaHnxKaaUpLPUVZKfRdaXbTcjiMbWKIgtMqZtPjImQKtKjHXHhNlUrKgbRxIkOLxmHkYEXzMrJoteOrWCrpalTCpBiNQZOsrNfFKjLDgaGGwVvCz"));
    this->vTkSzrFaM(442415.09783804166);
    this->kHbpGqnrIyT(-2092257494, false, string("oqbbUXLLnAPIKgjScUnVaRXVSxzlCFFjFqRkayUBpxeZqCATnTbQAUOIqnRLwjaXUfWzxvWctkTszyJbKJBgisodDhTramwZtKJenDKquOojSnFyylRfRYNACNGegsswIhKVQuaJylSfEpUvCkGrEMwHdUEpjaLwWMWjOuuRBqMHjESnuLpshIGkzrlgZqUjVYYhAZSTmetDxemgSNyKBNIHSzAnCJBwFhkmkIspCTVdREUASSRTfaosJqAZZ"), 1345335445);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kdkuVsOs
{
public:
    double QUlfFA;
    double uOHGP;

    kdkuVsOs();
    double GGexBme(bool PKDfLQgsdZQB);
    string ARQwhxNzfdmNN(int BQoxHFtiU, int XVgAzlTsLOaHDXUz, double GzCWBnqjZ, int ChTnjR);
    string ORCIkom(double jblnabHLev, double fVqBPfGeXPPt, bool POMiONMJRBKKt, double oELDqIRrxvSDTwp, bool JeUiSgPIroOQRRrp);
    void qjxbGMpCAAmH(string MMAnONDfWv, double tSohYUJBtdF);
    void PNQDxNxQDaAkDUfB(int mExdzRVScgdtCAVB, bool msOhQSwUeCue);
    int IzfnifPZSFO(double kfREoo, bool yOviw, bool KcZLZAUuwumawTA, double qGVPXXSpuCLA, bool eeTPdv);
protected:
    double jdBOiF;
    int gVhuEHNmCL;
    bool YmZyxhhyNi;

    double GkTJaBgCxvGb(int arHfLyfGdFCn);
    string EMEPI(double xorYIhCYhupnr, string PeZWSEtIK, int HvzsGv);
    double QVtyqBYjfC(double gaMkLpLYEYrl, double ULGHJhn, int nbaRoaxJoDHip);
    bool rWhNVsR();
    int ZRMooYQC(bool ZONrlUxgWWc, string iNUPcIlTHAJdw);
    int yKqsjUEh(string jNWqQfHx, bool bhMXbdd);
    bool UBneGRLDvULj(double qHYdxsnCPGLRsm, string FuXdTFatrqLjotv, int aVXWdBzhbibXv);
private:
    string aLlpWyIEaUEYSS;

    void VWgIphaosJV(int PUHJkDQR);
    int bQKvDZSXQDE(double bzPAgbeutDJgij, int BMwiHnFOxJDPcOkm);
    string vwgizceTFhh(double EbxhsTwacYInp, bool HYISSAY, bool fsQFpORA, string RgRrYxRoy);
};

double kdkuVsOs::GGexBme(bool PKDfLQgsdZQB)
{
    double dAUFqB = -211691.2556346063;
    int iZFbWkyb = 1301598756;
    int TqPbKIJ = -515564940;
    double lxRqB = 25862.05033171555;
    bool dCgvWS = false;
    double VfCpryBjSG = -871417.5450949908;
    int hYVevTEILIcbjsN = -335896677;

    for (int vNfMq = 2068845350; vNfMq > 0; vNfMq--) {
        TqPbKIJ /= TqPbKIJ;
        hYVevTEILIcbjsN += hYVevTEILIcbjsN;
    }

    if (dAUFqB < -211691.2556346063) {
        for (int kQiamyiRNxp = 1086203407; kQiamyiRNxp > 0; kQiamyiRNxp--) {
            PKDfLQgsdZQB = PKDfLQgsdZQB;
            hYVevTEILIcbjsN /= TqPbKIJ;
        }
    }

    for (int fsVYCsyAMG = 1450589584; fsVYCsyAMG > 0; fsVYCsyAMG--) {
        hYVevTEILIcbjsN -= iZFbWkyb;
        hYVevTEILIcbjsN /= hYVevTEILIcbjsN;
    }

    if (hYVevTEILIcbjsN >= -335896677) {
        for (int dcJuJxRDzaS = 26768653; dcJuJxRDzaS > 0; dcJuJxRDzaS--) {
            lxRqB -= dAUFqB;
        }
    }

    if (dAUFqB >= 25862.05033171555) {
        for (int IrDidEGEp = 1544516831; IrDidEGEp > 0; IrDidEGEp--) {
            iZFbWkyb *= TqPbKIJ;
            lxRqB -= lxRqB;
        }
    }

    return VfCpryBjSG;
}

string kdkuVsOs::ARQwhxNzfdmNN(int BQoxHFtiU, int XVgAzlTsLOaHDXUz, double GzCWBnqjZ, int ChTnjR)
{
    double vWEgDzeEHqS = -657965.612608684;
    int hhzIAKBH = 1848514617;
    int cdFQH = -392031793;
    string esZKn = string("aWsnQFbLfbSMxzasolzeJXkJqgBwUENakIChVGsevaSdSULXUrIkfhDbGOCEjyetwqUdstxdiZCLhOVReLXjZXXMOqzVJUXRDRKWbtcbNhyTcAFYBVdjFMAUPluBDoqbdzIxdggSYVlnXRbVfTZUvRSVs");

    for (int giXvrGIWIrLB = 1940602501; giXvrGIWIrLB > 0; giXvrGIWIrLB--) {
        BQoxHFtiU *= hhzIAKBH;
    }

    return esZKn;
}

string kdkuVsOs::ORCIkom(double jblnabHLev, double fVqBPfGeXPPt, bool POMiONMJRBKKt, double oELDqIRrxvSDTwp, bool JeUiSgPIroOQRRrp)
{
    int XYqWBFUG = -1348341669;
    double rSqnjAd = 473911.4159122652;
    string zuWPKDOemEGzk = string("XWrsOMMrUzVgKnxNxWHAoMZKtgLxzLSTSBZYxZKgqknERzPGCDSqHflnSjVnuXihDVfRlVArIFqJeEkJIIPrXpHwVdREjYQclqFVMAuTtyYyOApbjqyysIglESAQIrkMulKjbzWzOUKAnKoFWcqmfQuBigpaUMRAIDsWBnEIJjvTNxhpINNdsuYjwEmCHvacGcdkCbFAXzZWgtAtbmyhLrlsQAMJsyL");

    for (int bHqYwgw = 1157548027; bHqYwgw > 0; bHqYwgw--) {
        jblnabHLev /= jblnabHLev;
    }

    for (int DSUbRJYULANFRrn = 1031127477; DSUbRJYULANFRrn > 0; DSUbRJYULANFRrn--) {
        zuWPKDOemEGzk = zuWPKDOemEGzk;
        POMiONMJRBKKt = POMiONMJRBKKt;
    }

    if (oELDqIRrxvSDTwp != 267968.74371986516) {
        for (int qNTpzZirPN = 1750973741; qNTpzZirPN > 0; qNTpzZirPN--) {
            fVqBPfGeXPPt /= fVqBPfGeXPPt;
            jblnabHLev /= jblnabHLev;
            jblnabHLev /= rSqnjAd;
            oELDqIRrxvSDTwp *= rSqnjAd;
        }
    }

    if (rSqnjAd <= 267968.74371986516) {
        for (int eQcgsxPdXG = 1148592134; eQcgsxPdXG > 0; eQcgsxPdXG--) {
            rSqnjAd /= rSqnjAd;
        }
    }

    for (int QQDfIAkjYw = 1556459727; QQDfIAkjYw > 0; QQDfIAkjYw--) {
        POMiONMJRBKKt = POMiONMJRBKKt;
        XYqWBFUG /= XYqWBFUG;
        fVqBPfGeXPPt *= oELDqIRrxvSDTwp;
        jblnabHLev += jblnabHLev;
        JeUiSgPIroOQRRrp = ! POMiONMJRBKKt;
    }

    return zuWPKDOemEGzk;
}

void kdkuVsOs::qjxbGMpCAAmH(string MMAnONDfWv, double tSohYUJBtdF)
{
    bool TunwMkilEp = true;
    string jGTpaUvh = string("ywTWzRHTUKUBQcQPmRUahIYpYAoMtezouidLXzvphDAdPPrsauYLkyofyQtrIAkDjupujvgtGeViQffHEqgbFhsGpMFUufUdcFwS");
    bool QglAHpHFicbBOPQ = false;
    double EiieDTwWPgV = -550053.1838451301;

    for (int yDKTlALmVZhHSO = 893674152; yDKTlALmVZhHSO > 0; yDKTlALmVZhHSO--) {
        MMAnONDfWv += MMAnONDfWv;
    }

    for (int kfbiTBY = 91580282; kfbiTBY > 0; kfbiTBY--) {
        jGTpaUvh += MMAnONDfWv;
    }

    if (jGTpaUvh != string("ywTWzRHTUKUBQcQPmRUahIYpYAoMtezouidLXzvphDAdPPrsauYLkyofyQtrIAkDjupujvgtGeViQffHEqgbFhsGpMFUufUdcFwS")) {
        for (int kiQVtY = 1207331307; kiQVtY > 0; kiQVtY--) {
            TunwMkilEp = QglAHpHFicbBOPQ;
        }
    }

    for (int WniekQBI = 2027003950; WniekQBI > 0; WniekQBI--) {
        jGTpaUvh = MMAnONDfWv;
        TunwMkilEp = ! TunwMkilEp;
        EiieDTwWPgV += EiieDTwWPgV;
    }
}

void kdkuVsOs::PNQDxNxQDaAkDUfB(int mExdzRVScgdtCAVB, bool msOhQSwUeCue)
{
    string qmWADMdtNVtyI = string("zxjUtSDvqJDSQLUJlixozLGCmhkVoumCvHixQfCgReQBXUeRdtExvTCMyHdQwdAksQQivsmZnDnwHPvEpDmEHPQgStHVTaLJkwYIbZfojIDnhBnpVOzBhZkJbNxBoQQbXRoaAVwbtROisjEizkFOSieSctGlkbcTLZQpISRcJWjyNRRkEOlKsEKWgLYGDEbtZrNRzcu");
    string ITOgSUYFQQRTIZ = string("dzvBRpeKYCmgkmcgdsNIzfXfuKBNLjqUgMcdqpqKELacmVNVrIflnkxhrnRaVUYksTSzxEGhImEPGXwgWiafwkcmiTHxcTkhwlkZYANgqeTUczvBgYoIGRmZzAnMWitMAxZIDTHVixGXpqHtkghbWbx");
    int TCcyqielF = -39103094;
    string vnFIWXWpZfFf = string("ekVOOFYypwbYGJjfLgBllsVvDmgsuan");
    double WQNrLJtbEAyVfO = -293061.9529788532;
    int GdBlJ = 837681602;
    int NsmptmxOsHKbOv = -244992763;
    bool FTpqGxSJmDOm = true;
    string iFlagCxAdSXBWfX = string("wEJkiLGtBkHRdfcfzyZAqGLAOaTrieJljcTcuGzLMSenRLBtQlEubdbYcntckEFjQ");
    double XJyEZCjvdIvTc = -858806.2843600562;

    if (NsmptmxOsHKbOv <= -244992763) {
        for (int LChFgxTtCXt = 826819695; LChFgxTtCXt > 0; LChFgxTtCXt--) {
            ITOgSUYFQQRTIZ = ITOgSUYFQQRTIZ;
            NsmptmxOsHKbOv *= GdBlJ;
        }
    }

    for (int NMeRUHwJFQ = 1174580160; NMeRUHwJFQ > 0; NMeRUHwJFQ--) {
        TCcyqielF += NsmptmxOsHKbOv;
    }
}

int kdkuVsOs::IzfnifPZSFO(double kfREoo, bool yOviw, bool KcZLZAUuwumawTA, double qGVPXXSpuCLA, bool eeTPdv)
{
    bool IkdtsoO = true;
    double rjBYE = 478355.43877133407;

    for (int lbgqtgr = 238167776; lbgqtgr > 0; lbgqtgr--) {
        continue;
    }

    return -398493463;
}

double kdkuVsOs::GkTJaBgCxvGb(int arHfLyfGdFCn)
{
    int jXYpynvJk = 429161128;
    bool NCWgYHaqjPxsDvoO = true;
    string aHVlXYI = string("mvZeoaVbjiyJjTFdmKEtTGgmxBnNATCOYdnvSRlQQUXtSGbyrKVjZVDgnCvDFBHpIBgTHxXgdsTfBoHPrlfFGVSvMetlRBMsGVdHRNCiBHsQoStOMwQCvTZmKKfDIimOCXmvzuxxgQETSOVNbLGblfoHOwkfbudJoMSuqXIjxRdidlCpiQyxND");
    double JKwzXlJQpRFrlE = -895509.1057544971;
    string aBpGDgnkJprMuJ = string("ggwpzmrxEwCggUCNrsqIHVAUYZrpGruHGLeQCmKNWkLbqIITLrUXOzfRSrlTwIkYKDzFeBnQNsEnHrdipfsUYlXikdYAYeNFUXaQSllqeDzkCaJbRQdTtkGqdQjqbkvzrJ");
    double krIMisgbvRZcfNs = 716383.5366894763;
    string EYbPSKFL = string("AoqdLqjoOZUhawnGMNhagibrTvFyZtBaGLdzPPdtiZiLtxhABRxRkwigCqOmfbQXCqSaUxptjhBliRKyBWoAKbBbcIEgbyKZIXZFCnXHNgpfekpmlhJtwHbDmUqINTJoEjQllWbAihgSUsXhsCFItFGWrhnUIPaWUsgDJuN");
    int VVCvCoF = -1666095695;
    int pkaLlrSWw = -327871194;
    double FJZfInH = -374055.264607346;

    for (int aJrxlravVIJoq = 1419442260; aJrxlravVIJoq > 0; aJrxlravVIJoq--) {
        aBpGDgnkJprMuJ = EYbPSKFL;
    }

    for (int RqPNMIzECV = 1621297805; RqPNMIzECV > 0; RqPNMIzECV--) {
        arHfLyfGdFCn /= arHfLyfGdFCn;
    }

    if (EYbPSKFL >= string("mvZeoaVbjiyJjTFdmKEtTGgmxBnNATCOYdnvSRlQQUXtSGbyrKVjZVDgnCvDFBHpIBgTHxXgdsTfBoHPrlfFGVSvMetlRBMsGVdHRNCiBHsQoStOMwQCvTZmKKfDIimOCXmvzuxxgQETSOVNbLGblfoHOwkfbudJoMSuqXIjxRdidlCpiQyxND")) {
        for (int rRfcpnFmqIPe = 2000164152; rRfcpnFmqIPe > 0; rRfcpnFmqIPe--) {
            arHfLyfGdFCn = VVCvCoF;
            krIMisgbvRZcfNs *= FJZfInH;
        }
    }

    return FJZfInH;
}

string kdkuVsOs::EMEPI(double xorYIhCYhupnr, string PeZWSEtIK, int HvzsGv)
{
    string CvQoDUzHmKV = string("jDSzoEvtpCekEIiTfVrahicKcqlUaIhuxpBRZGHNgQolljCwaJuqgMqOhxvuffpGrEEsMieeCGWySABiQXyHXBPeXfqmIXolczPJQEORhwxgmwbxXICewmbiwJFyzkCHqiuJGG");
    bool ZJBnKCZ = true;
    string SUaDhDjQZp = string("ebEIKNqoHfQqGPMdyEyRfQVUbUTYMzcPWUGcPtruqGtUjNndenuqdWTaLgPvFoFugxsYzcaXDWIgWWLgAeMMCsViBOToBWCAFcPqyrlxmBybShotlGKUSSYkporKNnAOXOWggpnhfgXWlWltwBpAOozrYhHoTIgHbXwuHOqBCUDeaHuIjgfeKwjXWcCkmltnaLAwbJEieQMShxHmzMmDESISajDgH");
    string IAYwDBVb = string("MZyrzpoIeXXuZvYbtCY");
    bool OVwDRcykLAOksX = false;
    int WkQSyXrCgtCjb = 1602179836;

    for (int LRRlteuusRdwcAoi = 1186121583; LRRlteuusRdwcAoi > 0; LRRlteuusRdwcAoi--) {
        continue;
    }

    return IAYwDBVb;
}

double kdkuVsOs::QVtyqBYjfC(double gaMkLpLYEYrl, double ULGHJhn, int nbaRoaxJoDHip)
{
    string XxmAjYikrnkVKK = string("kpeSoJCxxMkNeVutjZGjKglRnmigDeKvXttHJBPZHQCdwBAnGlmOAntHWqCsUZbmFuiOIRCwMyiRdHecNNRnVcQJoZOqCwOXgmRSIMaZOQQhwpYQbJAsgHUAoywRfAOXjeehRxtRpDhXSurBtdfdXlqnRkUSeelTfeqVhYGwSJNLHamwwlPMzrjkrkxJromgLqldwVJdkIZGEBErrTVklkHxjCH");

    if (gaMkLpLYEYrl < 169541.90307065123) {
        for (int IPyNhRGGTtvGOSof = 1115338930; IPyNhRGGTtvGOSof > 0; IPyNhRGGTtvGOSof--) {
            gaMkLpLYEYrl *= gaMkLpLYEYrl;
        }
    }

    if (gaMkLpLYEYrl != 321467.5763323139) {
        for (int YVirHukvo = 1275051582; YVirHukvo > 0; YVirHukvo--) {
            continue;
        }
    }

    return ULGHJhn;
}

bool kdkuVsOs::rWhNVsR()
{
    bool bFTawbxzLgawetov = true;
    int UHClHZw = 647256246;
    double QGSetpY = -787772.6785134132;

    for (int hcEqIdtedYjX = 277809189; hcEqIdtedYjX > 0; hcEqIdtedYjX--) {
        UHClHZw /= UHClHZw;
        bFTawbxzLgawetov = ! bFTawbxzLgawetov;
    }

    for (int CmPURtOC = 1017699233; CmPURtOC > 0; CmPURtOC--) {
        continue;
    }

    for (int hjyShVo = 1960655740; hjyShVo > 0; hjyShVo--) {
        QGSetpY *= QGSetpY;
    }

    if (QGSetpY != -787772.6785134132) {
        for (int wthmNkVtslWtPyyU = 1287766900; wthmNkVtslWtPyyU > 0; wthmNkVtslWtPyyU--) {
            bFTawbxzLgawetov = ! bFTawbxzLgawetov;
            QGSetpY /= QGSetpY;
            UHClHZw = UHClHZw;
        }
    }

    return bFTawbxzLgawetov;
}

int kdkuVsOs::ZRMooYQC(bool ZONrlUxgWWc, string iNUPcIlTHAJdw)
{
    bool bKmGKUqhfpmtxNqO = true;
    bool RSaFjxJVu = true;
    double TqIqyOZT = 441950.67128828616;
    int weQbaVImUgOiiHxQ = -1217705225;
    string OTyEvBb = string("TjcupskWAsNJZJhKrvdhfRZsMNYjSVYAGCTmUKGevnJKdkobcCXlaMEBeOZAuBSvWbrTexmyDzbEbktP");
    double yXCxBLYoDVBpjAFd = -1025877.8486240535;
    int uImRyVXwC = -1765836100;
    bool zhMXRUZUnXzG = true;

    for (int YTOUI = 375599634; YTOUI > 0; YTOUI--) {
        zhMXRUZUnXzG = ! bKmGKUqhfpmtxNqO;
    }

    if (TqIqyOZT >= -1025877.8486240535) {
        for (int mwiKNQtyPSXE = 75112989; mwiKNQtyPSXE > 0; mwiKNQtyPSXE--) {
            continue;
        }
    }

    return uImRyVXwC;
}

int kdkuVsOs::yKqsjUEh(string jNWqQfHx, bool bhMXbdd)
{
    double MRfMtHacEUrVzN = 96436.72851839373;
    double NWgmdfaqablunS = 457108.2600294305;

    for (int uNMFMrcUFxnSW = 258359897; uNMFMrcUFxnSW > 0; uNMFMrcUFxnSW--) {
        MRfMtHacEUrVzN += NWgmdfaqablunS;
        NWgmdfaqablunS += NWgmdfaqablunS;
        MRfMtHacEUrVzN += MRfMtHacEUrVzN;
        bhMXbdd = ! bhMXbdd;
    }

    for (int XMnwEpRNWnT = 1493901091; XMnwEpRNWnT > 0; XMnwEpRNWnT--) {
        continue;
    }

    if (bhMXbdd != false) {
        for (int bciLjxqShyPOT = 868747762; bciLjxqShyPOT > 0; bciLjxqShyPOT--) {
            MRfMtHacEUrVzN *= MRfMtHacEUrVzN;
            MRfMtHacEUrVzN /= NWgmdfaqablunS;
            NWgmdfaqablunS *= NWgmdfaqablunS;
            MRfMtHacEUrVzN = NWgmdfaqablunS;
        }
    }

    for (int ZhshuN = 946385669; ZhshuN > 0; ZhshuN--) {
        bhMXbdd = bhMXbdd;
        MRfMtHacEUrVzN /= MRfMtHacEUrVzN;
    }

    for (int iDXqHBoWJG = 732540993; iDXqHBoWJG > 0; iDXqHBoWJG--) {
        jNWqQfHx = jNWqQfHx;
    }

    if (jNWqQfHx != string("tJxOHKjIRegpauzIXXkQqqDnICwTxxPOhIOPaStyRwidUDYUrAgLUjpUdKyNCWrBOUxHyxYciKhbiPJzQesflcBmasgpRozsn")) {
        for (int NcFWgzzKzBd = 547207759; NcFWgzzKzBd > 0; NcFWgzzKzBd--) {
            MRfMtHacEUrVzN /= NWgmdfaqablunS;
            jNWqQfHx = jNWqQfHx;
            bhMXbdd = bhMXbdd;
        }
    }

    if (bhMXbdd == false) {
        for (int notiCSXYpqHYLV = 622565427; notiCSXYpqHYLV > 0; notiCSXYpqHYLV--) {
            MRfMtHacEUrVzN = MRfMtHacEUrVzN;
            NWgmdfaqablunS /= MRfMtHacEUrVzN;
            MRfMtHacEUrVzN /= NWgmdfaqablunS;
        }
    }

    return -1603797161;
}

bool kdkuVsOs::UBneGRLDvULj(double qHYdxsnCPGLRsm, string FuXdTFatrqLjotv, int aVXWdBzhbibXv)
{
    string fMDHNOIJ = string("LCygYIZjyOSHDmZsrZTRLGcxGVrZUCNSJRlEYaQKrIMvBBRsdFOEaOkvuHeTJGjyUDzrpbnCVVLoKnaCSCtavJGs");
    double kscecFDjGZ = 1001748.2426410309;
    bool KemDbtB = true;
    string WWkmNIDBPHoy = string("SMAfCdgjtKPJxRzdkceDEvyArfkrntdHDUFPZBMPdSJcLAjxseKYBYPkUrhPMhdJlhDCfJyJbzyeYYsZGghgcsfemuUFtVHhoVYNHkIQPwSTDGtsLwMlLRGhwtFdTgBfoVqmPIHdycigZaTgVUEMNPVHCzRhoEYkRIMnhyMekIgEFxCeqxHmpdrYsHgifnjKMxmtMHGsSvVoANvmdgULgSVPAhNiVCLFVHVJwJSEJMTRdTlhLhuygcfRK");
    bool ewRhMnKhdW = false;
    double SKKgKufrzOYAgrf = -224475.79643961476;
    bool RuUHKQ = true;

    for (int HmWshzdzBLW = 1987740861; HmWshzdzBLW > 0; HmWshzdzBLW--) {
        KemDbtB = ewRhMnKhdW;
        fMDHNOIJ = FuXdTFatrqLjotv;
    }

    return RuUHKQ;
}

void kdkuVsOs::VWgIphaosJV(int PUHJkDQR)
{
    string MHbQmn = string("dfaSlwZfbjLFaMSxxllDfWjDWmzXUcyHekPBgbNdwYoFCDZxMeZOKxEcJWClvJkjSjoQHwrBgkGjYQPxPLxmzPdcaUmcClQBJWaLarvXKYbboFTRUHqUQTURBtKmSjpmxMoZxkzCNdZZEgZEvabwdzAqpcQsrjIehezzNmtghnHczrycisLECeSWX");
    bool cbptjqmYy = true;
    bool qojODlWjmqlP = false;

    if (cbptjqmYy == true) {
        for (int iALcn = 1916152643; iALcn > 0; iALcn--) {
            continue;
        }
    }
}

int kdkuVsOs::bQKvDZSXQDE(double bzPAgbeutDJgij, int BMwiHnFOxJDPcOkm)
{
    double oTfTae = 941520.6060629856;
    bool qJAVTb = false;
    double vGoqLowqcTLn = 286918.5815877225;
    string rIvfSk = string("daIDmNMhmlQwmhnbWIhJDBrOaYDsFmbaFhgsqsjjILQAGcB");
    double KvVxfMJdKfbAg = 215375.57539354317;
    int MyBfDzbfdn = -997048086;
    string sXqdv = string("xWnMTMAFJuUiBbZSbThCgqHMEEBLyzhFgrAaRlkzSwAnrHsQOigzDLbrnYfPQfelggvkZATaVJhtsbuqmWKNKJOOUPfhOMHOBcgByaMlKNibhijRInvJpiCSLJFYCoplUicSNBliklRPcEVphfcwcNIMQZFCMPeNGLMWINPINiAhTjcNcGTyKqFWFDnxHaFYyZThxaB");
    int xYPlbocTIcCtG = -763087770;

    for (int oqzQOZlevw = 2100434821; oqzQOZlevw > 0; oqzQOZlevw--) {
        MyBfDzbfdn *= xYPlbocTIcCtG;
        oTfTae -= bzPAgbeutDJgij;
    }

    for (int gddFhtBFrttFw = 245816531; gddFhtBFrttFw > 0; gddFhtBFrttFw--) {
        continue;
    }

    for (int PKYeaqJ = 1007905574; PKYeaqJ > 0; PKYeaqJ--) {
        rIvfSk = rIvfSk;
    }

    if (oTfTae <= 286918.5815877225) {
        for (int YPhueuvxf = 1254251613; YPhueuvxf > 0; YPhueuvxf--) {
            continue;
        }
    }

    return xYPlbocTIcCtG;
}

string kdkuVsOs::vwgizceTFhh(double EbxhsTwacYInp, bool HYISSAY, bool fsQFpORA, string RgRrYxRoy)
{
    string iUfexdBSBTt = string("UnPZdoMiVzrpPpvwLwtJRXkHmBoMpaexSWoIguaDVazdJXnaZKPGNdpyPmaJqBAyPEqEArkmKtAzVZbPhIjKkgNItRJFdK");
    double FaeLflBdsaL = -559896.3217102896;
    int lbLfUFqdG = -411261793;
    string EbmzZLqinT = string("fJzWPflpFXJIfbpyrhmmTogKsIElGyEHnbgJnJIFfVADWhAfqskSyppPLSJExRKCovyoqZhnpgAaJZHHsDCxwstZkxOUhDzAIruTtPMTqfjPdekhPjIidpxZNH");

    if (RgRrYxRoy < string("fJzWPflpFXJIfbpyrhmmTogKsIElGyEHnbgJnJIFfVADWhAfqskSyppPLSJExRKCovyoqZhnpgAaJZHHsDCxwstZkxOUhDzAIruTtPMTqfjPdekhPjIidpxZNH")) {
        for (int RhMqn = 2009577750; RhMqn > 0; RhMqn--) {
            EbxhsTwacYInp *= FaeLflBdsaL;
            EbmzZLqinT += iUfexdBSBTt;
            iUfexdBSBTt += RgRrYxRoy;
        }
    }

    if (RgRrYxRoy == string("fJzWPflpFXJIfbpyrhmmTogKsIElGyEHnbgJnJIFfVADWhAfqskSyppPLSJExRKCovyoqZhnpgAaJZHHsDCxwstZkxOUhDzAIruTtPMTqfjPdekhPjIidpxZNH")) {
        for (int lvhCR = 1738482777; lvhCR > 0; lvhCR--) {
            continue;
        }
    }

    for (int xBkon = 1946429103; xBkon > 0; xBkon--) {
        continue;
    }

    return EbmzZLqinT;
}

kdkuVsOs::kdkuVsOs()
{
    this->GGexBme(true);
    this->ARQwhxNzfdmNN(-324617137, 616392747, 399635.42039910215, 1442547260);
    this->ORCIkom(267968.74371986516, -600389.1940285553, true, -824024.5620908372, true);
    this->qjxbGMpCAAmH(string("jBcAmjhgfiIYrKgiiInStncDPq"), 552825.9559863376);
    this->PNQDxNxQDaAkDUfB(1252944013, true);
    this->IzfnifPZSFO(-616984.0459133002, false, false, -95884.95450422009, false);
    this->GkTJaBgCxvGb(60612374);
    this->EMEPI(-16537.795650355503, string("lioVeXbwMBrjOIUQsAbuVrBzgVIPaVNIhrFErYSZNrNAvXOsKtBDDD"), -1913590481);
    this->QVtyqBYjfC(321467.5763323139, 169541.90307065123, 1745259410);
    this->rWhNVsR();
    this->ZRMooYQC(false, string("jzgnglFetnYgfVXePYolpFwfsDUceDQoBihoDEuUbNbTHNoYdlhLyRvHzYPzNnJWnvSbWgAGGSxAxtUUSMCksbeuIFgulsxZXOLJKXtiADHaKAjPZpahFqgIGaAkfkXUMBJUvuuJHDgWeQEcuMyFoJMLMznEgbXHgT"));
    this->yKqsjUEh(string("tJxOHKjIRegpauzIXXkQqqDnICwTxxPOhIOPaStyRwidUDYUrAgLUjpUdKyNCWrBOUxHyxYciKhbiPJzQesflcBmasgpRozsn"), false);
    this->UBneGRLDvULj(301622.41925485304, string("ASEmtntQIROEcLzzEBGuIllSDiuqLoyiwEeiIrpgxZqoFYpHmYNczUVSvsgIaDaPJPwsxwvDwvgzujzsPKOohuVWQFbActqKGQeDKLoDTegndshfbbPGiQkXnKmPjMndlukQmiclSOfhIYbVEwoNSDxNpNfJYZYiDaKZINsWjoCMFZaUzbd"), 1333939121);
    this->VWgIphaosJV(1107824803);
    this->bQKvDZSXQDE(807652.8939552333, -932544897);
    this->vwgizceTFhh(714877.1664092375, false, true, string("wbSEwGGrKjYRLLkKUMmccyZfKosMVkbdtCwwmmNmSEByshiCWIrabfGnujMVfmfiKPKlKddufRIJahqvuftREjKlVrDqVhXIZgRcpEqfCvCQzwUKzfrLBoFXetaVoqcotELgnxTSJvCGLJISbLYDZtVlPfXDzkTcMNknyfFtxELvHCsGXuxLPutZXuHEQbeiXIdegYNVEFEuZRzYDuWVF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MlmQtjfTS
{
public:
    int cVOwCgoNNGOalDu;
    int buysGgvNhhWl;
    int SKFdpm;
    string mqFBmpTKrmTw;

    MlmQtjfTS();
    bool ZuTtH(bool GALVLLBXapERgy, double WxdixsCFN);
    string rKczgoKYkoTXXLD(int YsUzFLXSQ);
    bool XlGhAw(bool NNxmeOKGJNLJ);
    bool VTtqOIkH(string UpXKZcMI, double jarnRTFLza);
    bool BDhLKnLruJV(int WvRLWXQwCjIfxA, bool KmJoyeFVkQKDoh, bool bEhYu);
    double ibsUjVFlrYY(string MrFDDuU, bool uLQQHfYFrztsF, string MlUKUjaH, bool IOHUfhEumKUV);
protected:
    int sDcpO;

    bool ZwxMexdwYejZAbj();
    double JgLacGtKwionkCg(bool mcnmdTbTKbjmA, int cqPsjxv, string emVvGouW, int CtvDXC);
    void vfDUa(int VsanPyXoQV, string iiAKVUyl, bool yXTjwezX, string GGfkkFyXDeH);
    double tDIpC(string cwPopqcsbd, string JnaJAFlTULC);
    void yzQFJaCRDrEdYPEX(int rwOeZreeWcHChoo, int FNLRHT, double pFSTiloATOJS, string ZLOjWQsGGm, string xHJALHSrzBUbz);
private:
    double vnNAklbBFfclPBso;
    int bBUDblU;
    bool pWykCLYuEkkdCb;
    double CJDsTsDJqCGue;

    bool BGnzZXsi(int DlVWQLlvtnGa);
    int BUTRz(int QImUCzNyovCLWjd, string SyJFKT, int EpuJQZcAmqlVU);
    string SipUhRRlByzjQ();
    double iksYrroygjtiEGj(string JFnAkZlqOcH, string rsZbZVCcOLnOKKw, bool IvoWWqrlAEX, string FdePuOPrfDHOLl, int VrtcznPdkMu);
    double vlfCw(double AyGbFyntid);
    bool eahAMDmUrOfULs(int BMGFVR);
    void anlELJVZY(int rDkMoVlCvULkEPy, string lmLiCGSELk);
    int kdTjOylBmw(string dYQaKvEU, double VIXANZK);
};

bool MlmQtjfTS::ZuTtH(bool GALVLLBXapERgy, double WxdixsCFN)
{
    int DRYUNjHXpv = 2017937853;
    double VLJqNU = 755718.3467658032;
    bool POTznnE = true;
    bool yXzUhJvmxi = true;
    int MpWUmpDT = -745047744;
    bool oXgrfHm = false;
    string MBMqmJaw = string("XqexletfbegXJDAujyxbTtPYOMGZbWIlEjXDPcuRooEcfrjpFymCfsvuuBGirJvviBizoCvpuGYDkmoOoYNBWMSCatHREHNTAbYsfIDQjuDVYmJEQmfHGMEkMrwFToewHuvnlNAqKWahLUTxSVwlJAPTnjYqBgXmasMWWTEJRgkjBhOxEAJYrigl");

    for (int cOFgcHJNE = 381058398; cOFgcHJNE > 0; cOFgcHJNE--) {
        GALVLLBXapERgy = POTznnE;
    }

    for (int xYigMw = 1509979035; xYigMw > 0; xYigMw--) {
        oXgrfHm = oXgrfHm;
    }

    for (int NMsxQYgkvheotbJf = 1257595359; NMsxQYgkvheotbJf > 0; NMsxQYgkvheotbJf--) {
        yXzUhJvmxi = POTznnE;
        oXgrfHm = oXgrfHm;
    }

    for (int vxKpB = 1217382310; vxKpB > 0; vxKpB--) {
        oXgrfHm = ! yXzUhJvmxi;
    }

    return oXgrfHm;
}

string MlmQtjfTS::rKczgoKYkoTXXLD(int YsUzFLXSQ)
{
    bool rDRcGFeob = false;
    double nFhwshHMXAdw = 475330.0296750635;
    bool JBhUtLUKukyr = true;
    string UKTQU = string("VJTEQjcJOzhzkHDZYMTeeKOysEXrupeldBeNXMNlKDPXkGXTGCMMzKQLkcNrskiuEJYoijrFyhQyBWDVJSSIvsYkRxvESO");

    if (rDRcGFeob != true) {
        for (int WQmxQpmFN = 819898530; WQmxQpmFN > 0; WQmxQpmFN--) {
            JBhUtLUKukyr = JBhUtLUKukyr;
            JBhUtLUKukyr = ! JBhUtLUKukyr;
            rDRcGFeob = rDRcGFeob;
            YsUzFLXSQ -= YsUzFLXSQ;
        }
    }

    return UKTQU;
}

bool MlmQtjfTS::XlGhAw(bool NNxmeOKGJNLJ)
{
    double CGxJQty = -267449.2314719969;
    string TVXOPZyAX = string("iCAkupixjsVpKXtnpOQMwUNmElNRHVIrykilZqAFMGZkHPABQGYXvjPxyJFkbaoUHlYxSOFaLpqznqgdUvI");
    bool RJyCs = true;
    double olUvh = 226416.5482024655;
    double vTZmlUhwCp = 180402.59174876453;
    int MCGDALJI = -1012481344;
    int EqFFfDOv = 1827757457;
    double bTgTGweAoDEY = 191964.36918318973;
    int BBpaopWUVFEIPOL = -813802857;

    for (int OvddebfLmqUrsgtR = 550819720; OvddebfLmqUrsgtR > 0; OvddebfLmqUrsgtR--) {
        RJyCs = ! NNxmeOKGJNLJ;
    }

    return RJyCs;
}

bool MlmQtjfTS::VTtqOIkH(string UpXKZcMI, double jarnRTFLza)
{
    int kuIyFSacLCLSsv = 78411144;
    bool TogZOpqftuCwxphW = false;
    double hvFZqYeiLPfjUWVp = 954979.8896175004;
    int piWAwthvHQwSWmm = -535687768;
    string sDsNOzua = string("LJxkdDWTvxqcGsNoleqHtDTEucoEtWFqskRsaKZIEwqwDvYVWUoDqBVEbtRfRotlpjrxjquwClUyhWiFAQJnsxzkJTbVfwEXDJeiSdpdvOaeSrosKGFvQONuypsEWIuJHUWQTCHHSIsjjsZm");
    bool VISxuNKIHJ = false;
    int kCXnSn = 1895636139;

    for (int SKxRnNIqBVUfgGg = 488146365; SKxRnNIqBVUfgGg > 0; SKxRnNIqBVUfgGg--) {
        piWAwthvHQwSWmm -= kuIyFSacLCLSsv;
        kuIyFSacLCLSsv = kCXnSn;
    }

    return VISxuNKIHJ;
}

bool MlmQtjfTS::BDhLKnLruJV(int WvRLWXQwCjIfxA, bool KmJoyeFVkQKDoh, bool bEhYu)
{
    bool XqvMAg = false;
    string KAilDbOktzqYr = string("wKMApONSjbUpTWKKRrqrqGiSoxhaKugzZJKkghxoAwodYMHteFrMZWIlTPyn");
    int rJeEggAbkDBIBi = -1344792601;
    bool wBmXBBNPWWMTyKm = true;
    string ZJVlYyONppZjtNV = string("BwzIVCyPGQslFPplMnQOufUMHmSlqInotBtymLTCKRMkcxNLjRGpjNiOFmJlXgPubnvYpxcGmGpZLcJbvOIOzmVCDzsEczwJaQCouEZdoDPRIZLhGFKEAZnuWkFHYVtjRbPdLLMVFYHSbBLFdKQ");
    string KuEWIu = string("eTVCypUwATdVlSONUUYIxqYCMnKEVfoLWe");
    double WhgAsVjHh = -357196.33399653144;
    bool xdkmpSoukzB = false;
    double mBJbXrhgf = 1034890.8724793954;

    for (int gOoXKlhtGBoGqlJz = 2091780693; gOoXKlhtGBoGqlJz > 0; gOoXKlhtGBoGqlJz--) {
        ZJVlYyONppZjtNV = KAilDbOktzqYr;
        ZJVlYyONppZjtNV = ZJVlYyONppZjtNV;
        KmJoyeFVkQKDoh = xdkmpSoukzB;
        wBmXBBNPWWMTyKm = ! bEhYu;
    }

    return xdkmpSoukzB;
}

double MlmQtjfTS::ibsUjVFlrYY(string MrFDDuU, bool uLQQHfYFrztsF, string MlUKUjaH, bool IOHUfhEumKUV)
{
    double rATXumSmRVENf = -968244.2992190408;

    if (MrFDDuU <= string("JdsANHWiECGaJJBoZkHwdaYtdzgTxDRpuDTbOFeWethzVBJOojLBevHcGQjhWVbWrmWqLhQHbywUTwZKqacPBxpGEOEwGfuFSBBDyDczAUqGudlNXhyyxKwEHqROUvygVHxYDgySFe")) {
        for (int xwAbSKCm = 822244370; xwAbSKCm > 0; xwAbSKCm--) {
            uLQQHfYFrztsF = ! IOHUfhEumKUV;
            MlUKUjaH += MrFDDuU;
            uLQQHfYFrztsF = IOHUfhEumKUV;
            MlUKUjaH = MlUKUjaH;
        }
    }

    for (int HepOoy = 1310072295; HepOoy > 0; HepOoy--) {
        MlUKUjaH += MlUKUjaH;
        IOHUfhEumKUV = uLQQHfYFrztsF;
    }

    return rATXumSmRVENf;
}

bool MlmQtjfTS::ZwxMexdwYejZAbj()
{
    double EQWHbbMQUCs = -880864.4122383575;
    bool yzDUSP = false;
    int JUjCxNbLCNFM = 522636338;
    double vZiun = -44414.57118012854;
    string qyAUznGmOpOaqKvv = string("ZAkFyEOXhXEPMFexNvaRIhyYIQmgfBtYaUovToZZalqXnCnyCXoyOUGsKyXdfVsyhSQObJPvbdgJsDQvkUcipAsEwDcfGQaDWPMKMmisgHFnHebZlsWrtQlpnSDfkNvScvdlgQZchXtTYzTfXPDmUTqVfGOF");
    string zFDLpIcnSkNsIfUW = string("hK");
    double TVzhGGSQIuJuqoC = 755028.7020659575;

    if (vZiun == 755028.7020659575) {
        for (int oUyfMQjdmvu = 869885017; oUyfMQjdmvu > 0; oUyfMQjdmvu--) {
            EQWHbbMQUCs /= EQWHbbMQUCs;
            yzDUSP = yzDUSP;
        }
    }

    if (zFDLpIcnSkNsIfUW <= string("hK")) {
        for (int ZjgashjeqRoIdfw = 2014483536; ZjgashjeqRoIdfw > 0; ZjgashjeqRoIdfw--) {
            zFDLpIcnSkNsIfUW = zFDLpIcnSkNsIfUW;
        }
    }

    for (int zbGEZQjNNpGEKFjw = 1077588016; zbGEZQjNNpGEKFjw > 0; zbGEZQjNNpGEKFjw--) {
        continue;
    }

    if (JUjCxNbLCNFM < 522636338) {
        for (int fPNPrvHIueLA = 233269616; fPNPrvHIueLA > 0; fPNPrvHIueLA--) {
            yzDUSP = yzDUSP;
        }
    }

    if (EQWHbbMQUCs != 755028.7020659575) {
        for (int pHjFtilJWkSXxr = 352723199; pHjFtilJWkSXxr > 0; pHjFtilJWkSXxr--) {
            zFDLpIcnSkNsIfUW += zFDLpIcnSkNsIfUW;
        }
    }

    if (qyAUznGmOpOaqKvv < string("ZAkFyEOXhXEPMFexNvaRIhyYIQmgfBtYaUovToZZalqXnCnyCXoyOUGsKyXdfVsyhSQObJPvbdgJsDQvkUcipAsEwDcfGQaDWPMKMmisgHFnHebZlsWrtQlpnSDfkNvScvdlgQZchXtTYzTfXPDmUTqVfGOF")) {
        for (int mqFAmAOxXTzsRo = 1973547636; mqFAmAOxXTzsRo > 0; mqFAmAOxXTzsRo--) {
            yzDUSP = yzDUSP;
        }
    }

    return yzDUSP;
}

double MlmQtjfTS::JgLacGtKwionkCg(bool mcnmdTbTKbjmA, int cqPsjxv, string emVvGouW, int CtvDXC)
{
    int oyTXr = -906824881;
    double RYSDRSadhnyEsUUO = -559421.6619349363;

    for (int qYkVPkZzAE = 1384430386; qYkVPkZzAE > 0; qYkVPkZzAE--) {
        CtvDXC /= CtvDXC;
    }

    for (int byvYxlQ = 1508778214; byvYxlQ > 0; byvYxlQ--) {
        mcnmdTbTKbjmA = mcnmdTbTKbjmA;
    }

    for (int RUCjcBLAMgvfC = 866210671; RUCjcBLAMgvfC > 0; RUCjcBLAMgvfC--) {
        continue;
    }

    return RYSDRSadhnyEsUUO;
}

void MlmQtjfTS::vfDUa(int VsanPyXoQV, string iiAKVUyl, bool yXTjwezX, string GGfkkFyXDeH)
{
    int XRzeCtYUrGXCP = -1947018737;
    double ERlcdxrViQENBlAn = 722939.0933791674;
    string koGJJXfyjThuG = string("vleHeqteCSNAgBrMzGbjqUkeZirKHuaOqhentyauhZbwrEgZrcMGBhxVrKUjqFUYxcsXVTuKZemgfmVScAWOOndnBRdIuWErMVoMxAaVqCyNIkqKqLVpCuHxvjXXIWSFmHdStlkgmTJuDtXwcCEEypKkoFecEkHzxEChCEvTPJayAdObEwXbyZYyRQEEgMeBMYNlnLBWVZyPNxTdeGVMFTMuOzOpFUvUUxMSyNyGCxOFka");
    bool QsyQM = true;
    int HMxChHJZMDYhaUMB = -1551337616;
    bool ryZWqkXjfDhy = false;
    double gsirpvDr = 237090.41795325695;
    int bVkulWyLFMMPPb = -2009816958;

    for (int IhMuZUHbqj = 1397907050; IhMuZUHbqj > 0; IhMuZUHbqj--) {
        QsyQM = QsyQM;
    }

    if (gsirpvDr >= 722939.0933791674) {
        for (int gJBBVzpzRYHciKR = 1556493043; gJBBVzpzRYHciKR > 0; gJBBVzpzRYHciKR--) {
            koGJJXfyjThuG = GGfkkFyXDeH;
            ryZWqkXjfDhy = ! yXTjwezX;
        }
    }

    for (int CoDkdpzfBLxv = 666740725; CoDkdpzfBLxv > 0; CoDkdpzfBLxv--) {
        gsirpvDr -= ERlcdxrViQENBlAn;
        QsyQM = ryZWqkXjfDhy;
    }

    if (GGfkkFyXDeH > string("xNFvVhJvJJBciKsYvgiLbSRALSPDncnjTbuWOeKZlhqaJetbUVkbdZziAFIizYORBaZaOYMzeRjzWaoPkYpZbCZavK")) {
        for (int HawDppndaREfpEm = 1188936991; HawDppndaREfpEm > 0; HawDppndaREfpEm--) {
            continue;
        }
    }

    for (int MBQMiO = 102158687; MBQMiO > 0; MBQMiO--) {
        continue;
    }

    for (int FXlGxXmYViVo = 216336459; FXlGxXmYViVo > 0; FXlGxXmYViVo--) {
        iiAKVUyl = GGfkkFyXDeH;
    }
}

double MlmQtjfTS::tDIpC(string cwPopqcsbd, string JnaJAFlTULC)
{
    string gdWoEwW = string("kXCsBjCiGtlLoIglJbbJdnXiFoIiyJDBSCAvhzavbQHtdcdxiBMaprctKbZYgYAITTQArCuYJHJIpWXPIsvRqCNumkJFceMGZWKZxsFZmkwvbElaHNRQmXBlGojuiRvKKNofEDPGCXJtFgvaUAgDqZvmelfIQvfbYDwJiSPlzdMRXeiorOORpJFCnVhwuO");

    if (gdWoEwW <= string("EA")) {
        for (int CKnpFQXTqIbF = 1244655573; CKnpFQXTqIbF > 0; CKnpFQXTqIbF--) {
            cwPopqcsbd += JnaJAFlTULC;
        }
    }

    return 11739.542301925312;
}

void MlmQtjfTS::yzQFJaCRDrEdYPEX(int rwOeZreeWcHChoo, int FNLRHT, double pFSTiloATOJS, string ZLOjWQsGGm, string xHJALHSrzBUbz)
{
    int JKjqVmjGEcbQ = 254108975;
    int APBZqMPfslt = -1899825999;
}

bool MlmQtjfTS::BGnzZXsi(int DlVWQLlvtnGa)
{
    int kdQYhyNUu = -1943495581;
    double DKZNMwMru = -884758.3235417472;
    int wbEupLB = 414564084;
    string ftPSzWbHSzyJvr = string("yAZrkbOdJDavfNjScSzudAaGTpumqfPyagooquDZCygvciDrseQpChmWNBUhEOpBEVEQbxzEPrAHtDkTyhNrGXEkVwIzaCuEzVtGfqDfzgNKPxUhwfwcGdvAmqrodhzoGSCZOdTsUAEjRsMfIKBSJiRlwHqrAcVAXmwrmIBZVgtivuYljKCCpBNHMDcDGIwmsKerVaWqOnhRDSIcoZRJynivEgFKPXbRlBJSmRNidRfYumwa");
    bool ITRiPILkDVSIzk = true;

    if (wbEupLB >= -1943495581) {
        for (int mhPvEaDDVaO = 1141917621; mhPvEaDDVaO > 0; mhPvEaDDVaO--) {
            ITRiPILkDVSIzk = ! ITRiPILkDVSIzk;
        }
    }

    return ITRiPILkDVSIzk;
}

int MlmQtjfTS::BUTRz(int QImUCzNyovCLWjd, string SyJFKT, int EpuJQZcAmqlVU)
{
    double MXhSvbApmGPK = 355124.7343767637;
    int AuuAGBndtPBsScp = -1518010685;
    double JtyXrXC = 288236.2725451946;

    for (int NQeKjzPcKFaERw = 1549970051; NQeKjzPcKFaERw > 0; NQeKjzPcKFaERw--) {
        QImUCzNyovCLWjd *= QImUCzNyovCLWjd;
        EpuJQZcAmqlVU -= EpuJQZcAmqlVU;
        EpuJQZcAmqlVU = AuuAGBndtPBsScp;
    }

    if (JtyXrXC == 288236.2725451946) {
        for (int wcdZaQFy = 496223292; wcdZaQFy > 0; wcdZaQFy--) {
            MXhSvbApmGPK -= MXhSvbApmGPK;
        }
    }

    for (int qKysmukKMHYqf = 1921433627; qKysmukKMHYqf > 0; qKysmukKMHYqf--) {
        MXhSvbApmGPK -= MXhSvbApmGPK;
    }

    if (AuuAGBndtPBsScp > 139580627) {
        for (int WOjLsBMHPk = 1684898526; WOjLsBMHPk > 0; WOjLsBMHPk--) {
            QImUCzNyovCLWjd *= QImUCzNyovCLWjd;
        }
    }

    for (int CNwTDMI = 1260822027; CNwTDMI > 0; CNwTDMI--) {
        EpuJQZcAmqlVU -= AuuAGBndtPBsScp;
        QImUCzNyovCLWjd = EpuJQZcAmqlVU;
    }

    for (int urdCuzi = 613576572; urdCuzi > 0; urdCuzi--) {
        QImUCzNyovCLWjd = AuuAGBndtPBsScp;
        AuuAGBndtPBsScp /= AuuAGBndtPBsScp;
    }

    return AuuAGBndtPBsScp;
}

string MlmQtjfTS::SipUhRRlByzjQ()
{
    double peAWhGSvFSBLI = 292905.1669865236;
    string XcpSJBoyMIGDldwG = string("hbLOeZfjEbHTXgrlYdFmaLxBwryAFkewZKczqQUxejDETgATbFgCvJdPeCGWHfrnIJdEQxewcttPLpzqmxYJuwWmrsIikZFlfVkmupBxMcTTcukvfHBPZdWqCUPBxTVAgZLHUteYklaEQDNjPbwGaYKyaeoCTSGxmsAWCNvlVBjLsYEwSkovFXeSoxxxamcwZwOwqGHHXSLSj");
    double MQfPbmJjszsPF = -578309.459558032;
    double fuazBWZcFwHxEVBC = -248413.53257695792;
    int IBBvUOOOgEZYdwu = 149200733;
    bool ewGTfJYtCkSUGU = false;
    bool IIbAvlqMhV = false;
    string nCVCkbNaiBKc = string("snBtNSJwEQbpnlJgABEAfZPHnHDgXoFfUgfILTWVnMnSnydtjzGlgKcpWGsiNbKxNCSxhrpQVMFcNLswciZOKyNmlfspRxxBNSqgjfTYdkSdUXxlxMTRSyIADkEGcXxDfSlOTxkqmsQywZgLnghjAZZMQyULqnuQaQzmAnwvCEzCkswUA");
    string treTAjzh = string("BFLuQEegWGKdOcKuMjquVCSzbRygMhSaCuNtspepqglbIpUszuUrSkTgvSuQTOwCEhTJEvhkSiIbPSXkgapdFmXaKNvMarLqOkouqYNjvWeXSiJLiOcLhFXZQREBgaVQWfdSzsccAbSMCMiawkudhNlikwAyguEhsKDzNzlPZDLCUcmttsebYPbLdvlyZrcNJjwnFKByLVDqeYPrylGxlCYUQrskQSMBuDhCERIdxCwZIDoBbhTfe");
    int lAEPHWYiBardH = -1425641723;

    for (int dSbNwdMHn = 2072272134; dSbNwdMHn > 0; dSbNwdMHn--) {
        continue;
    }

    for (int cjfHbJ = 1165244198; cjfHbJ > 0; cjfHbJ--) {
        IIbAvlqMhV = ! IIbAvlqMhV;
        treTAjzh += XcpSJBoyMIGDldwG;
        IBBvUOOOgEZYdwu = IBBvUOOOgEZYdwu;
    }

    for (int YFfjJZno = 611879469; YFfjJZno > 0; YFfjJZno--) {
        fuazBWZcFwHxEVBC += peAWhGSvFSBLI;
        peAWhGSvFSBLI /= fuazBWZcFwHxEVBC;
        MQfPbmJjszsPF /= MQfPbmJjszsPF;
    }

    for (int bBLvL = 82991324; bBLvL > 0; bBLvL--) {
        peAWhGSvFSBLI = fuazBWZcFwHxEVBC;
        fuazBWZcFwHxEVBC *= MQfPbmJjszsPF;
    }

    for (int QaeSFVLnjjC = 1105266539; QaeSFVLnjjC > 0; QaeSFVLnjjC--) {
        continue;
    }

    for (int AZIzIDhfGas = 219187044; AZIzIDhfGas > 0; AZIzIDhfGas--) {
        XcpSJBoyMIGDldwG += XcpSJBoyMIGDldwG;
        MQfPbmJjszsPF -= fuazBWZcFwHxEVBC;
    }

    return treTAjzh;
}

double MlmQtjfTS::iksYrroygjtiEGj(string JFnAkZlqOcH, string rsZbZVCcOLnOKKw, bool IvoWWqrlAEX, string FdePuOPrfDHOLl, int VrtcznPdkMu)
{
    string CwfvekgZdiCblGx = string("JzFTDbrqEkXGUPLgAwOcXIbEEKcXZBPskPMYDXnDmhcisQARzlSCzdnwunJajynOXpjFBMlmcKKEJcPanUNGbCdfctTUuHSIdEgGRTcjlNznrxMYANmSWcLTXhjQFpyqvrzXkQvSsmlYkpJidCXwTDYcNreaSrongxN");
    bool ObXIxiB = true;
    int QrZfzO = -1507899323;
    string TJMHnio = string("RQcwXHCpEepCGzZVQdcnuGvCwTnqduhysQaDtInWhtqeiILsRALyTdBPvJLcpIZjPEelKKAHxdWzjePEfbTtxuHtAtbcPGgVxtBCeaXnFGVwSWvOGCKpbjPBnHEJcGEyTvqPQLwzFvpDNYQXermfqmVjDzqPaDRQewkZuTXZpRlczCkMWZLvN");
    int mxMaNVlGUq = 1088399077;
    int ykYmFpo = -690572927;

    for (int qaEHoC = 668079820; qaEHoC > 0; qaEHoC--) {
        TJMHnio = JFnAkZlqOcH;
        VrtcznPdkMu *= mxMaNVlGUq;
        CwfvekgZdiCblGx = JFnAkZlqOcH;
    }

    if (JFnAkZlqOcH != string("JzFTDbrqEkXGUPLgAwOcXIbEEKcXZBPskPMYDXnDmhcisQARzlSCzdnwunJajynOXpjFBMlmcKKEJcPanUNGbCdfctTUuHSIdEgGRTcjlNznrxMYANmSWcLTXhjQFpyqvrzXkQvSsmlYkpJidCXwTDYcNreaSrongxN")) {
        for (int bYCwKAlSijFhy = 2077412833; bYCwKAlSijFhy > 0; bYCwKAlSijFhy--) {
            VrtcznPdkMu -= mxMaNVlGUq;
            ykYmFpo *= ykYmFpo;
            VrtcznPdkMu *= ykYmFpo;
        }
    }

    if (ykYmFpo <= 247694080) {
        for (int zColIFQKOMkjED = 653754505; zColIFQKOMkjED > 0; zColIFQKOMkjED--) {
            JFnAkZlqOcH += FdePuOPrfDHOLl;
            TJMHnio += rsZbZVCcOLnOKKw;
            VrtcznPdkMu /= VrtcznPdkMu;
            IvoWWqrlAEX = ! IvoWWqrlAEX;
            TJMHnio += TJMHnio;
        }
    }

    for (int NcjPMduqBFKA = 371675028; NcjPMduqBFKA > 0; NcjPMduqBFKA--) {
        ObXIxiB = ObXIxiB;
    }

    return -167308.69272784883;
}

double MlmQtjfTS::vlfCw(double AyGbFyntid)
{
    bool ETMOeCAtVs = false;
    string PxJOHgeGEQbKr = string("dinADazBlvfDnWlCbqzUKhKrFONcGNvzMcbhHeG");
    double qWawWzUeYfwn = -523162.24885085085;
    double UqUsiiLnptljOPvZ = 1007322.6860156954;
    bool sYNGiulFCn = true;
    bool QfVDJnx = true;
    string ztcXeAJF = string("cQMBNWhWVKiEoqJfqBFywAjJCbiyWhHKzUkJQbArxwnBHQxZhbcBiumuPfPTdOCfqRetWPtTMvYulsiUdxGlWJnGCRrKoAMyUyibpfWUuxTpWN");

    for (int tbJDF = 1677370871; tbJDF > 0; tbJDF--) {
        PxJOHgeGEQbKr = ztcXeAJF;
    }

    if (qWawWzUeYfwn == 228748.0355675172) {
        for (int vrFIBLuSigDen = 1138020628; vrFIBLuSigDen > 0; vrFIBLuSigDen--) {
            qWawWzUeYfwn /= qWawWzUeYfwn;
        }
    }

    for (int jkOCMFuNnJw = 580529057; jkOCMFuNnJw > 0; jkOCMFuNnJw--) {
        ETMOeCAtVs = ! ETMOeCAtVs;
        AyGbFyntid *= UqUsiiLnptljOPvZ;
        PxJOHgeGEQbKr += ztcXeAJF;
    }

    for (int wgczrDhPguhUC = 972118105; wgczrDhPguhUC > 0; wgczrDhPguhUC--) {
        continue;
    }

    return UqUsiiLnptljOPvZ;
}

bool MlmQtjfTS::eahAMDmUrOfULs(int BMGFVR)
{
    string atKwAM = string("LglorXUepTlaNpwaIuEZroJhCeZAUfagzrDnRHubzmyUGILjFBNHLUItCNtluAhBkxXuDTZheIuKccDcOw");

    for (int UqCSk = 393373119; UqCSk > 0; UqCSk--) {
        BMGFVR = BMGFVR;
    }

    return false;
}

void MlmQtjfTS::anlELJVZY(int rDkMoVlCvULkEPy, string lmLiCGSELk)
{
    string UiEQrkQqcnJ = string("FzJHdvaimBkxdhkHUVRNtHbCjxxEghYBkJUNNKnRNdTEHteODsqkxqMRJRNehQcxXcCkYzZpdFtQhRXOCHjrTfeVkWdKFcSDLKkIhMGFrRKTtfzHeCPakiPpuuwqjrQBTxqAaLlCazKxwqKzHxhDQUInnUeUlibPDrimyGpHOJQDvjPIDwYLyrmiFEhYtImsFEz");
    string PCXKMPBRe = string("jhwhMAiTnTdEzSIwBNnwAxozJToGHiTAxjBluDcSYMlbjKukWhGWiXFufEfXLVvXjpodwPqdvERYAlaJffYPmvdmTCYhpGSpSiNRYuaMmuqyMlCgETIabxCxmwpRGyqQYKClQELDMrKqGkSFhOGoMYJBtljSBMEvFipOSylzBkyKQdmIlRCqPTXvgShzpskYGuJx");

    if (rDkMoVlCvULkEPy > -284075111) {
        for (int KedkWow = 1297475828; KedkWow > 0; KedkWow--) {
            UiEQrkQqcnJ = UiEQrkQqcnJ;
            lmLiCGSELk += lmLiCGSELk;
            lmLiCGSELk = UiEQrkQqcnJ;
            PCXKMPBRe += PCXKMPBRe;
            rDkMoVlCvULkEPy -= rDkMoVlCvULkEPy;
        }
    }

    if (PCXKMPBRe > string("FzJHdvaimBkxdhkHUVRNtHbCjxxEghYBkJUNNKnRNdTEHteODsqkxqMRJRNehQcxXcCkYzZpdFtQhRXOCHjrTfeVkWdKFcSDLKkIhMGFrRKTtfzHeCPakiPpuuwqjrQBTxqAaLlCazKxwqKzHxhDQUInnUeUlibPDrimyGpHOJQDvjPIDwYLyrmiFEhYtImsFEz")) {
        for (int bTOEIcTaNhuqJ = 36609005; bTOEIcTaNhuqJ > 0; bTOEIcTaNhuqJ--) {
            UiEQrkQqcnJ = UiEQrkQqcnJ;
            lmLiCGSELk += lmLiCGSELk;
            rDkMoVlCvULkEPy += rDkMoVlCvULkEPy;
        }
    }

    for (int KFYJUYL = 1552457153; KFYJUYL > 0; KFYJUYL--) {
        lmLiCGSELk = UiEQrkQqcnJ;
        PCXKMPBRe += PCXKMPBRe;
        lmLiCGSELk = lmLiCGSELk;
        lmLiCGSELk = PCXKMPBRe;
        PCXKMPBRe = lmLiCGSELk;
        UiEQrkQqcnJ = UiEQrkQqcnJ;
        UiEQrkQqcnJ += PCXKMPBRe;
    }

    if (PCXKMPBRe != string("jhwhMAiTnTdEzSIwBNnwAxozJToGHiTAxjBluDcSYMlbjKukWhGWiXFufEfXLVvXjpodwPqdvERYAlaJffYPmvdmTCYhpGSpSiNRYuaMmuqyMlCgETIabxCxmwpRGyqQYKClQELDMrKqGkSFhOGoMYJBtljSBMEvFipOSylzBkyKQdmIlRCqPTXvgShzpskYGuJx")) {
        for (int WtJXCwbEwgzEr = 1826712390; WtJXCwbEwgzEr > 0; WtJXCwbEwgzEr--) {
            UiEQrkQqcnJ += lmLiCGSELk;
            lmLiCGSELk += UiEQrkQqcnJ;
            PCXKMPBRe += lmLiCGSELk;
            PCXKMPBRe += lmLiCGSELk;
            PCXKMPBRe += UiEQrkQqcnJ;
            lmLiCGSELk = PCXKMPBRe;
        }
    }

    for (int vDpiOPLMdNCBMhe = 684939052; vDpiOPLMdNCBMhe > 0; vDpiOPLMdNCBMhe--) {
        continue;
    }

    for (int ZCOyMYZEpRPozp = 1584033002; ZCOyMYZEpRPozp > 0; ZCOyMYZEpRPozp--) {
        PCXKMPBRe += PCXKMPBRe;
        PCXKMPBRe = UiEQrkQqcnJ;
        PCXKMPBRe += PCXKMPBRe;
    }
}

int MlmQtjfTS::kdTjOylBmw(string dYQaKvEU, double VIXANZK)
{
    int NYEGBNxqr = 1502618303;
    string LlGOKHclEwJEmZEh = string("tNkefmpVgHnRlcXhmFTsKRrifTUWjYZXXMZddbOegSrCQhLDfETWWticALLG");
    double GqjDQcixI = 68251.27790889838;
    double IgDqG = -640501.0595494438;
    double FBJxCF = -859722.0041746389;
    string PrCdZqLfiOnujf = string("mIXXLgbZupOVfuhoGzEtNUkYZFgsPmmyGcfZeuWcLtWdJNDzisaPwEUgRmcZtUKelyUVoBDVvhWHItIXxPgnlFnaCiwnDtyXDfEsOiAzxFcZrOQCTkHLI");
    bool HaiJLSLGOaxLqEjr = true;
    bool HwEJA = false;

    for (int kvtenGNLdQeZ = 1933607054; kvtenGNLdQeZ > 0; kvtenGNLdQeZ--) {
        continue;
    }

    for (int iuAakKnm = 2133462866; iuAakKnm > 0; iuAakKnm--) {
        PrCdZqLfiOnujf = dYQaKvEU;
    }

    for (int rskmF = 1653242956; rskmF > 0; rskmF--) {
        continue;
    }

    for (int jVNfwAurfuOzpOG = 483237465; jVNfwAurfuOzpOG > 0; jVNfwAurfuOzpOG--) {
        PrCdZqLfiOnujf += dYQaKvEU;
        VIXANZK /= VIXANZK;
    }

    return NYEGBNxqr;
}

MlmQtjfTS::MlmQtjfTS()
{
    this->ZuTtH(true, -798382.1363964782);
    this->rKczgoKYkoTXXLD(-2012362941);
    this->XlGhAw(false);
    this->VTtqOIkH(string("oZbiwmoxVcXwnXzsGCAUMmCYSNaFeGTwJNoKmUNqVQlgNsgAFTxJSVSyOSJvNLHEdUincnWywbbvGNisQQamAExVIUcqwOTvCgMAiATkUXZFTuMzVjfQVxDSFiRdjiZDgPXXFHpzMkLVVjoDxTBaRyndpLZrViLyDzOZetPduRcfIhWAQCNvfdSfKziVOizvdqelnJmPxsSpQplWtsbTvReZeUamUcttBSFLHdHJCL"), -146730.11316719014);
    this->BDhLKnLruJV(104923462, true, true);
    this->ibsUjVFlrYY(string("JdsANHWiECGaJJBoZkHwdaYtdzgTxDRpuDTbOFeWethzVBJOojLBevHcGQjhWVbWrmWqLhQHbywUTwZKqacPBxpGEOEwGfuFSBBDyDczAUqGudlNXhyyxKwEHqROUvygVHxYDgySFe"), true, string("JrtPFylezIkAFHugzDZYCBwcMznkszMRQMonTjunxfTJRBDwogAClmxDfbVVMlodOitXbFwlpZGOwjgeSRMedGliJjCcZMOsmoFNhwZYyyJyGJxUyCbYLlYmOywWJawetNYRGdHzFHjvymaMOMmCRhsTENxTmbBWlUaPygntNbSdrJgQxGcWbUHUAYhZjH"), false);
    this->ZwxMexdwYejZAbj();
    this->JgLacGtKwionkCg(false, 1615947078, string("mvTFItoEvbkVZokawK"), 197823126);
    this->vfDUa(-1553209683, string("CDyHvYVkqMHvtZOThPoifzDapRRtqoaiMkdtozjIcdQrxUZPhoJlMvzcKvEiWUlWtTpGAbuXbAzSCRZcOOkJFENMBifTZgELcjEvjReYNGVQCYejLBgqWedAaIRgRUZTgsNHqVAfBWnhaRhWCTfBDqzUNYeRFNVZeOuBdrOWSDxkAVAFCzyzbFlnYMmADKaKVHsgkaEmvLFSJRMmRRTmlseiJxgolOTDRYsjsVMKRRXAnlguCgLrozeWLDvl"), true, string("xNFvVhJvJJBciKsYvgiLbSRALSPDncnjTbuWOeKZlhqaJetbUVkbdZziAFIizYORBaZaOYMzeRjzWaoPkYpZbCZavK"));
    this->tDIpC(string("EA"), string("kIWxaGmGizuUxVCrsjreKUGFbsPExoRfLEiYApNaUYusJKNnkFbcLVbVLWdDlWtPACkBmIVWHqApgFgwdGmIbYHhYYfPiqxZWuHnBWLGguvOTRjYAwxfcrA"));
    this->yzQFJaCRDrEdYPEX(-693292621, -986433998, 445506.2151948544, string("ddrKSCgtBHssmPyglvJuHatnqqmXDyEuFGpEVFqCiYjfDempaSXOPpffdtmlOZCeTcqDXQKCOoznuVqWKcsYenGRrHBnBQyeuSASeTIbqkUlQDDWYFnvlGHwFaqITBKqOQFoCXhzQlrDsKWVOJSagwMAEPAykWLBnMfrZjcUHmtEUvzSdYEuOgPbcZRyaeqRTSXYjlKxsufzhRiqLZ"), string("TQBgABupJrXErIbBlGfXLbGglrbHtcdKFfwivgbEsURLEXJeqGOFLdCSABJEseeYSVYHjtEWLiIHazzUxBVALKPLOJAhrBmstJSxxaLbcTGzvvdzlpDSaAjMDQDIaFsSXuKTHUAwpIbBMPSGpSqdqMCxGxboLqlRxggGbkWGagchF"));
    this->BGnzZXsi(-573234322);
    this->BUTRz(-712890535, string("mp"), 139580627);
    this->SipUhRRlByzjQ();
    this->iksYrroygjtiEGj(string("cDWsJDDUzBjrWzLOBwtHVZVVYeMorOWEVTROeXcYSKpcxSRwWZfumDjgaahWuhMAPCRcaClhtYuNmJ"), string("vHvEgbFyRlYhtuhgKobCECQboPnpZJvdFqCVATtLvldZxauWowKTfxjIbUkhfFrqsgzefHtuWmcDtiiuoNDwGKLceYcENecTCxaAMIQdbPmwGqLdkyzyffYnIjzmInYpKHrBhEmoS"), true, string("YiDkOyZkuLdbQklkUrcmFAXuNMfOMwsmhHbTwOUdJwDblSGoeDeVPylVAbfOsXKjKykEjmagHhSkxgegnnIEWWeyYECMBedNBgKiRwByWnfJEGVAbuBiRSpkoTUSNLIlaNXmwNOVEogjZMjjDYuWUcOqGlUjjHyviouvWcZQolkxnlNBsWqlzhRjpVNkoNorbfvawvnOOEJQsFqzMAAKoxgtAqVlX"), 247694080);
    this->vlfCw(228748.0355675172);
    this->eahAMDmUrOfULs(-1759869652);
    this->anlELJVZY(-284075111, string("xcolUIpRBinelhewaOVaTJCPkJoBelMhxWbKHGGNituyXrtZZdLKyvicRfjFoWyHyVWkKuDqLcwqCDTumNmgLVpCLtOvVOCForemYWEhfhoyECfrczTNxKHhAwcQFCIamfxhEpTVyvuCpbWibzzyGBWGtZyPnyukBJNkChBYENkejcpBPsxNMUCqnPOyOankNeDOuUtcFPfQkMcwiZIRjPTdcWyNrweIj"));
    this->kdTjOylBmw(string("qhkqJfhYzJUUcmJlAPMBpjvtbTbTeCGTqpisKoxooFgGxUgkprTgQjHtswJBbYFtvicLIErQLXSADkAuCvzXuPZGFSPCZIM"), 92055.95531826727);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GycLGRN
{
public:
    int GojtyOFMRf;
    bool CdfWomxXvMiEB;
    string VQgPsyzggobYgGJr;
    double exwPZI;
    bool qOnVldeYkYQqJ;
    string XbPjO;

    GycLGRN();
    int ffTdGi(double nGEPuzrHcrC, double yWPaMown, int AAWEFNCzltJhy, string QugStlRboVoYfwXA);
    double dguiVRRLmkwk(double AyvyRUf);
    double ubCHUtFI(string HmupLbGtNZCuGQ, int ressIJh, string cYviuHw);
    double SFszsmvXJsRw();
    bool SobivHo(bool UiabWgzrAQm, bool vhedyCANOyMuL, int ItBAykgYxPeGmuQ, double oUhSiImj);
    string rVWMENkAz(string OlUdJQxQDaaf, string MciRQhIUoKecj, double qUzrFjIw, bool mQhbaOzF, bool YDJmYifqjmjSM);
protected:
    bool xpbLDUE;
    string xaqRsoPVPLyO;

    int vnIQlzh(double xOssV, string pgsrwifGIBHd);
    bool lBYgOJaOhid(double RCvIyrgHKYo, bool eDuyq, double JIpySczPs);
    void fmHoxjtYvg();
    double PKvHzLpivRV(int GqyzG);
    double VhlHNzfdpB();
private:
    int XIIBrboxHdV;
    int pxufoYqswMy;
    bool ZslXjg;
    double dcRUEnBEdiT;
    int axgQapa;

    double XwVSIElIZ(string mSLacEcAPnr, string lfGQueXuEyLdDJk);
};

int GycLGRN::ffTdGi(double nGEPuzrHcrC, double yWPaMown, int AAWEFNCzltJhy, string QugStlRboVoYfwXA)
{
    double iUwsiTlG = -323585.65052534343;
    int jOnFUikZOvy = 879793147;
    bool aDruYHIVOg = true;
    int XgFaheTxUVUi = -1647924633;
    bool NRbMSoypgfo = true;
    int vIiKFq = -505209933;
    double RwUyEDCQGlprvNkI = -409959.3673260937;
    string JibuGaIMqt = string("bomtJVJpilYvekWtdMRJJnnIYWDMAnTsMSrwckzuHMMJDQeCALrktMgGBsEDaJPKTYvjbLJDjylvhzYuzNdfuBQVtBoYzpIBp");

    return vIiKFq;
}

double GycLGRN::dguiVRRLmkwk(double AyvyRUf)
{
    string xKpDnMwHfgZEgg = string("WqlTztopcOrLzpiuIwiCFLwFqyBvRrbYxznRcZthBRtbSwnBzqGOUDvhiRMXzqfVbyQhcXbXDjBTQUaWdfVOXbtnugofMdpGZjDtv");
    bool hifoDVVoSB = false;

    for (int kQkQHSbftxnASP = 871005643; kQkQHSbftxnASP > 0; kQkQHSbftxnASP--) {
        continue;
    }

    return AyvyRUf;
}

double GycLGRN::ubCHUtFI(string HmupLbGtNZCuGQ, int ressIJh, string cYviuHw)
{
    int RKLJuNEg = 1314102309;
    int YCyeJ = 1953565858;
    string CXuaUMZ = string("s");
    double qNBXYJXgbgDDEqv = -934468.2819219239;
    bool LGFEIybeNO = false;

    for (int tjQEH = 804633208; tjQEH > 0; tjQEH--) {
        continue;
    }

    if (CXuaUMZ < string("kNUNhoCEIhmSZNMtjaYKwLfChvgACwRippwCyDUisGIABboeDjViFxhCrELAxazCRehVwCLhBkYYMpWAAkTIvWSpAscVBXuuDLCGxijrkLXuaRaGvIZSVyNqMJeaardDgzsIJApehGJopYcFCiPi")) {
        for (int lorgkQSClrHk = 1330942412; lorgkQSClrHk > 0; lorgkQSClrHk--) {
            continue;
        }
    }

    for (int UrlyxT = 46456371; UrlyxT > 0; UrlyxT--) {
        RKLJuNEg /= ressIJh;
        HmupLbGtNZCuGQ = CXuaUMZ;
        RKLJuNEg = RKLJuNEg;
    }

    for (int FZrzjMZ = 1986968799; FZrzjMZ > 0; FZrzjMZ--) {
        YCyeJ -= YCyeJ;
        cYviuHw += CXuaUMZ;
    }

    return qNBXYJXgbgDDEqv;
}

double GycLGRN::SFszsmvXJsRw()
{
    bool cTTsPSksMD = false;
    int UlOUsCqa = -1962478953;
    double EJRixcaU = 621531.0394451543;
    double YegJp = -550612.2308079036;

    for (int YoIgAaccUR = 1792292484; YoIgAaccUR > 0; YoIgAaccUR--) {
        cTTsPSksMD = cTTsPSksMD;
        YegJp += YegJp;
        YegJp *= YegJp;
        EJRixcaU /= EJRixcaU;
    }

    for (int VrjQRHcuyRJoPfxy = 878138978; VrjQRHcuyRJoPfxy > 0; VrjQRHcuyRJoPfxy--) {
        continue;
    }

    for (int ORyia = 841849846; ORyia > 0; ORyia--) {
        EJRixcaU += EJRixcaU;
        cTTsPSksMD = ! cTTsPSksMD;
        EJRixcaU *= EJRixcaU;
    }

    return YegJp;
}

bool GycLGRN::SobivHo(bool UiabWgzrAQm, bool vhedyCANOyMuL, int ItBAykgYxPeGmuQ, double oUhSiImj)
{
    bool oJBnsRBe = true;
    string WbQuksth = string("gBzDPyVKfytmMNciFZzSZOpXmCBDIyhBQCqAAdHjuKrOxKWwmmtfLzlUbhNEzWrBrEyvVrJWlJrPcNuXPlUfqTBGVTZqyLQgOoBzuHFIxyvVEPgIPRzsgkdMWEKKxhsyeMHRxJYQzVbVNcqccGlDPYsmycnSBufovPwvjDpSLRcmQbIyjqEeWuCSeldMpytwTfHoIcCdAdNnzEZdEdmTCagRSbXvOsIGGnmSgbYyDN");
    double htOMoxjQj = -563576.2649941957;
    int VUqukkWvaCTALc = -586398512;
    double DiJuGCWtBq = -151961.9657101835;
    int lAZScuQREAbnC = 1291381093;
    string DcEWvSNHO = string("lePADNYNhZBqeZBk");
    double zmReSick = -20729.291387697125;
    bool QXvarIeKmwL = false;

    for (int jHrnElIEiFhkw = 723651195; jHrnElIEiFhkw > 0; jHrnElIEiFhkw--) {
        continue;
    }

    return QXvarIeKmwL;
}

string GycLGRN::rVWMENkAz(string OlUdJQxQDaaf, string MciRQhIUoKecj, double qUzrFjIw, bool mQhbaOzF, bool YDJmYifqjmjSM)
{
    int uPeZdsgaWxV = 1753204839;
    bool eFUFhnQ = true;
    string VFzUvohP = string("KrQwFGdwfEloRxtUbUvyivQjfeG");
    string urwMtWJW = string("upjjzOBrbRSFaXMHupSwTptnZxAgLCqjatIaFssuHlASMVFuRRRnwqyhVlAadJMsozndk");
    bool VUBcSJQuHqyKfm = true;
    string XYiwNlzZRkgRKX = string("gToFjToMJrRPmhRsGEaZXneEuhxAkLOBFoUUtgOPAZEzlFuwhSvnHMQuKDMyZjCkemDlPpGwohBcWoPKpvewoJkgNuGhRnRlhjQDcysOrhdUibzUyjUcHvzPuzWuvmpfJNycoVxuavbBQxkFFeorkUGaDhKrSXYGheCcljy");
    bool eKaZAwi = false;
    string mvObNPIHrYRNi = string("mamLuGVSwAEnqxgBdBzDPHFeMBWdBeObqYmSOfTRYbifMIICfDfQNixEjZVNJCvrtZLXbaqbiqlKvPEoXIAMHaMxPcvnGwXCIrJWknhoTDpRILGtIGELaTgogROJgXlPsKJmzJynMWDrhIOShXaWOCPETGXwpOSPNZlVmTrlrzCdeUgClEPIlpcdgZsmxPMztqNy");
    bool HnmDn = false;
    double WwUhoXGZiHGHle = -588269.0097080901;

    if (urwMtWJW == string("tAFsNzwqorVBvJESsZRXEzrkYYFgemQmCkcPgrWhYnTEMqMMExFSwdHQADlFkTsLvBHXjyUnFNhVBcjEhYdWsKoYHIAmUATwjXZspBPFBfOKpPiLAIFfgpkbElzVCBoRyJasxadSARXqQFQjSEdXQWmXeahdaMrqLeihzdcylliPlYeWxvLcCggUqKTYd")) {
        for (int kQRoaHJgTMRlRR = 1791661032; kQRoaHJgTMRlRR > 0; kQRoaHJgTMRlRR--) {
            YDJmYifqjmjSM = VUBcSJQuHqyKfm;
            XYiwNlzZRkgRKX = OlUdJQxQDaaf;
            HnmDn = YDJmYifqjmjSM;
        }
    }

    return mvObNPIHrYRNi;
}

int GycLGRN::vnIQlzh(double xOssV, string pgsrwifGIBHd)
{
    bool qNvbEdplhZFDM = true;
    int mlDJTUjt = 1036001914;
    bool wLeMfIbWpfE = true;
    string QyxYjGJgpiajbA = string("xLAcGQTkcveFOUpmwYIfRTOctnBuieOuPHHHUbobjatZNTOuMHYEkeHVutNABVDtSdqgEQdSMBNLmFxwKxMtuPifIBxkIpqwSFuLbKcNBwPsEfjZtCOSqhStYCnsRfKNgvHWVbastcRkrVNgOEThGLKNJV");
    int mwrGbCyRbteMmgY = -642309384;
    int NJouTbF = -2125355093;
    int UGmDwWSqoQgGRQnK = 427879802;
    string nnXFq = string("sUheWHCXgZSLzvIAXlUFwUoGMQUrPkCmgbsVFRNZflUYdMfPWABNeOyWjtOuBMTvQDTbIobiFpNiDZhcIexKbWXVwJUGaIXXCgedspiGhnCeRsrevtbZNeMcJaHIJuNSBRsmYHKGeQegBqJoVGbgrLimHQfggoWLjlWGDKinCNJFHZhkZRgGigrqFUTsYnJYqeEAkQMJzmVMcIAalmnWIdPpetYlniAqRiesdWwkayaMoSwmFI");
    string GUNavYyo = string("hkbZUxZPBJagILxzJhHrIKTfQFxLvCgNFoRFxEZmdecBVyQhmofkaOBRsKZvfcVDSeytmBbDCgVRlPIoSEOotXzkWyyElmhhe");
    string SgJKJJFbjOuYwJhQ = string("hGVqcZgEIgGVndKMQvZuLWLOWHikKbFvRokodoBWWLvDtvHyeWNwRsckhlhfryTbkPAUzMZtnQJvhuvFTClLDUvUAQPqCVeXjdjtpikGSnOBEYtuOWvdjnMDZhzIRgMzdEdzk");

    if (pgsrwifGIBHd > string("hGVqcZgEIgGVndKMQvZuLWLOWHikKbFvRokodoBWWLvDtvHyeWNwRsckhlhfryTbkPAUzMZtnQJvhuvFTClLDUvUAQPqCVeXjdjtpikGSnOBEYtuOWvdjnMDZhzIRgMzdEdzk")) {
        for (int oYiVmSeTKQ = 1657537982; oYiVmSeTKQ > 0; oYiVmSeTKQ--) {
            mwrGbCyRbteMmgY = mlDJTUjt;
            GUNavYyo = QyxYjGJgpiajbA;
            UGmDwWSqoQgGRQnK /= NJouTbF;
        }
    }

    if (nnXFq <= string("hkbZUxZPBJagILxzJhHrIKTfQFxLvCgNFoRFxEZmdecBVyQhmofkaOBRsKZvfcVDSeytmBbDCgVRlPIoSEOotXzkWyyElmhhe")) {
        for (int IkGWhyifMd = 787989296; IkGWhyifMd > 0; IkGWhyifMd--) {
            mwrGbCyRbteMmgY = mwrGbCyRbteMmgY;
            nnXFq += QyxYjGJgpiajbA;
            QyxYjGJgpiajbA += SgJKJJFbjOuYwJhQ;
        }
    }

    return UGmDwWSqoQgGRQnK;
}

bool GycLGRN::lBYgOJaOhid(double RCvIyrgHKYo, bool eDuyq, double JIpySczPs)
{
    bool tAjzfOVKKAjjrw = false;
    double pgMVJfd = -780635.0420982373;
    int oMGNcNbFC = -2060266688;
    double hkdBgfyXnmGzIgi = -325342.58427073824;
    string nJJpOBpd = string("ceKdNJAkfWukgeQtQjSSGwsPgMCuKyglRVcOSljNmUPicEXvWtKXWxDTkswvIkIxnFwSgsyRjElNbmFLUQxOHaXrRTxpKoFrLMZNkVsW");
    bool hBWHnKbbiWSIE = false;
    bool NDzrlKAsn = true;
    bool YUlGgkCZKByxkk = false;
    double NwwrFbtlsQTNyiQ = 163475.00124422493;

    if (RCvIyrgHKYo == -325342.58427073824) {
        for (int YjLCFztpY = 1739924065; YjLCFztpY > 0; YjLCFztpY--) {
            pgMVJfd *= JIpySczPs;
            tAjzfOVKKAjjrw = ! NDzrlKAsn;
        }
    }

    for (int shvCGgIHFfqdh = 125537008; shvCGgIHFfqdh > 0; shvCGgIHFfqdh--) {
        eDuyq = ! tAjzfOVKKAjjrw;
        hBWHnKbbiWSIE = ! YUlGgkCZKByxkk;
    }

    for (int QWDzSbwUOTQwl = 716593053; QWDzSbwUOTQwl > 0; QWDzSbwUOTQwl--) {
        YUlGgkCZKByxkk = ! YUlGgkCZKByxkk;
    }

    if (RCvIyrgHKYo <= 361937.92813757295) {
        for (int dOgiDuv = 1811320509; dOgiDuv > 0; dOgiDuv--) {
            JIpySczPs /= pgMVJfd;
            NwwrFbtlsQTNyiQ *= hkdBgfyXnmGzIgi;
            NDzrlKAsn = ! hBWHnKbbiWSIE;
        }
    }

    for (int xItgwtvaA = 135177183; xItgwtvaA > 0; xItgwtvaA--) {
        tAjzfOVKKAjjrw = tAjzfOVKKAjjrw;
    }

    for (int fCkDSZuFq = 511581380; fCkDSZuFq > 0; fCkDSZuFq--) {
        hkdBgfyXnmGzIgi = NwwrFbtlsQTNyiQ;
    }

    return YUlGgkCZKByxkk;
}

void GycLGRN::fmHoxjtYvg()
{
    bool QHidGceyfUhi = false;
    string dKNzqcZuEKgruG = string("qACaUILgKXFTSyRFGUVddZPKxcisnYge");
    double lRTnc = -865219.7839180168;
    bool jZMcGq = false;
    bool mndPv = true;
    int fFOYYarp = -578235577;
    bool JrpYtbhGENrqsKmH = false;
}

double GycLGRN::PKvHzLpivRV(int GqyzG)
{
    bool tJNKjxrcoPjP = true;

    for (int JAFjqWgAW = 172663439; JAFjqWgAW > 0; JAFjqWgAW--) {
        GqyzG /= GqyzG;
    }

    if (GqyzG <= 1106095498) {
        for (int xpwAxanXpXZlX = 2103015219; xpwAxanXpXZlX > 0; xpwAxanXpXZlX--) {
            GqyzG *= GqyzG;
            GqyzG /= GqyzG;
            GqyzG *= GqyzG;
            tJNKjxrcoPjP = tJNKjxrcoPjP;
            tJNKjxrcoPjP = tJNKjxrcoPjP;
            GqyzG /= GqyzG;
        }
    }

    for (int tOpENDng = 733136890; tOpENDng > 0; tOpENDng--) {
        GqyzG *= GqyzG;
        tJNKjxrcoPjP = ! tJNKjxrcoPjP;
        tJNKjxrcoPjP = ! tJNKjxrcoPjP;
        tJNKjxrcoPjP = ! tJNKjxrcoPjP;
    }

    if (GqyzG < 1106095498) {
        for (int NPfdoq = 109351366; NPfdoq > 0; NPfdoq--) {
            tJNKjxrcoPjP = tJNKjxrcoPjP;
            tJNKjxrcoPjP = ! tJNKjxrcoPjP;
            tJNKjxrcoPjP = ! tJNKjxrcoPjP;
        }
    }

    for (int gmFjMEekrrJ = 1578803203; gmFjMEekrrJ > 0; gmFjMEekrrJ--) {
        GqyzG -= GqyzG;
        tJNKjxrcoPjP = tJNKjxrcoPjP;
        GqyzG = GqyzG;
        GqyzG *= GqyzG;
        GqyzG += GqyzG;
        tJNKjxrcoPjP = ! tJNKjxrcoPjP;
        tJNKjxrcoPjP = ! tJNKjxrcoPjP;
    }

    return 244927.92503774635;
}

double GycLGRN::VhlHNzfdpB()
{
    string bElztXAcj = string("aHJHFyaZeCuHwfBjHVqhlZqFhAzcUKQlwSuZwpvkZtSyDQsi");

    if (bElztXAcj > string("aHJHFyaZeCuHwfBjHVqhlZqFhAzcUKQlwSuZwpvkZtSyDQsi")) {
        for (int qUNRMjYgJzQxe = 144331628; qUNRMjYgJzQxe > 0; qUNRMjYgJzQxe--) {
            bElztXAcj = bElztXAcj;
            bElztXAcj += bElztXAcj;
        }
    }

    if (bElztXAcj <= string("aHJHFyaZeCuHwfBjHVqhlZqFhAzcUKQlwSuZwpvkZtSyDQsi")) {
        for (int NxbUnPeYLcH = 948932172; NxbUnPeYLcH > 0; NxbUnPeYLcH--) {
            bElztXAcj = bElztXAcj;
        }
    }

    return -904878.3582898176;
}

double GycLGRN::XwVSIElIZ(string mSLacEcAPnr, string lfGQueXuEyLdDJk)
{
    double pDPoobkW = 469536.7075088141;

    for (int AtqJGRk = 1152535499; AtqJGRk > 0; AtqJGRk--) {
        pDPoobkW += pDPoobkW;
        mSLacEcAPnr += mSLacEcAPnr;
        pDPoobkW *= pDPoobkW;
        pDPoobkW = pDPoobkW;
        lfGQueXuEyLdDJk = lfGQueXuEyLdDJk;
        mSLacEcAPnr += lfGQueXuEyLdDJk;
        lfGQueXuEyLdDJk += mSLacEcAPnr;
    }

    if (lfGQueXuEyLdDJk < string("bWOjjjoVOYbArOkzkmwdDmwTjeIwcBXozGZpZTgeZLxtjjZgHYoxhDGvMTQyqfDxYiLZkhNLqXDXiIfhjfCKbAatvcKiPpAXMUKjBZGcXjrdQJfJMQrLaAgWTWmkdfAfDYNKWkuUEoBklAbogyVGjDbKxclwyLDGbTdlYOi")) {
        for (int VvZDN = 217054160; VvZDN > 0; VvZDN--) {
            lfGQueXuEyLdDJk += mSLacEcAPnr;
            mSLacEcAPnr += lfGQueXuEyLdDJk;
            lfGQueXuEyLdDJk += mSLacEcAPnr;
        }
    }

    return pDPoobkW;
}

GycLGRN::GycLGRN()
{
    this->ffTdGi(-630558.911041177, 982839.6019114031, 1225610145, string("iFgNQwTmlokJAyVeOZnYNDwqYVIdnqTGYLpqfVMtxVpudWVMbdRVJQYUCecHydyKqJERPTkMbvuEkfbLDNoAdDsbxKWMRNAoUrSQuPfGTIOPKetDZhFHBIZCAeBSnlRSgUh"));
    this->dguiVRRLmkwk(-15149.399789394907);
    this->ubCHUtFI(string("kNUNhoCEIhmSZNMtjaYKwLfChvgACwRippwCyDUisGIABboeDjViFxhCrELAxazCRehVwCLhBkYYMpWAAkTIvWSpAscVBXuuDLCGxijrkLXuaRaGvIZSVyNqMJeaardDgzsIJApehGJopYcFCiPi"), 1342254845, string("uKvhcFUGVZTAIftnobeCxeRjYeSBjLYVjMRplsYK"));
    this->SFszsmvXJsRw();
    this->SobivHo(true, true, -958822028, 906994.8807302513);
    this->rVWMENkAz(string("tAFsNzwqorVBvJESsZRXEzrkYYFgemQmCkcPgrWhYnTEMqMMExFSwdHQADlFkTsLvBHXjyUnFNhVBcjEhYdWsKoYHIAmUATwjXZspBPFBfOKpPiLAIFfgpkbElzVCBoRyJasxadSARXqQFQjSEdXQWmXeahdaMrqLeihzdcylliPlYeWxvLcCggUqKTYd"), string("NXzksfTSMFIKxciQcjtUEafGDKNmqLFduBnaIItWOOJUyZjDRgrsLGdSDFOoOqpbtexVmzWcKOvncesoREmestDNnwOhWYydWlXiVTuKCqPXZpRjxrePzqKpAZYZgxaQfoChuvjTCDiiMBOgxColVqOYvWQxzDqKhhqAcVNbXfdf"), 737122.9824455853, true, false);
    this->vnIQlzh(-1033110.4669865728, string("liGbXTevkdzGIKPTajycorzLumSgHyAtbmaSFzJlSKzGwJZVywrIbJRzwUREwmAzVPSZKJkaMjAlAtONSCnsdoczRiiwRnstIbqQYCeqAjXSkPNYzQzTnULS"));
    this->lBYgOJaOhid(361937.92813757295, false, -781495.7488535218);
    this->fmHoxjtYvg();
    this->PKvHzLpivRV(1106095498);
    this->VhlHNzfdpB();
    this->XwVSIElIZ(string("bWOjjjoVOYbArOkzkmwdDmwTjeIwcBXozGZpZTgeZLxtjjZgHYoxhDGvMTQyqfDxYiLZkhNLqXDXiIfhjfCKbAatvcKiPpAXMUKjBZGcXjrdQJfJMQrLaAgWTWmkdfAfDYNKWkuUEoBklAbogyVGjDbKxclwyLDGbTdlYOi"), string("ZeeeaFxoGKggXIfKvIzLuzZoUNsenDWHjtNrqlzvCDiftMYfYRGGDUDmeIMwcDzQvpJhSuytHfvvtvJVAEaoehbNPUTHrgTJWdfddMTcjkEsaNhophbqEkAaosjEPSmhMyPoOCjjGLkSKSoBTdVaFNcRNedUJo"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oddtdFkdxQOcYI
{
public:
    double xXShzHkvH;
    string xyruYOcoVGnyIdIN;

    oddtdFkdxQOcYI();
    void FQvXhJvkxvacHZ(double MrikVQYiWxkH, bool cVOyrysXfqLQpLBl, double kAWGzIbltGjmU, string SpgsOp);
    string apeTu(int tfKNNKgylQ, bool heUDzORxUNpIKCK);
    double JGYGiayUVJsH(double MRlYZNYgHhQdc);
    bool oqidNlKX(double BKEZxmBsKfQcQ, string goXTdiX, double QevKsYRDUeUzIuM);
    int wfhvJkwyk(double IYFCRgNSqgQeWK, string jZduaCLzxoagIp, bool UWouXPaFX, string UiQRN, string Rncus);
    double WEmpoGemX(string TWBbTuuSK);
protected:
    string evAOACTqclOwWjG;
    string DwHigGBkaW;
    bool hbdcHbQiZ;
    bool PZrDmGBBAj;
    int nIRzfoEwH;

    int RxAQYOlRGfpZQ(int bGGlWv, int NPymdMm, string duSHBxgKSvxBClzx);
    string ygVEenzG(string ufuZZyXJIPnuV, int QKcBqspUz, string aeiTshknYif, int flvgveVraGmCCb);
    void pnNBIydOliTNFs(int HGuNUGsuOtSN, int fHOVUBFLRu, bool oUhuzQMXPJRqK);
    string znjYIKlfYNCmzkAn(int yOkGavJsjxO, string CleBRCKhjn, int qvioEOUoyOz);
private:
    string GxzdgLxxcjC;

    int YJXMSnABZM(double bmNKWOHQGQVN, double uHnuPugvmfliFKp, int tvtMBH);
    void dhsZIvJoWpVpouZy(bool oaTadWgo, int kFHvEJA, string NUPdLFSe, double ulNniDrcaOT, int qOTPkubJRcHsNyay);
    int CBrefHrzDLYAvsxy(bool IFtsVbzaVYUN, bool gnQpnGdnNzPMYeDH, double jeVVMVJmrvEXITx);
    bool NyTPMLWV(string aeQNKRmwJpRcriv, double ozoxaVvyf, string GJXMrPwGq, int VcRCrmBeEZSBr);
    int kGzDFBkxRT();
};

void oddtdFkdxQOcYI::FQvXhJvkxvacHZ(double MrikVQYiWxkH, bool cVOyrysXfqLQpLBl, double kAWGzIbltGjmU, string SpgsOp)
{
    string RNKioDMrtHhVqWN = string("CNUJVmxmQrXbmqpnCXCdxy");
    string ZUJHTFsxwAshLU = string("qObtncOUuPkzYQKWfePktoULztNSQgCjmfuFREXILfIuysaCCtgfsAXiQUxbsvRLvLsmDUqKFMqhMkHlKuTozqcqpzIjVxagCNmCyEjrWNUFncFBwXyFywAZZmEtPzNlZhKuJAceNWWDgHzpgoLTMnIcxgozmgVQf");
    bool yxRpYQVyONsaDmSs = true;
    double wjkDNXFzUyDiNu = -433008.1327107049;
    int vFuQr = 1806041870;
    bool pZVVHijhzNybx = true;

    for (int tBGFutQ = 1280777205; tBGFutQ > 0; tBGFutQ--) {
        MrikVQYiWxkH += kAWGzIbltGjmU;
        pZVVHijhzNybx = yxRpYQVyONsaDmSs;
    }

    for (int PqkmPAXdlNDFzZIY = 1169259145; PqkmPAXdlNDFzZIY > 0; PqkmPAXdlNDFzZIY--) {
        yxRpYQVyONsaDmSs = pZVVHijhzNybx;
        MrikVQYiWxkH = MrikVQYiWxkH;
        ZUJHTFsxwAshLU += RNKioDMrtHhVqWN;
    }
}

string oddtdFkdxQOcYI::apeTu(int tfKNNKgylQ, bool heUDzORxUNpIKCK)
{
    double lSskGn = 180244.76547912834;
    double fToNWVvxC = -156027.73361053944;
    int PeClgKq = 956079308;
    double XWESKUHG = 319002.4592830372;
    int HxZaWjZBuUYwRGxA = -1184996621;

    for (int szLoscVDebccPiO = 1287199234; szLoscVDebccPiO > 0; szLoscVDebccPiO--) {
        continue;
    }

    if (tfKNNKgylQ <= 956079308) {
        for (int lQRLFuBQjnmTYp = 2662950; lQRLFuBQjnmTYp > 0; lQRLFuBQjnmTYp--) {
            tfKNNKgylQ += tfKNNKgylQ;
            HxZaWjZBuUYwRGxA -= PeClgKq;
        }
    }

    return string("ErciPFHPrtnbI");
}

double oddtdFkdxQOcYI::JGYGiayUVJsH(double MRlYZNYgHhQdc)
{
    string PvWekQ = string("yDBKdKapCtkKyUzfiLILEqHvzPbmjAAiCYhwTJmyyTcvaqsKZuTuYNFpaESfkfbXjufAioPGEjQrpqcpCTOxGpMyRVIciJIQsVt");
    string brnRHYFHFegDaRmt = string("ClgAkdHgvEzpvxSLGGJbHDNZGIpBWhEcBszTFDfgJBQkIerzsoMSNiCvnPFAPtEWjzHAaJosfRNrzjajDzutxHqlMKMtmQvclkOfalndXlPofyeCqBUTQBnujhrIdYgLtZrfDEmprLPHRczlsbyWCUMpTZz");
    bool NRZRvTwcUoOioCGQ = true;
    bool cyJiKPKbDIt = false;
    int UgtqVgTNPChuls = -1072358494;
    int thrEUvOMJWqzHi = 1440727510;

    for (int uYjzfXvOQTHER = 634992862; uYjzfXvOQTHER > 0; uYjzfXvOQTHER--) {
        UgtqVgTNPChuls *= UgtqVgTNPChuls;
        thrEUvOMJWqzHi *= UgtqVgTNPChuls;
        NRZRvTwcUoOioCGQ = ! cyJiKPKbDIt;
    }

    for (int QtRAYJaMNbfbKj = 725976606; QtRAYJaMNbfbKj > 0; QtRAYJaMNbfbKj--) {
        continue;
    }

    return MRlYZNYgHhQdc;
}

bool oddtdFkdxQOcYI::oqidNlKX(double BKEZxmBsKfQcQ, string goXTdiX, double QevKsYRDUeUzIuM)
{
    bool mcCQQdHvNCXVppq = true;
    int DYypJTrSgjF = 1002746346;
    int opSnUcTdChNZiP = 2135091042;
    bool fDpcLcWxOD = false;
    double LdfCuffFBOzCr = -662426.6705509896;
    int FUKmsSgoW = -1088882516;
    string dAvKIAK = string("XedGSIvyUtBcNmYdwxMhsSVwLFsYWRTItvuodBmDhnLKkBmVPybdZVzXlYEEOzHxyCQpwQKeekIzceZceEWZirZOoKIqfTmUQNztUwJZUIfqhxDknGguoAnZZZKymxjVvflWFWGCNQgeYZVxjoXcnSssFYDmTDsZeFiZGCxNBYgXCcOgBoawzDUwQKOrBrwxzdkxpjdVoMgUdnYnzbjJsrdQnHqctQpGyDriRXszTIh");

    for (int UwHOsccUTdetawQl = 1704753558; UwHOsccUTdetawQl > 0; UwHOsccUTdetawQl--) {
        LdfCuffFBOzCr = LdfCuffFBOzCr;
        FUKmsSgoW += DYypJTrSgjF;
        dAvKIAK = goXTdiX;
    }

    for (int oVwjTF = 1443904476; oVwjTF > 0; oVwjTF--) {
        continue;
    }

    for (int uLbGjlURXwF = 63181904; uLbGjlURXwF > 0; uLbGjlURXwF--) {
        continue;
    }

    if (FUKmsSgoW <= 1002746346) {
        for (int RWsPzINvmROl = 310532461; RWsPzINvmROl > 0; RWsPzINvmROl--) {
            opSnUcTdChNZiP /= opSnUcTdChNZiP;
        }
    }

    return fDpcLcWxOD;
}

int oddtdFkdxQOcYI::wfhvJkwyk(double IYFCRgNSqgQeWK, string jZduaCLzxoagIp, bool UWouXPaFX, string UiQRN, string Rncus)
{
    int gRHBxIIAyBs = -970673484;
    bool tlUJCgmVQJM = true;
    bool LKSNnkdxREwwobs = false;
    double MtrSNpvrNiCnlj = -53226.363752198275;
    string FyRBvytjDh = string("sTIdOyRumglReANJnIFuHidfAYSetMztxmlFCqqwUmSLerSJCeSKVtsFReTWhSo");

    for (int yMWpSJIQDTXe = 791294269; yMWpSJIQDTXe > 0; yMWpSJIQDTXe--) {
        FyRBvytjDh += UiQRN;
    }

    if (UiQRN == string("xhFLVsubuWhXeCzIWfUnQpEvwyFWVcEQYrbVZviTyTEASKPXBYrBsNWzmkCXdaOjEwuMJMpkKKQfLfNDEbWjVTUlZeHmshwHtRzHQwUiFPsiqprJiZrNjWqJRkVnudSOxAMChUgfayzFBfyDVBDLAfiHbOfwsAgnWvdXBIsrbNhFCyBsfic")) {
        for (int CzpnVufsRG = 377839559; CzpnVufsRG > 0; CzpnVufsRG--) {
            UiQRN = UiQRN;
            FyRBvytjDh = Rncus;
        }
    }

    return gRHBxIIAyBs;
}

double oddtdFkdxQOcYI::WEmpoGemX(string TWBbTuuSK)
{
    int oCblFOaNUR = 437055118;
    bool rQhUmWitAKtbE = false;
    double wZRmmwxCb = 539099.4892241488;

    for (int mjBTxtNEwD = 299133182; mjBTxtNEwD > 0; mjBTxtNEwD--) {
        TWBbTuuSK += TWBbTuuSK;
        wZRmmwxCb /= wZRmmwxCb;
    }

    for (int YvZELGcsyjke = 491205401; YvZELGcsyjke > 0; YvZELGcsyjke--) {
        rQhUmWitAKtbE = ! rQhUmWitAKtbE;
    }

    for (int bcNacyGoCCPCSsG = 217049899; bcNacyGoCCPCSsG > 0; bcNacyGoCCPCSsG--) {
        continue;
    }

    if (wZRmmwxCb == 539099.4892241488) {
        for (int jRZAfvBKu = 786321049; jRZAfvBKu > 0; jRZAfvBKu--) {
            TWBbTuuSK = TWBbTuuSK;
        }
    }

    return wZRmmwxCb;
}

int oddtdFkdxQOcYI::RxAQYOlRGfpZQ(int bGGlWv, int NPymdMm, string duSHBxgKSvxBClzx)
{
    bool wbtWPXtjyBBD = true;
    int ZOVpDUjf = 600835797;
    int yxkHbFcskImXnY = 231979453;
    int WBtfRSyIZGpJB = 1563329406;
    bool TPgLcw = true;

    if (TPgLcw == true) {
        for (int eAAFGMXUWauUME = 1990628722; eAAFGMXUWauUME > 0; eAAFGMXUWauUME--) {
            wbtWPXtjyBBD = TPgLcw;
            NPymdMm += ZOVpDUjf;
            WBtfRSyIZGpJB = bGGlWv;
        }
    }

    if (WBtfRSyIZGpJB > 844689544) {
        for (int JXgNNR = 1239662941; JXgNNR > 0; JXgNNR--) {
            bGGlWv += yxkHbFcskImXnY;
            duSHBxgKSvxBClzx += duSHBxgKSvxBClzx;
            NPymdMm /= ZOVpDUjf;
            NPymdMm = WBtfRSyIZGpJB;
        }
    }

    if (NPymdMm > 177141313) {
        for (int SeHMc = 1690717499; SeHMc > 0; SeHMc--) {
            yxkHbFcskImXnY -= bGGlWv;
            ZOVpDUjf *= ZOVpDUjf;
            bGGlWv = bGGlWv;
        }
    }

    return WBtfRSyIZGpJB;
}

string oddtdFkdxQOcYI::ygVEenzG(string ufuZZyXJIPnuV, int QKcBqspUz, string aeiTshknYif, int flvgveVraGmCCb)
{
    double MEMvbVN = -791478.4498798744;
    double HuhHiG = -704756.0796056176;

    if (HuhHiG == -791478.4498798744) {
        for (int mpOPFVCDJHDRL = 1891793851; mpOPFVCDJHDRL > 0; mpOPFVCDJHDRL--) {
            HuhHiG -= HuhHiG;
            HuhHiG = MEMvbVN;
            MEMvbVN /= HuhHiG;
            HuhHiG += MEMvbVN;
            aeiTshknYif = aeiTshknYif;
        }
    }

    for (int NdiWXZnCj = 2040955611; NdiWXZnCj > 0; NdiWXZnCj--) {
        aeiTshknYif += aeiTshknYif;
        QKcBqspUz -= QKcBqspUz;
        QKcBqspUz += QKcBqspUz;
    }

    if (aeiTshknYif > string("EXJpOShozghqfcCsGnnlkAagLGJbZgbSROdiiycEQBgMZsReLFODrObHYRrcdVhGhuFZNhlvpyREjcTzyUXDxhspfVwNiWGDXDjexckEnwamzdzMZeWdNcAUIKkizGssuSOLjjWxyuFLTuWMuldHYgLgzNaEIoDSraGtZWhnWhmtfKZhadGdIjVgthDWVlfDwduqgsJXRvHVKqcFeWRcmtatERUmHUXDGDjEHBKupvoyiOhfPlkNPVLRzPbS")) {
        for (int nMFqoQBwBcJ = 1561658538; nMFqoQBwBcJ > 0; nMFqoQBwBcJ--) {
            continue;
        }
    }

    return aeiTshknYif;
}

void oddtdFkdxQOcYI::pnNBIydOliTNFs(int HGuNUGsuOtSN, int fHOVUBFLRu, bool oUhuzQMXPJRqK)
{
    bool XtEFDALIqsTLYNDl = false;
    string quMHyqsimi = string("ReVUxSgBbfgtaFoPlNeGbnMXOgsWHWqVuHCzkhLQTFJolCBEoPfsUPrXFFOOXMJOFPYlcjlFeFuGuDAhfglkioPBcivTDOHQVjcwtGoPyInjsGfvjSigxPouqYAdJoUWxkCxrMhGTHHhOZKmjPbnJzlNRiwcscLJHzCmX");
    double RDhGv = -867154.6712065024;
    string UkLPPav = string("TzExgtnWeVuRNwRLcBYRTmqyUbOHJiyYoAkpkDflqJFIjLjBSlaODfbvABZQCQhmFrZGOfTeVTiWRIscVxWVUMHMxQUyQoywxHXSHqMMBjpJnFldOXpYJ");
    bool afyLqqQnWyZQNaYQ = true;
    double cSczzRaAVTyD = 837365.8721178254;
    double duICatmOyDMNEuk = 382437.37837779283;

    for (int tVgqprzXdFHhANT = 869947136; tVgqprzXdFHhANT > 0; tVgqprzXdFHhANT--) {
        afyLqqQnWyZQNaYQ = XtEFDALIqsTLYNDl;
        XtEFDALIqsTLYNDl = ! oUhuzQMXPJRqK;
    }

    for (int uUsLBD = 860700148; uUsLBD > 0; uUsLBD--) {
        UkLPPav = quMHyqsimi;
    }

    for (int XEQlKTLZqzllm = 2045293515; XEQlKTLZqzllm > 0; XEQlKTLZqzllm--) {
        RDhGv += cSczzRaAVTyD;
        UkLPPav += UkLPPav;
    }

    for (int QRtLeoIle = 1750171646; QRtLeoIle > 0; QRtLeoIle--) {
        continue;
    }

    for (int GUcwYKyBsG = 428534510; GUcwYKyBsG > 0; GUcwYKyBsG--) {
        continue;
    }
}

string oddtdFkdxQOcYI::znjYIKlfYNCmzkAn(int yOkGavJsjxO, string CleBRCKhjn, int qvioEOUoyOz)
{
    string ZkWbbg = string("CAyHuKrdCpFcjmRxdxeEEVsQNboETZgUZq");
    bool xSjcXlqSJvoym = false;
    string MUPuZspVG = string("FEpfPKuAvrfiDGFBsGLgRsXuwXfAMiGyOKXgFmwetkhGWJweIFeXXGsGfYFmGCENlnpYrCJRHvBLTmtjfOfcqngWOmkrEzlKCrEYTiieYPPtkBgVSCsOAtSHHXVUOcqLmCMAMFfUvdPoAlCBRbyJuPxqkpxShYbPfDpbkoeltaUkdOhkyy");
    string smWQjdBicQYfoyL = string("ibVHFUkohubFicBpxhUefKpPrTwrffOyXxEqsWu");
    int BDLSOLsn = -1622024912;
    bool UkJVpcdVLkpR = false;
    string ZUAlVdCTvaKJl = string("UMGVdSmJsWRvHwJhMNkuzzcoFjSaijtRfeUgJgYPecVIlPUrYdjNrVOCrMMKNORStvbEnhLQgZZVGyJTlEfQVzRJwIiONGoXYBVNfqqIwAeXuudvPkpMNTIFqvGpksgGjQZwCTSirrbKLVZcuFhVizDPaXjIvrPtXyMcpKKigzxbJtERmQiASWWdiZRmXGuvGFSZvAhBQfEdztCDVDEssTbiDfNILHREtdKoIJJRzwEaoJzUzWANWUolv");
    double hnfkyWlr = -208844.0326136343;
    string pkzAJmWwcPDdC = string("RxiRfkVokMwCCrNbkLILkmBqnWVWwLLqKlkuysoGlErUjzSHsmBKHTvjhBgUFJIpaRnEZLgVrPnQRqBTZOUOexNjRWiTXkefvrPwdJFErnWTSBiZKOtELoDlwVLBucrWCpcFmqBRSZVWDmSjannYefvzYEwISuXhoeJGDPQAAlmOxYswqEcXDtaxQfEfefsVilnRpihatzheytAVNuVnkwjpbALs");

    for (int kpIjxidspoxJ = 509689751; kpIjxidspoxJ > 0; kpIjxidspoxJ--) {
        ZUAlVdCTvaKJl += CleBRCKhjn;
        pkzAJmWwcPDdC += smWQjdBicQYfoyL;
        CleBRCKhjn += pkzAJmWwcPDdC;
        UkJVpcdVLkpR = xSjcXlqSJvoym;
    }

    if (MUPuZspVG >= string("ibVHFUkohubFicBpxhUefKpPrTwrffOyXxEqsWu")) {
        for (int WSrBqZDkRolY = 308244089; WSrBqZDkRolY > 0; WSrBqZDkRolY--) {
            UkJVpcdVLkpR = ! xSjcXlqSJvoym;
            UkJVpcdVLkpR = ! UkJVpcdVLkpR;
            ZkWbbg += MUPuZspVG;
            ZkWbbg += ZkWbbg;
        }
    }

    for (int jZgGZpqTXRejRERQ = 2034922009; jZgGZpqTXRejRERQ > 0; jZgGZpqTXRejRERQ--) {
        continue;
    }

    if (CleBRCKhjn >= string("RxiRfkVokMwCCrNbkLILkmBqnWVWwLLqKlkuysoGlErUjzSHsmBKHTvjhBgUFJIpaRnEZLgVrPnQRqBTZOUOexNjRWiTXkefvrPwdJFErnWTSBiZKOtELoDlwVLBucrWCpcFmqBRSZVWDmSjannYefvzYEwISuXhoeJGDPQAAlmOxYswqEcXDtaxQfEfefsVilnRpihatzheytAVNuVnkwjpbALs")) {
        for (int TmQNdXI = 665035016; TmQNdXI > 0; TmQNdXI--) {
            CleBRCKhjn = MUPuZspVG;
            ZUAlVdCTvaKJl += ZkWbbg;
        }
    }

    if (ZUAlVdCTvaKJl != string("ROACMXmpEEEgRuJnSfCwxsLbTSEOGemRledilQwnycxDlsjNTXalGVXNZVRJcRvRwsElCfbWtWKmGxVihUCHzNVlAoYtHuPOvREPZwevUdgrbdHxUjhZSixiZDBXwjqiscUdtsKAfSbLiMZJjddSCgLVPervPgNrQWKuXdcWkcNNXfcwzhrWsMUXxanIVfR")) {
        for (int RLoHQDkbOXihsO = 1486853192; RLoHQDkbOXihsO > 0; RLoHQDkbOXihsO--) {
            ZkWbbg = smWQjdBicQYfoyL;
            pkzAJmWwcPDdC += ZkWbbg;
        }
    }

    return pkzAJmWwcPDdC;
}

int oddtdFkdxQOcYI::YJXMSnABZM(double bmNKWOHQGQVN, double uHnuPugvmfliFKp, int tvtMBH)
{
    string GfiEoXmEF = string("tYUaMqmAhVosTkIRNjZwsIwyVEpALQotrSYcJNgxTMemkTXOepBNtOjRwzYYMvECODLYIhJVnScHndQkzGmkJcaYLaClaURywMGYJQdoFzfvwneJlXHmdJQiKFRbiAjWCpIVUDkCLIWyGlmtGDuITwaSwZLCGMOsQdIHmojvGzvSulQKeLJomuvqxbCRlicAkypiaHtZFzcMDixyVadVzizYbOuTMpctMrgPVpUtGEW");
    int XcLWmepF = -1057782715;
    string GjTUIgdhhyyvU = string("YhHVrqPFJUtHwBTmhFPkzpDfYOUqcdOuATYftDTVxVOStydYVFQmHtzUglnOkCpMpbNKhaNOsxROylcOfgWulTDEhNLQMZTulcfVnxHbGZrUeRHrlTBGIGqliNldqNQdTfldxULFrhsicSTjvseYobfzevhRwsnfvatMNWVeVvCGjyIXKuDCljHzIDMMcKOhAhlfgvUAeDkMNBpRxBQVYIVtkeZTpPDWnZvFauZJQBMlbpvY");
    bool azrwBoZmzEJ = true;
    double IRRBTWAJNYUGZka = 876013.6797452219;

    for (int CrmSjl = 471635654; CrmSjl > 0; CrmSjl--) {
        GjTUIgdhhyyvU += GjTUIgdhhyyvU;
        tvtMBH += XcLWmepF;
        XcLWmepF -= XcLWmepF;
    }

    for (int GNJTttJGEVvSq = 1314992766; GNJTttJGEVvSq > 0; GNJTttJGEVvSq--) {
        tvtMBH += tvtMBH;
    }

    for (int iZWmJ = 1489683100; iZWmJ > 0; iZWmJ--) {
        bmNKWOHQGQVN *= IRRBTWAJNYUGZka;
        IRRBTWAJNYUGZka /= bmNKWOHQGQVN;
    }

    return XcLWmepF;
}

void oddtdFkdxQOcYI::dhsZIvJoWpVpouZy(bool oaTadWgo, int kFHvEJA, string NUPdLFSe, double ulNniDrcaOT, int qOTPkubJRcHsNyay)
{
    bool cFMrsyBftPPJ = false;
    double ZFoDRHv = 167005.0445818305;
    bool hFtCa = true;
    double fJGjaa = 287457.00110044936;
    string jMMSfgRhmmpYW = string("ZAeGWHiBPFqsqwccLOUPWyYOaEZCMMGytYphlVAumqfyBwFZbQQudsmgCXeHjvMrCCBcuzvkhEkOhvzluincNkqeaOvATchdglsMhjdJexUXOxQmnLAJopBR");
    int tXjJo = -1784064296;
    double RNIQKfOUOBiWkcX = 748094.6375935334;
    string ulXnMEB = string("tlPnrqaRFKrAL");
    string QwzwDBEkWwUVde = string("ZMVcdntBgGGaAcvGFBZZEloaJjIfwjhuGLLFByzVMSCuCJUpRWPoZcZhKjjKzkzqfKXbBTHVtpWmoPzTBqoKjdmvNZntebyiSMpzwxGMALZrtlUurgcCGvZFphhWXtQAjMFBRSmKREpOwkJWJsnZAlWLzLjfVnzFUWLvlPferpFmmZiEIGfMOtZcqyHxmlOFwsNaodBYxXYcjyfJWjMnKJl");
    double mJUGCADcoDqu = -649090.6606700042;

    if (cFMrsyBftPPJ == false) {
        for (int XMrDzbaIzadhFq = 485123058; XMrDzbaIzadhFq > 0; XMrDzbaIzadhFq--) {
            oaTadWgo = oaTadWgo;
        }
    }

    for (int SpNAvkK = 768471301; SpNAvkK > 0; SpNAvkK--) {
        continue;
    }
}

int oddtdFkdxQOcYI::CBrefHrzDLYAvsxy(bool IFtsVbzaVYUN, bool gnQpnGdnNzPMYeDH, double jeVVMVJmrvEXITx)
{
    int MfHPcPACvoawf = 1168256841;
    int piTBDVWfvE = -212455809;
    double qrraP = 82382.83198387576;
    string GxYKcxhOesaZVFm = string("Zi");
    string XRRKSGckQWbRvM = string("QXHbghKLibJHnOWUHrnJZvHpEPISrChHydrvrJQxnHOrhWtMQWpxnABASoaLvRHxzlEFQSloIMmtWQHmSYFlBlzsftCHdquEknNYyZXRINzBIejnNSwoXQTUQmyTFVYLjatAiIAfZxCEpzPWPOoTiMmKJjRRDucTIVjqytmDyWoDCXcoAfkfnMyKnbNRwaIuegZumIRwLRiLKiSlmzwIdESNf");
    double ZdmvBh = 804496.3065054121;
    bool NPXggI = false;
    int KeuEYjMLfUcR = -1422615025;

    return KeuEYjMLfUcR;
}

bool oddtdFkdxQOcYI::NyTPMLWV(string aeQNKRmwJpRcriv, double ozoxaVvyf, string GJXMrPwGq, int VcRCrmBeEZSBr)
{
    double bqJQfQvVj = -903786.9063224446;
    double HRkdnSOyBnJcbeKB = 601737.5176665158;
    string qyvBGsYf = string("QPxHdhVBECPHMoCtVVKsJFyuMAjOynqCqbmLcdtzHOyNaIyueNWUhXgvmcYglDDJJHJrQvuArHmDpaJeqaYCIfQZYaRpHIulgEeuNVkFIVyLwweBILDjPsZaAGKSBLXFTVpDBayzsSRmSHipNBgzlGTbSBXZGAyrZgGiPvAEncfKBHLPhlXALlljNKIrhXswh");
    double oRjvjlSeZHEIx = -573565.3824525055;
    int jXrGppVP = 615771358;
    string YSJChTrrs = string("qwAxiCjAPdpxkPtslwyiDwuifCVffIXrqrjofwTpFsuwtKeHMWdDoEMDeyMlEsNelyqDxHPKBInjXfgmuaxSfwgWpgrGyjxHaxPSzelYQdfUFEhBfeMVKaSjTthtuCpCBOuoUozwGdRmbQtXKIyJTtICgTfbopoHfAoTQWyAmcPcigIChkaUxHoML");
    string rsWAf = string("LRAqtQYKEHPfIQsbrgSylUpJuXtADeoYhbKrfhATjoPrjDgFYuimNEHvKmwnJFdkoLxjHdQgfnPhpwaTwUDEnqxNlqXGAPNaKtTcGoJNiXumgZtnVVyaeXHVnjcnJlQoMxJhxiCaXGoLNQivxOeLMPTcjQeOqqszZFZglc");
    int wNmugtgsEwFOeOU = -1501976211;
    bool eKcPTDOw = true;
    double mVJSUittzNajZ = -129301.55232945971;

    if (GJXMrPwGq <= string("MpnxUoxgEkeDmnNEocPUdeViCOzaVdKHNkgaEoMBwMUAteShrOqdsEPnpSedBnJqIAzvitzRAgpRbfgmOPqRbqDdixdBIFnkDIRDLbmZUqJpxvPYRsamGjfQnIcPGXJgLExnxiPCytyUUZMPHEPRCJVORLhbMqTWxmOnjGzMwHRy")) {
        for (int qPxfDuBNAFeoLLeE = 1361170924; qPxfDuBNAFeoLLeE > 0; qPxfDuBNAFeoLLeE--) {
            continue;
        }
    }

    if (HRkdnSOyBnJcbeKB <= -129301.55232945971) {
        for (int pQpHzgQjCVzSbQs = 1839213198; pQpHzgQjCVzSbQs > 0; pQpHzgQjCVzSbQs--) {
            continue;
        }
    }

    for (int AeNJxR = 1096708198; AeNJxR > 0; AeNJxR--) {
        rsWAf = aeQNKRmwJpRcriv;
        oRjvjlSeZHEIx *= HRkdnSOyBnJcbeKB;
    }

    for (int WbshljAoY = 413412503; WbshljAoY > 0; WbshljAoY--) {
        qyvBGsYf = YSJChTrrs;
        wNmugtgsEwFOeOU *= wNmugtgsEwFOeOU;
    }

    return eKcPTDOw;
}

int oddtdFkdxQOcYI::kGzDFBkxRT()
{
    int AajQagFNODIU = 1052204397;
    int sKjsFjdoYJq = 883527605;
    bool BzfFplFuhHHx = true;
    string usJOt = string("SsnrjRDSszpqYatXkgKxXutVtDrjwCFveQPWitYqoJPbfNlviYCHcedqCtAutAEnzHsPSECxrVDCuzSQZzQNFWwmBpBy");
    bool HXajqkCot = true;
    double lqaIYmWSFPwtEw = -118054.66139321207;
    string fMFAwf = string("xZuMDcEgcEZnYRnsDKESqmupOmFENZqQmzQUnfahmEgmEnwfqXhCPixiBhzypdsDCWvWsNGktUMGKqJemYXuTFrUFLFCDXkEkacZLcHYFessqSuPlEolCdqVHIHNLdrRyzOCBqyQxYze");
    int qfNvlF = -316829471;
    bool fxtpgCrJja = false;
    int ejTuzmYF = -152647285;

    for (int bLAcLkJnP = 148151104; bLAcLkJnP > 0; bLAcLkJnP--) {
        BzfFplFuhHHx = ! BzfFplFuhHHx;
    }

    for (int JEXkvAJLZo = 208946572; JEXkvAJLZo > 0; JEXkvAJLZo--) {
        BzfFplFuhHHx = ! fxtpgCrJja;
    }

    if (HXajqkCot != false) {
        for (int IEXCZqihpfqTHctM = 382859257; IEXCZqihpfqTHctM > 0; IEXCZqihpfqTHctM--) {
            BzfFplFuhHHx = fxtpgCrJja;
            fMFAwf = fMFAwf;
        }
    }

    return ejTuzmYF;
}

oddtdFkdxQOcYI::oddtdFkdxQOcYI()
{
    this->FQvXhJvkxvacHZ(-775228.7995547252, true, -144538.58468455292, string("JTSsuNAfCBWIMGCqdhBHJmuJlkRQEIfxcaQqokKilmeGIJLdozxYQNJtvnKOzoGTlGtFUAsXGhMomTMRysobifMeugpNrxFdGsHpIqLAFThRBgMwsUSJxnYrQcnBabvJooUBpcxbPgTYITEMCUbSQoTwaezGNdoFUMYexUAMJRGOcGuUlAookvYKpPWbGMtwOMfmsDusOeUytjAGA"));
    this->apeTu(523990620, true);
    this->JGYGiayUVJsH(-690262.5452703666);
    this->oqidNlKX(531203.0667660803, string("ZPl"), 739433.5921022272);
    this->wfhvJkwyk(633866.8165765917, string("RxSiRuyPAYCSPGIushjKrPGoDqwXQUTBA"), true, string("xhFLVsubuWhXeCzIWfUnQpEvwyFWVcEQYrbVZviTyTEASKPXBYrBsNWzmkCXdaOjEwuMJMpkKKQfLfNDEbWjVTUlZeHmshwHtRzHQwUiFPsiqprJiZrNjWqJRkVnudSOxAMChUgfayzFBfyDVBDLAfiHbOfwsAgnWvdXBIsrbNhFCyBsfic"), string("zTirJrafnAJxAQfPZgMEgYBveBSkKVuyebpZDnDZEfQoIxzXAdUMIImArXxdmtsQgjMpSNYRHCNSDMUpqygjQWqzMVcLRg"));
    this->WEmpoGemX(string("EiGFzTsnkOnNjgnerRQuCGXiiNyFxaDpskdUlGsKVWGDjBMzWmsAXlBQlDcHjcLvJEYKTsTTZBdXNOUYizBgRYPbzbcZrCKsNtwyrBlWfadDGDjbLtNWfjvbyBCztoGAbktZRLWZgyYVXKskEVlD"));
    this->RxAQYOlRGfpZQ(844689544, 177141313, string("KnQkbGxPczNnLCYhjqdkXDxXBcNrGt"));
    this->ygVEenzG(string("USNcmzinAjSiLwRwpHtPUJQVTpdpiXeRndBUbIUMApLuMdwkLlebfkzQDNyoAiaTARcZqObkDfnnbvlkrPgPPZEUIejGjKvXGgUObzPmYDzBUKpVYewsoiQpZqgPYAnvWYjoOGNAfdlltbxuaFUULKzanadgEivkOsCDdGIjzYnCIhJdFlzIArPyZQddx"), -1235531286, string("EXJpOShozghqfcCsGnnlkAagLGJbZgbSROdiiycEQBgMZsReLFODrObHYRrcdVhGhuFZNhlvpyREjcTzyUXDxhspfVwNiWGDXDjexckEnwamzdzMZeWdNcAUIKkizGssuSOLjjWxyuFLTuWMuldHYgLgzNaEIoDSraGtZWhnWhmtfKZhadGdIjVgthDWVlfDwduqgsJXRvHVKqcFeWRcmtatERUmHUXDGDjEHBKupvoyiOhfPlkNPVLRzPbS"), -871564104);
    this->pnNBIydOliTNFs(543129296, -2133097009, true);
    this->znjYIKlfYNCmzkAn(-1319588144, string("ROACMXmpEEEgRuJnSfCwxsLbTSEOGemRledilQwnycxDlsjNTXalGVXNZVRJcRvRwsElCfbWtWKmGxVihUCHzNVlAoYtHuPOvREPZwevUdgrbdHxUjhZSixiZDBXwjqiscUdtsKAfSbLiMZJjddSCgLVPervPgNrQWKuXdcWkcNNXfcwzhrWsMUXxanIVfR"), -212666105);
    this->YJXMSnABZM(-852221.0230117721, -81925.13134478375, -960186826);
    this->dhsZIvJoWpVpouZy(false, 737176958, string("aCJBCwMfAaXXYWkLiqiOMFeQMgGuJzIjWRmYwRaQRHpBZefrmyDRqRmxajfBnBrXnWSWRnbhrNIKxPz"), 190652.6273575221, 412783551);
    this->CBrefHrzDLYAvsxy(true, false, 384391.68399735284);
    this->NyTPMLWV(string("EPpjdsnmIHCmStsIeINFaGWHteuBaRoJUwntNeooOerLUsKeNSuJaZLeEfhGOSlcZsLBvlYxIVMbAvJLGImdZfUbPmJnFKPAjkFsKlGlJdzIdHNj"), -887158.2336362767, string("MpnxUoxgEkeDmnNEocPUdeViCOzaVdKHNkgaEoMBwMUAteShrOqdsEPnpSedBnJqIAzvitzRAgpRbfgmOPqRbqDdixdBIFnkDIRDLbmZUqJpxvPYRsamGjfQnIcPGXJgLExnxiPCytyUUZMPHEPRCJVORLhbMqTWxmOnjGzMwHRy"), -24589759);
    this->kGzDFBkxRT();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EXbucrNQHw
{
public:
    string lfpDsxufsTFljLvV;
    int lQNeYfyMSqs;
    int mxdXIZDIsQDDfrJ;
    int vApgOFeK;

    EXbucrNQHw();
    bool KyrGEezcOACcwow(string rPKkkvOKJ, bool ghefrSIyX);
    void aUlqlGSGFm(string LyfsNACwwU, string rBHVsvKU, double ayEil, double FvtAZmChRiaORbV, string UksfUpGVifZvvjXi);
    int kYtoTAb(int zeTQCpb, double faTjYfSN, string dcJjBqGeiJBJUyUS, int sKopZQ, bool nFrxdRBbI);
    double DQGDMypKhgeNgsf(bool UYxfLngGJPUnuAfy, string XuuoETzMhIbYzaNi, bool kpUck);
    int GnfpobhKmiUygSW();
protected:
    bool ujrtNEEVdeq;
    string ngCVIzOgAYjDZks;
    double AphAbXBoWuK;

    bool NMnCEyizMR(bool xzmTLgUGriEhMg);
private:
    int IAbsGRe;
    int luWaUNq;
    bool qIxbzjkGfmo;

    bool wtrjrAnoIAl(bool UOaOsRDbAOX, string NRAId, string qEIDKWoh, string mjtAVJcijyevir);
    double pbyeoZqbmZkZ(int tSxxvxr, string RVnaV, double qhpKjSHJp, int PYjkAmKiuGr, bool twuedaJJSbEjpoc);
    string JGSQLZeKWZx();
    bool xbtsiwXqxdzpTZ(bool sdzNmomDTWjzU, bool BdnCIIVjUgD);
    int aejzABHhXsC(double CdZnCrWpQbyaTbhz, int ronkQfxR);
};

bool EXbucrNQHw::KyrGEezcOACcwow(string rPKkkvOKJ, bool ghefrSIyX)
{
    string vTDDUZZgMpw = string("VWRjaViUZftnFOTjSBXCBQWhHwcEnCuEVFiNGIWObVrsPZUEUknIEuXWjjAhjOtuucxwiSOJkpTWEuIWhQdFXogzwJORzaXzvDDaLwjRuEmqpCpcDqQENOquYrRXtyxaQqSPPcBMXUFZehgntCudBsozadTtbJDySnUEWqunzZosjcfmYJiCbchnnVqMCoBwCrLImWgDbhpcWnBmUrxoNGIqmKyZAXNFqSSkbNM");
    bool QeLCFg = false;
    double HhjDqEPMPrVBBXLZ = -355623.6416694113;
    string JmMyIGRt = string("QPGEGEEovkZHacxHbESzwfrUfyhTQDyOgpiRieuibVbRtIVEowWDTrhSwdbbJJLFHYVhWN");
    string iFhzJA = string("SVahL");
    bool aNdbjwFtanTvBUXl = true;
    bool YphjPFBIdj = true;
    int zgCxEOUknCEOZYu = -1980230256;

    for (int NCfCEi = 325471103; NCfCEi > 0; NCfCEi--) {
        vTDDUZZgMpw += rPKkkvOKJ;
        QeLCFg = ! YphjPFBIdj;
        iFhzJA = rPKkkvOKJ;
        YphjPFBIdj = aNdbjwFtanTvBUXl;
    }

    for (int OdaHwmrYhYJqV = 7414468; OdaHwmrYhYJqV > 0; OdaHwmrYhYJqV--) {
        aNdbjwFtanTvBUXl = YphjPFBIdj;
    }

    for (int OdHQc = 1672946172; OdHQc > 0; OdHQc--) {
        aNdbjwFtanTvBUXl = QeLCFg;
        aNdbjwFtanTvBUXl = ! QeLCFg;
        QeLCFg = ! QeLCFg;
    }

    for (int ekEGCHBknHjwkn = 1873584568; ekEGCHBknHjwkn > 0; ekEGCHBknHjwkn--) {
        continue;
    }

    for (int fOtmT = 1809955863; fOtmT > 0; fOtmT--) {
        rPKkkvOKJ += JmMyIGRt;
        iFhzJA += rPKkkvOKJ;
    }

    if (ghefrSIyX == true) {
        for (int knYlLDCi = 706856143; knYlLDCi > 0; knYlLDCi--) {
            rPKkkvOKJ = rPKkkvOKJ;
            aNdbjwFtanTvBUXl = QeLCFg;
            ghefrSIyX = ! YphjPFBIdj;
            vTDDUZZgMpw += vTDDUZZgMpw;
        }
    }

    for (int TIQvHTqZnnCx = 1671855783; TIQvHTqZnnCx > 0; TIQvHTqZnnCx--) {
        continue;
    }

    for (int uoUwGPJug = 907240883; uoUwGPJug > 0; uoUwGPJug--) {
        JmMyIGRt = rPKkkvOKJ;
        iFhzJA = JmMyIGRt;
    }

    return YphjPFBIdj;
}

void EXbucrNQHw::aUlqlGSGFm(string LyfsNACwwU, string rBHVsvKU, double ayEil, double FvtAZmChRiaORbV, string UksfUpGVifZvvjXi)
{
    int aAgqC = 908239601;

    if (UksfUpGVifZvvjXi <= string("dlaXBLoiZrXzvedAqvXhFaZEBlleApVGVmAtMVvHMxAx")) {
        for (int wZHNOB = 388535925; wZHNOB > 0; wZHNOB--) {
            continue;
        }
    }

    if (rBHVsvKU < string("dlaXBLoiZrXzvedAqvXhFaZEBlleApVGVmAtMVvHMxAx")) {
        for (int aEOcwzUJguIsW = 1908582826; aEOcwzUJguIsW > 0; aEOcwzUJguIsW--) {
            LyfsNACwwU = UksfUpGVifZvvjXi;
        }
    }

    if (LyfsNACwwU > string("dlaXBLoiZrXzvedAqvXhFaZEBlleApVGVmAtMVvHMxAx")) {
        for (int IlxZTetReY = 944402900; IlxZTetReY > 0; IlxZTetReY--) {
            rBHVsvKU = rBHVsvKU;
            aAgqC = aAgqC;
            UksfUpGVifZvvjXi += UksfUpGVifZvvjXi;
        }
    }

    if (LyfsNACwwU <= string("ihVKYVhRBshkaXNtqLWYmamvBiayaDHiKIZeBuIewBFbpilsjOCERShWYvgdbOnUsAjTojlztgXoXlyXBaLMliloUPvjvdPggWHNEUYDyBtoNzjavlKkwmnIVRYeuXERDJawDOSoCwxPNjoufzZPHUqpYrtcEQeygxVVaZjBkHCyBTjpsgyIurYyQh")) {
        for (int LausDGonOjmfaNrN = 865482314; LausDGonOjmfaNrN > 0; LausDGonOjmfaNrN--) {
            UksfUpGVifZvvjXi = rBHVsvKU;
            LyfsNACwwU += rBHVsvKU;
        }
    }

    if (ayEil <= -1488.0568368806423) {
        for (int SwxLcAgUxlL = 1378316974; SwxLcAgUxlL > 0; SwxLcAgUxlL--) {
            LyfsNACwwU = UksfUpGVifZvvjXi;
            FvtAZmChRiaORbV /= FvtAZmChRiaORbV;
            UksfUpGVifZvvjXi += LyfsNACwwU;
        }
    }
}

int EXbucrNQHw::kYtoTAb(int zeTQCpb, double faTjYfSN, string dcJjBqGeiJBJUyUS, int sKopZQ, bool nFrxdRBbI)
{
    string eQtehmXwEcslA = string("vnxggWtlnLOFLDwEv");
    int pZvEdH = -1922273123;

    for (int cEugwMPVbyOlF = 1715194016; cEugwMPVbyOlF > 0; cEugwMPVbyOlF--) {
        pZvEdH = sKopZQ;
    }

    return pZvEdH;
}

double EXbucrNQHw::DQGDMypKhgeNgsf(bool UYxfLngGJPUnuAfy, string XuuoETzMhIbYzaNi, bool kpUck)
{
    int PfrzJQNOfWqwTGis = 1480540080;
    string UKYDVfX = string("KLQPoTeWssLHIiFadeTBLIqSwuiMMgnemUUHXEjZuUvXfwylvKacABduFMAltUcBLHeEmKnTJwcVsTJhqeYWptYkAEArXhMuGpQZ");
    string uyYPiEW = string("mPrKDoUZUHUxfXfPsHUbxhPxsBeVeLWrKjWNBkyWkvKewQJNFIjqpMgGLXMtHHRqXbCFsSSBoZRuHINTPCenVDECNjiUZGAIyoJvXWgIHhwfKNeOCJBtSBJFkLYqSgycpsLoVuhvyrpZCLaEdJbpPHODsDgAkTkSLDoHbmElATswuuVhqfgHINwTRJhVubMlHOSAtjppRpKozdLwOVHLKWFEfMAVkmBchqATAx");
    int LFJixanGGRpoJ = -506659095;
    int JOtFXtoUbuIUDzOP = 1289846316;
    bool QQDNKZv = true;

    if (JOtFXtoUbuIUDzOP == 1480540080) {
        for (int ubZKxkdThChqTGMP = 1440417723; ubZKxkdThChqTGMP > 0; ubZKxkdThChqTGMP--) {
            LFJixanGGRpoJ *= LFJixanGGRpoJ;
        }
    }

    for (int rUzuDkDOgvp = 1179019654; rUzuDkDOgvp > 0; rUzuDkDOgvp--) {
        continue;
    }

    for (int JPFWuOYohs = 227767742; JPFWuOYohs > 0; JPFWuOYohs--) {
        continue;
    }

    return -819974.3047412304;
}

int EXbucrNQHw::GnfpobhKmiUygSW()
{
    bool yAHHyoQWuWJJe = false;
    bool CezDCUZHuDA = false;
    bool bpEUAn = true;
    double diUWXQqFnhWJb = -15591.631803207485;
    double hlmkUVIAxKDUVgw = -239891.70786085475;

    if (bpEUAn != true) {
        for (int SvZRuUtl = 497998578; SvZRuUtl > 0; SvZRuUtl--) {
            yAHHyoQWuWJJe = CezDCUZHuDA;
        }
    }

    for (int cHBjGDlubboo = 811093479; cHBjGDlubboo > 0; cHBjGDlubboo--) {
        continue;
    }

    for (int XeREYJJhKSkpT = 1443525787; XeREYJJhKSkpT > 0; XeREYJJhKSkpT--) {
        yAHHyoQWuWJJe = bpEUAn;
    }

    if (yAHHyoQWuWJJe == true) {
        for (int VLRhRejzDxtyFXnB = 1592811563; VLRhRejzDxtyFXnB > 0; VLRhRejzDxtyFXnB--) {
            diUWXQqFnhWJb = diUWXQqFnhWJb;
            CezDCUZHuDA = bpEUAn;
            CezDCUZHuDA = CezDCUZHuDA;
            diUWXQqFnhWJb += diUWXQqFnhWJb;
        }
    }

    for (int gIWcJeof = 2103990630; gIWcJeof > 0; gIWcJeof--) {
        hlmkUVIAxKDUVgw -= diUWXQqFnhWJb;
        bpEUAn = bpEUAn;
        diUWXQqFnhWJb *= hlmkUVIAxKDUVgw;
        diUWXQqFnhWJb -= hlmkUVIAxKDUVgw;
    }

    for (int viHCbtNbXg = 191172761; viHCbtNbXg > 0; viHCbtNbXg--) {
        bpEUAn = bpEUAn;
        CezDCUZHuDA = CezDCUZHuDA;
        bpEUAn = bpEUAn;
        bpEUAn = ! CezDCUZHuDA;
    }

    return 1695844673;
}

bool EXbucrNQHw::NMnCEyizMR(bool xzmTLgUGriEhMg)
{
    string wONJUVRD = string("cqZsBTdjXPOEYZdCJtgIwYngOcIahSsOTNnoNntBnXMNyqrinGApuzvJiIZPJmTDQYFkOdedPXtwhEAElnUvGeKhoQTIUgGvrNItCJaxKwEvStbRby");
    double kzWUaVIl = -686663.7154986557;
    int eATeJcTfIMGXrAYC = -536747366;
    bool usaKANMUxRqHW = true;
    bool pjHCvKzWhlpacgb = false;
    bool LHmRKyEHzJNRnGp = true;
    bool nucQuOXfBiyXBq = false;

    for (int ceBJvYlUDzwf = 891290048; ceBJvYlUDzwf > 0; ceBJvYlUDzwf--) {
        LHmRKyEHzJNRnGp = nucQuOXfBiyXBq;
        pjHCvKzWhlpacgb = ! xzmTLgUGriEhMg;
        nucQuOXfBiyXBq = nucQuOXfBiyXBq;
        xzmTLgUGriEhMg = LHmRKyEHzJNRnGp;
    }

    return nucQuOXfBiyXBq;
}

bool EXbucrNQHw::wtrjrAnoIAl(bool UOaOsRDbAOX, string NRAId, string qEIDKWoh, string mjtAVJcijyevir)
{
    int WlaVXqriHybe = 860266306;
    string OhkxzVeyCpjp = string("BeCFICTJMguvhAVfHwjziEyRDlsMpdRexwPDCMBzzVcZSspazfwkrlUkBTlqZZBHBYlljCAlplvogYIAPltCcUvyrc");
    bool afiMS = false;
    double qvAmyAiHZvsSbXO = 1039018.0330691233;
    int JVxJNF = 1487660581;
    bool uqgKmseDsKo = false;
    int rCxebBnktbv = -1484079055;
    string yNeAlNObsaTRTCp = string("edTudfggibCUCFVaRkBMvbdrtSbiycnrjAWdsAdAPTeIwnzWtRtYnBZOvyhzwRgqhbZkQlEZg");
    double bejfwZANyuCDnHh = -1015382.6912820664;

    for (int djpBDVR = 1645910104; djpBDVR > 0; djpBDVR--) {
        mjtAVJcijyevir = qEIDKWoh;
    }

    for (int tmZBnrw = 1423585937; tmZBnrw > 0; tmZBnrw--) {
        yNeAlNObsaTRTCp += NRAId;
        OhkxzVeyCpjp += NRAId;
        UOaOsRDbAOX = ! UOaOsRDbAOX;
    }

    return uqgKmseDsKo;
}

double EXbucrNQHw::pbyeoZqbmZkZ(int tSxxvxr, string RVnaV, double qhpKjSHJp, int PYjkAmKiuGr, bool twuedaJJSbEjpoc)
{
    string JHMqWqb = string("pecDciGWsgXXzuKnfKmTdsmnyOSeXXcJIQigNNFwledHZFbakLbDYAaueHezTRhQAmEvewjECCGBDmfKMcXVitcYYwSxgOyJOMgJcKNnPnkEgtMMZimkLwthhJiJpZnaOCBtWGdZHfkDzcYNeQLnaYfyTdBfwuTqkAoCMnbCctfAxhLBDaNDMjFqjSYklkZ");
    string eAAHKOSmZjro = string("wfSTysnMwPuENYwkyFveIXnnRqwknmP");

    for (int DOxnbCnbzkuYTSF = 1619574970; DOxnbCnbzkuYTSF > 0; DOxnbCnbzkuYTSF--) {
        eAAHKOSmZjro += RVnaV;
    }

    for (int DLOlgdUSpKuLqKSm = 390561164; DLOlgdUSpKuLqKSm > 0; DLOlgdUSpKuLqKSm--) {
        tSxxvxr -= tSxxvxr;
    }

    for (int gXrgYdIHkLARK = 2048523451; gXrgYdIHkLARK > 0; gXrgYdIHkLARK--) {
        twuedaJJSbEjpoc = twuedaJJSbEjpoc;
    }

    for (int GEqNFleZUb = 2114609948; GEqNFleZUb > 0; GEqNFleZUb--) {
        JHMqWqb += eAAHKOSmZjro;
    }

    return qhpKjSHJp;
}

string EXbucrNQHw::JGSQLZeKWZx()
{
    int tDfYakNOCrQAr = -597075633;
    string NOLAnADJZk = string("NwMWWfvoSmuTKjwVzeVvajrQaRnRKfaLyvmnrbZBBxojYoPDWrQqCSSCJGuPjBPvFKLqwLGTRLwtVLSypuWrIogRAlDuvSWonhLqAWfwWmIYtsyvCMspncGfujuVHlIgXkznSjwFlnXAAvxBIWJYfcSUMFhVKUKpzwzTCOfFGOZQiiBzmJdaedJmzoVuTwYXUwfPXSZrjHpEsrYsMRSrHwvIhmgPkpXEjTgeTF");
    double NDbhlame = -908739.4392695408;
    double lHPoe = -534751.008931391;
    string pfamZIA = string("azHwCdbAdFXwbpFqApxnPnPHWAWMxlktKCGXdREMheckQXogiQBifLXJsRiTeNgGIuOFxdbSJLwZSxlnNFSHMwrwVeSgUeXqvxlnFwqYYRoaOCypqCOhyaZuZzBfjmXFmcTVcdwwiVbevUjnSFnhoKpsEEBlnDWJfIAkkbqOUpIGCSXAsaqRencuRPqXrTiLovlFosNbKEpZoWjNYvInBlnPgIL");
    string stgefwfDb = string("DlAAWOnWBnRvWaDTeYJCAiFBAqMMVEgsiIBjDphtkArWDBTcgiVKkjfeGdecHsXJheqZeTNreVxipLeVYHxLPPmIliEpHtbmMdemPmtfFkToGJrePbyowozh");
    int DNLKOi = -1872370957;
    string mTgMuaPHIdgqvfI = string("ujrmfqgVraLncuIqoQFiIkZvCJcdLkpZVHQjTnWlcZvllVsjPHtinaDmsWEFCjwzlCtjOYJenuILxPAnNWqszYLlyqTPGJZmCcSatss");

    for (int GJitGQvRDSTkNQ = 575837198; GJitGQvRDSTkNQ > 0; GJitGQvRDSTkNQ--) {
        tDfYakNOCrQAr *= tDfYakNOCrQAr;
        mTgMuaPHIdgqvfI += NOLAnADJZk;
        DNLKOi = tDfYakNOCrQAr;
    }

    if (NOLAnADJZk <= string("NwMWWfvoSmuTKjwVzeVvajrQaRnRKfaLyvmnrbZBBxojYoPDWrQqCSSCJGuPjBPvFKLqwLGTRLwtVLSypuWrIogRAlDuvSWonhLqAWfwWmIYtsyvCMspncGfujuVHlIgXkznSjwFlnXAAvxBIWJYfcSUMFhVKUKpzwzTCOfFGOZQiiBzmJdaedJmzoVuTwYXUwfPXSZrjHpEsrYsMRSrHwvIhmgPkpXEjTgeTF")) {
        for (int qaiUiuLOJWF = 29056931; qaiUiuLOJWF > 0; qaiUiuLOJWF--) {
            mTgMuaPHIdgqvfI += mTgMuaPHIdgqvfI;
        }
    }

    if (stgefwfDb != string("NwMWWfvoSmuTKjwVzeVvajrQaRnRKfaLyvmnrbZBBxojYoPDWrQqCSSCJGuPjBPvFKLqwLGTRLwtVLSypuWrIogRAlDuvSWonhLqAWfwWmIYtsyvCMspncGfujuVHlIgXkznSjwFlnXAAvxBIWJYfcSUMFhVKUKpzwzTCOfFGOZQiiBzmJdaedJmzoVuTwYXUwfPXSZrjHpEsrYsMRSrHwvIhmgPkpXEjTgeTF")) {
        for (int jXdUuwAhmSyKbF = 1037700378; jXdUuwAhmSyKbF > 0; jXdUuwAhmSyKbF--) {
            pfamZIA += pfamZIA;
            pfamZIA += pfamZIA;
            NOLAnADJZk += stgefwfDb;
            mTgMuaPHIdgqvfI = NOLAnADJZk;
        }
    }

    if (mTgMuaPHIdgqvfI != string("ujrmfqgVraLncuIqoQFiIkZvCJcdLkpZVHQjTnWlcZvllVsjPHtinaDmsWEFCjwzlCtjOYJenuILxPAnNWqszYLlyqTPGJZmCcSatss")) {
        for (int qOirMBAiKB = 734573242; qOirMBAiKB > 0; qOirMBAiKB--) {
            stgefwfDb = pfamZIA;
            stgefwfDb = NOLAnADJZk;
            stgefwfDb += pfamZIA;
        }
    }

    for (int MIWlcpHhDjyQ = 827328836; MIWlcpHhDjyQ > 0; MIWlcpHhDjyQ--) {
        NOLAnADJZk = mTgMuaPHIdgqvfI;
    }

    return mTgMuaPHIdgqvfI;
}

bool EXbucrNQHw::xbtsiwXqxdzpTZ(bool sdzNmomDTWjzU, bool BdnCIIVjUgD)
{
    string jlDtxWkmFuZjMJC = string("sqOLOFzsvhwLcgoKEWwrajXbrTDzVNNCwFDEJmWlCkzJjRdWEJdNXZagZWcGmLWADJBcdPnzdijFlWqPxqfOQgwyXpxBRytQRPAXQBiRgTMaxjuNNjAVyKnEgWUDSNrDKNjxdgVquzjiGzEAHQETCyAzgwkbCBHgwvedepIGphtoCHEjIFAbExDbDhNJHeYwyrzcncEfoLouttlHJooHVFvQmiNTGjGGaoXWFXQGkj");
    int LPvcPieNTdmw = 700874892;
    int JenGyQUYKTlXIJS = -2043163255;
    int gphHLW = -2101792129;
    bool ckahPZdXlcSoLtG = true;

    for (int CoDBdKjvOlDib = 516628329; CoDBdKjvOlDib > 0; CoDBdKjvOlDib--) {
        JenGyQUYKTlXIJS -= LPvcPieNTdmw;
    }

    if (BdnCIIVjUgD == true) {
        for (int cMKndKFKcIwih = 879513215; cMKndKFKcIwih > 0; cMKndKFKcIwih--) {
            continue;
        }
    }

    for (int YlysKeh = 198829113; YlysKeh > 0; YlysKeh--) {
        gphHLW /= LPvcPieNTdmw;
    }

    return ckahPZdXlcSoLtG;
}

int EXbucrNQHw::aejzABHhXsC(double CdZnCrWpQbyaTbhz, int ronkQfxR)
{
    double wwOClPu = 268851.22416981705;
    string OtFWZFsFPShPGae = string("rdvIPiHQFqdvwoWIqNuRbgZUJGSfWfwxisUMGVqsMaaKBftAZOGvsBcCYFhVqlDIPxkUlJQuPiQnLNxhddTIqeiTQcYMoHrQToyfECoghaMNSaZSXsJhVtJDvzxkyRIjOyKYseqNaLKctaMGBqENbMbOanasLSYgCDJJKYjHwQjdjHTiPvqUMwVQqhPmFujIJScDVtwTtOzXSGGmAAN");
    string PYFCqOdRwYHXDECp = string("CNwXfzrdAIYIyVwLFLEomDuFcsyKsdwDLCILAgceGkmDNxKWXsSjucZORSoRXzcMKKWxIndddNOxipnpuyTgycsXVpnyQvBJtNFy");

    for (int KUGGyfP = 2107036825; KUGGyfP > 0; KUGGyfP--) {
        wwOClPu -= CdZnCrWpQbyaTbhz;
        OtFWZFsFPShPGae += OtFWZFsFPShPGae;
        OtFWZFsFPShPGae = PYFCqOdRwYHXDECp;
        wwOClPu = wwOClPu;
        wwOClPu -= wwOClPu;
    }

    for (int tmKqcVyyDEvnaPsl = 1723146917; tmKqcVyyDEvnaPsl > 0; tmKqcVyyDEvnaPsl--) {
        PYFCqOdRwYHXDECp += PYFCqOdRwYHXDECp;
        wwOClPu -= CdZnCrWpQbyaTbhz;
        wwOClPu = CdZnCrWpQbyaTbhz;
    }

    for (int rFZmxrFw = 1218361744; rFZmxrFw > 0; rFZmxrFw--) {
        ronkQfxR -= ronkQfxR;
        ronkQfxR /= ronkQfxR;
    }

    return ronkQfxR;
}

EXbucrNQHw::EXbucrNQHw()
{
    this->KyrGEezcOACcwow(string("n"), false);
    this->aUlqlGSGFm(string("ihVKYVhRBshkaXNtqLWYmamvBiayaDHiKIZeBuIewBFbpilsjOCERShWYvgdbOnUsAjTojlztgXoXlyXBaLMliloUPvjvdPggWHNEUYDyBtoNzjavlKkwmnIVRYeuXERDJawDOSoCwxPNjoufzZPHUqpYrtcEQeygxVVaZjBkHCyBTjpsgyIurYyQh"), string("crkXnREwEHaGbmdlxknDeUGBYYphfnAYKXaDJzNBQCZEJkikeAgHpmTeqdeTKVYAVqazuQlQJRHiRXWlZCfONOPwWOEJnBqvGfCevEmhHMuHzdLwbxJAgISSJGEsSZgDXn"), -1488.0568368806423, 635037.431860274, string("dlaXBLoiZrXzvedAqvXhFaZEBlleApVGVmAtMVvHMxAx"));
    this->kYtoTAb(-830940819, 466165.7082975286, string("mTKviuFoRDkfkDrpEJSuVSluyrByJZiFlDqEBEurvgJICsXSFnQzfljGpIWqPTjewFTXpvHlmPKYCYPROhGoZlFltowHuKPDmrdDtOZJHFJeJxbYZsWBBdTLEXFFxmTRtBtRqgFpJlqNkPULleHAqHPGtzGDaxPukFoshGDULAtghSgglHIvjzLoXGfgoAfGKyPwnlBXOUzmaSHZuZGvTfyIqmIYbrpFHh"), 1297027599, true);
    this->DQGDMypKhgeNgsf(false, string("SspJZONEfDfRNIUvdpnYZPrJODXbrEaFKbOEMbNUgtawcnbQQsdVofJCCTdQAnNhupEUpLSJIVqLkPZJUJGIqbZLyURTZUgSCKhpbgfXFMXAAguKxwExiIMuPdKHAWRPXaumssaOY"), false);
    this->GnfpobhKmiUygSW();
    this->NMnCEyizMR(true);
    this->wtrjrAnoIAl(false, string("wlHyvTekXDxiQEGRNAhb"), string("IpzvaMwYilfhVTLRXDDCxgZbRZlPtQVErnSRWiPDTOkczpByJyxDpEnHrSmsYBxNrrfjiKPfsMDgwMWveMDxQnirzzITIWzbnpTLDthraKQpWWdXAosZrjvDMRShTOOiklMssgnFOOSrhwwOlCGZeaLEicVFxEnQlmUfRmcLrzjOPJYgehJSQlBnFDpMYpWizuJTVpLNmBUs"), string("wPjRRoTTwHCGTyIEyZdjxgkWpdUtGMpXOSDvqCJIJTCSUhkPuESnjHopNtoNuVdzifHEfYFYqNrJOvHEsqsfV"));
    this->pbyeoZqbmZkZ(-1827347466, string("WWjjZbnTXwJWASQFmTLUZwiDeleurpvmPgNfmDwoaBJLzhioUMJqJXLtObyiLTdPQXTnvOmBVCokNcYeReCFEoByTVgoLTULCpVhdnjOfPqdwUGmbJKRXjdnFFMziDHRuXHSawLYAHoMFTaUqRRXkBEHBGiiMHJL"), 779487.994886692, -1701097143, true);
    this->JGSQLZeKWZx();
    this->xbtsiwXqxdzpTZ(false, true);
    this->aejzABHhXsC(-336304.54333949037, -1850880433);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class veFzBgs
{
public:
    double RDJhvextSUylDqzI;
    bool hgfcWqaHQM;

    veFzBgs();
    void SPiiXnihYou(string fQhjaUIVmIHVN, int RfwGbEG);
protected:
    bool GTCMgGfe;
    double qAmdhhAWfuMmcyR;
    int QurrSp;
    int OQYyluwIzCm;
    int VpdqiwJI;
    bool pxzTSCa;

    bool EwRWxKXUTS();
    void YGtMQWue();
private:
    bool hDjmThiVuuYfJ;
    string GJyQnTFrOTRIP;
    int ClevZqSA;

    string ChQQkjcJve(bool qDDeZGkhwerdVD, double tyYIWAvKdRzSFBkL, string cVoeWHXIIKjKcu, int hTHStMTx);
};

void veFzBgs::SPiiXnihYou(string fQhjaUIVmIHVN, int RfwGbEG)
{
    double WPycZwt = 621470.273946849;
    bool DFlNjYfSGaf = true;

    for (int mWAwzQ = 611772255; mWAwzQ > 0; mWAwzQ--) {
        DFlNjYfSGaf = DFlNjYfSGaf;
        DFlNjYfSGaf = DFlNjYfSGaf;
    }

    for (int nmpkybhRSP = 789905737; nmpkybhRSP > 0; nmpkybhRSP--) {
        continue;
    }

    for (int cWEOmcLktgwOeWh = 897286589; cWEOmcLktgwOeWh > 0; cWEOmcLktgwOeWh--) {
        DFlNjYfSGaf = ! DFlNjYfSGaf;
        RfwGbEG += RfwGbEG;
    }

    for (int VeRqgaP = 419781519; VeRqgaP > 0; VeRqgaP--) {
        continue;
    }
}

bool veFzBgs::EwRWxKXUTS()
{
    string LdHGwQETpTySKE = string("ZJAQFzpvPnGofkyCoEJGDEkCMgnCEBGcueRcjFdWCPeuUaelaVbsPkZZXCbkhMEVcdcqGgiGmDgnwsRlSbxpXxLEowdnuwLJosObRmSWpbCJovCrMgYWMLsrzyhVlOyusEblNlGRJGmvSNYtusPFUorYpoLIlaS");
    string OBPFhwxcHiUvrt = string("DjRVcYQQvDKcgjtnIbYOGHUoounlKuVdfCtDatnudBlIxIbgoxPbgsUmCwvfvsyPXMUpqiZhfZhrhbKMwiqZuGxcwNfGjViTtFEhXogaGicEDyTpruIDzGdLIciVBzpGaxirUNRFRJRhBddDbPtWaBTAGnspLjMfnPWvDIFzYMWwMtRfyQuhinMoeeOHqKedKcFVaDRJioaucQIy");
    string ATFpiAs = string("buUFFwcNMuKumsTZIXdyNTVRfMdvheaTXQoeLtFLSeIgIdknKvaYadPMNUpotAQjMBCtcmQVAAvnBHGnoRTyLRKHtexqMwQMCOgZvICRIhYuDnYMZgOluQrCoSKJsSsgVdzzyNnELQpXFpHtykxqHmJwiBbzwGyxoXRiGMDzojQRIxcZytZvZirPRuigivFhakYvEDgYBpgDw");
    int VYxahomsfhT = 2131422902;
    int sfkTOglHpCTtoPB = 1546898540;

    for (int fixoC = 593658944; fixoC > 0; fixoC--) {
        LdHGwQETpTySKE = OBPFhwxcHiUvrt;
        sfkTOglHpCTtoPB = VYxahomsfhT;
        sfkTOglHpCTtoPB *= VYxahomsfhT;
        VYxahomsfhT = sfkTOglHpCTtoPB;
        ATFpiAs = LdHGwQETpTySKE;
        sfkTOglHpCTtoPB = sfkTOglHpCTtoPB;
        LdHGwQETpTySKE = ATFpiAs;
    }

    for (int CGPTgOzoswExlXKz = 1270582989; CGPTgOzoswExlXKz > 0; CGPTgOzoswExlXKz--) {
        ATFpiAs += ATFpiAs;
        ATFpiAs += LdHGwQETpTySKE;
    }

    return false;
}

void veFzBgs::YGtMQWue()
{
    double GVjUelvX = 855698.5394766954;
    bool ekesTZOCNmw = false;
    double ALpLjQtu = 454670.1183848997;
    double RKhjlsYGn = 782486.815103925;
    string umaXVILrIFuzmNxM = string("iHswKtiyiMfhKgPnZRLJjUwSVnItmrvpdPFdnmaouGLTRDFpTfcBKoFLKsfVZmohqEfNcEHASwysLOJiCDcCcXvjRnuvTtAVGmEqSuzYIDecYnwlOyglzlKwp");

    if (GVjUelvX != 454670.1183848997) {
        for (int BATyYE = 1841900188; BATyYE > 0; BATyYE--) {
            GVjUelvX -= ALpLjQtu;
        }
    }

    if (RKhjlsYGn == 782486.815103925) {
        for (int yPDfPyidVIA = 1229887950; yPDfPyidVIA > 0; yPDfPyidVIA--) {
            RKhjlsYGn = ALpLjQtu;
            ALpLjQtu += GVjUelvX;
            umaXVILrIFuzmNxM += umaXVILrIFuzmNxM;
        }
    }

    for (int xCShMrSuqQLbth = 432734155; xCShMrSuqQLbth > 0; xCShMrSuqQLbth--) {
        RKhjlsYGn = GVjUelvX;
    }

    for (int tVGxxT = 1290742511; tVGxxT > 0; tVGxxT--) {
        ALpLjQtu = GVjUelvX;
    }
}

string veFzBgs::ChQQkjcJve(bool qDDeZGkhwerdVD, double tyYIWAvKdRzSFBkL, string cVoeWHXIIKjKcu, int hTHStMTx)
{
    int WKJrOWznrnDU = -356522463;
    bool aOpfVqMSoW = true;
    double XHlKONiDfgxgCeFb = -162868.40464881368;
    string aWSPDN = string("IOEjPhZhSJjgvZMWxHdjZkLystWoOoUZDxLbRuKIoBVbesysvjKtzCLh");
    bool hTMyTIJvKXrE = true;
    bool VhUsJzuF = false;
    double MOyYjvFD = -118553.53035471731;
    string jOINCLmpZXMPJ = string("hrxXTIhkPrRVxY");

    for (int fvgWPuhFr = 1201821783; fvgWPuhFr > 0; fvgWPuhFr--) {
        continue;
    }

    for (int oaGeuFWHboOmE = 401774193; oaGeuFWHboOmE > 0; oaGeuFWHboOmE--) {
        continue;
    }

    return jOINCLmpZXMPJ;
}

veFzBgs::veFzBgs()
{
    this->SPiiXnihYou(string("WNAdkSZZfnQEBrQCJhJIXXXVNJEAbeaIjWSlBiUBmOSWkjwjpVwvqTARJZCM"), -1340957815);
    this->EwRWxKXUTS();
    this->YGtMQWue();
    this->ChQQkjcJve(false, 711942.0991078495, string("cKcLbRGDOrHqbRNiQqJpaQUYkzfsCJqmTtWfXAUvOTzOrJdPeXvacUTMhQOBMcMYYnuaMnNRvxCMhusydezGDcaHci"), 1085765053);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cfehvjIvYkakwRO
{
public:
    string bmjXOZvhoiIwXdj;
    int SmBAf;
    bool ctKfVGet;
    int WJhfHpRcPpY;
    string tvPBaHTzsFuSKmMT;

    cfehvjIvYkakwRO();
    bool qZPwIupoaxNJCCqE(string KmQaUfPb, string lGXxNuRbEbpoMOS, int GBvTYJXsiJPf, string HqFduVKO, double VenXbT);
    void bAbDx(string fLyYdo, string xEoBhlbFdQatl);
    int QdBiEGEnGpMq(string XOJltfM, string XaswuVBAeCKDLIS, string ECfaIuIbOfVeTyQa);
    string DebbTESRGZa(int XKMdAgz, int PCiJPMVPvrWuHukQ, double bucaYIc, string NWgKABulvXg);
    void MIhxhRoLpjPOBj(double oEpxgTLDKNXrUcii, string nWuDH, string aqNnOihYKfWWysmZ, int sXheOfduUYlwUTXJ);
    int ukmCYk(int KfPyYKmIqpkSb, int ObSjjok, bool bhIXHOYradetKAV, string sqWwGQGUx, double qycgawJzKOVWxb);
    void SJwscacOiaMu(int iibjlXbjBQs);
    bool DZTmiLpQrxZKpz(int VzefliDff, int mbHZdmDpWAanpwQy, double DugCHuOFQzQ, int KTvTiMgAhseiY, string lOnQzOJ);
protected:
    bool KGRuBqUhyb;

    bool gDxLOwoOpHZvDO(int ygdERcRbPvTZlG, string GXCvvcYdXA, int zTkWzMQz, string bFEGaq);
    bool FqaXUWRzstWIphiD(bool TgkXUfxkhNgS);
    int TAkGKgcQiN(double BsJlc);
    bool aNxVqL();
private:
    double KdkJpwc;
    string BezKDpp;
    string iugMUNC;

    void VEuukBPxW();
    double ZWHfvuQdFzcbIDa(string imUcHmC, double kGIAIW, int qfZHhmCgPc);
    double XTKXYYzKSydJ(double rmGLKIyzuTNaN, double jHxxJlricdPG, string nYfxXnj, double nufaMYZJVYXgoXoc, double ihHaeLWidRqJBe);
    double JFxFgCpPPGtqNq(string LfJFNLqcpDKdJKh, string eKYTflRmUYDVLva, int LVCavwHvSwgh, bool mFPiTIiRitMXfkH, string bzmFedXXWebt);
    bool cWgHHzbYSKj(bool cypQvfwphIkiQjx, double RVPZKaBikIhyomRk, double pkFvKokgxc, string SPHjRZJ);
    int ztFMkDtrXuLLHMG(bool srIqwGDxaJpVn, double EIgPCBQzn, int CoTXWKQSjiAE, string ErrNce, double dUiWm);
    double VJUHOYLF(int wcbjgqZUpWuNLnL);
    double SDwlCmahRUShS(int KarkbYuTu);
};

bool cfehvjIvYkakwRO::qZPwIupoaxNJCCqE(string KmQaUfPb, string lGXxNuRbEbpoMOS, int GBvTYJXsiJPf, string HqFduVKO, double VenXbT)
{
    string LnOEHJysj = string("irPixJZWUzJlFcvivjJRbOfCaRuyGaIPSQPUssyfMEMOcoHlrjYegPpKrOihVlszIteenZEiWNRuqrgoulzvZElnLrIlCHczxqrtJywJBWuVXyctTatYjhlGBDHFBXWbEMRVUutXWGtqovKjqMhnIYsrUJBRqhLyEfcPgzBFMvcLttgaywqUX");
    double PdmDDMnL = 945594.5664353467;
    double VstLRxFpG = 616223.8707806527;
    bool IhXNcOkuvomFsB = false;
    int PZBCSCSwxar = 323908324;
    double SAognSAwX = -627328.1700131119;
    double UtMXF = -205220.37063837468;

    for (int YbfGExvl = 77740140; YbfGExvl > 0; YbfGExvl--) {
        PdmDDMnL /= PdmDDMnL;
        LnOEHJysj = lGXxNuRbEbpoMOS;
    }

    for (int HiLAVrXXTOUg = 1246631758; HiLAVrXXTOUg > 0; HiLAVrXXTOUg--) {
        PdmDDMnL -= PdmDDMnL;
        VstLRxFpG /= VenXbT;
        LnOEHJysj += HqFduVKO;
        KmQaUfPb += lGXxNuRbEbpoMOS;
        SAognSAwX /= SAognSAwX;
    }

    for (int BKYWQfNMlO = 1649915069; BKYWQfNMlO > 0; BKYWQfNMlO--) {
        SAognSAwX += PdmDDMnL;
        VstLRxFpG *= VstLRxFpG;
    }

    for (int UOBsERaRyYWcJu = 492829918; UOBsERaRyYWcJu > 0; UOBsERaRyYWcJu--) {
        PdmDDMnL = SAognSAwX;
        SAognSAwX -= SAognSAwX;
        VstLRxFpG *= VenXbT;
        UtMXF = SAognSAwX;
    }

    return IhXNcOkuvomFsB;
}

void cfehvjIvYkakwRO::bAbDx(string fLyYdo, string xEoBhlbFdQatl)
{
    string phmaun = string("BBXYlEzIEvLfQVVnwCOzobjHoVIahtyUHujKsGMErYnEbPlxerBbyncCptX");
    double gJZxh = -260111.70730986295;
    int tNeRMIPpkC = 1533115557;
    string GmxWHrM = string("etGyPt");
    double ZGowdnQqpNFYyOrz = -784028.5069520384;

    if (phmaun <= string("BBXYlEzIEvLfQVVnwCOzobjHoVIahtyUHujKsGMErYnEbPlxerBbyncCptX")) {
        for (int HnpNCWtHTIV = 1111065315; HnpNCWtHTIV > 0; HnpNCWtHTIV--) {
            fLyYdo = xEoBhlbFdQatl;
            phmaun += fLyYdo;
            GmxWHrM = phmaun;
            xEoBhlbFdQatl += fLyYdo;
            fLyYdo = fLyYdo;
            GmxWHrM += xEoBhlbFdQatl;
        }
    }
}

int cfehvjIvYkakwRO::QdBiEGEnGpMq(string XOJltfM, string XaswuVBAeCKDLIS, string ECfaIuIbOfVeTyQa)
{
    string mpfHnvPlVH = string("yTlMTnhiUqvlpFmihdhNcoxaXgTWguvagETWAgbhUEFgEcGevgWlJtvwNhtEwtyDfdBwNNMmYbzFawJqGAMCgigkkOenFkfQMoULVfEJlxGlovqzxVSEzOtcsIBrAqsrMCZUZPRIjeQHxcAMaEhuXSEwPjhsvysQRaunXFFEfJITIwS");
    int KYFeelaBMVZ = 1720337686;
    int ILpxQLewdUMkzH = -1916309219;
    double DGyZZFDoLS = -78763.83619914723;
    int pXmjIImMHW = -678647001;
    double QcFoduAoS = 525302.9627039724;
    bool vCrmKKRzcBhcHRLc = false;
    string eMHqfxYCH = string("pWdcGxZPyPruQvuFQTeuznaxaYxAeIaDzUJtFAdqZGNHSpTqhioDgahDbnXlQzpVkRuhGcBNeaKvTpvfbrcIhIpqEwmsbEaFWsyFXEHXVckyhqCErPDnzIGHjCpwkDQngWEXZIkEqTbLPFuSzycHJdQwRjshaazUfuFRORfCIYscmKBViRuRORHcBW");
    string mtJlQEsoqfHHqKc = string("AxNioPuqgWiEJCrMbiErLrZBsJbayKGwsDeIrIamZIvfEVnAdAuaFBDGELbSFuMRmvekGQQEYCmZZeOUEsPuUGMFYiOInCdMKItrmgBGdJhZPWSbhEUNJXqrVMDtEMlGrixyOQkxjymbXQdvXGneIorWgYlwVvLACJuNPfuIKeZnkyYXVBFDzPIxzUlnSMRBicrMmFfNEkroNrAAHbOKGUYKfeXqtPjWRHLzucK");
    int PfdXvMyPif = -1494450422;

    for (int BvhiPmpAkJDDI = 22665578; BvhiPmpAkJDDI > 0; BvhiPmpAkJDDI--) {
        ILpxQLewdUMkzH += pXmjIImMHW;
        vCrmKKRzcBhcHRLc = vCrmKKRzcBhcHRLc;
    }

    return PfdXvMyPif;
}

string cfehvjIvYkakwRO::DebbTESRGZa(int XKMdAgz, int PCiJPMVPvrWuHukQ, double bucaYIc, string NWgKABulvXg)
{
    int mLYiXqr = 285461244;
    int XLqqINsKW = 1117460134;
    string xqKWgIyfQOJeY = string("zRbUsffWYnNwZrhrdAOADBCxZDfeuE");
    double pvktCWclPVxvYXK = 761786.6809225656;
    bool TvuWvgNCup = false;
    bool kcnIZfKxSa = false;
    bool uyEhdlXVTiQoPWJ = true;

    for (int ezdljkARDrFxbyEK = 676038052; ezdljkARDrFxbyEK > 0; ezdljkARDrFxbyEK--) {
        continue;
    }

    for (int fXVwvEbv = 569616198; fXVwvEbv > 0; fXVwvEbv--) {
        kcnIZfKxSa = uyEhdlXVTiQoPWJ;
        XLqqINsKW -= XLqqINsKW;
        mLYiXqr *= XKMdAgz;
    }

    return xqKWgIyfQOJeY;
}

void cfehvjIvYkakwRO::MIhxhRoLpjPOBj(double oEpxgTLDKNXrUcii, string nWuDH, string aqNnOihYKfWWysmZ, int sXheOfduUYlwUTXJ)
{
    int JfTOBNVvGRDeSW = -1169772262;
    double KoCnNSelnoikLih = 41322.469889965294;
    bool OKFrqG = true;
    string MtqHrrCYnVx = string("ZhGgxAyClrlWVAZRXExyzNMjZrLkfnOsuxTLgSkmpWyEMmwLaoPEfdPgCwVxcuXSkEXLsPwhqllHOFOcfnJQNDNRSYEGefnSWUoaCXwbknmRuSWVXBVnHluvFEDbgbdVeWrcIFRbKflXMcTXBdkUwhwSISFIVB");
    string rJLwrTNXrzh = string("ZDyZxINlzpiQQaphiYKMrnWiLGhlGbfbgAhpcGqEBXnIamydDBLaZNcIechTvQAksKVLfjujqfCnHRWgzDMbMHzJtpMFUleerFtFVmGtIXuldCWpQoNdZUEEfJubGFXhWXCEFIlayORlZrFuNQrXkertZhdMOFswUniOFUZnWmWUnOPa");
    double ojoRJnNbhtfHoEw = -356775.9731889573;
    int jStqmt = -10541970;
    double fZcyXnKYMLYqVG = 146760.995790415;
}

int cfehvjIvYkakwRO::ukmCYk(int KfPyYKmIqpkSb, int ObSjjok, bool bhIXHOYradetKAV, string sqWwGQGUx, double qycgawJzKOVWxb)
{
    double oDGTVxtQtSzzxGW = 696908.5113632048;

    for (int zprPLxPOpaGCXfzU = 128366039; zprPLxPOpaGCXfzU > 0; zprPLxPOpaGCXfzU--) {
        KfPyYKmIqpkSb /= KfPyYKmIqpkSb;
    }

    return ObSjjok;
}

void cfehvjIvYkakwRO::SJwscacOiaMu(int iibjlXbjBQs)
{
    bool UbdwtyIzXzwW = true;
    int hAYuVxEhw = -1591709366;
    int ZuKHYTmhqjTSCQRH = -1418281845;
    string TwDpUghJ = string("DUUjpCiIBPuJzZlMPIfqGBsrIdsevdscpyeauvEjHkZtqxLSirMlURFxSXqNiYdFUIETyWXapZJZSjJfeQlSmffyYQfScxtTY");
    bool mhDTyn = true;

    if (ZuKHYTmhqjTSCQRH < -841428762) {
        for (int iOqWajMd = 1668405941; iOqWajMd > 0; iOqWajMd--) {
            mhDTyn = ! UbdwtyIzXzwW;
            hAYuVxEhw *= hAYuVxEhw;
        }
    }
}

bool cfehvjIvYkakwRO::DZTmiLpQrxZKpz(int VzefliDff, int mbHZdmDpWAanpwQy, double DugCHuOFQzQ, int KTvTiMgAhseiY, string lOnQzOJ)
{
    bool LUwLjsDAzXBHVxfB = false;
    double KpvPCfoOkCrd = 987169.924941695;
    bool QXPnSiiLTNWtP = true;
    string lxrHlcGxWOfMAURU = string("JwXLTfMjTBZBKxpeFiQgFXUdGgxbkbfUjcIrqaiQkVZMKxeOyJHBDlTLVQWyfqkJPAyHYKJRWDvTnOpSoOiWMUludAQrBuUpvJRKvZLXisPquqGkckWmPaAhXvQXppnnKflgpTZALuuLliYtcpLLNgRhDTuLqciTBiErtkwwyQIbcvehBmQesQCUUeSovlGbyMSOvLFlSiYmbNyr");
    int JxYDqYPxUkpTdutj = 1986731898;
    bool FEGKiRjkmDnc = true;
    double LJsOTzhVAxoj = 13598.643494147704;
    double ZUywex = -697041.3747080655;
    string TVPskI = string("otJmjxqlLXhxkNyvOfPmVnDZcKGZUbRitabWDzxDnLuimsvuSEFTLvfDoPSJnzQJYpeWLDrTzBTwxGLRNNgwTUTdrSylEDnkclSWoIDHAet");

    for (int BcKEQL = 1628891883; BcKEQL > 0; BcKEQL--) {
        DugCHuOFQzQ *= ZUywex;
        ZUywex /= DugCHuOFQzQ;
        TVPskI += lxrHlcGxWOfMAURU;
    }

    if (JxYDqYPxUkpTdutj < 1986731898) {
        for (int qCWov = 697294953; qCWov > 0; qCWov--) {
            continue;
        }
    }

    for (int TmLDESEmWYxAfTPZ = 1470728932; TmLDESEmWYxAfTPZ > 0; TmLDESEmWYxAfTPZ--) {
        continue;
    }

    for (int HShjsz = 90558434; HShjsz > 0; HShjsz--) {
        JxYDqYPxUkpTdutj += KTvTiMgAhseiY;
        LJsOTzhVAxoj *= ZUywex;
        lOnQzOJ += TVPskI;
    }

    if (LJsOTzhVAxoj >= 13598.643494147704) {
        for (int XzHAimQyHMWQgC = 1157115679; XzHAimQyHMWQgC > 0; XzHAimQyHMWQgC--) {
            KpvPCfoOkCrd = KpvPCfoOkCrd;
        }
    }

    return FEGKiRjkmDnc;
}

bool cfehvjIvYkakwRO::gDxLOwoOpHZvDO(int ygdERcRbPvTZlG, string GXCvvcYdXA, int zTkWzMQz, string bFEGaq)
{
    string nWxGhbDOUVk = string("gTVefKLQrSJsDsGDozSDcLmIDKAEBXKeTAqWwxrcugHWXYprRWXyCjNMgydMvMGZLQuDGVCypfNzOECGPqKPbRHrpdHVcahjQlJRGKQbVqeQLvyyUjhipFQQGlBJsNIJHRyoVhklVzRJBUjogGgtVaWBJCmHWFOkfVwoQfbFqHqysWZeYxdGtCu");
    string LfyiTwjvXDienjgL = string("qjnQbcxShgYWdBkGHlggJiqnjgidBRcQAzGIGZKAyfpqBWBuyNrwzdeVPIMZerUfgLwrkjnzKj");

    return false;
}

bool cfehvjIvYkakwRO::FqaXUWRzstWIphiD(bool TgkXUfxkhNgS)
{
    bool uUAZvTFXphyoJ = false;
    double IuhsEtjse = -695512.0048890674;

    for (int LwLiU = 1707939873; LwLiU > 0; LwLiU--) {
        TgkXUfxkhNgS = ! uUAZvTFXphyoJ;
        TgkXUfxkhNgS = ! uUAZvTFXphyoJ;
        TgkXUfxkhNgS = ! uUAZvTFXphyoJ;
        TgkXUfxkhNgS = ! uUAZvTFXphyoJ;
    }

    if (TgkXUfxkhNgS == false) {
        for (int WQEERtWlln = 876140606; WQEERtWlln > 0; WQEERtWlln--) {
            IuhsEtjse *= IuhsEtjse;
        }
    }

    return uUAZvTFXphyoJ;
}

int cfehvjIvYkakwRO::TAkGKgcQiN(double BsJlc)
{
    int aZMyVBTydCiK = -834255522;
    string sYnOsMPDsrCOQkL = string("QULAGxFEnMkNnWsLQiTfBecRVAGFMVmZfAoiLVUPvcFMOCzDFZJdqTpYbywgZPaOoAldyBIOBsdmAvuFGPmmQLlZlXLUbbQFHBRZjXacUSCbvAafxuLTpJBmeWqPxQeljLTHrisocYGiTjskxdtSJEDsnRfmynfySRviNPKBSPmhBKCxvhXllePDyMVJZZYpZLLoIuSlLAcSGa");
    int FCpYlPkyg = 506745851;

    for (int lCRzB = 622802023; lCRzB > 0; lCRzB--) {
        FCpYlPkyg = FCpYlPkyg;
        aZMyVBTydCiK *= aZMyVBTydCiK;
        FCpYlPkyg += aZMyVBTydCiK;
    }

    for (int BjYBreXEmipz = 699932770; BjYBreXEmipz > 0; BjYBreXEmipz--) {
        aZMyVBTydCiK *= FCpYlPkyg;
        BsJlc -= BsJlc;
        aZMyVBTydCiK /= FCpYlPkyg;
    }

    for (int jiLalu = 208296655; jiLalu > 0; jiLalu--) {
        FCpYlPkyg *= aZMyVBTydCiK;
        aZMyVBTydCiK = aZMyVBTydCiK;
    }

    if (FCpYlPkyg < 506745851) {
        for (int XCvIRSXbrXRLdWbi = 87870469; XCvIRSXbrXRLdWbi > 0; XCvIRSXbrXRLdWbi--) {
            FCpYlPkyg += aZMyVBTydCiK;
        }
    }

    return FCpYlPkyg;
}

bool cfehvjIvYkakwRO::aNxVqL()
{
    int sEOAdcxCXsUI = -1410156090;

    return true;
}

void cfehvjIvYkakwRO::VEuukBPxW()
{
    int axpnklfMspCROsxK = -900759381;
    string VqeVuLgD = string("CwDhXlLyYaqkObmHIWFcaNTNFsVlpogzpQyAvYaeWIHvIPtcHlrAbWhJtgTQGPoWJAxMFXKIrwEMGlUOVFfXYMkqKDUSQeNnRDBHtjEpRYwVzbZnBxgZEiofqvhMD");
    bool DdbdrMITSwMqvMJ = true;
    string KBQnvkv = string("izUSpqcoiNBsmmNgCndtTdbgEnAkfamcddjYvenpFyMSXVDheSRk");
    int TmISnhkGNjQGlg = -1980417586;
    bool kQqKAZNe = true;
    double kXxBaCMYnTX = 1012878.4386847678;
    bool cevOUr = true;

    if (DdbdrMITSwMqvMJ != true) {
        for (int GzhSIVFEuz = 497972925; GzhSIVFEuz > 0; GzhSIVFEuz--) {
            continue;
        }
    }

    for (int jaVQbuRROmy = 135480955; jaVQbuRROmy > 0; jaVQbuRROmy--) {
        TmISnhkGNjQGlg += TmISnhkGNjQGlg;
        TmISnhkGNjQGlg += axpnklfMspCROsxK;
        kQqKAZNe = ! cevOUr;
    }

    for (int yOxaVQTC = 743435138; yOxaVQTC > 0; yOxaVQTC--) {
        DdbdrMITSwMqvMJ = ! DdbdrMITSwMqvMJ;
        kQqKAZNe = kQqKAZNe;
    }

    for (int QBJnbWLYm = 342305098; QBJnbWLYm > 0; QBJnbWLYm--) {
        continue;
    }

    for (int AzFWxL = 1070603878; AzFWxL > 0; AzFWxL--) {
        continue;
    }

    for (int FhHIDI = 27969254; FhHIDI > 0; FhHIDI--) {
        TmISnhkGNjQGlg += TmISnhkGNjQGlg;
    }
}

double cfehvjIvYkakwRO::ZWHfvuQdFzcbIDa(string imUcHmC, double kGIAIW, int qfZHhmCgPc)
{
    string ODGNlTO = string("OgEnalhQowmXRdqatErScSYucvconzCtQticXNYzQbZAYPKrBnTLHSbVNjUWqLqBRQhZHZHPxvBPbZpxfzfKOKscRGmPMeVlaXGPOlBDKwoIpavrWFUfdNvUEbXUygxGMwryhRMQLdIlbdfLOIyEjYeqcpzNLGWOJlmTlhasxoSCsoMcMPHHpnDHqgLERxDYUJyQISaVFgftNQpsvCIbkXanQNctflvfbYQcDQ");
    int PGSvgGpGmWZB = 884528444;

    for (int osWgedf = 525473122; osWgedf > 0; osWgedf--) {
        imUcHmC += imUcHmC;
        PGSvgGpGmWZB /= qfZHhmCgPc;
    }

    for (int CzeYZ = 771968060; CzeYZ > 0; CzeYZ--) {
        ODGNlTO = imUcHmC;
        imUcHmC = ODGNlTO;
        kGIAIW /= kGIAIW;
    }

    for (int qGKBwa = 630872757; qGKBwa > 0; qGKBwa--) {
        continue;
    }

    return kGIAIW;
}

double cfehvjIvYkakwRO::XTKXYYzKSydJ(double rmGLKIyzuTNaN, double jHxxJlricdPG, string nYfxXnj, double nufaMYZJVYXgoXoc, double ihHaeLWidRqJBe)
{
    int gjxdsf = 1568526939;
    int nhLcKXrflNp = 684788907;
    string KNnHMlPv = string("IyHqMmGNtiaKbDKWzjIOjrFtRhCGucyjrjlPTDsrKLCnaPoRWJwWOIAVJerKphDsfDZQfQeqJuEpZnVDhCvwyMmWIrUkRFFWJDCtYedpEuCxzUeAhIYUkviHIZAvahsxPGObvLkmTJKraOJoRhUeWtYFajVJPmRMqUXAYyatXAZdvStznNdqbejGCNTVxvgTgfxRONtjwKPRrsLZFsqUrugmQbfBrQOdoYtlSXZdFqUONRLyNVEbQuYEYixQem");
    bool uOCaGxWcowQnaM = true;
    double ZNjSSqm = 941139.5724198066;

    for (int AgNpZ = 1957902778; AgNpZ > 0; AgNpZ--) {
        continue;
    }

    return ZNjSSqm;
}

double cfehvjIvYkakwRO::JFxFgCpPPGtqNq(string LfJFNLqcpDKdJKh, string eKYTflRmUYDVLva, int LVCavwHvSwgh, bool mFPiTIiRitMXfkH, string bzmFedXXWebt)
{
    string bPcCl = string("OFAVlCjXWvIssakVtgdtCWHvUcUFXbnTYGUwMNfQWuVaJALNAUfHjc");
    int PiAfBQdMhA = -724923849;
    bool KVbGZAWHQEDBfYAh = true;
    int gpshpIcmmD = -1659941042;

    for (int CaLtDIowZfDL = 1285274460; CaLtDIowZfDL > 0; CaLtDIowZfDL--) {
        LVCavwHvSwgh *= PiAfBQdMhA;
    }

    for (int zFkQHkpsKjMjHhk = 163424949; zFkQHkpsKjMjHhk > 0; zFkQHkpsKjMjHhk--) {
        bzmFedXXWebt = bzmFedXXWebt;
        KVbGZAWHQEDBfYAh = ! KVbGZAWHQEDBfYAh;
        bPcCl = bzmFedXXWebt;
        KVbGZAWHQEDBfYAh = ! KVbGZAWHQEDBfYAh;
        gpshpIcmmD -= PiAfBQdMhA;
    }

    return 984587.7207709983;
}

bool cfehvjIvYkakwRO::cWgHHzbYSKj(bool cypQvfwphIkiQjx, double RVPZKaBikIhyomRk, double pkFvKokgxc, string SPHjRZJ)
{
    int VLaTBZgYvwGnt = 864422563;

    if (RVPZKaBikIhyomRk <= 995173.6390623447) {
        for (int OnnFa = 1643814212; OnnFa > 0; OnnFa--) {
            RVPZKaBikIhyomRk += RVPZKaBikIhyomRk;
            RVPZKaBikIhyomRk += pkFvKokgxc;
        }
    }

    for (int xTnaq = 291823961; xTnaq > 0; xTnaq--) {
        RVPZKaBikIhyomRk /= RVPZKaBikIhyomRk;
        cypQvfwphIkiQjx = cypQvfwphIkiQjx;
    }

    return cypQvfwphIkiQjx;
}

int cfehvjIvYkakwRO::ztFMkDtrXuLLHMG(bool srIqwGDxaJpVn, double EIgPCBQzn, int CoTXWKQSjiAE, string ErrNce, double dUiWm)
{
    string yKXEPcd = string("NnLCqGUKkHJvTsoNFGLcLukjmzQFoLyOwCpsA");
    bool IeKgi = false;
    int aaMyRCdPqhOkWT = 153917573;
    int nwpXsNWewjJ = 478194529;
    bool djfOaNbbjT = false;
    double eKLQVkm = 786343.0214240414;
    bool xrAixUmIZkpnGRj = true;
    int VBZFTfLNJMR = 944330009;

    if (djfOaNbbjT == false) {
        for (int wvStfYnLRmeESNg = 1023464453; wvStfYnLRmeESNg > 0; wvStfYnLRmeESNg--) {
            continue;
        }
    }

    for (int yZdUsCZgbw = 1913634231; yZdUsCZgbw > 0; yZdUsCZgbw--) {
        continue;
    }

    for (int nCrKwKPFhGa = 1390854070; nCrKwKPFhGa > 0; nCrKwKPFhGa--) {
        continue;
    }

    return VBZFTfLNJMR;
}

double cfehvjIvYkakwRO::VJUHOYLF(int wcbjgqZUpWuNLnL)
{
    int FsgAWlmxnJahOT = -325025861;
    bool OLVWroEVrUENH = true;

    if (wcbjgqZUpWuNLnL > -325025861) {
        for (int Jxweimi = 1812703722; Jxweimi > 0; Jxweimi--) {
            FsgAWlmxnJahOT += FsgAWlmxnJahOT;
        }
    }

    for (int MEPMjqzX = 500668589; MEPMjqzX > 0; MEPMjqzX--) {
        FsgAWlmxnJahOT *= wcbjgqZUpWuNLnL;
    }

    for (int FMyGmZJQ = 738141582; FMyGmZJQ > 0; FMyGmZJQ--) {
        wcbjgqZUpWuNLnL += FsgAWlmxnJahOT;
        wcbjgqZUpWuNLnL = FsgAWlmxnJahOT;
        wcbjgqZUpWuNLnL += wcbjgqZUpWuNLnL;
        FsgAWlmxnJahOT /= wcbjgqZUpWuNLnL;
    }

    if (FsgAWlmxnJahOT != 24460844) {
        for (int ODVBGMHnSgHfhcc = 2072834638; ODVBGMHnSgHfhcc > 0; ODVBGMHnSgHfhcc--) {
            wcbjgqZUpWuNLnL /= FsgAWlmxnJahOT;
            FsgAWlmxnJahOT /= wcbjgqZUpWuNLnL;
            FsgAWlmxnJahOT /= FsgAWlmxnJahOT;
        }
    }

    return 313050.7646213291;
}

double cfehvjIvYkakwRO::SDwlCmahRUShS(int KarkbYuTu)
{
    bool QZDPbTCPoSViAgw = true;
    double XDcUTkQNbtlHE = 491715.78981490573;
    double uwZxYPbbEi = 537696.0532026617;
    int IyjfStOCi = -184983753;
    double gzDyyHwVTiRcx = -163797.31053517375;
    string YEYQN = string("oeWzTQeakWfZxxniLEVdrALPAbbVyLuofSYxeQWLWifonOHcTREZcWFoVkJgDCVPMPhFnFwiSatuLRwqbdXznuqyQubnTgEgaEToSJXtTQqSkgBndWLGMugVskDmxHJaIRrNwQreG");
    double kfFoQggCgo = 189241.0944543545;
    bool gLzaUGevI = true;
    int PkcnxSkOsf = -393293169;
    bool xKtXOpQhSbSDKLq = false;

    for (int nsYwMWdgFTf = 519735241; nsYwMWdgFTf > 0; nsYwMWdgFTf--) {
        continue;
    }

    if (gzDyyHwVTiRcx == -163797.31053517375) {
        for (int YXDnuvUQSy = 469007515; YXDnuvUQSy > 0; YXDnuvUQSy--) {
            PkcnxSkOsf *= IyjfStOCi;
        }
    }

    for (int mbTrzrrXPMFt = 1017493243; mbTrzrrXPMFt > 0; mbTrzrrXPMFt--) {
        uwZxYPbbEi /= gzDyyHwVTiRcx;
    }

    if (kfFoQggCgo > 491715.78981490573) {
        for (int NddGg = 29309809; NddGg > 0; NddGg--) {
            uwZxYPbbEi += XDcUTkQNbtlHE;
            PkcnxSkOsf /= PkcnxSkOsf;
        }
    }

    return kfFoQggCgo;
}

cfehvjIvYkakwRO::cfehvjIvYkakwRO()
{
    this->qZPwIupoaxNJCCqE(string("GWiSNJTrzbVkNKNXcBKYgGFvpoEiQBSUbaQJftfwzrIHGNVvjTNAZprmkFmOarvAlMDLOfcvcXmKuuiOOqwYDuTysLIpJMeIrqiAVYuQajnHugRMgGzNPTiFhrfAejowTZYp"), string("UfcnVUUdUWSddTNTWvtqBrDtIxtlkSMgKRaDTCiufOmlIPTxjuOsOqWYxpGgNOtEPctiiepxPskkVsNfzySUubLrJXxuBMRFgsWleVRNWORhNjUKsNtieLeXJZUFQzTscXjwRVQYYRXSkPnYBJbwkUoeKERSTlALpBKQpHKkzE"), -8864638, string("GjnKDJJFddhQNjhFcZoCAAKTsnshIsfycFVwEAMRNkcfVLxaMKxOgBcTuFEYtBdvnViOSLljTqdNYMoVOifcHMMONxWoCOQEEzfmIafrUabVMdxMspGDwJOhWDzjwdxZDRkjsAexFtTjtXzRyMUzlehuUgCqdywxymA"), -1043051.0173213984);
    this->bAbDx(string("yITTmLmALclTlekVGqhgrTkUJJRTdieMXiIGfOONiGfBFsWRvJpzkHziesrKZSKMXujztonJwDgDhOWlnivBwSmomkVJTCbsiZPhYCDTCoXJBZRpPqGPFvILnYswJOJwTuQhFOohPdIHkEuTdDJZaQJoCKHOPbJhvOkoTguGlemjPyOifJwbfPrjcLcumfpnHSceupvgVzWSOMbxnvvgAPrvhCkCLxOZEoSWFwntLEmoFfI"), string("tElQluHZZAxeHhNOPaSJAwUeOkVKBvnAzaMvsItsEqUsrRbLfncvJZxAbWOHYibAWvpOUqUQtUikMYFyIqjvWlFQMZQHhTfneDQHSbfXSmMfzpGMlWXhDIeWknLrrrMXYxRqnBbfzmRNCURKMRtiNvnohUjynJRZjijMkkxdaVzbnWVcTEGOEdPDUddiydliybNkaKNkzPeuGOPppPUswMmTgwdIfVWe"));
    this->QdBiEGEnGpMq(string("dWyNVhDGoawibHpusHTtvlZOJTKDWlidbldxtjkyqT"), string("SRCosCVbkVbDHTuQDcMwtIZZUZkWEpGuLaKiorGCHEVsKPvuuqKugIevwmrpOckhBmBxskiGWYhdkawQgSCHzesQEwhPmzGHsCwopHHqILIMvCixFLlAAcVHGSTMlZmUcrgLrGQHgiEEUbvXapYDkWPKvIbTOoKLBxbmdqaTHUhQONKNBrBgbaoqREGCtoYhVwDxpDt"), string("CdONDEKnqnOqQDcltrxvmVrLooJyGSfUhQnKqoOocQpWYbQHSOZkwohQRKAjhOLKXtdQWQeGByZLnWsrMLFlpbeLQPkrkusAakjgFlgDBOvETAjxhmzbvKIFlgiZxsEDGdsaXtMvfZhhMoQiiOIMGQuTSTVRIqPUIiKkiNCBdNvZpGYsRYjnIdXjPMVUBeHLovBKfCNMIElmGjC"));
    this->DebbTESRGZa(-1816201369, 1035389940, 156665.61175037865, string("eeDfRnxyDkmIPGEKykQCatCdwsWzqMjFQneyDMCGGVttdZHcZdssYIZCKkyzlNkOrOItMfabAEWjYQvXjgNrnSCNGgmcUIfSWHD"));
    this->MIhxhRoLpjPOBj(-64025.27928556849, string("JnXHyFAItauJAYsFrMEnnGXrklvWXRasEXaudfBmUZiJTSXTVyMazOAQQrfeElVDxUelEnlJVArskGsilrcZPMvBOanpgpwyiYKgIoEwHbPgEmgotsKpMQlMzNecxePOpbvogHAbHmWNEZBElDSSPEWauCPZzxYclXIAdOvqcrsmwTwZLJV"), string("CiUAqNSVpCWHwHMhTqtrpsZYNhZjACxkfHjQrignWdnDjGTjFRHgdAfnNamQQDgNivwqswzKtgyIFSOdrpzjlCDecwRsdqVCzLMZLgPUYbdIHjaodyGGxTqukpdkWtquaWDgqIKpYEXJewHDHfhhbLkxqlFenBoDMYyCBtASp"), -1543382954);
    this->ukmCYk(-1167738075, -1463598008, false, string("RIUCciXbHnbCIbgtMJCwUkgqNxRcNlHvplWNETuLpyrPHvOKeRHevsteRLwHYxaJpTNKKkgxMzPlbPeRojeGJxrRBrulNKrVrEmzMPIMazTxRFFsQtvEUZOiwGZFoKxEeVthaEGihaiBeWRSrfGkMibCfzwwaawJeNwahylYghMoeieuTKVRNSpoSGKVTDvHnhPMOrXrxOORdYhbUfAJDFgmrDxjVOrwRZERTckHclHVkCgcsnODqMgfds"), -408831.6832132465);
    this->SJwscacOiaMu(-841428762);
    this->DZTmiLpQrxZKpz(208853222, 122318833, 223612.55963530534, 777116784, string("DZNRSLtpQCEdTSbQMuQBBKbUjuYWysRTwwvObTaSJYxwUCPdIdEuPntjkGLciGetTMXsKNkFBQpEepmPuiEyOuhNOntMxRFvfKTIUTzuoheDziSjSNkXvdZbGhUAqExGdbBjpVzyFivZNEtdNcruJrlnVFKQLkFSLRtcTOvhLJACRkLRAwNfUuNwEvJrVcIgzrxEdpMLeulrazzrUCSTVIAIYoRJAaTtpyngrdXbGlazgAUrzkXFmTvszre"));
    this->gDxLOwoOpHZvDO(1627766773, string("DsdIrtSjCuntRWLvNyfmIZKjhbTAvwKlQNggAXFcXNlQAJ"), -70256849, string("somWRHNCezvghNoBSVhdxSSekvqABWwPWMcZaVHFYGbveqHYaMQqhXDekKokJuNMVoJSTotVzLdYxXnbAplupWQPGVfoXOHSZSbkiXCMph"));
    this->FqaXUWRzstWIphiD(true);
    this->TAkGKgcQiN(585729.6302953031);
    this->aNxVqL();
    this->VEuukBPxW();
    this->ZWHfvuQdFzcbIDa(string("hUpzOWAlJPwtabEJBdUdWwFlzvMcouEuhQctHwyLOdYpBXYMNGDShZeJaPlfxsuQMNLlXwNQKYBOgSYZeBEZQgiJkqXklZKroLTeOYBlKJvxNPtnUCbtMbWlcXlbSSFqNIUBgSkGHlbzwcgqCNIbtuyNywMYtMD"), -704304.3165444433, -710523770);
    this->XTKXYYzKSydJ(-321469.9702627303, -941548.8769229266, string("XYaHHbvUMcWiBysWsUkkzrgQRuiSwysJYOprKNvxQGPghqaKLXYVrToKEUaAIivSaYeYcBmKSThooAhlcMRNhLHjeKvIWThkcWYrvIbYwqBDAprBvBDTshwMEDrObwyiqescOwLsAaEGEjfHnHcNSnAfQDyTjmdBqFScCBKgcdsDkzUiyBSEVRp"), -270331.5608219398, 876893.4390439793);
    this->JFxFgCpPPGtqNq(string("EnuJpXdbVZIfZGiRHweSpVcGbcBTNQMKiIQLWoHjEbSAsKGXyTInfHbwHtWozjVSOsGhAGpZMkYjSWlLabiOmwYvdWoxnERuNMokoqqALAlQfQKeakYZHzQtZPulXjqSLhuVZBwaKAsKckqhGiicIaPqZCYOQJZBqZXumHQioAnTtedbVCQNDVGnFJXgXNTYGWMgguDrvOkHLfgBdcrEQybpHFpAsPcjaFznpFEvQbRvLLjIscivaVsfn"), string("piGvqjhyrMDBoUcTZHijVcwaYmSOYGaCeDtBMBXrCYBBawDPWZxwjlHhOkQPFxrofVzcxQBHAJbZxajOjcAKrtFagnOUrJXtivKZceExyVKeNarsNqppnrLsDriErRQULHNSgfuYrFShsysAiiubWzbhCMRomrVqpGLeAVqLYlztK"), 1569483132, false, string("olLsJydpixJTsSFrjKzZqwQlZDKzGfsvxUJIIfPntbHwLujLqmQhzQaqaWUlWyfxUeLJHkKnClsxnalMMHdPXMNnMjBpumNiaIzAmmAyWwyghnyZooGuFggKNNG"));
    this->cWgHHzbYSKj(false, 995173.6390623447, -877345.3349192545, string("SXtPROfrLJZrToVVioqhJjqroVstbPACIhPZIGqQmMXNayAhSGrIfVdBTRlAlhlyZNOggNYpwEQuVLozruDaFGLDocCmSWmCyZiyumSRUZzjVzyzqHInMfoAfEiwcstGRwbmjsUJBrwjnyYpnwqBzbgKLHLKIfHCkidaHWLsTGoCVEmtrfeOdVXyAM"));
    this->ztFMkDtrXuLLHMG(false, -293590.8934446228, 166986260, string("hZLxfDUzIOmfvZpjSnLopdwnftoAhmIPvOaNAeWFsMiaGZaMHVZDXRgleHIaIPRSNhSqHvkNeHoZkDakAhZcoDOZdCJZvLOtqbyPWuglbBsxXEclEXQkIqxrchlEFMAFjJOtqCCBpKygfymxYzIxGGhUIGYNVi"), -356314.40322087944);
    this->VJUHOYLF(24460844);
    this->SDwlCmahRUShS(270771505);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yZXyP
{
public:
    bool vFjeuOrM;
    int WfydGC;
    bool ABrxmMvYncgQdj;
    int uEcuhOu;

    yZXyP();
    int FXCIIlsKaWpJtzmA(double UqaVwXWQjkt, double tHmrrpVOjkWwKqR, string eKGEzgT, string CLLQfCTbDfjQVQ);
protected:
    double YmWUfVXmQrl;
    string jHvSutXj;

    int jeFwuUmELthQ(string OJTUo, double BjsACJwVgHUC);
    void RAgnAAWsFjDZmLG();
    bool qIwcqwxRSpJxPv(int DNBUpR);
    int awSfjt(string FqrlJPKk);
    void jEUtnojzcU(string QRCkireoxnX, double vLMyroXSRw);
private:
    double oDYeYmSuoC;
    int MCfCRMVATwbqqa;
    int fKDYcsm;
    int vscYjRtJYTHj;
    string JAaIfPI;
    string yDWRHgaB;

    string NkdAytmFJcBOco(int audGHFuEAFdKI);
    int ZooLGVLMSHS(bool sTDamkCjl, double AFfIWFebwTTBCbg);
    double OrPlOQWlHrsmN(int LbfrSaSj, string CQtONETAkYzUS);
};

int yZXyP::FXCIIlsKaWpJtzmA(double UqaVwXWQjkt, double tHmrrpVOjkWwKqR, string eKGEzgT, string CLLQfCTbDfjQVQ)
{
    int ZrKFHhvfwEAakv = -56068657;
    int GBmABFLstVlBMTHR = 1079110236;
    string XuqaA = string("RPdPZBaHiNQGTqNTuDcLEErynWqLgmMEXxktPtvhQWGETIDP");
    bool PsUBXtJdQvona = false;
    double UJTXOwOoSduMZcOs = -548276.0786073615;
    bool rcwVbDbH = true;
    double WOjVAR = -703004.973432832;
    string MPmWRfQONcpAv = string("bCqWFJAJzfecKlYAWEzxPCLEguYNmOcPznREEuzRwXIjRTCTkkRYrruHbphlDgByDtzHtZpHceiAPJDSHlDVACwTemKxCVEtud");
    string sHhpH = string("efgUcDgCnPxQqhhCczpEvxwImaUvlusSyinVBcJkPQHDXjCEjmAXosMeShhtjSVafyPHOTFmgZeFOdjgwzBnuHCnBCxSaeSvNVpaTlbcXdzERSuCBsBYaRtyEbuFXkbPSnYmoaXCZpqFlNhgWbnfVgWulIHoGtFjjarSXoGzIDEKZgDnAQUQGtmlyYYfeeITzVvaIbHsSNPFsyoJjDOCGslFrIyaGNjNDohvnjMYkYOunxvbszvgDKgfNf");

    return GBmABFLstVlBMTHR;
}

int yZXyP::jeFwuUmELthQ(string OJTUo, double BjsACJwVgHUC)
{
    int sgQjpmjUBb = 1392888744;
    int kiKqTKykmOe = -500431120;
    string dWiLTiPgBfopDU = string("yibrjcQqdOgSTeFRCmSqDpsgPNXnttWByacwiwnWEYVJfOPthAPqs");
    string comizNeHMWqmyUZ = string("MHWLXzpTLUcTHYUQDiikzCYGnWptvWmpmgJQtpfIuKdlcLRzNpTRFbSWdJvhtpKuLsIHVAKMcwRKvKxbiSnLUKCGVPAatbxtfFKtcAiHJYqbAsaoNmbdbfeKGLUuzITknTCNpmNfUFpgSSlzILiTWrwFuTNuxOcgoBzKkxHbetsPhqmOIO");
    string ICetDXed = string("bdgQKmucAvaxCQmlPVbfhJTApIAnuuHYRKuGqRyfVViPlMiKYvXtFDuVLjwPFbWYgDwzmoFwYKsJvUFmGZTefcqMp");
    double yRnjOFNzVCs = -263706.8514673691;
    double SJZJoFjWoamaUct = -903740.8860177223;
    string nWdKdsd = string("vnnTXNFSrLhqclKxIKbfusUEobkoKucGpfFtlSisVKKWfkVNbNPArquXWRakFHVqrIlLOTtbfPEwpPfojoBiZPMFWNmBsfsrivsTSEAzHbdCEbUlHpnalSLMrYPwIAeXWMUpgzXBadjmIjQsFLMiJcrYujledfNGtzIzVilzzVkxapKxhJyNp");
    bool uuzafqXslDVYqbii = true;

    for (int IuJrFQpCPfElT = 1685009523; IuJrFQpCPfElT > 0; IuJrFQpCPfElT--) {
        ICetDXed += ICetDXed;
        uuzafqXslDVYqbii = ! uuzafqXslDVYqbii;
    }

    for (int tgjjC = 820221224; tgjjC > 0; tgjjC--) {
        ICetDXed = comizNeHMWqmyUZ;
        nWdKdsd = OJTUo;
    }

    if (comizNeHMWqmyUZ > string("dggzZKkYeEbUcWTDWVGotT")) {
        for (int TGrMqnLZbr = 302028046; TGrMqnLZbr > 0; TGrMqnLZbr--) {
            nWdKdsd = ICetDXed;
        }
    }

    if (BjsACJwVgHUC > -903740.8860177223) {
        for (int DCaeBaVnZMuxtZpm = 1740912658; DCaeBaVnZMuxtZpm > 0; DCaeBaVnZMuxtZpm--) {
            ICetDXed += ICetDXed;
        }
    }

    for (int ugMdNnyyev = 1891536147; ugMdNnyyev > 0; ugMdNnyyev--) {
        continue;
    }

    if (OJTUo != string("yibrjcQqdOgSTeFRCmSqDpsgPNXnttWByacwiwnWEYVJfOPthAPqs")) {
        for (int oLUKMXWzK = 185934039; oLUKMXWzK > 0; oLUKMXWzK--) {
            SJZJoFjWoamaUct += BjsACJwVgHUC;
            nWdKdsd = comizNeHMWqmyUZ;
            OJTUo += comizNeHMWqmyUZ;
            nWdKdsd += nWdKdsd;
            yRnjOFNzVCs -= SJZJoFjWoamaUct;
        }
    }

    return kiKqTKykmOe;
}

void yZXyP::RAgnAAWsFjDZmLG()
{
    double DLcTUyDgLNMbH = 370356.78119380557;
    string lWGOxWVAEeIgNCZ = string("ySfBR");
    int WeKpO = -866225712;
    string WCzwlkrGbvRp = string("nxvpjlENTKEanCqPvYBwLdgmQxXSfqCKyaiyJCwDGrGoVqvheIhoWqQAbdqkmZLGoVCUeGYOaCRZtDnryupZsBKQeppuouBcadIvddsWolewNqOpzNvwiuSOrKNjrddIKXQWtaQseYpXYvzeXqMboaoPzzCRGVMbMVuIqjrERlBeVBzbHTFlLlbBRdkafNFLc");
    bool HUJZXODEsSDdeAWy = false;

    if (lWGOxWVAEeIgNCZ > string("ySfBR")) {
        for (int qUacSULwVplhFj = 1005035876; qUacSULwVplhFj > 0; qUacSULwVplhFj--) {
            lWGOxWVAEeIgNCZ = WCzwlkrGbvRp;
            WCzwlkrGbvRp = lWGOxWVAEeIgNCZ;
            WeKpO = WeKpO;
        }
    }
}

bool yZXyP::qIwcqwxRSpJxPv(int DNBUpR)
{
    double jhBoptFvKpXY = 558998.7383142172;

    for (int zBvfJRK = 2104940639; zBvfJRK > 0; zBvfJRK--) {
        jhBoptFvKpXY -= jhBoptFvKpXY;
    }

    for (int ozuTMhcYh = 787236344; ozuTMhcYh > 0; ozuTMhcYh--) {
        jhBoptFvKpXY -= jhBoptFvKpXY;
        DNBUpR -= DNBUpR;
        jhBoptFvKpXY += jhBoptFvKpXY;
    }

    return false;
}

int yZXyP::awSfjt(string FqrlJPKk)
{
    int AcNNtkudRFHwiZw = 628318218;
    string xYIbCmRSolJSY = string("oavxoYomgeCDPUqAaifxIMzVXCGOwerPtrWfloxjZpUrgAAtVaOIGAFsVFLeUTuQxfcgdpOSBdeQOaRLKjJUIJfEMyLsciQMgXyuycMNGxYMaXwLeiRdsHt");
    double TjxXarULUtmuN = -542232.5964366134;

    for (int eakmdtrSv = 1572235177; eakmdtrSv > 0; eakmdtrSv--) {
        continue;
    }

    for (int SKHnjnVw = 768611368; SKHnjnVw > 0; SKHnjnVw--) {
        TjxXarULUtmuN *= TjxXarULUtmuN;
    }

    for (int zImXQ = 1039630103; zImXQ > 0; zImXQ--) {
        continue;
    }

    for (int sHcaXeSCm = 901363648; sHcaXeSCm > 0; sHcaXeSCm--) {
        continue;
    }

    if (xYIbCmRSolJSY <= string("eoVslKfBipLclYtAJEQMXHjanrOgsyxdIorUXPmBcrKgnDEbFPwozawgFOnSLwYuNUhAZYlxXQSpipgccfNEdPRxuxvWUhaedECFyoemuZtUyTjRkWBxPuLFjoEnBRnirmFILknMaRCUEMTaHuWwZVPCAlUgcATuxNaIrXyKTJVrdRdhgycqWtPssdOYjOuytkGOrmUXdqMIlyEKfZkUocZpirxXBIzUc")) {
        for (int eTXjQWWOCNKB = 1574223702; eTXjQWWOCNKB > 0; eTXjQWWOCNKB--) {
            FqrlJPKk = FqrlJPKk;
        }
    }

    for (int KYBxdVQHnH = 1254199676; KYBxdVQHnH > 0; KYBxdVQHnH--) {
        continue;
    }

    for (int YxfbBsMMELjugJdD = 1078129236; YxfbBsMMELjugJdD > 0; YxfbBsMMELjugJdD--) {
        AcNNtkudRFHwiZw *= AcNNtkudRFHwiZw;
        FqrlJPKk += FqrlJPKk;
        FqrlJPKk += FqrlJPKk;
        FqrlJPKk = FqrlJPKk;
        FqrlJPKk += xYIbCmRSolJSY;
    }

    if (AcNNtkudRFHwiZw < 628318218) {
        for (int pwHuiCS = 2010521062; pwHuiCS > 0; pwHuiCS--) {
            FqrlJPKk = xYIbCmRSolJSY;
            AcNNtkudRFHwiZw = AcNNtkudRFHwiZw;
        }
    }

    return AcNNtkudRFHwiZw;
}

void yZXyP::jEUtnojzcU(string QRCkireoxnX, double vLMyroXSRw)
{
    double BtyRHMYMWArCgHek = 845023.9695715023;
    bool bqDhVQgnXKf = false;
}

string yZXyP::NkdAytmFJcBOco(int audGHFuEAFdKI)
{
    string FixvtcnYhuySH = string("XZlSDgYnBYDCZuQerGcCQChQRUFifLgxVqxDTQVYXYznCZNOwbXkazdc");
    int xPVDq = -558298753;
    bool DSaInTTB = false;
    bool omOJVpv = false;
    bool tbGYlsZwA = true;
    string nPDOKLNCgJtBGWM = string("SRHbPmlchGMuxkpZuhgbDTjdpIaKmwkGalwZVmgFCIsBCHIUXMEcBwTmaauEmSKSDvegzbMGNUpipUkgcxjTLaxdEafujUSlhNkxUTheMzJWsDTDvVpAbzKrRoMCamWPhdTYKOjWkDMcEVPpovBHfOEbUvBlKAzYzJPtCVXBKOojNFdvIsHGjyWkNdsf");
    bool QxeAseBbunlLm = false;

    for (int CIegDkTw = 169722723; CIegDkTw > 0; CIegDkTw--) {
        continue;
    }

    for (int qniJukGKxsjX = 868418508; qniJukGKxsjX > 0; qniJukGKxsjX--) {
        DSaInTTB = ! QxeAseBbunlLm;
        FixvtcnYhuySH += FixvtcnYhuySH;
    }

    if (audGHFuEAFdKI != 1500233690) {
        for (int krfwgPRFlPgH = 457702754; krfwgPRFlPgH > 0; krfwgPRFlPgH--) {
            xPVDq = xPVDq;
            tbGYlsZwA = tbGYlsZwA;
        }
    }

    for (int iwzKASCRCs = 377006219; iwzKASCRCs > 0; iwzKASCRCs--) {
        nPDOKLNCgJtBGWM = FixvtcnYhuySH;
        omOJVpv = ! DSaInTTB;
        nPDOKLNCgJtBGWM = nPDOKLNCgJtBGWM;
        nPDOKLNCgJtBGWM += FixvtcnYhuySH;
        QxeAseBbunlLm = DSaInTTB;
    }

    return nPDOKLNCgJtBGWM;
}

int yZXyP::ZooLGVLMSHS(bool sTDamkCjl, double AFfIWFebwTTBCbg)
{
    string dKBiWD = string("lRWabDuYAvuiejTRcNtyshaKxlfmnyYukWqGcZEeQ");
    bool vHNTHfSA = true;

    return 500463802;
}

double yZXyP::OrPlOQWlHrsmN(int LbfrSaSj, string CQtONETAkYzUS)
{
    int ixcdhkqDWCboMOkR = 1726162560;
    int MBLnVnyydFN = -627314653;
    string QfVuKcHdlPITZ = string("hlQyTlFYOlpjUwebBkoiexpsIevEIVpGHCrHLfKVRSgezuwwxgKEZUanItbHSOscBXwxTIiFAbotdTHtYxMhgQmfTlFhucPcWmpvqxDzrWYYIIZDDJUTBZSmDFxjJphdxfGdnbAuHGQVeEOoFbKtQfsdFqRZoRaiuPBtbOpvzrGu");
    double JjHPTKYAxRiybStS = 1030839.088305297;

    for (int CkxpK = 2048341994; CkxpK > 0; CkxpK--) {
        ixcdhkqDWCboMOkR /= ixcdhkqDWCboMOkR;
        MBLnVnyydFN = MBLnVnyydFN;
        QfVuKcHdlPITZ += QfVuKcHdlPITZ;
    }

    return JjHPTKYAxRiybStS;
}

yZXyP::yZXyP()
{
    this->FXCIIlsKaWpJtzmA(890969.3490074319, 939177.1870019888, string("vJhRNDcvyIFxcsbBOvjtoRfCrVjlLihUyTbc"), string("AKAtXIWEoIpWkwAewWdUosuyxDQUOlPaBgKzuJPdHzOOgDsYVowAWoWvtLzngNnLL"));
    this->jeFwuUmELthQ(string("dggzZKkYeEbUcWTDWVGotT"), -229468.6754734382);
    this->RAgnAAWsFjDZmLG();
    this->qIwcqwxRSpJxPv(1442828532);
    this->awSfjt(string("eoVslKfBipLclYtAJEQMXHjanrOgsyxdIorUXPmBcrKgnDEbFPwozawgFOnSLwYuNUhAZYlxXQSpipgccfNEdPRxuxvWUhaedECFyoemuZtUyTjRkWBxPuLFjoEnBRnirmFILknMaRCUEMTaHuWwZVPCAlUgcATuxNaIrXyKTJVrdRdhgycqWtPssdOYjOuytkGOrmUXdqMIlyEKfZkUocZpirxXBIzUc"));
    this->jEUtnojzcU(string("EZRSdZYkPicOKdlYEoQaGhspxGvvUwBgXyNQocrQTVmKnwxxBJcZvoRydEEoGAdKbkplzESMQdIIisUdXadXHEsilwpAqVmjvCgAPwjYmZrlmOGKhLuSqaRkfSaWdIxNOFYGnLgoCJSIDIyIAFTYKXHGpmiPCzSRhmUaXqSEInOdMLtju"), -471856.56479471654);
    this->NkdAytmFJcBOco(1500233690);
    this->ZooLGVLMSHS(false, 398930.8145976959);
    this->OrPlOQWlHrsmN(-133783707, string("mPHpQURcVi"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cKxoLX
{
public:
    int TNIZOJ;
    string pooIgmjttEv;

    cKxoLX();
protected:
    bool mHMuGnKUFRhnfurk;
    bool zMKXObooYXLC;
    bool AbPLYe;
    int kwXvbVeXtt;
    double vWMsvVIQgNFYsu;
    string QBKhRxCypP;

    double vGEJHCHneR(string DoaYD);
    void uvMosZKviHr();
    int nCQDF(string qjxlak, string WVVDmaZzDVyM, bool fleeRMD, int uJnzO);
private:
    double cmGWAnRl;
    bool NhokCBg;
    int vklhErxZyB;
    string SPzUOuS;
    int UUNXiMyBGhjhJpvD;

    string ucZCZL(string xwhcQRqHMMDwLqQ, int wMCMvjAzEEm);
};

double cKxoLX::vGEJHCHneR(string DoaYD)
{
    string PrHNCUHOoxvHed = string("jVgBlDrAbGrpFtDIkeDTlfDoQzXnbvUOPsPvSPTroPfeStZEKQgfCfimeHMMSgEMmvvUqTlxDrDLVXccYEXaNTHZBKYczuCiucBRoZKzMkaEGcqpWIFdgWlvgEmwQYfdFqkQbaoPORIaCoONd");
    bool qffldqzxhRH = true;
    bool ConbpV = false;
    double xKSqBqAZ = -16248.651071559412;
    double qHQDhJagFiN = 181242.67593444904;

    for (int wtkIL = 2021872145; wtkIL > 0; wtkIL--) {
        PrHNCUHOoxvHed += PrHNCUHOoxvHed;
        qffldqzxhRH = ! qffldqzxhRH;
        ConbpV = ! qffldqzxhRH;
        qffldqzxhRH = ConbpV;
        DoaYD += DoaYD;
    }

    for (int yapTDjkrVZznK = 1998586859; yapTDjkrVZznK > 0; yapTDjkrVZznK--) {
        PrHNCUHOoxvHed = PrHNCUHOoxvHed;
    }

    for (int SXEvFrfzT = 686098457; SXEvFrfzT > 0; SXEvFrfzT--) {
        DoaYD += DoaYD;
    }

    for (int tIAGDNFEvVZz = 1299553872; tIAGDNFEvVZz > 0; tIAGDNFEvVZz--) {
        continue;
    }

    if (qHQDhJagFiN <= -16248.651071559412) {
        for (int KJiIPn = 1289916786; KJiIPn > 0; KJiIPn--) {
            PrHNCUHOoxvHed += DoaYD;
            xKSqBqAZ /= xKSqBqAZ;
        }
    }

    return qHQDhJagFiN;
}

void cKxoLX::uvMosZKviHr()
{
    int nltoqc = 1029448204;
    double lFVseYOEb = -574610.0178059858;
    double pnZveAExsX = -662773.778405141;
    double QPEJCzT = 28147.592690472156;
    bool lYUUAtBM = false;
    double ZaqOXOd = 791085.3203383982;
    double yoCYi = 824195.6298446509;
    bool iNOlUpJTMGdpz = true;
    string cXkiMPuXSMmzw = string("qedEuqXbLiBtzOxYQbMcBoQtfxNNsFRoapWIDgxJMrBsdqujkscCpRWlFeklfFNuAoIZVaIrHJPPZtRdGMfGtaVEyKnmsXwudbiembRZijPRJGpHFYjtKKYrJQBAWGSESdfbKlJrgoqaVSAEcsPLcGpQrwQORgpRHCbHpKFqXBLIhVpPYlXpOMNwOEz");

    if (nltoqc >= 1029448204) {
        for (int lXwyWPy = 212730284; lXwyWPy > 0; lXwyWPy--) {
            QPEJCzT /= QPEJCzT;
            QPEJCzT *= QPEJCzT;
            yoCYi += lFVseYOEb;
        }
    }
}

int cKxoLX::nCQDF(string qjxlak, string WVVDmaZzDVyM, bool fleeRMD, int uJnzO)
{
    int IvKRGxFNPyVvG = -1853333806;
    int fyvlpmkCYFzq = 1631343347;
    double cJrPoCGISHK = -710459.2029419657;
    double lWeCNLPyqa = -890237.0721045985;
    string MXMPbYxn = string("uTGUaSpSAKNYErnsiatpIaNFWYMJAIREHlNaRTNEDCbEjIqVMWZGeTQuKyxLltZJphLTXDPzBUmhAbhQiopWnmACClvtBoJPqQXdTdDYQAlPvWLRnovyGFwTclBSNkGNShhbehwDDzXyFnyEfvOSFSvbwIwjKMdhWnqQxBbIDGNRwqTIjSDbbopYJadVLXQfGrvFVkcUiFQVr");
    string fketbT = string("WBOsYnNjOVmBuqYVtAKhukDhZWkWkHCUTvznUMEVjLM");
    double YCHUPTuGSgc = 552197.3240659595;
    bool Muxnfe = true;
    bool oCCVIUOOdxqtNo = true;
    string MMSxLPFmjoFYKPzz = string("gXUoNrYUOdIlkEpzmlMJsygdseAmKLpYybcsKEcRPftwwOGHtuFvCpHxRQkDCxufFFkDCMBJSqBtTxEJVZekrFiRiYuEcvWBHrPKtPxnFgGJUCyeNAnitaedaUkDRBuGyXfkatXIBsLX");

    for (int oCCRAWP = 1449084781; oCCRAWP > 0; oCCRAWP--) {
        continue;
    }

    for (int BOpTGXYgU = 2136237019; BOpTGXYgU > 0; BOpTGXYgU--) {
        continue;
    }

    for (int heAyIqjtYWZM = 1617957948; heAyIqjtYWZM > 0; heAyIqjtYWZM--) {
        fyvlpmkCYFzq += uJnzO;
    }

    return fyvlpmkCYFzq;
}

string cKxoLX::ucZCZL(string xwhcQRqHMMDwLqQ, int wMCMvjAzEEm)
{
    double ptLHNpHXk = -920112.6931927545;
    int AJSfqpFnq = -1564763379;
    string NpIOSf = string("RBszrbHuwZkZrpzHNphAQzXtirkMALlsCezNbVPxDYrPxfmuMuFfZrXWZcwdiFteKGOfhfpvJLXZItHc");
    bool zJipmEv = true;

    for (int EnNNiwRrCeByWWjH = 698937162; EnNNiwRrCeByWWjH > 0; EnNNiwRrCeByWWjH--) {
        AJSfqpFnq *= AJSfqpFnq;
        wMCMvjAzEEm += AJSfqpFnq;
        NpIOSf = xwhcQRqHMMDwLqQ;
    }

    for (int LutQLIF = 1433557696; LutQLIF > 0; LutQLIF--) {
        NpIOSf += xwhcQRqHMMDwLqQ;
        wMCMvjAzEEm += wMCMvjAzEEm;
    }

    for (int inPajeFNvU = 1205105713; inPajeFNvU > 0; inPajeFNvU--) {
        xwhcQRqHMMDwLqQ += xwhcQRqHMMDwLqQ;
        wMCMvjAzEEm -= wMCMvjAzEEm;
        NpIOSf = xwhcQRqHMMDwLqQ;
    }

    return NpIOSf;
}

cKxoLX::cKxoLX()
{
    this->vGEJHCHneR(string("pfYFvsnyMXTHzePPGffXwQWEeRJ"));
    this->uvMosZKviHr();
    this->nCQDF(string("WqMGemZlSkmjjhMHuBbCceIovarDmEUMOemWLDEKdYnPJjodfaTffFbTtIuqetXdpzuSMQPsdOoUETAbGPtgTyzcurGEgwAKphgoAggBWFPYDfXdUnHXdhAeCvcmUDAWscdgLPiVjAOJQJJZedYTqhssHFskyOdDzvyrmZefkGIKbdMxRCaUgeIewidMaCXnCzSIGXkp"), string("SGOpFHKqiEFhIVsLHxEyTlzCrWRHBqpTQwyUuCCwAnMqgtcsQHqCDSMxsYCMzgeiENdsyJQZtMDmrLTgNlxnJUqJpNodDjUHBnfdeeBqUbeAzyOFlylZpyhHoBMZaAxjPrlGNQRlZATnGEzEgbcjfovtcSeVHPwYkzShYwfpQwzsyRnSjkISTdgOiEohGxBSlIjrIZRrtkJDnYwMtWdmjAYcnMTXYWaRiL"), false, 649503281);
    this->ucZCZL(string("TwiMN"), 667003945);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MEmGi
{
public:
    bool OKakwSZw;
    string aIzYkFUO;
    int WOijnOmsScX;
    int AtjkzkOhCOVFgRtV;
    string PGBGVxjoSAwk;

    MEmGi();
    bool xUhahRTbWsbGKWZ(int KgNJhGYBlDMilCp);
    int pvTAggESY(int EKNEgmsWZGeu, double aEDywI, double qeodufhuCzePo);
    double dcjSxFeaSCUVS(double wATNxhQYCFjXctgR, string ZetrsEwdM, string QEmfZRar, double GWaULGNRar);
    bool mDgiAbHSEypvE(bool iTNRDAdWdHI, int FVQdEjkNGWvvtxLr);
    string DEqFUxbsaeV(double eWeLTee, bool lrzJZbeC, double IlFFlOitz, bool QSsHGVMqduBwFaA, string rrVGIToMn);
    int oPYeYwOYVjqrXoqv(string VqDxVlJanKsxE);
protected:
    string rOIxzACkv;
    int JKPRwKNQy;

    bool wFNBgDlgyZg(int FFvIZi, string BsBnneLutMuXS, bool ZsayJle);
    bool bHUlLUOsWWIWsH(string GSvJrjFhTwBHj, double DZycpNd);
    void kJyBT();
    string aUFJh(double zAvhwoqUFuyFi);
    void uFKoyljzmnvX();
    string EATGxUa(int yceOinLljMzSy, string vFRneoOpoTygkE, double QeerVB);
    double VBfmhtxYQHUhO(int VuTEW, int nqxDmTWQpTwU, double rVJsV);
    double uEFlnSYMSR();
private:
    double cmmtTKtYA;

    bool cJAahIndMpIJZ(int CqxxBisTb, int qMDTiaWcAZREAdkS);
    void EbhqLSbkqdzgnoz(string unEwrTpSdHGoB, int rlMuKMrQc, int roJuywPTkGoQPMP);
    int DAtfcmaZu(double czILjI, double ZmQANzFTaGYgSPi, int TwGkBhoEpGWG, string aDAqSTIoPCtHSRM, int yDBgtjKSjldRLCyQ);
    void yApvRNyZYAAWV(int yeJOqrAWO, string BkWRp);
    double DccRc(bool VTSVZYqnyHN, double JtXGFmmsAxeHvr, bool kTSXHSuyaDLF, bool trUGkEFLf, string bPpSmLyEvcloUrhn);
};

bool MEmGi::xUhahRTbWsbGKWZ(int KgNJhGYBlDMilCp)
{
    int jepNAxQYMOdVP = 142624671;
    bool dJzavCQOniE = false;
    bool BTMok = false;
    int FFBPZVIXoakPpS = -1552033989;
    bool sueITcSyfzjoiX = true;
    bool KtppYbDFbf = false;
    string bBKvNn = string("GsITECtdofMIVbZWlkOMEvAvKaWJYtpArkgyPTTkufeCVnDjCFPQzSYchtgiQNOLuUtPfWhFvkWlVVUoaWdrxqPrPpGvNABaALGnu");
    string LciRHuKxQxkYSp = string("IgCAauAAcNHTsnLuGLjEBMFkNeFXWLXVfsYWaOrKtPTWOwbKkcddNaPhxTAyVFfoywUsmYsVYUsqAXUuSqrSynMPBQNjmEiTQJuZdLwoeTeRbLjUMwAKtIfBJaLsCLcbNbJpDiAVcfgrheMsDjgddJvJbCouoOzUnZYegkLfmvlNkWTpUNmukZ");
    double ZaCWrHvjP = 555122.9660026324;

    for (int kPAbFJpuDUv = 1822599057; kPAbFJpuDUv > 0; kPAbFJpuDUv--) {
        bBKvNn += bBKvNn;
    }

    for (int VDKIIfI = 268864388; VDKIIfI > 0; VDKIIfI--) {
        sueITcSyfzjoiX = ! sueITcSyfzjoiX;
    }

    if (KgNJhGYBlDMilCp == -844210646) {
        for (int uDugMRItHmlWGx = 463152882; uDugMRItHmlWGx > 0; uDugMRItHmlWGx--) {
            dJzavCQOniE = ! BTMok;
            KtppYbDFbf = ! dJzavCQOniE;
            BTMok = dJzavCQOniE;
        }
    }

    return KtppYbDFbf;
}

int MEmGi::pvTAggESY(int EKNEgmsWZGeu, double aEDywI, double qeodufhuCzePo)
{
    string vqznzi = string("gnWDBSZzptxBQAogfHYzhHmekwyUSOdchQjzdFVEyYcEPaNZMCqlnaCWlZELUFpnuWQbUQSOWmVVifZpkQKukhHpuTouKkXHRBVTmoCSGwybWNpdfPwuiUglQGpBsEwUcpQLnvnqEzpNkqLWcNNMrtsAHdyNebrdfPGXkhqbdgqWEQVkyORotiStlXrNZjes");
    string xERqblF = string("WVNWOuRlWJNVWMpmUYmXHaeVtPUAjiTDEzjEpzbkJjdKvTSXSGPwLoCEGpiTOjjAqFpRSKfdjczYnwXLvLOiZUMpKlCSCfOiqZAKTBcMZTjQvkpufYkrnFfVqcNNCIwHr");
    double PRoxqT = 857279.9281883889;
    double AExhvVXwdwvYGd = -837202.8375293671;
    double kxZEjVNnB = 97712.9052399103;
    string oePYeBcycduRnvd = string("zQsMaiLHgqQWHPTJbtEIgHljMyNMtFjyTkFXjnxSnHunTyaAYtVaHWnoMWvABMUyXIDtbRTgDkxKREBqtTZXjTrpcXPaiiiHUXyhvedonLEnTpWzJjSiaDknkvXGNkIMFlOdMGAcrKcUFBvAnGxQmiKnNCkvzqYYBieyMORPGPLLFzUfgmzXHdVEyibCtUMfYugiLPBxsMN");
    bool RBjjopIagjOA = true;
    int STrYLkZmrY = 48102854;

    for (int hWyQzLhrWPvFSlre = 150657681; hWyQzLhrWPvFSlre > 0; hWyQzLhrWPvFSlre--) {
        aEDywI = kxZEjVNnB;
        RBjjopIagjOA = ! RBjjopIagjOA;
    }

    if (qeodufhuCzePo >= 857279.9281883889) {
        for (int VsymfFluFkp = 1053162694; VsymfFluFkp > 0; VsymfFluFkp--) {
            AExhvVXwdwvYGd = PRoxqT;
            kxZEjVNnB -= kxZEjVNnB;
            qeodufhuCzePo = kxZEjVNnB;
        }
    }

    for (int geTmgRT = 638329768; geTmgRT > 0; geTmgRT--) {
        qeodufhuCzePo += aEDywI;
        EKNEgmsWZGeu *= EKNEgmsWZGeu;
    }

    if (xERqblF <= string("WVNWOuRlWJNVWMpmUYmXHaeVtPUAjiTDEzjEpzbkJjdKvTSXSGPwLoCEGpiTOjjAqFpRSKfdjczYnwXLvLOiZUMpKlCSCfOiqZAKTBcMZTjQvkpufYkrnFfVqcNNCIwHr")) {
        for (int DjnjQYFEyKuGFVgB = 1924620815; DjnjQYFEyKuGFVgB > 0; DjnjQYFEyKuGFVgB--) {
            continue;
        }
    }

    for (int jhPtNdrGT = 1099278099; jhPtNdrGT > 0; jhPtNdrGT--) {
        aEDywI = AExhvVXwdwvYGd;
    }

    return STrYLkZmrY;
}

double MEmGi::dcjSxFeaSCUVS(double wATNxhQYCFjXctgR, string ZetrsEwdM, string QEmfZRar, double GWaULGNRar)
{
    int klzPHc = 883746339;
    double yBhBheJdxqztbR = 685993.2765643689;
    bool UaNmNzmd = false;

    for (int HIAkNwvgxdBY = 2051353510; HIAkNwvgxdBY > 0; HIAkNwvgxdBY--) {
        yBhBheJdxqztbR /= yBhBheJdxqztbR;
    }

    return yBhBheJdxqztbR;
}

bool MEmGi::mDgiAbHSEypvE(bool iTNRDAdWdHI, int FVQdEjkNGWvvtxLr)
{
    int eYlYZrpDTTA = -1809136461;
    string VkiwsZ = string("ApnbirPkLkZYhhyGWXRQrnWWXttQEZjzatFUkLNboCScjFjYzmgUNphLzpZ");
    bool uOovixnpBsR = false;
    int SBbnCgXd = -466516328;
    string sonieIGczMxP = string("yYQbDmblCjLbiyVffJjgEo");
    bool onprVPFTkS = false;
    string fjfKyAgnzVkkR = string("AQRhuZiNpNnpQNUdwzjGyjOUrPwuhgBUWSQODEebiVYxiPTzDLhMBqlyBeUOfKMKdFNeRxPaAYaPgqhTbKvwjKzjLHMWgqSrxvIEaDFZnUSuhUarXnFihLduONmHfdUSIiKfbLlJQMpOniumjwIZXqzfQUHJMYAkN");

    return onprVPFTkS;
}

string MEmGi::DEqFUxbsaeV(double eWeLTee, bool lrzJZbeC, double IlFFlOitz, bool QSsHGVMqduBwFaA, string rrVGIToMn)
{
    int tFCyJ = 1027221523;
    int vNNYCUSTn = -472902571;

    if (lrzJZbeC != true) {
        for (int AekdLNfyqbY = 1617464502; AekdLNfyqbY > 0; AekdLNfyqbY--) {
            QSsHGVMqduBwFaA = ! QSsHGVMqduBwFaA;
        }
    }

    if (vNNYCUSTn == 1027221523) {
        for (int DKzgCaVyJ = 1346703581; DKzgCaVyJ > 0; DKzgCaVyJ--) {
            tFCyJ += tFCyJ;
            QSsHGVMqduBwFaA = ! QSsHGVMqduBwFaA;
            rrVGIToMn = rrVGIToMn;
        }
    }

    for (int AhOxzjtg = 1149016818; AhOxzjtg > 0; AhOxzjtg--) {
        eWeLTee -= eWeLTee;
        tFCyJ -= tFCyJ;
        eWeLTee += IlFFlOitz;
    }

    for (int qgAajpMenaXoX = 333971561; qgAajpMenaXoX > 0; qgAajpMenaXoX--) {
        eWeLTee *= IlFFlOitz;
        vNNYCUSTn /= vNNYCUSTn;
    }

    return rrVGIToMn;
}

int MEmGi::oPYeYwOYVjqrXoqv(string VqDxVlJanKsxE)
{
    bool GEgsJsWouQfzdQzP = true;
    string BcAPIaMCFndj = string("kCvReCJuEzY");
    string YwpSSUIyRbKSTZ = string("HjPrVfamhgmpWjDUYfuYMsIAIKqbykPxpEsBLjomGpxkYUAXAJkHdEnCQwoJUsbAECmkyxCupiHRpw");
    int iGUBXXwmNQ = 1879877871;
    string TzybJVWDbZIPfQwu = string("fXhgkmlqlfHxnMZRjcYEJPdGjlGKxqpCETYrbBowfTVrnLqgabGjxjlEwQzMpsorYKgcSaSzWUwmUSqHYzQNULBoeGusIjPwQkRFAiVzQebSdIMbqpbguysGkrckOZCsY");
    string bjJBu = string("EbTSkpYTsnmieYiRMUWNcLAQISPOWKiUHmZcnxIqRhuHRysFHgVtDlYSySeJskVpJuHqRmpoOlkftJuuybiNzITBxFhRVFkoMrQXZTHXYivaITBCNIJDbHEwrATLAWnUHPETfNEAZwyNBWZYEiUDxCViHJLraWyhLGWnxyAgQvcconxHnwIGSmivMWTYFJQODyagGoKMAcVhHLcMxpzNtHElTGPHciUk");
    bool KUzYpdu = false;
    int JgPuthLN = 481910516;
    bool FWozDL = false;
    string vZrYNWCmPCl = string("mMHBVHFVRJiJKYLHIjilEEQlVIawXpbAAOMrHuJKIkbJKrkojiiivxvOECXnruaKrTHqRcDxdGnVrCkAGydAmGSxwtsQpujrzjNzAkMXpYKcKZDUqVjwLqTJovlCNYENAyJWtXuBrmApeiSLTJQFmShfsFkhJ");

    for (int arwzMshCuMt = 369273449; arwzMshCuMt > 0; arwzMshCuMt--) {
        YwpSSUIyRbKSTZ = VqDxVlJanKsxE;
    }

    if (GEgsJsWouQfzdQzP == false) {
        for (int KqUiQyWWMdMj = 1862040612; KqUiQyWWMdMj > 0; KqUiQyWWMdMj--) {
            BcAPIaMCFndj = BcAPIaMCFndj;
            YwpSSUIyRbKSTZ += YwpSSUIyRbKSTZ;
        }
    }

    for (int VGCctInXpPHzVzfi = 1767001365; VGCctInXpPHzVzfi > 0; VGCctInXpPHzVzfi--) {
        continue;
    }

    return JgPuthLN;
}

bool MEmGi::wFNBgDlgyZg(int FFvIZi, string BsBnneLutMuXS, bool ZsayJle)
{
    int ittzIGb = -2013217369;
    bool ihNPSOZyVFvmsu = false;
    double tjWbDDRxWeUNo = 615912.494216775;
    double zIZYJDRKJ = 252414.8240738591;
    double AIFrWZ = 369047.0067763837;
    bool hbVMjfNnq = true;
    double RkOGhesv = 352018.3686055911;

    for (int zJEiMDUsdueMneq = 1153794377; zJEiMDUsdueMneq > 0; zJEiMDUsdueMneq--) {
        continue;
    }

    for (int VYvczjUxoOffqn = 942823220; VYvczjUxoOffqn > 0; VYvczjUxoOffqn--) {
        continue;
    }

    for (int zvTRAk = 403648355; zvTRAk > 0; zvTRAk--) {
        ihNPSOZyVFvmsu = ZsayJle;
        FFvIZi /= ittzIGb;
        ZsayJle = hbVMjfNnq;
    }

    for (int BAeBdAUVnb = 890520051; BAeBdAUVnb > 0; BAeBdAUVnb--) {
        continue;
    }

    return hbVMjfNnq;
}

bool MEmGi::bHUlLUOsWWIWsH(string GSvJrjFhTwBHj, double DZycpNd)
{
    double KJwWdF = -391700.1453715444;
    double XeidVG = -263286.6847292305;
    bool JWRAQSvBj = false;
    double PsXMI = 406820.0055873717;
    double JqxvGfiUJPUapHff = 65406.67892894815;
    double zCeeWgJjqAd = -511136.3786732927;
    string EbphkFqaCWAdLgU = string("MHAbAkCKulKFYnQgTvlJWxAGdyZWAFyxkPhVpycXoVcIjxAtHsaWNIQoGULsbQtuZpzCRmFmOhJhzIcuVlRtloMNczNGEEYQgHfvQqTmHhAjuohNcdvYUxjanIwBWlcAAKpbuUsUxkwIGugXLNRBkMpxAaIHYDjrFJnMmbPSwNZqSLrvQtdrzk");
    double qptqxHmvl = 96326.73608951774;

    for (int acvkTolNXxAF = 1401124464; acvkTolNXxAF > 0; acvkTolNXxAF--) {
        JqxvGfiUJPUapHff *= XeidVG;
        KJwWdF += PsXMI;
        qptqxHmvl += PsXMI;
        KJwWdF -= qptqxHmvl;
    }

    for (int sADtxm = 149494784; sADtxm > 0; sADtxm--) {
        zCeeWgJjqAd -= zCeeWgJjqAd;
        qptqxHmvl *= KJwWdF;
    }

    if (XeidVG > 96326.73608951774) {
        for (int mbvStOuFiO = 420059608; mbvStOuFiO > 0; mbvStOuFiO--) {
            zCeeWgJjqAd *= XeidVG;
        }
    }

    return JWRAQSvBj;
}

void MEmGi::kJyBT()
{
    bool avCRMDwKtvUocCd = true;
    double uFyXpEUwSRloV = 794887.559050488;
    int ZapQdonQLaTaEx = 31930339;

    if (ZapQdonQLaTaEx != 31930339) {
        for (int FiqyqlAbLwvhumZ = 1489186478; FiqyqlAbLwvhumZ > 0; FiqyqlAbLwvhumZ--) {
            avCRMDwKtvUocCd = avCRMDwKtvUocCd;
            uFyXpEUwSRloV += uFyXpEUwSRloV;
            avCRMDwKtvUocCd = avCRMDwKtvUocCd;
            ZapQdonQLaTaEx -= ZapQdonQLaTaEx;
            avCRMDwKtvUocCd = ! avCRMDwKtvUocCd;
        }
    }

    if (ZapQdonQLaTaEx > 31930339) {
        for (int OBEjVRBHVgnGJv = 303772018; OBEjVRBHVgnGJv > 0; OBEjVRBHVgnGJv--) {
            avCRMDwKtvUocCd = ! avCRMDwKtvUocCd;
            uFyXpEUwSRloV /= uFyXpEUwSRloV;
            avCRMDwKtvUocCd = avCRMDwKtvUocCd;
        }
    }
}

string MEmGi::aUFJh(double zAvhwoqUFuyFi)
{
    string wAzhISCGfBmIzW = string("vmAaLVUuxQPSpkUKfgBytaPdHhSJEpKAFUSuTxTSBwOiChNGYzLKXCizqDAZvHZaFZfGfvulzhFsxwTpKWPXBQhvzZBeENOwaLgqvkDXBWpkLzglJgfXNXAwpUbGLfIaTBOjgDJVhSUximNjvVCbPGVyEScbrawCgQFVyDfcLHPOukDAoaghzrvSXSEzeQoid");
    double SDHxEGzGkAOpkrPo = -295113.1853866278;
    int HwCZCgtuP = -441575645;
    string EcQLtiZGxjwuc = string("rLymgBIPoPQtVxiIlehbLjkHiXKfIVdIo");
    int DYzZVLSBSQEo = -755128281;
    int ONGrMWYPvT = 347381152;
    int gLcoSU = 1145773199;
    string Qkier = string("bdeUnHdtHRpNirYvhvkRvEZIijtZJvAGRnMeKeRyUEZCqPEaNVTfvebnPoPtLdYqCZYXWQwBDrIxUJfMwOWUcXKPTkZqKxXYuHyyeywPAPmYhBhUGvufkDUDmxGeirJwKRNIdRujWrDNAGyIYvWiseTGFxFgRTCBQDkUmKllkdQEzFSmdYlmwvtgAeTTYrksHhStveoiVHDqSvDGdKtH");
    bool RURcC = true;
    bool jcAUfGAtd = false;

    for (int eLIFQBoI = 18135762; eLIFQBoI > 0; eLIFQBoI--) {
        ONGrMWYPvT /= ONGrMWYPvT;
        HwCZCgtuP *= HwCZCgtuP;
        RURcC = RURcC;
        gLcoSU -= DYzZVLSBSQEo;
    }

    for (int TEWoLVQbTuSIkW = 1419440534; TEWoLVQbTuSIkW > 0; TEWoLVQbTuSIkW--) {
        wAzhISCGfBmIzW = wAzhISCGfBmIzW;
        EcQLtiZGxjwuc = Qkier;
        HwCZCgtuP /= gLcoSU;
        Qkier += wAzhISCGfBmIzW;
    }

    return Qkier;
}

void MEmGi::uFKoyljzmnvX()
{
    string zRtKHf = string("tWT");
    int RwEratupte = 1590194448;
    string sQGkcdEFTjUgXpl = string("mpmNEYLCretDYZXTrEvRKjJlRRKswjPRhwZMZQegEwYEfQPTpymUGXozHKYVrmuMxJadsjBpYwwVSusrrUfvyAdLOaNLdYRJVuqiuWjT");
    int LewHINZvyira = 1947681592;

    for (int yGLhwikVPHbh = 1166636938; yGLhwikVPHbh > 0; yGLhwikVPHbh--) {
        zRtKHf += sQGkcdEFTjUgXpl;
        LewHINZvyira /= RwEratupte;
        LewHINZvyira *= LewHINZvyira;
        LewHINZvyira = RwEratupte;
        RwEratupte -= RwEratupte;
        sQGkcdEFTjUgXpl = sQGkcdEFTjUgXpl;
    }

    for (int IKcfDRgaRFBgzu = 1226247697; IKcfDRgaRFBgzu > 0; IKcfDRgaRFBgzu--) {
        sQGkcdEFTjUgXpl += zRtKHf;
        LewHINZvyira *= RwEratupte;
    }

    if (sQGkcdEFTjUgXpl <= string("tWT")) {
        for (int iIIbcjwb = 199357366; iIIbcjwb > 0; iIIbcjwb--) {
            zRtKHf = zRtKHf;
            LewHINZvyira /= RwEratupte;
        }
    }

    for (int NGdtBpMRSi = 277166418; NGdtBpMRSi > 0; NGdtBpMRSi--) {
        continue;
    }
}

string MEmGi::EATGxUa(int yceOinLljMzSy, string vFRneoOpoTygkE, double QeerVB)
{
    bool rhfFpKYRbnUnH = false;
    bool SSfnqfkFp = false;
    bool OhtEjAX = false;
    int mBvebKYa = -299948116;
    string AfSByTxOmQ = string("GCoARZvCjWCfGKVMhEAwwqxSkoLFFmCWZOIkLKaSiMcKMicFjQKRyDSACnowSoWcWAkMLjJubtLqPbcVFKrpPpbLAnTiokSuNjbLtSQQtVLRQCjDxPIiGSqFiZYRYDzzQhOvtCOfdzwmHUxAdZTTxsFAUYmAvXEwp");
    double crXVkrDSV = -1004308.425072924;

    for (int tpwNlZfmkIYvheF = 691780924; tpwNlZfmkIYvheF > 0; tpwNlZfmkIYvheF--) {
        yceOinLljMzSy += yceOinLljMzSy;
        rhfFpKYRbnUnH = ! OhtEjAX;
        crXVkrDSV = crXVkrDSV;
    }

    for (int UppMQpuwhqcXe = 644705719; UppMQpuwhqcXe > 0; UppMQpuwhqcXe--) {
        OhtEjAX = rhfFpKYRbnUnH;
        QeerVB *= crXVkrDSV;
    }

    for (int cHZeUXN = 1066038846; cHZeUXN > 0; cHZeUXN--) {
        yceOinLljMzSy /= mBvebKYa;
        QeerVB = QeerVB;
        rhfFpKYRbnUnH = ! SSfnqfkFp;
    }

    if (yceOinLljMzSy != 432643592) {
        for (int RfuzIYBvsFVJ = 718478697; RfuzIYBvsFVJ > 0; RfuzIYBvsFVJ--) {
            AfSByTxOmQ += AfSByTxOmQ;
        }
    }

    for (int DbqdOsWWHPAi = 736551671; DbqdOsWWHPAi > 0; DbqdOsWWHPAi--) {
        SSfnqfkFp = ! rhfFpKYRbnUnH;
        AfSByTxOmQ += vFRneoOpoTygkE;
    }

    return AfSByTxOmQ;
}

double MEmGi::VBfmhtxYQHUhO(int VuTEW, int nqxDmTWQpTwU, double rVJsV)
{
    double IXnFe = 976798.9390058747;
    string kIniNutVSTk = string("THdsrHrEnIGOCZpgdOYPOPeMKomCXaPdZnacZjKadHVXvXFWDgpVLlLeXfxbZQbFoIEfRYBdEnbYWAMqVkGawvNQaScPMjLsYXQARNOeGLigEMIOTBXykbbIsFZLkPlwQewTqSHORzUuUJorWRqYPeKInxgKlGbMTMfLOxpCQKbaFJWrgzzYirzjBj");
    bool VYggnyOtIhvQvovL = true;
    int AzJES = 897331632;
    string nIWvS = string("JIUv");
    int hLJenVBTza = -1471168868;
    string XnyRVwjE = string("vdXjRKthIZmePZsTIWwUrUuyAph");
    int nISCrcYsBAguck = -522896123;
    bool SCTVUXiNLdOhqcOS = true;
    bool MZcBR = true;

    if (VuTEW == -486207834) {
        for (int FylOWtPrwL = 788915842; FylOWtPrwL > 0; FylOWtPrwL--) {
            VYggnyOtIhvQvovL = VYggnyOtIhvQvovL;
            AzJES += nISCrcYsBAguck;
        }
    }

    for (int sGrRUcTRGFDICu = 2006232319; sGrRUcTRGFDICu > 0; sGrRUcTRGFDICu--) {
        kIniNutVSTk += kIniNutVSTk;
    }

    for (int TFpNCWx = 1621615832; TFpNCWx > 0; TFpNCWx--) {
        continue;
    }

    for (int NfoqJL = 322368210; NfoqJL > 0; NfoqJL--) {
        continue;
    }

    return IXnFe;
}

double MEmGi::uEFlnSYMSR()
{
    string dqvJjq = string("hdHXIMkKLnJHeQcdwJusqIZYEcidsTSoFuITqSdrpTQqSySntWjlGNdXrQTGOHQvGjVoTnEPeoSDQdGDpIIZvAuUIiohvMRHbKSVXAguInNOhOPtpAqdwFUQYyIlnRFVTrPksdRhTtRcoKQRaHAImLYWEJqyuXaeJdomPVKILawwXXCRhFMGOljCkCPjGlGgzoHcWurEMohxnKnq");
    int YfyfDPZO = -1937937516;
    double faSpNL = -487468.361717347;

    return faSpNL;
}

bool MEmGi::cJAahIndMpIJZ(int CqxxBisTb, int qMDTiaWcAZREAdkS)
{
    bool wTsczjRYSLM = true;
    bool zptsKlWJITfxMlg = false;
    int bYlAIcA = -2090569394;
    double mfgIZobrcqstN = -355959.0827827195;
    bool prxOVH = true;
    int SlXWQeDTaQAe = -2095536378;
    int MqbengjWbjA = 339625524;
    bool vQtzSjJb = true;

    if (MqbengjWbjA > -2090569394) {
        for (int KAoxlABjMtbJ = 2089330848; KAoxlABjMtbJ > 0; KAoxlABjMtbJ--) {
            vQtzSjJb = ! prxOVH;
        }
    }

    if (qMDTiaWcAZREAdkS <= 339625524) {
        for (int ARDTadhxvRdjk = 793839674; ARDTadhxvRdjk > 0; ARDTadhxvRdjk--) {
            continue;
        }
    }

    for (int bcDvuW = 165937920; bcDvuW > 0; bcDvuW--) {
        qMDTiaWcAZREAdkS /= CqxxBisTb;
    }

    if (SlXWQeDTaQAe <= -1917164925) {
        for (int ERPHAJXvsIXXP = 998872915; ERPHAJXvsIXXP > 0; ERPHAJXvsIXXP--) {
            zptsKlWJITfxMlg = ! prxOVH;
        }
    }

    for (int FmqDqJIdcgnVWQJO = 306021911; FmqDqJIdcgnVWQJO > 0; FmqDqJIdcgnVWQJO--) {
        zptsKlWJITfxMlg = ! zptsKlWJITfxMlg;
        prxOVH = wTsczjRYSLM;
    }

    return vQtzSjJb;
}

void MEmGi::EbhqLSbkqdzgnoz(string unEwrTpSdHGoB, int rlMuKMrQc, int roJuywPTkGoQPMP)
{
    string yKHnJbgHveFEEa = string("AbQxwgTuEQGkLDDxnaptrNACtFhk");
    int AdBVWRSSOoisyd = 996874654;

    if (unEwrTpSdHGoB >= string("aTyrIppmkYIDbECeERnjjrhUtyjfsRoxQraAPFpBfArCxCCpwBLqIDLnnFzVucgZtXHBfzCtEQgCXXRWtaAyAScvGGCWZdWroBbrNkNkNkcABzhljkyxRxcZeWeUiFwCnzxrlwNbVAWeVGScJniliLwDOmTEUlqZVdJSKLBSjkgbYOReFNOrhdJiqChlWgUmsaertPtaQZimVBZBLtbfoJPpIDMrY")) {
        for (int rfONWRqRGHvzW = 2041270540; rfONWRqRGHvzW > 0; rfONWRqRGHvzW--) {
            yKHnJbgHveFEEa += yKHnJbgHveFEEa;
        }
    }

    if (roJuywPTkGoQPMP > 949146563) {
        for (int nNKyp = 806728386; nNKyp > 0; nNKyp--) {
            continue;
        }
    }
}

int MEmGi::DAtfcmaZu(double czILjI, double ZmQANzFTaGYgSPi, int TwGkBhoEpGWG, string aDAqSTIoPCtHSRM, int yDBgtjKSjldRLCyQ)
{
    bool dGlIiTgCM = false;
    int UxAlhnSZqCqhe = 697570334;
    double HbSCR = 258629.47342361;
    string QEbrYTaOfBVk = string("zIEvRGeJzOVrdCPsjpxttmnuuqSSefZgJMkSkEhzmzxpektxnFMHOWXpWpEXCieIhpSKnqQTGOZDqAQwytQnAIhEHZdzNwLfRcgXZZBxtgAmSTXGNJEIuwejzkZFQGFAvMySApkXzOuawZbvywAuOyhkQLIPWLfsyNZCTCsqrKrIzTPmdJPwQab");
    bool phOtwU = true;

    if (yDBgtjKSjldRLCyQ == -1160802082) {
        for (int KnRyqeAaZhQLNJuo = 863140772; KnRyqeAaZhQLNJuo > 0; KnRyqeAaZhQLNJuo--) {
            continue;
        }
    }

    for (int nQMvzBmrmNNyk = 1362382467; nQMvzBmrmNNyk > 0; nQMvzBmrmNNyk--) {
        HbSCR -= ZmQANzFTaGYgSPi;
    }

    for (int iDnaJKuqrdgWfA = 1891848005; iDnaJKuqrdgWfA > 0; iDnaJKuqrdgWfA--) {
        continue;
    }

    if (aDAqSTIoPCtHSRM <= string("BnLAVhCwgKVlhwhTgwewfPuRXDFhCoalQhowFBXpvaVcvfWcRdgXhVNGeBcQeZhGhdLGoXRKDnQzGTupDPvOxgpUJXPHOKKPQtzzcnCAaaEJNILoGwYrLQthGMVBWkgSjBHuTDiTTLVQfWSMrzoEVFcvKbWXRLZlgizCvFy")) {
        for (int BnNTvC = 1915573654; BnNTvC > 0; BnNTvC--) {
            QEbrYTaOfBVk += QEbrYTaOfBVk;
        }
    }

    if (HbSCR != 412928.1263081576) {
        for (int XUZCzXqURFz = 584771887; XUZCzXqURFz > 0; XUZCzXqURFz--) {
            aDAqSTIoPCtHSRM += aDAqSTIoPCtHSRM;
        }
    }

    return UxAlhnSZqCqhe;
}

void MEmGi::yApvRNyZYAAWV(int yeJOqrAWO, string BkWRp)
{
    string CKxtHQRPEAVutEB = string("MpMWIhWfKvTajkZJhDdqFqzsVizQSpSJwmJYubFGhloBjQsUhHoFJjNLuDaLvctkfoUkjfbcpBHtwzPmqgzXvOhvoaONfQRwoKDdTvpnIJcZMxpNFWQvCtyIqXjcRoyCFlEbnIsPFvjrlpHWOOGHfhwEwEWbcIXcXvofkXOuyFUmOhPiCutaeQBfViPkjyVeXGDBxrNqhlCEcLdDd");
    string RNzVTocVzmFWkVUh = string("SPIBIzNugxJTslgaWZVZgezdnXRHayCOGpixoDxWNLDUmXsqcNfBRlmlFmXOAyrUYjOjRoZzYoHyyLLscxZxAmMeTJgLkMklJCHviJUIwqKpvSBKZuBXZoUkJdnasKICISyOZqQOsqenKuPDoigDXOTNJPKWWSuetgxsraVrJSGfSWaaIqZNRq");
    double QtvNmuW = -247710.63349846125;
    bool PxGJlIQlmEXqh = false;
    double VtKFHpGQ = 245425.5358096872;
    double JgDIQ = 378622.27195005893;
    double neeAP = -95066.01981792525;

    if (VtKFHpGQ > 245425.5358096872) {
        for (int NIokVHOvFxj = 1123995254; NIokVHOvFxj > 0; NIokVHOvFxj--) {
            neeAP = QtvNmuW;
            CKxtHQRPEAVutEB = CKxtHQRPEAVutEB;
            neeAP += neeAP;
        }
    }
}

double MEmGi::DccRc(bool VTSVZYqnyHN, double JtXGFmmsAxeHvr, bool kTSXHSuyaDLF, bool trUGkEFLf, string bPpSmLyEvcloUrhn)
{
    double KmqqGG = -46991.03090850332;
    bool XjxQwpITPNa = true;
    bool SXzAmULQ = false;
    bool CNLfvWHzXAk = false;
    bool qMJddEhrqdLckw = true;

    for (int mJNtp = 1292071284; mJNtp > 0; mJNtp--) {
        CNLfvWHzXAk = trUGkEFLf;
        XjxQwpITPNa = VTSVZYqnyHN;
        qMJddEhrqdLckw = SXzAmULQ;
        kTSXHSuyaDLF = qMJddEhrqdLckw;
    }

    if (CNLfvWHzXAk == false) {
        for (int JIiwtcSLc = 1564584774; JIiwtcSLc > 0; JIiwtcSLc--) {
            CNLfvWHzXAk = ! XjxQwpITPNa;
        }
    }

    if (XjxQwpITPNa != false) {
        for (int OdPSXUoKRZKAYVvU = 251811500; OdPSXUoKRZKAYVvU > 0; OdPSXUoKRZKAYVvU--) {
            SXzAmULQ = ! XjxQwpITPNa;
            trUGkEFLf = trUGkEFLf;
            qMJddEhrqdLckw = XjxQwpITPNa;
            qMJddEhrqdLckw = VTSVZYqnyHN;
        }
    }

    for (int SreImKiSlCvY = 2095257416; SreImKiSlCvY > 0; SreImKiSlCvY--) {
        trUGkEFLf = ! trUGkEFLf;
        VTSVZYqnyHN = qMJddEhrqdLckw;
    }

    return KmqqGG;
}

MEmGi::MEmGi()
{
    this->xUhahRTbWsbGKWZ(-844210646);
    this->pvTAggESY(-2010073641, -252852.95711759976, -969609.8341397105);
    this->dcjSxFeaSCUVS(388286.95550042344, string("TPCSGkCFEXaZNLegNDvHamLJpfRThqYCQBuztbGGrrvGMYPTZuCJbhDGweuFyyflnKAIzsdpyPILQSBmwjSEdPAajGTzWiKHtGboBIeSJfSseUNEovywtDPZlaVtGWdIO"), string("LOTLNiTBKaXnbqBmCbpSwKvksPFcczRVuMqOWwQiLyJsIYGnxQLURZuqLchlpbfQGnjLSZwmfwRvnmWbwhtOwJQbUScwySKeMhQZsZHElXQUlyTEhfagEaAXyaBThtTaDujFhsEUwfLJilqvAirgSpPHanMiWyFcVsIrDQhNQOwqSGvJmrBuRKlETZZQVqxiqYQDufuAlanx"), 96601.92240792034);
    this->mDgiAbHSEypvE(true, 1209665837);
    this->DEqFUxbsaeV(-834397.2473379143, true, -577829.506188674, true, string("LjFxxBknfGfCbfiZlqiGjxllrNQqqBCGhKJHeGxewOBVimzGkvHMOcTuxxkJCykjLDStgRVWxsJRZrRmcvSqyaNoHtajsWEHuYLCdjYAnvvjgSNlwyfiaXiLjPWXrtnbvUgxouIkpyQVdoiuCbiaiFEXMsGeLfdwFqhBeQotWyeEPFq"));
    this->oPYeYwOYVjqrXoqv(string("QgCqhYCuUOjFyBH"));
    this->wFNBgDlgyZg(210873772, string("JRWQJMTPIapRYMcwXvdEhdaZgtPWhgjVNNOAzECXapuufisPGsmXYuTArbpoYEVPfDKyparFlMbjcpjrMeqadkyTLTkjcPt"), true);
    this->bHUlLUOsWWIWsH(string("LixFLzGlruwuVcoDQBSwctzJBdqlIJRDkruMBVOPWeoYdFjvzvyTtsesRdAxcNyPRSsHakXlPtfhrTREJJdFiUyiXcqKtMMEwemyNRpsmklIU"), 264833.59111232444);
    this->kJyBT();
    this->aUFJh(57311.47588199968);
    this->uFKoyljzmnvX();
    this->EATGxUa(432643592, string("XvlXCrWjwVpVhlQIszMzMwOSxZCuCldLtqcsbxaTXuHlApzDpGoDCMuhULCwynrTDQErjFYdJBnBZtEqMpUqNtvSmwJSYSjOWeaHRALuzvjypqwvdAlZPeUNBnAcEKmGOxiBZiTczqNWxRrcBpHZRZaNeuvEGmLxKYRZJTLqxQibzjbZAiOxfYow"), -947037.284922123);
    this->VBfmhtxYQHUhO(-486207834, -2060922354, 710422.4172604925);
    this->uEFlnSYMSR();
    this->cJAahIndMpIJZ(-1599050325, -1917164925);
    this->EbhqLSbkqdzgnoz(string("aTyrIppmkYIDbECeERnjjrhUtyjfsRoxQraAPFpBfArCxCCpwBLqIDLnnFzVucgZtXHBfzCtEQgCXXRWtaAyAScvGGCWZdWroBbrNkNkNkcABzhljkyxRxcZeWeUiFwCnzxrlwNbVAWeVGScJniliLwDOmTEUlqZVdJSKLBSjkgbYOReFNOrhdJiqChlWgUmsaertPtaQZimVBZBLtbfoJPpIDMrY"), 949146563, -573154297);
    this->DAtfcmaZu(412928.1263081576, -417416.08953828015, 24723274, string("BnLAVhCwgKVlhwhTgwewfPuRXDFhCoalQhowFBXpvaVcvfWcRdgXhVNGeBcQeZhGhdLGoXRKDnQzGTupDPvOxgpUJXPHOKKPQtzzcnCAaaEJNILoGwYrLQthGMVBWkgSjBHuTDiTTLVQfWSMrzoEVFcvKbWXRLZlgizCvFy"), -1160802082);
    this->yApvRNyZYAAWV(1130295672, string("yRjFtUXPYBCjNPtZbXa"));
    this->DccRc(true, -505506.0026817154, false, false, string("wcHJtSmYukVpdryiMKHpugnppeiIxJQI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZGmBsXEGpNf
{
public:
    int BzZRdLSOXjaNRJKF;

    ZGmBsXEGpNf();
    void RzMdNYoscuAHIez(int veXlDtIzWV, string DthjQV, string uYKiPvdeCmMnoCV);
    double OsxWgG();
    int lapBNWRsCy(double GszZJgnGlLR, int NXvyYTeeIfrOK);
    bool FLrugKlJ(bool yHWMZxpuMr, int fSvZayakj, string aGeIRiG, bool foFsgzzdARNyqu, int MaHxESFBCXhUBgSF);
    int DDpaO(bool woVjTwqkw, double FMKKAMqPHQREtPY, string CmFNmGs, int faGBY);
    string mAwMtEWrPs();
    string RoiwPdIlQHVOBqu();
    int VrqrpOtDhvV(int XlTcyYmch);
protected:
    int doqpHUOAd;

    string FHrkTmm();
    bool mhmxqxGahVar(int naJdMeFUafXxLUX, int miypfGEfl, string WtfvFjrlmQdaA, bool TEtwJXQ);
    bool NopODwGd(int laEWYurdeUkMr, double YYGlePDiBLqNZyz);
    double cjexzAAsgiNE(double PlzgcuDZiba);
    int UkeAuX();
private:
    bool ChIaClVYAXd;
    string ECIXpTSyHngKJMWu;
    bool JpxEI;
    double SxjEfF;
    double WHjcOKy;

    void ewyMhuCm(bool YhqpAjDhK, double NeHAfrpTIFyQIbdp, bool kksvSWecf);
};

void ZGmBsXEGpNf::RzMdNYoscuAHIez(int veXlDtIzWV, string DthjQV, string uYKiPvdeCmMnoCV)
{
    string MCPAmQikOPnir = string("ToZtOzzqUjiBrojwlZCjJzfaFbEXuELGgtgWpZGKcRChRgrKJFBieDfIjUNEQExXISFdoCDJnHuioxkweIFmYTYsgxuGSYqYNNDGVnNnvcbyVrMoHJtfZargzPOdIaTmRCLLzGFJLgmdgcMy");
    int lFbJpkCzNE = -1000247517;
    string XXRMRrun = string("gXrSyRtFsRpVRryrpHuE");
    int pJQhAHbupNIFBwa = 1248027129;

    if (veXlDtIzWV < 1551582665) {
        for (int uDlJCtNuycgu = 1487317920; uDlJCtNuycgu > 0; uDlJCtNuycgu--) {
            uYKiPvdeCmMnoCV = uYKiPvdeCmMnoCV;
        }
    }
}

double ZGmBsXEGpNf::OsxWgG()
{
    double LnWxqzRPxrUEz = 24667.735414106613;
    bool PlNmVDARg = true;
    double oBXBwONtpHPrWPD = -570913.0005278104;
    double FMgMyaDtq = -43387.374236238684;
    int pkgNsqDoRRz = 2075933803;

    for (int bpBABMqYZp = 217038439; bpBABMqYZp > 0; bpBABMqYZp--) {
        oBXBwONtpHPrWPD *= oBXBwONtpHPrWPD;
        LnWxqzRPxrUEz -= LnWxqzRPxrUEz;
    }

    if (oBXBwONtpHPrWPD >= -43387.374236238684) {
        for (int IFsWNJeLwnkoJp = 769531500; IFsWNJeLwnkoJp > 0; IFsWNJeLwnkoJp--) {
            pkgNsqDoRRz += pkgNsqDoRRz;
            FMgMyaDtq = LnWxqzRPxrUEz;
        }
    }

    for (int QRykIg = 1175089880; QRykIg > 0; QRykIg--) {
        pkgNsqDoRRz = pkgNsqDoRRz;
    }

    for (int cDcYYzBP = 743729963; cDcYYzBP > 0; cDcYYzBP--) {
        LnWxqzRPxrUEz -= FMgMyaDtq;
    }

    return FMgMyaDtq;
}

int ZGmBsXEGpNf::lapBNWRsCy(double GszZJgnGlLR, int NXvyYTeeIfrOK)
{
    string sOZpHlJoZ = string("qOCSinWqyeUSQWHyLChSfpwnLugDBioNc");
    int XOOxfSIajH = 300753009;
    int IvsCN = 448625963;
    int tpRrmcqchI = -1162018547;

    for (int ssIwGQOv = 1632616488; ssIwGQOv > 0; ssIwGQOv--) {
        XOOxfSIajH /= NXvyYTeeIfrOK;
        sOZpHlJoZ += sOZpHlJoZ;
        NXvyYTeeIfrOK += NXvyYTeeIfrOK;
        XOOxfSIajH = tpRrmcqchI;
    }

    for (int WPVEFv = 229942663; WPVEFv > 0; WPVEFv--) {
        tpRrmcqchI -= XOOxfSIajH;
        tpRrmcqchI /= XOOxfSIajH;
        NXvyYTeeIfrOK -= XOOxfSIajH;
    }

    for (int qoMwrzMiWaiPhF = 916283239; qoMwrzMiWaiPhF > 0; qoMwrzMiWaiPhF--) {
        GszZJgnGlLR /= GszZJgnGlLR;
        GszZJgnGlLR -= GszZJgnGlLR;
        tpRrmcqchI -= NXvyYTeeIfrOK;
    }

    return tpRrmcqchI;
}

bool ZGmBsXEGpNf::FLrugKlJ(bool yHWMZxpuMr, int fSvZayakj, string aGeIRiG, bool foFsgzzdARNyqu, int MaHxESFBCXhUBgSF)
{
    int SCuuB = -553096948;

    if (SCuuB < 380868189) {
        for (int ALJEm = 276556479; ALJEm > 0; ALJEm--) {
            SCuuB = fSvZayakj;
            fSvZayakj /= fSvZayakj;
        }
    }

    for (int BqKkpLqpEReW = 2073117471; BqKkpLqpEReW > 0; BqKkpLqpEReW--) {
        foFsgzzdARNyqu = foFsgzzdARNyqu;
        MaHxESFBCXhUBgSF *= fSvZayakj;
        fSvZayakj = MaHxESFBCXhUBgSF;
        SCuuB /= SCuuB;
    }

    return foFsgzzdARNyqu;
}

int ZGmBsXEGpNf::DDpaO(bool woVjTwqkw, double FMKKAMqPHQREtPY, string CmFNmGs, int faGBY)
{
    double DGMLNhoC = 1033451.4803177807;
    bool lkBjMf = false;

    for (int jXmmax = 1764377554; jXmmax > 0; jXmmax--) {
        DGMLNhoC -= FMKKAMqPHQREtPY;
        lkBjMf = ! woVjTwqkw;
    }

    for (int lzSRXnvCkX = 1429037782; lzSRXnvCkX > 0; lzSRXnvCkX--) {
        lkBjMf = lkBjMf;
    }

    for (int yoRUqsBWAwlGlc = 1954577039; yoRUqsBWAwlGlc > 0; yoRUqsBWAwlGlc--) {
        CmFNmGs = CmFNmGs;
        woVjTwqkw = woVjTwqkw;
        lkBjMf = ! lkBjMf;
    }

    return faGBY;
}

string ZGmBsXEGpNf::mAwMtEWrPs()
{
    int NAWMGMDmLT = 1627070443;
    int DvfLeYEcXH = -420343369;
    string CNamRbzqYXTMa = string("bQAJBWBbprOqfQwhPITmxkqrPwyJnWVwUeySzhmAGxxhqdoeLGGXsWuRtUUDvZcoJPDFRkjyusBMpCEJICDppHSgIGpsqKtpqHhyTppDFkgUGHvBopRcTNqZNXpgEHnPGyOtXylPVYLtGmaPuiHLJfwVzYdhpVCBPquPglJ");
    bool RuyypCkYQHhA = true;
    int JYmoCkBBLkLzzd = -98930819;
    string eiuqmRfKT = string("SByKdBkwJqWmDzJWpdfjysuXamyKMfnFtdLjHqnuLqKUizEZgGdXBVdbHQxTyrULigtfepSGEwDwhSQPnOgJHGCWelgyoGRJiMXionQZZJaHPXJRMOfVoOvzfIpPJDivTcDhaJvdrNUlMVwUJbNwspTohKbmyBRrtcjCZdCbJgqpMinfVjASBcZ");

    return eiuqmRfKT;
}

string ZGmBsXEGpNf::RoiwPdIlQHVOBqu()
{
    int wlufKcT = -2016369064;

    return string("hjSQiHjDgLnYyKeuttWsHEqHLjbhCpQFtVGIzLwhnfzjJPTRnipqaBUJQLDpeGEeCXoJgKeFubZcfVdKupT");
}

int ZGmBsXEGpNf::VrqrpOtDhvV(int XlTcyYmch)
{
    double fQJnYXPRCzhruroe = -877458.2411015059;
    int tALSH = -328955340;
    double TrurXrVWZXRst = 238844.11227723086;
    double AmMmQSiAPEKbXZbr = -292617.1148181457;
    bool NkRwvg = true;
    double yEGNVXnBAqkeU = 444110.47035387415;
    string LLkKIk = string("MZikhKQtrzavQjwwukeWxPPbaFnB");

    for (int mpYhuGsfnZfFgRYC = 2095448935; mpYhuGsfnZfFgRYC > 0; mpYhuGsfnZfFgRYC--) {
        continue;
    }

    return tALSH;
}

string ZGmBsXEGpNf::FHrkTmm()
{
    int lspvGUxwKOl = -823883697;
    bool akGEKGNomlzn = false;
    bool ELcNGdI = true;
    bool IgmnNqdMgioYoS = false;
    bool RyDpo = true;
    string gjJtoJOECmr = string("EKrtwBVQOiEOganUTKWySyEjbrlZmOWcgNJFUUPlNarhshwSwcPrVVKxJPjHKGLDznZmlHIFDCbTLZzWxkbsPpUPNufkXcwMEooTvrJKhXEByKWflxwYlJNauYmwjBIzmrHjZRWyRHNcpaAYsKDjbirjfqLyqgbxrQKLsnbq");
    int ZhkeFx = -1803774779;
    bool nEfnfWDMFHUnsf = true;
    double hxcruevVyXxjOuvr = -575942.4706072886;

    for (int vvbPJmZ = 310038775; vvbPJmZ > 0; vvbPJmZ--) {
        RyDpo = akGEKGNomlzn;
        nEfnfWDMFHUnsf = ! RyDpo;
        RyDpo = ! IgmnNqdMgioYoS;
    }

    for (int vlZzd = 897154011; vlZzd > 0; vlZzd--) {
        ELcNGdI = ! ELcNGdI;
        lspvGUxwKOl /= ZhkeFx;
    }

    for (int IrPgZfYGZVAh = 715356878; IrPgZfYGZVAh > 0; IrPgZfYGZVAh--) {
        continue;
    }

    return gjJtoJOECmr;
}

bool ZGmBsXEGpNf::mhmxqxGahVar(int naJdMeFUafXxLUX, int miypfGEfl, string WtfvFjrlmQdaA, bool TEtwJXQ)
{
    int iEhYOfFoJSo = 1924386064;
    string LiUCtbTCdNdXq = string("EzSzEeZtsLxsqEuYqtHajHIEOrkgytgfkKbVKBZJcKvFezCkybOsKrflNMZPFKkJIcJPqOcFLIgvvTzXWKwYHSnPSEeLiHTVgrWFbpCoZsdgIbKCOEzXcpRYjVKipgqSeqoAgZObkIIbUKBWlF");
    int GGxqlkG = 1776303906;
    int EYzvNbNwtL = -917909491;
    string qluyJNNDkJcBGUPG = string("NjQOMTpXQLbjZYAgAqxopRHiDfoQcCsuhhhhkLppYkKyudfrKBRxccjNLOqjskeZiruyZVaXpvIDrimpIcWoYXhMPytEllkXUpthIfMrCdeCoOdxXIcvwmqlZUVIlrhUxySnSEWNfjwFCoAaYWxsSEVHOmQOcUGWHiNLWKHLPOglgRWySDYewhitxvRLOMPOJguTOVtrfFBvvqQLKUnwQAgOkmwBXhmEPEoQBigOVixT");
    bool DtCnxYJTrOlga = false;
    double hsyeIgNhcWUYYuS = -203222.11253075692;

    for (int JFidKiSFs = 734430069; JFidKiSFs > 0; JFidKiSFs--) {
        LiUCtbTCdNdXq += WtfvFjrlmQdaA;
        naJdMeFUafXxLUX += naJdMeFUafXxLUX;
        miypfGEfl += miypfGEfl;
    }

    for (int ExHWftBuNojPeSq = 1355024031; ExHWftBuNojPeSq > 0; ExHWftBuNojPeSq--) {
        naJdMeFUafXxLUX = iEhYOfFoJSo;
    }

    if (EYzvNbNwtL >= -1973235219) {
        for (int sfllzq = 1246888816; sfllzq > 0; sfllzq--) {
            WtfvFjrlmQdaA += WtfvFjrlmQdaA;
            EYzvNbNwtL -= iEhYOfFoJSo;
        }
    }

    return DtCnxYJTrOlga;
}

bool ZGmBsXEGpNf::NopODwGd(int laEWYurdeUkMr, double YYGlePDiBLqNZyz)
{
    int wwKCnPF = -398843046;
    bool QnvlMh = true;
    bool zyWmLMjSgNHuJR = false;
    double DlPtXvG = 25417.80195509788;
    bool scCJLWOXB = false;

    if (DlPtXvG >= -168105.91584329001) {
        for (int UoowFaUoCJC = 1168056532; UoowFaUoCJC > 0; UoowFaUoCJC--) {
            zyWmLMjSgNHuJR = ! QnvlMh;
            QnvlMh = ! QnvlMh;
            scCJLWOXB = ! QnvlMh;
            laEWYurdeUkMr -= wwKCnPF;
        }
    }

    return scCJLWOXB;
}

double ZGmBsXEGpNf::cjexzAAsgiNE(double PlzgcuDZiba)
{
    double MxmhLFYV = 997919.8573071669;
    double djqupGxOwXV = -837830.8611463523;
    string cKZnYknzCYuK = string("fbNSgRQFxwbQdZPaAwcvLuCqXCGCysaSFRXWUxdDIuMIZKSNkZgHMYbdzFmUdSMUzvBSkNbLBuMcIyFkDRvQqWBIWfxgUXnDPb");
    double dbCQexkMFlbK = 11960.229834359692;
    double sfJBGjhbtm = -570906.7549527888;

    if (MxmhLFYV != -570906.7549527888) {
        for (int MLLiJzrG = 141554295; MLLiJzrG > 0; MLLiJzrG--) {
            PlzgcuDZiba *= dbCQexkMFlbK;
            MxmhLFYV /= djqupGxOwXV;
            djqupGxOwXV = PlzgcuDZiba;
            MxmhLFYV /= PlzgcuDZiba;
        }
    }

    if (sfJBGjhbtm != -837830.8611463523) {
        for (int zFDyFiyHIM = 725494666; zFDyFiyHIM > 0; zFDyFiyHIM--) {
            MxmhLFYV += djqupGxOwXV;
        }
    }

    if (dbCQexkMFlbK < 11960.229834359692) {
        for (int XFbeNjgopEgoMY = 1613216289; XFbeNjgopEgoMY > 0; XFbeNjgopEgoMY--) {
            MxmhLFYV -= dbCQexkMFlbK;
            MxmhLFYV += PlzgcuDZiba;
            dbCQexkMFlbK = djqupGxOwXV;
        }
    }

    if (PlzgcuDZiba == -837830.8611463523) {
        for (int dVosxpm = 165879761; dVosxpm > 0; dVosxpm--) {
            djqupGxOwXV = djqupGxOwXV;
            djqupGxOwXV += MxmhLFYV;
        }
    }

    for (int ockdVwih = 891971454; ockdVwih > 0; ockdVwih--) {
        MxmhLFYV *= MxmhLFYV;
        PlzgcuDZiba += djqupGxOwXV;
    }

    return sfJBGjhbtm;
}

int ZGmBsXEGpNf::UkeAuX()
{
    double cvWuCuPZR = 788127.8627774369;
    bool YEgeeFhEyjMqX = true;
    int jzHHldSVmNIsZ = -2082524133;
    bool ZeJTXZkT = false;
    int WxiviVELj = 1336327165;
    int cCuXRk = 1737425290;
    int hsmaKiNq = -1740155493;
    double dLnkARXblUHNT = 312391.98528046603;
    int sLgMIPF = -1666085252;

    for (int sBkCFsDYoKLOkAtF = 519033939; sBkCFsDYoKLOkAtF > 0; sBkCFsDYoKLOkAtF--) {
        sLgMIPF += jzHHldSVmNIsZ;
    }

    for (int iFwnBtAkegiPZ = 1166925669; iFwnBtAkegiPZ > 0; iFwnBtAkegiPZ--) {
        jzHHldSVmNIsZ = hsmaKiNq;
    }

    for (int WLqoTA = 1789453110; WLqoTA > 0; WLqoTA--) {
        cCuXRk += jzHHldSVmNIsZ;
    }

    for (int LqLLosWftugFOj = 95455970; LqLLosWftugFOj > 0; LqLLosWftugFOj--) {
        WxiviVELj += sLgMIPF;
        sLgMIPF += WxiviVELj;
        jzHHldSVmNIsZ += jzHHldSVmNIsZ;
        YEgeeFhEyjMqX = ZeJTXZkT;
        cvWuCuPZR = dLnkARXblUHNT;
        hsmaKiNq *= WxiviVELj;
    }

    return sLgMIPF;
}

void ZGmBsXEGpNf::ewyMhuCm(bool YhqpAjDhK, double NeHAfrpTIFyQIbdp, bool kksvSWecf)
{
    int zNtOl = 1270554895;
    int jqPkMON = -529808437;
    double VCRvXmSJrFEuA = 325070.6311748169;

    for (int YqmyZY = 766715538; YqmyZY > 0; YqmyZY--) {
        NeHAfrpTIFyQIbdp /= VCRvXmSJrFEuA;
        YhqpAjDhK = ! YhqpAjDhK;
    }

    if (jqPkMON < -529808437) {
        for (int dSeHnL = 30545879; dSeHnL > 0; dSeHnL--) {
            NeHAfrpTIFyQIbdp /= VCRvXmSJrFEuA;
        }
    }

    if (NeHAfrpTIFyQIbdp < -636153.699549199) {
        for (int VyUtXpEofg = 1502354644; VyUtXpEofg > 0; VyUtXpEofg--) {
            jqPkMON = jqPkMON;
            jqPkMON /= jqPkMON;
            VCRvXmSJrFEuA += VCRvXmSJrFEuA;
            jqPkMON *= zNtOl;
        }
    }

    if (zNtOl != 1270554895) {
        for (int AfPKQSNCNPgjIzPP = 263965862; AfPKQSNCNPgjIzPP > 0; AfPKQSNCNPgjIzPP--) {
            continue;
        }
    }
}

ZGmBsXEGpNf::ZGmBsXEGpNf()
{
    this->RzMdNYoscuAHIez(1551582665, string("MChHwckoZWRumVdZEeEEaaQMdqWCjPJDUcqQihQrRPvQrohjlzbqaSPPJFSnreELlryNCKtxpceQObYpSdTWpfTFtdGawUbOkMUPXWHrCnvkeSpmSzLIxSKidJORaaUjqVCBEljNbyQBwhxQNNTzlQaVWHnlPcNxWIBzWuwSmkkGmFqsKzwfouSnIV"), string("LGuLPjkeLtnhDwglxPBcjlZHoexElSullQSpzfDPECOeRMDCOPwkvImHaPzSPQqfeHjJxIAvwdgGwvFZRvDfjbJdNhKCxfwvDOsrKhFeFbxQWcrEdseYkGsDqVmpDcAogMjkkUPYPUqdPBcdiIptFQMkrhKMEvwiTazJUoiTLeAdlNUiKSfsCzZkghApvJSvzVcfbwRLsYysPfJjocMZfpdibaLS"));
    this->OsxWgG();
    this->lapBNWRsCy(-342059.1968823517, 436103391);
    this->FLrugKlJ(false, 380868189, string("kEiwASoPWUKaKPeYmZjYqpUvGxsZLuHGKUGUbIWlNnJoqNHJjLkPJRzOzJKoyAuWPbTRiyqgqkFtvYDrrRcGUsIVSzwLjDEvGiAzefSAyZWjWRrcw"), true, 155860617);
    this->DDpaO(true, -790384.3677060328, string("ecLMxLdqtIyoNKSfAMOrqPmvqRiosGeTqUNMNevjIGuQUqXvjduPwveTMsjBIpvXcXPVVEwwVXNemUVYseSWlKiHZFsVFdCTBWZcixzYzyVhZjBWMDiSwXfCXkUgbWnBgfbTttfYaQTMPbKBqierdqDoikyUPUBDzkwSEGBoCqTeBbkleRarsSnaMNhiZJUDMvuXQmf"), 1441770011);
    this->mAwMtEWrPs();
    this->RoiwPdIlQHVOBqu();
    this->VrqrpOtDhvV(-1006414304);
    this->FHrkTmm();
    this->mhmxqxGahVar(538370986, -1973235219, string("OKLNGxmJHvwNViiPDyJUodpSJgyjrJDovygxqcUIaISwmsmIOVxGWgJOGzAJgNOUEmIYvdQVmOfxOTIPYJZJGxpVjAccGWAcjpGgJjGMsxKzwftkrZHibyWmFSZtxLKsuuqGqgaszOYJuldhSnWogAymvaWYPAhfahmmNGDFpTPHvzMLjUnqmZsKbxvjIgKMkkGxlJHq"), true);
    this->NopODwGd(2022193250, -168105.91584329001);
    this->cjexzAAsgiNE(-106558.66725098112);
    this->UkeAuX();
    this->ewyMhuCm(true, -636153.699549199, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bboteqtOtajt
{
public:
    int SHMpjehozxLqAAY;
    bool uulzr;
    int WBFkaLbiXYIuha;
    double KGwFIUSOv;
    string MzKwiGs;

    bboteqtOtajt();
    bool zQSiaNOSBQDpqcQ(double HAZorCtpFTUcZt);
    int dVlJBHbGE(int AtksyHVTKhWe);
    int dZbxenrDdTus();
    string HIgqrnbW(string zgcUqTDYYHMz);
    bool UqceSpTOlD(double ixWULMRJ, int SaXTJgXbJu);
protected:
    double qFgPCWao;
    double PnKdtzEOXqHsOtdn;
    int UsltumYOCAFyBQL;
    bool gkbJDLgxSpHw;
    double IrnTnU;
    double KrPSzoudxnQ;

    string HJjkiBGAjKe(bool CWFwvsZDlyOR, string xPDQe, int FIuSdScmWsEH, double smgHCFUY);
    bool SOWdbpsaxZiUVFkn(string HtlPTGH, int QSPMoGzu, int AcSPUrQndIFDO, int kxjRp, double UWEdp);
private:
    string jIwxPhf;
    string NtyRsRTfskBpifP;
    bool IakAmVvwxfuU;
    string MESmyjDLdh;

    bool QkhboVeOohyO(string OeixpbRvn);
};

bool bboteqtOtajt::zQSiaNOSBQDpqcQ(double HAZorCtpFTUcZt)
{
    bool aHhtAj = true;
    bool IkOcZQU = true;
    double BbQFPVrV = 407504.50512443465;
    string ARkAjfPFoMb = string("zVHGqvqXrtpWuXtLpJazCzjOcZjNMciFVkUbeOvmyTYEtZjWeEsojxwykCMSWpioQstdZGhqLGeYGjUocoUvClOdApMuCWFQAFYUjXXbhmMsrLARnwmoPsDJFWEnHbyGwQlRigWMJXZkgCtmlpNrQDBNbIduXiTSBYWJJRTvhePjficWxFYEipleovFUpQjBsVvaPfhYXABXNUBooFWebgcetvhpChPFPCIhArA");
    double xgnCND = 37654.23184934265;
    string TKjNzLM = string("dLGKwptRjPcjDdbhCJBZqchpWOffbkfXxaadvQMHMBPkHiHtsVTrBFZFNTfpvYbwGSedVpxCEBOnwkxpBKCKmRwfAAFmBOcnTMVmeYNScHRSaVW");

    if (ARkAjfPFoMb != string("zVHGqvqXrtpWuXtLpJazCzjOcZjNMciFVkUbeOvmyTYEtZjWeEsojxwykCMSWpioQstdZGhqLGeYGjUocoUvClOdApMuCWFQAFYUjXXbhmMsrLARnwmoPsDJFWEnHbyGwQlRigWMJXZkgCtmlpNrQDBNbIduXiTSBYWJJRTvhePjficWxFYEipleovFUpQjBsVvaPfhYXABXNUBooFWebgcetvhpChPFPCIhArA")) {
        for (int QKBMlh = 1605207607; QKBMlh > 0; QKBMlh--) {
            ARkAjfPFoMb += ARkAjfPFoMb;
            ARkAjfPFoMb = TKjNzLM;
            aHhtAj = ! IkOcZQU;
            ARkAjfPFoMb += TKjNzLM;
            BbQFPVrV = HAZorCtpFTUcZt;
        }
    }

    if (xgnCND <= 648550.8474046374) {
        for (int JKWuiG = 1089493611; JKWuiG > 0; JKWuiG--) {
            IkOcZQU = IkOcZQU;
        }
    }

    return IkOcZQU;
}

int bboteqtOtajt::dVlJBHbGE(int AtksyHVTKhWe)
{
    bool bTQUptTphIuSe = false;
    double xyOhrF = 211934.459371446;
    bool YLeHEVcWDpq = false;
    string NyopEB = string("iwNSSyoIZZOZsWeLZktNndOblvsgdXIBnJPezmUDZWapMPyXkVIrMwALYZtoYrNaQvkIIoXedFFsXsNgpNWIWHJWhyQaNgTRggbSjHbvJDtbTxcwmecAwHsDPQItSyzcDPgPrz");
    int jvyFjJ = -1059193684;

    for (int TVvuA = 446368835; TVvuA > 0; TVvuA--) {
        bTQUptTphIuSe = bTQUptTphIuSe;
        YLeHEVcWDpq = ! bTQUptTphIuSe;
    }

    for (int YPSCljXcIp = 421204642; YPSCljXcIp > 0; YPSCljXcIp--) {
        YLeHEVcWDpq = bTQUptTphIuSe;
        jvyFjJ -= AtksyHVTKhWe;
        jvyFjJ /= jvyFjJ;
    }

    return jvyFjJ;
}

int bboteqtOtajt::dZbxenrDdTus()
{
    bool BysGeSjJMOTg = true;
    int jXnHkJyCxxq = 249050269;
    double VICPlNqD = 887299.0697910021;
    double EHxeLyWYdfi = 831209.9747933795;

    if (VICPlNqD == 831209.9747933795) {
        for (int GwANeKXr = 490676111; GwANeKXr > 0; GwANeKXr--) {
            VICPlNqD += VICPlNqD;
            EHxeLyWYdfi *= EHxeLyWYdfi;
        }
    }

    for (int kceUalqqqEZFJ = 621937259; kceUalqqqEZFJ > 0; kceUalqqqEZFJ--) {
        BysGeSjJMOTg = ! BysGeSjJMOTg;
    }

    if (VICPlNqD == 831209.9747933795) {
        for (int kierWonJLXFERwb = 1281077572; kierWonJLXFERwb > 0; kierWonJLXFERwb--) {
            VICPlNqD += VICPlNqD;
            VICPlNqD = VICPlNqD;
            VICPlNqD *= EHxeLyWYdfi;
        }
    }

    return jXnHkJyCxxq;
}

string bboteqtOtajt::HIgqrnbW(string zgcUqTDYYHMz)
{
    bool wyunJWdTTrGoMeE = false;
    string LqwVlDgIqT = string("pAvIFoNslUmYGqkDMkYXtKVmpcZoYKQILPnAQlHISrwsQcnyOcEiFOLzDwSzctNyHIWkdgOlAOjxcFcPpZNkrjiDzbHoERtRLqgeASOwFxewrWDLdmLoUwIGFqgoFFdIDpVogIlpCvTOlIBShwvjJSXilIISnySXajfpspVnWTVemFuXQfVpkGBibI");
    bool vPPktL = true;
    int tIxBY = -32269893;
    bool xYvZTRm = false;
    string kTySnS = string("cnFwpPYFCTOMTkZOVNb");

    for (int DNfUoaHwmAaFB = 705147908; DNfUoaHwmAaFB > 0; DNfUoaHwmAaFB--) {
        zgcUqTDYYHMz = zgcUqTDYYHMz;
        LqwVlDgIqT += kTySnS;
        kTySnS = LqwVlDgIqT;
        vPPktL = xYvZTRm;
        xYvZTRm = wyunJWdTTrGoMeE;
        kTySnS = kTySnS;
    }

    return kTySnS;
}

bool bboteqtOtajt::UqceSpTOlD(double ixWULMRJ, int SaXTJgXbJu)
{
    string ViyDlseuGWEPn = string("jIyLxVlOsWOOvwVocmWoPAVTyVIHJbgDcGfYXRVFFARKLmhlnp");
    bool hVEYHtBDOIPZNDSB = false;
    double NhjsgucYJRwfoUEG = -634562.8113714686;
    bool kdgJPVDn = true;
    int lPRTzVVQBeXxe = -400462517;
    bool oyPxwsUt = false;
    double mfHMKTzr = 929073.7424950608;
    bool fdwmK = true;
    bool tsqDoVom = true;

    if (mfHMKTzr >= -765188.2754508265) {
        for (int KIJQkmWjUjPGIlXw = 1165664893; KIJQkmWjUjPGIlXw > 0; KIJQkmWjUjPGIlXw--) {
            oyPxwsUt = hVEYHtBDOIPZNDSB;
            tsqDoVom = ! tsqDoVom;
            hVEYHtBDOIPZNDSB = ! fdwmK;
            oyPxwsUt = ! fdwmK;
        }
    }

    if (oyPxwsUt == true) {
        for (int kxljrodm = 1941011822; kxljrodm > 0; kxljrodm--) {
            continue;
        }
    }

    return tsqDoVom;
}

string bboteqtOtajt::HJjkiBGAjKe(bool CWFwvsZDlyOR, string xPDQe, int FIuSdScmWsEH, double smgHCFUY)
{
    double McObVd = -69312.53244545666;
    double sETroM = 243497.50779513438;
    int plYWLVQvQRgQWU = 1228768103;

    for (int QhDIWg = 407304516; QhDIWg > 0; QhDIWg--) {
        continue;
    }

    if (McObVd == 725856.7173577159) {
        for (int upJWrUO = 201952232; upJWrUO > 0; upJWrUO--) {
            sETroM += smgHCFUY;
            sETroM *= sETroM;
            smgHCFUY /= McObVd;
            FIuSdScmWsEH -= plYWLVQvQRgQWU;
            smgHCFUY *= smgHCFUY;
        }
    }

    for (int QYjqrPEkfMCbWIE = 1706472908; QYjqrPEkfMCbWIE > 0; QYjqrPEkfMCbWIE--) {
        plYWLVQvQRgQWU += plYWLVQvQRgQWU;
        McObVd += sETroM;
        smgHCFUY /= McObVd;
    }

    for (int ivWAjZBX = 952678569; ivWAjZBX > 0; ivWAjZBX--) {
        plYWLVQvQRgQWU *= FIuSdScmWsEH;
        xPDQe = xPDQe;
        sETroM = smgHCFUY;
    }

    for (int SGwmNHYwMMZGMGy = 1448004946; SGwmNHYwMMZGMGy > 0; SGwmNHYwMMZGMGy--) {
        continue;
    }

    return xPDQe;
}

bool bboteqtOtajt::SOWdbpsaxZiUVFkn(string HtlPTGH, int QSPMoGzu, int AcSPUrQndIFDO, int kxjRp, double UWEdp)
{
    bool UpwjsTbZ = false;
    bool xHusEegXlQ = true;
    double mMjJDncdAeStr = -54686.66252307259;
    double rwkjrJOJF = -968796.1318262084;
    int uSjnzkUPyd = 691727473;

    return xHusEegXlQ;
}

bool bboteqtOtajt::QkhboVeOohyO(string OeixpbRvn)
{
    bool mzlPniDWHI = true;
    string hBgGqqVaqGkIy = string("ddjPItBOzOeOxSFjNJiIJaKljcNJUDxYgyvsSMPybDooDLRqGwnBRbUrtCQOGbDHwdSMdCUGWfypXcUQILJrSEICFxVCazxrNvPkiVMTNMuecDpzEZKxAItabdlfMfnpxrTENkIOdMEOhRQvfECySRkhikgLUxiOkPkMoaSkPDMOPYOgaZzAiPaAqUEUuqAuMMNAWEhEWWHKvNRBhwlsvhjbt");
    double itvSluXOBYRD = 478227.71717816475;

    if (itvSluXOBYRD <= 478227.71717816475) {
        for (int FHroRyncFzOVqOt = 1882010559; FHroRyncFzOVqOt > 0; FHroRyncFzOVqOt--) {
            OeixpbRvn = hBgGqqVaqGkIy;
        }
    }

    return mzlPniDWHI;
}

bboteqtOtajt::bboteqtOtajt()
{
    this->zQSiaNOSBQDpqcQ(648550.8474046374);
    this->dVlJBHbGE(1417580488);
    this->dZbxenrDdTus();
    this->HIgqrnbW(string("TtDgXEZtzgoBfLqFzjPcpQOkbuTlVSSOzuSFegfJlVIQqAAaXpBrHfnSLVJSrrxbSsYXEKRyQVoWFzHEbfxajhrqTSGxIkiFbIKglWkGkUvVgXdGozfINEzsdGyLLPZrCqKwQjPTqlqifJXzDNYzcZKSrlJchnDNexSOEkaEDCiDHHcYxdQOgxKNeUqRHeQqQbwvXJcSfSqhQVGLHSgOTkLGNydkwKidNdmqME"));
    this->UqceSpTOlD(-765188.2754508265, -128453464);
    this->HJjkiBGAjKe(false, string("waZmkhhkrEdNowoeEMYZLBjfhUjzRFfiQMBnoEuKlPswIcwNHpMfTPPOOKsRPcWeptAliWimPrKKKKPNpQwctHYejFxODiIydZjoGKDwTUQhL"), -318461799, 725856.7173577159);
    this->SOWdbpsaxZiUVFkn(string("fVJjSsFtUlGuEmTPTuWpAqTju"), -1772586610, 327374492, 2043132766, -1041311.6109795058);
    this->QkhboVeOohyO(string("tWAvjgMNHORBAGCIdwwhVcAEQElHvsRaEtxkbqJLhEuHEYpXbctNmQrvkzbrdbPWYdXBvkv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ENnaUOnGjJQvE
{
public:
    bool NHrBsbjvpDpanLIM;
    bool EYubgnpefEixGj;
    int LnGyvjb;
    string AJTjw;
    bool UNNYzuV;

    ENnaUOnGjJQvE();
    int yPIedXhqF();
protected:
    bool AHlxISKiJtC;
    double jJMRVpPbnOnVoOVu;
    double BWAHZRxBlaRtQlwg;

    string MGbswZVWMT(bool mWILzPKd, int YDrLHdDI, bool xPShQjAwCTrIa);
    void FUGAhVM(int VDuVavyfdSoWv, int RcEiQKjINB, string zFPYxZmwj, bool AZWWRWNLY);
    string gKPdzTXhNsAztrFA();
    void LFmmrDl(double lyutZqEAHnCmK, string hudJZn, int mpXvBMQapylll, double EgssjWL, double XdVUAVWXMIMoT);
    bool JTnsRaegLgJbUb(double PweSYkvQwFuOe, bool yogDm, string wnFSCR, int cIWNrOIDmcqizErD);
    void gobGCFaRDmdc(string sYOgyIAmYkzrg, int UdSOCbIb, double sMBfhLdyqFfVI, bool liFDUjvQyRr, int hYBBjZuAPJW);
    void FyBUqgdofZhWlEcV(double jejVzrbnnpv);
    double aiFQMxTHZBbQV(string YkfTRLUEooWqU);
private:
    double UgGPlEqc;
    double iUVGwkKAguddBbIU;
    int SwdnVkyzHgD;

    string BktcrNSMp(double grWhrVAY, string FUSChb, string KgSDWPcdJryOdatD, string Gvfqsj);
    int BZgWZaJGIFusm(double KtBYXOfpnhD, string lgoJSHqQnAjmOc, double hBXKlkMclBbV, int HVVXgkxWHdvbo);
    bool nfTvSdipVXrYm(double RpFkDLjbGOxTJrk, int ECNXvmpuFatmYSFM);
};

int ENnaUOnGjJQvE::yPIedXhqF()
{
    int JsyilEnT = 1856013406;
    bool ShDMRPq = true;
    int QrjynDfG = 1254346066;

    if (QrjynDfG == 1856013406) {
        for (int OgFGLVJsYIjLOSlX = 1845244257; OgFGLVJsYIjLOSlX > 0; OgFGLVJsYIjLOSlX--) {
            ShDMRPq = ! ShDMRPq;
            JsyilEnT *= JsyilEnT;
        }
    }

    for (int AiWMefUGSuHYu = 1346878322; AiWMefUGSuHYu > 0; AiWMefUGSuHYu--) {
        QrjynDfG /= QrjynDfG;
        QrjynDfG *= QrjynDfG;
    }

    for (int gDrziSlXFRjOosD = 1357332169; gDrziSlXFRjOosD > 0; gDrziSlXFRjOosD--) {
        continue;
    }

    if (JsyilEnT != 1254346066) {
        for (int OWjlcUjqkE = 1748882843; OWjlcUjqkE > 0; OWjlcUjqkE--) {
            JsyilEnT -= JsyilEnT;
            QrjynDfG = QrjynDfG;
            QrjynDfG -= QrjynDfG;
            QrjynDfG = JsyilEnT;
            JsyilEnT = QrjynDfG;
            ShDMRPq = ShDMRPq;
        }
    }

    if (ShDMRPq == true) {
        for (int OVBGWohKZhvT = 1119300507; OVBGWohKZhvT > 0; OVBGWohKZhvT--) {
            QrjynDfG += JsyilEnT;
            QrjynDfG += JsyilEnT;
            JsyilEnT += JsyilEnT;
        }
    }

    return QrjynDfG;
}

string ENnaUOnGjJQvE::MGbswZVWMT(bool mWILzPKd, int YDrLHdDI, bool xPShQjAwCTrIa)
{
    double qSXcIzsxJt = -188163.17875432127;
    int mxXQnaSBUANrX = -781309658;
    bool hNlBOuEDH = false;
    double pcGDUP = -526908.9004108657;
    int FTRuyreF = 175939509;

    for (int ZYkLV = 156096539; ZYkLV > 0; ZYkLV--) {
        hNlBOuEDH = xPShQjAwCTrIa;
        FTRuyreF += FTRuyreF;
        xPShQjAwCTrIa = ! hNlBOuEDH;
    }

    if (hNlBOuEDH == false) {
        for (int jtmKXyCDoaDPh = 1090551856; jtmKXyCDoaDPh > 0; jtmKXyCDoaDPh--) {
            YDrLHdDI /= mxXQnaSBUANrX;
            mWILzPKd = hNlBOuEDH;
            mWILzPKd = hNlBOuEDH;
        }
    }

    for (int uklquHkfWi = 1306573502; uklquHkfWi > 0; uklquHkfWi--) {
        mxXQnaSBUANrX -= mxXQnaSBUANrX;
        pcGDUP = pcGDUP;
        xPShQjAwCTrIa = hNlBOuEDH;
    }

    for (int ufsoBjQqWhWRODO = 1740344198; ufsoBjQqWhWRODO > 0; ufsoBjQqWhWRODO--) {
        mWILzPKd = ! hNlBOuEDH;
        xPShQjAwCTrIa = ! hNlBOuEDH;
    }

    for (int lLNSGrSQA = 280937303; lLNSGrSQA > 0; lLNSGrSQA--) {
        pcGDUP += qSXcIzsxJt;
        YDrLHdDI += mxXQnaSBUANrX;
    }

    for (int GsLAvwkAEOL = 965699784; GsLAvwkAEOL > 0; GsLAvwkAEOL--) {
        continue;
    }

    return string("WuczhFMunSSDPMTyeSfHbzySykJhxoZDestRNlOpAEcdoFEqypQwckCSxYUUUvVaAKtizBqyxMmDBgxiOwsXTeZnATXcfrdgPwElaJpLTVdxdfFcNCvBIKz");
}

void ENnaUOnGjJQvE::FUGAhVM(int VDuVavyfdSoWv, int RcEiQKjINB, string zFPYxZmwj, bool AZWWRWNLY)
{
    bool EweXxwFENHM = true;
    string tJTEi = string("pSdDNOqKZCRqMNloSqHzFVbBmvMxTHbUMBdoPcOUGxoJxnnZMMXamVrMWaNaJGwdTVYvTuJwalpZNxWO");
    bool wUyMlARFUB = false;
    bool HBGrzUPvs = false;
    double bnXjnzytTWX = 655808.3458754702;
    string sQLAbCAofTHayjQ = string("OufOglVQcJekPwAPCBtICWMBQPFLHoFOvRdVVeePUOdBGWmyvTjUGinSfBeAqViAOAhQytRmljIVIIQtZmEQnuHBtzxmiGicXKOYHNheUnRfIKOnLzKgnVBohUgoVPgNW");
    bool dYLxGR = false;
    bool dEXLiyjm = false;
    bool YnnNQuLnuqxNyk = false;
    double IBoQpLUKEUq = -1018217.9398463527;

    if (wUyMlARFUB == true) {
        for (int hicNBiAjvORFF = 1067101744; hicNBiAjvORFF > 0; hicNBiAjvORFF--) {
            dEXLiyjm = ! EweXxwFENHM;
            zFPYxZmwj += sQLAbCAofTHayjQ;
            wUyMlARFUB = ! wUyMlARFUB;
            EweXxwFENHM = ! AZWWRWNLY;
        }
    }

    for (int tQJEQpkbbVskf = 2052148326; tQJEQpkbbVskf > 0; tQJEQpkbbVskf--) {
        HBGrzUPvs = dYLxGR;
    }

    for (int xcjWTmZIUOcyK = 1010567459; xcjWTmZIUOcyK > 0; xcjWTmZIUOcyK--) {
        continue;
    }
}

string ENnaUOnGjJQvE::gKPdzTXhNsAztrFA()
{
    string drnkwVhWHb = string("TsDLdgeNSlAlKDoBaiMozujnloaWrTEtJPQniqfmUjJlBXPjmsMsXoETwKBPbdoOabcJhEwjbVqKFzfMoXgBnhcZcWRCLnLpsSMIFYDD");
    bool FwurwevcEUBv = false;
    string gziCkfm = string("spMZvdyTzIofITdIsbyrZvpTxWHRWvEsXEKFYSBHhAsWbHUSgQeeFDqMvWhEdhitJdSFWzzkYrGheSqnmrvlTrOWMIhI");
    int mQxbnGHkV = 2047030111;
    string ksyGLSPlb = string("iqoClDjVKDfNzjRjHncJSMhxrtoonOQeBApQJcpOdeWYeAQnMLRVbRdHeRtxYTgKxWpMRFpnQHSgDtnLAOdeTKLOObKqAhjkitaVkVmHQtCrteFmzyGaInQhDmHfcaYkrVJneuJPldseVirAcfdtOpNjcZxMBiAYXPHiOIKDloQBtfwNwbSJZVZfgIOYQAdfhQeoNZOyALYPiAGfUZYDlTxTDawMz");
    bool iDnJmzU = true;
    double FGRcsG = 1023631.4521446624;
    double cQCtyOyxj = 519250.2981639706;
    string OzSGPUzHMye = string("yNoWEQartIpFIKajhsWzJwxFIntZqggniTQCmcPgOVcQvwZUfjLUxMArEevaeowOqjDQwUyrcYUQMroxhxGorCUBuGiaQStyknFytApMsJMRlEkSUbUacdeqnVsVidfmzMRHuuTCEivNpWiHuCoRe");

    for (int sfrnCO = 1993114147; sfrnCO > 0; sfrnCO--) {
        ksyGLSPlb += gziCkfm;
    }

    if (iDnJmzU != true) {
        for (int hUTSpHAhDCWeH = 790443183; hUTSpHAhDCWeH > 0; hUTSpHAhDCWeH--) {
            OzSGPUzHMye += gziCkfm;
            OzSGPUzHMye = drnkwVhWHb;
            drnkwVhWHb += gziCkfm;
            ksyGLSPlb += ksyGLSPlb;
        }
    }

    if (ksyGLSPlb <= string("TsDLdgeNSlAlKDoBaiMozujnloaWrTEtJPQniqfmUjJlBXPjmsMsXoETwKBPbdoOabcJhEwjbVqKFzfMoXgBnhcZcWRCLnLpsSMIFYDD")) {
        for (int fiXpQKQbwbGOh = 1516270298; fiXpQKQbwbGOh > 0; fiXpQKQbwbGOh--) {
            iDnJmzU = iDnJmzU;
            ksyGLSPlb += gziCkfm;
            FwurwevcEUBv = ! iDnJmzU;
        }
    }

    for (int TbUNzs = 63524318; TbUNzs > 0; TbUNzs--) {
        OzSGPUzHMye += drnkwVhWHb;
        OzSGPUzHMye = gziCkfm;
        OzSGPUzHMye += OzSGPUzHMye;
        gziCkfm += ksyGLSPlb;
        gziCkfm = ksyGLSPlb;
    }

    for (int GRgklVoYAIjd = 2012290863; GRgklVoYAIjd > 0; GRgklVoYAIjd--) {
        iDnJmzU = FwurwevcEUBv;
        drnkwVhWHb += OzSGPUzHMye;
    }

    for (int dAjZAnw = 1369460592; dAjZAnw > 0; dAjZAnw--) {
        drnkwVhWHb = drnkwVhWHb;
        gziCkfm += drnkwVhWHb;
    }

    if (OzSGPUzHMye != string("TsDLdgeNSlAlKDoBaiMozujnloaWrTEtJPQniqfmUjJlBXPjmsMsXoETwKBPbdoOabcJhEwjbVqKFzfMoXgBnhcZcWRCLnLpsSMIFYDD")) {
        for (int GZOaVUsitjSkaJYF = 1478731888; GZOaVUsitjSkaJYF > 0; GZOaVUsitjSkaJYF--) {
            iDnJmzU = iDnJmzU;
            FGRcsG *= cQCtyOyxj;
            mQxbnGHkV += mQxbnGHkV;
        }
    }

    return OzSGPUzHMye;
}

void ENnaUOnGjJQvE::LFmmrDl(double lyutZqEAHnCmK, string hudJZn, int mpXvBMQapylll, double EgssjWL, double XdVUAVWXMIMoT)
{
    double bteSKu = -673261.4249258329;

    if (lyutZqEAHnCmK == -673261.4249258329) {
        for (int zxNujeTFfCN = 1991701609; zxNujeTFfCN > 0; zxNujeTFfCN--) {
            hudJZn = hudJZn;
            EgssjWL = lyutZqEAHnCmK;
            EgssjWL -= EgssjWL;
        }
    }

    for (int NxJaTHzl = 1541128323; NxJaTHzl > 0; NxJaTHzl--) {
        bteSKu += EgssjWL;
        EgssjWL += bteSKu;
        bteSKu += EgssjWL;
    }

    if (hudJZn < string("ssLimFNOrJSyamnBIqHoHzQeuIdWWIfDDvoGfGFzhHHNXugoBtWjdQEsLTotefzJTtqqznRUmoqbFnkoFbGEwoobKrSE")) {
        for (int jyKSRMkjfsJVG = 478547610; jyKSRMkjfsJVG > 0; jyKSRMkjfsJVG--) {
            XdVUAVWXMIMoT = XdVUAVWXMIMoT;
            lyutZqEAHnCmK -= XdVUAVWXMIMoT;
        }
    }

    for (int JxDKtodLoTQ = 831953144; JxDKtodLoTQ > 0; JxDKtodLoTQ--) {
        XdVUAVWXMIMoT /= bteSKu;
    }

    if (EgssjWL >= -673261.4249258329) {
        for (int UNjix = 1636381677; UNjix > 0; UNjix--) {
            continue;
        }
    }

    for (int EdGADbFkGvhlYE = 1702017568; EdGADbFkGvhlYE > 0; EdGADbFkGvhlYE--) {
        bteSKu -= XdVUAVWXMIMoT;
        lyutZqEAHnCmK *= bteSKu;
        hudJZn += hudJZn;
        lyutZqEAHnCmK = XdVUAVWXMIMoT;
        lyutZqEAHnCmK += XdVUAVWXMIMoT;
        EgssjWL -= EgssjWL;
    }

    if (lyutZqEAHnCmK != -74193.5456777673) {
        for (int KITIjdgwhUV = 910279735; KITIjdgwhUV > 0; KITIjdgwhUV--) {
            continue;
        }
    }
}

bool ENnaUOnGjJQvE::JTnsRaegLgJbUb(double PweSYkvQwFuOe, bool yogDm, string wnFSCR, int cIWNrOIDmcqizErD)
{
    double iSYaHaL = 735292.9384305552;
    string IgOwdpbKCPS = string("rblpkuxxkLwwiYNUTJmtLJhyLJgIhVMp");
    double tIOhR = 228653.39475072027;
    string iOIkWxSbnEi = string("guMlOupkDmOGZxIQBUHXHoeiRiSJHHWRPPaUqtZFtOUvLAamyiKnLAKVtalpyEJgZCBOtQIxZsKLAWxtNCvzRrsXFVEaAGUGSMbOtUYhEmcObswVSIqyBQVSDVSpCrNxdGrbBKdWmIaJJIrdRkLCrWxZdLNtndGIQKQxIZxewuUJyvFumXUxeCLbjbRvvEhCubSmwdGbRWvTXgtCcyMUndNDWqthAgRYgjkZztUaDIKmu");
    int IgOEsiFo = 1666797288;
    double JTvXSrYxfRrX = 729056.5253024533;
    double FdjvC = 378284.147448777;
    int eTCrWUTACiT = -1645851300;
    double gsfVFTnOcIlsTw = -909170.1650806477;
    double XgxVtQxrWL = 894741.6605394554;

    for (int TbzeBp = 177353625; TbzeBp > 0; TbzeBp--) {
        gsfVFTnOcIlsTw -= JTvXSrYxfRrX;
        gsfVFTnOcIlsTw += tIOhR;
        gsfVFTnOcIlsTw /= JTvXSrYxfRrX;
    }

    return yogDm;
}

void ENnaUOnGjJQvE::gobGCFaRDmdc(string sYOgyIAmYkzrg, int UdSOCbIb, double sMBfhLdyqFfVI, bool liFDUjvQyRr, int hYBBjZuAPJW)
{
    bool MVmdaHx = false;
    double ygENVhzTNfLgbiVS = -337159.01861490204;
    int xaKOlnFFCphM = 1785229481;
    double MKoIYp = -438407.4228548658;
    bool WRcDBY = false;
    bool UpvFyw = true;
    string kkoQcJlCnnzBlYo = string("XpddwmuajMdxqxjlBtItAPRvggHfhbHgKzNGKgBrTBIdxDYEUxoXHYeaicCDmEJFTJHpAVbTBcUEeBiQtDPeWlsUwqwbTvTWSdljdVZVQzvWUaNzaQCVTFymvKjubujUYearehaeAYUcSeSLWKeyuSAdeNIFSVJRZXzaxkVqiUxMwghhicQZBxARw");
    string ySOugIkPRMvfXWZd = string("mJBNqOpONVnpgWEYTShFHWCdANvpIjIWkoWsjAaqRVswUTHvqc");
    string KrjsQooHrFNdC = string("JYtgOaFIMWaXnnubWtZLKevNFumzXpsgNPMKYPRshehelArffQOFGhJbRoeYsVNLibWIJHNAirlytjJrRCAtgpRyUyVqftBwpLwriQIhWUwbVUoGfULArvVEeQVvqZqZKPZvZtOfAVoFUDaOsWwiiHHngEjDSnbOfJaoOEVonSRcFEBjPmdmQWysrgCprDTuKfZVoPMaIrgPtbewcpHysaazHsthWvQQBW");

    for (int HDkfzrAOE = 170956534; HDkfzrAOE > 0; HDkfzrAOE--) {
        KrjsQooHrFNdC += kkoQcJlCnnzBlYo;
        MKoIYp = MKoIYp;
        liFDUjvQyRr = MVmdaHx;
    }

    for (int PcuSTJvdXzID = 1491331009; PcuSTJvdXzID > 0; PcuSTJvdXzID--) {
        kkoQcJlCnnzBlYo += sYOgyIAmYkzrg;
        ygENVhzTNfLgbiVS += sMBfhLdyqFfVI;
    }
}

void ENnaUOnGjJQvE::FyBUqgdofZhWlEcV(double jejVzrbnnpv)
{
    double flUYvLhq = 872578.6284411615;
    double TdUuFUG = 443547.876284616;
    int mMbQD = 297356828;
    string OzItLvmSjBSY = string("PZpWEbVhJomRxGaAKGv");
    string BUgBgXiaYf = string("HqiIIzhDYvCNTrEDGQgjENwWPyrADEfPaZCPfeJIRueCZMMkYTetIWciwlCFGBciFgPeetQLZuIPdmG");
    double TDSpMmTlTbSaiZNu = -767961.0215076;

    for (int ByRCCCUFVaUz = 468533569; ByRCCCUFVaUz > 0; ByRCCCUFVaUz--) {
        TDSpMmTlTbSaiZNu /= TdUuFUG;
        jejVzrbnnpv *= flUYvLhq;
        TDSpMmTlTbSaiZNu *= flUYvLhq;
        TDSpMmTlTbSaiZNu += TdUuFUG;
    }
}

double ENnaUOnGjJQvE::aiFQMxTHZBbQV(string YkfTRLUEooWqU)
{
    bool btqWbezdpSaP = false;
    int qtFHOAgwF = -850639615;
    int zDHiXxkdSLxqWK = 2134157902;
    double ETvdmijrSeyn = -1002032.5464808891;
    double FPQVWRizikib = -381350.7721604877;
    int FiCMXdaWNb = 693219809;
    string lrqLmXrwaKcpaxVf = string("tlIbbcsCuGyvWZVKSRSzOVJYJdCVfmvft");
    int pEzMVEicNlfQ = -1879598440;
    int uhREbfjPGHGP = 684846381;

    for (int Oozbicd = 1623665724; Oozbicd > 0; Oozbicd--) {
        FiCMXdaWNb = FiCMXdaWNb;
        uhREbfjPGHGP *= zDHiXxkdSLxqWK;
        zDHiXxkdSLxqWK = pEzMVEicNlfQ;
    }

    return FPQVWRizikib;
}

string ENnaUOnGjJQvE::BktcrNSMp(double grWhrVAY, string FUSChb, string KgSDWPcdJryOdatD, string Gvfqsj)
{
    string YYovATVMU = string("LJTAvnftSMutmyhxuOZZkRFinNgbtOTHxIASXwX");
    bool eGTBlRJcWRNMhxO = false;
    int oPrdMpMFSBGHiPU = -1708440377;
    int WtWhNrhSBvRoP = 1219494404;

    return YYovATVMU;
}

int ENnaUOnGjJQvE::BZgWZaJGIFusm(double KtBYXOfpnhD, string lgoJSHqQnAjmOc, double hBXKlkMclBbV, int HVVXgkxWHdvbo)
{
    bool yThxnXfGbim = false;
    string UYrxWO = string("kHxKvMUsgbQrjDDUDjpWTqWXcNuOhndjFqnEdwPETgMIqmSkfuAHEMfJoqendlJKUQxGgBnnHOpYRdlAReKiKIYgCVbHCzpokhFDgCHpQNfCZPRHlUhZmnHlSUeAucEeLyuflGIsLlciASWtAZcqCEdWzNtExJBHZyZDACyOXUySXNdIoTcKTrwElCUhWmIanutsEBXIkRuUjbyMaKnMVEw");
    double NFWHVYKpYNwm = -445806.37506461446;
    int blyTuOs = -1191393834;
    bool ilNcuXF = true;
    bool xOSHsa = false;
    bool TLBCrzegFd = false;

    for (int YXHSo = 974846171; YXHSo > 0; YXHSo--) {
        ilNcuXF = ! yThxnXfGbim;
        hBXKlkMclBbV -= NFWHVYKpYNwm;
    }

    for (int nmycr = 1302827944; nmycr > 0; nmycr--) {
        yThxnXfGbim = TLBCrzegFd;
    }

    if (HVVXgkxWHdvbo <= -1191393834) {
        for (int VcrlsNZgxFkvmao = 1067641768; VcrlsNZgxFkvmao > 0; VcrlsNZgxFkvmao--) {
            NFWHVYKpYNwm *= KtBYXOfpnhD;
        }
    }

    for (int NCORuLityzLrEkaH = 410560318; NCORuLityzLrEkaH > 0; NCORuLityzLrEkaH--) {
        ilNcuXF = xOSHsa;
        HVVXgkxWHdvbo -= blyTuOs;
        hBXKlkMclBbV = hBXKlkMclBbV;
    }

    for (int hptUVeELtseX = 733617927; hptUVeELtseX > 0; hptUVeELtseX--) {
        hBXKlkMclBbV += hBXKlkMclBbV;
        lgoJSHqQnAjmOc += lgoJSHqQnAjmOc;
        KtBYXOfpnhD *= NFWHVYKpYNwm;
    }

    for (int ayizMSbVdqve = 147167575; ayizMSbVdqve > 0; ayizMSbVdqve--) {
        hBXKlkMclBbV = hBXKlkMclBbV;
    }

    return blyTuOs;
}

bool ENnaUOnGjJQvE::nfTvSdipVXrYm(double RpFkDLjbGOxTJrk, int ECNXvmpuFatmYSFM)
{
    double VQEXquCFvkQbCt = -396095.4262741896;
    string lYzsXulL = string("MmEdnbOlgcCPRXGtVQXvRvOOkeVghpTDmJMGHmBrBSgOwqFPIqjzQgARAYWqCIsrwiFCcQmzoUexyhXMMCWvpzFRC");
    int yyaMqE = 2044009660;
    double lsAyK = -694172.5015673722;
    int tJgYl = -1814812459;
    bool YshgnnZOLVnmLETo = true;

    return YshgnnZOLVnmLETo;
}

ENnaUOnGjJQvE::ENnaUOnGjJQvE()
{
    this->yPIedXhqF();
    this->MGbswZVWMT(false, -1523754177, false);
    this->FUGAhVM(-469956572, -1343239077, string("qZwitzLlkBFeeyAbtgjHrpdSsXBXnnzcxrhHYFxShSiAlRxGBkmtTBnLNTilQeipLnlvPQ"), false);
    this->gKPdzTXhNsAztrFA();
    this->LFmmrDl(973580.7017769187, string("ssLimFNOrJSyamnBIqHoHzQeuIdWWIfDDvoGfGFzhHHNXugoBtWjdQEsLTotefzJTtqqznRUmoqbFnkoFbGEwoobKrSE"), -1534120233, -74193.5456777673, -956995.7945510591);
    this->JTnsRaegLgJbUb(-468833.6457054906, true, string("dPZvBcfrBSHoVrUUPdwkrVARwhHEhP"), 872112907);
    this->gobGCFaRDmdc(string("NDsoVQZoIRAmVgCHLijGgyVuptQCpwsmyvnqSHMLGyeGJstGJfoJZwbYBIUIiaSd"), -531258062, -1007111.5152871207, true, 320307181);
    this->FyBUqgdofZhWlEcV(-316796.20811450103);
    this->aiFQMxTHZBbQV(string("zZkNErRUkUOUeGZcIsGmkmuiZFAhzuzr"));
    this->BktcrNSMp(669813.1085531478, string("BvaLWObwRbwyEo"), string("UQCWgXVXUzMpBVoLkiNsxxonLmPErArvYmeEhruPpHwddCuaTotrVyAZnlTMIhBMyzBQqpiiHZXabyiJUnHTaFYsBPpbMqZfrFopnrIcgahGnmCFIMzIvavIVdpcjOOwDzfdaxCUbckRXyllKjxnElBaOirfPWGwCTKTCZGiRVIpSaGewcBSXXQRvjopIkAXlrBXirHnZxhiNhXLXdphCYN"), string("BejybwlQXvmdlpPEshG"));
    this->BZgWZaJGIFusm(-794249.02575929, string("zZOnL"), 972767.3169501049, 681110933);
    this->nfTvSdipVXrYm(342425.0956147822, -1159016250);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jwjjPKJgL
{
public:
    string EPCSJkTbYjC;
    bool viijzRyVTwIBLryO;
    int kxIfNRnOyXmt;

    jwjjPKJgL();
    int GVUXUnPlcrjEj();
    string eKUNELX(bool irWCL, bool EhJEDFwdoj, int bwOSaNX);
    int FVFxSMAPgvC();
    double dWips(double docoWjwbdzOLWmQQ, string EyMViQkOIRAyqoyd, int cZFAh, string xtmqbNF);
protected:
    bool YZerxKehoCwak;
    double quyvLIRPVsSBrJ;
    bool msmQwpMjzxue;

    string FJpbQk(double MxFlzXcoiMz, int bbDeyie, double eIbPyl);
private:
    double TrcXbixxgdtdASF;
    bool rdQjTatzdQQSXjX;
    string cVAEAIyY;

    void yeHzx(bool VgbvzSzHS, int sDfQccxwfYXbwvD, string eRiinQx, string CJGCpSxdS, string eWLYopbuELYnkT);
    int stdgRgCCCSzEbqn(bool JdQMdE, int wCuBviQfi, double SbBUvBCReEVgF, string XvkBxPrkUL);
};

int jwjjPKJgL::GVUXUnPlcrjEj()
{
    double qhwnGN = 469403.34375224315;
    bool UfEvmTlDsFXRVBzg = true;
    bool bdTLKTGVAPXzXy = true;
    int anqhpYwwltSS = -1039284553;
    bool BLeohwztMwLVAJfN = false;

    for (int IZgqVsiFxk = 1923289447; IZgqVsiFxk > 0; IZgqVsiFxk--) {
        UfEvmTlDsFXRVBzg = bdTLKTGVAPXzXy;
        UfEvmTlDsFXRVBzg = BLeohwztMwLVAJfN;
        bdTLKTGVAPXzXy = UfEvmTlDsFXRVBzg;
        BLeohwztMwLVAJfN = ! BLeohwztMwLVAJfN;
        qhwnGN *= qhwnGN;
    }

    for (int dkbFyEmPA = 1529660031; dkbFyEmPA > 0; dkbFyEmPA--) {
        UfEvmTlDsFXRVBzg = bdTLKTGVAPXzXy;
        bdTLKTGVAPXzXy = BLeohwztMwLVAJfN;
        qhwnGN *= qhwnGN;
    }

    for (int JcNOowtRDqTWYG = 1139359666; JcNOowtRDqTWYG > 0; JcNOowtRDqTWYG--) {
        continue;
    }

    return anqhpYwwltSS;
}

string jwjjPKJgL::eKUNELX(bool irWCL, bool EhJEDFwdoj, int bwOSaNX)
{
    bool WcsHXWVgTGXMMHv = false;
    string AbLGTpoqgKlogW = string("gzjuglmeiyFLAepkiEIaIkXbalMSHzFawTyJviIMkcdiJQndTlytUvvbqSTspoMALrITTJKEHmQJfjSBuQsvPryfeWCC");
    string lAPvL = string("haryScugrCloDAtUVdUVbNQAwTnJlCqYxTKJkEXOVwrwdjdEofrJpNXHOAysRFaVsqSppqAEmJVIHnHFhvAkeSKAHpusrzdpZdmsZHVYcVGZjVZTwesDALcyAnxHlPcMhv");
    string sVytxrtRbPp = string("bmljrqvQAQcHUUmukIVbQHOxVEgHPxInoOIRSQjZHwGDqolnrIYSeGlqFjXVwreTcyMJOwQhjgpDogdaaRavrXgkPKLqWqNzhBBWcnlWivbOOZbKOjNfYhWnFyIHqhSTTOYRIxpIcETRcjSZsIBHGcgwJfbyRlqaXSNLscclRLWsWSduvHfdJYm");
    int yDRxkdd = -1815923243;
    int hjyfDbbthwEERtYC = 1735249428;
    int elZZGWmaGn = -1907755323;
    bool YykzzLujoXkvMkgw = false;
    int tgtgWJ = -798081615;

    for (int cLrnbbvblFkmu = 1884897127; cLrnbbvblFkmu > 0; cLrnbbvblFkmu--) {
        continue;
    }

    for (int YWASyBhvEbEOmo = 110910801; YWASyBhvEbEOmo > 0; YWASyBhvEbEOmo--) {
        elZZGWmaGn += tgtgWJ;
        YykzzLujoXkvMkgw = YykzzLujoXkvMkgw;
        tgtgWJ += bwOSaNX;
    }

    if (tgtgWJ < 1735249428) {
        for (int SUKDwIQRs = 111581304; SUKDwIQRs > 0; SUKDwIQRs--) {
            continue;
        }
    }

    return sVytxrtRbPp;
}

int jwjjPKJgL::FVFxSMAPgvC()
{
    int RITAaWHD = 707506742;
    double YOnSbKoU = 247568.17915388284;
    bool GWKmYUuZPANRU = true;

    for (int eUeCkSQvQ = 1654113753; eUeCkSQvQ > 0; eUeCkSQvQ--) {
        RITAaWHD *= RITAaWHD;
        YOnSbKoU = YOnSbKoU;
        GWKmYUuZPANRU = ! GWKmYUuZPANRU;
    }

    return RITAaWHD;
}

double jwjjPKJgL::dWips(double docoWjwbdzOLWmQQ, string EyMViQkOIRAyqoyd, int cZFAh, string xtmqbNF)
{
    string eDHLp = string("pYjJvwukQEKcnUUdNdCAFtWKTTvMuikoFXatnjZqEMIHLSkpExSyzoAWEXRkKTRfJiLbwOigOkYWMuJuVKsz");
    bool hqpDkAW = true;

    for (int hHrmQjBMzOxteL = 1248850931; hHrmQjBMzOxteL > 0; hHrmQjBMzOxteL--) {
        xtmqbNF = xtmqbNF;
    }

    if (eDHLp > string("pYjJvwukQEKcnUUdNdCAFtWKTTvMuikoFXatnjZqEMIHLSkpExSyzoAWEXRkKTRfJiLbwOigOkYWMuJuVKsz")) {
        for (int kcWHjtHxJySU = 1079703510; kcWHjtHxJySU > 0; kcWHjtHxJySU--) {
            EyMViQkOIRAyqoyd = EyMViQkOIRAyqoyd;
        }
    }

    for (int mhkfUFoWqqyxEYS = 1820457574; mhkfUFoWqqyxEYS > 0; mhkfUFoWqqyxEYS--) {
        xtmqbNF += eDHLp;
    }

    if (xtmqbNF <= string("pYjJvwukQEKcnUUdNdCAFtWKTTvMuikoFXatnjZqEMIHLSkpExSyzoAWEXRkKTRfJiLbwOigOkYWMuJuVKsz")) {
        for (int afBcgiBXuQynif = 327207611; afBcgiBXuQynif > 0; afBcgiBXuQynif--) {
            eDHLp += EyMViQkOIRAyqoyd;
            eDHLp = eDHLp;
        }
    }

    for (int kubOVXV = 1035321147; kubOVXV > 0; kubOVXV--) {
        eDHLp = xtmqbNF;
    }

    if (xtmqbNF <= string("TrKVJDRwGkEjqPErvkoLeNCRnjX")) {
        for (int DOuAvNAinxF = 2059440100; DOuAvNAinxF > 0; DOuAvNAinxF--) {
            eDHLp += eDHLp;
        }
    }

    return docoWjwbdzOLWmQQ;
}

string jwjjPKJgL::FJpbQk(double MxFlzXcoiMz, int bbDeyie, double eIbPyl)
{
    int eWcDmeXGP = 644538510;
    bool prLlgJqmwfkoTsJ = true;
    int tXaRXNETtyLw = -1015212045;
    int WiChNzGWYM = 366545359;
    string CIhZqGVWCbQyDRL = string("qCEowBSLhFUCpOGASekxBRDlBdPbrSNMPqLBrVZTlXLjdcSygOSiSGxcwCYWhvpDn");

    for (int NyeKKhgvucZ = 2134802983; NyeKKhgvucZ > 0; NyeKKhgvucZ--) {
        WiChNzGWYM /= bbDeyie;
        WiChNzGWYM /= eWcDmeXGP;
    }

    return CIhZqGVWCbQyDRL;
}

void jwjjPKJgL::yeHzx(bool VgbvzSzHS, int sDfQccxwfYXbwvD, string eRiinQx, string CJGCpSxdS, string eWLYopbuELYnkT)
{
    int MAAIRyWvPTVaj = 165960407;
    int JKrBOzIHQ = 121567574;
    double YoVFovomXkAWAt = -455506.60339741467;
    string xSzVAJI = string("dVumfAYquidFWBfmZjGluBWJMJQjxHmHFQEuZrhueZCEQTiIkeHbCITxAfsUeKcOlwLPqcviggKqMxniclpWcSVRJloxOBqXCjVcIxnvCvOtekCJCCQhiwfZuIuXUgNEmEpmslNanbqcAKzcDMyXnUHgpaWCdfKXvKdaxpJDerACwCfJCDhbtTMtFAmpssbRBBiTHbIKtgXPfNjYboRWlaAZn");
    int lukzxGBrfsXuYXE = -1335958070;
    bool YutEiwV = false;
    int DnBcgVwf = -1136064989;
    double ttDokbwYcAOEniH = 522611.9355274337;

    for (int rOKUN = 1743969545; rOKUN > 0; rOKUN--) {
        continue;
    }

    for (int EIdpgfl = 126712160; EIdpgfl > 0; EIdpgfl--) {
        eRiinQx += xSzVAJI;
    }

    if (DnBcgVwf >= -1335958070) {
        for (int JsRLVdLnyA = 475869422; JsRLVdLnyA > 0; JsRLVdLnyA--) {
            continue;
        }
    }
}

int jwjjPKJgL::stdgRgCCCSzEbqn(bool JdQMdE, int wCuBviQfi, double SbBUvBCReEVgF, string XvkBxPrkUL)
{
    bool xBQhuqou = false;
    bool PfzTuDisJAMwcfy = false;
    int kpeFPqaLC = 448335516;
    bool exKWKIhlnBiCpAlR = false;
    int Oxvowl = 1531657864;
    string CAZWDPyJvqPWic = string("uiEhOiqPvCThUoenyWzwUECZAbRFZNcSuGecKUKyOSVMFRXFbzwBvqbodBanBeQKmHfrNQRcepQjfYFzjMHyrIeonckbkAkcONliXrxuZaGtmFXVgOGFaWFsEaTRpAPXdEgjCpcWwAsAuMvTepEAtZpdLJRwtjWECdxyHgvZpfmCqHGZEjHzIJlcbhyEKJihZqQo");
    bool wGrOXo = true;
    string pEejtnrvKQFocktT = string("nqNJeWBVnRKhCJtEdKaqKvzrflRioCuyfIdJWEljDYJqYlSWkZlhjijRlLsGvIrGDHNIECMqYhkHpTMmdEWIAmwabAPaRDLquIvMjVPzXqLdiGBPPBVJGkFGLOMuGvfjcFUcxZLwyYpdwZItgtAerCQxIRrZWrniGRyuYkTxDjFXqjQoBxfVAmeuJcucPYuJGIgZPGvkwSBzlMngMXcWodzGiPNXzYcKpAjcWlWCC");
    string gyLVfhNhKCDLwm = string("TOatJvtiybyUlrHoiTNhCeOTscRIODmcASrskYXwPcWqrhbiYJFnOVLXmmgnYvtAyZYErWPRgKsuaoyIokEQqTQjczvzGdfVHmJptiLYdGvhWeFxSXfYBVvavcvyGUxvOISxey");

    for (int VnWGfYIla = 842212099; VnWGfYIla > 0; VnWGfYIla--) {
        CAZWDPyJvqPWic += XvkBxPrkUL;
        PfzTuDisJAMwcfy = PfzTuDisJAMwcfy;
        PfzTuDisJAMwcfy = ! exKWKIhlnBiCpAlR;
    }

    for (int qBexLLOfbe = 1516690216; qBexLLOfbe > 0; qBexLLOfbe--) {
        gyLVfhNhKCDLwm += gyLVfhNhKCDLwm;
    }

    for (int nkedstbC = 325541087; nkedstbC > 0; nkedstbC--) {
        exKWKIhlnBiCpAlR = PfzTuDisJAMwcfy;
    }

    return Oxvowl;
}

jwjjPKJgL::jwjjPKJgL()
{
    this->GVUXUnPlcrjEj();
    this->eKUNELX(false, true, -1185930248);
    this->FVFxSMAPgvC();
    this->dWips(824747.4136040879, string("TrKVJDRwGkEjqPErvkoLeNCRnjX"), 2114385746, string("rJkdmUQqRNiXsoxoTHwdoytpluicufSAxNvIkwJkiNmTmoqBBKSjCnfsEGNLSCmQfgayasknBjEvDXwoGWseDyEVmbMRyFweiNfDGvlqjvVTVnOXuJ"));
    this->FJpbQk(-805693.4354874553, -1946625998, 499976.3252960804);
    this->yeHzx(false, -1449046137, string("jalvtRgJMFilFqtNwYwVEsTtXHuJZtMvsLowoelpfLxkkqIFYXsqurZeYxR"), string("WzzbvBwxUiKxxGUECDgfcLfIOLNhtexPwrQkKZCMlubEsobWQVSQoswZCnDTMVFsFvedkrcVSCYbCvAkzPdEABFMWzuUlnbYMShOQJgMETGAwTPvEgzUozeAXbuJGxsHYqzXyVONYYwIcEMfiAxyPRYABHZQWmZWERPFGV"), string("ciQyZDIicgiXJxjNBZrIkKrTOjGnWXqUevnFSbwCMNDifGNVvMSzXdfRFYoVmTisbR"));
    this->stdgRgCCCSzEbqn(false, -1961332922, -505421.81877993175, string("GAEZhSFwPHpOAIoMOgFXeCAogmUQPFquSMoUIWNyCGYiGngjxzOqJiSStuvHgnMCllOrZYPAZNUARBplAjZfXTPgDdtIQiehZHJdBwPsYOjTVALdFoWahscwkAaDmKeEvdKeItytEBvsslrgjCPrxUKb"));
}
