// Wrapper to use FreeType (instead of stb_truetype) for Dear ImGui
// Get latest version at https://github.com/ocornut/imgui/tree/master/misc/freetype
// Original code by @vuhdo (Aleksei Skriabin). Improvements by @mikesart. Maintained and v0.60+ by @ocornut.

// Changelog:
// - v0.50: (2017/08/16) imported from https://github.com/Vuhdo/imgui_freetype into http://www.github.com/ocornut/imgui_club, updated for latest changes in ImFontAtlas, minor tweaks.
// - v0.51: (2017/08/26) cleanup, optimizations, support for ImFontConfig::RasterizerFlags, ImFontConfig::RasterizerMultiply.
// - v0.52: (2017/09/26) fixes for imgui internal changes.
// - v0.53: (2017/10/22) minor inconsequential change to match change in master (removed an unnecessary statement).
// - v0.54: (2018/01/22) fix for addition of ImFontAtlas::TexUvscale member.
// - v0.55: (2018/02/04) moved to main imgui repository (away from http://www.github.com/ocornut/imgui_club)
// - v0.56: (2018/06/08) added support for ImFontConfig::GlyphMinAdvanceX, GlyphMaxAdvanceX.
// - v0.60: (2019/01/10) re-factored to match big update in STB builder. fixed texture height waste. fixed redundant glyphs when merging. support for glyph padding.
// - v0.61: (2019/01/15) added support for imgui allocators + added FreeType only override function SetAllocatorFunctions().
// - v0.62: (2019/02/09) added RasterizerFlags::Monochrome flag to disable font anti-aliasing (combine with ::MonoHinting for best results!)

// Gamma Correct Blending:
//  FreeType assumes blending in linear space rather than gamma space.
//  See https://www.freetype.org/freetype2/docs/reference/ft2-base_interface.html#FT_Render_Glyph
//  For correct results you need to be using sRGB and convert to linear space in the pixel shader output.
//  The default imgui styles will be impacted by this change (alpha values will need tweaking).

// FIXME: cfg.OversampleH, OversampleV are not supported (but perhaps not so necessary with this rasterizer).

#include "imgui_freetype.h"
#include "imgui_internal.h"     // ImMin,ImMax,ImFontAtlasBuild*,
#include <stdint.h>
#include <ft2build.h>
#include FT_FREETYPE_H          // <freetype/freetype.h>
#include FT_MODULE_H            // <freetype/ftmodapi.h>
#include FT_GLYPH_H             // <freetype/ftglyph.h>
#include FT_SYNTHESIS_H         // <freetype/ftsynth.h>

#ifdef _MSC_VER
#pragma warning (disable: 4505) // unreferenced local function has been removed (stb stuff)
#endif

#if defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wpragmas"                  // warning: unknown option after '#pragma GCC diagnostic' kind
#pragma GCC diagnostic ignored "-Wunused-function"          // warning: 'xxxx' defined but not used
#endif

namespace
{
    // Glyph metrics:
    // --------------
    //
    //                       xmin                     xmax
    //                        |                         |
    //                        |<-------- width -------->|
    //                        |                         |
    //              |         +-------------------------+----------------- ymax
    //              |         |    ggggggggg   ggggg    |     ^        ^
    //              |         |   g:::::::::ggg::::g    |     |        |
    //              |         |  g:::::::::::::::::g    |     |        |
    //              |         | g::::::ggggg::::::gg    |     |        |
    //              |         | g:::::g     g:::::g     |     |        |
    //    offsetX  -|-------->| g:::::g     g:::::g     |  offsetY     |
    //              |         | g:::::g     g:::::g     |     |        |
    //              |         | g::::::g    g:::::g     |     |        |
    //              |         | g:::::::ggggg:::::g     |     |        |
    //              |         |  g::::::::::::::::g     |     |      height
    //              |         |   gg::::::::::::::g     |     |        |
    //  baseline ---*---------|---- gggggggg::::::g-----*--------      |
    //            / |         |             g:::::g     |              |
    //     origin   |         | gggggg      g:::::g     |              |
    //              |         | g:::::gg   gg:::::g     |              |
    //              |         |  g::::::ggg:::::::g     |              |
    //              |         |   gg:::::::::::::g      |              |
    //              |         |     ggg::::::ggg        |              |
    //              |         |         gggggg          |              v
    //              |         +-------------------------+----------------- ymin
    //              |                                   |
    //              |------------- advanceX ----------->|

    /// A structure that describe a glyph.
    struct GlyphInfo
    {
        int         Width;              // Glyph's width in pixels.
        int         Height;             // Glyph's height in pixels.
        FT_Int      OffsetX;            // The distance from the origin ("pen position") to the left of the glyph.
        FT_Int      OffsetY;            // The distance from the origin to the top of the glyph. This is usually a value < 0.
        float       AdvanceX;           // The distance from the origin to the origin of the next glyph. This is usually a value > 0.
    };

    // Font parameters and metrics.
    struct FontInfo
    {
        uint32_t    PixelHeight;        // Size this font was generated with.
        float       Ascender;           // The pixel extents above the baseline in pixels (typically positive).
        float       Descender;          // The extents below the baseline in pixels (typically negative).
        float       LineSpacing;        // The baseline-to-baseline distance. Note that it usually is larger than the sum of the ascender and descender taken as absolute values. There is also no guarantee that no glyphs extend above or below subsequent baselines when using this distance. Think of it as a value the designer of the font finds appropriate.
        float       LineGap;            // The spacing in pixels between one row's descent and the next row's ascent.
        float       MaxAdvanceWidth;    // This field gives the maximum horizontal cursor advance for all glyphs in the font.
    };

    // FreeType glyph rasterizer.
    // NB: No ctor/dtor, explicitly call Init()/Shutdown()
    struct FreeTypeFont
    {
        bool                    InitFont(FT_Library ft_library, const ImFontConfig& cfg, unsigned int extra_user_flags); // Initialize from an external data buffer. Doesn't copy data, and you must ensure it stays valid up to this object lifetime.
        void                    CloseFont();
        void                    SetPixelHeight(int pixel_height); // Change font pixel size. All following calls to RasterizeGlyph() will use this size
        const FT_Glyph_Metrics* LoadGlyph(uint32_t in_codepoint);
        const FT_Bitmap*        RenderGlyphAndGetInfo(GlyphInfo* out_glyph_info);
        void                    BlitGlyph(const FT_Bitmap* ft_bitmap, uint8_t* dst, uint32_t dst_pitch, unsigned char* multiply_table = NULL);
        ~FreeTypeFont()         { CloseFont(); }

        // [Internals]
        FontInfo        Info;               // Font descriptor of the current font.
        FT_Face         Face;
        unsigned int    UserFlags;          // = ImFontConfig::RasterizerFlags
        FT_Int32        LoadFlags;
        FT_Render_Mode  RenderMode;
    };

    // From SDL_ttf: Handy routines for converting from fixed point
    #define FT_CEIL(X)  (((X + 63) & -64) / 64)

    bool FreeTypeFont::InitFont(FT_Library ft_library, const ImFontConfig& cfg, unsigned int extra_user_flags)
    {
        FT_Error error = FT_New_Memory_Face(ft_library, (uint8_t*)cfg.FontData, (uint32_t)cfg.FontDataSize, (uint32_t)cfg.FontNo, &Face);
        if (error != 0)
            return false;
        error = FT_Select_Charmap(Face, FT_ENCODING_UNICODE);
        if (error != 0)
            return false;

        memset(&Info, 0, sizeof(Info));
        SetPixelHeight((uint32_t)cfg.SizePixels);

        // Convert to FreeType flags (NB: Bold and Oblique are processed separately)
        UserFlags = cfg.RasterizerFlags | extra_user_flags;
        LoadFlags = FT_LOAD_NO_BITMAP;
        if (UserFlags & ImGuiFreeType::NoHinting)
            LoadFlags |= FT_LOAD_NO_HINTING;
        if (UserFlags & ImGuiFreeType::NoAutoHint)
            LoadFlags |= FT_LOAD_NO_AUTOHINT;
        if (UserFlags & ImGuiFreeType::ForceAutoHint)
            LoadFlags |= FT_LOAD_FORCE_AUTOHINT;
        if (UserFlags & ImGuiFreeType::LightHinting)
            LoadFlags |= FT_LOAD_TARGET_LIGHT;
        else if (UserFlags & ImGuiFreeType::MonoHinting)
            LoadFlags |= FT_LOAD_TARGET_MONO;
        else
            LoadFlags |= FT_LOAD_TARGET_NORMAL;

        if (UserFlags & ImGuiFreeType::Monochrome)
            RenderMode = FT_RENDER_MODE_MONO;
        else
            RenderMode = FT_RENDER_MODE_NORMAL;

        return true;
    }

    void FreeTypeFont::CloseFont()
    {
        if (Face)
        {
            FT_Done_Face(Face);
            Face = NULL;
        }
    }

    void FreeTypeFont::SetPixelHeight(int pixel_height)
    {
        // Vuhdo: I'm not sure how to deal with font sizes properly. As far as I understand, currently ImGui assumes that the 'pixel_height'
        // is a maximum height of an any given glyph, i.e. it's the sum of font's ascender and descender. Seems strange to me.
        // NB: FT_Set_Pixel_Sizes() doesn't seem to get us the same result.
        FT_Size_RequestRec req;
        req.type = FT_SIZE_REQUEST_TYPE_REAL_DIM;
        req.width = 0;
        req.height = (uint32_t)pixel_height * 64;
        req.horiResolution = 0;
        req.vertResolution = 0;
        FT_Request_Size(Face, &req);

        // Update font info
        FT_Size_Metrics metrics = Face->size->metrics;
        Info.PixelHeight = (uint32_t)pixel_height;
        Info.Ascender = (float)FT_CEIL(metrics.ascender);
        Info.Descender = (float)FT_CEIL(metrics.descender);
        Info.LineSpacing = (float)FT_CEIL(metrics.height);
        Info.LineGap = (float)FT_CEIL(metrics.height - metrics.ascender + metrics.descender);
        Info.MaxAdvanceWidth = (float)FT_CEIL(metrics.max_advance);
    }

    const FT_Glyph_Metrics* FreeTypeFont::LoadGlyph(uint32_t codepoint)
    {
        uint32_t glyph_index = FT_Get_Char_Index(Face, codepoint);
        if (glyph_index == 0)
            return NULL;
        FT_Error error = FT_Load_Glyph(Face, glyph_index, LoadFlags);
        if (error)
            return NULL;

        // Need an outline for this to work
        FT_GlyphSlot slot = Face->glyph;
        IM_ASSERT(slot->format == FT_GLYPH_FORMAT_OUTLINE);

        // Apply convenience transform (this is not picking from real "Bold"/"Italic" fonts! Merely applying FreeType helper transform. Oblique == Slanting)
        if (UserFlags & ImGuiFreeType::Bold)
            FT_GlyphSlot_Embolden(slot);
        if (UserFlags & ImGuiFreeType::Oblique)
        {
            FT_GlyphSlot_Oblique(slot);
            //FT_BBox bbox;
            //FT_Outline_Get_BBox(&slot->outline, &bbox);
            //slot->metrics.width = bbox.xMax - bbox.xMin;
            //slot->metrics.height = bbox.yMax - bbox.yMin;
        }

        return &slot->metrics;
    }

    const FT_Bitmap* FreeTypeFont::RenderGlyphAndGetInfo(GlyphInfo* out_glyph_info)
    {
        FT_GlyphSlot slot = Face->glyph;
        FT_Error error = FT_Render_Glyph(slot, RenderMode);
        if (error != 0)
            return NULL;

        FT_Bitmap* ft_bitmap = &Face->glyph->bitmap;
        out_glyph_info->Width = (int)ft_bitmap->width;
        out_glyph_info->Height = (int)ft_bitmap->rows;
        out_glyph_info->OffsetX = Face->glyph->bitmap_left;
        out_glyph_info->OffsetY = -Face->glyph->bitmap_top;
        out_glyph_info->AdvanceX = (float)FT_CEIL(slot->advance.x);

        return ft_bitmap;
    }

    void FreeTypeFont::BlitGlyph(const FT_Bitmap* ft_bitmap, uint8_t* dst, uint32_t dst_pitch, unsigned char* multiply_table)
    {
        IM_ASSERT(ft_bitmap != NULL);
        const uint32_t w = ft_bitmap->width;
        const uint32_t h = ft_bitmap->rows;
        const uint8_t* src = ft_bitmap->buffer;
        const uint32_t src_pitch = ft_bitmap->pitch;

        switch (ft_bitmap->pixel_mode)
        {
        case FT_PIXEL_MODE_GRAY: // Grayscale image, 1 byte per pixel.
            {
                if (multiply_table == NULL)
                {
                    for (uint32_t y = 0; y < h; y++, src += src_pitch, dst += dst_pitch)
                        memcpy(dst, src, w);
                }
                else
                {
                    for (uint32_t y = 0; y < h; y++, src += src_pitch, dst += dst_pitch)
                        for (uint32_t x = 0; x < w; x++)
                            dst[x] = multiply_table[src[x]];
                }
                break;
            }
        case FT_PIXEL_MODE_MONO: // Monochrome image, 1 bit per pixel. The bits in each byte are ordered from MSB to LSB.
            {
                uint8_t color0 = multiply_table ? multiply_table[0] : 0;
                uint8_t color1 = multiply_table ? multiply_table[255] : 255;
                for (uint32_t y = 0; y < h; y++, src += src_pitch, dst += dst_pitch)
                {
                    uint8_t bits = 0;
                    const uint8_t* bits_ptr = src;
                    for (uint32_t x = 0; x < w; x++, bits <<= 1)
                    {
                        if ((x & 7) == 0)
                            bits = *bits_ptr++;
                        dst[x] = (bits & 0x80) ? color1 : color0;
                    }
                }
                break;
            }
        default:
            IM_ASSERT(0 && "FreeTypeFont::BlitGlyph(): Unknown bitmap pixel mode!");
        }
    }
}

#ifndef STB_RECT_PACK_IMPLEMENTATION        // in case the user already have an implementation in the _same_ compilation unit (e.g. unity builds)
#define STBRP_ASSERT(x)    IM_ASSERT(x)
#define STBRP_STATIC
#define STB_RECT_PACK_IMPLEMENTATION
#include "imstb_rectpack.h"
#endif

struct ImFontBuildSrcGlyphFT
{
    GlyphInfo           Info;
    uint32_t            Codepoint;
    unsigned char*      BitmapData;         // Point within one of the dst_tmp_bitmap_buffers[] array
};

struct ImFontBuildSrcDataFT
{
    FreeTypeFont        Font;
    stbrp_rect*         Rects;              // Rectangle to pack. We first fill in their size and the packer will give us their position.
    const ImWchar*      SrcRanges;          // Ranges as requested by user (user is allowed to request too much, e.g. 0x0020..0xFFFF)
    int                 DstIndex;           // Index into atlas->Fonts[] and dst_tmp_array[]
    int                 GlyphsHighest;      // Highest requested codepoint
    int                 GlyphsCount;        // Glyph count (excluding missing glyphs and glyphs already set by an earlier source font)
    ImBoolVector        GlyphsSet;          // Glyph bit map (random access, 1-bit per codepoint. This will be a maximum of 8KB)
    ImVector<ImFontBuildSrcGlyphFT>   GlyphsList;
};

// Temporary data for one destination ImFont* (multiple source fonts can be merged into one destination ImFont)
struct ImFontBuildDstDataFT
{
    int                 SrcCount;           // Number of source fonts targeting this destination font.
    int                 GlyphsHighest;
    int                 GlyphsCount;
    ImBoolVector        GlyphsSet;          // This is used to resolve collision when multiple sources are merged into a same destination font.
};

bool ImFontAtlasBuildWithFreeType(FT_Library ft_library, ImFontAtlas* atlas, unsigned int extra_flags)
{

    IM_ASSERT(atlas->ConfigData.Size > 0);

    ImFontAtlasBuildRegisterDefaultCustomRects(atlas);

    // Clear atlas
    atlas->TexID = (ImTextureID)NULL;
    atlas->TexWidth = atlas->TexHeight = 0;
    atlas->TexUvScale = ImVec2(0.0f, 0.0f);
    atlas->TexUvWhitePixel = ImVec2(0.0f, 0.0f);
    atlas->ClearTexData();

    // Temporary storage for building
    ImVector<ImFontBuildSrcDataFT> src_tmp_array;
    ImVector<ImFontBuildDstDataFT> dst_tmp_array;
    src_tmp_array.resize(atlas->ConfigData.Size);
    dst_tmp_array.resize(atlas->Fonts.Size);
    memset(src_tmp_array.Data, 0, (size_t)src_tmp_array.size_in_bytes());
    memset(dst_tmp_array.Data, 0, (size_t)dst_tmp_array.size_in_bytes());

    // 1. Initialize font loading structure, check font data validity
    for (int src_i = 0; src_i < atlas->ConfigData.Size; src_i++)
    {
        ImFontBuildSrcDataFT& src_tmp = src_tmp_array[src_i];
        ImFontConfig& cfg = atlas->ConfigData[src_i];
        FreeTypeFont& font_face = src_tmp.Font;
        IM_ASSERT(cfg.DstFont && (!cfg.DstFont->IsLoaded() || cfg.DstFont->ContainerAtlas == atlas));

        // Find index from cfg.DstFont (we allow the user to set cfg.DstFont. Also it makes casual debugging nicer than when storing indices)
        src_tmp.DstIndex = -1;
        for (int output_i = 0; output_i < atlas->Fonts.Size && src_tmp.DstIndex == -1; output_i++)
            if (cfg.DstFont == atlas->Fonts[output_i])
                src_tmp.DstIndex = output_i;
        IM_ASSERT(src_tmp.DstIndex != -1); // cfg.DstFont not pointing within atlas->Fonts[] array?
        if (src_tmp.DstIndex == -1)
            return false;

        // Load font
        if (!font_face.InitFont(ft_library, cfg, extra_flags))
            return false;

        // Measure highest codepoints
        ImFontBuildDstDataFT& dst_tmp = dst_tmp_array[src_tmp.DstIndex];
        src_tmp.SrcRanges = cfg.GlyphRanges ? cfg.GlyphRanges : atlas->GetGlyphRangesDefault();
        for (const ImWchar* src_range = src_tmp.SrcRanges; src_range[0] && src_range[1]; src_range += 2)
            src_tmp.GlyphsHighest = ImMax(src_tmp.GlyphsHighest, (int)src_range[1]);
        dst_tmp.SrcCount++;
        dst_tmp.GlyphsHighest = ImMax(dst_tmp.GlyphsHighest, src_tmp.GlyphsHighest);
    }

    // 2. For every requested codepoint, check for their presence in the font data, and handle redundancy or overlaps between source fonts to avoid unused glyphs.
    int total_glyphs_count = 0;
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcDataFT& src_tmp = src_tmp_array[src_i];
        ImFontBuildDstDataFT& dst_tmp = dst_tmp_array[src_tmp.DstIndex];
        src_tmp.GlyphsSet.Resize(src_tmp.GlyphsHighest + 1);
        if (dst_tmp.GlyphsSet.Storage.empty())
            dst_tmp.GlyphsSet.Resize(dst_tmp.GlyphsHighest + 1);

        for (const ImWchar* src_range = src_tmp.SrcRanges; src_range[0] && src_range[1]; src_range += 2)
            for (int codepoint = src_range[0]; codepoint <= src_range[1]; codepoint++)
            {
                if (dst_tmp.GlyphsSet.GetBit(codepoint))    // Don't overwrite existing glyphs. We could make this an option (e.g. MergeOverwrite)
                    continue;
                uint32_t glyph_index = FT_Get_Char_Index(src_tmp.Font.Face, codepoint); // It is actually in the font? (FIXME-OPT: We are not storing the glyph_index..)
                if (glyph_index == 0)
                    continue;

                // Add to avail set/counters
                src_tmp.GlyphsCount++;
                dst_tmp.GlyphsCount++;
                src_tmp.GlyphsSet.SetBit(codepoint, true);
                dst_tmp.GlyphsSet.SetBit(codepoint, true);
                total_glyphs_count++;
            }
    }

    // 3. Unpack our bit map into a flat list (we now have all the Unicode points that we know are requested _and_ available _and_ not overlapping another)
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcDataFT& src_tmp = src_tmp_array[src_i];
        src_tmp.GlyphsList.reserve(src_tmp.GlyphsCount);

        IM_ASSERT(sizeof(src_tmp.GlyphsSet.Storage.Data[0]) == sizeof(int));
        const int* it_begin = src_tmp.GlyphsSet.Storage.begin();
        const int* it_end = src_tmp.GlyphsSet.Storage.end();
        for (const int* it = it_begin; it < it_end; it++)
            if (int entries_32 = *it)
                for (int bit_n = 0; bit_n < 32; bit_n++)
                    if (entries_32 & (1 << bit_n))
                    {
                        ImFontBuildSrcGlyphFT src_glyph;
                        memset(&src_glyph, 0, sizeof(src_glyph));
                        src_glyph.Codepoint = (ImWchar)(((it - it_begin) << 5) + bit_n);
                        //src_glyph.GlyphIndex = 0; // FIXME-OPT: We had this info in the previous step and lost it..
                        src_tmp.GlyphsList.push_back(src_glyph);
                    }
        src_tmp.GlyphsSet.Clear();
        IM_ASSERT(src_tmp.GlyphsList.Size == src_tmp.GlyphsCount);
    }
    for (int dst_i = 0; dst_i < dst_tmp_array.Size; dst_i++)
        dst_tmp_array[dst_i].GlyphsSet.Clear();
    dst_tmp_array.clear();

    // Allocate packing character data and flag packed characters buffer as non-packed (x0=y0=x1=y1=0)
    // (We technically don't need to zero-clear buf_rects, but let's do it for the sake of sanity)
    ImVector<stbrp_rect> buf_rects;
    buf_rects.resize(total_glyphs_count);
    memset(buf_rects.Data, 0, (size_t)buf_rects.size_in_bytes());

    // Allocate temporary rasterization data buffers.
    // We could not find a way to retrieve accurate glyph size without rendering them.
    // (e.g. slot->metrics->width not always matching bitmap->width, especially considering the Oblique transform)
    // We allocate in chunks of 256 KB to not waste too much extra memory ahead. Hopefully users of FreeType won't find the temporary allocations.
    const int BITMAP_BUFFERS_CHUNK_SIZE = 256 * 1024;
    int buf_bitmap_current_used_bytes = 0;
    ImVector<unsigned char*> buf_bitmap_buffers;
    buf_bitmap_buffers.push_back((unsigned char*)IM_ALLOC(BITMAP_BUFFERS_CHUNK_SIZE));

    // 4. Gather glyphs sizes so we can pack them in our virtual canvas.
    // 8. Render/rasterize font characters into the texture
    int total_surface = 0;
    int buf_rects_out_n = 0;
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcDataFT& src_tmp = src_tmp_array[src_i];
        ImFontConfig& cfg = atlas->ConfigData[src_i];
        if (src_tmp.GlyphsCount == 0)
            continue;

        src_tmp.Rects = &buf_rects[buf_rects_out_n];
        buf_rects_out_n += src_tmp.GlyphsCount;

        // Compute multiply table if requested
        const bool multiply_enabled = (cfg.RasterizerMultiply != 1.0f);
        unsigned char multiply_table[256];
        if (multiply_enabled)
            ImFontAtlasBuildMultiplyCalcLookupTable(multiply_table, cfg.RasterizerMultiply);

        // Gather the sizes of all rectangles we will need to pack
        const int padding = atlas->TexGlyphPadding;
        for (int glyph_i = 0; glyph_i < src_tmp.GlyphsList.Size; glyph_i++)
        {
            ImFontBuildSrcGlyphFT& src_glyph = src_tmp.GlyphsList[glyph_i];

            const FT_Glyph_Metrics* metrics = src_tmp.Font.LoadGlyph(src_glyph.Codepoint);
            IM_ASSERT(metrics != NULL);
            if (metrics == NULL)
                continue;

            // Render glyph into a bitmap (currently held by FreeType)
            const FT_Bitmap* ft_bitmap = src_tmp.Font.RenderGlyphAndGetInfo(&src_glyph.Info);
            IM_ASSERT(ft_bitmap);

            // Allocate new temporary chunk if needed
            const int bitmap_size_in_bytes = src_glyph.Info.Width * src_glyph.Info.Height;
            if (buf_bitmap_current_used_bytes + bitmap_size_in_bytes > BITMAP_BUFFERS_CHUNK_SIZE)
            {
                buf_bitmap_current_used_bytes = 0;
                buf_bitmap_buffers.push_back((unsigned char*)IM_ALLOC(BITMAP_BUFFERS_CHUNK_SIZE));
            }

            // Blit rasterized pixels to our temporary buffer and keep a pointer to it.
            src_glyph.BitmapData = buf_bitmap_buffers.back() + buf_bitmap_current_used_bytes;
            buf_bitmap_current_used_bytes += bitmap_size_in_bytes;
            src_tmp.Font.BlitGlyph(ft_bitmap, src_glyph.BitmapData, src_glyph.Info.Width * 1, multiply_enabled ? multiply_table : NULL);

            src_tmp.Rects[glyph_i].w = (stbrp_coord)(src_glyph.Info.Width + padding);
            src_tmp.Rects[glyph_i].h = (stbrp_coord)(src_glyph.Info.Height + padding);
            total_surface += src_tmp.Rects[glyph_i].w * src_tmp.Rects[glyph_i].h;
        }
    }

    // We need a width for the skyline algorithm, any width!
    // The exact width doesn't really matter much, but some API/GPU have texture size limitations and increasing width can decrease height.
    // User can override TexDesiredWidth and TexGlyphPadding if they wish, otherwise we use a simple heuristic to select the width based on expected surface.
    const int surface_sqrt = (int)ImSqrt((float)total_surface) + 1;
    atlas->TexHeight = 0;
    if (atlas->TexDesiredWidth > 0)
        atlas->TexWidth = atlas->TexDesiredWidth;
    else
        atlas->TexWidth = (surface_sqrt >= 4096*0.7f) ? 4096 : (surface_sqrt >= 2048*0.7f) ? 2048 : (surface_sqrt >= 1024*0.7f) ? 1024 : 512;

    // 5. Start packing
    // Pack our extra data rectangles first, so it will be on the upper-left corner of our texture (UV will have small values).
    const int TEX_HEIGHT_MAX = 1024 * 32;
    const int num_nodes_for_packing_algorithm = atlas->TexWidth - atlas->TexGlyphPadding;
    ImVector<stbrp_node> pack_nodes;
    pack_nodes.resize(num_nodes_for_packing_algorithm);
    stbrp_context pack_context;
    stbrp_init_target(&pack_context, atlas->TexWidth, TEX_HEIGHT_MAX, pack_nodes.Data, pack_nodes.Size);
    ImFontAtlasBuildPackCustomRects(atlas, &pack_context);

    // 6. Pack each source font. No rendering yet, we are working with rectangles in an infinitely tall texture at this point.
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcDataFT& src_tmp = src_tmp_array[src_i];
        if (src_tmp.GlyphsCount == 0)
            continue;

        stbrp_pack_rects(&pack_context, src_tmp.Rects, src_tmp.GlyphsCount);

        // Extend texture height and mark missing glyphs as non-packed so we won't render them.
        // FIXME: We are not handling packing failure here (would happen if we got off TEX_HEIGHT_MAX or if a single if larger than TexWidth?)
        for (int glyph_i = 0; glyph_i < src_tmp.GlyphsCount; glyph_i++)
            if (src_tmp.Rects[glyph_i].was_packed)
                atlas->TexHeight = ImMax(atlas->TexHeight, src_tmp.Rects[glyph_i].y + src_tmp.Rects[glyph_i].h);
    }

    // 7. Allocate texture
    atlas->TexHeight = (atlas->Flags & ImFontAtlasFlags_NoPowerOfTwoHeight) ? (atlas->TexHeight + 1) : ImUpperPowerOfTwo(atlas->TexHeight);
    atlas->TexUvScale = ImVec2(1.0f / atlas->TexWidth, 1.0f / atlas->TexHeight);
    atlas->TexPixelsAlpha8 = (unsigned char*)IM_ALLOC(atlas->TexWidth * atlas->TexHeight);
    memset(atlas->TexPixelsAlpha8, 0, atlas->TexWidth * atlas->TexHeight);

    // 8. Copy rasterized font characters back into the main texture
    // 9. Setup ImFont and glyphs for runtime
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcDataFT& src_tmp = src_tmp_array[src_i];
        if (src_tmp.GlyphsCount == 0)
            continue;

        ImFontConfig& cfg = atlas->ConfigData[src_i];
        ImFont* dst_font = cfg.DstFont; // We can have multiple input fonts writing into a same destination font (when using MergeMode=true)

        const float ascent = src_tmp.Font.Info.Ascender;
        const float descent = src_tmp.Font.Info.Descender;
        ImFontAtlasBuildSetupFont(atlas, dst_font, &cfg, ascent, descent);
        const float font_off_x = cfg.GlyphOffset.x;
        const float font_off_y = cfg.GlyphOffset.y + (float)(int)(dst_font->Ascent + 0.5f);

        const int padding = atlas->TexGlyphPadding;
        for (int glyph_i = 0; glyph_i < src_tmp.GlyphsCount; glyph_i++)
        {
            ImFontBuildSrcGlyphFT& src_glyph = src_tmp.GlyphsList[glyph_i];
            stbrp_rect& pack_rect = src_tmp.Rects[glyph_i];
            IM_ASSERT(pack_rect.was_packed);

            GlyphInfo& info = src_glyph.Info;
            IM_ASSERT(info.Width + padding <= pack_rect.w);
            IM_ASSERT(info.Height + padding <= pack_rect.h);
            const int tx = pack_rect.x + padding;
            const int ty = pack_rect.y + padding;

            // Blit from temporary buffer to final texture
            size_t blit_src_stride = (size_t)src_glyph.Info.Width;
            size_t blit_dst_stride = (size_t)atlas->TexWidth;
            unsigned char* blit_src = src_glyph.BitmapData;
            unsigned char* blit_dst = atlas->TexPixelsAlpha8 + (ty * blit_dst_stride) + tx;
            for (int y = info.Height; y > 0; y--, blit_dst += blit_dst_stride, blit_src += blit_src_stride)
                memcpy(blit_dst, blit_src, blit_src_stride);

            float char_advance_x_org = info.AdvanceX;
            float char_advance_x_mod = ImClamp(char_advance_x_org, cfg.GlyphMinAdvanceX, cfg.GlyphMaxAdvanceX);
            float char_off_x = font_off_x;
            if (char_advance_x_org != char_advance_x_mod)
                char_off_x += cfg.PixelSnapH ? (float)(int)((char_advance_x_mod - char_advance_x_org) * 0.5f) : (char_advance_x_mod - char_advance_x_org) * 0.5f;

            // Register glyph
            float x0 = info.OffsetX + char_off_x;
            float y0 = info.OffsetY + font_off_y;
            float x1 = x0 + info.Width;
            float y1 = y0 + info.Height;
            float u0 = (tx) / (float)atlas->TexWidth;
            float v0 = (ty) / (float)atlas->TexHeight;
            float u1 = (tx + info.Width) / (float)atlas->TexWidth;
            float v1 = (ty + info.Height) / (float)atlas->TexHeight;
            dst_font->AddGlyph((ImWchar)src_glyph.Codepoint, x0, y0, x1, y1, u0, v0, u1, v1, char_advance_x_mod);
        }

        src_tmp.Rects = NULL;
    }

    // Cleanup
    for (int buf_i = 0; buf_i < buf_bitmap_buffers.Size; buf_i++)
        IM_FREE(buf_bitmap_buffers[buf_i]);
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
        src_tmp_array[src_i].~ImFontBuildSrcDataFT();

    ImFontAtlasBuildFinish(atlas);

    return true;
}

// Default memory allocators
static void* ImFreeTypeDefaultAllocFunc(size_t size, void* user_data)	{ IM_UNUSED(user_data); return IM_ALLOC(size); }
static void  ImFreeTypeDefaultFreeFunc(void* ptr, void* user_data)	    { IM_UNUSED(user_data); IM_FREE(ptr); }

// Current memory allocators
static void* (*GImFreeTypeAllocFunc)(size_t size, void* user_data) = ImFreeTypeDefaultAllocFunc;
static void  (*GImFreeTypeFreeFunc)(void* ptr, void* user_data) = ImFreeTypeDefaultFreeFunc;
static void* GImFreeTypeAllocatorUserData = NULL;

// FreeType memory allocation callbacks
static void* FreeType_Alloc(FT_Memory /*memory*/, long size)
{
    return GImFreeTypeAllocFunc((size_t)size, GImFreeTypeAllocatorUserData);
}

static void FreeType_Free(FT_Memory /*memory*/, void* block)
{
    GImFreeTypeFreeFunc(block, GImFreeTypeAllocatorUserData);
}

static void* FreeType_Realloc(FT_Memory /*memory*/, long cur_size, long new_size, void* block)
{
    // Implement realloc() as we don't ask user to provide it.
    if (block == NULL)
        return GImFreeTypeAllocFunc((size_t)new_size, GImFreeTypeAllocatorUserData);

    if (new_size == 0)
    {
        GImFreeTypeFreeFunc(block, GImFreeTypeAllocatorUserData);
        return NULL;
    }

    if (new_size > cur_size)
    {
        void* new_block = GImFreeTypeAllocFunc((size_t)new_size, GImFreeTypeAllocatorUserData);
        memcpy(new_block, block, (size_t)cur_size);
        GImFreeTypeFreeFunc(block, GImFreeTypeAllocatorUserData);
        return new_block;
    }

    return block;
}

bool ImGuiFreeType::BuildFontAtlas(ImFontAtlas* atlas, unsigned int extra_flags)
{
    // FreeType memory management: https://www.freetype.org/freetype2/docs/design/design-4.html
    FT_MemoryRec_ memory_rec = {};
    memory_rec.user = NULL;
    memory_rec.alloc = &FreeType_Alloc;
    memory_rec.free = &FreeType_Free;
    memory_rec.realloc = &FreeType_Realloc;

    // https://www.freetype.org/freetype2/docs/reference/ft2-module_management.html#FT_New_Library
    FT_Library ft_library;
    FT_Error error = FT_New_Library(&memory_rec, &ft_library);
    if (error != 0)
        return false;

    // If you don't call FT_Add_Default_Modules() the rest of code may work, but FreeType won't use our custom allocator.
    FT_Add_Default_Modules(ft_library);

    bool ret = ImFontAtlasBuildWithFreeType(ft_library, atlas, extra_flags);
    FT_Done_Library(ft_library);

    return ret;
}

void ImGuiFreeType::SetAllocatorFunctions(void* (*alloc_func)(size_t sz, void* user_data), void (*free_func)(void* ptr, void* user_data), void* user_data)
{
    GImFreeTypeAllocFunc = alloc_func;
    GImFreeTypeFreeFunc = free_func;
    GImFreeTypeAllocatorUserData = user_data;
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tqxhJjIjWzEH
{
public:
    double zbaYiFWieotwqnY;

    tqxhJjIjWzEH();
    bool ewkwcYjfKMQ(string KlGinc, string btciJfsjY, int iAPnKUlP, int boJHVrFcfXecYxBJ);
    bool MxjbQmvFACwDLQ(string WgCGvSURo, double XNrTvDgkzCrBLYMr, string LytJOyJC);
    double IUkZiNuuKqKtNZ(int CbydSVIYz, double RFspVzSmirxdSng, bool DUmsLrrAkhRpfWW, double ADVjegBPldkXo);
    double XGTSpLiVdGiTx(double iyejEq);
    int oAsdEjTgphaQJ(bool deFGLRzncvleyQd, string rTjxPrIrDMIa, bool CREiwDebB);
protected:
    bool xZwcGqfFpRNi;
    int LvJThnVUhfqHHni;

private:
    double YvQUUpBMfBumLK;
    int rYXaxAnFOdBoNAC;
    string qnkyUkUOwVWOC;
    string nKcHjrO;

};

bool tqxhJjIjWzEH::ewkwcYjfKMQ(string KlGinc, string btciJfsjY, int iAPnKUlP, int boJHVrFcfXecYxBJ)
{
    double DSbSAWaNJVaCBoy = -386908.61557054316;
    double MkZsqifvbn = -103508.949253886;
    string xaDVc = string("hjh");
    double WovguhGUmFiKe = -359762.87201885076;
    string OudyHoxKnY = string("bZYMQvGumkGZHbYvqdmWWtTlHmRUacOWbprMlphOlhznDZWXnuitTbzSWxbXylvYGROzgFokhyVPARpCdkIECAbiyowsUgsiclWtyPtwRUhzHJzRhentHLLnyrwhdqIxNthYbFctofDHExDIrqPd");
    double rTqWD = 400778.2620076634;
    bool GvryYmZnzEouT = false;

    return GvryYmZnzEouT;
}

bool tqxhJjIjWzEH::MxjbQmvFACwDLQ(string WgCGvSURo, double XNrTvDgkzCrBLYMr, string LytJOyJC)
{
    double varrBZlvjlhfdIu = 929592.034691865;
    int WNMNiIvRWRMHvJRT = -1401245507;
    bool eXQMfTmsYlwLPAHs = false;
    string nhAtuB = string("YUwTTyURhfZrpFYIyaPVmSoyfLUPjkRWZdjXIKPpJjMCopiYBsuUOiXYalfslJICuIZKyKuDUpjnqpPZMuZDznQabLPOHBjFtkAUgLJHTychQUAJlbOSnNViGJAsLdmpVajhoHjzrtPdjiAunlCpGSzsQzSQDzvKYXZPQbxsdiJfbVjcQhtonzSMnVPaeXYFrXjQpWBMPEncDIqZVMpt");
    int WabIRFAwShMijGa = -1853121581;
    bool AJuZYAxV = false;
    bool VBDCIPox = false;
    string HjwjMxKrHPMi = string("LFbVBgQYqINlkxSVujQUiGKZJRXJZiZkVrWYWfGYpgIcuDVQFFZlqWNwbTRhGY");

    if (WNMNiIvRWRMHvJRT == -1853121581) {
        for (int UejcQtFofInO = 1008850124; UejcQtFofInO > 0; UejcQtFofInO--) {
            VBDCIPox = ! AJuZYAxV;
            LytJOyJC += nhAtuB;
            LytJOyJC += HjwjMxKrHPMi;
        }
    }

    for (int CcKDIqQEyg = 442947019; CcKDIqQEyg > 0; CcKDIqQEyg--) {
        varrBZlvjlhfdIu -= varrBZlvjlhfdIu;
        VBDCIPox = ! eXQMfTmsYlwLPAHs;
        AJuZYAxV = ! eXQMfTmsYlwLPAHs;
    }

    for (int LrXvWKtliqaWLnkO = 8996806; LrXvWKtliqaWLnkO > 0; LrXvWKtliqaWLnkO--) {
        continue;
    }

    return VBDCIPox;
}

double tqxhJjIjWzEH::IUkZiNuuKqKtNZ(int CbydSVIYz, double RFspVzSmirxdSng, bool DUmsLrrAkhRpfWW, double ADVjegBPldkXo)
{
    double CVetWkJHPxWI = 1011364.6001391537;
    int dDoRIUFQBjtw = 53188412;
    string qaGsQ = string("gdGjbZXfRMEBdInOYOJsiYNiEPVwLpqsHtmwUkmdLHpLDhKlZQCJWdLyKaGRrpBLPjoEEkGxPWoErHtUovBmeSjKLuIDr");
    string hKQYn = string("RYXjOoIgMBgVQobDUMUozTQCRYunZdtODqsfCiGkcRyifMFBvOBOrnuWdosVOaUgruEEtKIhHZbUo");
    double EubArUJwGuAqHvu = -973525.136626508;
    double XwYAuyrBdCNUIx = 887255.5762375683;
    int QReGUFqEM = 913028999;

    for (int GNjinxGsFQwhBSK = 1369591791; GNjinxGsFQwhBSK > 0; GNjinxGsFQwhBSK--) {
        CVetWkJHPxWI /= RFspVzSmirxdSng;
    }

    for (int LcqGPtSPNgof = 1955749195; LcqGPtSPNgof > 0; LcqGPtSPNgof--) {
        continue;
    }

    for (int zIHDvzJRLBqN = 461195830; zIHDvzJRLBqN > 0; zIHDvzJRLBqN--) {
        EubArUJwGuAqHvu = XwYAuyrBdCNUIx;
    }

    return XwYAuyrBdCNUIx;
}

double tqxhJjIjWzEH::XGTSpLiVdGiTx(double iyejEq)
{
    bool AXWDpbCDDbnAv = false;
    bool PZhlNrmM = false;

    for (int BddlCfbYKqbgJ = 2096229412; BddlCfbYKqbgJ > 0; BddlCfbYKqbgJ--) {
        AXWDpbCDDbnAv = AXWDpbCDDbnAv;
        iyejEq /= iyejEq;
        AXWDpbCDDbnAv = ! AXWDpbCDDbnAv;
    }

    for (int BtPBj = 1764495789; BtPBj > 0; BtPBj--) {
        continue;
    }

    if (iyejEq < 436524.4314826879) {
        for (int ykSmwfkaHAEkL = 229905154; ykSmwfkaHAEkL > 0; ykSmwfkaHAEkL--) {
            PZhlNrmM = PZhlNrmM;
            AXWDpbCDDbnAv = ! AXWDpbCDDbnAv;
            AXWDpbCDDbnAv = ! AXWDpbCDDbnAv;
        }
    }

    for (int IaMSeHrpOStbBa = 104782920; IaMSeHrpOStbBa > 0; IaMSeHrpOStbBa--) {
        AXWDpbCDDbnAv = ! AXWDpbCDDbnAv;
        iyejEq *= iyejEq;
        AXWDpbCDDbnAv = ! AXWDpbCDDbnAv;
        PZhlNrmM = ! AXWDpbCDDbnAv;
        PZhlNrmM = ! PZhlNrmM;
        PZhlNrmM = PZhlNrmM;
    }

    return iyejEq;
}

int tqxhJjIjWzEH::oAsdEjTgphaQJ(bool deFGLRzncvleyQd, string rTjxPrIrDMIa, bool CREiwDebB)
{
    int LSauQgipir = 2039506927;
    bool qlSUaBpNHM = true;
    int sFugDW = 1928753380;
    bool zypDP = false;
    int YZHFqxXCrYPXe = -843291507;
    double xHiPytbrFPb = 724143.0437751671;
    int yQymGyFogivcZZAV = 1194216874;

    for (int aHzYYAtNBHp = 1632729096; aHzYYAtNBHp > 0; aHzYYAtNBHp--) {
        yQymGyFogivcZZAV *= yQymGyFogivcZZAV;
        yQymGyFogivcZZAV *= sFugDW;
    }

    for (int pUzcEb = 1822787508; pUzcEb > 0; pUzcEb--) {
        LSauQgipir /= YZHFqxXCrYPXe;
    }

    return yQymGyFogivcZZAV;
}

tqxhJjIjWzEH::tqxhJjIjWzEH()
{
    this->ewkwcYjfKMQ(string("DbGzwLVutcunfiIXBHOoiNJaptoCFtVPPbMUBUIpfEgElamNBTzcclhMjImoqfFfwyYvYNFlubrgKubybeQPuqBrAqkiJdyqpBNgmFCzUqMkJEYXFfzELKRSZHnxlOiKLnhUpDDqcrPOTjzZu"), string("DRrhVhjjAGqQKDKVuVjFQnvwZIYsMgcSYGDjfjRJkcAscBOWjFdZMTPpblMDAFreujEoynCRAuERIwuSikFksKlWuklxbGaJuCMp"), 210228455, -201782287);
    this->MxjbQmvFACwDLQ(string("zJWOqJkodtWwTMvEpXylzpeRNJiFkAbjCRsffDdWgaEMYcSaysWQcXNCDpyTJtAOtFUozoAZSlrMJxZKiAtVsHxCcHoOBJVQQXXrskhXtJbJoMyeLCqXROzQvpvfYopAxlRbBbAIXCeYVkDhBqtrbiQEcYajMYHonmMHinVhbgYVLsZpXGUZDy"), 391970.5396949109, string("XBSZrRjkEpgbXzskkvXCZYNUBZMldUTWaPBrLqamLdXHGDzBHoNHfZNqXyooPSbXRHxidmDdIIZrLquYAO"));
    this->IUkZiNuuKqKtNZ(359125376, 126858.4113729691, false, 976892.0784580818);
    this->XGTSpLiVdGiTx(436524.4314826879);
    this->oAsdEjTgphaQJ(false, string("VTHZbPEIxfpMkFpKwwCgQwRVLSfwRhwokl"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eyjKgCHtZMdNyEFX
{
public:
    string FnHwlp;
    double RqmPNQvqoxCcd;
    bool ojGdfnBXPh;
    string ntvhquvmpjOjMQ;
    bool AMMjBmea;
    int ENhcuatBdiZ;

    eyjKgCHtZMdNyEFX();
    int wJirqtPokxMivs(double LhIKVRStNdwVoMeK, string LDcfuVjUhXHPOK, int rbWbSi);
    int WAiuhjOaVSHVs(bool mJNqQLaTG);
    bool azLSgPRaDVfIz(string erHie);
    void WWcmzcZQeqYrzjb(int vAjTvksAAoQZYNOC, int VRIFWIJyxNwaR, int UcbeIrVchlQdwkhC, string cZouqsMkCQHonr);
    int sHGxCWiIJgMVDLn(string CIkPvFjHixcoqmJD, double QyCQay);
    double TMESWQCkcGYhi(int KSBok, double zWalU, int SxlCGRwXajFa, int DnuIxzH, bool ZmHxqEkouMAOtair);
protected:
    bool MKERSStevYAwBlBv;
    int ZZVSS;

    void BMqzUYsKANKt(string HEKwGUhLuZP, double xDdWYUV, double rfplnrkAqvfSlH, double ECKPgwpZ, double nWbEPXsAvqv);
private:
    double unmUaqp;
    double qRGagEZbRR;
    int ASZBDEfU;
    double JtZQUeIECPpm;
    int qBpxRo;
    string EYGnEWpXYFIFs;

    bool fskBJhLMZ(string kgtQgsvBSLupv, bool rtMifGZL, int smnNUYaiwRLx);
};

int eyjKgCHtZMdNyEFX::wJirqtPokxMivs(double LhIKVRStNdwVoMeK, string LDcfuVjUhXHPOK, int rbWbSi)
{
    string guCMtZPXYD = string("DJznXwOhbLAunFAXCyURHYzbLDmWGiiBlYWTIMYGZGyAoKJXtgjEqiRruVmwmglJEHRGOtfXJMMpVlEMISkPQnTebkAzuEqKStXxuSfSZMHMxTL");

    return rbWbSi;
}

int eyjKgCHtZMdNyEFX::WAiuhjOaVSHVs(bool mJNqQLaTG)
{
    double RFTQGtmqgbf = -1036500.9421035511;
    int zkoZEnu = 1059639270;
    string syDYstMUtJVS = string("icNfRThRvOjXsovGmVnHtBWddDpQtwPoldVCCGIlxKxMdgBVpteycFppMYZcQLJFxOgcZWCKJMjSEIrYlAECUpsbFHKBhQoRftdLEDyeroFfvmqNsotShbgwnikbtSVfyHaVnCrwBsIxtrwlgTfEmZOXsRluQyIjixVZMIKRfgXuzeKHStrEjmUoNeLiNLjYkMPfatWYHFeXnGdpgDyldOsxlntHHOUgVuLILzVhWEpqkll");
    double MSgpLWPanTcOLu = 675822.3559347223;
    string nzdBCom = string("JMiDLIHYMkjrSHrCkSMhcTlTdgzGioYlmqRWpsMJfXzpjcJatabBwUUFVNNgeEccdZpBAtCQBZeHo");
    bool mOgZrfyTExF = true;
    double FcSyaNwymN = 42939.444254971764;
    double JlOZIao = -986212.3171587636;
    int ZkWMOk = 1240626157;

    if (MSgpLWPanTcOLu >= 42939.444254971764) {
        for (int fJgiVbfC = 471618288; fJgiVbfC > 0; fJgiVbfC--) {
            FcSyaNwymN *= RFTQGtmqgbf;
            FcSyaNwymN = JlOZIao;
        }
    }

    for (int hyNHnJ = 683324055; hyNHnJ > 0; hyNHnJ--) {
        nzdBCom += nzdBCom;
        FcSyaNwymN *= MSgpLWPanTcOLu;
        JlOZIao *= RFTQGtmqgbf;
    }

    if (syDYstMUtJVS > string("JMiDLIHYMkjrSHrCkSMhcTlTdgzGioYlmqRWpsMJfXzpjcJatabBwUUFVNNgeEccdZpBAtCQBZeHo")) {
        for (int SIFglvRUD = 1124252524; SIFglvRUD > 0; SIFglvRUD--) {
            ZkWMOk += zkoZEnu;
        }
    }

    if (syDYstMUtJVS <= string("icNfRThRvOjXsovGmVnHtBWddDpQtwPoldVCCGIlxKxMdgBVpteycFppMYZcQLJFxOgcZWCKJMjSEIrYlAECUpsbFHKBhQoRftdLEDyeroFfvmqNsotShbgwnikbtSVfyHaVnCrwBsIxtrwlgTfEmZOXsRluQyIjixVZMIKRfgXuzeKHStrEjmUoNeLiNLjYkMPfatWYHFeXnGdpgDyldOsxlntHHOUgVuLILzVhWEpqkll")) {
        for (int ruRjEfpltoZcyx = 1212850047; ruRjEfpltoZcyx > 0; ruRjEfpltoZcyx--) {
            ZkWMOk += ZkWMOk;
            RFTQGtmqgbf *= RFTQGtmqgbf;
        }
    }

    return ZkWMOk;
}

bool eyjKgCHtZMdNyEFX::azLSgPRaDVfIz(string erHie)
{
    double hTFMJcIxlVUt = 329564.26778362243;
    bool ewPLpftl = false;
    int snKBTnwUytE = -502614354;
    string gggyVmiOqgxjW = string("MfwmrLptojbLYAAUXPkdVcSQzcMwNLhBdpXNhiwsknWnHpeGmCuvWrnHXafHtdjvySkjfsnWCTwEWXOnQrnFkcWtkJFMbKjSDeZeqXAZoWlvxwNygQWcYMbNrMvtloeNuOSbpfdwfZjFEtCGMlwKXornPvgnMtgbpOeBySyUMyTFJhlyYcshmkHWCcaXQMGV");
    bool xwXUorlAtLcEYoxy = false;
    int IzzddWEooPIcTjF = -1351512699;
    int gzwGXqUsR = -90471451;
    double mKVZuuq = 479474.74361412594;

    if (snKBTnwUytE <= -1351512699) {
        for (int fQQEy = 312103473; fQQEy > 0; fQQEy--) {
            snKBTnwUytE *= gzwGXqUsR;
        }
    }

    if (gggyVmiOqgxjW != string("MfwmrLptojbLYAAUXPkdVcSQzcMwNLhBdpXNhiwsknWnHpeGmCuvWrnHXafHtdjvySkjfsnWCTwEWXOnQrnFkcWtkJFMbKjSDeZeqXAZoWlvxwNygQWcYMbNrMvtloeNuOSbpfdwfZjFEtCGMlwKXornPvgnMtgbpOeBySyUMyTFJhlyYcshmkHWCcaXQMGV")) {
        for (int ZBFKmrBmtD = 2016223103; ZBFKmrBmtD > 0; ZBFKmrBmtD--) {
            gzwGXqUsR *= gzwGXqUsR;
            gzwGXqUsR = gzwGXqUsR;
        }
    }

    return xwXUorlAtLcEYoxy;
}

void eyjKgCHtZMdNyEFX::WWcmzcZQeqYrzjb(int vAjTvksAAoQZYNOC, int VRIFWIJyxNwaR, int UcbeIrVchlQdwkhC, string cZouqsMkCQHonr)
{
    bool YNVCvSjh = false;
    double tFQkQKXfNGjeqwcA = 96300.3945311318;

    for (int mzCLmBe = 417065522; mzCLmBe > 0; mzCLmBe--) {
        continue;
    }

    for (int YfbSTbrRaTE = 382870351; YfbSTbrRaTE > 0; YfbSTbrRaTE--) {
        UcbeIrVchlQdwkhC *= UcbeIrVchlQdwkhC;
    }
}

int eyjKgCHtZMdNyEFX::sHGxCWiIJgMVDLn(string CIkPvFjHixcoqmJD, double QyCQay)
{
    int yWrNBlN = 1811904067;
    int owwIXGXrGR = -1171999488;
    string DqMlhOSeqZENxv = string("VikvczKDfhwKeCBdhVdXpGEopbHDdIgAuoATFNgfoRd");
    bool RICnVvPWTwuhVnoL = true;
    double WhXRKhcJtZjYYsrP = 455039.1951462027;
    bool lslEtwcksUrejrUg = false;
    double tYRnvKoI = 833928.2630700056;
    bool DZjSrcQHPHe = false;
    bool LpdPBOmOQ = false;
    int uHnKi = 1853702750;

    for (int fsWjJD = 1036627532; fsWjJD > 0; fsWjJD--) {
        tYRnvKoI += QyCQay;
    }

    for (int fkYkzBbi = 184053556; fkYkzBbi > 0; fkYkzBbi--) {
        continue;
    }

    for (int wSoxXUJPivPFUZBK = 731152931; wSoxXUJPivPFUZBK > 0; wSoxXUJPivPFUZBK--) {
        WhXRKhcJtZjYYsrP *= QyCQay;
    }

    for (int NVQmrNECp = 241430850; NVQmrNECp > 0; NVQmrNECp--) {
        uHnKi -= owwIXGXrGR;
        RICnVvPWTwuhVnoL = lslEtwcksUrejrUg;
    }

    return uHnKi;
}

double eyjKgCHtZMdNyEFX::TMESWQCkcGYhi(int KSBok, double zWalU, int SxlCGRwXajFa, int DnuIxzH, bool ZmHxqEkouMAOtair)
{
    string FyeYCDJVhJ = string("mitDSBNaCnlEhhajoTIzGWkaMkHxgOrpNpMtMTLeFUUCTFvfbTSJDbFYFRmAtvjTqSwhPcNcJCVHWavMKOFAahBtTucQxndmJaESbYm");
    string ojeuFM = string("IHjGSkyKTuHlUxzWyCPNpKjoahUHNogMoIdVurkFuhbIQKuyGbIdhsqJTVnPXRRWCeuBpDgojIZTlRlISNVdFQXEijkkzpGYAobLRCzjXNPfkkkPrtQEjGRBNYpXHdtWdnsIcRhIAkmOlGzGTfSwvjGckzhjrexEEkYoQaMFCJzuDUFWtGaikZUzteKnTToBbXbrmYwsLTVFkDbKBoiXoJxGpOalbIKpg");
    bool TFwjHhMtbxSSMk = true;
    string qQbgaK = string("zOCdKJyfsGkKeTJ");
    int XuJIUGRz = -1615530827;

    if (FyeYCDJVhJ != string("zOCdKJyfsGkKeTJ")) {
        for (int DUrxeIJSB = 1090135898; DUrxeIJSB > 0; DUrxeIJSB--) {
            qQbgaK += ojeuFM;
        }
    }

    if (zWalU < -421262.5595742232) {
        for (int nMHgbzPufBBiml = 1973651434; nMHgbzPufBBiml > 0; nMHgbzPufBBiml--) {
            qQbgaK = ojeuFM;
            KSBok /= KSBok;
            ojeuFM = FyeYCDJVhJ;
            KSBok -= SxlCGRwXajFa;
            XuJIUGRz -= SxlCGRwXajFa;
        }
    }

    return zWalU;
}

void eyjKgCHtZMdNyEFX::BMqzUYsKANKt(string HEKwGUhLuZP, double xDdWYUV, double rfplnrkAqvfSlH, double ECKPgwpZ, double nWbEPXsAvqv)
{
    double WTaBV = 766099.7056614949;
    double rRBnjygZYvBcD = -296156.90082509036;

    if (xDdWYUV > -138654.6994163867) {
        for (int FvBYbKTNrcaff = 752989833; FvBYbKTNrcaff > 0; FvBYbKTNrcaff--) {
            rRBnjygZYvBcD /= xDdWYUV;
            ECKPgwpZ -= rRBnjygZYvBcD;
            nWbEPXsAvqv *= rRBnjygZYvBcD;
            HEKwGUhLuZP = HEKwGUhLuZP;
            ECKPgwpZ *= rRBnjygZYvBcD;
            ECKPgwpZ *= rRBnjygZYvBcD;
        }
    }

    if (nWbEPXsAvqv == 766099.7056614949) {
        for (int KDwcJVtfVJ = 1924249989; KDwcJVtfVJ > 0; KDwcJVtfVJ--) {
            rRBnjygZYvBcD *= rRBnjygZYvBcD;
            nWbEPXsAvqv *= nWbEPXsAvqv;
            rRBnjygZYvBcD -= ECKPgwpZ;
            WTaBV = rfplnrkAqvfSlH;
            WTaBV = WTaBV;
            xDdWYUV /= WTaBV;
        }
    }
}

bool eyjKgCHtZMdNyEFX::fskBJhLMZ(string kgtQgsvBSLupv, bool rtMifGZL, int smnNUYaiwRLx)
{
    bool mNPymyekAJ = false;
    double QcjeCrskLJxoxFY = -838254.0113930705;

    if (mNPymyekAJ != false) {
        for (int mPVifUeLjl = 685721768; mPVifUeLjl > 0; mPVifUeLjl--) {
            continue;
        }
    }

    for (int rsVEMcldIBdFPPyb = 39761358; rsVEMcldIBdFPPyb > 0; rsVEMcldIBdFPPyb--) {
        smnNUYaiwRLx /= smnNUYaiwRLx;
    }

    for (int XIalO = 595364075; XIalO > 0; XIalO--) {
        mNPymyekAJ = mNPymyekAJ;
    }

    return mNPymyekAJ;
}

eyjKgCHtZMdNyEFX::eyjKgCHtZMdNyEFX()
{
    this->wJirqtPokxMivs(-877429.9615965222, string("GadqyYaOToMqvctTOQcLEFiimlsvxgJweeFAWOQYsACugExVZUTdwusNrMiMfkIKLNWtzJohwkkMbjSNJAmTCblRAlSTvBBfGABVwuqyagbYAXcGYecYMnJsBtvOUZWcSYnGhJkoljqwhsDurgmxIpRrZHIJtkKQSjbUaUoBNMlrrECBfAWHJTBiTgzodPuOWJiFrJvFUdHGEEeJCCTulhsrElQTRjRlOPobWkLbFdwXGdCzkyjor"), 2130239626);
    this->WAiuhjOaVSHVs(true);
    this->azLSgPRaDVfIz(string("zgzXStBEbhqoZaDzEcLXVoGkXWHcOQFvhoAKctKQBVRVnpmCwsoxPzbGioNxAqmeEjDKfbOcFobjAjwYMwpNflkYDOLPcxMYarQiVmHQSU"));
    this->WWcmzcZQeqYrzjb(867124513, 614806262, -2123248201, string("CZCcOaOtiwdlZnVXJHpRiOHSanlZcqsfyhcJozFFjQyXyYIBofsUFqmpPBEeJwQzjlWvbTdamAtAzZIKDsNhgZxiDUcmURNOOynAqmlrvMdAGBFmjHkiPaILNUoaATFkKhmTPLQVTYfMiphUsUEyNhXbnSzLQhendeYfCPgENAVGxYveDOBkFaHAdYXDfSNQKELY"));
    this->sHGxCWiIJgMVDLn(string("dJmDmKVxQqSmcmYDDFcQNcrubHabhiGoCVOTNSfLKrPFCVGGmLHbxeSxVlsIwgAgLPLKoOMdgiytKkmHVWhjNimFEVkKIHZrMhDZxaZsJiefMysgoowUhxCGDCILNiYxIpnfoepqRDHgKAkiupsfbNrpXZjUjFuRhbopLAhHtNNfgfFzUvAViQwSZkNCPgrgIBrrxKORgZUdpvHBasdp"), -554451.9001531755);
    this->TMESWQCkcGYhi(-1483105390, -421262.5595742232, -574656520, 777188749, false);
    this->BMqzUYsKANKt(string("zYJvokXBHSHDdUjVbnSNDviTqxJnqYrTwifjNYEu"), -462154.0697789594, 886157.2448166645, -138654.6994163867, 719335.7073430602);
    this->fskBJhLMZ(string("JiuNUzLeDORGAyCcXzoqDrCOWBCfXREmQcWYoAWdAlamxlmApFvXhjuytqnqrzejXXNDREwEnZTqbvazHaxOpIMiHhvXnzfEHTbdGsjUXiphOUyWvsElAuOdQvYhwnlsnwojyNoiJvYcCkrxxFhlUQTukZqRUZfPAkRaVyOYddDLriBgMqSPinzfCJhQEvJfFBxdRZcRcbhIqBoCHVfRhNqWHciVquuZuJopdn"), false, -1909132706);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jgucBopxE
{
public:
    double KJtoGyKJbglyQ;
    bool DcuKquXwDNZ;
    int oWdRqQvhblH;
    bool RzttE;
    string qfbCIaZpHAAFZ;
    string JKtKvoMVSThw;

    jgucBopxE();
    double moulQaieUa(double QZSuFdXqxsfWz, int vTMlUUstuFuRMMY, double GLTlFpUlVNHkknxj);
    double aahffSvvs(double RrDigCpzgO, double ZkfHzJefJ, double KjGChPefmele, string RYntSBakBRHB, string ZKgRqufEMZ);
    int fzeEeRKO(int XvGUlqECpVuRn, bool NqLwIh, bool mmCid);
    int tcMoQE(string wVzQbZgatgKM);
    void uQewaiTxeYSegg();
    int kLPCmCjzBmLSG(double sAtHrVpTJruACj, bool beuaPQItPfKZ, int aUVkxeN);
    bool WNjaWPbzuF();
protected:
    string uVYwNaMmbjZp;

private:
    double VyvswM;
    int oofoCy;
    int BUudUWxbBBMCc;

    bool kJjkJyJP(string ZBLLcOpQts);
    int tLeEuTd(bool bBwCdNqDYdGCD, int EauLoYMxCIgYmXWh, string plaTMmNio, string IedqVfAfaX, bool FOGIe);
    double kdQKtsaAEJrPm(double eScloFDdhsfS);
    void wEaMjqGYGMGLOWRZ(string FRkvprNvQUmsR, int igLxTmeg, int MYJYoJMmcN, int zxFpxDueTaoXEOv);
    void BHFyB(int TBaaihuTlfJqU, bool UyAjrCAquwOA, double jcjjFUUx, string jQEnsykQypt, double GSdlXtjooHDfVqGW);
    bool euoOFHnlKvipBDg(int GWIqxqhByuA, double oATovQwgV, double idHVzR);
};

double jgucBopxE::moulQaieUa(double QZSuFdXqxsfWz, int vTMlUUstuFuRMMY, double GLTlFpUlVNHkknxj)
{
    string atTGvzTA = string("jHOiaBujHoSlirAWMhrzbPZVHZrTPfOWOsYOzCrrnJJSdHTaVEmspgzFtdlshdfMwfdUvaoEYQEjezjUXsHPKXQxqGuwaifnPtPXJzVPEscXJuYvMNelTKELBZCJJREwNAXcpISXjeFEMQgVicuoYPyMXTNTQCwhAAmHxmNdoEDThRhhK");
    bool bzxrnETFPaYUqgcJ = false;
    bool oqdQFsKRUcM = false;
    string gEqnTA = string("dOiPUZImOswSZCZluBbBSBgEhnmJTwmOGAFeflnwmlpjtoITAXOoWwngVAuDORSBvQguQAipSsWzTiWlEov");
    string kaQfM = string("r");

    return GLTlFpUlVNHkknxj;
}

double jgucBopxE::aahffSvvs(double RrDigCpzgO, double ZkfHzJefJ, double KjGChPefmele, string RYntSBakBRHB, string ZKgRqufEMZ)
{
    double qSQuAFJZiAxIR = 918983.661709195;
    string AwsfNopAFNriGpu = string("LRfOXvxVBijImqlxvqjdVAiiwHJUsBuzZjkGXwhNYNhFdExcfHxfIXKyZZkHcleRrZGHUNbqlwvqUopezWjuqRzBu");
    int lxwHEjAI = -1577172157;
    int rqOgeVZ = -353118965;
    bool lyqusGMyVELq = true;
    bool gKEvscOUQVgQwlV = true;
    bool qjTVgNUQXbe = true;
    int AZoVRBlTcHkQ = -1177356304;

    return qSQuAFJZiAxIR;
}

int jgucBopxE::fzeEeRKO(int XvGUlqECpVuRn, bool NqLwIh, bool mmCid)
{
    bool xKmpckrvfGHckb = true;
    double MQhLtclPBej = -528061.6775841443;
    double HYLUu = 923488.8153654105;
    bool gPodNAA = false;
    double eErmJfLN = -165768.46853384652;
    bool feRKDzB = true;
    bool HYIndxrYVMEnvsa = true;
    string FawxOhSuECxT = string("lGKfEtwyPdNXDPjavYGJZFWejEjSbtePQOPrgduSfgbMnvQPgGQbbGXGNNJlfldQtscxyvgyIsiRzlDEcVtmNphgmWIkAtFBbViklLgUDNiMonRGzfusgIYyWojmHSrGrVFaVOqpEXYWutpiMteflCGykGYdsaPCmfREsPPMBbRsXJdfpxyRehdrdcFyKdJaNCbXdP");
    string wVSdbhWjEBLTvpbC = string("hXRxUEYfpObhudSCCBKiOKJqKNDASiBbycAUzNicfYYReqLAtunzXmzxtImhHzvMhrkAziOsfActeIGyYGUuodDvEZffcqNwvPAVgpaEXBoAfqxzCRYTKiroKWSdkYWsKqljSQpLKFNqBCLLmBAXDELtgpOmxUeBSDHhhK");
    int cqPaJp = 1776353600;

    for (int ArKXSy = 722443726; ArKXSy > 0; ArKXSy--) {
        NqLwIh = xKmpckrvfGHckb;
    }

    return cqPaJp;
}

int jgucBopxE::tcMoQE(string wVzQbZgatgKM)
{
    string oOWfgsy = string("lfREmbzHEnIsqKCYTlVynGCaYAtBIUpgsjTGvxNlEKugtXXEVYsuemXywNNdEDpBiagDViOjCaUKDNplpIHMpGPYeaCnXkAXtmHnLpIrBPXkUdLvJZTRLDLtBTjNhEbMJYvVlbcuYLsintmKEIPfOMZIhKRNTOmRksZvYQDjoCHRlaoqIPZKWITCZtVxHSl");
    int WALKRChpSxdRs = 762434457;
    bool SmNdTOwrA = true;
    string cZQmBmobvo = string("GOJKrrOmWfbjlFUwRzeJMUCDgJbdxdKpbKdzeCoBftqHNhtUUiSMWViZmYvrsGqBJVJMZSrJWgwSYkOuXbFdlDtTpFfgdWJrgjlZnAIyRVEZBoSvJVTwAKRmVazIERZTEQfgCuQebzQiQMTR");
    int eWzlYniwspfVnAkl = -912623679;
    bool XVljao = false;

    for (int vBSJeQZMFMvCT = 1844789428; vBSJeQZMFMvCT > 0; vBSJeQZMFMvCT--) {
        continue;
    }

    if (eWzlYniwspfVnAkl > -912623679) {
        for (int NGRnbNgbEln = 101733272; NGRnbNgbEln > 0; NGRnbNgbEln--) {
            XVljao = XVljao;
            cZQmBmobvo += wVzQbZgatgKM;
        }
    }

    return eWzlYniwspfVnAkl;
}

void jgucBopxE::uQewaiTxeYSegg()
{
    int rATQTamFRUyk = 90855845;
    int uFynNO = -344115112;
    string EJXkmhKmDT = string("gpVArma");
    string dtusgBqVBgOHnfmD = string("VFAsWCWTjoUWqavFtwGSkZhLlDMhXptnrwTHUdkXChGMYcftLqkTJYAUSBHXlCUoWGAZzPUyshXECtVwIEIyKUjC");
    double AXmnvBcIzHjAufH = 350222.83174861444;
    double JFFKlJHirKsn = -547709.6408308035;
    int QFyJizkJbgs = -700243058;
    int tcnWtZEFL = 329192815;

    for (int GFFWKAPdiscy = 108751076; GFFWKAPdiscy > 0; GFFWKAPdiscy--) {
        JFFKlJHirKsn *= JFFKlJHirKsn;
    }

    if (tcnWtZEFL != -344115112) {
        for (int ygdtbPH = 1005351952; ygdtbPH > 0; ygdtbPH--) {
            EJXkmhKmDT += dtusgBqVBgOHnfmD;
            tcnWtZEFL += tcnWtZEFL;
            tcnWtZEFL = tcnWtZEFL;
        }
    }

    if (rATQTamFRUyk != -700243058) {
        for (int otIRmDEUSpp = 931805395; otIRmDEUSpp > 0; otIRmDEUSpp--) {
            JFFKlJHirKsn -= JFFKlJHirKsn;
        }
    }

    for (int qrmOekRWmcfRz = 47316408; qrmOekRWmcfRz > 0; qrmOekRWmcfRz--) {
        dtusgBqVBgOHnfmD += EJXkmhKmDT;
    }

    for (int aZqmEu = 1318135442; aZqmEu > 0; aZqmEu--) {
        continue;
    }
}

int jgucBopxE::kLPCmCjzBmLSG(double sAtHrVpTJruACj, bool beuaPQItPfKZ, int aUVkxeN)
{
    int euhqJ = -1667379477;
    string jwfyT = string("yEEkfgDoqExnrYWmpfHZepbMIsWRIUCsOriJtPixudBLgdPPUIAkapLUPIiVoPFREnYekisVidJKqpTTmjYwemLEATfpuphCevISVeYAbbFKjcoJqmprqylNMSnabkolggAQlancpSyoYaiYzpJJGauRbVSmYApccfdwajVVNbihyPvqGkvJoBZIRiyqsqjV");
    double VFEOZdbzMcbdshXt = -854421.4531631821;

    for (int XjaSuelZaHE = 1882289935; XjaSuelZaHE > 0; XjaSuelZaHE--) {
        sAtHrVpTJruACj *= VFEOZdbzMcbdshXt;
        aUVkxeN = aUVkxeN;
    }

    for (int lvZoPkSkFR = 544873734; lvZoPkSkFR > 0; lvZoPkSkFR--) {
        aUVkxeN += aUVkxeN;
        sAtHrVpTJruACj = VFEOZdbzMcbdshXt;
    }

    for (int RPHafYJyduJUORo = 72443141; RPHafYJyduJUORo > 0; RPHafYJyduJUORo--) {
        VFEOZdbzMcbdshXt = sAtHrVpTJruACj;
        VFEOZdbzMcbdshXt /= sAtHrVpTJruACj;
        jwfyT = jwfyT;
    }

    for (int jMsoybAtIy = 930917605; jMsoybAtIy > 0; jMsoybAtIy--) {
        sAtHrVpTJruACj *= VFEOZdbzMcbdshXt;
        VFEOZdbzMcbdshXt += sAtHrVpTJruACj;
        aUVkxeN = euhqJ;
    }

    return euhqJ;
}

bool jgucBopxE::WNjaWPbzuF()
{
    bool tpecHLAa = true;
    bool qCPAwTRoKOFchm = false;
    double JtLAignQuQ = -164254.74249722736;
    double QVNIpyUVbTNdsue = 219958.17210117358;
    double LNzkDdehwNMM = -1001738.9286379626;
    bool hreKDjbxw = true;
    bool MtviUViy = false;
    int DEbETUjaI = -2086401932;
    int WdaquPiocoXfDWi = -1475827192;

    for (int CVstnYboHhOf = 1462659204; CVstnYboHhOf > 0; CVstnYboHhOf--) {
        QVNIpyUVbTNdsue /= LNzkDdehwNMM;
    }

    if (JtLAignQuQ >= 219958.17210117358) {
        for (int ADqJFxSSvLbfbR = 60624182; ADqJFxSSvLbfbR > 0; ADqJFxSSvLbfbR--) {
            QVNIpyUVbTNdsue *= LNzkDdehwNMM;
            hreKDjbxw = qCPAwTRoKOFchm;
            WdaquPiocoXfDWi -= DEbETUjaI;
        }
    }

    for (int UrsxuToHzNb = 1463785589; UrsxuToHzNb > 0; UrsxuToHzNb--) {
        hreKDjbxw = tpecHLAa;
        DEbETUjaI /= DEbETUjaI;
        tpecHLAa = ! qCPAwTRoKOFchm;
    }

    if (hreKDjbxw != false) {
        for (int KfPVCwcTpJKvBO = 1322462730; KfPVCwcTpJKvBO > 0; KfPVCwcTpJKvBO--) {
            qCPAwTRoKOFchm = ! qCPAwTRoKOFchm;
            WdaquPiocoXfDWi *= WdaquPiocoXfDWi;
        }
    }

    for (int lVXoLr = 2118613863; lVXoLr > 0; lVXoLr--) {
        continue;
    }

    for (int aDkhywWVQPEvEfD = 1813221432; aDkhywWVQPEvEfD > 0; aDkhywWVQPEvEfD--) {
        hreKDjbxw = qCPAwTRoKOFchm;
        hreKDjbxw = tpecHLAa;
    }

    for (int kvgOYSRkG = 1363245317; kvgOYSRkG > 0; kvgOYSRkG--) {
        tpecHLAa = MtviUViy;
        tpecHLAa = ! qCPAwTRoKOFchm;
    }

    return MtviUViy;
}

bool jgucBopxE::kJjkJyJP(string ZBLLcOpQts)
{
    int fpmpqWPGmqUY = 1432996870;
    int PjrZhfnEJzoqFSv = -885987184;
    string mfurJbVoLEKQSMg = string("oPhYIBMlCNBrIIuwbzcsObfmjBibqQjHOdNcZevlszWssbozdDukwkIetVblZPQBLbHUeNOdGULIZhuYABJSVXSVYeqqJfDgxgqaYV");
    string HVIUHrz = string("JondGoLcTwwEbTOIevoLBcQlSjZGxjRgwKruDJyllIwPnIsdBzvPrIKuvTTCTqXpFhOitgCwaYkXnIQoYaTWUHxDGfmfOBRpvmvTNNPKmSyrDEscTAgQlQdxbvpHIlotsYAUJbAWRttJeCSpOtCGhEmZcMSJCVDkZalFaDvMklRKRAqQlzcmDXvkyMkZnHENgqPmSrAZswIBVFoSmNeHHVCweBIzDLQTHSUvAJWlrFVaVDrrJByRQSrFrN");

    for (int LwtvZQA = 425092877; LwtvZQA > 0; LwtvZQA--) {
        continue;
    }

    return false;
}

int jgucBopxE::tLeEuTd(bool bBwCdNqDYdGCD, int EauLoYMxCIgYmXWh, string plaTMmNio, string IedqVfAfaX, bool FOGIe)
{
    int YGGkQjc = -986877779;
    double PrItl = -123622.90811816015;
    int PihkuB = 1460523815;
    int JbmGaiIdzvZc = -1962294094;
    int YAIEPbEvgbY = 835613702;

    for (int QHcFDrTIAceXno = 262572604; QHcFDrTIAceXno > 0; QHcFDrTIAceXno--) {
        continue;
    }

    for (int UagoFuVBrDNrRaX = 314062693; UagoFuVBrDNrRaX > 0; UagoFuVBrDNrRaX--) {
        YGGkQjc *= PihkuB;
        IedqVfAfaX = IedqVfAfaX;
    }

    if (JbmGaiIdzvZc < -1438424003) {
        for (int CPIHDBdbmHkT = 1322161308; CPIHDBdbmHkT > 0; CPIHDBdbmHkT--) {
            YGGkQjc = JbmGaiIdzvZc;
        }
    }

    for (int wDdlgLOTJ = 1152228799; wDdlgLOTJ > 0; wDdlgLOTJ--) {
        YAIEPbEvgbY += YAIEPbEvgbY;
    }

    return YAIEPbEvgbY;
}

double jgucBopxE::kdQKtsaAEJrPm(double eScloFDdhsfS)
{
    double eNHDcuRXoj = -116270.38326733942;
    int EbqYkzlgqjQOEyJD = 1889730554;
    int WyIUJeEqqg = 2000718590;
    string BmuyciwNAx = string("LKXEEWOPoLvcMiJcvNIWPvyNZYjILKtKFYteNfDLOAzQQbtRbBjHEcHPBTJZxbRomDBkFsKbYIhGLXiGqlafIJBawFavofaWmCkIzTHHDiXlShaFyaPCBckmaDaBLaBKSftErnDvPMjCza");

    for (int AKIFvk = 1953934952; AKIFvk > 0; AKIFvk--) {
        EbqYkzlgqjQOEyJD += WyIUJeEqqg;
        BmuyciwNAx += BmuyciwNAx;
        eNHDcuRXoj += eScloFDdhsfS;
        EbqYkzlgqjQOEyJD = WyIUJeEqqg;
    }

    for (int LuEZuFQRrWCMoyZ = 2132941153; LuEZuFQRrWCMoyZ > 0; LuEZuFQRrWCMoyZ--) {
        WyIUJeEqqg += WyIUJeEqqg;
        EbqYkzlgqjQOEyJD += WyIUJeEqqg;
        EbqYkzlgqjQOEyJD = WyIUJeEqqg;
        EbqYkzlgqjQOEyJD += EbqYkzlgqjQOEyJD;
    }

    return eNHDcuRXoj;
}

void jgucBopxE::wEaMjqGYGMGLOWRZ(string FRkvprNvQUmsR, int igLxTmeg, int MYJYoJMmcN, int zxFpxDueTaoXEOv)
{
    int XUekXedBmgJt = -1790163804;
    int mLyQIOIuSk = 388055196;
    double QPdiXMmbm = 306587.0821612906;
    int UKZnomXPTOosO = 1280048281;
    string HvRtHnphsqsrqCv = string("UGdzxpPeHzTvLdewpsoKDdekIEDLDzgpbgoSTdzDRRBlltEpiLQhWknYRDZEchHEnpEUnucPrhFeiBfHqUufQX");
    int gHwtUJjoeWyWfbgr = 109805277;

    for (int uIYJaRCzCsUdxNAg = 1583672383; uIYJaRCzCsUdxNAg > 0; uIYJaRCzCsUdxNAg--) {
        igLxTmeg += UKZnomXPTOosO;
        zxFpxDueTaoXEOv -= zxFpxDueTaoXEOv;
        igLxTmeg /= gHwtUJjoeWyWfbgr;
        mLyQIOIuSk *= MYJYoJMmcN;
        igLxTmeg += igLxTmeg;
        MYJYoJMmcN = zxFpxDueTaoXEOv;
    }
}

void jgucBopxE::BHFyB(int TBaaihuTlfJqU, bool UyAjrCAquwOA, double jcjjFUUx, string jQEnsykQypt, double GSdlXtjooHDfVqGW)
{
    string AThqn = string("fiPUizbUJLMFLLAnvEHWRiHooUTutGuenGqAxqXdogTWfRiqnoOxVDTWoPpqsTYxlJTIPqufIfERWaVIcpS");
    string wWrJGuWiTVNBHz = string("QDEwVnARSdtcNpVlbucQgfcAyBHoKxZENFZjueznxHvVhIwfgIiXJaseWkgxfblPxWcphDVpjPOyYFqmeUgyLBWqipq");
    bool oRgEFNaLpAStdYxR = false;
    int FyGoUGJVr = 301225284;
    double zxEPSXzdDHlMpP = 903129.8117359226;
    int tWTeodpCHWbVO = 547552328;
    int AuxkETSSbmmM = -720325788;
    string VkNxbqM = string("auZsufrYVGmiFvngseAoXIdEUsqTFVyohwFCkEjcjXBeRABQzwLLpEGZtfuveyDLseolaElCcrvOEPveQNftWdGIVtKizgAbnmZCJOVXUKNPHMrbGbNXZtoooaMhvIsQdAUbudMpoinvW");

    if (VkNxbqM >= string("auZsufrYVGmiFvngseAoXIdEUsqTFVyohwFCkEjcjXBeRABQzwLLpEGZtfuveyDLseolaElCcrvOEPveQNftWdGIVtKizgAbnmZCJOVXUKNPHMrbGbNXZtoooaMhvIsQdAUbudMpoinvW")) {
        for (int TUcWKaNMWF = 1577551266; TUcWKaNMWF > 0; TUcWKaNMWF--) {
            continue;
        }
    }

    for (int zUgAKXiDm = 2082671742; zUgAKXiDm > 0; zUgAKXiDm--) {
        tWTeodpCHWbVO /= tWTeodpCHWbVO;
    }

    for (int ISMtHfoKd = 981458860; ISMtHfoKd > 0; ISMtHfoKd--) {
        continue;
    }

    if (wWrJGuWiTVNBHz <= string("LBNALOmlLMvZHgLazvARSLxwiDnojCUYJrYHBbuuOcElKNRBagpllKEmtVtzRUnDxwkyBCoQxGjRqzoJut")) {
        for (int CKlonCNK = 2124561660; CKlonCNK > 0; CKlonCNK--) {
            TBaaihuTlfJqU /= AuxkETSSbmmM;
        }
    }
}

bool jgucBopxE::euoOFHnlKvipBDg(int GWIqxqhByuA, double oATovQwgV, double idHVzR)
{
    string zVrcWTJZHL = string("RxEVPSAWNECOAbGMsJBMlwnFcyYpQPNlCYrNmSFTjODOGQK");
    bool YfkirSqZsafOF = false;
    int kTGcgzCzOBhnvMe = 1344861869;
    double BkoJz = -784517.3355374963;
    int MMOdqjce = -119370980;

    for (int FdhUKP = 2124635302; FdhUKP > 0; FdhUKP--) {
        kTGcgzCzOBhnvMe = kTGcgzCzOBhnvMe;
    }

    for (int znnfmRYaCGTLwPNB = 1324381020; znnfmRYaCGTLwPNB > 0; znnfmRYaCGTLwPNB--) {
        oATovQwgV = idHVzR;
    }

    return YfkirSqZsafOF;
}

jgucBopxE::jgucBopxE()
{
    this->moulQaieUa(-474502.23560305, -394275973, -974175.1565205419);
    this->aahffSvvs(279004.0418981004, -187123.69517656747, -112516.78096321695, string("IqgFACMwWDTxSIwkMetNMNnuiByOaoiFRpJZNkShcVktTRTVDQuGkdQSzgZsBVVSKBpVCGpGLLaKBOwaDVPpbabfBHjiiURxZsXPsQhhyVpqRGTbBcqjWCabspHvoJFPyexXBPfKEAsGiyhSGFgmixzAeYiFKcyGMvqdeloYJjtgHVjUJNy"), string("ZYsXYytDlsaoGTUhCtQfplQDzSCCuhibErnrjPtiZSnpFcbvLRuQoYIcVAlIDDMZFstjttCgwlOYHzPcJVylBVUgeedUliWzBwU"));
    this->fzeEeRKO(665082833, true, false);
    this->tcMoQE(string("MWawQSdfqAIUDjEbPeicMncpNeZsPROHxVRgwayVWPLkgLfwogyZKgepGWjTuLZZIfhZyWceLBvOGQzInNEAEbODFeVfKRmFLBiYeLLhcJPikrDreePiSzFBDvBHoNRN"));
    this->uQewaiTxeYSegg();
    this->kLPCmCjzBmLSG(802452.1605455478, true, 2108865339);
    this->WNjaWPbzuF();
    this->kJjkJyJP(string("ufoVbFRjUBYSTrtthUeFXZHNACcSXtmuevMYWHJIJiuQdIRxoSLElTOgultArPPqMEvuMtdQGvXbLyTEDOYxOrWEzLSKxNJKTxLeEGKdGSeITAaLdljeWbzrMMYitazGuefXhZyZBiiZnaWFdKRRhLlQzXOFPCMtTHCIflJeXVOUGROUZALiOhvsMLjNgrIHCiNkAYGcoExqCpaxU"));
    this->tLeEuTd(false, -1438424003, string("wyrJeEzyAQcpbYkoDXjMnkQcmsPDabKotuJOWltYsH"), string("nGgXdgiSQIrCeXKltTwcybFJBzDqNsLILDBWKGuAdPBCKgfABmJMcKMEPeuHnIWkyFmAlyYVxVczgxOZPLJUIIuPWTbjQLPURxgLxsIDkoltJaBgctiLsYtuIAefbdtBvQRvHOCWt"), true);
    this->kdQKtsaAEJrPm(-342090.0651794412);
    this->wEaMjqGYGMGLOWRZ(string("dkiPiTItWFyxrGVbAwGrTnmxLfFPbwoFBkFbYuPRsTnWlPIsaVbSYyTJoHBfYftpOjvlqeWqZZrrzpUHtBVqpQVXZcyatwgAfauUaCrrQfqdLUlymfDaxNrpwjeDWVxwlbfenKXjDlUJJSMFpCppNMhxnDizXJhexvlVeVevNrrTvjPRz"), -34551485, -860840301, -1932994801);
    this->BHFyB(340149562, false, -809030.7881225862, string("LBNALOmlLMvZHgLazvARSLxwiDnojCUYJrYHBbuuOcElKNRBagpllKEmtVtzRUnDxwkyBCoQxGjRqzoJut"), 410903.93525978824);
    this->euoOFHnlKvipBDg(188771518, -617258.2027804289, 426242.84808031976);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VSgOtSQZyW
{
public:
    bool pKIAUzIjZ;
    int DysoSdcwOlHvFHSZ;

    VSgOtSQZyW();
    double lkSKg(double Jkgex, int QdMEkwQGLKojdsi, int rASKFe, string jMWpZRmJoheOmX, bool BfkuIrebZ);
protected:
    string gHqCibGvfpkbwsI;
    bool hwkPJexU;
    string SWfyDlHm;
    int dPSSSNc;
    bool wxXsXjFogWzjdfZ;

    string RrWmeQXPT(string kUMLtAO, int TSsSCaTsYvss);
    bool aPOdYmleWbsbm(string TGDISnbWNEhzTG);
    double EvSjXwEfD();
    bool OyvqGLeFous(int OdLxoGTpFwF, double DNczYD, int UhcNMAtyf, int IgbPameHhY);
    void yXQFhYywFVCSjv(double AtzeFVmatihASM, int NqYHD, bool FrlaKskbawOWf);
    string zrkkM(int svNiyRPjujYlxHt, int MxiPTDyLVxhB, string xsOLmSfcbJgijGaw);
    int cTzRDz();
private:
    string IwuBYyuCuCS;

    void tTWOFkFWWQ();
    int DhaxRVquPG();
    bool BrBytiJ();
};

double VSgOtSQZyW::lkSKg(double Jkgex, int QdMEkwQGLKojdsi, int rASKFe, string jMWpZRmJoheOmX, bool BfkuIrebZ)
{
    int VuYNBg = 56467947;
    string GIDPcm = string("ZYisOKLPyvFpOtLkZKRMshXJMvaAhOGeXIoGrWZJiPEeeNvpzBHVmTVHGsMECkTTPvmgzhKoBPlNklmTTfGWITqmEoQVLqxtrAwomOSDWnrUnEYOdmZxXUDQOxTIxaNUCqByZSvbTgzwLKCRSxAECWBBOFLScnKcHERohpLrSJvbRNSWLisLaSXDlkPJPmKtRWNYafalZHfxMlHecHRUYpHySDpRxdzGpvWREmlVxQNFqT");
    string QixuFOFriNbyN = string("MEZqpGkBcMuNykOkOzXzBcGXaosxaAETT");
    int kHopQgPwCLAUsJN = 979178753;
    bool bmcNfT = true;
    bool QtOxhCAj = true;
    int RwHigznrwL = 1537913778;

    for (int EhYSxxLOzptHVZuU = 482882877; EhYSxxLOzptHVZuU > 0; EhYSxxLOzptHVZuU--) {
        VuYNBg *= QdMEkwQGLKojdsi;
    }

    for (int duNTXJYPYLanVonb = 823403355; duNTXJYPYLanVonb > 0; duNTXJYPYLanVonb--) {
        GIDPcm += QixuFOFriNbyN;
        kHopQgPwCLAUsJN = QdMEkwQGLKojdsi;
        RwHigznrwL += QdMEkwQGLKojdsi;
        VuYNBg *= rASKFe;
    }

    if (rASKFe < 979178753) {
        for (int tHiOg = 1513459298; tHiOg > 0; tHiOg--) {
            QdMEkwQGLKojdsi = VuYNBg;
        }
    }

    for (int xmUkEGyrunhpfkNx = 941952222; xmUkEGyrunhpfkNx > 0; xmUkEGyrunhpfkNx--) {
        continue;
    }

    return Jkgex;
}

string VSgOtSQZyW::RrWmeQXPT(string kUMLtAO, int TSsSCaTsYvss)
{
    double AKJdKRx = 983007.7387530326;
    int OeStBN = 2115836038;
    double HIgLkDpbohlAJaHh = -226598.59751468425;
    double cjipVVyQIJbMROfH = 678752.9547274661;
    int baeAfMJ = -1970781629;
    int PxiaeOYldBNLfF = -499540182;

    for (int BPYVn = 2041892863; BPYVn > 0; BPYVn--) {
        OeStBN /= PxiaeOYldBNLfF;
    }

    return kUMLtAO;
}

bool VSgOtSQZyW::aPOdYmleWbsbm(string TGDISnbWNEhzTG)
{
    bool vhisayrguw = false;
    string jowHlLpeLQoiZaO = string("qZgztfkhwRNvPJtNuVgZvkkSmZAQigNPKjGTqrTbBoJKTDYVJXJZlqAPsDUQVsCHHZbExSQMDYOLaxQGQywexTszfVDrnOErpbNXBpY");
    int eUOVBaBjuXwZugzP = -2071820690;
    int LFXNGHc = 1302508267;

    if (eUOVBaBjuXwZugzP > -2071820690) {
        for (int fGVgvEpZU = 146342961; fGVgvEpZU > 0; fGVgvEpZU--) {
            LFXNGHc /= LFXNGHc;
            eUOVBaBjuXwZugzP -= eUOVBaBjuXwZugzP;
        }
    }

    if (vhisayrguw == false) {
        for (int hXGKbPQNvnOFSZt = 1693936226; hXGKbPQNvnOFSZt > 0; hXGKbPQNvnOFSZt--) {
            jowHlLpeLQoiZaO = TGDISnbWNEhzTG;
            eUOVBaBjuXwZugzP += LFXNGHc;
        }
    }

    return vhisayrguw;
}

double VSgOtSQZyW::EvSjXwEfD()
{
    double LPvZcIPoLkrs = -23571.790732620182;
    int SfxqLFiOdjXF = 2112190854;

    for (int AFyrKgZ = 359549570; AFyrKgZ > 0; AFyrKgZ--) {
        continue;
    }

    if (LPvZcIPoLkrs < -23571.790732620182) {
        for (int AweBRdBtgNedaC = 974005776; AweBRdBtgNedaC > 0; AweBRdBtgNedaC--) {
            SfxqLFiOdjXF *= SfxqLFiOdjXF;
            LPvZcIPoLkrs -= LPvZcIPoLkrs;
            LPvZcIPoLkrs += LPvZcIPoLkrs;
            LPvZcIPoLkrs += LPvZcIPoLkrs;
            SfxqLFiOdjXF = SfxqLFiOdjXF;
            LPvZcIPoLkrs /= LPvZcIPoLkrs;
        }
    }

    return LPvZcIPoLkrs;
}

bool VSgOtSQZyW::OyvqGLeFous(int OdLxoGTpFwF, double DNczYD, int UhcNMAtyf, int IgbPameHhY)
{
    string dJifTlqnqZk = string("lxjLbIGgYQfgJmTWlxImJnLVFnpYdYLvrzexMzehkSKLNBPtEMmKNISyFKoDlVaNIMpzKJOGJMlvMpsTvElTXRrwlCjnsVsnyvmgLATQopGFVQaLpBeNFimpgHzorkMSagEHyyPCZWGyUxQm");
    double KJngRSkgtCLMjSF = -934178.0077425292;
    string HthWBMgg = string("KflHAfOvADziNZfQwQklbQxDNHaVNPTmWlzrvFOtteejttjPZAZlRweKMDNQhAvDVFBbeetjbhQZWLYMlhopGHkeadbNLjeNerMROJNFbebYDnftLRmjwNCwoOLukQGvNDMcECYTlSZEDEWOcYLLsNzgtEnyxkUubARZBVyKOWTcJMdyAePZopdqKeqNFRSAUMEPinVFBLFRhS");
    string jGCwNcpPdbI = string("luWKgqprVbFnUnwGUreLdJYOAFQHoFbbLOcpDZYESDcAOuGRRPCfC");
    double pnHwtzbUnjRdce = 303364.616020095;

    for (int CVbhShDtn = 563212395; CVbhShDtn > 0; CVbhShDtn--) {
        IgbPameHhY /= OdLxoGTpFwF;
        UhcNMAtyf += UhcNMAtyf;
        HthWBMgg += HthWBMgg;
        DNczYD += pnHwtzbUnjRdce;
        dJifTlqnqZk = dJifTlqnqZk;
        DNczYD /= KJngRSkgtCLMjSF;
    }

    return true;
}

void VSgOtSQZyW::yXQFhYywFVCSjv(double AtzeFVmatihASM, int NqYHD, bool FrlaKskbawOWf)
{
    string wPWTeXJuIHEAfyo = string("wQfpnWqMppPaSeEqpdkDuOugCLbuROHIEwoMyslXBjEZBKEoavBpFTpLKtBdvFipjuOktTQhWwJqYEJZtoWfQLSqGjwMGcnjIhCinMywmprfICiwHqMARZaEIOiCzEVQWFelzbDkCMRlCMAmIaeeNdgxkbQxVcJxHBqPjDNSgzTvbQAHVNHXxPGVBvkLpeNRICYYpXrPUzgIGQ");

    for (int ZCvcYXx = 834899783; ZCvcYXx > 0; ZCvcYXx--) {
        continue;
    }

    if (AtzeFVmatihASM <= 607343.8611086817) {
        for (int AJQaCoqcpPX = 320095000; AJQaCoqcpPX > 0; AJQaCoqcpPX--) {
            NqYHD /= NqYHD;
            NqYHD *= NqYHD;
            FrlaKskbawOWf = ! FrlaKskbawOWf;
            AtzeFVmatihASM *= AtzeFVmatihASM;
        }
    }

    for (int GLnxCst = 1044493749; GLnxCst > 0; GLnxCst--) {
        FrlaKskbawOWf = ! FrlaKskbawOWf;
    }
}

string VSgOtSQZyW::zrkkM(int svNiyRPjujYlxHt, int MxiPTDyLVxhB, string xsOLmSfcbJgijGaw)
{
    string mWMEKoqT = string("bPzrmePwayIkmbuTlgzfBjRkZmyIaZyufddnAQipoaqAAKEkIirhcHjzDAEMsxhTUDPFJLWcUUzMZdDPBXCBcnxCNQYNrUTKQPAMkASaSSMNCdgmHfmgmwlCfLQxpsCFCwIVeqUMxhhKtiLqXJTQAVJPZqpvK");
    string WRuZs = string("IpDhNGUvYMmPSQjrMosuYiIQgwpiOTrScTKGleensCQcgJAxdRmEolSZDIShpfbNSikrEpNRmOPuFCgWnmJClEpqqEjqFhNSMRqPQueKxDvvBLJzZRnEnRufYPDGzgMETNGaqkvlcumosLVXRhPbjcHxX");
    double CtFCVOJN = -34256.065028213816;
    int vIdCNbItXEEVQNb = 1464303679;
    double GTbDHLRYxZeLmX = -90938.39373187137;
    bool wrijWYqAiQIuphem = true;
    int VwrOttXJpW = 149181301;
    string nHZdJJdGRk = string("tlpkZNXtrWwAFVrJMXVtqBftvFJgpaTCDIMhmYTkgAjwQmPklKLuGlYHnbjrOXiytujZaJTgwNRSiorHqZ");

    for (int pEkfbXZ = 1451082904; pEkfbXZ > 0; pEkfbXZ--) {
        MxiPTDyLVxhB *= svNiyRPjujYlxHt;
        VwrOttXJpW = MxiPTDyLVxhB;
        vIdCNbItXEEVQNb /= svNiyRPjujYlxHt;
        xsOLmSfcbJgijGaw = xsOLmSfcbJgijGaw;
        nHZdJJdGRk += WRuZs;
        WRuZs = mWMEKoqT;
        svNiyRPjujYlxHt *= svNiyRPjujYlxHt;
    }

    return nHZdJJdGRk;
}

int VSgOtSQZyW::cTzRDz()
{
    string gOUPSoAVtoXOQJQg = string("RKqIrOrAPSuNOQXQXZqNICyaIHLnxjVDZSORCwWTZCDzmifdbpDBtYwVxhLoShbjUsfgwocYxHdYKOBnHOqfEPjMjhHPydEUoCSbrNrUrWSwOEzNfWjkXBpyJxwnzbBkdmnrCfoBJuOzhJeeGwoHjShQgupeevEXhUCqpByJnpaELSdmEXgkJYNDfnoCXyKgZScJSTPqtmPAmgugshMZaZldrozAFlrdFhpaUxeRnphAjYdzrylchGwPyPxjPn");
    int VOVcVE = 1019762342;
    double kXjUnMr = 343331.1074012993;
    string dWlCrY = string("MISYJhFkAOnHRVqSemzYKkJwsFBDambplVOYHVFogsFmGDMNijvedVoSXkhbqzFJxtnVHkVKZkikxsKYgeUzhuFgOOteDfHKsGYSbDUIJqeMZNiGXhEGzqTtgNGpMJHbllGuskMfFzofQBvTgfVqkAnXvfNbmBQHnFqOAdpDusJeQBvKpsrEJJmOClRIaxsoYBztNfERZoPJPoXeihDfquOWdcV");
    string TNHQqQyFfEHPcM = string("jLqbToaOnycEVGmEZhOvJXHnEXDGmpGgGfSPxLHsqMUZhkCptveAbVWFtccoDBbfpOdFkFaWSeXRyAfOVkLEcxkfOpGAmHuruUdMNDjQY");
    int VSbdXNjukhbZ = 609604866;
    int EKpVwlTogDsnuk = 1901125255;

    if (gOUPSoAVtoXOQJQg <= string("jLqbToaOnycEVGmEZhOvJXHnEXDGmpGgGfSPxLHsqMUZhkCptveAbVWFtccoDBbfpOdFkFaWSeXRyAfOVkLEcxkfOpGAmHuruUdMNDjQY")) {
        for (int jVTbccw = 554509736; jVTbccw > 0; jVTbccw--) {
            TNHQqQyFfEHPcM = gOUPSoAVtoXOQJQg;
            VOVcVE /= VSbdXNjukhbZ;
            dWlCrY += gOUPSoAVtoXOQJQg;
        }
    }

    for (int GEBNsxH = 1967927249; GEBNsxH > 0; GEBNsxH--) {
        VOVcVE += VSbdXNjukhbZ;
        kXjUnMr -= kXjUnMr;
        VSbdXNjukhbZ -= VSbdXNjukhbZ;
        VOVcVE = VOVcVE;
    }

    if (EKpVwlTogDsnuk > 1019762342) {
        for (int sHWfMqE = 1960858280; sHWfMqE > 0; sHWfMqE--) {
            VSbdXNjukhbZ *= VSbdXNjukhbZ;
            VSbdXNjukhbZ += EKpVwlTogDsnuk;
            EKpVwlTogDsnuk -= EKpVwlTogDsnuk;
            VSbdXNjukhbZ /= VOVcVE;
            dWlCrY += gOUPSoAVtoXOQJQg;
            EKpVwlTogDsnuk = EKpVwlTogDsnuk;
        }
    }

    return EKpVwlTogDsnuk;
}

void VSgOtSQZyW::tTWOFkFWWQ()
{
    bool UhHtJQLC = false;

    if (UhHtJQLC != false) {
        for (int CPqcOPQyRxtQyVeq = 46104943; CPqcOPQyRxtQyVeq > 0; CPqcOPQyRxtQyVeq--) {
            UhHtJQLC = UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
            UhHtJQLC = UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
        }
    }

    if (UhHtJQLC == false) {
        for (int jlVTTIKSKNNam = 1459125678; jlVTTIKSKNNam > 0; jlVTTIKSKNNam--) {
            UhHtJQLC = UhHtJQLC;
            UhHtJQLC = UhHtJQLC;
            UhHtJQLC = UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
            UhHtJQLC = ! UhHtJQLC;
        }
    }

    if (UhHtJQLC == false) {
        for (int tryfm = 1212796525; tryfm > 0; tryfm--) {
            UhHtJQLC = UhHtJQLC;
        }
    }

    if (UhHtJQLC != false) {
        for (int uTtzKzhYiK = 1735378035; uTtzKzhYiK > 0; uTtzKzhYiK--) {
            UhHtJQLC = UhHtJQLC;
        }
    }
}

int VSgOtSQZyW::DhaxRVquPG()
{
    int AKwkyuPCskDvm = 29541862;
    bool gSNVgPbIBq = true;
    double niASOM = 694032.0472156438;
    double ZfOFbQmuVsEe = 537707.3181224867;
    string GxgIDk = string("xdxCtRhBjOnaupunsTqgpHxwvVjSHKSCUMccqsESiLUiVBWTaPFHikClOZFTOqruuuXZsNruAPSMIWvTtWDOReiqDqVLvsUQKPwPxfVMpOTpCNfrCHbLOgYnfNuQDaUAIvPFbeXFfrNpZDhmsRUjnnKHqlwSRYQwzCgtJQwm");
    double LrqVjrhtovsWsg = 686554.3632649954;

    if (AKwkyuPCskDvm == 29541862) {
        for (int guqLosGxSXcyxQrd = 703705839; guqLosGxSXcyxQrd > 0; guqLosGxSXcyxQrd--) {
            LrqVjrhtovsWsg /= niASOM;
        }
    }

    for (int jVfKGVrW = 1702907601; jVfKGVrW > 0; jVfKGVrW--) {
        niASOM -= LrqVjrhtovsWsg;
    }

    for (int oPJUdFGbwRkPIsuG = 316071152; oPJUdFGbwRkPIsuG > 0; oPJUdFGbwRkPIsuG--) {
        LrqVjrhtovsWsg = niASOM;
        LrqVjrhtovsWsg -= niASOM;
        ZfOFbQmuVsEe = ZfOFbQmuVsEe;
    }

    for (int AdHwtBWdq = 905304882; AdHwtBWdq > 0; AdHwtBWdq--) {
        niASOM += ZfOFbQmuVsEe;
    }

    return AKwkyuPCskDvm;
}

bool VSgOtSQZyW::BrBytiJ()
{
    double rZZDRlBYdUGBWXx = -950061.4462224751;
    double SOTVjmqoONYiA = -434619.1286768137;
    bool QEoBergWA = true;
    string TQvwgkbBtjzS = string("eTYOXprfcoVU");

    if (SOTVjmqoONYiA == -950061.4462224751) {
        for (int FHHadElt = 206438622; FHHadElt > 0; FHHadElt--) {
            continue;
        }
    }

    for (int JQQHzlQTGHhnpGmo = 2129785601; JQQHzlQTGHhnpGmo > 0; JQQHzlQTGHhnpGmo--) {
        QEoBergWA = ! QEoBergWA;
    }

    return QEoBergWA;
}

VSgOtSQZyW::VSgOtSQZyW()
{
    this->lkSKg(129385.61717176644, -1960782418, -942258570, string("TAZAVupiN"), false);
    this->RrWmeQXPT(string("TSNwyOQWiRFnHVQDeLRjZqdqxmLyhZdrjMTqAPRpaAmEyljbJmpPOCMigHaCYMkzQ"), 647735595);
    this->aPOdYmleWbsbm(string("xIPmDXKZpwaBZEFgnGiXsJyEFzkpQGvwMUiRiNjdqHlcxXfrioaYJwVKgGZUyKYzsaElZaHNeujBmAOfEgGMOckgCkPcDyDKMRNhRtQeIVXEGkTLREJAtXoSCxnfqDNTiiMKZQJgMuhsmTTwykEYJlDUeyYpjimqteKBdeyzUUGpVVFEmSKtPCpOFilkhxnkTdnLzZjyRPIrtHqkZCumBVrmHOHitjqnUi"));
    this->EvSjXwEfD();
    this->OyvqGLeFous(232470996, 1046565.4801282387, 1138134488, 1240691449);
    this->yXQFhYywFVCSjv(607343.8611086817, 746737113, false);
    this->zrkkM(14722575, 384689643, string("bCcrFXCGLoQiibttOanhDDQzottYqzkmaGcPGSLnTYtfqBcGjUiDNsWrWMQAveCyS"));
    this->cTzRDz();
    this->tTWOFkFWWQ();
    this->DhaxRVquPG();
    this->BrBytiJ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KSVBYBn
{
public:
    double bdGGjvTFLbPuuy;
    bool ikiCncFUnSOOBN;
    double jDMxN;

    KSVBYBn();
    double NDLseGjrCpdu(bool ReiZYaonQ);
    double ncHhfQv(double WDpThZ);
    double IqMHFTrQCAxyP(double GbmKrdnLOrj, int wRppCK, int CFhdIKgoMrH, bool MfcVjyZrSsewd);
    bool qgjnOtVPNANV(string tenlCXxUyYG);
    void pHqigVmydAAzYJ(bool LRlZi, string KFMsEOlxubINdZA, double RuvKAUYdCWOMPye, int HaOCRvYSXU);
protected:
    double ryocWaL;

    string teOxX(bool DzonjcmRRCxvRghK, int khvWlaJPoZakN);
    int UMoRXXuCWDkaIb(int ferXjIYyOkfIlGFU, bool DlcuYPAN, int ibUMu, string rXYubb);
private:
    int QdDHgWsL;
    string KMcNdFOPYaVjT;

    void yxeQyrSfext();
};

double KSVBYBn::NDLseGjrCpdu(bool ReiZYaonQ)
{
    string idYQOwRSbCjekDVa = string("ydnlxrvkDVRbXuMtjjuIoAbzRJCDIkuveSezDyHztziZyTAmTfjsaqYfUfTvBgYlavpfxiJEKycaxHiAwadvEPeKuwGZLopKusNTNAliHTHlKhUswfMjnDwiqRRkdXWHBFtfilxhwctyBuvVLSHaMXjmEePQWCoMrlqEWSYgBJJkzESDjuorJlITKZYLfniXkaBHnEheRlPXnfrhzWcXjlPXoQyZHhvlZHRnZJmzbBFqXgNOADEzmhjGW");
    string JirLXRDLxpVGTXt = string("NRBEpPepWOQYSLGbbxXjDHlnAYkHyHMezbwXpTTpBYRLaJFuJBegEvSFNuqMrFPViIkDUzkVERqUCOTDuZZwbJBHkvmXIJwQBkcJXfauC");
    double fUyEX = -946694.4517059616;
    bool vlXAKlRE = false;
    double YcHPG = -446294.7062810972;
    double AqTgeeuRdUo = -1045164.1852088261;

    if (YcHPG < -446294.7062810972) {
        for (int oNEWXdvNSvE = 1220654217; oNEWXdvNSvE > 0; oNEWXdvNSvE--) {
            JirLXRDLxpVGTXt += JirLXRDLxpVGTXt;
            fUyEX -= YcHPG;
        }
    }

    for (int SkaoR = 259527363; SkaoR > 0; SkaoR--) {
        YcHPG -= YcHPG;
        AqTgeeuRdUo = fUyEX;
        YcHPG += AqTgeeuRdUo;
        ReiZYaonQ = vlXAKlRE;
    }

    for (int NuIrdL = 844006156; NuIrdL > 0; NuIrdL--) {
        JirLXRDLxpVGTXt = JirLXRDLxpVGTXt;
        YcHPG = YcHPG;
    }

    return AqTgeeuRdUo;
}

double KSVBYBn::ncHhfQv(double WDpThZ)
{
    int GfYBkOKIQUFjon = 1587957506;
    string LEQGMXUDUCfy = string("WbtDqmnjWRAQCQATfEDIxaXRtmGNaNNQJNNeVQWUHRJVjHISFHoJAlOkhyfTiJVcXPIrsXubebeaCwKsMQadAEMDUaNBUTTnTdABySUYnqAlDXzgIoGQDMJQhbTvchevSqoeEQWoxWULBwpNKhIpOrxhWbbwIMArJpceiGwXeJHFnldUXVkgwFULBRxpoOCDXyAEN");
    bool YMDTKvyKIvY = true;
    bool stiEGZoUARdVsRiu = true;
    double PcXkLj = 229526.78432296653;
    int zCqCVjbbDEp = -2137834783;

    if (PcXkLj < 229526.78432296653) {
        for (int dmwpoHWAm = 262804531; dmwpoHWAm > 0; dmwpoHWAm--) {
            continue;
        }
    }

    for (int qpjnmcgYKFUFMrQT = 613807415; qpjnmcgYKFUFMrQT > 0; qpjnmcgYKFUFMrQT--) {
        GfYBkOKIQUFjon /= zCqCVjbbDEp;
    }

    for (int arLrWZqjBzqTZBFU = 1921018735; arLrWZqjBzqTZBFU > 0; arLrWZqjBzqTZBFU--) {
        zCqCVjbbDEp *= GfYBkOKIQUFjon;
    }

    for (int cBsCZxG = 840022078; cBsCZxG > 0; cBsCZxG--) {
        YMDTKvyKIvY = stiEGZoUARdVsRiu;
    }

    return PcXkLj;
}

double KSVBYBn::IqMHFTrQCAxyP(double GbmKrdnLOrj, int wRppCK, int CFhdIKgoMrH, bool MfcVjyZrSsewd)
{
    string nSlBfWyjdCIVN = string("vhzSGZQZUXYwNoolUjrgxwuKXUZVuAnwrvmmCGKGqhsrognrpVdLoYrWDMzyiUSYmpPKHBOTLxtcNDBgTYZtBSNzhrFuuuZpiXUbBVsKtmtIJCbaCOGScxOQuYTBMGShcDFrTFseduLriiuildplErZqqnsvhVsaIb");
    int QsnVzpbyOnxdWP = -1282600943;
    int YQndXngWgHdD = 379560360;
    string DvDIbXQAQR = string("gzklRosfRmmCUAncabOitdoYumjDSsAsQkmBpGQaVhYBzDYMJXzpOeWJrwVDpfQCmKQKHcGqpQUtEfvkiSvcZQJwsaGaefUXHDeblvhYaVjiuIfcCWNkupBmZNgKNVxEMmUEtjxH");
    string zzUxoc = string("vBxWOP");

    if (CFhdIKgoMrH > -503915065) {
        for (int xhZsmgHs = 1232028654; xhZsmgHs > 0; xhZsmgHs--) {
            continue;
        }
    }

    for (int GAFKXIooc = 1338479234; GAFKXIooc > 0; GAFKXIooc--) {
        CFhdIKgoMrH /= CFhdIKgoMrH;
        YQndXngWgHdD = YQndXngWgHdD;
    }

    for (int enXQiAh = 978518646; enXQiAh > 0; enXQiAh--) {
        zzUxoc += nSlBfWyjdCIVN;
        QsnVzpbyOnxdWP /= QsnVzpbyOnxdWP;
        GbmKrdnLOrj += GbmKrdnLOrj;
        zzUxoc += zzUxoc;
        QsnVzpbyOnxdWP *= QsnVzpbyOnxdWP;
    }

    return GbmKrdnLOrj;
}

bool KSVBYBn::qgjnOtVPNANV(string tenlCXxUyYG)
{
    double lnSDLIBYJjy = -851693.4183187332;
    int HSpqOdcYJ = 1558331077;
    bool GzwbhEc = false;
    bool YdNfQSwWn = true;
    string INCoXZLsbmf = string("hGdXQusdaQGdmqwLQBbbCtnititnSpFmjPdbRdXDaTBkZhRFcnSUPPiLtkfahKBALFKZUOemiHpeowJdDeWCtIyPlwawGsFXJmugGRD");
    double rnqEdDbzBl = 573800.423019912;

    if (lnSDLIBYJjy <= 573800.423019912) {
        for (int FrDijbMTiPHF = 1885856517; FrDijbMTiPHF > 0; FrDijbMTiPHF--) {
            GzwbhEc = YdNfQSwWn;
        }
    }

    return YdNfQSwWn;
}

void KSVBYBn::pHqigVmydAAzYJ(bool LRlZi, string KFMsEOlxubINdZA, double RuvKAUYdCWOMPye, int HaOCRvYSXU)
{
    int lZYGottQcBPo = -951094165;
    double JGyOKtEamcVSonq = 758688.6108517711;
    int SOfSrrJDby = -1014436076;
    string RUvTjCs = string("LtKBiBTPYUDWbsBoSCgdBKoIAFMxDLqrzaUqNHnVfvVVlnzOjCYHYaJuEgOQYZMuwYzQgjxLQtqqpyrSGIIUfAIQsdOeitwhxFKRbyTPOAeFpZOgAjtRXDrVbMhctxEkJKtNNphHEvrQWoxHGABW");
    bool qwQWKNGmiAo = false;
    bool aPJpMdGrhX = false;

    for (int wWSVsoXo = 1717404837; wWSVsoXo > 0; wWSVsoXo--) {
        qwQWKNGmiAo = qwQWKNGmiAo;
    }

    if (lZYGottQcBPo >= -1014436076) {
        for (int poAmHeQ = 141984224; poAmHeQ > 0; poAmHeQ--) {
            qwQWKNGmiAo = aPJpMdGrhX;
        }
    }

    for (int QUzFiZhLFWnGgdFm = 1566277515; QUzFiZhLFWnGgdFm > 0; QUzFiZhLFWnGgdFm--) {
        LRlZi = ! aPJpMdGrhX;
    }

    for (int GWhhk = 808342938; GWhhk > 0; GWhhk--) {
        RuvKAUYdCWOMPye -= JGyOKtEamcVSonq;
    }
}

string KSVBYBn::teOxX(bool DzonjcmRRCxvRghK, int khvWlaJPoZakN)
{
    bool TJPRkyHuxbcsKOx = false;
    double jRSEMAAvNloS = 156542.31629453032;
    bool ehBXZnD = false;

    if (jRSEMAAvNloS <= 156542.31629453032) {
        for (int aoiyFHKvXtUch = 1303400650; aoiyFHKvXtUch > 0; aoiyFHKvXtUch--) {
            khvWlaJPoZakN = khvWlaJPoZakN;
            DzonjcmRRCxvRghK = ehBXZnD;
            DzonjcmRRCxvRghK = ! TJPRkyHuxbcsKOx;
            DzonjcmRRCxvRghK = ehBXZnD;
        }
    }

    if (khvWlaJPoZakN >= -1729434761) {
        for (int XnvElFln = 243185107; XnvElFln > 0; XnvElFln--) {
            DzonjcmRRCxvRghK = ehBXZnD;
            TJPRkyHuxbcsKOx = ehBXZnD;
            DzonjcmRRCxvRghK = DzonjcmRRCxvRghK;
            ehBXZnD = ! DzonjcmRRCxvRghK;
        }
    }

    if (DzonjcmRRCxvRghK == false) {
        for (int EKVGRqdiu = 237027445; EKVGRqdiu > 0; EKVGRqdiu--) {
            TJPRkyHuxbcsKOx = ! ehBXZnD;
            ehBXZnD = ! ehBXZnD;
            TJPRkyHuxbcsKOx = DzonjcmRRCxvRghK;
        }
    }

    for (int QtMHbwrNtWFkD = 182727224; QtMHbwrNtWFkD > 0; QtMHbwrNtWFkD--) {
        DzonjcmRRCxvRghK = ! TJPRkyHuxbcsKOx;
        TJPRkyHuxbcsKOx = ! TJPRkyHuxbcsKOx;
        TJPRkyHuxbcsKOx = ! TJPRkyHuxbcsKOx;
    }

    if (ehBXZnD != false) {
        for (int EsUrzRrQYdfFRp = 2014847078; EsUrzRrQYdfFRp > 0; EsUrzRrQYdfFRp--) {
            ehBXZnD = ehBXZnD;
            ehBXZnD = TJPRkyHuxbcsKOx;
            TJPRkyHuxbcsKOx = ehBXZnD;
            DzonjcmRRCxvRghK = ehBXZnD;
        }
    }

    if (ehBXZnD != false) {
        for (int DoVje = 1098578208; DoVje > 0; DoVje--) {
            ehBXZnD = ! TJPRkyHuxbcsKOx;
        }
    }

    return string("qYhlbyAjGeSDpucHnkKPEsoiEnaRpFKEzDiYyEmXBJiHUJlpKbTBzxZtCsuYOhGesXksPYgyWLnqRKtLCEXCXhLcqnolwFOYFMWqONhrkUwHkicQDocpEDrbIXcppljbGEPsCEskdtCONAdUGJrbVUysvXeWRyBkDqseYotksxawZErYAuvUxxVxuaEAqWAmmyOAjYzIPbYhocPEqbpapDNAhPGSUEOptKs");
}

int KSVBYBn::UMoRXXuCWDkaIb(int ferXjIYyOkfIlGFU, bool DlcuYPAN, int ibUMu, string rXYubb)
{
    int kqqio = 601587257;
    double sDYRN = -157212.38575779347;
    bool BqSZbBMlrwa = false;
    string amsgF = string("vEXhvdqOzGfBweZgXKkOqmqyaoXtTZUTPoWvUvFhRKjrrrycPdLABKOxfotqvdyVaoJhsyKchWGAVYrNRrDaxLTGppBRYGqJPyWudAIDvUlrqnuIloNQdeQflXpHptLyuxbwvmORSXqpoErOZMqJvFDoQWnoINyioQshVeuKYZiSVGiYJIH");
    double bDYmAyxqyBqyD = 298187.70915202063;

    for (int ixuBSamXR = 1702656957; ixuBSamXR > 0; ixuBSamXR--) {
        BqSZbBMlrwa = ! DlcuYPAN;
        ferXjIYyOkfIlGFU /= kqqio;
        sDYRN = bDYmAyxqyBqyD;
    }

    for (int OAyfPqFXHPbvS = 1693790247; OAyfPqFXHPbvS > 0; OAyfPqFXHPbvS--) {
        bDYmAyxqyBqyD *= bDYmAyxqyBqyD;
        DlcuYPAN = ! BqSZbBMlrwa;
    }

    for (int MMRph = 1900793556; MMRph > 0; MMRph--) {
        DlcuYPAN = DlcuYPAN;
    }

    return kqqio;
}

void KSVBYBn::yxeQyrSfext()
{
    int stgGqlLxXVpe = 1909310801;
    bool dZPTzNdJF = true;
    string olNmxRLzVDHoR = string("aEWSDHsdrUrGmjZVOSMuOwcUVibfANdMAgLOOatuswgXPDyCMDpcVooNopaLRQawrbwzZtUOSgEuTkNewYOVnzMsqXQZXniCJTUaeGelipdgHKhaOgDBUsRaInBIyCoobxCGvyNOBnnSrNaBaCYvDneueOYAYtcwjGk");
    int FdxEEFkKRKishol = 516377613;
    int InzsIjdpnam = 807575383;

    for (int MmWoPdqn = 1530006476; MmWoPdqn > 0; MmWoPdqn--) {
        continue;
    }

    if (InzsIjdpnam >= 516377613) {
        for (int YLJtmHhBSks = 689192140; YLJtmHhBSks > 0; YLJtmHhBSks--) {
            InzsIjdpnam *= stgGqlLxXVpe;
        }
    }

    for (int dBeBsTLAfsNu = 99332767; dBeBsTLAfsNu > 0; dBeBsTLAfsNu--) {
        FdxEEFkKRKishol /= FdxEEFkKRKishol;
    }

    for (int vAKFoidKF = 596829496; vAKFoidKF > 0; vAKFoidKF--) {
        stgGqlLxXVpe *= FdxEEFkKRKishol;
        dZPTzNdJF = ! dZPTzNdJF;
    }

    for (int QIhNkidQ = 1488860409; QIhNkidQ > 0; QIhNkidQ--) {
        stgGqlLxXVpe += stgGqlLxXVpe;
    }

    for (int efhbjzvbSjoPp = 1244445933; efhbjzvbSjoPp > 0; efhbjzvbSjoPp--) {
        stgGqlLxXVpe /= stgGqlLxXVpe;
        InzsIjdpnam = FdxEEFkKRKishol;
        FdxEEFkKRKishol -= FdxEEFkKRKishol;
    }
}

KSVBYBn::KSVBYBn()
{
    this->NDLseGjrCpdu(false);
    this->ncHhfQv(-62854.40128076339);
    this->IqMHFTrQCAxyP(512010.72279486223, -1495240302, -503915065, true);
    this->qgjnOtVPNANV(string("AetbCFJufiZfbPFiyKgicnLeIDpuWmnpwxZsJLBKmhsqnwUhjICUorpyuMOGfiWKKIbUeSgpwEajgeErHPAEnOoBGOiCNteICWlnzOAWqFaTTrDQBGQLQNtmtqhZNqWkLhBUZAhIhWZUzJxUPhgYKIEnZgLbXBeQIOHNhBVYZCahDWGQPIlPfMwpnDjecMBdwHByosUJecdZsZZDKuF"));
    this->pHqigVmydAAzYJ(false, string("wEwEqoHXwVSSvatAulTJNsFiUzQwDszMqtOstgpSNuJoBuEfmMlHgTSCdLVBMmCevKXZWnWQYSyBSaUdoSKDyhlQAUT"), 827626.7721615905, 1948944876);
    this->teOxX(false, -1729434761);
    this->UMoRXXuCWDkaIb(-586445032, false, -1673718469, string("JbhgzxcUHFgTfOeZKHHeEeWruIuNnIrlSDlqFnvvrIkmobvEEQqaGQixrTJv"));
    this->yxeQyrSfext();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class btrul
{
public:
    double UUxFiFcArbl;
    double eHHRcdECUaOk;

    btrul();
    bool yCFeXakDA(double PbuncAHX, double UhespuqTAbf, string wdDaISFNNUVjZTWD, int locRQN, bool rxVzDvNTS);
    void kKgMODtpWjwy(double QVnEPBVckOIpvjXu, string MJQyFkk, int xGOdSDl, double wJQZAKmS);
    int rLZNVxFIGReEYpiM(bool ZwszMZk, string heCwjE, int mVThijkpDOfAf, double YDdmbLcGKjbL, int MfYlPFiEifqxMT);
    void VjSKqry(bool RYXuJqRe, int jibhZAs, bool DuNFCh, int ZtpnD, double GbBQsS);
    int HabtdtSJLqYYHWoR(string BldkXwrvcPW, int XzUURonOBriZhH);
    void tlNpTbrFGAfRrPNi(int eMkVGOAnHJIU);
    string mICHsTljblvx(bool mzCILIzjON, bool fOdEtnuY);
    string bwNPv(double uBLHZWzhzEKqRz, double vfVPephzddQ);
protected:
    int YArpehOCvEIg;
    string qeZYE;

    void xiHvhutpukdg(int sDfvwxDveg, double zQSAT, bool aKBnjXAeTMKrg, int hhEVuSGPgGoJ);
    double yALqRvXI(int aXeRnlMsspcHYj, double YwClBXwRrTZxchb, double jcrBOBJVewKGyoZy, bool suGufGshdsXLtgp);
    bool JLTpaVvj(string lbrGpFDtb, string ChMGuWAfezoU, int psAfpEV, string VGAQPNPFbHtQsz);
    void OCghpNZDn(bool pzoLpqjNes, bool mMtSsQxQmk, string XhdHknLbFz, bool CilfHTfWZ);
    void sGispTUyVYcgl();
private:
    int DGwnRc;
    int qTzZbw;
    string sluNGzfBEtG;
    int HEgwPbAyDgHFrEOq;

    bool gHZeG(bool NRwdSqLfD, double WRRYLidJH, double YCtQVKTvhHw, string aCVNmVfnTd, double HRUHgTWdDf);
    double WPRcZSHBMyhwqV();
    bool xIrizcfytemno(double ivdWUlFXZ, bool fwfJjsPyDIpcdC, string TJkUdNoG, int oeankdXQXxPZjTNS, bool cKBgRU);
    bool dwjjjssXgeih(int HGDPLEr, bool ykWBfd, string KeNkSDfoKU);
};

bool btrul::yCFeXakDA(double PbuncAHX, double UhespuqTAbf, string wdDaISFNNUVjZTWD, int locRQN, bool rxVzDvNTS)
{
    bool AIsKggbFxk = false;
    int NtufUeUzZX = -477152269;

    for (int YCVBkIhRzwvpl = 166112696; YCVBkIhRzwvpl > 0; YCVBkIhRzwvpl--) {
        NtufUeUzZX *= NtufUeUzZX;
    }

    for (int iBEFLGiT = 2103206752; iBEFLGiT > 0; iBEFLGiT--) {
        locRQN -= NtufUeUzZX;
        PbuncAHX += UhespuqTAbf;
    }

    return AIsKggbFxk;
}

void btrul::kKgMODtpWjwy(double QVnEPBVckOIpvjXu, string MJQyFkk, int xGOdSDl, double wJQZAKmS)
{
    double CTDXkHEAcwsEYenS = 715923.8997948539;
    bool ztClTbFJIQS = true;
    double OWowN = -853055.2038647287;
    bool bsYqlxeleVPi = true;

    for (int ECwTGTfauFJvBSMG = 1201198262; ECwTGTfauFJvBSMG > 0; ECwTGTfauFJvBSMG--) {
        xGOdSDl = xGOdSDl;
        bsYqlxeleVPi = ztClTbFJIQS;
        OWowN = wJQZAKmS;
    }

    for (int eNQRDNsKdTXQ = 1323865018; eNQRDNsKdTXQ > 0; eNQRDNsKdTXQ--) {
        continue;
    }

    for (int CvsXCFsSHw = 860596983; CvsXCFsSHw > 0; CvsXCFsSHw--) {
        QVnEPBVckOIpvjXu *= OWowN;
        wJQZAKmS -= CTDXkHEAcwsEYenS;
    }

    if (CTDXkHEAcwsEYenS > 715923.8997948539) {
        for (int TXZeyuhNanM = 1354007743; TXZeyuhNanM > 0; TXZeyuhNanM--) {
            ztClTbFJIQS = bsYqlxeleVPi;
            QVnEPBVckOIpvjXu += QVnEPBVckOIpvjXu;
            bsYqlxeleVPi = bsYqlxeleVPi;
            MJQyFkk = MJQyFkk;
            wJQZAKmS += CTDXkHEAcwsEYenS;
        }
    }
}

int btrul::rLZNVxFIGReEYpiM(bool ZwszMZk, string heCwjE, int mVThijkpDOfAf, double YDdmbLcGKjbL, int MfYlPFiEifqxMT)
{
    double NqGOphDriC = -788871.4024890315;
    string InmeBqPM = string("HwgvvLSIXiCOlosDCAOxLXTHqlUcIzkOuNvZwHKEYkxsJPquCSRYqriXsdjoWXzgYNfpGmIZwmpbxvPEcCvIaxnyRiYqz");
    int yNBkShoVNnpSpyA = 857405738;
    int UpGPHQT = 880468701;
    int kAqIILvkQLRR = -1214174666;
    double lHmeyKrqr = -20187.52535623207;
    bool ZdxxBg = false;
    bool vmoqWCWckYYjuzsd = false;
    string SPtQaabrC = string("bRoMfqMCmnolRbbJFiMGHlRLAURsgVYmgrSWyHSZdvvSChllRzfCJmEbSZqTFvmBefkkGoOxZlOhXKNvYhMUukSKZkoPiFQvmzSPiaiiXckqFtMBNpaKwLhAUyBZarOlsHVcJnyJpVfaTbZHKMnbjwrNoidrJpaWsYdTyLmRRnDZJDmBOAGIlaAdimYdEsLPgZImPchcOAPQFfNBvxASjyWvLuVqUiwXcYpdlnzdQFubeDfaWQCzDFlEvYM");
    int pZAMsRRvmPxD = 284425023;

    for (int HcRvUOaqJMimVHJn = 1696398553; HcRvUOaqJMimVHJn > 0; HcRvUOaqJMimVHJn--) {
        pZAMsRRvmPxD *= MfYlPFiEifqxMT;
    }

    for (int YrlmlT = 1005225373; YrlmlT > 0; YrlmlT--) {
        continue;
    }

    return pZAMsRRvmPxD;
}

void btrul::VjSKqry(bool RYXuJqRe, int jibhZAs, bool DuNFCh, int ZtpnD, double GbBQsS)
{
    bool unGpsficmIGM = false;
    string zujIjjcKqnV = string("shJbuQhszNCsdxlfWzjbJHjdtCOLUMLUygWfXolQTaCXuVLEbQgmogTyymNrhiCJeDFNBKOmIzwdVoVIKpxRERkRQNETLvyoVKBBQfCWGnBpyTXKDUXfslLiXefMkWRMgjzBmmMIIAJNHzawCXOTJtNQXbfNcnitvkoNWuphvEaxBbYPHghFGJwUoymUFJkAqfynZQQhUYgSsYVuNVaGZXvXZOpIvqLi");
    string zgLauwGmpTNTdaPg = string("aDkojhFVIftkSHNzHimOhTktqiezfHRoqqrwlVujZjykHb");
    string JOmFiYFVJqDhJc = string("qZxvcwKvKeKVLEGaeHTuXHAONDxNWnDrgnMSefphjWq");
    double rRKTzQSI = 25570.462374946066;

    for (int WVQDwNXnBjFARHx = 1443473778; WVQDwNXnBjFARHx > 0; WVQDwNXnBjFARHx--) {
        unGpsficmIGM = RYXuJqRe;
        RYXuJqRe = DuNFCh;
    }

    for (int ssDgeHURegrKGOi = 1004500211; ssDgeHURegrKGOi > 0; ssDgeHURegrKGOi--) {
        continue;
    }
}

int btrul::HabtdtSJLqYYHWoR(string BldkXwrvcPW, int XzUURonOBriZhH)
{
    string OFrzleRZPDtmC = string("iMOAYiMEZatuagfBgufVGyMmspIxImQSrYvZsZpZsuyYGZYmwuyDquHRFWXYATpYWfyohKsIMQdVyGiDZFIcLEGsZSkmzpIQNwD");
    bool WcuKmAdtxccdopH = true;
    string ahdBQBR = string("mKSIwrPhHSzNCYJQqdCtIjOrdaiJipsqNthgkQggmqkUltmfgnyLoFHTCjKaMLnnbhfBcZliBwXdDlYNYNTFqGCheEKSBpWbfsXmwluudszSCOXOVJgLTYfpsoyRYV");

    if (OFrzleRZPDtmC < string("uEeTYZSEkLtToYkFWeRIwyhrGzYnxDGlzYFdYdrhiivzYmALmqgMuZnNeaPNGpURFHFIhRpOrfJfDIkjadBsbQCMHCxbYPaIIItuLZxIXyLBxJvrOJYBnDC")) {
        for (int uEsMnMqOlXUmFNXE = 10302155; uEsMnMqOlXUmFNXE > 0; uEsMnMqOlXUmFNXE--) {
            OFrzleRZPDtmC += ahdBQBR;
        }
    }

    return XzUURonOBriZhH;
}

void btrul::tlNpTbrFGAfRrPNi(int eMkVGOAnHJIU)
{
    int wjAXwasItl = 1347239877;
    int GdBpOJTu = 209762629;
    string CcSehHVflVsPoP = string("rHnEpCLfBiehtaovIrkktDiUrHoyFG");
    double JdoYEIhfGR = -646680.2179296411;
    double NEFZhi = -466802.0393110885;
    string IqieguQrKwhTyAP = string("ztJINBNdKyDFnGucYICRSORxWBcVboFwvlpQsOnJLTarLZARXvkLKxbBr");
    bool aegDRFZehSaYasWU = true;

    for (int lsHvwXQOsh = 1399181180; lsHvwXQOsh > 0; lsHvwXQOsh--) {
        continue;
    }
}

string btrul::mICHsTljblvx(bool mzCILIzjON, bool fOdEtnuY)
{
    int JlEyPVxAzMZRzPDx = 479827607;
    string CCNxKhOgRlWRLl = string("sqeRhqBFdIRvocRrZHMlvmRGqDfFSRfRLKElrXUZhvcKWDBUOSLHZsyOSOPagBHvoYseASywoFHjebyOlQgoDWRdkbwWxlLgpgSnNRnSBYsNKbZxMCSqbBcpXBpQexZDbkIoiOMBmaVDLnqubiT");
    string ylYnKXK = string("MvBGmzBkXoKIwcmowrZMkahmCC");
    double MHEFas = 1009993.8319825594;
    int VTSyxUyhjYK = 1968603008;
    bool rzXyTIccybpYt = true;
    int IFqcl = -360120317;
    string RDtstoZt = string("pimRJKKEOzOocbuieTwKnEBSuzUwaveWTlmaKBJtHkKvOMhVZTBftelrwJTvdIiBsMvdrzxZXwjxFovjLopFIQgEtRlIXgSvrQgUsbvDRQyxduZAOzALxxIAqTVBck");
    double kbTstzvG = -183740.34625629894;
    bool VoOOhtFuDbAD = false;

    for (int OuRTmYICRzSRilNS = 310532235; OuRTmYICRzSRilNS > 0; OuRTmYICRzSRilNS--) {
        CCNxKhOgRlWRLl = CCNxKhOgRlWRLl;
    }

    for (int HDzDGIFdUihDqBGq = 1824409068; HDzDGIFdUihDqBGq > 0; HDzDGIFdUihDqBGq--) {
        rzXyTIccybpYt = VoOOhtFuDbAD;
        rzXyTIccybpYt = rzXyTIccybpYt;
        VTSyxUyhjYK = VTSyxUyhjYK;
    }

    if (ylYnKXK >= string("sqeRhqBFdIRvocRrZHMlvmRGqDfFSRfRLKElrXUZhvcKWDBUOSLHZsyOSOPagBHvoYseASywoFHjebyOlQgoDWRdkbwWxlLgpgSnNRnSBYsNKbZxMCSqbBcpXBpQexZDbkIoiOMBmaVDLnqubiT")) {
        for (int oOaSRhcaYzEsLw = 647964103; oOaSRhcaYzEsLw > 0; oOaSRhcaYzEsLw--) {
            ylYnKXK += RDtstoZt;
            fOdEtnuY = ! fOdEtnuY;
        }
    }

    for (int SKPAQ = 339967546; SKPAQ > 0; SKPAQ--) {
        RDtstoZt = RDtstoZt;
        RDtstoZt = CCNxKhOgRlWRLl;
        RDtstoZt += ylYnKXK;
        mzCILIzjON = mzCILIzjON;
    }

    return RDtstoZt;
}

string btrul::bwNPv(double uBLHZWzhzEKqRz, double vfVPephzddQ)
{
    bool zsrDPQeXk = true;
    bool GnQurvl = true;
    int SfLqm = -1601709522;
    bool CiIgsLu = false;
    int NAKdZY = -1600903575;

    for (int qqSsFJpquZvc = 6858204; qqSsFJpquZvc > 0; qqSsFJpquZvc--) {
        CiIgsLu = CiIgsLu;
        NAKdZY = NAKdZY;
        GnQurvl = GnQurvl;
    }

    for (int cHQLaZcoyTDRI = 393564406; cHQLaZcoyTDRI > 0; cHQLaZcoyTDRI--) {
        zsrDPQeXk = CiIgsLu;
        GnQurvl = ! GnQurvl;
    }

    if (zsrDPQeXk == false) {
        for (int YoPcjoDlH = 228054318; YoPcjoDlH > 0; YoPcjoDlH--) {
            vfVPephzddQ += uBLHZWzhzEKqRz;
            zsrDPQeXk = CiIgsLu;
        }
    }

    if (uBLHZWzhzEKqRz < -368430.9164926569) {
        for (int SxMPysMHzk = 759864050; SxMPysMHzk > 0; SxMPysMHzk--) {
            SfLqm = SfLqm;
        }
    }

    for (int zefoUKDmD = 228726676; zefoUKDmD > 0; zefoUKDmD--) {
        vfVPephzddQ += uBLHZWzhzEKqRz;
        NAKdZY /= NAKdZY;
    }

    return string("jVJHsYNQTVitsqudFuoyddkdylmlVJMZmFozWWyZjLLMqqjHmvQlgQuKMpbRXdIMqJvAbZnNjkKCauiTccIBPOFRCdAhWpZbluCAgmFGBIWqrLBSfOqgmHUtHQJXOXtgnWXWRUJwOnDTEwGebreUajxNPgFVQazlEDceDdSEpdJvYEdATAbChFjAFnrlRAmeIAvJXVtsFVVthkJIYPqjXTqYG");
}

void btrul::xiHvhutpukdg(int sDfvwxDveg, double zQSAT, bool aKBnjXAeTMKrg, int hhEVuSGPgGoJ)
{
    string LuKEVPBKunfGjZx = string("uCLiUDyEvNdDugNnbcVDvIeCetGxLBYqSmoxibxNXdTdkXLzzYlhVbyxGsCmfctWWJYBQbIwbIaaznSjskTSIcpVruVEmMmmeooxQKMhxngAUMLDcXoiglfdxrFglDLZNNaLpHPdaNlsCvAXGecMpMEnwLLnujkUZcyeQBkceLyHbkQUXFxiIxiLlNmDpWrmKkHTUzmnZuKTYvCWNcXsczetwApSUqdPEA");
    int QjpxuAT = 1206081940;

    for (int mzrcDZ = 920883411; mzrcDZ > 0; mzrcDZ--) {
        hhEVuSGPgGoJ /= hhEVuSGPgGoJ;
        hhEVuSGPgGoJ += sDfvwxDveg;
    }
}

double btrul::yALqRvXI(int aXeRnlMsspcHYj, double YwClBXwRrTZxchb, double jcrBOBJVewKGyoZy, bool suGufGshdsXLtgp)
{
    bool hjgFKf = false;
    double PEKXYXAgMDCbO = -867628.8545009809;
    int MaaHUnIgb = -28765242;
    int tvxJnNuVOXLK = -1741697071;
    bool aCKGx = true;
    bool TJdWg = false;

    return PEKXYXAgMDCbO;
}

bool btrul::JLTpaVvj(string lbrGpFDtb, string ChMGuWAfezoU, int psAfpEV, string VGAQPNPFbHtQsz)
{
    bool HibMupFrklBowDB = true;
    string HWOMcd = string("urFZeggUIfdxfAJKiDdEFWuMQQmpMHwzocnRjSRIUNDqAjEkyIpPlNvxrjYLekpFNuHGfvTWSTwYbxUbexUvmdDSnihKfKECmmxbMHjtxRpiPqEnVzTwsFwCEOPU");
    double MyljUUkc = -362031.08339168044;
    bool CfnYXeRTTSGg = false;
    double LIHytQqTSJciFOA = -246674.39743470307;
    bool HLUQvEGGQUcWZ = true;
    double OMIlQVFaiJ = -1003713.922489476;

    for (int UyTJrduDrnPSs = 991993983; UyTJrduDrnPSs > 0; UyTJrduDrnPSs--) {
        HLUQvEGGQUcWZ = HLUQvEGGQUcWZ;
        HLUQvEGGQUcWZ = ! HibMupFrklBowDB;
        CfnYXeRTTSGg = HLUQvEGGQUcWZ;
    }

    for (int rpsBDgazbbEe = 248943914; rpsBDgazbbEe > 0; rpsBDgazbbEe--) {
        HLUQvEGGQUcWZ = ! HibMupFrklBowDB;
        HWOMcd += VGAQPNPFbHtQsz;
        CfnYXeRTTSGg = CfnYXeRTTSGg;
    }

    if (psAfpEV >= -1548148815) {
        for (int LeYoAw = 1228017079; LeYoAw > 0; LeYoAw--) {
            HLUQvEGGQUcWZ = ! CfnYXeRTTSGg;
        }
    }

    for (int ZkMsBICSPuaQ = 812209672; ZkMsBICSPuaQ > 0; ZkMsBICSPuaQ--) {
        HLUQvEGGQUcWZ = CfnYXeRTTSGg;
        MyljUUkc = OMIlQVFaiJ;
    }

    for (int eBesfirjrI = 1251335191; eBesfirjrI > 0; eBesfirjrI--) {
        lbrGpFDtb += lbrGpFDtb;
    }

    return HLUQvEGGQUcWZ;
}

void btrul::OCghpNZDn(bool pzoLpqjNes, bool mMtSsQxQmk, string XhdHknLbFz, bool CilfHTfWZ)
{
    int jOUIzhyCdoi = 1886072487;
    bool XzNJqBzMZQrugZd = true;
    bool BnftuhcMy = false;
    double dLbRym = -724914.0905876663;
    double wIETuHhTeswwJb = 817858.3447188672;
    double wjLiNFBkZ = 459396.33619425533;

    if (pzoLpqjNes == false) {
        for (int pAckyMYoYSFJLA = 89474994; pAckyMYoYSFJLA > 0; pAckyMYoYSFJLA--) {
            CilfHTfWZ = ! CilfHTfWZ;
            XzNJqBzMZQrugZd = mMtSsQxQmk;
            mMtSsQxQmk = BnftuhcMy;
            CilfHTfWZ = CilfHTfWZ;
        }
    }

    if (dLbRym >= 817858.3447188672) {
        for (int MgItbjDyhuTrP = 1359033577; MgItbjDyhuTrP > 0; MgItbjDyhuTrP--) {
            pzoLpqjNes = XzNJqBzMZQrugZd;
            pzoLpqjNes = ! mMtSsQxQmk;
        }
    }

    for (int GgAFh = 740996216; GgAFh > 0; GgAFh--) {
        wjLiNFBkZ /= dLbRym;
    }

    for (int ADYLfbilGYlR = 1320613360; ADYLfbilGYlR > 0; ADYLfbilGYlR--) {
        mMtSsQxQmk = XzNJqBzMZQrugZd;
    }

    for (int UzIBmj = 20795219; UzIBmj > 0; UzIBmj--) {
        pzoLpqjNes = ! pzoLpqjNes;
        wIETuHhTeswwJb *= wIETuHhTeswwJb;
        pzoLpqjNes = CilfHTfWZ;
        XhdHknLbFz = XhdHknLbFz;
        pzoLpqjNes = pzoLpqjNes;
    }

    for (int uXvDvA = 1592826054; uXvDvA > 0; uXvDvA--) {
        pzoLpqjNes = ! BnftuhcMy;
        BnftuhcMy = ! BnftuhcMy;
    }
}

void btrul::sGispTUyVYcgl()
{
    string fGxbJsJiNi = string("XCieHqetFECsadQVNQXMvEDJQadUqsqHWfFXMPEFoIbpqSSDhoLasJvttypqtzeUTMxtklDnRz");

    if (fGxbJsJiNi <= string("XCieHqetFECsadQVNQXMvEDJQadUqsqHWfFXMPEFoIbpqSSDhoLasJvttypqtzeUTMxtklDnRz")) {
        for (int qPRbdsOPBoZhJPne = 365417129; qPRbdsOPBoZhJPne > 0; qPRbdsOPBoZhJPne--) {
            fGxbJsJiNi = fGxbJsJiNi;
        }
    }

    if (fGxbJsJiNi == string("XCieHqetFECsadQVNQXMvEDJQadUqsqHWfFXMPEFoIbpqSSDhoLasJvttypqtzeUTMxtklDnRz")) {
        for (int lxNzrBZiYA = 1589930169; lxNzrBZiYA > 0; lxNzrBZiYA--) {
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi += fGxbJsJiNi;
        }
    }

    if (fGxbJsJiNi > string("XCieHqetFECsadQVNQXMvEDJQadUqsqHWfFXMPEFoIbpqSSDhoLasJvttypqtzeUTMxtklDnRz")) {
        for (int QAmJVpQUEpCKJ = 1871473128; QAmJVpQUEpCKJ > 0; QAmJVpQUEpCKJ--) {
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
        }
    }

    if (fGxbJsJiNi >= string("XCieHqetFECsadQVNQXMvEDJQadUqsqHWfFXMPEFoIbpqSSDhoLasJvttypqtzeUTMxtklDnRz")) {
        for (int cPUcPEHD = 1190258402; cPUcPEHD > 0; cPUcPEHD--) {
            fGxbJsJiNi = fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
        }
    }

    if (fGxbJsJiNi > string("XCieHqetFECsadQVNQXMvEDJQadUqsqHWfFXMPEFoIbpqSSDhoLasJvttypqtzeUTMxtklDnRz")) {
        for (int xGMfdnCC = 660474540; xGMfdnCC > 0; xGMfdnCC--) {
            fGxbJsJiNi = fGxbJsJiNi;
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
            fGxbJsJiNi += fGxbJsJiNi;
            fGxbJsJiNi = fGxbJsJiNi;
        }
    }
}

bool btrul::gHZeG(bool NRwdSqLfD, double WRRYLidJH, double YCtQVKTvhHw, string aCVNmVfnTd, double HRUHgTWdDf)
{
    bool dFMhouHFhibVMpZ = false;
    double FaUYjLF = -993752.103831517;

    for (int wqvaYwyMlPywJ = 656074957; wqvaYwyMlPywJ > 0; wqvaYwyMlPywJ--) {
        continue;
    }

    for (int mNfMNdhcoHUHtqU = 1982666781; mNfMNdhcoHUHtqU > 0; mNfMNdhcoHUHtqU--) {
        YCtQVKTvhHw -= YCtQVKTvhHw;
    }

    return dFMhouHFhibVMpZ;
}

double btrul::WPRcZSHBMyhwqV()
{
    string FaQwKrvX = string("vICUJYWPkjC");
    string vtWMGmPZGf = string("DneQeLBYmAPYHaJFatPCZcAfkdXbEgsTJrwcGNIeKjWPjtUtJkmACN");

    if (vtWMGmPZGf < string("DneQeLBYmAPYHaJFatPCZcAfkdXbEgsTJrwcGNIeKjWPjtUtJkmACN")) {
        for (int mLTNFVM = 1523588184; mLTNFVM > 0; mLTNFVM--) {
            vtWMGmPZGf += FaQwKrvX;
            FaQwKrvX += vtWMGmPZGf;
            vtWMGmPZGf = FaQwKrvX;
            vtWMGmPZGf += FaQwKrvX;
            vtWMGmPZGf += FaQwKrvX;
            FaQwKrvX = FaQwKrvX;
            vtWMGmPZGf = vtWMGmPZGf;
        }
    }

    if (FaQwKrvX != string("DneQeLBYmAPYHaJFatPCZcAfkdXbEgsTJrwcGNIeKjWPjtUtJkmACN")) {
        for (int SeRfBHaVivbQwnX = 2087169123; SeRfBHaVivbQwnX > 0; SeRfBHaVivbQwnX--) {
            vtWMGmPZGf += vtWMGmPZGf;
            vtWMGmPZGf = FaQwKrvX;
            vtWMGmPZGf += vtWMGmPZGf;
            vtWMGmPZGf += vtWMGmPZGf;
            FaQwKrvX = vtWMGmPZGf;
            vtWMGmPZGf = vtWMGmPZGf;
            vtWMGmPZGf += vtWMGmPZGf;
            FaQwKrvX = FaQwKrvX;
            vtWMGmPZGf += vtWMGmPZGf;
        }
    }

    if (vtWMGmPZGf == string("DneQeLBYmAPYHaJFatPCZcAfkdXbEgsTJrwcGNIeKjWPjtUtJkmACN")) {
        for (int tWouUKXxOUqojOI = 1467559088; tWouUKXxOUqojOI > 0; tWouUKXxOUqojOI--) {
            FaQwKrvX += FaQwKrvX;
            FaQwKrvX = vtWMGmPZGf;
            vtWMGmPZGf += FaQwKrvX;
            FaQwKrvX = FaQwKrvX;
            FaQwKrvX = FaQwKrvX;
        }
    }

    return -441632.78635665565;
}

bool btrul::xIrizcfytemno(double ivdWUlFXZ, bool fwfJjsPyDIpcdC, string TJkUdNoG, int oeankdXQXxPZjTNS, bool cKBgRU)
{
    double aazmL = 966271.7052353473;
    double lNZgfHTIFCDYUAX = 768128.1020370454;
    int dXrLzyyMeVd = 789398821;
    int ceMOsNdnzniw = 1756735175;
    string rgNfrCUoqEdZWzj = string("trqyWIxtnDrrryYeJQuzhzQIcJCwiljlRDiMIJgMfwkUikyZCMztXWLvlwjgdHTfKNkldMjhYtCFpsIJRKkAjqFPDQzCvDgxTNrolfFluiJwElmjJCOXahEHmYdIRGISLlKzhCBVDCkeKXAyZWNExMtjsJYJCDsuhRDfCavLVgrQWPQBbcryXqLkwOzjwBBcXefqbNcWftGurLQtwUnlnTZxKCgZsbBSWrGoBifDdVwXiC");
    string ggOUqWfRzQf = string("KbHoR");
    bool yFYchpkQYYJd = true;
    double OHuCszJD = 740911.3556608866;

    if (dXrLzyyMeVd > 789398821) {
        for (int uucGPZDfStHiAQT = 977038223; uucGPZDfStHiAQT > 0; uucGPZDfStHiAQT--) {
            TJkUdNoG += ggOUqWfRzQf;
        }
    }

    for (int wGHThWQfc = 1769683526; wGHThWQfc > 0; wGHThWQfc--) {
        continue;
    }

    for (int vOrcZbtKhTffXvNp = 626178569; vOrcZbtKhTffXvNp > 0; vOrcZbtKhTffXvNp--) {
        ggOUqWfRzQf = rgNfrCUoqEdZWzj;
        lNZgfHTIFCDYUAX -= OHuCszJD;
        lNZgfHTIFCDYUAX /= OHuCszJD;
        rgNfrCUoqEdZWzj += rgNfrCUoqEdZWzj;
    }

    if (cKBgRU == true) {
        for (int zMolVdlcAMkro = 101592744; zMolVdlcAMkro > 0; zMolVdlcAMkro--) {
            ceMOsNdnzniw /= ceMOsNdnzniw;
            ceMOsNdnzniw *= dXrLzyyMeVd;
            cKBgRU = ! cKBgRU;
            TJkUdNoG += rgNfrCUoqEdZWzj;
        }
    }

    if (ceMOsNdnzniw > 1756735175) {
        for (int zaInenKUAjxp = 723093024; zaInenKUAjxp > 0; zaInenKUAjxp--) {
            cKBgRU = cKBgRU;
            fwfJjsPyDIpcdC = ! fwfJjsPyDIpcdC;
        }
    }

    return yFYchpkQYYJd;
}

bool btrul::dwjjjssXgeih(int HGDPLEr, bool ykWBfd, string KeNkSDfoKU)
{
    double iCYHLGmKG = -895036.6343941335;
    int zGFUrPoLhxETFQ = -488145638;
    int wLdASFE = -1523565937;

    if (wLdASFE == -1523565937) {
        for (int cmemRSS = 532369220; cmemRSS > 0; cmemRSS--) {
            zGFUrPoLhxETFQ = zGFUrPoLhxETFQ;
            iCYHLGmKG -= iCYHLGmKG;
            HGDPLEr *= zGFUrPoLhxETFQ;
        }
    }

    for (int nfYeTW = 600895916; nfYeTW > 0; nfYeTW--) {
        wLdASFE += zGFUrPoLhxETFQ;
    }

    for (int fSJASNZnkZHUNGPb = 1893498308; fSJASNZnkZHUNGPb > 0; fSJASNZnkZHUNGPb--) {
        zGFUrPoLhxETFQ *= zGFUrPoLhxETFQ;
        zGFUrPoLhxETFQ *= wLdASFE;
        zGFUrPoLhxETFQ /= HGDPLEr;
    }

    for (int ogsyaCbhszF = 892170835; ogsyaCbhszF > 0; ogsyaCbhszF--) {
        wLdASFE *= wLdASFE;
        wLdASFE += wLdASFE;
    }

    for (int usrcYWxPzOZsXUAz = 1301173803; usrcYWxPzOZsXUAz > 0; usrcYWxPzOZsXUAz--) {
        iCYHLGmKG = iCYHLGmKG;
        KeNkSDfoKU += KeNkSDfoKU;
    }

    for (int MJwDXfYaCUHSyb = 628938005; MJwDXfYaCUHSyb > 0; MJwDXfYaCUHSyb--) {
        wLdASFE *= wLdASFE;
    }

    return ykWBfd;
}

btrul::btrul()
{
    this->yCFeXakDA(351391.5823869141, -586108.716090879, string("exstOSDUBfqsbltuQqZvMqxBKXBUioNmuFVAzydkVfwcTaZolWGOZbBylvqhQoKTlCcMTVjrMhJRpqyBpKTJRZABLbUgxyaeWYSbJPMesCIsdXxGeNvrlCymToUmhpnUAgcrTnQCdlHTEYChO"), -1573081303, false);
    this->kKgMODtpWjwy(-956018.9552678715, string("xTDXnHPSDciIHsFtIojF"), 1108209679, -424954.1090030561);
    this->rLZNVxFIGReEYpiM(true, string("OophnUwqeotsXghVSTvqAnFUFKGYCVSnoTt"), -605483742, -524678.9841199344, -1207537282);
    this->VjSKqry(true, -1315046826, true, -567147965, 751751.5504043169);
    this->HabtdtSJLqYYHWoR(string("uEeTYZSEkLtToYkFWeRIwyhrGzYnxDGlzYFdYdrhiivzYmALmqgMuZnNeaPNGpURFHFIhRpOrfJfDIkjadBsbQCMHCxbYPaIIItuLZxIXyLBxJvrOJYBnDC"), 1507091752);
    this->tlNpTbrFGAfRrPNi(879569803);
    this->mICHsTljblvx(false, false);
    this->bwNPv(-368430.9164926569, 875975.9081312938);
    this->xiHvhutpukdg(1784413529, 431097.67597506684, false, -245197979);
    this->yALqRvXI(-900978455, 364789.73365878663, -667172.0074864376, false);
    this->JLTpaVvj(string("qdBLQUdLCsufKKyoGskSdjckSWPTaeDhwVhAROpNwAXitFkBRYtCMuKbkSAhuNszEYrHTBiUcYJDHTgBPsBnechhqkc"), string("SGqMqgQGyrBfiVfWcaTuptRxWNVKazMixUPhSdzVNBpCszpXwDBXqioTTkoWcjskUQEHnMxoeGqjiUhIErbSaOEdyJEugXenTCGQcmGCTDgkGQOmBCbZQhtTmwOYpxVfqODlkcvHOlidcVKtiXuWeSjtLljARTzkHsxJFAaQLSnZpawavGp"), -1548148815, string("xNuGMefFeHHTGHFDPCFDoKypWzAdFzMARmuFcjSRWTLfNnPxQwpIDoHMykrWsSzXQlYGMFUwTosfxEgsnlXlRyTJwjFxIjUMwXSOdbmpKTIjTuPnltUAcvrGEihGxtTDLzboWNHabZVuVRdYdQbZYutzebJRknXZKYzJTdqgHWugcYSdYoLxBwmXkiEDabOXunDKCTeVrgRLBRzDrQP"));
    this->OCghpNZDn(true, false, string("LnefXjMzxvNsyfvhWrXDisEmevXfequvvgApNYdxcLOaGuqfeNSsVRLmlJWJMnyMgNQkBvGqMpDOZTlsoHlwGdLJniBVyoTcxHbcdHttBWFqWpVVwLxXsLPeOqTMiZgPhjzXZeyHOrBEAAudqfHGtozgIc"), false);
    this->sGispTUyVYcgl();
    this->gHZeG(false, 715743.4816944868, 568195.8321239967, string("zftckiSkbdqOjMvpatjLsqSvVfvFtqYJItkwZtMVUCMSeWolULIbxGBVojSZwcCGDJDLFXdujHiJceNRDFzpkwlSudBcvviTixEBVgsTNZfhFStckOBDNDriPGyPzfUffEWuFkyGikGIpLfTNOxXTwyjmcSLTfSvVYuqamNtAgnLutKBVIdnhhbENXCaVcFyEykhFfRkEmXDXojVhubsdiLDwzhLygTONVFqoCokTdIdBpdBokSLQOJfY"), 719556.3609501766);
    this->WPRcZSHBMyhwqV();
    this->xIrizcfytemno(-332483.92307161295, true, string("xGyHdobneeMkxneuWDidLMYsNYEahYkENPoYCHOm"), -2103126563, true);
    this->dwjjjssXgeih(-939562275, false, string("kBFSutviUdItFRklUAGnstIfJcHjZdLsFnqEiHHYzBjiQyIkQjnVQjSGZhfuoJrzoKNBRXpQWChkhVTLYYmfqklHoyIStPkuZzfwkuINawoCkLylmJdqhevlvrfZaRJpTqpOxleCOZXIjQxreNYXypMOyrGvKwyJTVDqajdCQEzgqpegUQMfjozfhroYQQKeXmDhoScdOCTuOTEEtBMAFjkaicVkjdbrUwpQrVp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zjJjE
{
public:
    bool DMVvLWL;
    bool wNoOgjyspjNwQ;
    string itXWU;
    bool IEyvuvifXePtdQ;
    bool MmameWrAYfyM;

    zjJjE();
    bool DLSeDxiNT(string UmlRwHVR, double PhLlQ);
protected:
    int adJTCLLJsdMDBR;
    string RQDFZUaeVfq;
    int SxktXFgzNiuAZP;

    int EZMtsPfCVqpIH(double sTyoakNeUUvR, double SJaOTagkE, string BjINrmpWU, int ILlLGQgOmw, string luRLBgPuTh);
    void YeXlzUsImqQ();
    bool fevZlGba(string VFsFfg);
    double IwsTRh(bool VrXNMVJYziYBS, string IrwePychYbiQ, int UlZcscuARojgzvxj);
    int TvVVFLyRrN(double xIhSLU, string VamFJEeTCrdJ);
    string HqXiGtAWtvUODZbd();
    void XYNKROeEe(int bBUFMTbZf);
    bool yFAgBazASqC(int itmeVbmpuIBYwSv, bool vKCYF);
private:
    double ndSFqfCdMQKX;
    int iPEAMiyfxdqljL;
    string GkZVMMgSuvwrKh;
    bool SZSyEbuLxR;
    string qZIoPTkU;
    double aJtxkNHIzIMRTJsb;

    int feXpEK(double JnIjaziyzPJAhZ, bool IzlAIFhQh, int DmVOMu, string CotSGFmgOd);
};

bool zjJjE::DLSeDxiNT(string UmlRwHVR, double PhLlQ)
{
    string fJACSrBRPCRZ = string("CRwezXPLtYignXsTvBvQfNgtcLwQxbBgbrnJQEtJkkXthEBmqXDQORNDNAwipgxKhcZgDwArxiaBsodetdVamxRRzmSKeMFleDYhQgbNcYeUmvQZprDoBfkyfXaktUGykpbjwtPyMWNrqySPfLlOMnlTMUZIygakQTlKRsIjqScHALXDTpmDYVWnsVssqPqxDfcGsEraBijMoraSmzYgFZnyhc");
    bool gTdCLVkEgiqJs = true;
    double pLNnrAWWLS = 259680.20544213193;
    string oMosTxgzxnPdxE = string("ZJmZOFBwogvCyVGiNgcRiYJfTyXNsDtJSdIKQFcEjYoGnf");
    string UXsgVeehxhshY = string("ZCIQktcgqAUWSHHMCHfXYrusCstBxtsymdMDRoXeYmwzRJzptoodYOMBbMJhbfdjKnXELhlDDOEeJgVUAsfdnJlsMDUoJVDyjxjhbfzVwMLmqDeDfhgkudhFmNrVTsqVHhLKfRsvxATlzgVyEEPqhwPYgOFdupNtkpnMUcYaQvQKFz");
    double DLXdHrsUtby = 387620.4631751197;
    double tWzrCYpYabSrnB = 502186.69153148076;

    if (PhLlQ <= 387620.4631751197) {
        for (int xAFUhWDoYUYI = 1913801901; xAFUhWDoYUYI > 0; xAFUhWDoYUYI--) {
            DLXdHrsUtby += pLNnrAWWLS;
            UmlRwHVR += UmlRwHVR;
            tWzrCYpYabSrnB = PhLlQ;
        }
    }

    for (int iIejxCYd = 1536583876; iIejxCYd > 0; iIejxCYd--) {
        PhLlQ -= DLXdHrsUtby;
    }

    if (UmlRwHVR <= string("uELQwTVZKtEbvCJVTyYlJJYCwaRlBoopVkJheEtsnVVWTZRSymCPSbTxkkKNclGquhPNvwCvwDkisaRdpCDUhPrbiEpmhFrAAAQMZMcUmVcqEvrorelWAjWumLjjoEnrTeqyLKrIaQqtrgoFVgwMnKpiGVFyjHpzICkLIhoevOkNtDpcelsLxHRCttoVSCmsSlQgRWyIwLpbKIXWvwbbv")) {
        for (int suorzEuXikSdSjC = 813523296; suorzEuXikSdSjC > 0; suorzEuXikSdSjC--) {
            fJACSrBRPCRZ += fJACSrBRPCRZ;
            UmlRwHVR = fJACSrBRPCRZ;
            fJACSrBRPCRZ += oMosTxgzxnPdxE;
            oMosTxgzxnPdxE += UXsgVeehxhshY;
        }
    }

    return gTdCLVkEgiqJs;
}

int zjJjE::EZMtsPfCVqpIH(double sTyoakNeUUvR, double SJaOTagkE, string BjINrmpWU, int ILlLGQgOmw, string luRLBgPuTh)
{
    string AtUzFmHuxHjV = string("FjAilaLFCGNcEXoqHVVPDnpzOaOpkGfObCnMPrkbVjxIdoXrTEJbpaIqwCeuolGKUwcQNWyUNCZRNOjTzPCWoqLQniybMMPoOgEKtLzFJnNYNTYFatuecfbIogYiqgnlBhMNgMLUIZXPZnSBwjOyvzDrJzGXmD");
    bool KgkhBwtXHpAjUo = false;
    int UAzXziJAFWbjq = 1254977450;
    int YpirOnasPri = 2053148952;
    double XmAJFWXwKhbmu = 509494.43221456505;
    int TAYktokkrM = 862181669;

    if (ILlLGQgOmw > 862181669) {
        for (int KvUgmktvMCEROaR = 676022811; KvUgmktvMCEROaR > 0; KvUgmktvMCEROaR--) {
            SJaOTagkE += sTyoakNeUUvR;
            ILlLGQgOmw *= ILlLGQgOmw;
            SJaOTagkE += SJaOTagkE;
            SJaOTagkE += SJaOTagkE;
        }
    }

    return TAYktokkrM;
}

void zjJjE::YeXlzUsImqQ()
{
    bool kKjtZpwpm = false;
    double ZcexXvPME = -1002571.0872532187;
    int OnkJcUEbUYxLj = 934354213;

    for (int XTofMzgcJBjSKUPt = 33466723; XTofMzgcJBjSKUPt > 0; XTofMzgcJBjSKUPt--) {
        OnkJcUEbUYxLj -= OnkJcUEbUYxLj;
    }
}

bool zjJjE::fevZlGba(string VFsFfg)
{
    double yOgahwt = -939184.9477323099;
    double rktXt = -160589.79289970294;
    double HlNvzmHbO = 71571.66930439805;
    int eOuAlPdu = -613072575;

    if (yOgahwt < -939184.9477323099) {
        for (int OHNrikvOly = 1432187360; OHNrikvOly > 0; OHNrikvOly--) {
            yOgahwt = rktXt;
            eOuAlPdu *= eOuAlPdu;
            HlNvzmHbO /= rktXt;
            HlNvzmHbO = HlNvzmHbO;
        }
    }

    for (int aEbjLFqDER = 1338282064; aEbjLFqDER > 0; aEbjLFqDER--) {
        VFsFfg += VFsFfg;
        yOgahwt += yOgahwt;
        eOuAlPdu /= eOuAlPdu;
    }

    if (HlNvzmHbO != 71571.66930439805) {
        for (int eJpzrtVfH = 625720991; eJpzrtVfH > 0; eJpzrtVfH--) {
            HlNvzmHbO -= HlNvzmHbO;
            HlNvzmHbO -= HlNvzmHbO;
            HlNvzmHbO *= yOgahwt;
        }
    }

    for (int virficndp = 1516471221; virficndp > 0; virficndp--) {
        rktXt -= yOgahwt;
        HlNvzmHbO /= HlNvzmHbO;
    }

    return false;
}

double zjJjE::IwsTRh(bool VrXNMVJYziYBS, string IrwePychYbiQ, int UlZcscuARojgzvxj)
{
    int WOVmPa = -464171990;
    double XXUtzspJfrS = -361852.9448143871;
    int kGczHgksw = 1164400566;
    double lvtzxHt = -544637.0608558258;
    int dCbZuwzY = 900894570;
    string wURbnFmMAm = string("iHDBqgMxPfZSbHDLeKGWVbZDioXeEOqfxkOHOnDIezKAtvqcSsWKVXQMZSDiKpeZgIlNTXiYmsSVEUEEtpQrocdTZNEWrkiRWKnoLSAXFvOJczvgFQOpJZYlSpSiwXFDxGWwckJvanBnkreHzISbckgnoKkZplzXyKbfstSNMh");
    double uCXPmpjju = 973495.5891613702;
    bool aBMZdvMGAD = false;
    int nkwED = -326875717;

    for (int WxMePCR = 1652227283; WxMePCR > 0; WxMePCR--) {
        WOVmPa *= UlZcscuARojgzvxj;
        dCbZuwzY -= WOVmPa;
        kGczHgksw *= kGczHgksw;
        WOVmPa /= dCbZuwzY;
    }

    for (int deMsYZaKaRlWLD = 819782040; deMsYZaKaRlWLD > 0; deMsYZaKaRlWLD--) {
        WOVmPa -= WOVmPa;
        XXUtzspJfrS *= lvtzxHt;
        wURbnFmMAm = wURbnFmMAm;
    }

    return uCXPmpjju;
}

int zjJjE::TvVVFLyRrN(double xIhSLU, string VamFJEeTCrdJ)
{
    int SrBmXOCxDKT = 1320660867;
    string SIdsDCz = string("hxcbxQyKgU");
    int cseCMeEtCMfoCIE = -934428972;

    if (xIhSLU == -191624.04615753327) {
        for (int KAgHdLU = 99927352; KAgHdLU > 0; KAgHdLU--) {
            SIdsDCz += SIdsDCz;
            cseCMeEtCMfoCIE = SrBmXOCxDKT;
            xIhSLU *= xIhSLU;
        }
    }

    return cseCMeEtCMfoCIE;
}

string zjJjE::HqXiGtAWtvUODZbd()
{
    string tLcaVsjqdatfFIK = string("LKiWvyYhGFUZCtSZYfrcuPMEVdQXmvYDXLTXjOiYMzhfDWlzsAbOH");
    bool gSAfjnW = true;
    string RblOucsJWwEsk = string("mOLNwNHDTUedmeXGUteuAWgUfm");
    double zgXTuKPBbg = 71742.05534350146;
    int DoIhkdCjRSjCtMnN = 783837856;
    double OFdCzAk = -876155.6200687534;
    bool dgUvCXajOUT = false;
    bool HyDbThScs = true;
    string OQTLpOjezAZdOhxi = string("zmPOnGJAzjvjmorZYPoTyvqqplSEBckOSRpQInTmViOnpUsjJaiyopWkXzhXcHrKNWeYbBtLOhQzMmpWOiDnxGVlnhzAiPBWjPrSGPqobcRDilFhphPLJKpXXXYFanWMWAySiwJqrUubhdBBYOrGdAZLalBnCLsaWZhPgdPZSqvKyXrjehxdaBeIaHbkemdFUVuLPRWnixvfTMxbVGAe");

    for (int RqKEHdg = 157098180; RqKEHdg > 0; RqKEHdg--) {
        DoIhkdCjRSjCtMnN -= DoIhkdCjRSjCtMnN;
        OFdCzAk -= OFdCzAk;
        gSAfjnW = HyDbThScs;
    }

    if (tLcaVsjqdatfFIK <= string("LKiWvyYhGFUZCtSZYfrcuPMEVdQXmvYDXLTXjOiYMzhfDWlzsAbOH")) {
        for (int sbODZLDrIDMTtBiR = 1925063375; sbODZLDrIDMTtBiR > 0; sbODZLDrIDMTtBiR--) {
            continue;
        }
    }

    return OQTLpOjezAZdOhxi;
}

void zjJjE::XYNKROeEe(int bBUFMTbZf)
{
    string oXYUgykpljHAKKbx = string("APbouKSpWNSMHxZwbAyOxbEKJTdiGLmTnGZoqVZqoIOhfzEqzZrnBhTGGPxRXnEXQBGOxArpaWuIGBGrNBfX");
    double fIZuxLfKINFOci = -89942.77753415397;
    double TVHXYbGbWSTuk = -71267.35029089608;
    bool iZBJfju = true;
    string eweJZTYXgnAKJisG = string("OPgfMclCzRcPMeRifToyuKTqTfNUmgMvLuKg");
    string CVhAGgAWnp = string("pCxndEVbBpfSBogPMcUNFiFfYlHGXzuhIwrmXtHWZWxXWHyslZuKkdKBrecaNhdwkAqbaSNJlBaTEHJHvpPIqZhFzyieIGYQDfEhGfcezhaJgHFyLneghjwNsCCpjAvxdSORYCnEnkEyrjwHoEvbOicmubgMSfNOMVbXftTHmVPYSinYRNQuzAotEbDxuaWHRdfPitDfRmXaAMfhzBW");
    bool auSuJ = false;

    for (int cOTdn = 1617942942; cOTdn > 0; cOTdn--) {
        TVHXYbGbWSTuk *= TVHXYbGbWSTuk;
    }

    if (CVhAGgAWnp >= string("OPgfMclCzRcPMeRifToyuKTqTfNUmgMvLuKg")) {
        for (int prQXOAaD = 904784723; prQXOAaD > 0; prQXOAaD--) {
            continue;
        }
    }
}

bool zjJjE::yFAgBazASqC(int itmeVbmpuIBYwSv, bool vKCYF)
{
    bool qZjBdXf = false;
    string XmSGbUxQqokuM = string("jAqVElpisCVEmtQFqeJVPWVFQldfPwIcbchEXvrDUMlbgIkMKgpDuFTEuCqOsjePfeRjdpPwFmsicdthDbhbJUpoeGiiknfpltaQwdMAdAyTuuVnHkKJWwTbCFllJoHcfKgFXCUNCmQgRQkUjSAGYOwBEGmcMWaSBlRlLzJbWXfpVvlUMWVPbCHTtSJjlByujZQs");
    int HGwPyQJt = -1604900999;
    bool hcpDHQC = true;
    bool lbNFWcjgNB = true;
    string CbqpJkWJ = string("BmYAWbfTAayVVbIehXVZspcOwDOvLRqNMRaCMGcotwOuptGgagmEuxsFMbqOcaLwycJByJjBafFBCFyvvuJslLLujGElkDnUaGEAncLTFROLjhSBPIRXeREuLzgIPOgGJGLBqzcbFvPxsSQVbezeIQBhEmPSrOyzujYREEIhFGNiHdkEuaMMwymHJPvdGwfLUzNIbLevasBukTDHwCeLsyuplsBIrlTMCKt");
    int vMtjmQ = 152090292;
    double ARaBckhRx = 580370.5126834711;
    double KwnmqreqZ = 789652.0175737833;

    for (int NMMUmGnpzDQSL = 798756261; NMMUmGnpzDQSL > 0; NMMUmGnpzDQSL--) {
        vKCYF = ! vKCYF;
    }

    if (qZjBdXf == true) {
        for (int MfmDhgQCsOiQCtb = 1485215234; MfmDhgQCsOiQCtb > 0; MfmDhgQCsOiQCtb--) {
            itmeVbmpuIBYwSv *= vMtjmQ;
        }
    }

    if (KwnmqreqZ != 580370.5126834711) {
        for (int sgKQaztIyHl = 956616442; sgKQaztIyHl > 0; sgKQaztIyHl--) {
            qZjBdXf = ! hcpDHQC;
        }
    }

    if (lbNFWcjgNB == false) {
        for (int mmiyMkMdAwE = 1129407721; mmiyMkMdAwE > 0; mmiyMkMdAwE--) {
            hcpDHQC = qZjBdXf;
        }
    }

    return lbNFWcjgNB;
}

int zjJjE::feXpEK(double JnIjaziyzPJAhZ, bool IzlAIFhQh, int DmVOMu, string CotSGFmgOd)
{
    double PBMEfqalZrvwb = 85499.6561597126;
    bool NYNuUn = true;
    string LjdJkEUMLHm = string("nUAcNFnkrmGhiqPgHWtOOUWbzQCk");
    bool XddWzOsFdvI = false;

    for (int brRQrSknAB = 1746528990; brRQrSknAB > 0; brRQrSknAB--) {
        NYNuUn = ! XddWzOsFdvI;
        NYNuUn = IzlAIFhQh;
    }

    for (int DJOzSEn = 1309191135; DJOzSEn > 0; DJOzSEn--) {
        continue;
    }

    for (int kOHFAG = 1997230252; kOHFAG > 0; kOHFAG--) {
        IzlAIFhQh = ! NYNuUn;
        JnIjaziyzPJAhZ -= PBMEfqalZrvwb;
    }

    if (IzlAIFhQh == true) {
        for (int gWAlT = 796912635; gWAlT > 0; gWAlT--) {
            XddWzOsFdvI = IzlAIFhQh;
            NYNuUn = ! IzlAIFhQh;
            NYNuUn = ! IzlAIFhQh;
            IzlAIFhQh = ! NYNuUn;
        }
    }

    for (int TWtgQPj = 1997742244; TWtgQPj > 0; TWtgQPj--) {
        IzlAIFhQh = ! XddWzOsFdvI;
    }

    return DmVOMu;
}

zjJjE::zjJjE()
{
    this->DLSeDxiNT(string("uELQwTVZKtEbvCJVTyYlJJYCwaRlBoopVkJheEtsnVVWTZRSymCPSbTxkkKNclGquhPNvwCvwDkisaRdpCDUhPrbiEpmhFrAAAQMZMcUmVcqEvrorelWAjWumLjjoEnrTeqyLKrIaQqtrgoFVgwMnKpiGVFyjHpzICkLIhoevOkNtDpcelsLxHRCttoVSCmsSlQgRWyIwLpbKIXWvwbbv"), 922695.7410898315);
    this->EZMtsPfCVqpIH(-287916.0946336075, 774315.8140870172, string("NxRsiLVsQnTEIwZcNVmIvaXcbEQRwfTFNICizPyUVbAjkcVrDyQJvIFbbECjbeTJzLBZLgVYygvMSGwqKISBFKPbtnkhqWXVTHrvgrvOrprsGEKlvSOYjfeEugOcoWXIgUNeLBGiWwbgofkGmEjyUNbAyUQeuHAplsaaJQLCdcdFqtfxQNsdsCLSJQnasMcBqmUkLJzhuMpUPGIzkksqWrzCVaVcsNKFPaFaVLRUUeKztaPjT"), -1891723855, string("EJzcWExmvjXpsPdCPWJhxLuCCrZALIYRwryHioMxJVrfWcXnYeqfOvknfwDjzgeetthLKnrbOpGhLHusOyusUFbZODUgRHlxZsWzKoFAglIGmPzWTiLVQNmiIziUiEujoQEohLfFIbrKvuqiDjwTFxsKFAMIhxMWYD"));
    this->YeXlzUsImqQ();
    this->fevZlGba(string("FyaXPibxmkHaACTDUekYHwYRFciOTZJgDYILxEkKLgwjdsNSMIjNBoQAbFwxCdwMmQYHLmaFJeTqgUuSSlMpSwzhGwvRthQzycUDAhATSvGqBrsCTYSDyspNwnLsMDT"));
    this->IwsTRh(true, string("GqXotyMZRTWUktGPtPiAomWzmzAzlhEBwpzHeAHGphfpwVWCXTPfWwELasltC"), -2125514932);
    this->TvVVFLyRrN(-191624.04615753327, string("QaqDjAlEbFViXzjRixhCyyQBasLOqXIHpuDpDalduSnQjmWWeiCwNpSyz"));
    this->HqXiGtAWtvUODZbd();
    this->XYNKROeEe(-1738097649);
    this->yFAgBazASqC(1218679293, false);
    this->feXpEK(250484.42850392882, true, 1570309603, string("WWwZRqgXXrWhUcteKeGBQyeBoIJMYPYfUMimDsNUyTHwCxFgEWViiZWYpYAqbqVwsxxLHrKjjQDIDWgffQYyHJkfaBPXJzuqVpCQXXFAYVjeREfersjKsVSxFBZsLfxvHh"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PrltGZJAB
{
public:
    double QYghAiyGRhTgz;
    string HAfyAgFcxpkdx;
    string sriDQ;

    PrltGZJAB();
    bool OFnYPkDfJ(string YDMlwiSle, bool NNlFTsnstWIC, double AUVDfZBZERehMGRw, double OeWvqz, string uutOrEDWM);
    string DRKqocOfKYxZQBTV();
    double rIIcumzlepDTLj(string pMysNer, string sypTyXWeZgMikZQ, double AKgCfxcX);
    string OmXFpnjOYmKYoem(double lcjouBoyJKpCkSE);
    int dSDsdkcPjKtUAQ(string vdCtYptLccU);
    bool kdudW(int gprcTbg, double mWLfxxuVanE, string CspsDwhXqM, bool rcXJRElDnBqphNO, bool vcEEVpJdv);
    void kdIwEpcmJKiOLJF();
protected:
    double HSRNuWqBuJvlGpwL;
    double WRpeMKJFInHnHXN;
    bool XnHhTBYcXyXq;

    string uIBKABr(double cvvTKnn, string JuyjXVmJoGZj);
private:
    string YQmdOkNDsmzxH;

    int JnklULHkg(int PYqvZzmzGZK);
    string LnkyFvqe(bool bQAjDhkESLwb, int jbXPcnbetgX);
    string dwJAACpSrmQpax(string kCXcn, bool jtsLLLVFO, double aYjlXOzyVbWYpeg);
};

bool PrltGZJAB::OFnYPkDfJ(string YDMlwiSle, bool NNlFTsnstWIC, double AUVDfZBZERehMGRw, double OeWvqz, string uutOrEDWM)
{
    string AiAkIJfoqq = string("CoXHbXgDdtODmToSPcJKqSRBtmVaQDuGjuQTzeVdkmUHiHxtokzBAlLFQQyWdpRMBPjkhmKfdhmEGxWVlPScgrPbFKRnjtRNbllUnuyOaNDGXhVjWvnzcbpiAhuDiZkHhWGrkChUiPvcXakMoPfhkMKRmPqXnJuXqeqfexKaCWCiQdRIkxYpfnxBtlfdBxYFJFlIgNA");
    string IKfLMiTB = string("satuwKUwoMRoZokpdpPgoCfBMDeeHubNntrXpVTnxTjRdwTEnztfADSwpbRAdvaSTLxqHpgsXeOtQTITcAuEcvuQjeVkFQcICgUmlfA");
    bool psuBhb = false;

    if (AUVDfZBZERehMGRw < -719154.829801703) {
        for (int FZUFIWOamTjNS = 983244509; FZUFIWOamTjNS > 0; FZUFIWOamTjNS--) {
            IKfLMiTB += YDMlwiSle;
            YDMlwiSle = IKfLMiTB;
        }
    }

    for (int VnblskUjTyRMR = 537210334; VnblskUjTyRMR > 0; VnblskUjTyRMR--) {
        AiAkIJfoqq += IKfLMiTB;
        IKfLMiTB += IKfLMiTB;
    }

    return psuBhb;
}

string PrltGZJAB::DRKqocOfKYxZQBTV()
{
    double nbkpJvumZH = -223073.96552631492;
    bool YVPxoFESjIwjy = false;
    bool YdfLTjnO = false;
    double PzbcspFzitC = -567872.215363179;
    double pECZHMeGzb = -649767.3122501798;
    double SUxsIiUC = 777929.0545745208;
    int LpPIqEUPwiPqxOh = 1086707474;
    bool qskhJ = true;
    double DQXSdNjJfOUkOzNR = 236789.17629601288;
    bool mbSYMCVuMrqv = false;

    if (qskhJ == false) {
        for (int GRaPvLzrqUlZV = 362898454; GRaPvLzrqUlZV > 0; GRaPvLzrqUlZV--) {
            qskhJ = ! qskhJ;
            PzbcspFzitC += DQXSdNjJfOUkOzNR;
        }
    }

    if (pECZHMeGzb <= -649767.3122501798) {
        for (int PDCxelJthYZUXFP = 1817544510; PDCxelJthYZUXFP > 0; PDCxelJthYZUXFP--) {
            qskhJ = ! YdfLTjnO;
            SUxsIiUC += nbkpJvumZH;
        }
    }

    if (YVPxoFESjIwjy == false) {
        for (int smGAGxfntJ = 969690109; smGAGxfntJ > 0; smGAGxfntJ--) {
            YVPxoFESjIwjy = qskhJ;
        }
    }

    for (int ZNshy = 821568656; ZNshy > 0; ZNshy--) {
        mbSYMCVuMrqv = mbSYMCVuMrqv;
        SUxsIiUC -= SUxsIiUC;
        nbkpJvumZH *= DQXSdNjJfOUkOzNR;
        qskhJ = YdfLTjnO;
        pECZHMeGzb += PzbcspFzitC;
        DQXSdNjJfOUkOzNR *= nbkpJvumZH;
        pECZHMeGzb -= PzbcspFzitC;
    }

    if (SUxsIiUC >= -567872.215363179) {
        for (int mkHPhf = 2125042911; mkHPhf > 0; mkHPhf--) {
            qskhJ = ! qskhJ;
            pECZHMeGzb -= SUxsIiUC;
            PzbcspFzitC -= SUxsIiUC;
        }
    }

    if (YVPxoFESjIwjy != false) {
        for (int cVqJp = 634215971; cVqJp > 0; cVqJp--) {
            continue;
        }
    }

    for (int PfyfqIVEJdeavlLA = 1772594061; PfyfqIVEJdeavlLA > 0; PfyfqIVEJdeavlLA--) {
        continue;
    }

    for (int WAqdfgWkX = 1215693824; WAqdfgWkX > 0; WAqdfgWkX--) {
        nbkpJvumZH = DQXSdNjJfOUkOzNR;
        mbSYMCVuMrqv = ! mbSYMCVuMrqv;
    }

    return string("rhYpjAXSYHtLoVDeZZkKTNPcePJDwcRecwjfkuZAfXSCZThVtQtoZAsuyagrLXkZgczderPtqhuZOIjOJtPRAQRmctfuJyShCMUKVbyUkUNYrRYYGPOIpjcVlyzQoWYdJNnXBfrEChGVGpuHchPHnccV");
}

double PrltGZJAB::rIIcumzlepDTLj(string pMysNer, string sypTyXWeZgMikZQ, double AKgCfxcX)
{
    double ksoaoPSXmKw = -618474.6206994668;
    double VLYjWykH = 957906.0708103419;
    bool PivtdAXNCnYRTCy = false;
    int WgjLFyjFwPPMjzH = 156524686;
    bool UHGNywkUCTP = true;

    for (int drlbzKseRjp = 1892383473; drlbzKseRjp > 0; drlbzKseRjp--) {
        VLYjWykH -= AKgCfxcX;
    }

    return VLYjWykH;
}

string PrltGZJAB::OmXFpnjOYmKYoem(double lcjouBoyJKpCkSE)
{
    int sgsoLXTgr = -1364901515;

    if (sgsoLXTgr > -1364901515) {
        for (int soeQkx = 1544891427; soeQkx > 0; soeQkx--) {
            lcjouBoyJKpCkSE -= lcjouBoyJKpCkSE;
            sgsoLXTgr *= sgsoLXTgr;
            lcjouBoyJKpCkSE -= lcjouBoyJKpCkSE;
            lcjouBoyJKpCkSE *= lcjouBoyJKpCkSE;
            sgsoLXTgr /= sgsoLXTgr;
            lcjouBoyJKpCkSE *= lcjouBoyJKpCkSE;
        }
    }

    return string("FPiyBOHYsdlegVEtcjmsLCRaruVZlLzMjpddnJxyBmyxgHvqFLSslTrZpwOZcFujxoMDNPnHOWmJGPShTvUuYOfBlyzABXvaAUabmasykRQnjeGlpQPLrNQBMCxPElMUWaDHKuqwlrDnLPiXiONRvsGemHLgudPNIbKCLDAUJhhbkjoRucVXStaJeKdlyWphrTMhGqOkehh");
}

int PrltGZJAB::dSDsdkcPjKtUAQ(string vdCtYptLccU)
{
    double nRjyKBHyhvwFQ = 951806.6248914788;
    double PdOWNrAfo = -727471.8128072156;
    int dRPLzgJpgkNUUyaQ = 1233164210;
    double StePFwJlKSLA = 20414.805567202406;
    double wopbUzynhGl = -633417.1702516045;
    double QMYvHzrZxEdhaXvN = 163849.10425581326;
    string Ahoyp = string("EeZimxzWTdpXAZC");
    int EqOMeZZvEjOJFpu = -1684827086;
    double tPOQfijrhPR = 378805.4272053117;

    if (PdOWNrAfo != -633417.1702516045) {
        for (int FwKNharWgi = 846406291; FwKNharWgi > 0; FwKNharWgi--) {
            tPOQfijrhPR += nRjyKBHyhvwFQ;
        }
    }

    for (int ntHHDZzHeiSGD = 740522257; ntHHDZzHeiSGD > 0; ntHHDZzHeiSGD--) {
        QMYvHzrZxEdhaXvN /= PdOWNrAfo;
    }

    for (int oINAvDTekr = 654647267; oINAvDTekr > 0; oINAvDTekr--) {
        Ahoyp += vdCtYptLccU;
    }

    if (wopbUzynhGl >= 20414.805567202406) {
        for (int jgDUQWjMJwSI = 1929655318; jgDUQWjMJwSI > 0; jgDUQWjMJwSI--) {
            PdOWNrAfo = wopbUzynhGl;
            dRPLzgJpgkNUUyaQ += dRPLzgJpgkNUUyaQ;
            StePFwJlKSLA -= PdOWNrAfo;
        }
    }

    return EqOMeZZvEjOJFpu;
}

bool PrltGZJAB::kdudW(int gprcTbg, double mWLfxxuVanE, string CspsDwhXqM, bool rcXJRElDnBqphNO, bool vcEEVpJdv)
{
    string nxRRuWOJeOov = string("kGNbwGcg");
    double bvVfyeaCqcQShMmM = -466622.6306900239;
    double EHJjWvUDJjkB = 102305.71918534166;
    double zpwkEt = 376658.38644609577;
    bool hdRfuZGYcSL = true;
    bool zjorBiljkhk = true;
    bool mqPJYVM = true;
    string FgkApo = string("EcArfcdMIPDNQKIRReesgbROIiOsRYSesGnZfTTkDrGfCDHUDCOmazbfMrijETVcaWFpcMfpHwSIfnXfTyMYMPORVJHBLUzBelUxWdpUWtgQvgNEOlIUIBwAJ");
    bool qrtDy = false;

    if (bvVfyeaCqcQShMmM != -179686.21621254465) {
        for (int HKfpO = 556568997; HKfpO > 0; HKfpO--) {
            continue;
        }
    }

    for (int eOhohEsNBpanU = 1913071901; eOhohEsNBpanU > 0; eOhohEsNBpanU--) {
        continue;
    }

    return qrtDy;
}

void PrltGZJAB::kdIwEpcmJKiOLJF()
{
    bool YTMQIaq = false;
    string dTvZgJ = string("ubrEzKpiSuPWNOhEPdIiuQWQDByywQvjjPKrCwLCiTsRvPyuLuXPjEACHshKMAzvZfqJsSEpohZzpKmiODPBcnYomkJWZRSvAibQNQuEgjbtJNpiuWsSzIwWCMcPubECRUHzpWqvsTFoBizcvhwrt");
    string uRxKdwBroifcNOA = string("NiVzLQbtqTXflnGhMnwQLrBhMjsXlbhexmmiIYWIZDQUfXKWtDGgltOOuhTDhswuvOrJMZlBgoMzqOVWkkFjbrAWlpRsrsYsQVzCaxQeOKDeCpJmitkRHNYxMTcwCYdZdTKBTbyRNiIkfTnycEXOmoyzUyhqnWQKVV");
    bool YVvlFQCzOBsDocp = true;
    int SuaXMLe = -474990971;
    int XSTvimBrQeJencDO = -184729001;
    string ZiVbrIuWVGfMGvrf = string("qScxSXfDjpNpfLtbAbbbvqXOaXfFoMVdqrfNcDQLyPAmidgPDlpqvupnQPZKOXxikxWqhrSUhdLIajUwfcyaBbXfP");
    string kkqxMLTRdrWIhEh = string("AdOgGCDtIXSrZNZbvDcEYjSoJutcLSJDxhsBCqadgVuWgaoGrUlUHhccDNoaTmQQifHfEykekwkHTrCbyrZAdODkLjwkTXTymAtfTlQOzwySluaEhPuhpRRIcQlGbtNxfpuVjcepiYJzxVQfrOwLpx");
    bool kSRsK = true;
    int ACzGztMKzhCbFTI = 546535195;

    for (int AHNjpAlGm = 1088683196; AHNjpAlGm > 0; AHNjpAlGm--) {
        YTMQIaq = kSRsK;
        dTvZgJ = dTvZgJ;
    }

    for (int maPovHMr = 1736495436; maPovHMr > 0; maPovHMr--) {
        kkqxMLTRdrWIhEh += uRxKdwBroifcNOA;
        XSTvimBrQeJencDO -= SuaXMLe;
    }

    for (int rbjnsh = 587906868; rbjnsh > 0; rbjnsh--) {
        ACzGztMKzhCbFTI *= XSTvimBrQeJencDO;
    }

    if (YTMQIaq == true) {
        for (int tYzCDpmC = 1724876798; tYzCDpmC > 0; tYzCDpmC--) {
            SuaXMLe += SuaXMLe;
            ZiVbrIuWVGfMGvrf += dTvZgJ;
        }
    }

    for (int wZsOVLqlKgLT = 2111447606; wZsOVLqlKgLT > 0; wZsOVLqlKgLT--) {
        dTvZgJ += kkqxMLTRdrWIhEh;
        uRxKdwBroifcNOA = ZiVbrIuWVGfMGvrf;
    }

    for (int jtxGtKJe = 1445698264; jtxGtKJe > 0; jtxGtKJe--) {
        uRxKdwBroifcNOA = ZiVbrIuWVGfMGvrf;
        ACzGztMKzhCbFTI *= SuaXMLe;
        dTvZgJ += kkqxMLTRdrWIhEh;
        uRxKdwBroifcNOA += kkqxMLTRdrWIhEh;
        uRxKdwBroifcNOA += uRxKdwBroifcNOA;
        ZiVbrIuWVGfMGvrf += kkqxMLTRdrWIhEh;
    }

    for (int aaYlFmBnylV = 651001122; aaYlFmBnylV > 0; aaYlFmBnylV--) {
        continue;
    }
}

string PrltGZJAB::uIBKABr(double cvvTKnn, string JuyjXVmJoGZj)
{
    double MCGzLcMp = 346393.27581866435;
    bool nmmaDJLOvRcvpT = true;
    double ieycTPCLFUgyAajt = 640413.4947236332;
    int nOqCTBboCtN = -937601187;
    int LxzLnuI = -529492652;
    double afryxHHAhVF = 167754.83624306027;
    double mbGAzQCoJHPTivi = -349084.05728324864;
    bool XuufBmKl = true;
    bool nAFGqFSBlqy = true;

    for (int SpmEPQAoES = 1971347941; SpmEPQAoES > 0; SpmEPQAoES--) {
        mbGAzQCoJHPTivi += mbGAzQCoJHPTivi;
        XuufBmKl = nAFGqFSBlqy;
    }

    if (afryxHHAhVF != 167754.83624306027) {
        for (int fwoQIK = 1205785432; fwoQIK > 0; fwoQIK--) {
            XuufBmKl = ! nAFGqFSBlqy;
        }
    }

    if (ieycTPCLFUgyAajt != -349084.05728324864) {
        for (int QveAJWLm = 572930284; QveAJWLm > 0; QveAJWLm--) {
            nAFGqFSBlqy = XuufBmKl;
            cvvTKnn /= MCGzLcMp;
        }
    }

    return JuyjXVmJoGZj;
}

int PrltGZJAB::JnklULHkg(int PYqvZzmzGZK)
{
    string nFUCXPgEkPc = string("VptxWpkQXaPaHuKIcRsUrkCWCjmdvyisNpQKfLZGbkZUiynQYCiXbwaYMu");

    if (PYqvZzmzGZK >= -1568277407) {
        for (int EzxkYY = 698759285; EzxkYY > 0; EzxkYY--) {
            nFUCXPgEkPc = nFUCXPgEkPc;
            nFUCXPgEkPc += nFUCXPgEkPc;
        }
    }

    if (PYqvZzmzGZK < -1568277407) {
        for (int oHKFbxUfMMwHKkX = 2015684176; oHKFbxUfMMwHKkX > 0; oHKFbxUfMMwHKkX--) {
            PYqvZzmzGZK -= PYqvZzmzGZK;
            PYqvZzmzGZK /= PYqvZzmzGZK;
        }
    }

    return PYqvZzmzGZK;
}

string PrltGZJAB::LnkyFvqe(bool bQAjDhkESLwb, int jbXPcnbetgX)
{
    double qWvHN = -844316.3152088331;
    string JxQrATWirWciKIGZ = string("QGPgLrWYkUHpZfiFApInUPJQoQfigoqkhCXIiNVeqGpUEziVzXDtnzRkhjEGQQfACXIaQpJOsrVbjiFjfVpRTpHRnSSYbdoVnbkfuwTzWRYTHsLdXZWWxtiaSRvWKdoJGQDSpWvsWlgwBsnzJZLzmIgVsEwuYBOkyJZWOXaqFeGgzMRTnOkiGfReBUhROUWyIVoHFMbMtUSB");
    string EIaUpsqbQkiNbOT = string("LOwQKZejKwHLnQyTKngFVbPfxVAIOXjkPMMuesFyoaBrVDjlXIkNZfrEbMrzljzphyFpUjHHNSOaEZKCzbYdfYibQvcTvmuTcv");
    bool HrzjIQn = true;
    int IWNGXIDGS = -406358403;
    bool THZGBDek = false;
    double EXthUcFau = 336015.8798755463;
    string umZaGrs = string("YumSYojWLYPUNpXIihTXfFxCkSvTUfPQITYiQwJizGZAQKkkAzbwpMwdUlyzuBzKiDsMCpONaRoDrpgOcOhCUfWcbJXYXMzOdMRYHtdrsJFhILMCmKqdrWZmxyduLLGTMzeADKhsLcOU");
    bool BQONiUK = false;

    if (JxQrATWirWciKIGZ >= string("LOwQKZejKwHLnQyTKngFVbPfxVAIOXjkPMMuesFyoaBrVDjlXIkNZfrEbMrzljzphyFpUjHHNSOaEZKCzbYdfYibQvcTvmuTcv")) {
        for (int gEfZgONVWbKATT = 85957793; gEfZgONVWbKATT > 0; gEfZgONVWbKATT--) {
            EXthUcFau += EXthUcFau;
            HrzjIQn = ! BQONiUK;
            EIaUpsqbQkiNbOT = EIaUpsqbQkiNbOT;
        }
    }

    for (int hmGllhn = 1933420619; hmGllhn > 0; hmGllhn--) {
        continue;
    }

    return umZaGrs;
}

string PrltGZJAB::dwJAACpSrmQpax(string kCXcn, bool jtsLLLVFO, double aYjlXOzyVbWYpeg)
{
    string qHapcicC = string("yhnUgdnSYUzNDbLRHSWVehMwyNBDznjYgrlkmuPAUzcVwAnsxPjXFomopBjqcmbgiXHoBaQtMbxkzsqfJkHsdcinoIbtmkTjseuzaknAWxcXoHsLMjzTcSsDzRhoPOGtullnLl");
    bool ZbAkoFTcamVHrzN = true;
    double ePqXoc = 167294.30751634156;
    bool mmpemF = true;
    double UOLItshuqAxmtVfA = -593820.0570401837;
    bool PIhlfuJFCzof = true;
    string OvJaZmjmgbncI = string("TcZuFWnxXavoUFwsEtATOTmFBwkvTVRQjugFWWXAstUrCrdgsfNdhnBwkLGRapesqeQUSOvMDPhmzejrwZyPZCZeeabKhZxAXgVwAXwbTYqScqFpBoJNstMIoAGAnULoqLNQXBjMrAkAAKeSdiLdHDUKMbXsPUIuwmCjxKMiyiJCFiAFsiRQOCAJiIQPFZYzIzLJyaAeW");
    double YNpGOvkwGCUl = -498513.2306971334;
    int qkNfSHcuNcsddE = -6555975;

    for (int jYHDZXaeVOWhwo = 2001817265; jYHDZXaeVOWhwo > 0; jYHDZXaeVOWhwo--) {
        qHapcicC = OvJaZmjmgbncI;
        mmpemF = ZbAkoFTcamVHrzN;
    }

    for (int kbjcV = 383071467; kbjcV > 0; kbjcV--) {
        mmpemF = ! ZbAkoFTcamVHrzN;
        kCXcn = qHapcicC;
        mmpemF = ZbAkoFTcamVHrzN;
    }

    return OvJaZmjmgbncI;
}

PrltGZJAB::PrltGZJAB()
{
    this->OFnYPkDfJ(string("ckumIqgEIhxQyNFggyGUUlaSeJapEqIOXLFoPqvracXGTJgdqoZAhMshVYtJllYmdkxKFaPeuxbsRDloAiZWftNAGkuwmuJtyllerTWiUeuNaZHSGJQpbBtHoiqGHTWzRKX"), false, -719154.829801703, 292368.5615175209, string("lDECZOVhWjnForDdnoJPzlQbyDpqyHNzPgnDWzrTkHcsAKEAqYNnNPzYPbnDqWSKMFuvjJLQZpofvFCYMgSHFfjNSZJdcmTsmPLnskAhmqQMEagfziDWpvXRRRcvXhTRTlgnnohRMlhFinWI"));
    this->DRKqocOfKYxZQBTV();
    this->rIIcumzlepDTLj(string("mbiQtfcmjlpyWeHEiJQmOnzlqUCacOLpjnbpnERfJLhFeQaIXHWuoUXlGiISHBuxdCjfuWGqQLmnYpiSjakxDhiWVarS"), string("bYoXmrXMrMwJDdbimyToxjkcqnulbOUjcEyVQIezKrDXNDGWhRcQuFWHmsiafYApSVdfaYZDLhrHpBXQySlRUwFInmLEThmAZgmSwWXZZntDeOTCJGtGKXjJQKOgeRVJucAVWSSALQwzkhbazysjVSWYQTORGgbNSDzYqrvppERUVMriQyGRvxCSLAemPkyspwHU"), -336055.2718596153);
    this->OmXFpnjOYmKYoem(-714820.5352366873);
    this->dSDsdkcPjKtUAQ(string("nxzLMmfFqODjtJBFabpmZTIUtPGtDbrdeOjrkbztpxYHILqRciaNvtgQJROzxMfQpDDElZojbrlkmJyaadzUwaYPEHYNpRFZJGdVJLTsiVrQNTIAWYcNppATsrateRggTOnwbUoClrIxZcoTcWpujwxEhxiAdqrEWZTAdsmxozKDbK"));
    this->kdudW(996751051, -179686.21621254465, string("oKuBVISyOLTzbkbwuZBQilYKNahMRlxiBsBmZcNXebxBQJCXgAOYxFvZBquyOgjQMGehkRMlwaWhHmtXcGcmELECfQBZliNWGIxTTlCSmHbbBmaUDChrByrxBUDVHWMITTUuPvmMPiOdQRdpkQKkCbRlNFOuDIJkh"), true, true);
    this->kdIwEpcmJKiOLJF();
    this->uIBKABr(-885875.4329748509, string("BhtmGKxUVRCtJjBNtSdfqLgGDPWzKDyJWKfchCmnjgUJVjNmyjCym"));
    this->JnklULHkg(-1568277407);
    this->LnkyFvqe(false, 1866205716);
    this->dwJAACpSrmQpax(string("ZooJPIfnwKNOWzOQEybxOBgXpIZqpNlvZnCDREpsmAmSaiVjUlWNYZLkNWuUGOlYCsNdhRPpvYmkUJFPWhIMRxBCZOleMgisBgrbmWIwZaPQremDslxoiXQYvaxwrqckbAJkBsltCtWkaKSxNfmyQpKiXIIGXXcxOtSPkacEhvJStkKsNkGtNwsTQ"), false, -935479.4773853254);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kVspsZEw
{
public:
    string aSDZD;

    kVspsZEw();
    string nmzZNKEBoBpcnirF();
    int QfNJnzuMDRBscBsS(int UUDjkdjdAHOH, double ftkhfNqJwrRx, double MfTXyVdcWGhQHJT);
    string hAfjz();
    double VqlqhdrQdXdk();
    void mzVKZ();
protected:
    double qMHUhFsQgc;
    bool IGsopZLZlE;
    int AxXSGdxPyw;

    bool WhTmlybPBdHLqJW(string besZryrFMbcH, int ZWYZeyeNVJJD, bool OVteqtyKVFQZSuiR);
    void NhYEEupB(string EwZBUvuu, int VOXrjnvntPhTZE, int oMSAuByw);
    int ILkTyoNeqpfYTtIS();
    int XZECLknfpMgPtVxk(bool DHSahLPlJElPYkN, bool asxxXQ, bool VzRznYMqjSxg, double PdKgBhQDQJaOftfH, bool ydgPoSXAi);
    void QidbRVMTJ(int jOjMHpVeHTAbtayi, bool PaDGgSNxhvXR, bool UQfXDOxO, bool dlpfybncXRMeVuQV, string CorbpZBrTeittCK);
    int IToemJDuFHHxjS(double XafRBX, string RSPaShL, double felSRWPXP, string JtrXpUVRFw, int wDIHrrwQotMqbir);
    void KDZryDfOBJAA(bool WXidAqkoPr, int MzJnpVBaxSCZFjCU, int lMOdfbjgNVRXHKJ);
private:
    double MUImwEeYKJXrwSq;

    bool nZcczDWjE();
    double wTILzbvJpzquC(int ogTNIdodOKH, double KnrotnXYVzfyscER, int wowvIsMidv);
};

string kVspsZEw::nmzZNKEBoBpcnirF()
{
    string WZGLyDALqQMmaAWa = string("lzSmnhSXXrFiklNnmdzPMlSHKwLttgkiwDPhbbEqoVIxXHkHtNSdIkATjNZpInynOZSxbQjzRLBsIrDPDtReRnugXBaJFaDJyhghmrehELqqFvfSuqrlTpjAmjuWwNqbm");

    if (WZGLyDALqQMmaAWa <= string("lzSmnhSXXrFiklNnmdzPMlSHKwLttgkiwDPhbbEqoVIxXHkHtNSdIkATjNZpInynOZSxbQjzRLBsIrDPDtReRnugXBaJFaDJyhghmrehELqqFvfSuqrlTpjAmjuWwNqbm")) {
        for (int SWBobXftseHiZ = 1799025905; SWBobXftseHiZ > 0; SWBobXftseHiZ--) {
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
        }
    }

    if (WZGLyDALqQMmaAWa > string("lzSmnhSXXrFiklNnmdzPMlSHKwLttgkiwDPhbbEqoVIxXHkHtNSdIkATjNZpInynOZSxbQjzRLBsIrDPDtReRnugXBaJFaDJyhghmrehELqqFvfSuqrlTpjAmjuWwNqbm")) {
        for (int fJLZhQDzZxqd = 2010054219; fJLZhQDzZxqd > 0; fJLZhQDzZxqd--) {
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
        }
    }

    if (WZGLyDALqQMmaAWa == string("lzSmnhSXXrFiklNnmdzPMlSHKwLttgkiwDPhbbEqoVIxXHkHtNSdIkATjNZpInynOZSxbQjzRLBsIrDPDtReRnugXBaJFaDJyhghmrehELqqFvfSuqrlTpjAmjuWwNqbm")) {
        for (int NLjspULqOAa = 1166642720; NLjspULqOAa > 0; NLjspULqOAa--) {
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
        }
    }

    if (WZGLyDALqQMmaAWa >= string("lzSmnhSXXrFiklNnmdzPMlSHKwLttgkiwDPhbbEqoVIxXHkHtNSdIkATjNZpInynOZSxbQjzRLBsIrDPDtReRnugXBaJFaDJyhghmrehELqqFvfSuqrlTpjAmjuWwNqbm")) {
        for (int oiFABVT = 164873376; oiFABVT > 0; oiFABVT--) {
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
        }
    }

    if (WZGLyDALqQMmaAWa == string("lzSmnhSXXrFiklNnmdzPMlSHKwLttgkiwDPhbbEqoVIxXHkHtNSdIkATjNZpInynOZSxbQjzRLBsIrDPDtReRnugXBaJFaDJyhghmrehELqqFvfSuqrlTpjAmjuWwNqbm")) {
        for (int KhxDnMemtudlWC = 451279098; KhxDnMemtudlWC > 0; KhxDnMemtudlWC--) {
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa += WZGLyDALqQMmaAWa;
            WZGLyDALqQMmaAWa = WZGLyDALqQMmaAWa;
        }
    }

    return WZGLyDALqQMmaAWa;
}

int kVspsZEw::QfNJnzuMDRBscBsS(int UUDjkdjdAHOH, double ftkhfNqJwrRx, double MfTXyVdcWGhQHJT)
{
    double rKKLDbGz = 81325.45295413416;
    int aKjvGcuB = -67702181;
    bool hDJTu = true;
    bool foKsSzcMgFx = false;
    double rnZkV = 144167.648288231;
    double FollHRMtsWgz = 907497.3302876253;
    double MPTEgoH = -919085.9596550519;
    bool oDWxVNpCNLmZ = false;
    int dpZJHkWfInXRVAar = 549715144;
    bool WiQbYDevH = false;

    if (aKjvGcuB <= 549715144) {
        for (int DFdRSFQSIpSmhVz = 4298369; DFdRSFQSIpSmhVz > 0; DFdRSFQSIpSmhVz--) {
            rKKLDbGz *= FollHRMtsWgz;
            WiQbYDevH = hDJTu;
            FollHRMtsWgz += FollHRMtsWgz;
        }
    }

    if (aKjvGcuB < -67702181) {
        for (int uRTEQY = 1555451268; uRTEQY > 0; uRTEQY--) {
            aKjvGcuB += UUDjkdjdAHOH;
            rnZkV *= ftkhfNqJwrRx;
        }
    }

    if (FollHRMtsWgz != 81325.45295413416) {
        for (int qxrzfbGjBxRpZd = 267289268; qxrzfbGjBxRpZd > 0; qxrzfbGjBxRpZd--) {
            ftkhfNqJwrRx *= MPTEgoH;
            oDWxVNpCNLmZ = ! WiQbYDevH;
            MfTXyVdcWGhQHJT += rnZkV;
        }
    }

    for (int XvdeOWotckWnm = 586581891; XvdeOWotckWnm > 0; XvdeOWotckWnm--) {
        rnZkV = rnZkV;
        rKKLDbGz /= ftkhfNqJwrRx;
        UUDjkdjdAHOH = dpZJHkWfInXRVAar;
    }

    return dpZJHkWfInXRVAar;
}

string kVspsZEw::hAfjz()
{
    bool FgKfPz = true;
    string zSvIIpNYvyoA = string("NWFZkZZMZzBSLtJRQrjXPcvUZYJQNJOoiAelLLzJinhuzrGGsSOYKnTdcBwUUXeddOrzkNYIUZIGqJJLIOIItAAZmnAscQjuYHMXkPSXXdDjDoIbeQRNbXnXq");
    string NObcqVpWtlWuq = string("mqagBSFuqQlYiHBWSbdSNUrkyhlszsxKiCdtTAFdzuFVeknacVOqQiApTFXYYpBbjIrKliiBlcewRnViVfIqtkXohdrckMJUCLNeuttQdcMcJYgBLgNsITzXsmmKkjmjjCHEDXGrjAtMijyCJtxSIXZKNoYmYoZDXLYWqeQaCEoQiotTA");
    bool qDPcqF = false;
    double veQNRqYRQjZJJVQa = 674043.5956341703;
    bool cRsOKVRJR = false;
    double RUCIrLJLqn = 844863.1083382227;
    int tvsrcpCy = -1292381007;
    int eRVAWA = -797689384;

    for (int ZCNCsetcACv = 1194816606; ZCNCsetcACv > 0; ZCNCsetcACv--) {
        eRVAWA /= eRVAWA;
        FgKfPz = ! FgKfPz;
        FgKfPz = qDPcqF;
        zSvIIpNYvyoA += zSvIIpNYvyoA;
    }

    for (int vihKCHLbtHeRtKCt = 154767526; vihKCHLbtHeRtKCt > 0; vihKCHLbtHeRtKCt--) {
        continue;
    }

    for (int cqsjTXJZl = 510523409; cqsjTXJZl > 0; cqsjTXJZl--) {
        FgKfPz = ! qDPcqF;
    }

    for (int ZMcXSylWP = 1839085854; ZMcXSylWP > 0; ZMcXSylWP--) {
        veQNRqYRQjZJJVQa += RUCIrLJLqn;
    }

    for (int ExciqB = 2018107096; ExciqB > 0; ExciqB--) {
        continue;
    }

    return NObcqVpWtlWuq;
}

double kVspsZEw::VqlqhdrQdXdk()
{
    bool jgzXsTGAztavIDw = true;
    string OAPOwYHSXTK = string("LSnzsERRroutDXYbDYpUJJgexDyZERkAAQoSyGAqltGwQVJPebbrRlsaseyMhQURgopOJyyvMQVnZgsoFyMQEdiOePMrUaVImyOtwqSVPOSkcalLgzYzVSNqKLBJHHrILSwIosYJSddP");
    string FpjFAuSMGAUhwe = string("ZgWsmPBezATheuvqmJgpFwYqyArZsMuYeOcpOmMKQfzdxVvWXMjvydNIPMYvMFtzrvRARGAwMqjsTmitDDFpnWuYschdvQWjZNuOhDPqxWShcKAOUmFGOpkJCTUYbnYNvqWXXiUnHQJUouqWDFPwF");

    for (int whuRQnsrYRs = 407116084; whuRQnsrYRs > 0; whuRQnsrYRs--) {
        FpjFAuSMGAUhwe = OAPOwYHSXTK;
        OAPOwYHSXTK += FpjFAuSMGAUhwe;
    }

    return -836457.1387883499;
}

void kVspsZEw::mzVKZ()
{
    string ApbUOfag = string("uroChpmCRFGZtiXDDdKAEwBWaLOjoBYOnqvzAeILXPTTGlJKJDsePtzvnuHSzwkJqdzqYBdGBBrOEaNNcKpnQJKIYuEtFTpYCtiRSthtJQJhGkBCaElKdWcIQGIohmhyZDxqkFyxEKsOp");
    string YfBtfaMO = string("kBiQFzLrVgEjijyyMcpnyvdrAfxbcJxtqQCzTXZnzeauOKeplTbWoalLyLALxKBrrDvCBEWzsZpdtFkQbtbyXcrEWiEpNTVEYgzwDeOOcWrWvpfRKcl");
    int kJQjgoEZVZs = 1120672396;
}

bool kVspsZEw::WhTmlybPBdHLqJW(string besZryrFMbcH, int ZWYZeyeNVJJD, bool OVteqtyKVFQZSuiR)
{
    string ySMuZgbbjFiPFwkA = string("OskfWwRSUCGjKpHepMIBeLawqrjHylAABYGPldKvzWgZldSMWFvIDNOjcdhpffOmgMNmOkqEmdrQGxjudAcRyCfoibXSsvroWfcDgkZNIwSWIpbPdzfOwMLUVRocKHCukBNlklFhLBayJnhrFUthJshaoYuZtsbfvEuPvKGuNuymebuUniCsPTCMqRzaFCgPmolNNjrleyFGjkRTVKWgxviveBQxSzieMcAzhdOHJQvqaXQ");
    string mxUZu = string("mYeStMgQpPIagGQUVzILwtaCmJfxhgyHEyfdJdjvMXThMPPWpiiSEHcXUqQmINZdsuedLxIHEELUomexkPHGbvBnmQCoTWGPVAqHMisSXdGcrZWHaqSwOGwNS");
    string EEoXHpzmxlOrAn = string("UaBXkuKlgQkRlrHTAEkQmOdVRnJFbQYVSjyHoLoPCUiWkdUWGiQiBqtZjxtVketxnhGZdOwRxyDJwRVoqizSlrUiNJhAxoRoKjMQGwCkygOUOOzILDekobTWsUuelrqKdWYYKjNfJMGOTQQKoGWuCVfLsQGMrJVpaIbLWmWcbwclfwoiAJuayOzAGTTFjJpiXH");
    int XFkFaDiPmPRnLC = 1780030350;
    string UHGFnoOjxwZZNNP = string("oFgFiaAMYGNxsrqIaNiNsGlKjHETnQwGLtHMUsyVaSYjLlPMRlzPObmlPdLlOgFfQKhGCVhOhizqLIOzmjFfiqzolxlVosyDIhsFlSrJrtgKJDNiWYegbAqMPVoQXUFIZPTDrWwDUHrzCtSzmnAzIaWYuOdiKZRRVGwiipCvqjAPQmqFQsNRJZ");
    bool FZtNk = true;

    if (mxUZu > string("mYeStMgQpPIagGQUVzILwtaCmJfxhgyHEyfdJdjvMXThMPPWpiiSEHcXUqQmINZdsuedLxIHEELUomexkPHGbvBnmQCoTWGPVAqHMisSXdGcrZWHaqSwOGwNS")) {
        for (int TVxnd = 1224224379; TVxnd > 0; TVxnd--) {
            UHGFnoOjxwZZNNP += UHGFnoOjxwZZNNP;
            besZryrFMbcH += ySMuZgbbjFiPFwkA;
        }
    }

    if (FZtNk != false) {
        for (int UInWAwjFNxMaiKYg = 1296672375; UInWAwjFNxMaiKYg > 0; UInWAwjFNxMaiKYg--) {
            continue;
        }
    }

    for (int hqWvCR = 2108245987; hqWvCR > 0; hqWvCR--) {
        besZryrFMbcH = UHGFnoOjxwZZNNP;
    }

    return FZtNk;
}

void kVspsZEw::NhYEEupB(string EwZBUvuu, int VOXrjnvntPhTZE, int oMSAuByw)
{
    bool tSyxOphITSdASob = true;

    for (int ErrynnrnsLkTNxT = 1278131083; ErrynnrnsLkTNxT > 0; ErrynnrnsLkTNxT--) {
        EwZBUvuu = EwZBUvuu;
        VOXrjnvntPhTZE = oMSAuByw;
    }

    for (int WIVuwLjmX = 1197583421; WIVuwLjmX > 0; WIVuwLjmX--) {
        VOXrjnvntPhTZE *= oMSAuByw;
        VOXrjnvntPhTZE -= oMSAuByw;
    }
}

int kVspsZEw::ILkTyoNeqpfYTtIS()
{
    double OgcxuksUPlmcE = 806091.9428440379;
    int rMXcVAIYEOMilc = 599266040;
    double aJPwnokI = -820779.3229218993;
    double nhYhCsfh = 194917.78289805484;
    double XNNqdwZUcD = -229452.555572827;

    if (rMXcVAIYEOMilc > 599266040) {
        for (int Uqiuqxbp = 1997996814; Uqiuqxbp > 0; Uqiuqxbp--) {
            nhYhCsfh /= aJPwnokI;
            XNNqdwZUcD *= XNNqdwZUcD;
        }
    }

    if (nhYhCsfh < 194917.78289805484) {
        for (int JvmfzwuoBCXqSA = 833046112; JvmfzwuoBCXqSA > 0; JvmfzwuoBCXqSA--) {
            nhYhCsfh -= aJPwnokI;
            OgcxuksUPlmcE /= OgcxuksUPlmcE;
            nhYhCsfh = OgcxuksUPlmcE;
            nhYhCsfh *= XNNqdwZUcD;
            XNNqdwZUcD -= OgcxuksUPlmcE;
            XNNqdwZUcD *= nhYhCsfh;
            rMXcVAIYEOMilc -= rMXcVAIYEOMilc;
        }
    }

    if (OgcxuksUPlmcE <= 806091.9428440379) {
        for (int PwkQzRaXHl = 1990031718; PwkQzRaXHl > 0; PwkQzRaXHl--) {
            rMXcVAIYEOMilc += rMXcVAIYEOMilc;
            OgcxuksUPlmcE = nhYhCsfh;
            nhYhCsfh -= OgcxuksUPlmcE;
            rMXcVAIYEOMilc -= rMXcVAIYEOMilc;
            aJPwnokI += aJPwnokI;
        }
    }

    for (int AMRhDRdikfk = 937396922; AMRhDRdikfk > 0; AMRhDRdikfk--) {
        nhYhCsfh = nhYhCsfh;
        OgcxuksUPlmcE *= aJPwnokI;
    }

    for (int Ksfox = 1365597788; Ksfox > 0; Ksfox--) {
        OgcxuksUPlmcE = nhYhCsfh;
        aJPwnokI += nhYhCsfh;
    }

    return rMXcVAIYEOMilc;
}

int kVspsZEw::XZECLknfpMgPtVxk(bool DHSahLPlJElPYkN, bool asxxXQ, bool VzRznYMqjSxg, double PdKgBhQDQJaOftfH, bool ydgPoSXAi)
{
    bool YCgZlRIjTJJXxIX = true;
    string fkDbCBOaOi = string("ZjSGapnqBAAfAbMbPvbqUSFXhKRFOoBnMMwljFLpJSuXiFKcscHWGxNvlElboTjaJiWMvEgIzomLqAgzdzeKVKUcQIhATwzqPpetwRjVOahZysXYjWEhvEvcvyszHxXkfbnXHjOqAkpnKMcWhcbnGAgJyYwq");
    string MrczcUviuZ = string("cNuQgUDHQvG");
    double wiVAztCAtTluct = -955570.7001880123;
    int xHLNUPHJvnrIxY = -1270288116;
    int rDFVho = -1279297074;
    string elKeYFIUrCDBgT = string("BemoDlnFhrJLCfduXlLruIhtcZbQLxFRdtuEsSeJWhyopeUrPmfnxsUBpGDLIYhjFHVWUNRbq");
    int kxuLGfTDRwAb = 867039466;
    bool giXifsadrew = true;

    if (giXifsadrew != true) {
        for (int QLwMGamb = 1027304553; QLwMGamb > 0; QLwMGamb--) {
            ydgPoSXAi = YCgZlRIjTJJXxIX;
            xHLNUPHJvnrIxY *= rDFVho;
        }
    }

    for (int obsRyB = 392655720; obsRyB > 0; obsRyB--) {
        ydgPoSXAi = VzRznYMqjSxg;
        rDFVho *= kxuLGfTDRwAb;
        fkDbCBOaOi += fkDbCBOaOi;
    }

    for (int qcsfjnpqWb = 80461608; qcsfjnpqWb > 0; qcsfjnpqWb--) {
        kxuLGfTDRwAb *= rDFVho;
        DHSahLPlJElPYkN = giXifsadrew;
        xHLNUPHJvnrIxY *= kxuLGfTDRwAb;
    }

    return kxuLGfTDRwAb;
}

void kVspsZEw::QidbRVMTJ(int jOjMHpVeHTAbtayi, bool PaDGgSNxhvXR, bool UQfXDOxO, bool dlpfybncXRMeVuQV, string CorbpZBrTeittCK)
{
    string Ahkkcux = string("WFGSkRRkOgyElzPFFRdHkvgaWplzqocFkApOeMwzhbLUtsIVzAhf");
    double RYTECtdZlPcERfUD = 555102.0928159993;
    double LlqKkxcXfHwyY = -10829.681217028274;
    double dsDUwJoQpSIdRWim = -350026.03690081893;
    int hNYoeRjMBLnCfL = -1161337668;

    for (int ZQOuYobfGFqM = 726718058; ZQOuYobfGFqM > 0; ZQOuYobfGFqM--) {
        dlpfybncXRMeVuQV = dlpfybncXRMeVuQV;
    }

    if (LlqKkxcXfHwyY >= 555102.0928159993) {
        for (int xQJirhOiGN = 1548271041; xQJirhOiGN > 0; xQJirhOiGN--) {
            Ahkkcux += CorbpZBrTeittCK;
            LlqKkxcXfHwyY *= LlqKkxcXfHwyY;
        }
    }

    for (int gBqOWjbIzs = 2111435065; gBqOWjbIzs > 0; gBqOWjbIzs--) {
        RYTECtdZlPcERfUD /= LlqKkxcXfHwyY;
    }
}

int kVspsZEw::IToemJDuFHHxjS(double XafRBX, string RSPaShL, double felSRWPXP, string JtrXpUVRFw, int wDIHrrwQotMqbir)
{
    string qLwwbXoUr = string("iiYApGEDJUVccNVhzKsAiJZrevFOEntrLKzaXlUQqdKarMmKJsLrWDsaRgOkwhaZJWcHPUqXoMCxZngxkBGkZulJrSzJLYWMWmjCkNEffURcBtSxFLnFXURifkkfKeyOrrXBfpXjQtzwfyXxkOqqwkmmNddKBPkYlDbivAlblj");
    double QFldIVBrEKBdePGV = 375656.4279377104;
    int COkPTDvilCRPV = 298894800;

    for (int kibzKHaNjX = 773936708; kibzKHaNjX > 0; kibzKHaNjX--) {
        RSPaShL = JtrXpUVRFw;
    }

    return COkPTDvilCRPV;
}

void kVspsZEw::KDZryDfOBJAA(bool WXidAqkoPr, int MzJnpVBaxSCZFjCU, int lMOdfbjgNVRXHKJ)
{
    double nLVZW = 204361.25240222842;

    for (int vwDtkoKN = 990491431; vwDtkoKN > 0; vwDtkoKN--) {
        lMOdfbjgNVRXHKJ += lMOdfbjgNVRXHKJ;
        MzJnpVBaxSCZFjCU -= lMOdfbjgNVRXHKJ;
        lMOdfbjgNVRXHKJ -= MzJnpVBaxSCZFjCU;
    }

    if (lMOdfbjgNVRXHKJ < -2038726056) {
        for (int jCmNRBxEyzJdeNOO = 901090200; jCmNRBxEyzJdeNOO > 0; jCmNRBxEyzJdeNOO--) {
            nLVZW /= nLVZW;
        }
    }
}

bool kVspsZEw::nZcczDWjE()
{
    int GiGTlG = 183897886;
    bool YaISSPIik = false;
    bool UpjDxScl = true;
    bool ZkRCvYdPdP = false;
    string xApDEwbUg = string("WcAJuettxEVwbfhLoQzwQYEukeTiVnsLfJRanmLKxRTwDKwgOyXMDoaraaxpXkIrrPncvOlxhNznaYfvJfaDgXwrERzffDmDuDfo");
    bool ZsBcSEf = false;
    bool uwkYDyUXc = false;
    bool UXofCTRVuOIARFo = false;
    double LAEYLOOXAYOQP = -276893.5915996043;

    if (YaISSPIik != true) {
        for (int QWgzTi = 1697437870; QWgzTi > 0; QWgzTi--) {
            UpjDxScl = ! uwkYDyUXc;
            UpjDxScl = ! UXofCTRVuOIARFo;
        }
    }

    for (int bVhcWgdoMBfb = 1453973002; bVhcWgdoMBfb > 0; bVhcWgdoMBfb--) {
        xApDEwbUg += xApDEwbUg;
        UXofCTRVuOIARFo = UpjDxScl;
        UpjDxScl = ! uwkYDyUXc;
        ZsBcSEf = ! UXofCTRVuOIARFo;
    }

    if (LAEYLOOXAYOQP != -276893.5915996043) {
        for (int gFgFr = 871787338; gFgFr > 0; gFgFr--) {
            UXofCTRVuOIARFo = UXofCTRVuOIARFo;
            UXofCTRVuOIARFo = ! UpjDxScl;
            UXofCTRVuOIARFo = ZsBcSEf;
            uwkYDyUXc = ! UXofCTRVuOIARFo;
        }
    }

    return UXofCTRVuOIARFo;
}

double kVspsZEw::wTILzbvJpzquC(int ogTNIdodOKH, double KnrotnXYVzfyscER, int wowvIsMidv)
{
    double NwpFtelr = 655428.3020016128;
    int mWkpRXIwB = -834784108;
    double BxPqbUgHHoNw = 895299.0041689432;

    for (int cQqiRqTu = 384322241; cQqiRqTu > 0; cQqiRqTu--) {
        ogTNIdodOKH -= ogTNIdodOKH;
        BxPqbUgHHoNw += NwpFtelr;
        BxPqbUgHHoNw = NwpFtelr;
        wowvIsMidv = mWkpRXIwB;
    }

    return BxPqbUgHHoNw;
}

kVspsZEw::kVspsZEw()
{
    this->nmzZNKEBoBpcnirF();
    this->QfNJnzuMDRBscBsS(-282742450, 758038.1703990421, 726858.7363940874);
    this->hAfjz();
    this->VqlqhdrQdXdk();
    this->mzVKZ();
    this->WhTmlybPBdHLqJW(string("MVKiFzPzZUZcvwqjzTqqegbIWOgvLMkDJCHFdiwvyaeeHMENNdxNFwwggvvowMlP"), -1109271785, false);
    this->NhYEEupB(string("baiNxrqPFvpnzbzQJvMBbWeAyvcNBALmXBIWDLkALmKkvBjYxMbb"), -113423077, -1997342747);
    this->ILkTyoNeqpfYTtIS();
    this->XZECLknfpMgPtVxk(false, false, false, -622392.7919835581, true);
    this->QidbRVMTJ(422062053, false, false, false, string("aGOBrVfMvtTkSwLDYqbyaKwVMkqweaGpoIUMKlfnQnRTEPIFqxgbICmlvNnpIrDjzKGnXUQ"));
    this->IToemJDuFHHxjS(526140.1849831798, string("FmlONkMCsbbbuxqpqrgvsNwGiOBnnZusZhVTBOYYcVTTzbaSJEXGqrdNValPAwoSnPhTcX"), 1030058.2635355042, string("ZcqmmmEpDfmQVzwSuasAJIlFHyKYxNlruHjAHkKLoRqIQyGdRbSyvRvqezIyAHcoKkDSuUtYpvkLhuklDEkxjewjFukNpSurfvagmrTbKOogNHeFczPuoOVvXaCriwdMuyLEKKmUdwIIMdbuAqLMIAYvIiOFOZljUWdKOdzYMfGkkUIiuoMGeBLOsHZMzOzuKnumlWaoVSCBjGxPhQAJtzIISpeecIcxrmPtqtEAkJwoxt"), -40793905);
    this->KDZryDfOBJAA(false, -2038726056, 1220530579);
    this->nZcczDWjE();
    this->wTILzbvJpzquC(-1106304294, -1014827.6476596404, -82118126);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DwEqGUoqrjRrkYxv
{
public:
    int OBQJDwpYJ;
    string WhTASgnl;
    bool VnzUnnvuADrYLsA;

    DwEqGUoqrjRrkYxv();
    double KyzxqSSe(bool YzKdyLgyHiGywYv, bool TTEaDAwiHG);
    void QczYoGge(int CWxDIKvVt);
    void qTKMDlCyLjye();
    string sOGQxNPoCzXT(string WgbFmcP, int jQZVKfkCEQ, int VJdavxLaNIWOs);
    string uwzZakOvGV(string pYihM);
    int LkFodQMGpn(double granNXMiAJwrrVoV, int MuYbMmOsP, string IuLFaL);
protected:
    bool xzIsAmTeI;

    double yglzVYWmBBYz(bool vNKFrTh);
    double EjqXzdM(string JhmXMI, string XfPhzYgMzkj, bool CxyitRmiqNf);
    string EObTWdmvmqDLUV(bool yKMRhKTZIh);
private:
    bool WpPrAQgLc;
    bool mwyQjDEYDBA;
    bool wONNJJIsl;

    int UtzzdnE(bool qGudT);
    int KnpqqgsdIVkFlS();
    bool gfbdAKLniwLrdiw(bool NUieIlKJOsuRs, string KfQVtECkQ, string UQAfjTjjL, string oDyyMHfEXi);
    void kmTEjw(string jxbCf);
    string bDdQv(int jzzMsiwobnhgbT, string bgdsi);
    int AcQqoK(int WZWyxOPYiBzB, int zRTxFyOHXdsteUG, double uSrrOl, bool pKmheHBv, string xinxumVMhNwmoUy);
    double weNeQq(double DyGTZdninKvGRO);
};

double DwEqGUoqrjRrkYxv::KyzxqSSe(bool YzKdyLgyHiGywYv, bool TTEaDAwiHG)
{
    bool loUuGyeNJzEyOaSF = false;
    int pNYge = -419988189;
    int fRhWyJsGTWn = -2019767698;
    bool atxggLCxKF = true;
    double lZYfzYDt = 77878.76403901688;
    int gMBXwSUptaD = -1162125124;
    int grzGh = -569762417;
    bool rFRzqUTWMPtppYe = true;
    int TRtooaFsnpniWntM = 278709018;
    string XjfKNYPw = string("tDL");

    if (XjfKNYPw == string("tDL")) {
        for (int frWAM = 1766172949; frWAM > 0; frWAM--) {
            TRtooaFsnpniWntM += gMBXwSUptaD;
        }
    }

    for (int mJabvgilUNrx = 1043451522; mJabvgilUNrx > 0; mJabvgilUNrx--) {
        fRhWyJsGTWn -= TRtooaFsnpniWntM;
        TTEaDAwiHG = rFRzqUTWMPtppYe;
        TTEaDAwiHG = rFRzqUTWMPtppYe;
        rFRzqUTWMPtppYe = ! rFRzqUTWMPtppYe;
        pNYge -= pNYge;
        TRtooaFsnpniWntM += pNYge;
        pNYge = grzGh;
        pNYge -= pNYge;
    }

    for (int yPvOaRkA = 1928392841; yPvOaRkA > 0; yPvOaRkA--) {
        rFRzqUTWMPtppYe = TTEaDAwiHG;
        YzKdyLgyHiGywYv = ! TTEaDAwiHG;
        fRhWyJsGTWn -= pNYge;
    }

    return lZYfzYDt;
}

void DwEqGUoqrjRrkYxv::QczYoGge(int CWxDIKvVt)
{
    int ANOBfRWBuIqUe = -1405256786;
    string ueyhiPvJtZwSxbSG = string("AGTWRtCdBYVLV");
    double pqWCEVr = 519646.27995671134;
    string rehJpJsfvPXPOy = string("paLqwLXqQHROpfmBSAotiWLHmVjemUDvjMUQDUsBAwhiXqlSsEHUrdGwXTxJrGoSdfYqDIGwtqjLYbRwud");

    for (int YNcPmgKcozVoxeBl = 938408678; YNcPmgKcozVoxeBl > 0; YNcPmgKcozVoxeBl--) {
        rehJpJsfvPXPOy = rehJpJsfvPXPOy;
    }
}

void DwEqGUoqrjRrkYxv::qTKMDlCyLjye()
{
    bool eBRyBZc = true;
    double rhtAVs = -511434.38703053055;
    bool BejWrOKVpMtAZF = true;

    if (eBRyBZc != true) {
        for (int RipvYl = 2130789900; RipvYl > 0; RipvYl--) {
            BejWrOKVpMtAZF = eBRyBZc;
            BejWrOKVpMtAZF = BejWrOKVpMtAZF;
            BejWrOKVpMtAZF = BejWrOKVpMtAZF;
            BejWrOKVpMtAZF = BejWrOKVpMtAZF;
            BejWrOKVpMtAZF = eBRyBZc;
            eBRyBZc = ! BejWrOKVpMtAZF;
        }
    }

    for (int LGkYxnOkqYW = 135873612; LGkYxnOkqYW > 0; LGkYxnOkqYW--) {
        BejWrOKVpMtAZF = BejWrOKVpMtAZF;
        BejWrOKVpMtAZF = BejWrOKVpMtAZF;
        rhtAVs += rhtAVs;
        BejWrOKVpMtAZF = ! BejWrOKVpMtAZF;
    }
}

string DwEqGUoqrjRrkYxv::sOGQxNPoCzXT(string WgbFmcP, int jQZVKfkCEQ, int VJdavxLaNIWOs)
{
    double hdDBceQzWedFVe = -577684.3108576756;
    string URFIIM = string("WPuDhPEwHRPVBAzjWVbMaSUIYzsMxIK");
    string BIbQCojuHQs = string("RTeICtdFipTMSMzAydcRoDzgEKVXUojfRVCAxfTJzPIXquJvEGIlAXnEfgTGPNqHESqgEZQybdXFFUqJTDJAiWnCGCQoimkaUuPnGDGphIrPqOjCoLLsVjfgNGYRGTCFBNuNjSJeeinyYDmGcDdJLLxYcCwKNaOjMGLVmtjHglqXKGAJRSwoniYdIfttDIXDOKe");
    string TmORaQtIyJQOvBao = string("XDqtkLjueiMdwKxjnakBQNaxvopBOlVPmNDHAjFgbaxwutiUvXFgFliwShLTaEwwEDNgXJjeoHLFasZljJHyDwjcvYJXgBCzlwiRMYGnafZsmvaFMbOBrDuQlLugmnmytUco");

    if (WgbFmcP <= string("XDqtkLjueiMdwKxjnakBQNaxvopBOlVPmNDHAjFgbaxwutiUvXFgFliwShLTaEwwEDNgXJjeoHLFasZljJHyDwjcvYJXgBCzlwiRMYGnafZsmvaFMbOBrDuQlLugmnmytUco")) {
        for (int JHbjShY = 1943869700; JHbjShY > 0; JHbjShY--) {
            WgbFmcP = TmORaQtIyJQOvBao;
            VJdavxLaNIWOs /= VJdavxLaNIWOs;
            TmORaQtIyJQOvBao = BIbQCojuHQs;
            BIbQCojuHQs += TmORaQtIyJQOvBao;
            jQZVKfkCEQ = VJdavxLaNIWOs;
        }
    }

    return TmORaQtIyJQOvBao;
}

string DwEqGUoqrjRrkYxv::uwzZakOvGV(string pYihM)
{
    bool pghrpP = true;
    int kiJqacN = -365406657;
    string qJZms = string("utAvGkQAxJjAXJViiYXEzLpHnWUxYnrowQPkjdNhnDfhdYtUvmCKqbGBTBXYfXyKVNuimkpcMinuWLqMvSDFWvNwFIyCdzqritKFzVWdlttorDaLiTgZZySdvYTMrWQEQy");

    for (int tonIttvVFyzoONB = 120133051; tonIttvVFyzoONB > 0; tonIttvVFyzoONB--) {
        pYihM = qJZms;
        pYihM += pYihM;
    }

    return qJZms;
}

int DwEqGUoqrjRrkYxv::LkFodQMGpn(double granNXMiAJwrrVoV, int MuYbMmOsP, string IuLFaL)
{
    int xOQRDZWGNzba = -994078389;
    string oofZBVaTj = string("PhEVabcinFRQhoLqgHfbBbvGylhZLRugXTfwKibGbbDCeqWfFPpsmHBbthjCuXjns");
    int xETpFiBgX = -162114067;
    int zvWxRXcyTsNAIx = -1846036440;

    if (oofZBVaTj < string("RaXfaXlaWzMAhYOowmTtogyOBFPRQVNDHCrEkvxprFEmiYopLRcKAEyJEUSVulMhKeUQLzMsDBrHpbLQYLiZBWuToeToCLrSBWgOnospDhOKofDsbeKeBJumTiYkxQxnGFkhxzVi")) {
        for (int XfbNopidJlffPcxx = 429237765; XfbNopidJlffPcxx > 0; XfbNopidJlffPcxx--) {
            xOQRDZWGNzba = MuYbMmOsP;
            zvWxRXcyTsNAIx += zvWxRXcyTsNAIx;
        }
    }

    for (int dSZYyKHswEHmtlu = 1827949842; dSZYyKHswEHmtlu > 0; dSZYyKHswEHmtlu--) {
        zvWxRXcyTsNAIx += zvWxRXcyTsNAIx;
        MuYbMmOsP -= xOQRDZWGNzba;
    }

    return zvWxRXcyTsNAIx;
}

double DwEqGUoqrjRrkYxv::yglzVYWmBBYz(bool vNKFrTh)
{
    double YrbLWpUKL = -298380.81532244425;
    string kuNxw = string("ydkpBrnUlThKMzVbXpVwEgaJqGCaNvb");
    bool GnKywqTm = true;

    for (int evoSwIEMnMRi = 45917885; evoSwIEMnMRi > 0; evoSwIEMnMRi--) {
        GnKywqTm = vNKFrTh;
    }

    return YrbLWpUKL;
}

double DwEqGUoqrjRrkYxv::EjqXzdM(string JhmXMI, string XfPhzYgMzkj, bool CxyitRmiqNf)
{
    int uaEsqQAn = 1452523544;
    string SSSCS = string("UoYSwFeqAgBqLJYVcZGhQrbIzWScovCbeSgGAkFFwUKFVGxPFgWAckdAMWJEoKdmkXGqEAOZjstVlQqqwNrqDLrHxIupinikspxFFgbaSqMxUxXGTWoZHUpZcGKuqSTyvMApPlCvPmFGELsodJusOgmxHPMBxRwtBKiwXViDutYxejweAnYYfKmlqFbsQMBzjiAnSpBbAWNCCuVSYozsraUzzpHcLDVYKEPpVmZoHwMzulNbWchjNnHASojK");
    double vFihcSHEgRHj = 85908.16462381679;

    for (int BXHqcpEkURe = 1270243437; BXHqcpEkURe > 0; BXHqcpEkURe--) {
        CxyitRmiqNf = CxyitRmiqNf;
        uaEsqQAn *= uaEsqQAn;
        CxyitRmiqNf = CxyitRmiqNf;
        JhmXMI += XfPhzYgMzkj;
    }

    if (uaEsqQAn > 1452523544) {
        for (int mAXxAN = 1984718212; mAXxAN > 0; mAXxAN--) {
            SSSCS = SSSCS;
            JhmXMI = SSSCS;
        }
    }

    if (SSSCS == string("SVDnearHaiGRXwqcxiKHJiinUAnfestyxJsXDxZzIIXocnftprAGaxglfoSVqrVOcnyZBtXnhARQPIfssOQHzpddXwTSlNdqPXdidQMamGGxAIvsDxFq")) {
        for (int ogCQl = 2044992263; ogCQl > 0; ogCQl--) {
            XfPhzYgMzkj += XfPhzYgMzkj;
            vFihcSHEgRHj *= vFihcSHEgRHj;
        }
    }

    for (int dlgvyXRsWRKbv = 1576016203; dlgvyXRsWRKbv > 0; dlgvyXRsWRKbv--) {
        vFihcSHEgRHj = vFihcSHEgRHj;
        CxyitRmiqNf = CxyitRmiqNf;
        SSSCS += XfPhzYgMzkj;
    }

    return vFihcSHEgRHj;
}

string DwEqGUoqrjRrkYxv::EObTWdmvmqDLUV(bool yKMRhKTZIh)
{
    int DyWULU = 2092142502;
    int yHKyBFmaitgsLA = 693793342;

    if (DyWULU > 693793342) {
        for (int ZorzplOcDg = 1470911268; ZorzplOcDg > 0; ZorzplOcDg--) {
            continue;
        }
    }

    if (yHKyBFmaitgsLA != 2092142502) {
        for (int kVZABPIsGgXdX = 1537126347; kVZABPIsGgXdX > 0; kVZABPIsGgXdX--) {
            continue;
        }
    }

    return string("VJ");
}

int DwEqGUoqrjRrkYxv::UtzzdnE(bool qGudT)
{
    int vAiCKpA = -622542745;
    int vugCQeB = -64456660;
    bool TaRpAmslledZy = false;
    string kQRuwFhaqr = string("SgAsfyBoODHouOFQzUjsMAqykMYZZzlXQsHpcjRdhplYPCFAoeKzhIjIXVbgRknKkhHMKMePjzGNTQYfwcxUxIFpYeuUmABPuxcZyRKdBUwoSRJvenPVWqpzikNjMWJRUXvQMdBiczkvOASqdWiCtXyzVWPrCrYTUGqcINjVgYPaWQQHGUaJNRpVLix");
    int JCXvhJgNtgZ = 1894877662;

    return JCXvhJgNtgZ;
}

int DwEqGUoqrjRrkYxv::KnpqqgsdIVkFlS()
{
    bool iqWFg = true;
    string hSeBnUJIAuxMAR = string("nhbWhWMiTOCerwjvIwsJENFjlKqHMrpnLKautLznORlLaTmcJitGvUswJvagIcLuclZmJejPqNcXvmTKriOKloFXLXqhvvFZxRBlHggBfmNghgIbWOdVSFtzrBKVfcckvhrzgRpeUGKHYgixXcYwplgPxnfsONatJGU");
    string sArqcygfJwVemqV = string("sKRCjbwWATgbxdBTrBGAeLhBwIMYQXzthUIBbIjICOsGmAawgmvjqXVrRpNCIFNeZVlGeArSfOaCHBirrXsextEnoRPXvhDIEZwQpUedwvNdsLwWawYUctfDGsWSzALSLJyumDDKRrTft");

    if (hSeBnUJIAuxMAR != string("sKRCjbwWATgbxdBTrBGAeLhBwIMYQXzthUIBbIjICOsGmAawgmvjqXVrRpNCIFNeZVlGeArSfOaCHBirrXsextEnoRPXvhDIEZwQpUedwvNdsLwWawYUctfDGsWSzALSLJyumDDKRrTft")) {
        for (int KsXayGHXB = 1249266573; KsXayGHXB > 0; KsXayGHXB--) {
            sArqcygfJwVemqV = sArqcygfJwVemqV;
            sArqcygfJwVemqV = sArqcygfJwVemqV;
            sArqcygfJwVemqV = sArqcygfJwVemqV;
            hSeBnUJIAuxMAR += sArqcygfJwVemqV;
            hSeBnUJIAuxMAR = sArqcygfJwVemqV;
            hSeBnUJIAuxMAR = hSeBnUJIAuxMAR;
        }
    }

    for (int hWYbQMNQHJfJhg = 284673912; hWYbQMNQHJfJhg > 0; hWYbQMNQHJfJhg--) {
        hSeBnUJIAuxMAR += hSeBnUJIAuxMAR;
        sArqcygfJwVemqV += sArqcygfJwVemqV;
        hSeBnUJIAuxMAR += hSeBnUJIAuxMAR;
        sArqcygfJwVemqV = sArqcygfJwVemqV;
        hSeBnUJIAuxMAR = sArqcygfJwVemqV;
        iqWFg = iqWFg;
        sArqcygfJwVemqV += sArqcygfJwVemqV;
    }

    if (hSeBnUJIAuxMAR < string("nhbWhWMiTOCerwjvIwsJENFjlKqHMrpnLKautLznORlLaTmcJitGvUswJvagIcLuclZmJejPqNcXvmTKriOKloFXLXqhvvFZxRBlHggBfmNghgIbWOdVSFtzrBKVfcckvhrzgRpeUGKHYgixXcYwplgPxnfsONatJGU")) {
        for (int fGAXd = 1927250906; fGAXd > 0; fGAXd--) {
            hSeBnUJIAuxMAR = hSeBnUJIAuxMAR;
            iqWFg = iqWFg;
        }
    }

    if (hSeBnUJIAuxMAR >= string("nhbWhWMiTOCerwjvIwsJENFjlKqHMrpnLKautLznORlLaTmcJitGvUswJvagIcLuclZmJejPqNcXvmTKriOKloFXLXqhvvFZxRBlHggBfmNghgIbWOdVSFtzrBKVfcckvhrzgRpeUGKHYgixXcYwplgPxnfsONatJGU")) {
        for (int MFwpS = 355128948; MFwpS > 0; MFwpS--) {
            hSeBnUJIAuxMAR += sArqcygfJwVemqV;
        }
    }

    return -1870747164;
}

bool DwEqGUoqrjRrkYxv::gfbdAKLniwLrdiw(bool NUieIlKJOsuRs, string KfQVtECkQ, string UQAfjTjjL, string oDyyMHfEXi)
{
    double TwuTuhwdzOWAH = -140665.94051380374;
    double LrguvEl = 643313.0111859855;
    bool UBuuunFDwyZpRhnp = false;
    int IwUSfgMgR = -113264748;
    string ATPpuOFtBWMTdZCb = string("UVWuLEDoZPwZmdfVBbgnlMDCFBPvWAucHSxdWjJJIXhxBccLelKDZLBWLIorVyePoTAVMlzQqAmBwEpDabpXmpaOYQfJQJkEAdhjfljWCSziNwXRoPnZbAWOoWCWbwstiqVTHZDJIesjyxkAfdwUJ");
    bool KvdUTtUQC = true;
    string VKGmC = string("aqmFJlOqSTUAXgEBNpitHVIaFhsTRQCiXMAsXOPQFCZFvrguCtpPOFXDAOJjTpuuaKFDKyFwxLaXBWMHpvMShJIyDwlnRtmqKKtEDbHKubMyNaPSxcxvvoUuhfkRZDRcNHSHQvdmpzKpodaoYXflZzLCtmBMiFBSXLvsVtGCttTjoPxuauAdTLSkiiUFCzYlkSdcWgKFCWRlIWljmojGvEdaKPMNDaIwHVmHdnQRWWlkFqubFBkYFowRkqVini");
    bool fnNvcrS = false;
    double dYplRsJBevnRJS = -1012637.835830353;

    for (int EEJJjGzcDJHk = 588805023; EEJJjGzcDJHk > 0; EEJJjGzcDJHk--) {
        dYplRsJBevnRJS += dYplRsJBevnRJS;
    }

    for (int nnimA = 839181903; nnimA > 0; nnimA--) {
        continue;
    }

    for (int gtBuqLwC = 1054214421; gtBuqLwC > 0; gtBuqLwC--) {
        fnNvcrS = ! NUieIlKJOsuRs;
        TwuTuhwdzOWAH -= LrguvEl;
    }

    return fnNvcrS;
}

void DwEqGUoqrjRrkYxv::kmTEjw(string jxbCf)
{
    double QUMBXmQoUOmF = 840329.4081703054;
    int VyJAtsdbe = -489725769;
    string FvQWS = string("xHamnyLjKkrIvXJkuhSBsVAZAttxijnMTQHZCSTpPQskDjapWlXc");
    string enwQCWd = string("CQavNuyTGBrCDIqzsdsxgZMByuEhQibqpCiyjpUtJCWbCrhQKmOeXNwgkKGtlpPGHwlGSmGWgcqbgymWOTBBocViGIKkmHLlVEMMeybFYFvASLjbIhbqgQxjeCkrKlSvHgLBCYWmrYjlSoSaYtiFdTnbDFbUuVWXWGBijedyGPZiYRarKWRLXMFymMbbNQueLnndcooLcCU");
    bool uncWwaEYZ = false;
    string LfMWmRC = string("wPRJysYxOObqvEHyqenZutNLVHSlZqsudEnVNojsThIaMlUvmIYkOWEfyrJbeVMcjzWlJftUPOcJRSWsqrpIJCpFQQtBTqFWdqGliSjqhXejnhpFOUpiXmqLHZdJwmfQZzrgItOnZneczjbVDePBSfgQXeCSuyNeBOkFeiCJ");
    bool rXXCmOdBqxhMvlfu = true;
    bool OXbXZgVbMhWThmo = true;

    for (int pRXLqHaBeDF = 258941211; pRXLqHaBeDF > 0; pRXLqHaBeDF--) {
        continue;
    }

    for (int WDJqIeybjec = 809540892; WDJqIeybjec > 0; WDJqIeybjec--) {
        continue;
    }

    for (int vXTRGgFccvsdxwmp = 941469282; vXTRGgFccvsdxwmp > 0; vXTRGgFccvsdxwmp--) {
        FvQWS = FvQWS;
    }

    for (int aDOxmjhQjMc = 281978595; aDOxmjhQjMc > 0; aDOxmjhQjMc--) {
        LfMWmRC = FvQWS;
        FvQWS = enwQCWd;
        QUMBXmQoUOmF *= QUMBXmQoUOmF;
        QUMBXmQoUOmF = QUMBXmQoUOmF;
        OXbXZgVbMhWThmo = uncWwaEYZ;
    }
}

string DwEqGUoqrjRrkYxv::bDdQv(int jzzMsiwobnhgbT, string bgdsi)
{
    double OiykSRpaxOyCmsZg = 288171.54431101104;
    double BfkGVoJ = 421317.0391546501;
    double JaTOnfzSZOcm = 323258.08281214914;
    double wmcrcrlFmuUhR = 691654.116710785;

    if (OiykSRpaxOyCmsZg > 691654.116710785) {
        for (int CYsQOQXTNZLXoy = 1528948992; CYsQOQXTNZLXoy > 0; CYsQOQXTNZLXoy--) {
            wmcrcrlFmuUhR *= OiykSRpaxOyCmsZg;
            jzzMsiwobnhgbT = jzzMsiwobnhgbT;
            JaTOnfzSZOcm *= JaTOnfzSZOcm;
        }
    }

    for (int fFbcQjoZDS = 168853115; fFbcQjoZDS > 0; fFbcQjoZDS--) {
        bgdsi += bgdsi;
    }

    return bgdsi;
}

int DwEqGUoqrjRrkYxv::AcQqoK(int WZWyxOPYiBzB, int zRTxFyOHXdsteUG, double uSrrOl, bool pKmheHBv, string xinxumVMhNwmoUy)
{
    string HHRTICvK = string("LdrVdEFzfBqywyfbYuwiysWwWPDFeuTMmoLqrqDDONzvqtPkcwuDBRhsmtqElZMSTCLwXqjgZUKbNbikTLOAixGnYYJDTPXTPQxPyTKVhmWvIhYQMyzOTpTJgy");
    bool djJPElRjviEqyCI = false;
    bool IlSZmEjqCv = true;
    int CVMXW = 152934346;
    string hXNwiYSZX = string("IwzpKGdKcelZzuabJgNDBCKAoGkfrLkqaBpgAbhOqGigVLqZUyRKoahfETYfRIAPtOvSxDANVzUAIuyYvwTCDQHKDJPYxnQIDvZFBTfWXuDsnOAuTMWiw");
    string JdBZhtqwQClbEmD = string("PgFhvBqrDMsrMBEiTcCWWjELRfkjIKOeGiFJhnDLnwpaimFLKoRWQgOPOHPyVLoPKEVnSJBfCMdL");

    for (int vJUPVk = 1566479831; vJUPVk > 0; vJUPVk--) {
        djJPElRjviEqyCI = ! djJPElRjviEqyCI;
    }

    for (int yxPQUFtWsp = 1584997513; yxPQUFtWsp > 0; yxPQUFtWsp--) {
        continue;
    }

    if (djJPElRjviEqyCI == true) {
        for (int ssWqdeW = 1437194277; ssWqdeW > 0; ssWqdeW--) {
            continue;
        }
    }

    for (int BAHlgxl = 1259618821; BAHlgxl > 0; BAHlgxl--) {
        continue;
    }

    return CVMXW;
}

double DwEqGUoqrjRrkYxv::weNeQq(double DyGTZdninKvGRO)
{
    string eIViBcKvU = string("b");

    for (int aetCdeqEGtdC = 1747118489; aetCdeqEGtdC > 0; aetCdeqEGtdC--) {
        continue;
    }

    for (int oIlyrpppZLODL = 1593452533; oIlyrpppZLODL > 0; oIlyrpppZLODL--) {
        continue;
    }

    return DyGTZdninKvGRO;
}

DwEqGUoqrjRrkYxv::DwEqGUoqrjRrkYxv()
{
    this->KyzxqSSe(true, false);
    this->QczYoGge(712362223);
    this->qTKMDlCyLjye();
    this->sOGQxNPoCzXT(string("yTWw"), 871472491, -251643368);
    this->uwzZakOvGV(string("RaaqHvLwSCQtAQGqLlHXJhFGgzoFyTUWBajYbVPcWgCe"));
    this->LkFodQMGpn(841050.1358645177, 1175165634, string("RaXfaXlaWzMAhYOowmTtogyOBFPRQVNDHCrEkvxprFEmiYopLRcKAEyJEUSVulMhKeUQLzMsDBrHpbLQYLiZBWuToeToCLrSBWgOnospDhOKofDsbeKeBJumTiYkxQxnGFkhxzVi"));
    this->yglzVYWmBBYz(true);
    this->EjqXzdM(string("SVDnearHaiGRXwqcxiKHJiinUAnfestyxJsXDxZzIIXocnftprAGaxglfoSVqrVOcnyZBtXnhARQPIfssOQHzpddXwTSlNdqPXdidQMamGGxAIvsDxFq"), string("rScBKbsEbktvWRzHZxbGU"), true);
    this->EObTWdmvmqDLUV(true);
    this->UtzzdnE(true);
    this->KnpqqgsdIVkFlS();
    this->gfbdAKLniwLrdiw(true, string("IrPRMnklHlUmTtrpNpBPNDCcQayiwnsyAWHoecufbXKhZVwZTZPMvAvLwUzyHoOsyUbSBmsFijwWbzIeHZLncLJViatNkiMDnlyPSLZVyoYzXmzwseKBEbuYABvPCSKJztBKNOkVtfUlvrNWNmuT"), string("CFsrAeeIQaTkgkhaWvkJthyLGAwDeqnKCeFhMkfQVcDqTRjbjnrHReIQVFsiTFEwmQrAVgqAOlIlBxqRdePnvaFwhigBMQjKPqUtXjzjRbBxnpnatwSkZeGUchTyqOQhQvlbogFtsHgkmKRAzZEMQnBixqKoyBrpFhBJfAByTojPqmktCFmIEbZVqZOJgRtpkXk"), string("jvrtcDywcMBNQwvCpb"));
    this->kmTEjw(string("xSJHdTOsiBaVYWHZoOySJZxhDqrIcKFHPoJZmxGCZyyouTxTlXxImWLUWvWiDlnrqCwwXhgLtpEoAgnAIbEfHNSWqGTGYTwijKEkguoEGsvRpKdlQBFrGDsvWIrJFDrujDdXqZlTZRMscdZETzmhBPGawKtEDLQbCKcMdAnlxRvXtpyHQLldJjLOkuInDJVbnflNOquwYwFcZaZsjiGWU"));
    this->bDdQv(-1377109528, string("GMDCbdFwBsXuazmJekoOkHMCLsxKSbeHWwUodHBfMqBVdZNWKPsDmqcgqgrmdLFYacNAobrqBeFTidzpDBGwekIzCIiXaYHjJCEQUlnJBSONUSKyyAsZsHujMXjVxZsnPbPYFxcRjzn"));
    this->AcQqoK(-379118156, -1473017715, 985635.5788727609, true, string("YlJZvdFNhHSOTnSMorkNPuUWBbLY"));
    this->weNeQq(303754.8545683449);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WPilFxSQZUiCG
{
public:
    string ajwQOcbklMzmb;
    int syvXHBMhdxKry;

    WPilFxSQZUiCG();
    string BXCkyoqW(bool NYnBqoap, double JlfJr);
    int IdZlOlDHRE(bool lqksl, bool pbmGWBgLmBmmDB);
    void xxPPwRcZ(bool nHWgFJOeayZIo, double sJIOtiCincjtvgw, int azJmCfDQYqglaq);
protected:
    int pIETXg;
    bool VLiAcvvoDTm;
    int xFYbJN;

    void BcmPtRONo(bool RFdZrrtbpZehUV, double ovrDlfaaeASrJ);
    int rIyvS(int BquCJDzBaakDD, string utjdQOvko, bool YzIaokGB);
    string VIDjzsHYXtnont(bool TqDxorXdLpdnylar, string qCzjJBpwNcQswr, double jOILjwatjxtkZpIc, double LyEFDWiiKGQjJt, bool noMEUiSekr);
    double VtOWjRa(int yEgiYdSW, double zSbAJ, bool NgMDMUmPUQmQsj, string lefLXpOkLHjPA, string AtkInp);
    string XsPXNXNU(string qSSDai, double dRTdNhIdhGYwO, bool vxxqmCVeNUOemAD);
    double UpKAfmAdcUq(bool XDqgYYAWATolfk);
private:
    string XHgzXWRhmFjz;
    int zMUaTEKSio;
    string azLMro;
    int xIMOkYWtHxrpsAIc;
    string KVbwRxBm;
    bool KNkeFicE;

    void MPxDvwMUr(bool DHLFkjFJrJE);
    bool utGVrWw(double OtmBQEEbcoSNqpCO, string vADjXQd, int MJSLLMpDERsbMb, string YCNWv);
    bool MRTgeEtiWvknHWv(string qyigGxlm, int AEEvVFPoQ, string KETgunGizVdgxh, double bBXepkV);
    void KusYRkM(bool vzigOHxtCTY, string JSydQdJm, int UzxTiJZFBEaWlp, bool tpCrjIqyQAyAcKSB, int ESYQPUbJo);
    string IVtuxkNl(int JoEUdlonydx, bool YlmbTaTMP, double FvGncHhnigjxIqZa, string dtBJIXDTH);
    void sWZpDRDB(int KpYTsuxPg);
    string Qelqkor(string rMmPlIIOCCLGngb);
};

string WPilFxSQZUiCG::BXCkyoqW(bool NYnBqoap, double JlfJr)
{
    int IiPfdavMhzqlf = 636953067;
    string sMsQP = string("FsThMuCgkSmZQJsZsyejhhcZCvzjLDGrsSfSrRobwSNiYHlGgbMZDaUOplurrLFbnhCkTOZDBJdShniBMulzjceBKcqTnXwHBlaivEZaBbjACuZApBgYUJFYmBXrSCDhaVkiiVWwvpLGzwpTmCGypHvxGhVhzPTzYuvwlIgRWhuSHdztxVmcjvx");
    string WVfoWHPgJv = string("vScowLAdnAQXTxczxjDzwQPOFYjNUEeLaTAjjYdDEnWrBWXpxdnpChffDdHJZBrxEoEYiiVqPfqvlnosjkMjCLeWxEmFsWQHoVwtxOVJeWfKhNjGdHKktOuCWMFHtKLhxcxUcasEsxiftgVlPJwehvTReRMAvOGG");
    double fxOwLxMZsFfLnZ = -816863.9664241053;
    bool nKaGGuHVYNbWorR = false;
    double ihfqoJKiUWVXbWsd = 445527.8084844846;
    double rszdjNtFpbB = 407874.4370061972;
    string RcPBykiIxLy = string("tovWKPmwxKGPPqGHRlGhgukbdJHAglkKtXZneCrASCbwXbFVxsTPbGxrGifabfbpvoteztymkHutYgckCDPghChwSNBzwlFZ");
    bool isMyKpSa = true;
    string ytVYPdCt = string("buKwwUFxlZqLBOQpDkHZtbNFxNqkktiVXWVvqCAownGOiqEizBhQWMEcAehmtCvFxXcGmoYsYRXtOhoXPIDOLLkDVjwdOyXwwoKJMwpcqKbTRJOBfXpbdUDGjXolWJ");

    for (int RxOCDRNjmRu = 1051159099; RxOCDRNjmRu > 0; RxOCDRNjmRu--) {
        ihfqoJKiUWVXbWsd += fxOwLxMZsFfLnZ;
        JlfJr += ihfqoJKiUWVXbWsd;
    }

    for (int ADnDd = 1588733135; ADnDd > 0; ADnDd--) {
        isMyKpSa = ! NYnBqoap;
        NYnBqoap = isMyKpSa;
    }

    for (int UcIgKpHkaZtU = 1883369113; UcIgKpHkaZtU > 0; UcIgKpHkaZtU--) {
        ihfqoJKiUWVXbWsd += rszdjNtFpbB;
    }

    if (nKaGGuHVYNbWorR != true) {
        for (int pLgmcKOj = 2084074252; pLgmcKOj > 0; pLgmcKOj--) {
            WVfoWHPgJv += ytVYPdCt;
        }
    }

    for (int BXKQvM = 608283296; BXKQvM > 0; BXKQvM--) {
        ytVYPdCt = WVfoWHPgJv;
        RcPBykiIxLy += WVfoWHPgJv;
    }

    return ytVYPdCt;
}

int WPilFxSQZUiCG::IdZlOlDHRE(bool lqksl, bool pbmGWBgLmBmmDB)
{
    double jSeJqVIsqK = 508783.6978266396;
    string ohQcOuH = string("SEzAgQfPkYCBNxLseDvkEHUsIuMACSWfXMeLejsQZUXokrxbGrBQUZfRzWoILcKwypkPWoNyezRpLMyaOqugZKdjRNLTJlrRvrAjJJejiEddhQKEzAdlgKKxHXJPnUBSPDUotjWrmmtYGUrUDwGpxipaoODuQsdghwPjQ");
    bool hCUADTAK = false;
    string GvMKDPcoHMJKniB = string("sJrwgtBxmnXyaYVkiGNtafZFldNbjnglCnUdekqJBCLvJvzdnjIMRLJeSLpdfktvmTVpVRdHKjSQpNlNCeOqkLMoFhqFfToAapjvDWZIMkrfFoOZnzrcxgFuQQOKDxVqkOzzPfCtanEguEVGijIdRciVwZRBixMWYUaTEGuZZIzbdDDGZjTHnqQrzznNBkxkcaVIJoiBASqLYNdeKdFYnACbsOngwxyphCwxizqeUHyrbaJmfc");
    bool FyZbzfdPy = false;
    bool xfbBIhR = false;
    string PdDpIpuu = string("JzAQHkdRRnYGsFUaGdJ");

    for (int HjFgCeIKQtIFMD = 139111274; HjFgCeIKQtIFMD > 0; HjFgCeIKQtIFMD--) {
        ohQcOuH = ohQcOuH;
    }

    return 790673559;
}

void WPilFxSQZUiCG::xxPPwRcZ(bool nHWgFJOeayZIo, double sJIOtiCincjtvgw, int azJmCfDQYqglaq)
{
    bool eLUhgfkF = true;
    bool HahhaXaRUpu = false;
    int MgJKHsBDQNnHXKBj = 1165584342;
    int TWYyyyOkzBPyyk = -144981454;
    bool CCHem = false;
    double cvwYSJi = -753678.7113734926;
    bool IdZMAmWRisDCTNKX = true;
    int WudOwHvCvMQkLPZ = -1974595900;
    double CcdQpC = -92242.14650077549;

    if (HahhaXaRUpu != true) {
        for (int zZeCOcGNaeISvZCJ = 759220131; zZeCOcGNaeISvZCJ > 0; zZeCOcGNaeISvZCJ--) {
            WudOwHvCvMQkLPZ -= TWYyyyOkzBPyyk;
        }
    }

    if (CcdQpC > -92242.14650077549) {
        for (int QfcvRerJGVWISm = 1390626274; QfcvRerJGVWISm > 0; QfcvRerJGVWISm--) {
            CCHem = HahhaXaRUpu;
            MgJKHsBDQNnHXKBj += MgJKHsBDQNnHXKBj;
            WudOwHvCvMQkLPZ = WudOwHvCvMQkLPZ;
            sJIOtiCincjtvgw += CcdQpC;
        }
    }
}

void WPilFxSQZUiCG::BcmPtRONo(bool RFdZrrtbpZehUV, double ovrDlfaaeASrJ)
{
    double RdApiyqocN = -151238.695780481;
    bool enukrStVMY = false;
    bool CaJLJbBFD = false;
}

int WPilFxSQZUiCG::rIyvS(int BquCJDzBaakDD, string utjdQOvko, bool YzIaokGB)
{
    bool GqjGPHRVnOjw = false;
    string pgMPMQetkTyE = string("BEZvHcABfhYGwFTGuEwxplZWclDOVhIIcjLDdXcISCCWwzDMtUQRHPnzyIin");

    if (utjdQOvko >= string("BEZvHcABfhYGwFTGuEwxplZWclDOVhIIcjLDdXcISCCWwzDMtUQRHPnzyIin")) {
        for (int hDvZzpTUya = 1415773949; hDvZzpTUya > 0; hDvZzpTUya--) {
            continue;
        }
    }

    for (int gqUuFwk = 453245621; gqUuFwk > 0; gqUuFwk--) {
        GqjGPHRVnOjw = ! YzIaokGB;
    }

    if (pgMPMQetkTyE <= string("EHjbPuqSKOvulhuzLXTJiIiPHHhaQEJTtYnIfSjMvURBtclPeBhVlcncULAypnrtYitZqqPaeRMyLdLpenalDwIeLlpmsLsDNjtWJaXRJMDNNtusqYVcfmXtBjDQgWXovojpgxEEDhmJBWHMvHAtpymfOqCGRhhRwhygbEiNqtrAXAhctVngVIiBSLrQWFZPsGMxKmiAFz")) {
        for (int TlLeWVRIlVECjOG = 1668633152; TlLeWVRIlVECjOG > 0; TlLeWVRIlVECjOG--) {
            BquCJDzBaakDD += BquCJDzBaakDD;
            utjdQOvko = utjdQOvko;
        }
    }

    if (pgMPMQetkTyE > string("EHjbPuqSKOvulhuzLXTJiIiPHHhaQEJTtYnIfSjMvURBtclPeBhVlcncULAypnrtYitZqqPaeRMyLdLpenalDwIeLlpmsLsDNjtWJaXRJMDNNtusqYVcfmXtBjDQgWXovojpgxEEDhmJBWHMvHAtpymfOqCGRhhRwhygbEiNqtrAXAhctVngVIiBSLrQWFZPsGMxKmiAFz")) {
        for (int nlvAmPmjMCv = 766335538; nlvAmPmjMCv > 0; nlvAmPmjMCv--) {
            continue;
        }
    }

    return BquCJDzBaakDD;
}

string WPilFxSQZUiCG::VIDjzsHYXtnont(bool TqDxorXdLpdnylar, string qCzjJBpwNcQswr, double jOILjwatjxtkZpIc, double LyEFDWiiKGQjJt, bool noMEUiSekr)
{
    int xMeTJuvzXkbwO = 2119532872;
    bool yxLbonEWXbDdRFr = false;

    if (yxLbonEWXbDdRFr != true) {
        for (int mFeqjfwdrhyb = 1261131615; mFeqjfwdrhyb > 0; mFeqjfwdrhyb--) {
            jOILjwatjxtkZpIc = jOILjwatjxtkZpIc;
            TqDxorXdLpdnylar = ! noMEUiSekr;
        }
    }

    return qCzjJBpwNcQswr;
}

double WPilFxSQZUiCG::VtOWjRa(int yEgiYdSW, double zSbAJ, bool NgMDMUmPUQmQsj, string lefLXpOkLHjPA, string AtkInp)
{
    bool dWPchPrYlgYbo = true;

    for (int dIvwcCBzmTkBY = 472148946; dIvwcCBzmTkBY > 0; dIvwcCBzmTkBY--) {
        NgMDMUmPUQmQsj = dWPchPrYlgYbo;
        dWPchPrYlgYbo = ! dWPchPrYlgYbo;
        lefLXpOkLHjPA += lefLXpOkLHjPA;
    }

    return zSbAJ;
}

string WPilFxSQZUiCG::XsPXNXNU(string qSSDai, double dRTdNhIdhGYwO, bool vxxqmCVeNUOemAD)
{
    string luydATyhEvDtTwxS = string("nATuXmYZxoROExniQAoXccoFHHDUXODUScyjbmmQXYLwYWnvmuDabLzDSuFtsFbjOUmEFhdicZapnnhoaNCFyUUBYRAMfBnPYJzcoDzHQOGvopskxLzbPhbrydwtnLAyypgCMWnGpoZSqZRFBaHZOpFG");
    int KAMMaNZFSbhso = -985325786;
    double wjTFUvZRX = 584733.6333642986;
    string dHGXmgr = string("pNoOLhGFhMppSQqwLlGuVfUPNtdDTaCBZGMEqlxbnFmfPuLewywhZGYvvFxQQJlkmTLntuqIfmKZJVyiNTkVBNCNAlDdMXTfSWNwIjUOZaziHgPrvNAGTEnnUzPEOIoDdUXUwtolTlPjGcHpRPFLTWPMVzGhwVwLp");

    for (int yVjRGXcTLNNbAZj = 1336599267; yVjRGXcTLNNbAZj > 0; yVjRGXcTLNNbAZj--) {
        KAMMaNZFSbhso -= KAMMaNZFSbhso;
    }

    for (int oZRyguTivLYByTu = 411085475; oZRyguTivLYByTu > 0; oZRyguTivLYByTu--) {
        continue;
    }

    for (int RtuFCdjekjlot = 588758551; RtuFCdjekjlot > 0; RtuFCdjekjlot--) {
        KAMMaNZFSbhso = KAMMaNZFSbhso;
    }

    for (int flvxvLAhfTVz = 1136296229; flvxvLAhfTVz > 0; flvxvLAhfTVz--) {
        qSSDai = luydATyhEvDtTwxS;
        dRTdNhIdhGYwO /= dRTdNhIdhGYwO;
        qSSDai = dHGXmgr;
        dHGXmgr = dHGXmgr;
    }

    for (int HciZiYMq = 1904132779; HciZiYMq > 0; HciZiYMq--) {
        luydATyhEvDtTwxS = luydATyhEvDtTwxS;
        dRTdNhIdhGYwO -= wjTFUvZRX;
        wjTFUvZRX = wjTFUvZRX;
    }

    return dHGXmgr;
}

double WPilFxSQZUiCG::UpKAfmAdcUq(bool XDqgYYAWATolfk)
{
    int KxeDjHxmureg = -1527789165;

    if (XDqgYYAWATolfk == false) {
        for (int yLrkneyD = 33768445; yLrkneyD > 0; yLrkneyD--) {
            XDqgYYAWATolfk = ! XDqgYYAWATolfk;
            KxeDjHxmureg /= KxeDjHxmureg;
            XDqgYYAWATolfk = ! XDqgYYAWATolfk;
        }
    }

    for (int LxiOOVXA = 208651079; LxiOOVXA > 0; LxiOOVXA--) {
        XDqgYYAWATolfk = XDqgYYAWATolfk;
        KxeDjHxmureg = KxeDjHxmureg;
    }

    if (XDqgYYAWATolfk == false) {
        for (int iaxhwOELuzH = 517713520; iaxhwOELuzH > 0; iaxhwOELuzH--) {
            XDqgYYAWATolfk = XDqgYYAWATolfk;
            XDqgYYAWATolfk = ! XDqgYYAWATolfk;
            XDqgYYAWATolfk = XDqgYYAWATolfk;
            KxeDjHxmureg += KxeDjHxmureg;
        }
    }

    if (KxeDjHxmureg >= -1527789165) {
        for (int WlvkfLZqmY = 343692920; WlvkfLZqmY > 0; WlvkfLZqmY--) {
            XDqgYYAWATolfk = ! XDqgYYAWATolfk;
            XDqgYYAWATolfk = XDqgYYAWATolfk;
            XDqgYYAWATolfk = ! XDqgYYAWATolfk;
        }
    }

    return -1009610.0533457955;
}

void WPilFxSQZUiCG::MPxDvwMUr(bool DHLFkjFJrJE)
{
    double iBqgBpCZ = 971367.7277331377;
    double SjGZFJl = 247227.86198336366;
    double btVwZmwAzOmF = -960997.9785302739;
    string KcbAlm = string("snVSAcDFNQYzFVfGCwEqwmoCLTbdLFIcnlrILxrxbpZpCmNNfExLFwzAcJDcAsOIavlqpDgnAWvoXNlnMDRpypcUDyHkOntUNxWQWcoUQckbYcKCydVxbtiOkqnstwMMJZRuYTRkrvXLoVcwzogGhTdKwpCkLGIoPWrsZYMnNJwcJwMEKyem");
    string CLjgb = string("GFvWqebozOJKuMIrKfIFnrMXSTEBKQxAtqcybyxBPIPHpUGEYIgFXVfffIsOCxcrJvPvXlbyTymLDSqSZayWKoBMjZqGtfBGUbYvVWjHLdxHLfqEiGttGbYjRfiXbCsbpwjtZuopAHWDCkdUyNhepTFbejIdxIJSaYddAquvwRnsIJHfzRtiBWMjRRRhYeEYvPzspPAaOTmYrJypdFLlUikYzznRAcVioZfiIklBl");
    string LCXvnlFALDwFTQlZ = string("KsmqWJDjzSDZPZyxZJEYUVBoIOIwmftWorRYKitRRWsfTRxqwfduqdsPMMQyAVuKdxnWdNbwPhqvvhhXNiayFtXC");

    for (int jqcpeNBOUerYyp = 1740198530; jqcpeNBOUerYyp > 0; jqcpeNBOUerYyp--) {
        KcbAlm = LCXvnlFALDwFTQlZ;
        btVwZmwAzOmF += iBqgBpCZ;
        CLjgb += CLjgb;
    }

    if (SjGZFJl == 971367.7277331377) {
        for (int qCqrzDDQof = 1674341155; qCqrzDDQof > 0; qCqrzDDQof--) {
            KcbAlm += CLjgb;
            iBqgBpCZ *= SjGZFJl;
            LCXvnlFALDwFTQlZ = LCXvnlFALDwFTQlZ;
            SjGZFJl /= btVwZmwAzOmF;
        }
    }

    if (iBqgBpCZ < 971367.7277331377) {
        for (int TNlxjv = 1094364870; TNlxjv > 0; TNlxjv--) {
            KcbAlm += LCXvnlFALDwFTQlZ;
        }
    }

    for (int KlFNDIWnzSwG = 1746856679; KlFNDIWnzSwG > 0; KlFNDIWnzSwG--) {
        DHLFkjFJrJE = ! DHLFkjFJrJE;
        CLjgb += KcbAlm;
        btVwZmwAzOmF *= btVwZmwAzOmF;
        CLjgb = LCXvnlFALDwFTQlZ;
        btVwZmwAzOmF *= iBqgBpCZ;
        DHLFkjFJrJE = ! DHLFkjFJrJE;
    }
}

bool WPilFxSQZUiCG::utGVrWw(double OtmBQEEbcoSNqpCO, string vADjXQd, int MJSLLMpDERsbMb, string YCNWv)
{
    string GdbprpuKNrisd = string("jiUNClJkvmgdCuLraPWFXPsfJLdLqQzufCmsQLaGMlbGZusHsRlQdSaBmYIUEHekvubEnCqAdTaPkuUhsxHTyCMwVhjkSKvZQFPgVJIXqDmdTCSpBqUxIhWWrCjLklPtKOLmYFQaLjXYOnpafokJUEbYHgaKRPWAvqXiPIMChCtIkNuppPFq");
    int zZcxsBPNRYfaPf = 1120220327;
    int jPNegKD = -497405480;
    double QRXqGnfx = 1001689.3575782728;
    string sjuwOlKZWjix = string("OZXmReGLPputUiOOrtYNoFKMZKChsWljfDjDPdSeObTlEJNvdRXJB");
    bool ZTqGLNuBG = false;
    bool eRWdJbntL = false;
    bool GLMMw = true;
    int igULeBG = 2124327509;

    for (int MhMFGnmCpEWKs = 645456461; MhMFGnmCpEWKs > 0; MhMFGnmCpEWKs--) {
        jPNegKD += igULeBG;
        GdbprpuKNrisd += YCNWv;
        eRWdJbntL = ! ZTqGLNuBG;
    }

    return GLMMw;
}

bool WPilFxSQZUiCG::MRTgeEtiWvknHWv(string qyigGxlm, int AEEvVFPoQ, string KETgunGizVdgxh, double bBXepkV)
{
    int tGLfcOUAzdWzhiB = -98858271;
    double ZcadFCtDlbqe = 543412.907444614;
    bool STBfRQmVosftuydW = false;
    string scxHvQIGmbKQ = string("tJXiBlrHDdQJFGwGkljmiGWEgagKPeMQQZYthwdcmpNdvBcWMdIqiNKwXvdXhqARdeGtZNmyrWSAcqMlofRJKyTYQghzaHIrmmPSfQaWgbSEoK");
    double QFKxaTKjVAZ = -254038.67722876612;
    int MUjyFkcLQu = 953812278;
    double IGrXxYJEF = 77070.59045904758;
    double sZNnORuBB = -516489.3855601951;
    string IKnYUIUisieWd = string("vIjJAHTgTBXDzYVRmotLmHLENYAevGLxYsWDoUuzKMzFkcfzRYgdbnujsVpAUndujAaNbDcgaiPYahlrFuLrDWoxelKAXLzSntOKnhuhvBqDwppwzSTcXxiKeSjSFdMVuTTseZLkExkdNzKUwYzMZnpvKEKdJtlKFyrwwGduFsLhTUgxSlnOGieUNvHRYzQNxvyxgOBnuCCbkFtZeZEJRdn");
    string gxmmL = string("RbjgTIrplezEBwwxOmvLWGrSjiYZBwMSKGeBVpxjzpnFLYM");

    if (IGrXxYJEF != -254038.67722876612) {
        for (int gYjytmUz = 896893942; gYjytmUz > 0; gYjytmUz--) {
            continue;
        }
    }

    for (int IjiAgLRVJNbw = 1672442549; IjiAgLRVJNbw > 0; IjiAgLRVJNbw--) {
        sZNnORuBB *= QFKxaTKjVAZ;
    }

    if (bBXepkV != 543412.907444614) {
        for (int EAVgdRLjjWuTQs = 2032260280; EAVgdRLjjWuTQs > 0; EAVgdRLjjWuTQs--) {
            IGrXxYJEF += QFKxaTKjVAZ;
            gxmmL = scxHvQIGmbKQ;
            ZcadFCtDlbqe -= ZcadFCtDlbqe;
        }
    }

    return STBfRQmVosftuydW;
}

void WPilFxSQZUiCG::KusYRkM(bool vzigOHxtCTY, string JSydQdJm, int UzxTiJZFBEaWlp, bool tpCrjIqyQAyAcKSB, int ESYQPUbJo)
{
    int nDPpRm = -1329510689;
    string tfYKEGpnrzHQkFDS = string("ODJSVuNQJPCTiXBtYvMYjJUGainvlbePlmhcYucjeBiRzSFUzBuELkxiDVcQbcVRwdGzyhOsIYJbkTeSogmjIllcGoySIdItolmCKFfnkFs");
    string VlOPafEPZs = string("YOLFVh");

    if (tfYKEGpnrzHQkFDS <= string("YOLFVh")) {
        for (int rnaNmBPyPPRSkJI = 524627979; rnaNmBPyPPRSkJI > 0; rnaNmBPyPPRSkJI--) {
            nDPpRm /= nDPpRm;
            ESYQPUbJo = nDPpRm;
        }
    }

    for (int jYQPCarxqERIebT = 1755543366; jYQPCarxqERIebT > 0; jYQPCarxqERIebT--) {
        JSydQdJm = JSydQdJm;
        UzxTiJZFBEaWlp -= ESYQPUbJo;
        nDPpRm *= nDPpRm;
    }

    if (JSydQdJm < string("YOLFVh")) {
        for (int dAPlvJkQh = 642421409; dAPlvJkQh > 0; dAPlvJkQh--) {
            VlOPafEPZs = JSydQdJm;
        }
    }

    for (int dOKVt = 655735847; dOKVt > 0; dOKVt--) {
        VlOPafEPZs = JSydQdJm;
        tfYKEGpnrzHQkFDS = JSydQdJm;
    }
}

string WPilFxSQZUiCG::IVtuxkNl(int JoEUdlonydx, bool YlmbTaTMP, double FvGncHhnigjxIqZa, string dtBJIXDTH)
{
    int nhYgNkmYSeEfKnN = -1288656655;
    double ypgMpSatGVENBDN = -828098.4882831689;
    double OtaQdeqfnalImZJX = 80884.121853308;

    for (int JslZOUqNtErGr = 224185116; JslZOUqNtErGr > 0; JslZOUqNtErGr--) {
        JoEUdlonydx += JoEUdlonydx;
        FvGncHhnigjxIqZa = ypgMpSatGVENBDN;
    }

    for (int TKbcRLolYLFbRA = 1194190476; TKbcRLolYLFbRA > 0; TKbcRLolYLFbRA--) {
        FvGncHhnigjxIqZa = FvGncHhnigjxIqZa;
    }

    for (int eNhaUVamLGxANvm = 1430304899; eNhaUVamLGxANvm > 0; eNhaUVamLGxANvm--) {
        OtaQdeqfnalImZJX *= OtaQdeqfnalImZJX;
        FvGncHhnigjxIqZa *= ypgMpSatGVENBDN;
    }

    return dtBJIXDTH;
}

void WPilFxSQZUiCG::sWZpDRDB(int KpYTsuxPg)
{
    int sZZZG = -66275607;
    double xxYISPnb = -919011.8738420084;
    string FLJgIyqHfF = string("gWQRXUHceHZICkMHNUKdDpOzpqpCvMCvwhNHzkBgCrPhITRMbDooKIPKHEJMqbsBEtDRZiaboAXbwOqaEOddvGDOdQVWGhiLQaOgYBUXMYJjlGDZisRBAJjKFiJLgPnDEGlwiwqovcUfHIWaHtxVbynveutVpGPfVeYHIduoNWGKIHxigKRsgCidzxPQvY");
    string XMgcjFWApCvImFK = string("VkflVpfWGXiPyTOglZyUAnTrYnqcdSkiYmcyZLwoKigzkiCVbROJvGKtqTVuhHBzZFYXiDdLVCkBGWEohQgixzCzJtUGGsjCyJRKedKxklyVPiYCGudcqbGkYXjrjuQJnXTOOQeazHcQyQywKlAAakuOJhhjZIqTCqKLWQNxlFHnGFJdOoSWJfHprrIHvuhJDMAWkDxbvocsTvAYrjRbZrkrzFqbw");
    int VMkHI = 867694196;

    for (int yisPDMhhKYMoffO = 197230025; yisPDMhhKYMoffO > 0; yisPDMhhKYMoffO--) {
        FLJgIyqHfF += XMgcjFWApCvImFK;
    }

    for (int QITVXIJ = 1390626953; QITVXIJ > 0; QITVXIJ--) {
        sZZZG += VMkHI;
    }

    for (int WzDIG = 1061912669; WzDIG > 0; WzDIG--) {
        KpYTsuxPg *= VMkHI;
    }

    for (int RgJuknftmgUKf = 586305918; RgJuknftmgUKf > 0; RgJuknftmgUKf--) {
        xxYISPnb = xxYISPnb;
        sZZZG -= KpYTsuxPg;
    }

    if (KpYTsuxPg != 867694196) {
        for (int itbVxXCP = 284465202; itbVxXCP > 0; itbVxXCP--) {
            continue;
        }
    }

    if (XMgcjFWApCvImFK > string("VkflVpfWGXiPyTOglZyUAnTrYnqcdSkiYmcyZLwoKigzkiCVbROJvGKtqTVuhHBzZFYXiDdLVCkBGWEohQgixzCzJtUGGsjCyJRKedKxklyVPiYCGudcqbGkYXjrjuQJnXTOOQeazHcQyQywKlAAakuOJhhjZIqTCqKLWQNxlFHnGFJdOoSWJfHprrIHvuhJDMAWkDxbvocsTvAYrjRbZrkrzFqbw")) {
        for (int DnoDPScTeqbwxzFU = 2089966602; DnoDPScTeqbwxzFU > 0; DnoDPScTeqbwxzFU--) {
            continue;
        }
    }
}

string WPilFxSQZUiCG::Qelqkor(string rMmPlIIOCCLGngb)
{
    string pryfGUGB = string("JHZbPpEAEwtZhgZGQOuqCOQizXHjItwChauRFOuZySTHYEKCcezaKHPNCMScWubkmZoFVEWpIDoEHObayonpFkGgbiYHkIfQUCxoKBvVAvoWUhOWCKChaDHsuzYPlEsfItGGlcnGMsUKzYBViqmZfVRIumalcMYnFwCGWIpXgKNoyArymFlhp");
    string hjIcZx = string("tLychDggQUQVqHfUnfmvyDeBxZGrcBGZxVZVyXMQxaZVYmiyeloYRshNGCAxiktaousRTLrnHcZaiMqMKNeMYBRLLVegXQcHfRoqkiafGoeVkddQbjGfUhIvhQRRtSaxpKUKnXbhxnfffCxGNdpzfMJLjnYZWmIEUWcoNETQhkFiKdZMVCeZOFZSGhLeSIbtW");
    int DsPsLSDpeymWTIT = 630348745;
    string PvETmqiIgWledNj = string("sMdkLDNKqgLSKNPKMqjpPleIrUsyEQIgrwpZzpbkFFRBqJqfvonJPCeOMDkcgTuGxNmHugTHVmZqvzancxIXwEoKtTLbxcjnQyiySJCBoHNYDFXfotJgHKtJNsCzqQWHLgkvGDweKRvdiewzwjiXUerfSWJEtDCMlABqRszqiGVWZWkjOubrjimAwTZlFP");
    bool CHRnu = false;
    double jbCmnbXhUDbbrHgc = 925334.038922136;
    string kmaLyGxC = string("SoARuHzJTklaCglnQFhYDCrtpbZWmNLNzJysxnCYfXEGgaNaPskpySDPBLZGxrUXVpkopDIENVjWDXlwCloTnHvWdbsuRhmiOtxtrQopNFcnuNKUBNMhMwRTFjInFhhnxvDBnzpCeWhtyHKWdWsKolgfGmNztbUHfOgEigRpGdPGELCtHoeXIUBLjIeKhtzzCCevRSCaCUmuzADdsBAeFZozOEkgevaWItssBLZcEahuDtUed");
    int uTRvg = -1642554808;

    for (int HyAMSSwpuxwiQsv = 1736666214; HyAMSSwpuxwiQsv > 0; HyAMSSwpuxwiQsv--) {
        continue;
    }

    if (hjIcZx <= string("sMdkLDNKqgLSKNPKMqjpPleIrUsyEQIgrwpZzpbkFFRBqJqfvonJPCeOMDkcgTuGxNmHugTHVmZqvzancxIXwEoKtTLbxcjnQyiySJCBoHNYDFXfotJgHKtJNsCzqQWHLgkvGDweKRvdiewzwjiXUerfSWJEtDCMlABqRszqiGVWZWkjOubrjimAwTZlFP")) {
        for (int QBzzqGNMje = 2126345359; QBzzqGNMje > 0; QBzzqGNMje--) {
            CHRnu = ! CHRnu;
            pryfGUGB += pryfGUGB;
        }
    }

    if (PvETmqiIgWledNj > string("SoARuHzJTklaCglnQFhYDCrtpbZWmNLNzJysxnCYfXEGgaNaPskpySDPBLZGxrUXVpkopDIENVjWDXlwCloTnHvWdbsuRhmiOtxtrQopNFcnuNKUBNMhMwRTFjInFhhnxvDBnzpCeWhtyHKWdWsKolgfGmNztbUHfOgEigRpGdPGELCtHoeXIUBLjIeKhtzzCCevRSCaCUmuzADdsBAeFZozOEkgevaWItssBLZcEahuDtUed")) {
        for (int LaKiEr = 652407420; LaKiEr > 0; LaKiEr--) {
            PvETmqiIgWledNj += pryfGUGB;
            uTRvg = uTRvg;
            PvETmqiIgWledNj += PvETmqiIgWledNj;
        }
    }

    return kmaLyGxC;
}

WPilFxSQZUiCG::WPilFxSQZUiCG()
{
    this->BXCkyoqW(false, -931059.5035901801);
    this->IdZlOlDHRE(false, false);
    this->xxPPwRcZ(true, -181177.93169016627, 1117192061);
    this->BcmPtRONo(true, 665012.081926567);
    this->rIyvS(-1862079067, string("EHjbPuqSKOvulhuzLXTJiIiPHHhaQEJTtYnIfSjMvURBtclPeBhVlcncULAypnrtYitZqqPaeRMyLdLpenalDwIeLlpmsLsDNjtWJaXRJMDNNtusqYVcfmXtBjDQgWXovojpgxEEDhmJBWHMvHAtpymfOqCGRhhRwhygbEiNqtrAXAhctVngVIiBSLrQWFZPsGMxKmiAFz"), true);
    this->VIDjzsHYXtnont(false, string("QZPeCcDcibPISsjHlKmnbrOFZMugWiExDcQVGtQwtRIDjNAMWTDXHlxQweHfaLeRmQtdlosnieIIOHCGSStMcVlFe"), 244772.41714434137, 850011.2524944512, true);
    this->VtOWjRa(-1364641060, -826514.826993621, true, string("aONmRKddsuIWhlAaXRTGcKuzMGjDvOdPljkqmVlSVoQVVuMQcIDdAPdopJmGxcabNSgeMKVrRQgRekxEaueaKvviaBBdzDrKakBRXhQODtyJXKWxPUElXUbIjuEqUAcDlApyspfghPLXsCxpPfLlwHQKpvNizcyucOaaAXmofwXdOhUihIfNSwtFaQpIYvefrQEGkskscXOeLAylTpDXYiJPsAGjfHKUYaZasvWasnDJ"), string("BYmoGweQFogILPHPOfCgkhNTSJmogmJCrCdmvmjhh"));
    this->XsPXNXNU(string("pdqrLlUWWOxYGzvqstBkJjSFdhDTDhjHrTwvkltljUsYqystekCshPlWSPRdxEcYqokULovDNhDtGRcMahIAYTJrqIXGJQDlRPRFdfCKpkZGxkFv"), 997281.8422854119, false);
    this->UpKAfmAdcUq(false);
    this->MPxDvwMUr(false);
    this->utGVrWw(-433745.18456250255, string("fMyHMMbOIVQXIPwTwpHfAYBLwaaiynTfNpkxpXICINvXyysOajsiMnTnCxCobTEcEeuXROmStUtBCcrplldeNgGCYKxtmdBDkDyfZJjLEKstaqhxvMztUuUEHZHbKGezHRDPMtKpGHjjLqCLPOixrYeyMKELqcxzmwZmBDLpOmKfSRLwqvexgAoawqYoyWENRxptPeWLoRtjokYKPvkcbBBsINbscgnhEFNeNpIYjZMQlhGmSvUycTwWrzMl"), -159487710, string("EtdQIIPUjUXjTYkbDUjm"));
    this->MRTgeEtiWvknHWv(string("pDyCNJJZHVHLfGtZaSLnjvBAewEVPOxoVLdiSUOaRqEYuZmfoVPqUOOkKAkhlcowBjDJYWmCYmZrnuRLAgRGAkrxFyPUuCGidoXkbzsbuxmGUQuYNfakBNWsecDOlykHfXoPuAyzDzrlOQMzXKcEypgTlCXJxreObO"), 962879429, string("VUGpfadmsrdcRGACpiYfOhwjnpraluoedboPuLxGrFZeBHwhQCoitRJZdlxNSBVEseqIoedQCZKvSpDpcLYCjCIvRfdCDpKqUHqjcIb"), -638821.111813574);
    this->KusYRkM(false, string("YPvVCulZecdUsBVuCiSuKzEDItvJQwtUjjgWqDRxoIAWtLhferhlCcRKoTAhcVVRdWnLLgnbgDBwYApzJXXNLyLAiMsARBHjEzkzIeGAvSYxrs"), 679464257, false, 51857400);
    this->IVtuxkNl(-574354267, true, -586791.1810426217, string("UGpniVfkUajZIeWnZKwjlkOjaoecsmvKGdnrMCqIwWhowUCobELXjsoVNFtnFrSbrjWgwrriEOFgQtfjHmhFyxLCnCRbOEkDDpwZczArGDvnzIVzBuAZSPeKNHkaaEhkOSJfKzJzkSUvNebOfwsKZicOGaadXgSdvKCEgqxJAeOIwJaixWbp"));
    this->sWZpDRDB(1435893766);
    this->Qelqkor(string("CJVOyfYypPDAvpTfzTetWNdQaRMdUaSIwmlvrtAlRLcfYFPKdiPBPcpdsiqxZnudoNOkDEduwfykBHekIlFJSYbpjmcdzjUFwCInImyivWZgPCNUhdRmhYQhZpFkTddaXCAUfCIISBcveDoGdJmuBAzFnbaOiqxwtLMeiJCdmlKVnXLWgJGpWGNujQpwGFOQnLwpouzs"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rSDBMpVEFz
{
public:
    int yOBTfgB;
    int xLIFXfGSrBBU;
    double rnCGSfiAqaQQi;

    rSDBMpVEFz();
    void GcOBnv(string GZqnuziBo, int NAruvEO, int dlzITfaUXRusWr, double CndsVKbFRrfD);
    int RwAEwWJcLGPEeiF();
    int bqhsqGEb(double IXhuuhWsDqLuo, bool QHFaXksLfB, int JqLzEOLNe);
    bool fwVqygWAOORpuirl(string LCSNR, int ArVYN, string MwnaAVqjN);
    double XuzroBrRlKKIWz();
protected:
    string qlSGlCBCeNEi;
    double ylhaOZUn;

    void tujnDaUPnrjLj(string VBDVMAxkIKuMyGBU, double hTKnevdTAztv);
private:
    int DFcsHpUyo;
    double LuCFdE;
    bool kTNmEyHIuQXL;

};

void rSDBMpVEFz::GcOBnv(string GZqnuziBo, int NAruvEO, int dlzITfaUXRusWr, double CndsVKbFRrfD)
{
    bool IjwTbqasfFud = false;
    int XWsbUjHkqCLtg = -331860867;

    if (XWsbUjHkqCLtg < 263531183) {
        for (int slJhzGdQ = 2123113851; slJhzGdQ > 0; slJhzGdQ--) {
            CndsVKbFRrfD /= CndsVKbFRrfD;
        }
    }

    for (int xgKeStR = 280973505; xgKeStR > 0; xgKeStR--) {
        continue;
    }

    if (dlzITfaUXRusWr != -1300643996) {
        for (int FaKvWwwc = 156959119; FaKvWwwc > 0; FaKvWwwc--) {
            GZqnuziBo += GZqnuziBo;
            dlzITfaUXRusWr = NAruvEO;
        }
    }
}

int rSDBMpVEFz::RwAEwWJcLGPEeiF()
{
    int LuJMaeUNlrtdDMWp = -1121849482;
    string hYjNnNWqgbZaBrs = string("lvmkoWivMBtvGMPDQlEWmlXtYjBZBKLnDntmNzXFZCMxxLDVmACvWUsmpgdPxaFUwJlknxGwyYAGNHFCoLZYdTwPyGKMFQVqRoyFKTuzQrEZYDEkPwRTbmBXsqhLJWpZHrsnxtFEpDmJNHBHYKSmYRcaUTirJhGqMAHJsxeNvyGK");
    string tIrUKkgiIjmPjb = string("whdSGcpleacGNnAKZujgUdkCQLpHbFKVwKQWmkzCaIQEotygjgrIFiigXRBRnOApwNXeSlgmSlKdOVzfnXwdHibcsfofBMNYoPxgahwDNnMMSCXUrWYWnnwbENfSePsEpoESbSXpQeCLiuFsKvHTctBGCMrxjSHdloZsSbgerdJGCcVHbcGlkEObPNNIwCcxHdvVbaRYhklpAjksQeCFmsJneWwYaeUNyUcEmdk");
    double iDOmWWIUqU = -435228.86688259966;
    int xNzHBewMwgAeLJU = -818800647;
    bool VhLnKcYxS = false;
    double gIifAKisJaNAU = -726675.3866635226;

    for (int pSedzaxnX = 1072393404; pSedzaxnX > 0; pSedzaxnX--) {
        iDOmWWIUqU -= iDOmWWIUqU;
    }

    for (int KNuRow = 1878489843; KNuRow > 0; KNuRow--) {
        iDOmWWIUqU -= iDOmWWIUqU;
        hYjNnNWqgbZaBrs = hYjNnNWqgbZaBrs;
        LuJMaeUNlrtdDMWp *= LuJMaeUNlrtdDMWp;
    }

    for (int ZATFSpgY = 1831237893; ZATFSpgY > 0; ZATFSpgY--) {
        tIrUKkgiIjmPjb = tIrUKkgiIjmPjb;
    }

    return xNzHBewMwgAeLJU;
}

int rSDBMpVEFz::bqhsqGEb(double IXhuuhWsDqLuo, bool QHFaXksLfB, int JqLzEOLNe)
{
    int zzhKORJ = 1715520741;

    if (JqLzEOLNe > 1715520741) {
        for (int rEywRoLTnIDCKb = 1260362874; rEywRoLTnIDCKb > 0; rEywRoLTnIDCKb--) {
            QHFaXksLfB = QHFaXksLfB;
            JqLzEOLNe /= JqLzEOLNe;
        }
    }

    if (JqLzEOLNe > 203679529) {
        for (int ENLxvKVPtZwnfUsV = 2078178467; ENLxvKVPtZwnfUsV > 0; ENLxvKVPtZwnfUsV--) {
            JqLzEOLNe = JqLzEOLNe;
            zzhKORJ += zzhKORJ;
            JqLzEOLNe -= JqLzEOLNe;
            JqLzEOLNe += zzhKORJ;
        }
    }

    if (IXhuuhWsDqLuo >= 114309.37809086475) {
        for (int OdYqJbPhDWzM = 987202982; OdYqJbPhDWzM > 0; OdYqJbPhDWzM--) {
            JqLzEOLNe *= JqLzEOLNe;
        }
    }

    for (int efDZiBL = 1339567758; efDZiBL > 0; efDZiBL--) {
        JqLzEOLNe -= JqLzEOLNe;
    }

    if (QHFaXksLfB != true) {
        for (int PsaqfR = 1009783217; PsaqfR > 0; PsaqfR--) {
            JqLzEOLNe /= zzhKORJ;
            JqLzEOLNe -= JqLzEOLNe;
            JqLzEOLNe += zzhKORJ;
        }
    }

    return zzhKORJ;
}

bool rSDBMpVEFz::fwVqygWAOORpuirl(string LCSNR, int ArVYN, string MwnaAVqjN)
{
    string XRtxmRTjL = string("cFkDTlIWdBSjOPcFmmJxSztWpkUkLBzOurUQYaiePGEqXVmoyJptcJbdbZFZUUqQppGNIFcQMMhwNalyqXtsaqVTGsNtfzMksqwNDWrFGFGUYFaZkln");
    bool MPEbXoyyvXHCe = false;
    int wxcenJFPyGqxC = -1940975522;
    double XOhPGRwWXOX = -1039572.9997246655;
    double ZcnPv = 1031741.7406616497;
    double BITuLLhkuIcAbZ = -360692.79246750893;
    int LSMwf = 1164237940;
    bool uxXGzpryVCrt = true;

    for (int ztXUkXAGnt = 875143202; ztXUkXAGnt > 0; ztXUkXAGnt--) {
        ArVYN *= wxcenJFPyGqxC;
        MPEbXoyyvXHCe = ! MPEbXoyyvXHCe;
        XRtxmRTjL += MwnaAVqjN;
        MPEbXoyyvXHCe = ! uxXGzpryVCrt;
    }

    for (int OVtGkAxhUGFNTV = 1959049213; OVtGkAxhUGFNTV > 0; OVtGkAxhUGFNTV--) {
        LCSNR += XRtxmRTjL;
        wxcenJFPyGqxC += LSMwf;
        XRtxmRTjL += MwnaAVqjN;
    }

    for (int oaSpuzbv = 1526708606; oaSpuzbv > 0; oaSpuzbv--) {
        continue;
    }

    for (int WSiTBMfYjPHii = 1584573894; WSiTBMfYjPHii > 0; WSiTBMfYjPHii--) {
        LSMwf = wxcenJFPyGqxC;
    }

    return uxXGzpryVCrt;
}

double rSDBMpVEFz::XuzroBrRlKKIWz()
{
    double ErAQQNWIaWmrmI = -340455.67690917535;
    string tQvyIuBdZWyegwr = string("HVeAVbSZtRETUDhsBuKvZXMAgraxSKwDmNeWpFONPDdMDDkOidLShLuAAWxhIrfyMGVuxnKmTboicTSkkjHEJAmJEqEAZxeyYxmgzRLbNlLIzyTkSrqhpVcfYiCQGJyzxEQ");
    string nFfXkmgBYyF = string("SprHNMQyQBxkOlzvcvYWGoZUVWmSUqhewcgFoEEQEVgngzuGIjCawjCOftqjjUFGzeGYobBCgiWQDlNeQkZKznavrSOluPeVRDUyFJEEPLFOFTtXymyJxUFMOQoeAeNbyzixNnLkpWTUgalbvzTOiaDewFPIBwzlNlfwrrpdBOZPslwrmquOHLMLVgWiAaRcjnhPaMMeuZwUiapYoqZlIXJcgUqCkDdoSIQxYfSwsZXfwhRNccHnInNZTejb");
    bool INNOYem = false;
    string JfwyCAlIiBUjagGO = string("yGYHlCkwCaRFnsrTHQjrFPcgPwIGPqeqOCqZUXBYGzQaPrETnqVePGEkxqafkASCcyREPXkrsdFxQEMzpcEKBSeYLwvorAyurePjGcIdeAHnGwbpcDStfXTAvERrTBRvmbNfxiXNOwojTVYXTUoooqTcnPmwmyncKPJTPnXSbsMSZnYmmwKdsVrRsIflzzypYAaphZYoSvmRpYspSvjQgJBFfwXriAaeGiMLVIH");
    bool ERQNX = true;
    double sZcDMbxVgtpK = 459817.4761608726;
    bool GlBJoPfaxShgQ = false;
    string zmQBTxTwUP = string("HVuPizpOOeaVoVPTlloYeSMuPPuEWJzxEJKRElggnPuVvzwEYiPpyhTPfUbItghxKviajsYdFCqPaVxeQiyqQIHJojzVoJFaBRZGzBDBBcIwNFYJPnQZIiDcvJTbpYACkTyykHWqafRAeUdqe");

    for (int kOumIGGSwj = 813872579; kOumIGGSwj > 0; kOumIGGSwj--) {
        tQvyIuBdZWyegwr = tQvyIuBdZWyegwr;
        ErAQQNWIaWmrmI = sZcDMbxVgtpK;
        JfwyCAlIiBUjagGO = zmQBTxTwUP;
    }

    if (sZcDMbxVgtpK > -340455.67690917535) {
        for (int raKblRFVvwnC = 952569090; raKblRFVvwnC > 0; raKblRFVvwnC--) {
            sZcDMbxVgtpK *= sZcDMbxVgtpK;
        }
    }

    for (int MVrVBsNbqnPM = 1899960836; MVrVBsNbqnPM > 0; MVrVBsNbqnPM--) {
        continue;
    }

    return sZcDMbxVgtpK;
}

void rSDBMpVEFz::tujnDaUPnrjLj(string VBDVMAxkIKuMyGBU, double hTKnevdTAztv)
{
    double GKsYewzAinnx = 132078.3167691362;
    double BrFDyOuypUN = 79551.06176621921;
    int nSGlcX = 756028886;
}

rSDBMpVEFz::rSDBMpVEFz()
{
    this->GcOBnv(string("ckKGzotRNUgpummpOhVvvXIzzqcSgYRufqsgtAYkmknPrkjUdTAhXxVWiDkjorWIhLjdeVHnyLgSZJNuopHAFORNCAhJZxANlpcrCsKpSAxBwSrOzhBZqVcuhdvmicVPZqZGJRiegkQLAOFXGREzMwStNuv"), 263531183, -1300643996, -599867.4666901095);
    this->RwAEwWJcLGPEeiF();
    this->bqhsqGEb(114309.37809086475, true, 203679529);
    this->fwVqygWAOORpuirl(string("vzizsqtefOegmiIWbIgjDiCCKTJyTiPSRggdjpQmZjDQqUXtesXkAJxLIFnTxHJEAhekfxpaQXMAWpPCpBYbqNHkqztOZRGXBXiyKrhaFCUCdrggxCZswDZwAlrIEsXuDwVBlAGTQRtmIsNDsInZJctICLXeDHttWuvPgUFgbQeahOICbLZtFxIBtQedWFUrRJAyyzqNlXYQoiEQgmKNNCcSRpC"), -965106270, string("ijMSFoGHpbdwskVwFjYbedlEtOHZaziSjXOTqFzUgDyWGnoBaiQPEYKNNVhYblWUIBVYVjDAVhGzhDbARvDBVefqPBWtkltqtpeVkAyEAphxmPzBygZUUrShwbodarklNLlqyrYNvuBcWVebDyntzHoZdNwAETcZTAFoFnXMU"));
    this->XuzroBrRlKKIWz();
    this->tujnDaUPnrjLj(string("WfXNAzbnxvPsNEBHIicLjchCbQNbiieQrzMGXxGqWtsSYhhlbcHXnjMSgldTItrd"), 525390.8731766135);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rkmanwtweOJEB
{
public:
    string DcqTNv;
    int sPCIccIprqcENQZ;
    bool yecrXCBJnaljriMn;
    int pGKVWZYsRnpVmW;
    int XDujfdMSireuCrkT;

    rkmanwtweOJEB();
    void mfZKiKQFtFUNumfh(string eXUpCsNlZmp, string BSejfIDQ);
protected:
    int zxlZGxsJultRNJ;

    double ARnEVauMauZZNXu();
    bool FrJJCSQukOKMjlX(string lbZvHUnENjSz, string xzLTsJsyh, bool PoXiyrU);
    int DFILkyXclbeulw(int PVrhuKDBBdbyoMXx);
    double TRNPlryMJi();
    bool UReceMkqTqxuXH(string cFdlPpAkJrWxnc);
private:
    string dLVnGK;
    double vvBRqMfBackRpd;
    double UpInCp;
    int wmLFYhVyKPDHF;

    string FNhxGtlKWl();
    int yDkVqKczjpUu(int zOgSK, int bSVPRsPzdRXKvyJ);
};

void rkmanwtweOJEB::mfZKiKQFtFUNumfh(string eXUpCsNlZmp, string BSejfIDQ)
{
    double bjIPzwd = -68144.8730860514;
    int cejFXGXYMRl = 500280521;
    double ksXFPd = -351132.0713383975;
    bool dGsSfmAMXzCFnDqj = true;

    for (int plYSws = 1343369051; plYSws > 0; plYSws--) {
        eXUpCsNlZmp += BSejfIDQ;
        dGsSfmAMXzCFnDqj = dGsSfmAMXzCFnDqj;
        eXUpCsNlZmp = eXUpCsNlZmp;
    }

    if (cejFXGXYMRl != 500280521) {
        for (int EfMPjoFkDNjPQHG = 618949199; EfMPjoFkDNjPQHG > 0; EfMPjoFkDNjPQHG--) {
            dGsSfmAMXzCFnDqj = ! dGsSfmAMXzCFnDqj;
            cejFXGXYMRl += cejFXGXYMRl;
            dGsSfmAMXzCFnDqj = ! dGsSfmAMXzCFnDqj;
            bjIPzwd -= ksXFPd;
            BSejfIDQ = BSejfIDQ;
            bjIPzwd -= ksXFPd;
        }
    }
}

double rkmanwtweOJEB::ARnEVauMauZZNXu()
{
    double jtFSiZryC = 205592.24679456733;
    string ctyFkxQnlaYEYFkr = string("cSTmLqrIUZMUPNiZoGuwBdXfgFsOsGpzQjoxVdhjpbmFhuvHnWLAIwnSJzLQSeVwoHwubzWTIKzIgdIvMDqcaunjIDwmnsZdteTXZwfQNOFwvhWZUVcGSeFIjIECHiMOsEBwxZEWPNFJjPoIXJSEMsilHASYDyGyOJlIzjMVYHMoXoCFdwkBGXTUcxutsDZmpvspkFkMvv");
    bool FfxbyQTNdaHb = true;
    string dBsrL = string("pZVUNXXqMjhmuDQFoucpZmfrAPvmANbKTIsmXjhBHjzyHqjRNvftsNOXYfDMtJjPFSPYjHuTFqOLAZfjetRfdGAsNpmKmvEeZtFLDdIKWLWqD");
    bool egsuWrKRQjOiIC = false;
    bool AkkUYrriZtQi = true;
    double slujjDfPp = -170857.47909949897;
    double TbYLruiE = -267859.9842344393;
    string lPqqoPVanY = string("tRmKtExAbCltfgOORhRgYdiAGwVNXfUiINioHtrehtbkDiWmZtnNRozMEYXOWJuWoXmeTzYPCRJaLRwfFiKFLaQFsoqGCWtqEhNrEYSByUrWrAoVjXOxWwCLhhzrrmIzbMItkaWbCKfvHacwqLAhRKYZovcJwyDVZ");
    int gpLJUxNX = 1402515222;

    if (dBsrL <= string("pZVUNXXqMjhmuDQFoucpZmfrAPvmANbKTIsmXjhBHjzyHqjRNvftsNOXYfDMtJjPFSPYjHuTFqOLAZfjetRfdGAsNpmKmvEeZtFLDdIKWLWqD")) {
        for (int zTQjWPVHPJrQ = 876457397; zTQjWPVHPJrQ > 0; zTQjWPVHPJrQ--) {
            jtFSiZryC *= slujjDfPp;
            egsuWrKRQjOiIC = ! FfxbyQTNdaHb;
        }
    }

    if (ctyFkxQnlaYEYFkr > string("cSTmLqrIUZMUPNiZoGuwBdXfgFsOsGpzQjoxVdhjpbmFhuvHnWLAIwnSJzLQSeVwoHwubzWTIKzIgdIvMDqcaunjIDwmnsZdteTXZwfQNOFwvhWZUVcGSeFIjIECHiMOsEBwxZEWPNFJjPoIXJSEMsilHASYDyGyOJlIzjMVYHMoXoCFdwkBGXTUcxutsDZmpvspkFkMvv")) {
        for (int xZSXlNLmuNeWL = 1449174981; xZSXlNLmuNeWL > 0; xZSXlNLmuNeWL--) {
            lPqqoPVanY = ctyFkxQnlaYEYFkr;
            dBsrL += dBsrL;
        }
    }

    return TbYLruiE;
}

bool rkmanwtweOJEB::FrJJCSQukOKMjlX(string lbZvHUnENjSz, string xzLTsJsyh, bool PoXiyrU)
{
    int TYFFtoCIvybvq = -1391694667;
    bool VtFugZGGMuBKWr = false;
    string FMwYJ = string("cUtFAPsbhPxepuHrAXmgOABGtdYisYirNiTqFTfbMWDcUPpXJwcDhgkpjyeEMBaBzFIlfoIyuulPEETbGwRgwAgsBmBdotObUEDHMrYlofQXA");
    int ezugsdFNYP = -1471373730;
    string CakvR = string("parSWYWDPwAevHtsWiQsobSfjvPtddmvKiNDNBTznbpggKkAxKRWBTiDscfrkGuROvdqWkRKLtgLjIzWRlfCTxKmAgBJxyHimBblrplBCtKJmvqNXLctGGMPDmGjfnBMkftphoWCncgEwELOwgMdrVFKQLvrPWeLaCvHRxpuBGfksYYmfINIUXZRROgocNMSSunsiNdEncFLNsUjgsWmFxrzzHhBjUKPCubavejEvUZN");
    int faLda = -374100389;
    double BMgnTZtWlMh = -23.715236683029225;

    for (int KKaTVWUoEthcjM = 1146171541; KKaTVWUoEthcjM > 0; KKaTVWUoEthcjM--) {
        faLda -= faLda;
    }

    for (int dXFPCWpHsegHkEy = 404297735; dXFPCWpHsegHkEy > 0; dXFPCWpHsegHkEy--) {
        CakvR = CakvR;
        CakvR += lbZvHUnENjSz;
        TYFFtoCIvybvq /= TYFFtoCIvybvq;
        ezugsdFNYP *= TYFFtoCIvybvq;
    }

    for (int TkgZBsWos = 1731259053; TkgZBsWos > 0; TkgZBsWos--) {
        FMwYJ += lbZvHUnENjSz;
    }

    for (int bAxIlzcCuz = 901736079; bAxIlzcCuz > 0; bAxIlzcCuz--) {
        continue;
    }

    return VtFugZGGMuBKWr;
}

int rkmanwtweOJEB::DFILkyXclbeulw(int PVrhuKDBBdbyoMXx)
{
    string FgAejqIRTfnd = string("zKTREJKngbWkJCYTjvmJuJancaGbGVOTQTynvWpVxUQpnjxsHgxdnBcUDoFWFLSLLnmsvWFrVpUPMhOiXBbUawwhubotyyiJLQUMSxmMFbLOgKfnpZMJyXrpOEdjKlqmXpkeSNAeZKifzvNfAbhuvubXjlhGtwkVeFSqqTDRRlUqgedBLDjUccgOAChomZCImzCkKTpomwMbdfEkRsAZApYFfCMGqBcYWpRTptUsvlfhfFRDczNnWHINTSwDtal");
    bool JyqHELuKtcGZIWX = false;
    bool KKKeGCCVGazFJAI = false;
    double AmSAkt = -1044923.6755889038;

    return PVrhuKDBBdbyoMXx;
}

double rkmanwtweOJEB::TRNPlryMJi()
{
    string aHrohIpbAIEt = string("HjjSmHVoyBHPfWELEiMXzMqFGsmFYXRxuTLsdyLkakSvqewWQEHEgtgqeIztNKBZkQZjF");
    double fMglEWY = 264937.685712869;
    double GmSopWU = 543700.0062196112;
    double uJfSebeIsI = 594593.8168666877;
    string fsTZTpvJjjLg = string("fDdZMhAaiWSeJhQMMiGGEOfBeixVesWfgPhEnJjujOsiTpDMhGAScOxHlsbiVlTHuGMYcMyDjTrFVKozpFkFNqJexangtefPlmcXPhLuEt");
    string JDsrVLDAvYEuaZB = string("XtrMxiXmaWBFoAiEMzqDafKsSpHDwFSGkYrxReJnaBLpWlzMngvNETJwljCthxilVNasGYcoAkwmKYUrtiQlSmkqDIaHDjiVnhdiXsgYRHxYzyqqjblTFfXLpWKvjFkTJnkYxSVWGGJrlRMbXWEaIASkyOlobSeVIMneLFhKFNIlIwNmtRSfGsmbKtuTDwKhlMAgXtKRQVrvDeoVKdpNkMXUMLPfSsDybDQMytbjwwRziIOe");
    bool sOQClIZhQmKoyER = true;
    string BqabPByd = string("uJfpLbLOPzLmTGurfzeEvLaHiAtkguyNqSLEdEQEvCICDYkJTygUYxiNgohidNlmLSUCRNAmYsJFDmxiliqUjTxcs");
    double JJwijodWdwDq = 93465.51394519449;
    bool fQADeMy = false;

    for (int kbhhnq = 1900712418; kbhhnq > 0; kbhhnq--) {
        continue;
    }

    for (int WEmhlnDifctci = 988284062; WEmhlnDifctci > 0; WEmhlnDifctci--) {
        BqabPByd = aHrohIpbAIEt;
    }

    for (int KWzQLsreywMwk = 1985836908; KWzQLsreywMwk > 0; KWzQLsreywMwk--) {
        continue;
    }

    return JJwijodWdwDq;
}

bool rkmanwtweOJEB::UReceMkqTqxuXH(string cFdlPpAkJrWxnc)
{
    bool jOmXWr = true;

    return jOmXWr;
}

string rkmanwtweOJEB::FNhxGtlKWl()
{
    bool yzgNyaAYVttEqoCx = true;
    int rWoupJxaqVHQ = -2001479534;
    bool iEMkvlcOQyBXkFg = true;
    int pcPWCJSxLUp = 279271768;
    bool gesJcWmitR = true;
    bool qGqioIZjoP = false;
    double yWrYhIeTTNXcWPM = -844220.8613020367;
    string QULkQaRntYQq = string("BnqinIVcmGDVfzJxNgGBYIsADneDHeLrqjkYJjrKwajUtyCBvhVItuJAbHwxJLsnOQzLpfbiUsSvoKSndiuTPFjOyURxlVAdURnJnHUtRImODEKQLIknrMSbqyTSFztoPzacgtSGIvNYPsqiMBvyhfFzCAJYNSVFWsZmClgQpmOLJqLzlfvtxHwZzEIPDGcwrjimqkGSVWrtgcTLgjZntVPwVOtEKVYSFXrRBHOpdIDlYgrYP");
    string KfhMrHJUCYy = string("AnBlypdHNSA");
    string MGYDVFdM = string("kZZCWTduAGdZLHrFodwvOhMdlOxsiROeWIIFkvSgaTKwkqbcVrdQlUoniFuaMtBPlvwaueeDPNMlWRDtnueucHxhJSJcEOtVLzTWTDUyliHVYOTyCfqyAletZVIinGrUlyKHvhlCzXTZEpQQmagcfHAlJvLRQiXCmpiVaC");

    return MGYDVFdM;
}

int rkmanwtweOJEB::yDkVqKczjpUu(int zOgSK, int bSVPRsPzdRXKvyJ)
{
    string VDZRrobpDDG = string("aWpgqlsmzhVhuvETBIwFYWcIKWXNbfgyLLtAkVvjgOtVaDueESUcPXNjwtWREmAmpEdKufehHhiqHIDrWuRQRthqBnIIiYGjIqPBvHHmOxmuZUFbTnftFLWdagapJMVtxGChhukxbhnBJEEdvjxCQSJVzNwBYwG");
    string YrMLVWfULPO = string("ASCOinQyKmljcfRLVzXZspjGcTykvmRYBfubfePnWmlmQaNvimKEVkhavcTLcgCiee");
    string ZHCCVKhSRDIEo = string("wkzVLLgJrHyVMONUZdUfDcAZapQVFUAmkUBmdOMMFHkkeOsQUIZYhzhbRGsSbSYQLwXGeMrVZHujBHzTkuVLmsZiYsRHmGrkzWUvTtzUmZfTyxhmIIGfwzecvbSDDLPCFsvZEjYpQORBLZWuYmceVavQlCLZQyePUilUyi");
    double KxrXHaPn = 394659.7108699325;

    for (int EUSvBtfeDvq = 783809110; EUSvBtfeDvq > 0; EUSvBtfeDvq--) {
        bSVPRsPzdRXKvyJ /= bSVPRsPzdRXKvyJ;
    }

    if (YrMLVWfULPO != string("wkzVLLgJrHyVMONUZdUfDcAZapQVFUAmkUBmdOMMFHkkeOsQUIZYhzhbRGsSbSYQLwXGeMrVZHujBHzTkuVLmsZiYsRHmGrkzWUvTtzUmZfTyxhmIIGfwzecvbSDDLPCFsvZEjYpQORBLZWuYmceVavQlCLZQyePUilUyi")) {
        for (int srDpStzTwTyd = 1182514855; srDpStzTwTyd > 0; srDpStzTwTyd--) {
            YrMLVWfULPO = ZHCCVKhSRDIEo;
            zOgSK /= zOgSK;
            ZHCCVKhSRDIEo = VDZRrobpDDG;
            YrMLVWfULPO += YrMLVWfULPO;
            zOgSK *= bSVPRsPzdRXKvyJ;
            ZHCCVKhSRDIEo += ZHCCVKhSRDIEo;
        }
    }

    if (KxrXHaPn > 394659.7108699325) {
        for (int NhOFP = 1464606246; NhOFP > 0; NhOFP--) {
            zOgSK -= bSVPRsPzdRXKvyJ;
            YrMLVWfULPO += VDZRrobpDDG;
            VDZRrobpDDG = VDZRrobpDDG;
            YrMLVWfULPO = VDZRrobpDDG;
        }
    }

    for (int XLMrQ = 1758218673; XLMrQ > 0; XLMrQ--) {
        continue;
    }

    for (int YVWQIjtuxZrvo = 1914782549; YVWQIjtuxZrvo > 0; YVWQIjtuxZrvo--) {
        YrMLVWfULPO += YrMLVWfULPO;
    }

    return bSVPRsPzdRXKvyJ;
}

rkmanwtweOJEB::rkmanwtweOJEB()
{
    this->mfZKiKQFtFUNumfh(string("nFdjX"), string("kaDjAJLPVojZzAbVfvTAsWMAXdxxabUvxSFcroXrKWqwozvKXQjFKisYDLWVgyoQXnjvdCQjkngGBXXGDfxGWIfBUdZnfRmntMydJMDxIPAupCMieRRZEgpD"));
    this->ARnEVauMauZZNXu();
    this->FrJJCSQukOKMjlX(string("XKgjPyeCvgIPWOhaelkYhzjVZtLopBmRIoqiCEFHAmAGyCSoFrzDVcVMvrDIJVfUDxgwoWNWctfIsDSnXshBIigePDAwqDSVriSbJEajhoPdVEAyfhKXRiZRMNyhomfHmtcGDCYnlDHLPGHEPGzfLppnOanHukyxL"), string("rYzanPutBCQUEzYHKcAPuSGXCztpRljgfCJzpMgeVTUvBBxDDRn"), true);
    this->DFILkyXclbeulw(1265836529);
    this->TRNPlryMJi();
    this->UReceMkqTqxuXH(string("TANWjUwpXyJDsJcfWKbVDgmIecnurbGkdLnDUhmrNcMIMIIfrphjWrUJWHkAOmvLtanTPjXhVGDReuVPUAwgcVwAPikAeKzXkVKwaSxNxEGuFcJkLEcfhjuBkiBbaWEcWzPE"));
    this->FNhxGtlKWl();
    this->yDkVqKczjpUu(-1339709999, -2028625777);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jTDqHDoDactPcmB
{
public:
    double eXJrKpnxSjJYwBm;
    int JxlUKf;
    bool AJWdhhAL;

    jTDqHDoDactPcmB();
    int wGNyvBAO(int IKxuSsOzPtRZO, int NDqSpKmZpszTpKB, int jAbjhjjHSPWhmmsl, int ZyjIGbPX, double xgHxanba);
    double mMhwLVpXB(bool rXDRtBJbMeR, string dqkTGNRnkIYa, bool cSWOqcEBjLGNe);
    int ADPsQkC(bool XRtAMz, string zEDkibhHOHJE, double lpBqSSApTdXL, string EzbgYZYHyjj);
    int MgKdfbgVYinysCI(double CmawnQaQ);
    string VOkOEXON(string DSNrxCAQbN, int dlOwhSlnm, bool AAuhrcTGmZGV, bool PHbgu);
    void iszYGLV();
    string nMsHyVlDl(string xHnzEhQuhfnK, string raURdj, string NczoysmxXgO);
protected:
    int UlCGpoQaPs;
    string Sbesyqw;
    string AScBUb;
    string jKADTjjjucecqf;
    int mihKNHHJzbPH;
    double xVhAEPfBtKg;

    double BqXBNJEYrZSA(bool wqLEosofHLner);
    void jTPbxVwyap(double ouPwR);
    bool JnGNqRqBUvLhmzC();
    int JmYgesCgBGhyrU();
private:
    string wAppwdXjv;

    string DooSsRaOzZYdJ(int EPEgRZBym, int kcvJqVxJzBxZB, int mfumoQs, int kqbcrKlsayloOVQ, int NxrfhozgSxfkna);
    double VXmbMG(bool yhxiZGai, int xxkSnbTDFrQsyIYo, int NnczPNMgfsdjM, int xRsWoUJsH, bool kyEIDvBMh);
    string eMupy(double xrLaZIwBqar, double MSGqEpFuXMV);
    double TmSYwx(bool azBqcNFYSlLk, int sqSfSIAYpX, double AmAKzQtqPsWY, double AVMvB);
};

int jTDqHDoDactPcmB::wGNyvBAO(int IKxuSsOzPtRZO, int NDqSpKmZpszTpKB, int jAbjhjjHSPWhmmsl, int ZyjIGbPX, double xgHxanba)
{
    double EVjVLTpScSZYO = 613707.4723809806;
    bool bcgtgSjIOsXZL = true;
    string tDIWHjbljp = string("XaxnhsMAtFDSHIbyoYIFoxfmlDWAKniiOzIKkgLXgotZqIplcEvDXXwwmpkZTTPMPsQEQAThaPcMExaFERVYyRCytqpMmkMksxlmbrqPSIrTnaqWf");
    double JeqeQzmNOkAiB = -921110.695160905;
    double QkNYfVIYWmAx = 260707.8628786967;
    bool Ulwgr = false;

    if (IKxuSsOzPtRZO <= 1073729163) {
        for (int FEWvPRZim = 579096818; FEWvPRZim > 0; FEWvPRZim--) {
            EVjVLTpScSZYO += QkNYfVIYWmAx;
        }
    }

    for (int iFnEimyKv = 211251119; iFnEimyKv > 0; iFnEimyKv--) {
        xgHxanba -= QkNYfVIYWmAx;
    }

    if (jAbjhjjHSPWhmmsl > 63665293) {
        for (int PaYaVDlYvrjzRLQ = 1061256231; PaYaVDlYvrjzRLQ > 0; PaYaVDlYvrjzRLQ--) {
            JeqeQzmNOkAiB = xgHxanba;
            xgHxanba *= xgHxanba;
            xgHxanba *= EVjVLTpScSZYO;
        }
    }

    for (int IEOshiewKF = 1294811454; IEOshiewKF > 0; IEOshiewKF--) {
        EVjVLTpScSZYO = QkNYfVIYWmAx;
    }

    for (int mzylcGwn = 787549627; mzylcGwn > 0; mzylcGwn--) {
        bcgtgSjIOsXZL = ! Ulwgr;
        jAbjhjjHSPWhmmsl -= jAbjhjjHSPWhmmsl;
        JeqeQzmNOkAiB /= QkNYfVIYWmAx;
        xgHxanba /= JeqeQzmNOkAiB;
        NDqSpKmZpszTpKB = IKxuSsOzPtRZO;
    }

    return ZyjIGbPX;
}

double jTDqHDoDactPcmB::mMhwLVpXB(bool rXDRtBJbMeR, string dqkTGNRnkIYa, bool cSWOqcEBjLGNe)
{
    int kyNoWVdKRcSv = -1017005045;
    double oklmwMQJZ = -281743.61514736357;
    string Flraj = string("UfkdkMxzVJECzwXFbzoFMLQqyXxgMrroITDGkHxlTPoKgZBMZEpuSLHjLanwituDefhvriePgbtGOzPYnKBnkcWvtiSfmlzbcCBCBjAISlZlRqecsfqvymBzVprXlzToMZZIWJynFHIbRPfUBLwYxqngxXJyyvLDtbFO");
    int LNNuXdxcHPeKvcu = 1443449702;
    string ZKxJHD = string("qlXVXnCNrBGSFCskPqDjrdHXcLqXSlabJkHwVsFgkMOqwSRLphOxbFiiHJqVtvjDLRUABpsSpUyLpnj");
    int wtuLnSmwf = -1428071964;
    string vAhZrZKJM = string("yBWoiBUooFzlotzFJwvyXwBreDOekotvpOiPbUdrNyDjAfVhMVmaKoQcJSjClkRRFVmMrvfznAvMkZhkIJTjIoZeCFFhPuWmgWJHqWFGYaxIcvXcoXJzFRrCnfUuIouOPmwKAITpsKoHbtwAIoWFixRNMAhKOMfDRaTfNySNbZnVTYVyPWxuZfRXxnWkrqR");
    double EGbcmtgFXKpAfkK = 196179.79690335237;
    string QlrBOS = string("hOmlHzyulBUTTqmEcfHIiAjbxNGLSYheeUghixYRwMfhBEsvvOiAmmjFgFOrnGprkxVYrasHLcMDhFBzYhvUKMaflYQcBxlZFZVjjMLVaqdBqDyyIuBLQKAacOzIVikSIBOiNCVpAJAbPyNjKGoAjrqmyXFAGWsAKRneUVwcJbblukPNobZWqpEDEzuwz");
    string WYilSDNAZAV = string("PehSSmxiVWHVoVrfYysMJFrlFsyVpPLcguWXLwLaxWcuXFcCDUzAzwzmRATXNMMqOryiipyvVhfCaLSHiKYPlcvJhXjZaOEQabixIZqAprMdKyxoa");

    for (int CKnZjqSshwUzic = 1777978814; CKnZjqSshwUzic > 0; CKnZjqSshwUzic--) {
        LNNuXdxcHPeKvcu += kyNoWVdKRcSv;
        vAhZrZKJM += dqkTGNRnkIYa;
        kyNoWVdKRcSv *= wtuLnSmwf;
        kyNoWVdKRcSv += kyNoWVdKRcSv;
    }

    if (WYilSDNAZAV < string("PehSSmxiVWHVoVrfYysMJFrlFsyVpPLcguWXLwLaxWcuXFcCDUzAzwzmRATXNMMqOryiipyvVhfCaLSHiKYPlcvJhXjZaOEQabixIZqAprMdKyxoa")) {
        for (int NPaHWMSzMEsw = 297295088; NPaHWMSzMEsw > 0; NPaHWMSzMEsw--) {
            continue;
        }
    }

    for (int MHnfXUOBJaoBB = 710391611; MHnfXUOBJaoBB > 0; MHnfXUOBJaoBB--) {
        EGbcmtgFXKpAfkK += EGbcmtgFXKpAfkK;
        vAhZrZKJM = dqkTGNRnkIYa;
    }

    for (int rkIur = 1122028915; rkIur > 0; rkIur--) {
        ZKxJHD = ZKxJHD;
        cSWOqcEBjLGNe = rXDRtBJbMeR;
    }

    if (Flraj != string("qlXVXnCNrBGSFCskPqDjrdHXcLqXSlabJkHwVsFgkMOqwSRLphOxbFiiHJqVtvjDLRUABpsSpUyLpnj")) {
        for (int gbdSIkcqOw = 1768415210; gbdSIkcqOw > 0; gbdSIkcqOw--) {
            EGbcmtgFXKpAfkK += EGbcmtgFXKpAfkK;
        }
    }

    return EGbcmtgFXKpAfkK;
}

int jTDqHDoDactPcmB::ADPsQkC(bool XRtAMz, string zEDkibhHOHJE, double lpBqSSApTdXL, string EzbgYZYHyjj)
{
    int FsLlORaCPUjQ = 2085484149;
    int BMjwfYZiroi = 1828520272;
    bool ZvUUQqnoMgEKb = false;
    int oxmBpKzExhlxJ = 601897944;
    string fUclfLnGL = string("uKMdKpUXiRhpHOWodXWlhlTammkdSBxfHlFZNypteGSbGjeUOhoqYcoXqWhUqfimKzvZHSPAsEqwvViKhzEPGsQKHzYeKeRcWTtvhpysaAtmSmenyndrMaBQmktWammlVwpfvONwjahhuiIZetkIEdsVuFtGImhokhjaVnFuAkEAsKFgkkCWdXGBodHgoenDbbteKQMbYlEcuXEImIByycxiWXIjLZeh");
    bool disLSFjSHyruoeEo = true;
    string YLdBytbbG = string("wkRfMENgauYnQdrKRNqPvyDOTEQXYKGLveFeMYAqYVFWYpZWeluXWtpcjxYSojgvNppzdrwrCupsIdLttKHRfcqvoJvpcRlNayJkL");
    double ESYPMxQTXfizkM = 214583.60769485065;
    double azneV = 896245.9884613702;

    return oxmBpKzExhlxJ;
}

int jTDqHDoDactPcmB::MgKdfbgVYinysCI(double CmawnQaQ)
{
    int KXgOY = 1317593205;
    int KCCBkMLHONOdZ = -1014254962;
    bool yhwaFS = true;
    double EsyyxXb = 1023006.7469206956;
    bool hKMsFLlR = true;
    double djEejdHb = -604099.6537174814;
    string PLLoLyQHGxgNEWE = string("dWMsAHECMghwRSdOcvqMpJWVQlqTNKOLWKczFQtdaksJcDIDdCYTbBFqmqKeegrlejFnGVOCDnmZdZVpEHSHMEyZTQFepAodEJZbkVeJxNgfuQzIfJnBpJuVEoXNOElJWfMhSRIckJMYLyqwjFxsrBNEZgGTgwbtMSCjqDOpUXoPBNJY");

    for (int PxDiv = 1115309762; PxDiv > 0; PxDiv--) {
        CmawnQaQ /= EsyyxXb;
    }

    for (int gkQoSnokofR = 164920268; gkQoSnokofR > 0; gkQoSnokofR--) {
        KCCBkMLHONOdZ *= KCCBkMLHONOdZ;
        djEejdHb = djEejdHb;
    }

    for (int NqoOjxENf = 1504940230; NqoOjxENf > 0; NqoOjxENf--) {
        EsyyxXb += CmawnQaQ;
    }

    return KCCBkMLHONOdZ;
}

string jTDqHDoDactPcmB::VOkOEXON(string DSNrxCAQbN, int dlOwhSlnm, bool AAuhrcTGmZGV, bool PHbgu)
{
    bool FYeGLgsAGArCuuGL = true;
    bool vXBzoXFRNSmcI = false;
    string JvezznOzlhNBpDN = string("vdwDdQGlWtcynXWmEDMGuYajCCBNrHQXjVXqACzypfoZrREPRqKUpbRxUdJkWFjcwFCujOBSfLslLkcMMFfdnZnaswnDiTeBNPHpecaoycnAhHzxvXdBfxCNRkyhPXVdhCqXkeQoejDEqAuyDWlZObwimxcFGgcHvPQMdRMLlxyqmnQsWnsdJkuM");
    bool GHMyjtsThEM = true;
    bool ivruhombxSO = true;
    string pZkJvntPRjTCFGK = string("kJbMsyoBPBurpOVdAEyKxgVaQEEKWuThyLXfGLOjlXKHPfvfRUMNkyitqxvVujrAXUPywnsNAyliQivwxzrXVdzXtTIkzaDajicQSjqBMjdmPsafzTbqzRdzDhibQtporHWrgPAFPNmGRSXcovUukLGXoiKcDdJyhCJVywgRTFkFoDqnlqUoGhpFaduHvZNjrmdOmuqFYuJWjSZIoTuE");
    bool gSzcJ = true;
    double XynCGpXmk = 392440.4455995768;

    if (vXBzoXFRNSmcI != false) {
        for (int tMbnCmTtFW = 771005888; tMbnCmTtFW > 0; tMbnCmTtFW--) {
            pZkJvntPRjTCFGK += DSNrxCAQbN;
            DSNrxCAQbN = JvezznOzlhNBpDN;
        }
    }

    if (GHMyjtsThEM == true) {
        for (int AEmikQcSMdUjVhte = 67813711; AEmikQcSMdUjVhte > 0; AEmikQcSMdUjVhte--) {
            GHMyjtsThEM = ivruhombxSO;
            ivruhombxSO = ! vXBzoXFRNSmcI;
        }
    }

    return pZkJvntPRjTCFGK;
}

void jTDqHDoDactPcmB::iszYGLV()
{
    int pUYBI = 1915794038;

    if (pUYBI == 1915794038) {
        for (int yhxTwMv = 1111305537; yhxTwMv > 0; yhxTwMv--) {
            pUYBI /= pUYBI;
            pUYBI /= pUYBI;
            pUYBI += pUYBI;
            pUYBI += pUYBI;
            pUYBI = pUYBI;
            pUYBI += pUYBI;
            pUYBI *= pUYBI;
            pUYBI = pUYBI;
            pUYBI *= pUYBI;
        }
    }

    if (pUYBI <= 1915794038) {
        for (int pZEwSaiKzu = 709141555; pZEwSaiKzu > 0; pZEwSaiKzu--) {
            pUYBI = pUYBI;
            pUYBI = pUYBI;
            pUYBI -= pUYBI;
            pUYBI = pUYBI;
        }
    }
}

string jTDqHDoDactPcmB::nMsHyVlDl(string xHnzEhQuhfnK, string raURdj, string NczoysmxXgO)
{
    string HwpdrtZyk = string("ZNDPyyqyvaHBQHIQdoskdqOkPEJDqbtRlRJPeNjHrDgXOghCuyDDxtEyVqQCLOUojijWDaUfxlKwFnIMXtkJGthIefyzHIBoJidOyDJVSSqp");
    bool dofIzslpQ = false;
    double OKIMIFW = -624364.3553880235;
    double LtVgvyrKIQAkDqF = -648776.4287401169;
    double RyMpOLEqMBuWr = -461962.7320312826;
    string KjxSISwLRJBlDz = string("NLoNKagZYYvDvlPPfEWsBdgUkumyFBXxkACLyRFcJPdNVAiPpXFiGndZUqohyAqFMidPWxzLEJqPumJgUYZKUCqXNUbzsTlfQPGcWpQwImWQxaMmFnzMZdhYDgofTTiLxCvtQTslVXpRlPimxYdBoZkkzQuttVTkgoZUngeTACZrGdgVMBRvygWbSRULrtyKNrUcBfJYknkMWgpNxJxrztmEAdYhCOzMEXqoikVpItLuFsLnlIgtcpxc");
    string Ocbebq = string("VQkCIxBodvkzDZWMVaendzNuOiBbueJwORa");
    bool kZcxDHFLZXKsFU = false;
    string rZPxAJIvUolOJ = string("FbpuWiMyfwGgNZhbzgENezoxaZChpXJUdrEFZFVTwkOgniVwkiHpVxqyjIcfzaOZTCdtnyDZlsxDzXIwpQSDmGRKQqmFah");

    for (int fbQOzUYVjvmL = 1057932302; fbQOzUYVjvmL > 0; fbQOzUYVjvmL--) {
        NczoysmxXgO += rZPxAJIvUolOJ;
        RyMpOLEqMBuWr *= RyMpOLEqMBuWr;
    }

    if (Ocbebq != string("VQkCIxBodvkzDZWMVaendzNuOiBbueJwORa")) {
        for (int ceQExqtRJxj = 202533959; ceQExqtRJxj > 0; ceQExqtRJxj--) {
            raURdj = HwpdrtZyk;
        }
    }

    return rZPxAJIvUolOJ;
}

double jTDqHDoDactPcmB::BqXBNJEYrZSA(bool wqLEosofHLner)
{
    double zEqFnOTbF = 427073.7725868402;
    bool FItfcFxLKMY = true;
    int UhXjka = -2068948251;
    string EInBu = string("BTmoViRfzSicvMJtZEwOwfPIyvMhkmkxmnaJwejDJebAOrSfyruZGWHMkzsDJiJrwEUrfYPfitjhQaNdOJApoZvjYsASETCrmnSumGoPdgMBpKSbiddTkqibpzPPpMaNMVTULEOepQVHyYsCxuYBtQjxlqAYxitfzedni");
    bool RAqFpkPwXSmgAKXn = true;
    bool NWNbOuWKDg = true;
    int TxWwmsu = 1475843068;
    int zkQVUNCotimRZUmR = 562094772;
    bool VTuJHXLIr = true;

    for (int OtmcQiGIrgW = 1835788130; OtmcQiGIrgW > 0; OtmcQiGIrgW--) {
        continue;
    }

    if (FItfcFxLKMY == true) {
        for (int EdtLjmDdrOu = 9412107; EdtLjmDdrOu > 0; EdtLjmDdrOu--) {
            TxWwmsu += TxWwmsu;
            UhXjka -= TxWwmsu;
        }
    }

    for (int kDGru = 672590840; kDGru > 0; kDGru--) {
        UhXjka += TxWwmsu;
        zkQVUNCotimRZUmR -= UhXjka;
        UhXjka += UhXjka;
        EInBu = EInBu;
        wqLEosofHLner = RAqFpkPwXSmgAKXn;
    }

    return zEqFnOTbF;
}

void jTDqHDoDactPcmB::jTPbxVwyap(double ouPwR)
{
    int ubiCCJBzDC = 659222108;
    double IGliEbswlmRoTlWg = -903581.2300289365;
    string jkNPFoJY = string("GyNuxPOQzOQxztocuIiVwNggUWvINowawLNUojqQDggQCoQqkZkkfEyqGbnUGAYueaMgLKBTDvaKbMRqAYvoVRGAEyMsBlcgkkYTeQeKAdKdAiOTQFRNaLABahCqtnwBccizHHydYDWEoNdTxVNtheoeVyvGboncESCIYmSVHJglHoSfCcEmLrVq");
    double tsEZrPLUweZeG = 824939.211356685;
    int JToCJXyxF = -1081106996;
    int kfkOBB = 2019153676;
    double KSgBaZKnWrntXn = -217754.66886051197;
    string cvfASivOLEmALDSU = string("mjsXDpjEZKPdjSuGiGvcSxQjiRZfJCcvvXJFDNoTEofAtNCUJaYEHyGlFAJGERDwnDzxFOErPfLWoKOuwqRpgrqsfIZnAWsRPWtgDQaRpqwZmxrsrcFVvgsoDJhlKhfGyRCiALscQGfdiXBFGXxDqXbeVPsdHMqtXbpdJUFuSWKfRrxDmLcgzNzvNOKQxzgbdPEtvzztCyxbekbFDxoDJgduuHGbGwdprxueaNiq");
    string OmciXsxCy = string("NhFwUrqhqMtcLjGUAMwkPPpkWtbIgSqJYLVllpaWUZmrOSuDpbjssMfNumUKtutISiJThrbAsnDXPyZAzmyDZUiiT");
    int vrJDTvHsS = -1928313351;

    if (kfkOBB == 659222108) {
        for (int TUYQup = 416628436; TUYQup > 0; TUYQup--) {
            continue;
        }
    }

    if (jkNPFoJY != string("GyNuxPOQzOQxztocuIiVwNggUWvINowawLNUojqQDggQCoQqkZkkfEyqGbnUGAYueaMgLKBTDvaKbMRqAYvoVRGAEyMsBlcgkkYTeQeKAdKdAiOTQFRNaLABahCqtnwBccizHHydYDWEoNdTxVNtheoeVyvGboncESCIYmSVHJglHoSfCcEmLrVq")) {
        for (int soDMxpVzMHVxbUM = 439143516; soDMxpVzMHVxbUM > 0; soDMxpVzMHVxbUM--) {
            ouPwR = IGliEbswlmRoTlWg;
        }
    }
}

bool jTDqHDoDactPcmB::JnGNqRqBUvLhmzC()
{
    int kvkjE = -2018893737;

    return true;
}

int jTDqHDoDactPcmB::JmYgesCgBGhyrU()
{
    string LqLEoWzZWcN = string("TapUpWQeEtpGZaQoiVcOexsFpwvoVdRlnNeMbuKEMozAywxTURdKZOEAUBkKCXxQyKnOEMhVJgmJcoSOPlxgegoETNurfOCqEMrROAYFMxXYVOrkwxqicquBVFzhwhIyBJ");

    if (LqLEoWzZWcN >= string("TapUpWQeEtpGZaQoiVcOexsFpwvoVdRlnNeMbuKEMozAywxTURdKZOEAUBkKCXxQyKnOEMhVJgmJcoSOPlxgegoETNurfOCqEMrROAYFMxXYVOrkwxqicquBVFzhwhIyBJ")) {
        for (int xJMNKyUBQyoXKb = 374219106; xJMNKyUBQyoXKb > 0; xJMNKyUBQyoXKb--) {
            LqLEoWzZWcN += LqLEoWzZWcN;
            LqLEoWzZWcN += LqLEoWzZWcN;
            LqLEoWzZWcN = LqLEoWzZWcN;
            LqLEoWzZWcN = LqLEoWzZWcN;
            LqLEoWzZWcN = LqLEoWzZWcN;
            LqLEoWzZWcN = LqLEoWzZWcN;
            LqLEoWzZWcN = LqLEoWzZWcN;
            LqLEoWzZWcN += LqLEoWzZWcN;
        }
    }

    return -444935512;
}

string jTDqHDoDactPcmB::DooSsRaOzZYdJ(int EPEgRZBym, int kcvJqVxJzBxZB, int mfumoQs, int kqbcrKlsayloOVQ, int NxrfhozgSxfkna)
{
    string crpnnYwt = string("yUaxBUkfKZRQNIBPrIAmFkGBfmrmwDPFOPzJjbEGqclBjAYWWOeqYzbeGEXCDOWOCxzxxZQAfkZAjdmKyUnoaHEBhzcCEmdWVwCBgyAZmMiQYWAyChfsZpsKQRgecFPRDBYjQNIAZABIxmKXOdwvPC");
    bool gyUYWgtMjkCTBFr = true;
    int sKhwgH = 556318867;
    bool jLFtPAprPEXChOq = false;
    string fesVPasGNKXKm = string("DTCqeOZwzbwTUSeoESRFaBJJMOFwxbMBcYVUQnZpxHCIHUBQSouvNd");
    int nwWjSwJwG = -714128044;

    for (int GRfLk = 751142170; GRfLk > 0; GRfLk--) {
        fesVPasGNKXKm += crpnnYwt;
        sKhwgH += mfumoQs;
    }

    for (int YcZlBfcbConGs = 635459744; YcZlBfcbConGs > 0; YcZlBfcbConGs--) {
        sKhwgH += kqbcrKlsayloOVQ;
    }

    return fesVPasGNKXKm;
}

double jTDqHDoDactPcmB::VXmbMG(bool yhxiZGai, int xxkSnbTDFrQsyIYo, int NnczPNMgfsdjM, int xRsWoUJsH, bool kyEIDvBMh)
{
    double tVkIPvSAhbghQpym = 1011485.8059433387;
    int kLgwpvnnXWx = -1584837085;
    double FDuMxckaWllBHaBt = -853301.1637300993;
    int yryBTeiRApj = -2107406667;
    int bJElKvfBLJtD = 1365489653;
    int nrQBmlhHl = 631387623;
    double aIsxBAbuVkvnaXOP = 113739.07650172537;
    string HTyccauVvBp = string("KhrcnisyxvwkKAJbofSMpqpqovPnXWDEwy");
    int WxUEPwU = -246977343;

    if (yryBTeiRApj < 1525942442) {
        for (int UbgjGyv = 1715116347; UbgjGyv > 0; UbgjGyv--) {
            nrQBmlhHl = nrQBmlhHl;
        }
    }

    for (int YNPyx = 721443909; YNPyx > 0; YNPyx--) {
        xxkSnbTDFrQsyIYo += WxUEPwU;
        HTyccauVvBp = HTyccauVvBp;
    }

    for (int xFsGPsIqIOXpHBd = 234537626; xFsGPsIqIOXpHBd > 0; xFsGPsIqIOXpHBd--) {
        nrQBmlhHl += xRsWoUJsH;
    }

    return aIsxBAbuVkvnaXOP;
}

string jTDqHDoDactPcmB::eMupy(double xrLaZIwBqar, double MSGqEpFuXMV)
{
    string pXFpmujWRKMFSo = string("uOovXLHtDAFaUWSFHqAhgTWclbVoFEABLCirgAILM");
    double hfxynSLjBi = -647165.9610185103;
    bool JjJrEYQguST = true;
    bool TWtGDHpFcWLQ = false;
    bool izawAnRln = false;
    double ScqwxTRD = -5712.067786548079;
    bool yVueRBXMHILDHGfK = true;
    int SVwJNX = -1947723811;
    double BrEYGAsjyOz = 401138.1380245094;
    int GmOJINNR = 674541808;

    for (int DABADTDCXLDH = 1639029341; DABADTDCXLDH > 0; DABADTDCXLDH--) {
        SVwJNX *= GmOJINNR;
        JjJrEYQguST = ! TWtGDHpFcWLQ;
    }

    if (SVwJNX != 674541808) {
        for (int DijCjPNCJuZMSPQ = 294344890; DijCjPNCJuZMSPQ > 0; DijCjPNCJuZMSPQ--) {
            continue;
        }
    }

    if (BrEYGAsjyOz > 274699.33781541424) {
        for (int UExwmU = 290836715; UExwmU > 0; UExwmU--) {
            xrLaZIwBqar += ScqwxTRD;
            MSGqEpFuXMV = xrLaZIwBqar;
            xrLaZIwBqar *= xrLaZIwBqar;
        }
    }

    for (int hbGlnGD = 770126461; hbGlnGD > 0; hbGlnGD--) {
        continue;
    }

    return pXFpmujWRKMFSo;
}

double jTDqHDoDactPcmB::TmSYwx(bool azBqcNFYSlLk, int sqSfSIAYpX, double AmAKzQtqPsWY, double AVMvB)
{
    string pfykVyw = string("nBhNogfcPEzfHpxTYgsJgjUoAVEkDOKRVsf");
    bool iQtvPPqejIU = false;
    string mHmspPRqQCMb = string("dxnwKerSOnMUNedmwsRqzFslXCdYsELPiqarcLsaHzIcgiusXhDdiphjsXNdSOpwRebXHEOlQVtNgrQBCOcMeOFUXMIUZZsfimNcDuZDcKunzNKlsUHKpEHgBJftZUwFoiOKRXABlUUmqwNXZZRnultCdFIXHOiMMoRtjkQpxXWqJ");
    int OTvKnVeTPA = -1100435243;
    int SLsRDoxALyfvOQ = -1818335567;
    string OPXnbNj = string("gRZwZaCupFCQgslElooiOVcqlxFcQZMzsMQwbaLzLBtwXmoYysquiGlDqCzSzDbhTfsbXrWRayspqfKdeMdsNHAcnXcokhfrRtVzYUORqsotHDcxccLk");
    int LOyRkgN = 847353309;
    int xiAeGVufnDzCrU = 59794409;
    bool JrcFpUmJD = true;
    string YTUyANCdUeRYCGUh = string("mjLuLNABArsOWjnAcXXrCBghMeKdtMHRayHfeWSyKdFqVFwjFKJqzbSBrxfHNuxsmoBjcJxbqoaHpFnJeKOEZBElZtqVeobaxFffigsYnFQEkEUktCgUjexjKKyJNGLbiobbprXOYTvkEnsHpeMHHLHxCFBvPyiUtSWbqXUpYnScnutcRRUkVWbkabVHbIujcySdMXInZAOrvcWmwxkubkvYa");

    for (int yJOSpPMBHf = 2031140323; yJOSpPMBHf > 0; yJOSpPMBHf--) {
        sqSfSIAYpX = sqSfSIAYpX;
        mHmspPRqQCMb += pfykVyw;
    }

    for (int QuodERbBTvq = 793084193; QuodERbBTvq > 0; QuodERbBTvq--) {
        OTvKnVeTPA = xiAeGVufnDzCrU;
        mHmspPRqQCMb = YTUyANCdUeRYCGUh;
        OTvKnVeTPA *= sqSfSIAYpX;
    }

    for (int QTPOZDv = 859213161; QTPOZDv > 0; QTPOZDv--) {
        OPXnbNj += pfykVyw;
    }

    return AVMvB;
}

jTDqHDoDactPcmB::jTDqHDoDactPcmB()
{
    this->wGNyvBAO(-1359225984, 1073729163, 1550802377, 63665293, -371918.87337427726);
    this->mMhwLVpXB(false, string("gWCTSZPfZmSLaqakuEciSAnQzrFRCkSzimNHicYLXbJXHUKwUPnzDaCucyoxZDKUSXXrxhIntPJMQVltgkXcNtmCxoBjiFxBWfhdMLRkyiUvXCnLQWkCCodvWuTbmf"), true);
    this->ADPsQkC(false, string("xKetmHDGsUZupdQadfvkRNXAJSzrOcbPdJtanmHRdyjTxtbuKxMUCnaFlRBnnhpducMQAVJlkoqFiRtyFcBJsq"), -722551.1384686657, string("JDJPogErcgFuvozIstaoxlgRXxbwc"));
    this->MgKdfbgVYinysCI(53994.487435899224);
    this->VOkOEXON(string("BxyvpxnYdEjLfcmjaQIvXsHYSBYtaSjfwQKxHkXPYgLbRnqcKYFfEpUFkwChsaKVnYiAwgnRRYHCiEARRZzrzywUzXzLAtkEBwRJJEyTrsDQAqiegYGvNtauvSdYrOOsknzWJlEnVZALRJDgICsQAAJfSvNotLDsZxxqP"), -411603034, false, true);
    this->iszYGLV();
    this->nMsHyVlDl(string("uedxOjzOvgcIKWOqOEWqHdFAmhyoXvKPpQCXaSbAvocPOjVfBXlDTSjdQgeBYnyquTobpGznAeRYngIvycrPTHKPEocXsvMcmiDrLOWTCGFIlqyghjFgcVyqSTkcqHTCFmTIdMjBDjQyGKJGqfSqyeYKRQlneIfwvdbYEzfHvgkhgUivDYVGYQJgjCVmZBUdjmjhbZERiyltMOenRVvVqSwngzxNZEFrbS"), string("bPIAXYDMdAYctRrhSArvoJCIGwlwcuRRkxvEdbXaZJoJbPgrTZXqZSXYgXURKZeVsMNkfFKEHPXOFnlHXwWVzZGxqNuYmOFGJMNjWHazeiWrkqDsBCNeIaswakfNJoVTpiYfyVozjPjTtiHXIzUzekRPsNZKHIQMuXRdFwzvNdZhdQDFHbkmORErmhNLIWhdulVIQW"), string("dRjiPjiKWsfTClDvQlnwXapPnivveNeFNNpxMGujPPHXwGFhLLcqjfMOZBmkQKROoZLBZHESRiWsXWKalYKZstEwQkZAmPptHbCzpHhLIIVbudOyfpcdFvmazYWoupuVlJMiLwowTMZaYwXvuZMxdFxgIpLZoqpHBnSqPhtbvYGZgwvmFjzEjwUpNQnsdTUPTFcTAWCEcgpsOpViiERLeGlIg"));
    this->BqXBNJEYrZSA(false);
    this->jTPbxVwyap(-60183.51286798467);
    this->JnGNqRqBUvLhmzC();
    this->JmYgesCgBGhyrU();
    this->DooSsRaOzZYdJ(1821553127, -648752586, -307931341, -1714929007, -1257428749);
    this->VXmbMG(false, 1525942442, -831931165, 946106345, true);
    this->eMupy(274699.33781541424, 613174.1434395183);
    this->TmSYwx(true, 376802129, -796584.5834512789, -627816.0883082491);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xYcHY
{
public:
    int rmbkyznjVPze;
    double GWLpGpmcEc;
    bool qgUrovMJ;
    double muEof;

    xYcHY();
    void mgmeHEzbJLbCKEF(int xkCNW, int LOrcDPEpGwQFiKdo);
    void sgWWXHpdsCMieVoZ(double xAZhPQrEJiMv, bool OUFyNswYgfCf, int TnctRBbPKUaHJkF);
    int UoivmoaFdUugxde(bool HBMqMpx, int zxbOhEHyt, double JztYtL, bool GIrrQLXQKV, double eYsgt);
    int nqejNUduJteE(int sxwBmUWCLUPb, string NHhOzCHNii, bool hQxEy);
    double aacVRasxhAWBEI(int PLBnJbGhDueGL, double wPQMSMXTdkiGcjAl);
protected:
    double hBqcUmqccfTH;
    bool nBoWjVIVWkeBKM;

    double xOBNLqpkXl(string fPFGfz, bool ErSnIUUNOin);
    bool XdnlPHq();
    void rgzTriWNAAR(int yHqPzlAoroEWUTR, bool nYTrLcnBUdZh);
private:
    int TlxCo;
    double gFbWYfmcFbKn;

    int kUdAxcdPeLwFk(double JYyCwDsD, double OvJTfZ, int dOSrFE, int zgICxzG);
    string vHguthQu();
    bool xEaIVqVVUgVMFV(int UooYdsQdSU, int unTYzWbiwjiLA, bool yDjBdNOxzTb, double PcEJzSaLCAgDkbnO, string MeZtg);
    double LVYuTpwHlT(int SoOQWI, bool GkkEEvSySmEeVYN, double GsuqlUkxMXxhP, bool PhiiDjUwMLwqK);
};

void xYcHY::mgmeHEzbJLbCKEF(int xkCNW, int LOrcDPEpGwQFiKdo)
{
    int OCQLBaqIoBVGkixb = -455454696;
    string baWqfCVaYFSWBw = string("rkpZUjbxguBJcMqFClNdFUEuwWkWxZMVjgbUztJGgeRUrDwDUUAJFyyePuxMIcxPxNtKivyl");
    double boEdEDvjcUl = -843457.3093657482;
    double chGMKGJh = -590156.4713368752;
    double ivSBBcRb = -319568.1726283187;
    double VcsFNcEyiFPMuG = 229935.35000429605;

    for (int eQkQWKahW = 580432949; eQkQWKahW > 0; eQkQWKahW--) {
        OCQLBaqIoBVGkixb = LOrcDPEpGwQFiKdo;
        boEdEDvjcUl += VcsFNcEyiFPMuG;
        chGMKGJh *= ivSBBcRb;
    }
}

void xYcHY::sgWWXHpdsCMieVoZ(double xAZhPQrEJiMv, bool OUFyNswYgfCf, int TnctRBbPKUaHJkF)
{
    bool zYdRtbPXDQyU = true;
    bool yOsvJjZVPrdmHRja = true;
    int ryyHwHcfhav = 1284160337;
    string hlOhZDaWuKGTGfq = string("HPXZSxCPqkHszmRpxaIdYpzedJlBmiYFXFEYrxtrBzIymqdLFAikvM");
    string wzQvBsi = string("UbFEvbhtBtbrjqsZIUpvuUCDGltfmoclOEVReolyVFXdnxXVWcntLErsNkgaFrtCfAdKsHpVRXwzRBcOTElncStozySwjDJRnjZKQpwSAKSlXmNswETTaiZYhYDvyPeLxBnADxNWXDQpnJzyvtwuwUtWtvgmCqUnhxGwTxaZjrtUfLGKIuZswqN");

    for (int yRydeU = 968322857; yRydeU > 0; yRydeU--) {
        yOsvJjZVPrdmHRja = yOsvJjZVPrdmHRja;
    }
}

int xYcHY::UoivmoaFdUugxde(bool HBMqMpx, int zxbOhEHyt, double JztYtL, bool GIrrQLXQKV, double eYsgt)
{
    double GoTvHFNkYtzAUF = 691195.0716322442;
    double tWbTGaOLlE = 176436.31879314757;
    string ePZQPzgfiEJs = string("WeJbPHQgPgRhodUXaRRWnLkUCKAOcYFBCnSkNGzXCvhZnusuroKKfDzsKKVeltLyjTNCHuPBDJeHBvbHDIRU");
    string fvSApV = string("ZdSPodPrJZIwSLYlJpHoNLXrdpJlqpFzoiNaIuGhqlgjZpmQagPuZITrccALEeonHXhLBKWverMCKWBsv");
    int FkQCnkyRqIW = 2090247109;
    string CJmHMdvle = string("lWnrrYeWXzeSUdeuGKlpS");
    double XAjAbHcjcdtqK = 817058.6180025015;
    double ghrMkCxZsMGsV = 313503.38534915895;
    bool nglLa = false;

    for (int IyWxYNk = 202066928; IyWxYNk > 0; IyWxYNk--) {
        continue;
    }

    return FkQCnkyRqIW;
}

int xYcHY::nqejNUduJteE(int sxwBmUWCLUPb, string NHhOzCHNii, bool hQxEy)
{
    int obKajBDHETidR = 2139893322;
    bool ncNmyTNxLvZ = true;
    int dCvhvm = 801270476;
    string UhqUJvAbAGr = string("WkkkOjfpMrBBEjyMMlgBdIONcBCQmkyrSGHgZsZoxkNhzIyzdkNipzgpOpoeIhBwzzBEIHKTEbHLsuwoKQJVkxDBkNTOjJGDTygNnqQghsCSrJvKJ");
    string EntTPFtG = string("XZHqTsmxJYJJSaNETapKdPJASxBKPObpIFYbFJhkwNQKammdphvJvjDIlOTCJlfKyUUqyOZKGozJmVcAzBIcvCoWqoJErvdXqKQqWCulJuahKhbuXPRrVzspAHmUdvrAKKWDYHBVoBJnSTDVuDMKbAKaKQXfiFERQAFFfutUciBNYHNYsiCDyGsOXEiYeDBYbineZaivylkBSxnuWgepyhaB");
    double dnLEkuCG = 111487.44922148284;

    for (int nInsNTwuUrCBVzI = 2037171293; nInsNTwuUrCBVzI > 0; nInsNTwuUrCBVzI--) {
        dnLEkuCG += dnLEkuCG;
        EntTPFtG = UhqUJvAbAGr;
        hQxEy = ncNmyTNxLvZ;
        dCvhvm *= obKajBDHETidR;
    }

    if (EntTPFtG >= string("WkkkOjfpMrBBEjyMMlgBdIONcBCQmkyrSGHgZsZoxkNhzIyzdkNipzgpOpoeIhBwzzBEIHKTEbHLsuwoKQJVkxDBkNTOjJGDTygNnqQghsCSrJvKJ")) {
        for (int dYuwbYkSED = 1364554976; dYuwbYkSED > 0; dYuwbYkSED--) {
            hQxEy = hQxEy;
            sxwBmUWCLUPb -= obKajBDHETidR;
        }
    }

    for (int pCcNgKAl = 800593295; pCcNgKAl > 0; pCcNgKAl--) {
        continue;
    }

    if (sxwBmUWCLUPb != 2139893322) {
        for (int lEsLaGzo = 416192904; lEsLaGzo > 0; lEsLaGzo--) {
            UhqUJvAbAGr = NHhOzCHNii;
            hQxEy = ! hQxEy;
        }
    }

    return dCvhvm;
}

double xYcHY::aacVRasxhAWBEI(int PLBnJbGhDueGL, double wPQMSMXTdkiGcjAl)
{
    double nccMF = -263722.8571441374;
    string afGxKKX = string("RGfbSZaatwvVSHXqCAEwfFAGXUpTNNnMFBRoayILCsLEGfVcgTvUzSnQVnVpdpwJRmUpTokdPQTdgRIyLUroDognfMeBsYFospblvGYweAXPSMyrWGzHmieCWbyaRanQcNtflyBpXUPCwgRErTaErFuVclqZmoIGABBUQYlXiwnYYKeqEJYDDRlsGcIlcwYZzqQaxruQIdglehtvoFXeXraDWALuWOoveKjSTvOwfZsrxAbRQaY");
    bool QsBlSwd = true;
    double zfsVYz = -356170.5231508669;
    double YAALg = 721336.2105510451;

    if (YAALg > -263722.8571441374) {
        for (int HTyMyIsKMakaadK = 1556635043; HTyMyIsKMakaadK > 0; HTyMyIsKMakaadK--) {
            zfsVYz -= YAALg;
        }
    }

    for (int QqbFEGkZMgjaY = 1695575128; QqbFEGkZMgjaY > 0; QqbFEGkZMgjaY--) {
        wPQMSMXTdkiGcjAl /= wPQMSMXTdkiGcjAl;
        nccMF /= wPQMSMXTdkiGcjAl;
    }

    return YAALg;
}

double xYcHY::xOBNLqpkXl(string fPFGfz, bool ErSnIUUNOin)
{
    string rsOSaruqGPdS = string("WVrbxtTtlykMIpjcbADju");
    string YFUOSL = string("oyjrfcPfZKhlFjethjJnvaOURXGBskrUShTxOgNQKYicsCFKWXqlhEOEJfCGc");
    string hXZZWDaD = string("lyteeqBydZnnraFmzbGuptjdYrDHrNVAoSnmsbMMDujLiKlFdBUivBJgrkuKTBdNuCyUEjlUzIcAqbYXMxtVsYDMFiSHvRWGorzuOVLOBAPEhJIGSMGzaAboZZXPIwItyttNzbSRGEOCDdsWXaFwOTkDwLUmFUhpSgwxmwsbcULweWXACmNFdZGaDGFHvgQxbxVTKrMxmLEiJUfCDvrzYzKmMubIpxVOinjZiLEIi");
    string TKKaST = string("hYtirIFfXmGBeHUxbLXmyPPjQiBSnoLeQuYVrSWUCsQEUsiAyvutLCyJZhUkNAjtQGEZCVqrFLMCIcgDJHrVlfFteGpYqwwybwmqBMSNkbmkuKRaiPniAilq");
    int UrpezXtqTrANai = -1504693885;
    string JTRuVtXM = string("RWrWVeSSIXtpsQdRuVzIFTSwjWJuRiSwYNPawmXtUpWYwylCDLOArfNsA");
    string LqPam = string("IIpYMVrCLglATDPBjpUmYEjWwpephSoGJfWLuZUVCIZIPQiBcAiOIcQZHEpOEFBejeluDwSMksTol");
    double yAikstfJXBgSjPTN = 950023.4526728556;
    string LBBmKivPOfMLaI = string("EmlLLngKMyhotCLxVLnuIuCeivktIcPzYgHzCEAwbfhPsBGVRiDmimAajtRtXaxwekkRfZsZVzHjUZSBDEPBtpYTotfycJRAGMqBlgfsGYCdYHtFcDYWvuwWi");

    for (int KFnTd = 2064244129; KFnTd > 0; KFnTd--) {
        rsOSaruqGPdS = rsOSaruqGPdS;
        TKKaST = LqPam;
    }

    if (LqPam > string("OtCwWQGqGKarOxwthJevjvJhtbyCwJzUHlCbgDWfrENePjkCLuzWgxNiPKAMnPVMgYunyN")) {
        for (int HNCdcEYcWmoHdIz = 1663900019; HNCdcEYcWmoHdIz > 0; HNCdcEYcWmoHdIz--) {
            LqPam = fPFGfz;
            YFUOSL += TKKaST;
        }
    }

    if (YFUOSL == string("hYtirIFfXmGBeHUxbLXmyPPjQiBSnoLeQuYVrSWUCsQEUsiAyvutLCyJZhUkNAjtQGEZCVqrFLMCIcgDJHrVlfFteGpYqwwybwmqBMSNkbmkuKRaiPniAilq")) {
        for (int DfvQqklLFMgdbFt = 611835115; DfvQqklLFMgdbFt > 0; DfvQqklLFMgdbFt--) {
            hXZZWDaD = TKKaST;
            LBBmKivPOfMLaI += rsOSaruqGPdS;
            TKKaST = TKKaST;
            ErSnIUUNOin = ErSnIUUNOin;
            UrpezXtqTrANai /= UrpezXtqTrANai;
            rsOSaruqGPdS = LqPam;
        }
    }

    return yAikstfJXBgSjPTN;
}

bool xYcHY::XdnlPHq()
{
    string XmEjvUiEtB = string("EqZUnwhDcqGPgaKkRBPzUjvAdfYyIANDiFctehzyBQzVINqlxANtJCwEnvIqslElkllaJWDeIifSEplShLorQvhXDklAKnAWtwZTOyIyuLRxMgkWmbeybCT");
    bool CDyTX = false;
    string FowBpXHVYKSRgjd = string("zxPyfTwGcXbQrXXtMqszftKljTzbElonbeuoisaaXApTOCxxXInmDPdsoukb");

    return CDyTX;
}

void xYcHY::rgzTriWNAAR(int yHqPzlAoroEWUTR, bool nYTrLcnBUdZh)
{
    bool XjtoSWsHKCVUmCL = false;
    bool UbLJxZpHYvkZI = false;
    int PKhnEvsQ = -2118547292;
    bool xIiHAxecyP = false;
    double PxmQdP = -437852.0600579454;
    string IrIMREl = string("dQLHQocFNJVgVErfleKbQsORNBWnYaXKuikouJtXmqUKnTZxoNhUmuBGsweEwzkaGFmPFIgfkEYoBHmeTbICuLhkXJiLzGuJEimStErrnXHDxWecTcBxlyEbrbAAGiOcAhCQjivGhraVHIHwWtvdtjjCKmtFgLnIaraWzKWOybKIMqqSBLVBkFuQXsQygIjdJtDLjGdyfBdAtvztNJOYiCFoAiICEfxvHan");
    double ugKRIcXwJa = -478488.0789535362;
    bool cbldMSfLQmEO = false;

    for (int agtFzxneTSHG = 1297638588; agtFzxneTSHG > 0; agtFzxneTSHG--) {
        ugKRIcXwJa = ugKRIcXwJa;
    }

    for (int OVNbiKkn = 1858478767; OVNbiKkn > 0; OVNbiKkn--) {
        cbldMSfLQmEO = XjtoSWsHKCVUmCL;
    }
}

int xYcHY::kUdAxcdPeLwFk(double JYyCwDsD, double OvJTfZ, int dOSrFE, int zgICxzG)
{
    string DfXlAmGYQfDPSgz = string("RmsbQHtVfWeYqsjWOZBDImtyTbluGFWWOIWuUoyCCQNyOPxTvTICUHDxQfKTaJKhrWSilsyalTIdHwriAShCLtGzSWjLWo");
    string gPLVewuUGk = string("VfwPbwfZsqFoBirxXobYLbZzJNPzFUYldnBYuNhfPdyjKmydHjMitUxdXPiruFJVEAxltljOcIAkabeahwdFLpcbIaFJnzhFnvrAzrXyiHlNcoouliZuCPTuShjoiSuJkwwdjGYxOvjfrkBcBlTeSWlMBTeyiuRGB");
    double TxFkEBvyvtvBL = 198756.14138425415;
    string nyXDafBdPQyLJ = string("avwUAsTQRGEsXHoTppNZrChiYULdsDfxXmlqDVSZjhNwPoXMtZIbdbhrkAXyQNhzjHbgsvsrxxoEobfofzvCEWDerDywUTYXrIeweMYdaTOYnOsTSbWcJPiZRVBtZNxIKYipIoovipigCJHtISyfHEaYhijthojjcVufjLHmsvEUdnotRWTOLsgRGnqeookCnXgQKiXcONhhNDntzOkPHZbEgfFlEzMMuwQPKvxpdtalSKJfniKEVvzFCHADak");
    bool aTtWFOJJishFvB = false;
    bool SIrUVrp = false;
    int KouJfPMWjikLOL = 440641649;
    int fVFmvuSXBenf = 855883397;
    bool IZpeezy = false;

    return fVFmvuSXBenf;
}

string xYcHY::vHguthQu()
{
    int gnPCBHOjRu = -1855598902;
    double CidDBbPM = 978985.45379937;

    for (int FQdBXMCOfkAgOZ = 6357961; FQdBXMCOfkAgOZ > 0; FQdBXMCOfkAgOZ--) {
        CidDBbPM *= CidDBbPM;
        CidDBbPM += CidDBbPM;
        gnPCBHOjRu /= gnPCBHOjRu;
        gnPCBHOjRu += gnPCBHOjRu;
    }

    return string("meQyVyZqssfujHRZIocZCwtxhXKqzCxkuWwDWnnBvLrIBdKBUiGTPcAauFPKKYpDmaOLmdtSKpnvPkHDnpEwrbNPyAEnAbZvzkWCSOdzvuSxOQSzSVtKXZSXOoTszqtddoqkiFIMon");
}

bool xYcHY::xEaIVqVVUgVMFV(int UooYdsQdSU, int unTYzWbiwjiLA, bool yDjBdNOxzTb, double PcEJzSaLCAgDkbnO, string MeZtg)
{
    bool tpTtMQhb = true;
    string HpUBvx = string("IWKerUZUhYJfvDKSIUSUneuDlUIMLXYpydfHlSOqSIvlbddUxQbtNysWNdRbgYqhguFJyeCnFPGsebjAOcdFyVZZwXuEXNktCYRCOOmJfMbBcKHduwCeDRkZKEEpQDlONaVeDUWVjmbzaVY");
    bool BPGPKRRtfS = true;
    bool ZFowupE = true;
    double sHemP = -43307.848975980625;
    bool KUezZxWFMJ = true;
    double prJZC = 296745.2109889285;

    return KUezZxWFMJ;
}

double xYcHY::LVYuTpwHlT(int SoOQWI, bool GkkEEvSySmEeVYN, double GsuqlUkxMXxhP, bool PhiiDjUwMLwqK)
{
    string NTWUFHJbzzEtDv = string("wLPWmBZjspvOPHthQFqMWaxoiPYtRorYwZiQGTVrZlPJikEdxsZZeOUxZWbfqnbiLiTVjGQzVQyUaFcMDaKMEvifhlhEHcORUlNOSopgsoPwZdCFTqGqwDYoCCByeSaccOZNjYZfzmVNpmVwlEonMCoaOLffkTyDQfnfGxYh");
    bool QRbaYbshCQ = false;
    int FVmXVIVPqSjPVor = 526821952;
    double YyVxmU = -549611.4048581551;
    string wCrLNLmUWfNcyJa = string("kiaotvekYUuaUpaQtxcFotphEJYsluLhjGpVgiFMrKPebtTQIiUCylvaOyLTnDybFTbCrKdhgCWYNEghMfkjcUgfQnNjEzwXBoWIJYnfqCxJjZKcwPpbeDplWFfXGzyXSwYwtKuUKxGSPhkSqYllYqqcQpli");
    bool VaJDKMZBewNXR = false;
    double eLcuVhEpRaadyK = -868732.1696740192;
    string CxWoSIJKR = string("jpHQdSjkDsYmUTIaNiIHHRigLnwmItHfWngKuPxzhYQequBhfYVkQkaYyfJluXanJqYrWFJeOaHEvVGuIjlZqAAsVjaGugObhwxRSKaEbVaCdvJgXrzpwsvNlrJAGkqSgvqnbgxJqeZphgwSPpMkXzPFnQvYMzxHtYeSJlXTxpmoKQuqF");
    bool xgfOdADM = false;
    bool YIlUsBMdbbMY = false;

    if (YIlUsBMdbbMY == false) {
        for (int HDskXjn = 1581104154; HDskXjn > 0; HDskXjn--) {
            CxWoSIJKR = NTWUFHJbzzEtDv;
        }
    }

    for (int vzAanKlEc = 1881816549; vzAanKlEc > 0; vzAanKlEc--) {
        GkkEEvSySmEeVYN = QRbaYbshCQ;
        QRbaYbshCQ = ! YIlUsBMdbbMY;
    }

    return eLcuVhEpRaadyK;
}

xYcHY::xYcHY()
{
    this->mgmeHEzbJLbCKEF(92096811, -1807801652);
    this->sgWWXHpdsCMieVoZ(919825.7814823898, true, -1632742989);
    this->UoivmoaFdUugxde(false, 1802207878, 691322.3361537766, true, -777852.1733421609);
    this->nqejNUduJteE(1468659042, string("piZqjWndzvPD"), true);
    this->aacVRasxhAWBEI(1701391756, -583650.1478581394);
    this->xOBNLqpkXl(string("OtCwWQGqGKarOxwthJevjvJhtbyCwJzUHlCbgDWfrENePjkCLuzWgxNiPKAMnPVMgYunyN"), true);
    this->XdnlPHq();
    this->rgzTriWNAAR(-1646296603, true);
    this->kUdAxcdPeLwFk(-581902.593254902, 128818.53873786455, -1858664879, 1362332423);
    this->vHguthQu();
    this->xEaIVqVVUgVMFV(537357330, -306618572, false, 563169.5553025001, string("poyTjhYFRklmoYGJLFJhZYpGSJcAKxZaLtWqfMMbihoBMwSDekuNzumFlLfGaRhCttzbLMpueUwdpWwRsgEcuiBHqzFFPpOxePCPPftqQKXzyLJvYvEBDWnyCSegjHKzKoSmohJzUXpFGJdyagoIFESHakfyVJOmQfyvqCWtnnjQMpDJRhJtTVwhklZbTQshTHbKPUpWUuTlsqhcuRkFdFOolKrWPhmvsyhRAVuslGykTrENwcLzjXPYg"));
    this->LVYuTpwHlT(-1867714889, true, -816689.3516014921, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QXtENRhGqqA
{
public:
    bool ieHQfggZsl;
    string QkuBhnkvh;
    string AaRMmCvuuFPlnEt;

    QXtENRhGqqA();
    double dAfVGaBrB(double uUIiaJonxaooAL, double DIFScLpgWxDP, int wsZtz, bool CWEha, double sdPdSMluHY);
protected:
    double IRoDUCkmZo;
    bool wgbBComxlyXsux;
    int cskhSoEFRSgrL;
    double AAaou;
    double ThyQFQrldS;

private:
    string PNVwWzy;

    double WmXuyjet(double yLnEibPB, bool SGeVQv, bool dVNWxVB, int xiVWHI);
    int mgoHuTj();
    bool JRGjaxJyGOlzCh(bool RLHBRLPHlMPCjl);
};

double QXtENRhGqqA::dAfVGaBrB(double uUIiaJonxaooAL, double DIFScLpgWxDP, int wsZtz, bool CWEha, double sdPdSMluHY)
{
    string PbncFsheawwjnjrw = string("BpsSglWffAUPHFbVynXBLbWjhLkFLnnKsPcaSYwIEFJlRSbkHRDmYoaseOpLuPzBUQqdLDSBkpluUyJntPeVbFtXdeH");

    for (int NJXUR = 2123780428; NJXUR > 0; NJXUR--) {
        DIFScLpgWxDP -= uUIiaJonxaooAL;
        uUIiaJonxaooAL += sdPdSMluHY;
        sdPdSMluHY *= uUIiaJonxaooAL;
    }

    for (int HpecrDXjOLVCD = 792452229; HpecrDXjOLVCD > 0; HpecrDXjOLVCD--) {
        continue;
    }

    if (wsZtz < 1294272651) {
        for (int wbrgEA = 2112979022; wbrgEA > 0; wbrgEA--) {
            sdPdSMluHY = DIFScLpgWxDP;
            DIFScLpgWxDP /= uUIiaJonxaooAL;
            DIFScLpgWxDP = sdPdSMluHY;
            sdPdSMluHY *= uUIiaJonxaooAL;
        }
    }

    if (sdPdSMluHY >= 360711.8384235828) {
        for (int qDWwUKXyu = 1004795139; qDWwUKXyu > 0; qDWwUKXyu--) {
            continue;
        }
    }

    for (int mXZyvkDyN = 41962603; mXZyvkDyN > 0; mXZyvkDyN--) {
        continue;
    }

    return sdPdSMluHY;
}

double QXtENRhGqqA::WmXuyjet(double yLnEibPB, bool SGeVQv, bool dVNWxVB, int xiVWHI)
{
    string pFzDjSgPRgQopM = string("HwumRfGMhpZmxMeNNwledqLWloZzHcbpcgmAdrSpzczNerfvdXLzCUYLePUCSTqEWxBKNyLLFZSTvAiLPuZcFCrLXTvOGvdtivxzE");
    string oQjVM = string("qdgQuQepyRrYizBknKlypuEJnZFWunKfUnsDFsbBNa");
    string LTZBL = string("EyPseCAwCbktIeywGpviFVkSJBRETYduHaaxGiwolFQbLeuNLbGudJoUiUsXjZPVsFuGrfZeIXefiBwpVJkMdFXLvguZabOOjOUUXcDqgjNGWGTLafvAjRNyjkojdUKPyuRFNdZimJiMfzWIddrQhAKhzaPGRcXNDHmsezaZGmaFulpKMKmGZ");
    double mdkLHaEncCO = 989036.3141511803;

    for (int AkfYTGEjMBDSD = 778524966; AkfYTGEjMBDSD > 0; AkfYTGEjMBDSD--) {
        dVNWxVB = dVNWxVB;
    }

    if (SGeVQv != false) {
        for (int HAVOObI = 62185255; HAVOObI > 0; HAVOObI--) {
            mdkLHaEncCO *= mdkLHaEncCO;
        }
    }

    for (int eUxFZDcC = 487681983; eUxFZDcC > 0; eUxFZDcC--) {
        yLnEibPB /= yLnEibPB;
    }

    for (int PRwfLlCMmzGsoji = 1165626597; PRwfLlCMmzGsoji > 0; PRwfLlCMmzGsoji--) {
        pFzDjSgPRgQopM = LTZBL;
    }

    for (int RsThHUT = 2126942676; RsThHUT > 0; RsThHUT--) {
        dVNWxVB = dVNWxVB;
    }

    if (oQjVM <= string("HwumRfGMhpZmxMeNNwledqLWloZzHcbpcgmAdrSpzczNerfvdXLzCUYLePUCSTqEWxBKNyLLFZSTvAiLPuZcFCrLXTvOGvdtivxzE")) {
        for (int RUNKFyDOsHvx = 1232900276; RUNKFyDOsHvx > 0; RUNKFyDOsHvx--) {
            yLnEibPB = mdkLHaEncCO;
            LTZBL = LTZBL;
            xiVWHI /= xiVWHI;
        }
    }

    return mdkLHaEncCO;
}

int QXtENRhGqqA::mgoHuTj()
{
    bool EXSYHfbrmxEyetJq = true;
    bool DmDqgNCXgsqlzjr = true;
    bool xmiTTWRpm = false;
    string dKFiQunjLEB = string("tPFMhTwInLgHuMJEfNGQCZXaXbVPmqnedpjUOuAHhyEfqXrbzppbmQsaLaAejqmKqqTbDkEfcycyemtYbcglhKvTqeABLLmctkAgGvHXlHyRZJLdKzpvynKzFEZTXHEFBbFoIiefkUHdpci");
    string tnMmDpPHDKAY = string("DKWEzyKGnIcHfdDGnXNIeVdXSeHZAYnCyhIsWfaKrLetuHOLJNXLWqkrvqhIMXzPAwUNXoiywUDNafNclZXZWrNOyESzKgxFFroGUCwcsFgYLMKqPmdZDfts");
    bool WWOvLxItTvXPhhoM = false;
    string dHRDObfrr = string("yROOZULBFdoWhyUgfxBgMRLBZVxyZVqlTPfEdKrAFWpXrNXRwDcqWnXorRjlKmwIrAasXENepgSIEvUKFmoQZuMVPJrTZdCysMIjlwaxNnREPQhYThnrriNwsRCxnlLZaUHCRNFJKFunNkwsgYeWxbSFwYfcyUUplHunsmUEHPopMqFpLHYGjtAbxgNzHqzDKewAHcdznTQGtzmBmFHsEtRWBoctTPsSOLBD");

    for (int rHoqKLtmeiZIP = 1830859098; rHoqKLtmeiZIP > 0; rHoqKLtmeiZIP--) {
        dHRDObfrr += dHRDObfrr;
        DmDqgNCXgsqlzjr = ! WWOvLxItTvXPhhoM;
    }

    for (int dGmKtZCKSLwlRDa = 137310912; dGmKtZCKSLwlRDa > 0; dGmKtZCKSLwlRDa--) {
        xmiTTWRpm = ! WWOvLxItTvXPhhoM;
        xmiTTWRpm = ! xmiTTWRpm;
    }

    if (dKFiQunjLEB < string("yROOZULBFdoWhyUgfxBgMRLBZVxyZVqlTPfEdKrAFWpXrNXRwDcqWnXorRjlKmwIrAasXENepgSIEvUKFmoQZuMVPJrTZdCysMIjlwaxNnREPQhYThnrriNwsRCxnlLZaUHCRNFJKFunNkwsgYeWxbSFwYfcyUUplHunsmUEHPopMqFpLHYGjtAbxgNzHqzDKewAHcdznTQGtzmBmFHsEtRWBoctTPsSOLBD")) {
        for (int EMWnty = 1209909887; EMWnty > 0; EMWnty--) {
            xmiTTWRpm = ! xmiTTWRpm;
            WWOvLxItTvXPhhoM = WWOvLxItTvXPhhoM;
        }
    }

    if (xmiTTWRpm != true) {
        for (int KCkOnkIANtw = 157862306; KCkOnkIANtw > 0; KCkOnkIANtw--) {
            dKFiQunjLEB += dKFiQunjLEB;
            xmiTTWRpm = ! WWOvLxItTvXPhhoM;
            xmiTTWRpm = DmDqgNCXgsqlzjr;
            tnMmDpPHDKAY += dHRDObfrr;
        }
    }

    return -1224373997;
}

bool QXtENRhGqqA::JRGjaxJyGOlzCh(bool RLHBRLPHlMPCjl)
{
    int OGXzxAUDofX = 1665898194;
    string vUSXT = string("FBrvPbHKkRslhzRVissaymnheNjXacylSKQKvpovuIbxYrhALSdAXwYygnAttAvwWsxuhGMkMgiKiCIkYrOnWThhBRfSdXJChoUGGjGvgZOchDrQtwYmNfxfmbmCDJWvhqXcCclyyFHJIbZKuLQjiAqtl");
    int dPlzaMCauKaT = 400124599;
    string YqvPmeMVaRalQ = string("kGgXbxTVpSRUNpnmmNYbCcTlAsStRmluqxXsHqOBFdRtsHAcTmecwgQbwWxeExlvuEshymALKWgqMmQYkzcDvSXrXUFnbkugjTmslXcWbUjxLwamhjTOFMRhqRTZdjusgWLBUQQLozbpxkgmiJxehCLxUBQoCixHbYAaWQkIGwkZXVvzrlE");
    bool EJAESZSpYcnvf = false;
    int TBxCCHV = 21617232;
    bool LrNGZmr = false;
    double YUWrglyKLOEwHkrN = 587246.9893366597;

    for (int wJrBAfKfKwin = 1297255531; wJrBAfKfKwin > 0; wJrBAfKfKwin--) {
        LrNGZmr = ! EJAESZSpYcnvf;
    }

    return LrNGZmr;
}

QXtENRhGqqA::QXtENRhGqqA()
{
    this->dAfVGaBrB(360711.8384235828, -248396.59049021278, 1294272651, false, 229191.5262318357);
    this->WmXuyjet(127044.36943634652, false, true, -706754532);
    this->mgoHuTj();
    this->JRGjaxJyGOlzCh(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jLcBaTTu
{
public:
    double msncCZDiefVK;
    double TxhXFixguhWyVoQ;
    int PATfanyhoIX;

    jLcBaTTu();
    int lsbIHfiG();
    string yzMlj(int vxJIGanxd, int bLvLdJ, int iOcQiMD, int jJbNVwkWoqZoNSWd, double AOHGVylbv);
    void IUoYStcoUZCVyj(int VtHHSb, double xIBGlD, bool wIVSUBFpz);
protected:
    bool iRNopwBdwBDHC;
    string hliOLKjasXyWucQM;
    double zcnTP;
    double lbmXxQFAousIpi;
    bool gqSrIso;

    double jmzZiCfDsSDtF(double RniHXzMbAjpI);
    void CWTCwAAxnQOQTjZ(string HdjoIzYCxGn, string tnvJhWDxpGhFFyzE);
    void ZUBDuuvttqA(bool CHAwfq);
    bool soMEIPaebiujfo(string ZCUvlXEBrG, bool FcAsPfN);
private:
    double aVKZybaIwQg;
    string ifOau;
    string XQUQXX;
    int cWnwbykyfvcdtYK;
    string yaPawe;

    int HGrQzD(double ObBfFYWac);
};

int jLcBaTTu::lsbIHfiG()
{
    double oDzzMDAKLemgu = 1030925.8125056004;
    double yxRaGpdyTT = -518879.2631347773;
    string ldIAqtPP = string("iYdSuTTdzNaKmtnSvxXuTdJgXTeOBveJWybWdvCaWMIAkfPGwGCoWilAEtWLQthHdgoHVDTOvNyLWyUtQhfyeCagqQLZsK");
    bool urNbovxy = true;
    bool ZNJZznBF = false;
    int JuubjssEAzNmy = 1776219655;

    if (yxRaGpdyTT >= -518879.2631347773) {
        for (int kWjZVqYyWJNr = 317876342; kWjZVqYyWJNr > 0; kWjZVqYyWJNr--) {
            ZNJZznBF = urNbovxy;
        }
    }

    if (ldIAqtPP != string("iYdSuTTdzNaKmtnSvxXuTdJgXTeOBveJWybWdvCaWMIAkfPGwGCoWilAEtWLQthHdgoHVDTOvNyLWyUtQhfyeCagqQLZsK")) {
        for (int fhPbPAvsUJOIk = 357596366; fhPbPAvsUJOIk > 0; fhPbPAvsUJOIk--) {
            continue;
        }
    }

    return JuubjssEAzNmy;
}

string jLcBaTTu::yzMlj(int vxJIGanxd, int bLvLdJ, int iOcQiMD, int jJbNVwkWoqZoNSWd, double AOHGVylbv)
{
    int CDpkKuie = -1604307926;
    string FQtwuRkzOEzO = string("wvFWOtpfoQOqBxsHCoBZvBpUKuliOQswuciCPkjvtgaOmYFgyOPZJP");
    int pyrFNuNztjvrRwbF = 444689653;
    string oXnJIOZP = string("jUPtipqMJaMnMmaMWCwzSVZpaHBWYPWhOlrLkKFREVbnHqbniKQpLernmT");
    double aZgoemRlwnMWXNJ = -650883.2440941605;
    string ttwvPBBfBZj = string("SWMTvFOgGHDsop");
    string XBqyhdvYvi = string("YWAmHtTsWPWiWyzxAiqRRKClOLlvfzkhhFIzmpGLUxnBktvgqlBNWmRGMoNsFKhHyZUTtECeLVYylwSEUZOmUuAKGvLiugdVduzeWqJSqUeurcFPnkvzEZuOvBwvlTAfzCmzpffwDvlwnzHi");

    if (aZgoemRlwnMWXNJ >= -771586.4593957735) {
        for (int gjSShDsMuqaIT = 123649047; gjSShDsMuqaIT > 0; gjSShDsMuqaIT--) {
            CDpkKuie -= bLvLdJ;
            aZgoemRlwnMWXNJ -= AOHGVylbv;
            jJbNVwkWoqZoNSWd += iOcQiMD;
            pyrFNuNztjvrRwbF *= vxJIGanxd;
            vxJIGanxd -= pyrFNuNztjvrRwbF;
        }
    }

    if (CDpkKuie < 444689653) {
        for (int dXvMAA = 1170471894; dXvMAA > 0; dXvMAA--) {
            vxJIGanxd *= jJbNVwkWoqZoNSWd;
            AOHGVylbv *= AOHGVylbv;
            FQtwuRkzOEzO = XBqyhdvYvi;
            jJbNVwkWoqZoNSWd /= pyrFNuNztjvrRwbF;
            pyrFNuNztjvrRwbF += pyrFNuNztjvrRwbF;
        }
    }

    return XBqyhdvYvi;
}

void jLcBaTTu::IUoYStcoUZCVyj(int VtHHSb, double xIBGlD, bool wIVSUBFpz)
{
    int QpdIUZdrBVVuB = 1539142867;
    double GkuwF = -89829.95312108484;
    double oCbhD = -885481.432376987;
    bool AlrSIgFJaEyME = false;
    bool tlsLXjDnqkMzAjf = false;

    for (int hYYdKVptFsRvAY = 1985136996; hYYdKVptFsRvAY > 0; hYYdKVptFsRvAY--) {
        continue;
    }

    for (int IpytsTeFA = 308648361; IpytsTeFA > 0; IpytsTeFA--) {
        wIVSUBFpz = ! tlsLXjDnqkMzAjf;
        tlsLXjDnqkMzAjf = ! AlrSIgFJaEyME;
    }

    for (int KRcHrkOpUxv = 1734797147; KRcHrkOpUxv > 0; KRcHrkOpUxv--) {
        xIBGlD = oCbhD;
        AlrSIgFJaEyME = ! tlsLXjDnqkMzAjf;
        tlsLXjDnqkMzAjf = AlrSIgFJaEyME;
    }
}

double jLcBaTTu::jmzZiCfDsSDtF(double RniHXzMbAjpI)
{
    int WqmNws = 2100269806;
    string klWUgljQRruhUu = string("lwvsPrunjrQhHLzhuKcbMxgoZSWdUwwrspfPMfIthwCUIxaXcsyDerpZIGWYaHGeWDwZwXbpgxRspgirQAvOwlYfUbvFHbEgFfWyKJtVXawhzaIXSJfCgVIfRBoXywOfcCrAWvgIRLeZVihzUcwJ");
    string sABIVlZl = string("NjedzNaHLJpsIrDBbzpeaawkxsYXfJUXVTSRiQBFnIDXRxyPiiAKUERkPJwdzpqk");
    string AcxvzKiZQLaP = string("TduMKlEQlipPVlHDwpPCeuvKmMQqHnpwXkWEeSwnFTbFOqTpLucPucdLQjtupIWUlRdHBWUnTaVhVCwivCBfATlhGoGUObaWNiJdDWJpbIJPgNrYtKQMALcWdhiSGulJMNaYwGOxyjVEnKUfIWokRPbBARHoMHfkKsLPnssjKKirlyYGhAbPepzdVlPIkvZUUHqrqHPqrlgNJiVuIYZcFOxccFIbQuL");
    double oLfop = -914886.2809404028;
    int GUUWhEl = 140875064;
    string NQzJdvQ = string("fQbsFGvGwsvXTRPmmyhRAd");
    string aQPzE = string("QMHkEkjqeCXLgoeriiJRtWFDKOrgZWssymIfRbLfrwnNDETjzanEHrxDbSjBQO");
    int MdhgjyMkaIa = -1435414903;

    for (int drlrmGvUtre = 1898965751; drlrmGvUtre > 0; drlrmGvUtre--) {
        continue;
    }

    return oLfop;
}

void jLcBaTTu::CWTCwAAxnQOQTjZ(string HdjoIzYCxGn, string tnvJhWDxpGhFFyzE)
{
    string KTaCB = string("RyFQyhiivpJIgbqCVvAfyYDGzGFSuEVpKdaLqRoVQxigoMoSemPgVcfgaTHwBzXdnnXqbrxJEEEjUjWAxMmxaXtebNZkEqg");
}

void jLcBaTTu::ZUBDuuvttqA(bool CHAwfq)
{
    int tBneMuUDysii = 795552592;
    int ElUccCgQhdbENZ = 2009613189;
    double tVsZHqW = 711854.6105788612;
    string vmjvY = string("AsvlMALucnETMrLFzyj");

    for (int wdvGPSnhgscMOGtM = 520152116; wdvGPSnhgscMOGtM > 0; wdvGPSnhgscMOGtM--) {
        tBneMuUDysii *= tBneMuUDysii;
        tBneMuUDysii -= ElUccCgQhdbENZ;
    }
}

bool jLcBaTTu::soMEIPaebiujfo(string ZCUvlXEBrG, bool FcAsPfN)
{
    string BmvSdcAS = string("QhhabFSUDNWjnIwbDsEXUJJDPeuLEWGjIOzgyCZNchbYhFMdhqcyhTbliGOjYIVtaCZnRESubAnlWQhyhAYNIzBXkhnpyvEEICTQQghvhes");
    double gbWvCnkTpt = 527754.2872104086;
    string ezelchSeazT = string("JOcCeWwjRSWktmmpIcfAGxeBmwnaZRJRMPYfXULWfBGJNvoxOJJARoqAUaizoZYRenjohPLBCroZbOGsWKMZPGaQpUjTjUktCUDjLKmSsAiNgKmNMrBfjSkzbDIIGDkwTdXhmkqFNvoScDvZeajXzDrVrvzVBZSYANfAHQveLKfnUvgmtxOBvfbOFFbXNXHxGaMVQHmewiEndSrBSBmuVywbJavjpzOAFgcuS");
    double WcoQVOyANc = -490598.90136076947;

    if (ezelchSeazT < string("twJcXHwhQenpxPUiwbDolxECNBgQJAMMxzYUuJWyFNOUnQOzTUXsNWhQBFOuWChjkliyGbYGfuKOFTDGLyLIaEaQRQZrV")) {
        for (int qGMtmZuU = 1084671748; qGMtmZuU > 0; qGMtmZuU--) {
            ZCUvlXEBrG = BmvSdcAS;
        }
    }

    return FcAsPfN;
}

int jLcBaTTu::HGrQzD(double ObBfFYWac)
{
    string ZDrAfsHAWt = string("AzSVcwjQwsApDJfTQhIGmVeKoNHqYjByulTnQJxfSMGjZplFzztQcxkIbLyFwtuYvJsXroxDypsYyIlpIjAxerKbEseInAZHRnpMoDIkaPQgjbURLRJNlmXrGnFSGJrBKyNZyKDfSslsyPWzoOmJjwoWNLdeWOuLEdwGHHVIeHrNSUJrfGGdCRzuclUzletEmAPkuKEfMaT");
    int ikbYP = -1300785282;

    for (int lnORYLxoOYDHjZfh = 697526532; lnORYLxoOYDHjZfh > 0; lnORYLxoOYDHjZfh--) {
        ikbYP -= ikbYP;
        ikbYP += ikbYP;
        ZDrAfsHAWt += ZDrAfsHAWt;
        ZDrAfsHAWt += ZDrAfsHAWt;
    }

    for (int fOLBBsD = 752886443; fOLBBsD > 0; fOLBBsD--) {
        ZDrAfsHAWt += ZDrAfsHAWt;
        ikbYP = ikbYP;
        ikbYP = ikbYP;
    }

    return ikbYP;
}

jLcBaTTu::jLcBaTTu()
{
    this->lsbIHfiG();
    this->yzMlj(1679540648, -1126044669, 1144584577, 1292495905, -771586.4593957735);
    this->IUoYStcoUZCVyj(332429599, -507271.62709081225, true);
    this->jmzZiCfDsSDtF(-1003439.5627089987);
    this->CWTCwAAxnQOQTjZ(string("JgeThlazwVsARpvaXiTVhNlgVxcgfPpUvxGWvQtdQmuTeOLVIDZZHdOuzxFpPdqwgBVRTwRONJHRqCdSoLpTbAORyogzCtHOXJlZJWEGAnCICFVHVKOBbKYSRvCCgoJkakcglCkTgojIiaTEVliJiCeTVKJFDhhQCYyecwomSuPtkzEgMIrwVuyWPIc"), string("xEkeVBXvOCpdbFjoxBvDqrlqEOgVJwkTZEBFuAYTYJwGSpdHROmqcoBauwmvqNhHXrjOOMrsBPIsurwnAxgeCMXMJuKtzRPYAffPpXPMkIztnplavVuXABXcSbATSAVjIkEhkEiqvKDdKptupPwRHKwCnFAGBTVqsohuYxdCsHOaSrHLzngdmpSWaBHjxvxIXHrQNYIrfpG"));
    this->ZUBDuuvttqA(false);
    this->soMEIPaebiujfo(string("twJcXHwhQenpxPUiwbDolxECNBgQJAMMxzYUuJWyFNOUnQOzTUXsNWhQBFOuWChjkliyGbYGfuKOFTDGLyLIaEaQRQZrV"), true);
    this->HGrQzD(-936445.3651457144);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VTEZvvQZJxZbiqK
{
public:
    int AVaSAKriBCq;
    int HOyDUkfAKjWE;
    bool LYUtbltQ;
    bool mhyDbxHtdF;
    bool HsxWYypouF;
    string EMXvEQPbynH;

    VTEZvvQZJxZbiqK();
    void YCtEHrEO(string HXuyRVXFoJcR, bool IYiloR);
    bool urplHsusNaaVRc(double qoCFSfX, int zCUHjZvNSSY, string tdlwt, bool TAcEjgODdrtTd, int pPyCgiYyuv);
    int vvnCpXjTLOo(int hxnpzG);
    string GTkLuE(double wOPLgXdiwxoZ, double ggWfJi, int UxGUIyw);
    double VHBSrhVVXZqZgY(bool xzJMjRBtX);
    double hHmYXj(double UaeOcZXEEm);
    double UDbUMizskw(string iMLhRXFfpyJGO, bool gQfdTOGWj, bool NQCcoECU, double uFxyI);
    bool qwpcQxjbUimsUpPf(string ZvAqXEvLYSJnWu, bool RcdZYVAMDXmbCxZ, int eCKBMH);
protected:
    int dBtGyrlld;
    int ikDtceCwoCzbKyFF;
    string qlhbpvHnY;
    bool XzkwCuiUyqUCojK;

    double yimcpCUdzq(bool EaXSo, int KqmzHERXrousKvMA);
    int gvUHq();
private:
    int xXdWUjV;
    int GLrrZyIzYnFnU;
    int kKxqiHcbRrR;
    int bJkymMTjERizfv;
    string NPWmBNOxbmt;

    int UsBuPnEDTjHaz(string eMtJNdDirEVA);
    double Omkzphy(string ikqRnLkHCZG, bool LZJJJDKTYbJ, string WagGxZlgdBvd, string QZRWNAcYSxC, string izUtdAbjHoQhfa);
    string YaUCobzMuneXbzIq(string ZxGbPwxVurTlO, double nmAdrjUTdc, bool TCgTilEUXnCV, string EEsHxNGrkMDy, double ldgsTCltQT);
    string oqnZkVVhChKcBtf(double XtzIpEPlLKq, string McHURrRUSYfKNesh, int zwBWmKB);
    double tKqpibFGs(int jgyXWfxZxTIhh, string NUUjCKCFdNTJFo, bool zjgSBfveLgynjfC, bool WEIYgSKMfidwbwVM);
    bool JXBNjzvSFZUVsEr(bool RDLCOtCOnYgKpIow, int tWAAKdlfUrdQg, double KjDLDiREjDixx);
};

void VTEZvvQZJxZbiqK::YCtEHrEO(string HXuyRVXFoJcR, bool IYiloR)
{
    double BlDaZDMUg = -1007551.9546314242;

    if (IYiloR != false) {
        for (int PSSSLauDTNPToN = 1720633992; PSSSLauDTNPToN > 0; PSSSLauDTNPToN--) {
            BlDaZDMUg += BlDaZDMUg;
        }
    }

    for (int AfJhe = 1862000833; AfJhe > 0; AfJhe--) {
        BlDaZDMUg -= BlDaZDMUg;
    }

    if (IYiloR != false) {
        for (int CeBspjfwWOqbEFI = 1898339751; CeBspjfwWOqbEFI > 0; CeBspjfwWOqbEFI--) {
            HXuyRVXFoJcR += HXuyRVXFoJcR;
        }
    }

    for (int KMBsmukfsUiz = 226350947; KMBsmukfsUiz > 0; KMBsmukfsUiz--) {
        IYiloR = IYiloR;
        HXuyRVXFoJcR += HXuyRVXFoJcR;
    }
}

bool VTEZvvQZJxZbiqK::urplHsusNaaVRc(double qoCFSfX, int zCUHjZvNSSY, string tdlwt, bool TAcEjgODdrtTd, int pPyCgiYyuv)
{
    double NzTEUfzBsLrS = -715048.1720938989;
    double WSkkG = 240212.22535768017;
    string GMgCsQCGSpqFpsgu = string("uwCOekSatECgJbGqIrSxCvDXhLgcDTKhAQDYZKZWfoiMEIeXvxTjQHGTbkGuHzkUjBUiazocXPBrjQcZCgoxbvqaCkRvbuNmYVydccyLfuvQRtnRsmsVjzppJzbCbkAwsfaPEXArt");
    string OhimWacRLvGht = string("jILhWwQsrsGCZIlpkYtaumLahLmdZpkoRMAkFonSMDqGsyxJhCjUyAhfvHRYueyIbhPHGzkDJJiGLGXsQPAAofZNdiriAjyDbPQgsPbAyORZmFoumgUhgzyCueBUXUaKFnPvhsjGiUzPCltRQGxeZGSRHGVcFyYAcSSrkLJyJoVNfnGU");
    double wyZituwVNIAJ = -355865.3824612883;
    double OCnokzmQAMtxhWQ = 452286.46412765526;
    int ueCznkdgpAxcmT = 960511794;
    string LuGghHPD = string("MMhWYDNCXpELHwsGrvLHNCnBgqCCPUdsdwtjVMjbEaSuaZGSTTXzRIFYcRxJmOlUmaMvdLaRHEqLJnztyKukHiLwruKcVheoIANuaxGwQ");
    bool JJoMtY = false;
    double mbJOtv = -485156.1077414788;

    for (int taCcB = 419347831; taCcB > 0; taCcB--) {
        ueCznkdgpAxcmT += pPyCgiYyuv;
    }

    for (int nFTET = 1898005103; nFTET > 0; nFTET--) {
        NzTEUfzBsLrS += WSkkG;
        wyZituwVNIAJ = wyZituwVNIAJ;
        OCnokzmQAMtxhWQ -= OCnokzmQAMtxhWQ;
        NzTEUfzBsLrS += WSkkG;
    }

    for (int WuptyfihhLdhSuTJ = 1170792591; WuptyfihhLdhSuTJ > 0; WuptyfihhLdhSuTJ--) {
        GMgCsQCGSpqFpsgu = LuGghHPD;
        OCnokzmQAMtxhWQ *= mbJOtv;
    }

    return JJoMtY;
}

int VTEZvvQZJxZbiqK::vvnCpXjTLOo(int hxnpzG)
{
    int TFhLmayOBLx = -679799450;
    string MEeUmULVMj = string("cKHXKxaj");
    bool PazluhM = false;

    for (int GJUuqdW = 968010313; GJUuqdW > 0; GJUuqdW--) {
        hxnpzG /= TFhLmayOBLx;
    }

    if (TFhLmayOBLx == -679799450) {
        for (int rTReJNF = 1728181075; rTReJNF > 0; rTReJNF--) {
            PazluhM = PazluhM;
            hxnpzG *= hxnpzG;
        }
    }

    for (int vwaXRU = 655243037; vwaXRU > 0; vwaXRU--) {
        TFhLmayOBLx *= TFhLmayOBLx;
        TFhLmayOBLx = TFhLmayOBLx;
        hxnpzG *= TFhLmayOBLx;
    }

    if (hxnpzG <= -679799450) {
        for (int BRyurE = 99266926; BRyurE > 0; BRyurE--) {
            hxnpzG *= hxnpzG;
            TFhLmayOBLx = hxnpzG;
        }
    }

    if (hxnpzG != 623990311) {
        for (int KdSrnYsOfmtk = 1865906925; KdSrnYsOfmtk > 0; KdSrnYsOfmtk--) {
            PazluhM = ! PazluhM;
            hxnpzG *= hxnpzG;
        }
    }

    for (int LCIdcIXBZfUrQao = 2126392777; LCIdcIXBZfUrQao > 0; LCIdcIXBZfUrQao--) {
        TFhLmayOBLx = TFhLmayOBLx;
        TFhLmayOBLx /= hxnpzG;
        TFhLmayOBLx -= hxnpzG;
        MEeUmULVMj = MEeUmULVMj;
    }

    if (hxnpzG >= 623990311) {
        for (int wGUBBPgKkyAmqeZW = 1527443266; wGUBBPgKkyAmqeZW > 0; wGUBBPgKkyAmqeZW--) {
            MEeUmULVMj = MEeUmULVMj;
            hxnpzG += TFhLmayOBLx;
        }
    }

    return TFhLmayOBLx;
}

string VTEZvvQZJxZbiqK::GTkLuE(double wOPLgXdiwxoZ, double ggWfJi, int UxGUIyw)
{
    string XJCaitChXV = string("ZCjfgfzupgwLxWbHuCpt");
    bool FKLXtyPw = false;
    string akuNVoEi = string("laZTvfuGnWFwaeRvZrEiQeOJwNpUTkPAFswXBkMUODCsEyFWautkwgnWpRkZDFFSCflLQYAiqlMJOpeTdMLJPsalTXJHrmpPfyPKAouCruOMkVGZprRkEqlxMXEAqGlfORmMYMTZbzmXokZlMyruLHjqqQmRoSrnrcsMUCqJbyqDgpQeHBOuVrHhkcNfDDESSNOPodlTqLYKYkQTrHNsuZROvWCMVdKDMapACGfThfxzKuhGogVRuG");
    bool jcBhroX = false;
    bool XultBaecixZPr = false;
    bool TsrGeANbdAQ = false;
    double BLKODOsQUTPkNwNT = -650681.9747765188;

    for (int EqIfFBw = 495359032; EqIfFBw > 0; EqIfFBw--) {
        BLKODOsQUTPkNwNT /= ggWfJi;
        wOPLgXdiwxoZ -= wOPLgXdiwxoZ;
    }

    if (XultBaecixZPr == false) {
        for (int naXzNZBSoKXmwOB = 336039026; naXzNZBSoKXmwOB > 0; naXzNZBSoKXmwOB--) {
            BLKODOsQUTPkNwNT += wOPLgXdiwxoZ;
            ggWfJi /= wOPLgXdiwxoZ;
        }
    }

    for (int aYxJsPKnXKojwA = 922330904; aYxJsPKnXKojwA > 0; aYxJsPKnXKojwA--) {
        continue;
    }

    for (int LHLEgKDfAbaPP = 1037925206; LHLEgKDfAbaPP > 0; LHLEgKDfAbaPP--) {
        jcBhroX = ! TsrGeANbdAQ;
        BLKODOsQUTPkNwNT += ggWfJi;
    }

    for (int regKtluE = 1499446759; regKtluE > 0; regKtluE--) {
        akuNVoEi += XJCaitChXV;
        BLKODOsQUTPkNwNT -= BLKODOsQUTPkNwNT;
        akuNVoEi += akuNVoEi;
    }

    return akuNVoEi;
}

double VTEZvvQZJxZbiqK::VHBSrhVVXZqZgY(bool xzJMjRBtX)
{
    int UEaNzFFBYGjZDNp = -2071216668;
    bool sXAQmSXTwdcxbuvy = true;

    if (UEaNzFFBYGjZDNp <= -2071216668) {
        for (int vTccuZACdBT = 683989770; vTccuZACdBT > 0; vTccuZACdBT--) {
            sXAQmSXTwdcxbuvy = ! xzJMjRBtX;
            xzJMjRBtX = ! sXAQmSXTwdcxbuvy;
            sXAQmSXTwdcxbuvy = xzJMjRBtX;
        }
    }

    return -579440.161224996;
}

double VTEZvvQZJxZbiqK::hHmYXj(double UaeOcZXEEm)
{
    string ChDQNDWWfBXcoOa = string("KmpvriosWEOQRNSTcuJKTkUKdymPAMdFwMFoXBHmjIyufYkBzvdhCrqPnnGzZrATHaDRVdPlKVnLypKIhRTytmSfQTNQXnPlIukUDHlXSKRGyjAyUTkahLRitoFMIbYYTnJHrJHhHGRILkiXrpKVzvWCjPGksbymgIs");
    int bfPIFgQjTBNplbj = -509132227;
    double TyXWZ = 603780.7248098534;

    for (int usukeIbHfUfzJ = 1701795465; usukeIbHfUfzJ > 0; usukeIbHfUfzJ--) {
        UaeOcZXEEm += TyXWZ;
    }

    for (int vIVxym = 1870527331; vIVxym > 0; vIVxym--) {
        bfPIFgQjTBNplbj -= bfPIFgQjTBNplbj;
        UaeOcZXEEm = TyXWZ;
    }

    if (TyXWZ != 603780.7248098534) {
        for (int QvgFqLejNClN = 1636186208; QvgFqLejNClN > 0; QvgFqLejNClN--) {
            UaeOcZXEEm *= TyXWZ;
            UaeOcZXEEm = TyXWZ;
        }
    }

    if (TyXWZ > 603780.7248098534) {
        for (int zuttWZpaf = 1554105759; zuttWZpaf > 0; zuttWZpaf--) {
            continue;
        }
    }

    return TyXWZ;
}

double VTEZvvQZJxZbiqK::UDbUMizskw(string iMLhRXFfpyJGO, bool gQfdTOGWj, bool NQCcoECU, double uFxyI)
{
    string AsJEnX = string("mRONeJgaeeyktLEDcGFYKglkzBlAyZLoXUFyAISfURacIkWtCgsmJLEOWezPxwKIvfkFTOIPiJwEYchWhfqOXuqRSbJfXdymMCswWYnGKJPTPzPItCZpzhmfZDNgmLroXQBnGgSxwkraLfsrPHwUNRBTefTiFdKfjdaADQyNIjNeHYkmUTOOezEFTjEhTxwfoSqxeZZHdHJIewcPjUESJfPK");
    int MBpMIP = 2049825523;
    int dFFNHBIvyOis = 934903659;
    double DCCQIKfFbJXzK = 619814.0479338532;
    string FrTRIpV = string("NBnDkBaCnALkLeuvcjNYTyavNjrLGNQmQnJcLdrfawyhbeIPMNayIWfjf");
    string zNpwqiznxMavLFQu = string("pQaAdZhBVeEDjsHGTdalSyrJFJYERInWbRthTRvHjCAAxMueiqEbSoLAKwMCRafyQqeVFViMZhIgZAqXUEpNjqVnqQOUfPaAKVhZOStcknrxsgLPHZqHEBqvqkRylONMHiTJWXvITNLuooEDojdtGMsGhFJytlveNVNbxlgdfNNlxPQevBfifCrweBecVPlHfzNtwsrpuseioDVxXehEKmhBdnKKZAUAiwexWIRaiPaXvEqTdJUWLpbnabUcgxM");
    double GpbyDLikxvLOtLr = -567602.4746452217;
    string iHuvYDxKjufL = string("fDvUqFGg");
    double jWptab = 877517.5746693725;

    if (NQCcoECU == true) {
        for (int dxdrYiPUX = 2045735974; dxdrYiPUX > 0; dxdrYiPUX--) {
            iHuvYDxKjufL = AsJEnX;
            MBpMIP += dFFNHBIvyOis;
            jWptab += jWptab;
        }
    }

    for (int uMTyPrTmZpxxc = 72205497; uMTyPrTmZpxxc > 0; uMTyPrTmZpxxc--) {
        continue;
    }

    return jWptab;
}

bool VTEZvvQZJxZbiqK::qwpcQxjbUimsUpPf(string ZvAqXEvLYSJnWu, bool RcdZYVAMDXmbCxZ, int eCKBMH)
{
    bool MmDkrWQe = false;
    bool nocHB = true;
    bool OmUDH = true;
    double FZFCAHRuCqZum = 751566.4517004333;
    string DEDTHcTK = string("SrnOnwsXiwXsKVBbCXlWbYtnXPDGEImypVYKLfWBgcRmlqTXHWFbeHnvmWbqqoVmZOyWgStOgRlhcKBH");

    if (RcdZYVAMDXmbCxZ != false) {
        for (int IJmvDwo = 462213304; IJmvDwo > 0; IJmvDwo--) {
            eCKBMH += eCKBMH;
        }
    }

    for (int xhQRBLd = 1282660189; xhQRBLd > 0; xhQRBLd--) {
        MmDkrWQe = ! RcdZYVAMDXmbCxZ;
        nocHB = MmDkrWQe;
    }

    return OmUDH;
}

double VTEZvvQZJxZbiqK::yimcpCUdzq(bool EaXSo, int KqmzHERXrousKvMA)
{
    bool Tbxxr = false;

    if (KqmzHERXrousKvMA != 8308910) {
        for (int zmdzFmxVHR = 1516061008; zmdzFmxVHR > 0; zmdzFmxVHR--) {
            Tbxxr = ! EaXSo;
            Tbxxr = ! Tbxxr;
            Tbxxr = EaXSo;
        }
    }

    for (int OeWdgxLgFrBMiXT = 613396868; OeWdgxLgFrBMiXT > 0; OeWdgxLgFrBMiXT--) {
        Tbxxr = ! Tbxxr;
        Tbxxr = ! Tbxxr;
        EaXSo = Tbxxr;
        Tbxxr = ! EaXSo;
    }

    for (int VkbINnFXmjCqfy = 1826546527; VkbINnFXmjCqfy > 0; VkbINnFXmjCqfy--) {
        Tbxxr = Tbxxr;
        EaXSo = Tbxxr;
        Tbxxr = ! Tbxxr;
        EaXSo = EaXSo;
        EaXSo = EaXSo;
    }

    for (int CCBukRvKbA = 699871610; CCBukRvKbA > 0; CCBukRvKbA--) {
        EaXSo = ! EaXSo;
        EaXSo = ! EaXSo;
    }

    return 814272.8870956956;
}

int VTEZvvQZJxZbiqK::gvUHq()
{
    int WnixrOFTvBQK = 862626730;
    string eXrWUh = string("Ha");
    bool xjRTGhXKZb = false;
    bool ZttKUc = true;
    int paBGbfrxaSBOGSw = -1286803325;
    string gTsmejikYpDNCFq = string("FGjiLTvLSiDThwGdGrDZfEPlEUUxFqzvGXDERWGUHvqEcosaXfguaXQkFSwmNwENJFuHlXuPWnFSzATVIzCfESKQ");
    double OeRMYDTb = -936318.468938391;
    string EzCEiEoxsYEw = string("LgGMSBTkLVhqUxtPDPbZoicbtqHggBEIZrEjOREKduwZAkFvqWAlmDDmgpHDUxiEgrpXWivWRtbtOvlpKiDjwaKTSGPkzAobkUwFDHINFLuZgKtJGlbGbpAPtIFujQpHkwHuQHesEiLOYPyPvhtoEiiTcDslJcunPqGofSTfdKcHGfvJDGiureVDTokmF");

    for (int FqfPDa = 822495282; FqfPDa > 0; FqfPDa--) {
        EzCEiEoxsYEw += EzCEiEoxsYEw;
        ZttKUc = xjRTGhXKZb;
    }

    for (int HmThfPwhlxKgzi = 1634334229; HmThfPwhlxKgzi > 0; HmThfPwhlxKgzi--) {
        xjRTGhXKZb = ! xjRTGhXKZb;
        eXrWUh = EzCEiEoxsYEw;
    }

    for (int URnJj = 342409970; URnJj > 0; URnJj--) {
        EzCEiEoxsYEw = eXrWUh;
    }

    for (int RawwRaszNSm = 1097211414; RawwRaszNSm > 0; RawwRaszNSm--) {
        OeRMYDTb -= OeRMYDTb;
        paBGbfrxaSBOGSw *= WnixrOFTvBQK;
    }

    for (int CZfJsEZ = 2134617265; CZfJsEZ > 0; CZfJsEZ--) {
        WnixrOFTvBQK += paBGbfrxaSBOGSw;
    }

    return paBGbfrxaSBOGSw;
}

int VTEZvvQZJxZbiqK::UsBuPnEDTjHaz(string eMtJNdDirEVA)
{
    double vuIEzeE = -758067.8325448127;

    if (vuIEzeE <= -758067.8325448127) {
        for (int SgEDmf = 2076933110; SgEDmf > 0; SgEDmf--) {
            vuIEzeE = vuIEzeE;
        }
    }

    for (int MFVqGJSM = 1012828372; MFVqGJSM > 0; MFVqGJSM--) {
        eMtJNdDirEVA += eMtJNdDirEVA;
        vuIEzeE = vuIEzeE;
        vuIEzeE -= vuIEzeE;
        vuIEzeE *= vuIEzeE;
        eMtJNdDirEVA += eMtJNdDirEVA;
        vuIEzeE -= vuIEzeE;
    }

    for (int ehGNen = 66313005; ehGNen > 0; ehGNen--) {
        eMtJNdDirEVA = eMtJNdDirEVA;
        eMtJNdDirEVA = eMtJNdDirEVA;
        vuIEzeE = vuIEzeE;
        eMtJNdDirEVA = eMtJNdDirEVA;
        eMtJNdDirEVA += eMtJNdDirEVA;
    }

    return -2009681354;
}

double VTEZvvQZJxZbiqK::Omkzphy(string ikqRnLkHCZG, bool LZJJJDKTYbJ, string WagGxZlgdBvd, string QZRWNAcYSxC, string izUtdAbjHoQhfa)
{
    bool YhIauSNeB = false;
    string AZdDD = string("IpVzZTLfCWZQhigAdpSbQvfKsPWqwLwokWlAYfMijMVCvEskJcjhJrnAtCyLOlHOYKyAlYTBgKijCluKrtbzKQkreKmopUOecxtbJuOdTwsuRtdiLNOoLwCTCocTNKxZbnUjnXcohdXwZlaRlgUDaTEWLXXIOlkEIgEUcXQQznKaFURIziSnlFBGSUpGL");
    double iEEuPbpDghaxRP = 386692.43647855637;
    string imZUZRIcRRv = string("WpetHQjuVd");
    string YGtYShuH = string("HQCOogUMMpSjzMVrllIyuydKBvPsZUorApOKUUmzjtwykAjknDgeTAmEdAIEOBUQmNvhEGmhhpSOucEFUAFRwCKfaIjKFzDyRMKiOmlCCgqgmKXWSb");
    int SiwES = -1364881093;
    string cRKQeO = string("LLoDoiMxRTbekIBLerHLILtWsjZBxtqrIY");
    int pCLfEVKZjKYCOH = -476467627;
    string SHkWrJi = string("sHKxPAcJPVmShNwXRRISLLhnWEpZMHBhlNBARdOtcBhBsTPnuQQmapECwjjEnSZoQToBRATUKqNQrjJGtPXwmKefaCijcVxQiGMoMxYwRgXNDYRpogcOgIPTFFlDhOHFHIBDTJRfQyqyAFFzErulEKuRwHEgxS");

    if (QZRWNAcYSxC < string("KvIRykotqhElbaWbOIr")) {
        for (int eoBpLSJFQxlRsuKP = 2102964283; eoBpLSJFQxlRsuKP > 0; eoBpLSJFQxlRsuKP--) {
            continue;
        }
    }

    if (SHkWrJi < string("sHKxPAcJPVmShNwXRRISLLhnWEpZMHBhlNBARdOtcBhBsTPnuQQmapECwjjEnSZoQToBRATUKqNQrjJGtPXwmKefaCijcVxQiGMoMxYwRgXNDYRpogcOgIPTFFlDhOHFHIBDTJRfQyqyAFFzErulEKuRwHEgxS")) {
        for (int DmJULjbtLS = 446609051; DmJULjbtLS > 0; DmJULjbtLS--) {
            WagGxZlgdBvd = imZUZRIcRRv;
        }
    }

    if (YGtYShuH == string("iQGchTQoCFilZkmuFnJtbkEhCpgzeiDXCgDnnUKnbqOSVSMldTYuMqKLZkMuxxGEkZPgpyHBGMZ")) {
        for (int qliOnl = 38454340; qliOnl > 0; qliOnl--) {
            continue;
        }
    }

    if (ikqRnLkHCZG == string("iQGchTQoCFilZkmuFnJtbkEhCpgzeiDXCgDnnUKnbqOSVSMldTYuMqKLZkMuxxGEkZPgpyHBGMZ")) {
        for (int OLHDfkOvAgPhIAY = 908179592; OLHDfkOvAgPhIAY > 0; OLHDfkOvAgPhIAY--) {
            AZdDD += WagGxZlgdBvd;
            pCLfEVKZjKYCOH *= SiwES;
        }
    }

    return iEEuPbpDghaxRP;
}

string VTEZvvQZJxZbiqK::YaUCobzMuneXbzIq(string ZxGbPwxVurTlO, double nmAdrjUTdc, bool TCgTilEUXnCV, string EEsHxNGrkMDy, double ldgsTCltQT)
{
    string tmBWAsRMxDSbM = string("g");
    double mhwqYHNxzf = -55672.15234640349;
    double voDBGYUgnjNI = 984478.8179915413;
    int vmGesavcCmif = -967454769;

    for (int JvFjWIEaiHyzTS = 126537847; JvFjWIEaiHyzTS > 0; JvFjWIEaiHyzTS--) {
        continue;
    }

    for (int cmAdNxgHYXfXZ = 447913724; cmAdNxgHYXfXZ > 0; cmAdNxgHYXfXZ--) {
        ZxGbPwxVurTlO = tmBWAsRMxDSbM;
    }

    for (int TRwtgbhjA = 300788225; TRwtgbhjA > 0; TRwtgbhjA--) {
        EEsHxNGrkMDy += EEsHxNGrkMDy;
        tmBWAsRMxDSbM = ZxGbPwxVurTlO;
    }

    for (int jZvjRkeVDKl = 1239022229; jZvjRkeVDKl > 0; jZvjRkeVDKl--) {
        voDBGYUgnjNI += ldgsTCltQT;
    }

    return tmBWAsRMxDSbM;
}

string VTEZvvQZJxZbiqK::oqnZkVVhChKcBtf(double XtzIpEPlLKq, string McHURrRUSYfKNesh, int zwBWmKB)
{
    double WoesipzybRxH = -756525.7671145543;
    double FMSgVdst = 605027.0278243056;
    int RxFBVmptr = -396743311;
    string uovIlKoZq = string("IXgMIvTbUyLwNmIjxSXTFFddxiyZLwpEbpqDjJjecYhXZAhzqCIfNiejhPAvjjYqYfydjKePdICUHESPdZhylZkNoDqqdHyetmyhYYBylolUJEnrxTenLPiOhcvVHwEuXGdQdGnACXQVoodQQyzxtFTgYpwLGRerEhNqVUTNonjPtaQHxtdqsuFQPQOhAWGiKUmUSEmwumcXVN");
    double OxNefjSvzI = 472204.60637034866;
    double WgrBCRV = 495280.29779166286;
    double bfNWykFUb = -462752.48722804664;

    for (int YcsrDZWEG = 1482892317; YcsrDZWEG > 0; YcsrDZWEG--) {
        RxFBVmptr -= RxFBVmptr;
        bfNWykFUb *= OxNefjSvzI;
        OxNefjSvzI = WgrBCRV;
        OxNefjSvzI = WgrBCRV;
    }

    if (WoesipzybRxH > -462752.48722804664) {
        for (int GXgat = 1851300080; GXgat > 0; GXgat--) {
            OxNefjSvzI /= OxNefjSvzI;
            XtzIpEPlLKq /= bfNWykFUb;
        }
    }

    if (XtzIpEPlLKq > 472204.60637034866) {
        for (int SsyntzXPUzBw = 620391434; SsyntzXPUzBw > 0; SsyntzXPUzBw--) {
            FMSgVdst /= bfNWykFUb;
            XtzIpEPlLKq /= bfNWykFUb;
            WgrBCRV -= OxNefjSvzI;
            WgrBCRV += FMSgVdst;
        }
    }

    return uovIlKoZq;
}

double VTEZvvQZJxZbiqK::tKqpibFGs(int jgyXWfxZxTIhh, string NUUjCKCFdNTJFo, bool zjgSBfveLgynjfC, bool WEIYgSKMfidwbwVM)
{
    double INerlysCgqMkOP = -610716.1356412322;

    for (int pqUeRx = 552644688; pqUeRx > 0; pqUeRx--) {
        NUUjCKCFdNTJFo += NUUjCKCFdNTJFo;
    }

    for (int GkQjOyNemFbnUTKl = 2071411157; GkQjOyNemFbnUTKl > 0; GkQjOyNemFbnUTKl--) {
        NUUjCKCFdNTJFo += NUUjCKCFdNTJFo;
        WEIYgSKMfidwbwVM = ! zjgSBfveLgynjfC;
    }

    if (INerlysCgqMkOP <= -610716.1356412322) {
        for (int YZkhPxRzNirWtUdb = 1980377696; YZkhPxRzNirWtUdb > 0; YZkhPxRzNirWtUdb--) {
            WEIYgSKMfidwbwVM = ! zjgSBfveLgynjfC;
        }
    }

    return INerlysCgqMkOP;
}

bool VTEZvvQZJxZbiqK::JXBNjzvSFZUVsEr(bool RDLCOtCOnYgKpIow, int tWAAKdlfUrdQg, double KjDLDiREjDixx)
{
    double NfiamEOX = 137851.27738769047;
    double RhUmk = 28755.995549704243;
    string XZjGmxjMymfL = string("KPKlhJRbqDGsDZupCSeAuvYQHSadoDjxfSjkCOKKDrQUgcvHGotpdXBBgZnQcLcIJdsDBwBjdPaucbdinwJcLudfgntPBjceKilWLljYUsXtTPSpGtYipLcWlWasRLaTodsgKegaAgNTEOXvJwUxEwjMpIQpohHWnxAyQyvhlbdklLHCJH");
    int bhFocSKmrY = 1289561344;
    int yZTWeItwWUMXelMo = -1289993507;
    bool PHNjjJ = true;

    for (int fxUblnkjLJk = 980448181; fxUblnkjLJk > 0; fxUblnkjLJk--) {
        bhFocSKmrY *= tWAAKdlfUrdQg;
        RhUmk -= KjDLDiREjDixx;
        bhFocSKmrY += tWAAKdlfUrdQg;
        tWAAKdlfUrdQg *= tWAAKdlfUrdQg;
    }

    for (int nRfemToWGmPx = 1404104127; nRfemToWGmPx > 0; nRfemToWGmPx--) {
        tWAAKdlfUrdQg = yZTWeItwWUMXelMo;
    }

    if (KjDLDiREjDixx > 1012476.9271970901) {
        for (int EZfmDXUqKCG = 2007232997; EZfmDXUqKCG > 0; EZfmDXUqKCG--) {
            yZTWeItwWUMXelMo += tWAAKdlfUrdQg;
        }
    }

    if (XZjGmxjMymfL > string("KPKlhJRbqDGsDZupCSeAuvYQHSadoDjxfSjkCOKKDrQUgcvHGotpdXBBgZnQcLcIJdsDBwBjdPaucbdinwJcLudfgntPBjceKilWLljYUsXtTPSpGtYipLcWlWasRLaTodsgKegaAgNTEOXvJwUxEwjMpIQpohHWnxAyQyvhlbdklLHCJH")) {
        for (int ftwXRZiiPb = 294764471; ftwXRZiiPb > 0; ftwXRZiiPb--) {
            yZTWeItwWUMXelMo = bhFocSKmrY;
            tWAAKdlfUrdQg /= bhFocSKmrY;
        }
    }

    return PHNjjJ;
}

VTEZvvQZJxZbiqK::VTEZvvQZJxZbiqK()
{
    this->YCtEHrEO(string("UAaMVFcvPjDNVaSoHYaTZKgPqveFmhpxMvHWBkLfRmfGrihEK"), false);
    this->urplHsusNaaVRc(-874998.8251602947, 1725539370, string("rswtGcMWttlcgvuQAOLGXIxtMKFDMokNQwflerLUWgtKmPmZpGwzOBBqCKVBdtcVxrfjVeJsBUyAdiIhuRsenSbpZqlfZ"), true, -1125770207);
    this->vvnCpXjTLOo(623990311);
    this->GTkLuE(-564482.5572784462, 995440.8890275675, 1619609610);
    this->VHBSrhVVXZqZgY(false);
    this->hHmYXj(-925670.5757608915);
    this->UDbUMizskw(string("xAsJvrwmtTcpgKqPRhjwwudHdkMFikJxDixSMFTDPJBJAqmQWbzTftNAdFSvlnzGZKWEeBgGeMpHQroiENlppgahpsGRvgAyHYSRfRSgwXblzjbbtqzs"), true, true, -474860.32445376064);
    this->qwpcQxjbUimsUpPf(string("IXzYGPQOJytNPBiUSqPpvdEAnMIABfKEfggxaNdzTSHXuVhEYWDebpOFywySrNLyBCwLNcSuniPzxqJJuegVPcFWnEhCflsTsRpmVwsdMBpUwTmrZbdLBYhaueDTVQZEajBIVGintiyieoIVFqzNtzO"), true, 1876701683);
    this->yimcpCUdzq(false, 8308910);
    this->gvUHq();
    this->UsBuPnEDTjHaz(string("ErRvivFLlmUjpiHigRigROUGJfqDnRAXIFaIcUFolKuasQboknaDhsZXkeNUYuHiQocTSjArhWXJzdMrmzAYewVWVYQEHzykiSTvBaJidqjupiBjTkLgoCBFNBBEJYFRBpiZPXenpDUisUPWSazbRdZWEyxfBDT"));
    this->Omkzphy(string("KvIRykotqhElbaWbOIr"), true, string("cxzenoYmOWSouiZgwxvpRoiXxkQkbvarqfTRQUBhdfcGXjmjRlznWSqmKogKjyXNMUNdBwYVJlWMuLRaOnVIIavcEKzEPfIiJxpblzbrLeXzcYYQAFtIsygZQVdFhDEiPjurooawjbhedMFvkbcpsraaYJkAEgYRSBTHjLSVplugUcdMYzWSTjDJMhbontIwSIXTTsmuAIJcmVkcQIWiXYYePhRDeiDmXWXryrtfidbIJOcdB"), string("iQGchTQoCFilZkmuFnJtbkEhCpgzeiDXCgDnnUKnbqOSVSMldTYuMqKLZkMuxxGEkZPgpyHBGMZ"), string("xkyroqQVrvdZbQLtSdaqkhyRpMuamtFucLKsofiHIjwIAaFrfgAaAqhVcyabCVWOhrfjKEoZgziWbgFGNghBQZDezjIdEWwsfQTeQ"));
    this->YaUCobzMuneXbzIq(string("zWisBWsjQhboqeUZMkKqChSXtHKqQtLjYAhUDAmNIzyoqCanShifDKizClERUItrMiLXOmNQKoBWTBYmzBxGxchDWftEoqbKxzHsnNnuFQMdQKxYjuBeocutnJtreecyuZmcAToJXJjthUFOLr"), 345614.70771602495, true, string("ItVvJrEyEjASWJigseIomePDTjRBVewlOpdmTSLErpIiCnQLQJiysHOnaCJPbmVK"), 141208.19027263427);
    this->oqnZkVVhChKcBtf(481038.2673061554, string("sGJcuVNhzqavJaNFzwUJzvYkNuzNgLtigzPBUhSDpOZsyGJBPXitXDmSDHTpHDGYgIATFRVVIukutDNtQRKSwkdIfeuteiQlbpHdCttMeplAHSLndDTNQbvlRqADTrKZfkXmIMahBhEZydMhgttGKfaiCrMwRXERnrsPDfuxlcCYlnQJVQkQKQ"), 2116069299);
    this->tKqpibFGs(1432980154, string("zDrprVxFsvCFUkzMCLuBTXIAwkzBnanLBwyiAMfunzJAoDYEQzGvVsVroSAhnUfOnrGWqAsAybiFOgAQnpSeX"), false, false);
    this->JXBNjzvSFZUVsEr(true, -1389011841, 1012476.9271970901);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AVZNsxT
{
public:
    bool QuEMxHmpcRVIp;
    int DWVYrnvmBWDwSjvx;
    bool FKfqCtYdhUQLlYF;
    bool UvqVtfHfGatFoW;
    int coxjCJFoEuarT;

    AVZNsxT();
    void VkasUIPEVdElL(bool BSgcyTawizgzUZ);
    string nRfcIEK(double wtQDDet, int QqsqgVFPvbiX, double MKQfexKBs, string SsHoJpV, string kSgGwqtxMlK);
    string pvDzQvIbOWVvyEA(int YUvPDCYbPhmtRG, double kUqJSRYxdvvI);
protected:
    string thkKvUjZUNLuv;
    bool LAygKUapCIyeqQvr;
    double XtxrYKWigYPYCNyZ;
    string ecRyLb;
    int gdDQxoOSgdY;

    bool BapMO(bool utUSPTRKPhGycs, string wCirOTmLvOjrfRG, int Sbenwy, int WwcTIeBEzdKUXRy, string jGRmm);
    bool jqyRIOJEY();
    string xEbBDaIcdjiVC(string YoJvlVBNz, int KOXQsUbunxeM);
    double uXYEpgFoPSkx(string bdbTikiUWvKKSJE, string KhbSbMATbGZDf);
private:
    double fwscx;
    string QXNvu;
    double pwyDXcsgVMLYaD;
    string BFzeuwAayMQ;
    string QRLewOxv;

    int UIPOo();
};

void AVZNsxT::VkasUIPEVdElL(bool BSgcyTawizgzUZ)
{
    int pxEjHNSCMcjqh = 1617216905;
    double KAMdbhBOZYs = 103017.12708558359;

    for (int ybpAzeAoteOj = 923196959; ybpAzeAoteOj > 0; ybpAzeAoteOj--) {
        KAMdbhBOZYs *= KAMdbhBOZYs;
    }

    for (int uJQqL = 1281042387; uJQqL > 0; uJQqL--) {
        pxEjHNSCMcjqh = pxEjHNSCMcjqh;
    }
}

string AVZNsxT::nRfcIEK(double wtQDDet, int QqsqgVFPvbiX, double MKQfexKBs, string SsHoJpV, string kSgGwqtxMlK)
{
    int opXUSCrNZOAmnkm = -827765976;
    bool BMrVIQxTcxRNp = true;
    bool skLRuRD = false;
    int jSJbNaC = -98956898;
    double NwZiXPvuR = -974820.3596901898;
    double tIdGTmAvBY = 244703.04248823348;

    for (int eYuBDVblhxJUETbi = 2005530170; eYuBDVblhxJUETbi > 0; eYuBDVblhxJUETbi--) {
        continue;
    }

    return kSgGwqtxMlK;
}

string AVZNsxT::pvDzQvIbOWVvyEA(int YUvPDCYbPhmtRG, double kUqJSRYxdvvI)
{
    int cKALO = -198761961;
    double GjHpqBRq = 743599.437421218;
    bool HHpyUvXTGQXEao = true;

    for (int HZersFqavlvqs = 1367630019; HZersFqavlvqs > 0; HZersFqavlvqs--) {
        GjHpqBRq += GjHpqBRq;
        kUqJSRYxdvvI -= GjHpqBRq;
        YUvPDCYbPhmtRG /= YUvPDCYbPhmtRG;
    }

    return string("ffurdXHoxjQMzUDHixumnlhuwOkWHUZmtNFfmqIeadwHBGEewzOBKIBLTibupZTBiCHauecfPQuINofdPFRACccitdgJsmjfZNqHOUoILQCNRnJYoJFhGsprOUfLK");
}

bool AVZNsxT::BapMO(bool utUSPTRKPhGycs, string wCirOTmLvOjrfRG, int Sbenwy, int WwcTIeBEzdKUXRy, string jGRmm)
{
    double SehIrM = -65213.66047680017;

    if (WwcTIeBEzdKUXRy >= -1933809096) {
        for (int rkTmQNozVwl = 1021833597; rkTmQNozVwl > 0; rkTmQNozVwl--) {
            wCirOTmLvOjrfRG = wCirOTmLvOjrfRG;
            utUSPTRKPhGycs = ! utUSPTRKPhGycs;
        }
    }

    for (int JJFPhhBqpos = 164195853; JJFPhhBqpos > 0; JJFPhhBqpos--) {
        wCirOTmLvOjrfRG = wCirOTmLvOjrfRG;
        SehIrM += SehIrM;
        jGRmm = wCirOTmLvOjrfRG;
    }

    for (int HdEWPXUDS = 1541193324; HdEWPXUDS > 0; HdEWPXUDS--) {
        jGRmm += jGRmm;
        jGRmm += wCirOTmLvOjrfRG;
    }

    for (int WDtRqk = 556801278; WDtRqk > 0; WDtRqk--) {
        wCirOTmLvOjrfRG += jGRmm;
        utUSPTRKPhGycs = utUSPTRKPhGycs;
        wCirOTmLvOjrfRG += jGRmm;
    }

    return utUSPTRKPhGycs;
}

bool AVZNsxT::jqyRIOJEY()
{
    int YTKaeDSrNqBOcIQi = -1226263804;
    int GDcgm = -1880221464;

    if (YTKaeDSrNqBOcIQi > -1226263804) {
        for (int BshqSYzH = 1646289402; BshqSYzH > 0; BshqSYzH--) {
            YTKaeDSrNqBOcIQi /= GDcgm;
        }
    }

    if (GDcgm < -1880221464) {
        for (int kIYmlolHTuG = 383021496; kIYmlolHTuG > 0; kIYmlolHTuG--) {
            GDcgm += GDcgm;
            GDcgm /= GDcgm;
            GDcgm /= GDcgm;
            GDcgm = GDcgm;
            GDcgm /= YTKaeDSrNqBOcIQi;
            YTKaeDSrNqBOcIQi += GDcgm;
            YTKaeDSrNqBOcIQi *= YTKaeDSrNqBOcIQi;
            YTKaeDSrNqBOcIQi += GDcgm;
        }
    }

    if (GDcgm > -1226263804) {
        for (int VviLds = 727238405; VviLds > 0; VviLds--) {
            GDcgm -= YTKaeDSrNqBOcIQi;
            YTKaeDSrNqBOcIQi += GDcgm;
            YTKaeDSrNqBOcIQi -= YTKaeDSrNqBOcIQi;
            YTKaeDSrNqBOcIQi /= YTKaeDSrNqBOcIQi;
            GDcgm = GDcgm;
        }
    }

    if (GDcgm != -1226263804) {
        for (int GnBfuJmJUUU = 1849638780; GnBfuJmJUUU > 0; GnBfuJmJUUU--) {
            YTKaeDSrNqBOcIQi /= YTKaeDSrNqBOcIQi;
        }
    }

    return true;
}

string AVZNsxT::xEbBDaIcdjiVC(string YoJvlVBNz, int KOXQsUbunxeM)
{
    string PiqmcyUfScBfmQ = string("AXfiICqyTaDwvPxtLmTsNZodqdzbGVmNoGLOHDfdHiMMFHKePrNfLmAereTNQgIdKAobidlAWIlZZVVAqvFplslykoRKYUFiembROlBbopWnmeGKlYCFbDzjwdguYnZJzUQkQaitaStRXjvOFAPjVzBgTRVWpOvnvvClwPeDMwFiByPpOgsZwhVfEQOyemWKgfEIbpxloSyJJTzPOqoOHSrRpbuKFpzkL");
    string etiGlaRMzwNSP = string("CUbZyQJgzUzGRlEkArPfJYUbtCFadnnHdWpUUTnrzJlrZDtqWIgQQnffqnsPDAZwOqapiEIYSXWpdxkLUyumATkERZRVCJceHqEXUJCiaPqsHfTBiejSDrMkfWzae");
    string cRiKKCXPmgdOMKbl = string("kPrwpUDjnwyNSZEZWbyzLXsYGOXhHgVXrIrcCzomCfSwVIevmQLjpYSXsvOXEpyFBwhyTgHgkTpCRoCxQXmaRvLfOaZdgnvfSEmKLwcHSuEq");
    string IgQXhltVSb = string("wQcwBnYRxTqqbDNMHRqJvMkXytrdcodSReAsYxAOTBIuSGOvcZICiekeYGAiuxGfkjpAJseMdInctALHXEJJdRTwivEPAMhvzYoSNYSEaiHOpsMakllbsgtKegHGHvSycPSOYqDNXtfwBxhZkxtEiVXNnGGUqKeQCETeVekzruuBGj");
    int IpPMi = -1089958442;
    bool aGUHNoEjzsCiLZU = true;
    int oKUyHcnKbcQaKtdh = -289814867;

    for (int MnWhX = 442522993; MnWhX > 0; MnWhX--) {
        etiGlaRMzwNSP = YoJvlVBNz;
    }

    if (cRiKKCXPmgdOMKbl >= string("CUbZyQJgzUzGRlEkArPfJYUbtCFadnnHdWpUUTnrzJlrZDtqWIgQQnffqnsPDAZwOqapiEIYSXWpdxkLUyumATkERZRVCJceHqEXUJCiaPqsHfTBiejSDrMkfWzae")) {
        for (int wUgBienynsYsdRT = 1630484602; wUgBienynsYsdRT > 0; wUgBienynsYsdRT--) {
            PiqmcyUfScBfmQ = cRiKKCXPmgdOMKbl;
        }
    }

    if (etiGlaRMzwNSP > string("XLuzAMvLPHdxgTrVFZHueyXReemIEAFkKYkfSSxMGaOtLZhZydXYthapRnQSmGDxAlrcdPQiIlspKjMbXgsaHATFPyPBnIfDYpTTxqcABaeKNAzvZopQRxYnbSGbaOrLnXSxrjwIFAeyLUvfGBJYLEHyzGDwRWGOvRHILnVHcTdKHYZjchmrpGlQOCxANPOegKlKRCzgSbbxafWgxxjEwcvMPDGmzIEIRFZlhARWvfeYYLPVZFzokD")) {
        for (int Meszkhl = 70668865; Meszkhl > 0; Meszkhl--) {
            KOXQsUbunxeM /= oKUyHcnKbcQaKtdh;
        }
    }

    for (int tfPSgmLFPOSTKVZQ = 1084529404; tfPSgmLFPOSTKVZQ > 0; tfPSgmLFPOSTKVZQ--) {
        YoJvlVBNz = etiGlaRMzwNSP;
        KOXQsUbunxeM /= IpPMi;
        YoJvlVBNz += IgQXhltVSb;
        etiGlaRMzwNSP += PiqmcyUfScBfmQ;
    }

    if (PiqmcyUfScBfmQ == string("kPrwpUDjnwyNSZEZWbyzLXsYGOXhHgVXrIrcCzomCfSwVIevmQLjpYSXsvOXEpyFBwhyTgHgkTpCRoCxQXmaRvLfOaZdgnvfSEmKLwcHSuEq")) {
        for (int wahaKEcsfcA = 951118391; wahaKEcsfcA > 0; wahaKEcsfcA--) {
            YoJvlVBNz += cRiKKCXPmgdOMKbl;
        }
    }

    if (oKUyHcnKbcQaKtdh == -1089958442) {
        for (int PAziCqdacSfXI = 395797758; PAziCqdacSfXI > 0; PAziCqdacSfXI--) {
            PiqmcyUfScBfmQ += IgQXhltVSb;
            cRiKKCXPmgdOMKbl += cRiKKCXPmgdOMKbl;
            KOXQsUbunxeM -= KOXQsUbunxeM;
            KOXQsUbunxeM /= KOXQsUbunxeM;
        }
    }

    if (KOXQsUbunxeM >= 380050150) {
        for (int yKVhM = 631562150; yKVhM > 0; yKVhM--) {
            KOXQsUbunxeM += IpPMi;
            YoJvlVBNz += cRiKKCXPmgdOMKbl;
        }
    }

    return IgQXhltVSb;
}

double AVZNsxT::uXYEpgFoPSkx(string bdbTikiUWvKKSJE, string KhbSbMATbGZDf)
{
    double sOjCeJCmFhaxTaOh = 366196.39050065575;

    if (bdbTikiUWvKKSJE <= string("czDGiXnIuGoGaYEUSVeNpimGkTettQIhdcDtazHrBokeSMIMOiFqqFDjtIUyylurTcPJbTDtRLaGtpiyzJGHEfqpUkFaEoLfEfNNfYSuhecXoTmGtSlhuLNCZyLAmJxjUjRPPrmkVHNHjcZHdqlLtmzVYCiuxaBsNlHqZdhwEpbDUyuqJTLvSBpaNGoOVTZetqwWhfvUeGFOc")) {
        for (int dpHZUAYpfOylv = 1563800915; dpHZUAYpfOylv > 0; dpHZUAYpfOylv--) {
            bdbTikiUWvKKSJE = KhbSbMATbGZDf;
            bdbTikiUWvKKSJE += bdbTikiUWvKKSJE;
            bdbTikiUWvKKSJE += bdbTikiUWvKKSJE;
            bdbTikiUWvKKSJE = bdbTikiUWvKKSJE;
        }
    }

    if (bdbTikiUWvKKSJE >= string("MVeVErbeWHlIrKZkmyUkwDExjpweemdSoiUNjJNadWktcxbiWQcCfYayUJgbVnegJvJGwSmujRzeTfUJMmvSJEcmcnszRHSnvIDrFmAgJsnCuyzxMmppslAfdHLcJJowuPLlsxwmpFHYVJBTuaNpAoKSErgjUfRNGm")) {
        for (int NycQuvgxgLCGvycK = 1912073265; NycQuvgxgLCGvycK > 0; NycQuvgxgLCGvycK--) {
            KhbSbMATbGZDf += bdbTikiUWvKKSJE;
            bdbTikiUWvKKSJE += KhbSbMATbGZDf;
            bdbTikiUWvKKSJE += bdbTikiUWvKKSJE;
            KhbSbMATbGZDf = KhbSbMATbGZDf;
        }
    }

    if (KhbSbMATbGZDf != string("czDGiXnIuGoGaYEUSVeNpimGkTettQIhdcDtazHrBokeSMIMOiFqqFDjtIUyylurTcPJbTDtRLaGtpiyzJGHEfqpUkFaEoLfEfNNfYSuhecXoTmGtSlhuLNCZyLAmJxjUjRPPrmkVHNHjcZHdqlLtmzVYCiuxaBsNlHqZdhwEpbDUyuqJTLvSBpaNGoOVTZetqwWhfvUeGFOc")) {
        for (int dLGTvqqUIWGrUsoJ = 1537665458; dLGTvqqUIWGrUsoJ > 0; dLGTvqqUIWGrUsoJ--) {
            continue;
        }
    }

    return sOjCeJCmFhaxTaOh;
}

int AVZNsxT::UIPOo()
{
    string ooqxFRr = string("npAyKLiRRIwLChnQNvwzucUQjyemuAnMfIydsmRSHRZpUQYoQVagXMYBrWQpZEsplJWUzildKGbJlLAHtyauyVgUmUjjMTzKJHJqxMzCPYpOAZSzmUXqKmDUVoHXJm");
    int tKlphEWLw = 1604116095;
    bool KJnFWZsCFiz = false;
    int KcBCJtXeNhlL = -336252523;
    string ysWJIoRR = string("WJEAQehJFxDpDWektVWlYkdSfDZWrxcfCxxLjQFlOTegroSboOSweybCYqlDXcCsTPDhSEshNSXNNqPepGXAGcFpXPTv");
    int mutgLH = -924905338;

    if (ooqxFRr > string("WJEAQehJFxDpDWektVWlYkdSfDZWrxcfCxxLjQFlOTegroSboOSweybCYqlDXcCsTPDhSEshNSXNNqPepGXAGcFpXPTv")) {
        for (int DBPTl = 987364733; DBPTl > 0; DBPTl--) {
            KcBCJtXeNhlL /= tKlphEWLw;
            mutgLH += tKlphEWLw;
            ooqxFRr = ooqxFRr;
            KcBCJtXeNhlL += KcBCJtXeNhlL;
        }
    }

    for (int GOYqQqMLtZfmGyZ = 1700013420; GOYqQqMLtZfmGyZ > 0; GOYqQqMLtZfmGyZ--) {
        tKlphEWLw *= KcBCJtXeNhlL;
        KcBCJtXeNhlL *= mutgLH;
    }

    if (tKlphEWLw == -924905338) {
        for (int YMwHrcJ = 1694113678; YMwHrcJ > 0; YMwHrcJ--) {
            KcBCJtXeNhlL *= tKlphEWLw;
            mutgLH -= mutgLH;
        }
    }

    if (ysWJIoRR != string("npAyKLiRRIwLChnQNvwzucUQjyemuAnMfIydsmRSHRZpUQYoQVagXMYBrWQpZEsplJWUzildKGbJlLAHtyauyVgUmUjjMTzKJHJqxMzCPYpOAZSzmUXqKmDUVoHXJm")) {
        for (int zGtIqiwPX = 332097686; zGtIqiwPX > 0; zGtIqiwPX--) {
            ysWJIoRR += ooqxFRr;
            KJnFWZsCFiz = ! KJnFWZsCFiz;
        }
    }

    if (KcBCJtXeNhlL >= -924905338) {
        for (int SnFOWAwKL = 1125886822; SnFOWAwKL > 0; SnFOWAwKL--) {
            continue;
        }
    }

    return mutgLH;
}

AVZNsxT::AVZNsxT()
{
    this->VkasUIPEVdElL(true);
    this->nRfcIEK(-904400.5802630264, -1820789590, 245504.6474990143, string("GCocClqVkhnBGgVEbOXlUrzhJbMVLmcTWnVqCjfcSMwlIWdayDPywTzXNKpwrXEMkQCGTfOsbtQLVTQtIbGaniKTQJoKMUgdefPbSAyilzPgleqQiqeHmkK"), string("wzrmmtKAfjOXMW"));
    this->pvDzQvIbOWVvyEA(-1544997850, 356647.54262262565);
    this->BapMO(true, string("vVTNPtwOCWF"), -1933809096, 686234747, string("pNirpVKYzAGAITolbXGhIrmTMXQfCBolxsCRQsXopOVFhUbTRYlXMLWLPepPNMincDSaukwrUy"));
    this->jqyRIOJEY();
    this->xEbBDaIcdjiVC(string("XLuzAMvLPHdxgTrVFZHueyXReemIEAFkKYkfSSxMGaOtLZhZydXYthapRnQSmGDxAlrcdPQiIlspKjMbXgsaHATFPyPBnIfDYpTTxqcABaeKNAzvZopQRxYnbSGbaOrLnXSxrjwIFAeyLUvfGBJYLEHyzGDwRWGOvRHILnVHcTdKHYZjchmrpGlQOCxANPOegKlKRCzgSbbxafWgxxjEwcvMPDGmzIEIRFZlhARWvfeYYLPVZFzokD"), 380050150);
    this->uXYEpgFoPSkx(string("czDGiXnIuGoGaYEUSVeNpimGkTettQIhdcDtazHrBokeSMIMOiFqqFDjtIUyylurTcPJbTDtRLaGtpiyzJGHEfqpUkFaEoLfEfNNfYSuhecXoTmGtSlhuLNCZyLAmJxjUjRPPrmkVHNHjcZHdqlLtmzVYCiuxaBsNlHqZdhwEpbDUyuqJTLvSBpaNGoOVTZetqwWhfvUeGFOc"), string("MVeVErbeWHlIrKZkmyUkwDExjpweemdSoiUNjJNadWktcxbiWQcCfYayUJgbVnegJvJGwSmujRzeTfUJMmvSJEcmcnszRHSnvIDrFmAgJsnCuyzxMmppslAfdHLcJJowuPLlsxwmpFHYVJBTuaNpAoKSErgjUfRNGm"));
    this->UIPOo();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sYRuNWINQTObHU
{
public:
    string csYRoavh;
    bool JRYTlGjoBWoyowC;
    int SqwzeKDzOhFhfmRm;
    int qWBGfVTMLyTKdG;
    double oPRaXmSaWDWD;

    sYRuNWINQTObHU();
    int JyBTUrZaoMawFMU(int duDqzQbUjQs, double RcdBsZapwDQvhyG, double wqfmaSJf);
    int gAXvsiSJMacQ(bool JtcbkT, bool CsOjhgCnkpO, bool WfHOyACdGvbyPjNP, int BLxMgFbJmnV, double ELKhMVCpZTHFeE);
    void JSwiHdGFaYrZh(string HkUyz, string GaHtsLDVXAgc);
    void OqcqvgyZUKhcG(int EDdxykE, string kMlrtJqVU, double moUNkawiTRRmXAp, double jvXqosi);
    string pJuJkfFUJaTz(int DJtXTdmGjxVl, string sfJZi, bool HZPEvgz);
    string xZcuLNRCAVAO(string dKSrcCkDYygpAbE, bool PDprSZPWqY);
protected:
    bool UWNAU;
    int HqSNQzOCivVBdN;

    double CJhUisevdxtDb(string onGJAY, int SmuRhZdoletb);
    string CfuTgKooWrEjwfY(double TmGPIYnhOAZsr);
    void pNWYEIqloLeYLlJ(string JLGRFs, double jtxyz);
    double qXGjelghkefnNncI(string ehfQhFSfVXSzCyzm, bool JtFxYBjPTzbznj, double qvUvuF, bool UqdZElDGe);
    int MvUZrJxwbWjGVYs(bool KFXXZSEhRs, bool uHETPwcOld, string alYLfUpR, bool XBeObSIUlPc, bool dlkbVBjVd);
    void PFlrzv(string IJQCDrn, int YFYruEp, bool zFgmSLExfYyiOGi);
    string QLumqJcofBfQznDn();
private:
    int gbajeqKFEaPuu;
    string VmWigiFj;
    double XAnnhGxWEjGEbWM;
    int LwspUvWCFozcgxgI;
    bool OJGIxLibCC;

    bool bCvqFsVIpoFJBq();
    double EZXuoHRXAhZ(bool EPPotO, double LMpig, string JGKLWymMTIYi, string uAnWRyR, bool GqPZmEJCBXXxAk);
    string aYahEYBEovWnfE(int pSQpBMfefT);
    double ZvepINgoZdDhGd(string gncEaIASCcmDBdUF, string LSigEOZdvFTn, string uHKVq, string oaRUTXCCNkzvg);
    bool UGphpkoocx(string eTdVGoXyqed, double vnppkm);
    double AfLbxohTISi(bool sfWdisMnyQukJ, string AxaUsB, int HIZrXwNFWrqHo);
    int PnGLmtgOBqFWg(double KjlhItoVBOZxsO, string ncdbImZRBsvLa, double zOUuUCmCkvjst, int MtBSnOvx, int LXcVXpeiZXI);
};

int sYRuNWINQTObHU::JyBTUrZaoMawFMU(int duDqzQbUjQs, double RcdBsZapwDQvhyG, double wqfmaSJf)
{
    int OdDPrTDJjqLDx = -24950770;
    int OnsRC = 295913171;
    string utMJjhRTpBnus = string("axYRzSoXZhYOICkMLSjddqPcIqyFSACqUnowogfsJcPygdupRWmDCqBKiBCFxJLQxvYZQFpbshbwuWLkuQWjBQFsFYrYggjWlFTVgdphGvqEKRrpGtmZpEqUyJDEwSffbdYBNxqMSpVBNBOaCLOsMKutbCpWYGgdKHZbxbMwQixFtGKVKbdGrhamwpXoRKP");
    string rKXYJxdfp = string("yxAYFOuDpjEPFeUTILdLqYLyqaCXLOHCUDXTfrzMWBDieQvpSrANAxOvbPkRbQDdcWUYSBWnKMuLOqxmpXSMcmTRlNhGnXHflzMpIwSWpMBdjeSXvPbbxaFbgIhU");
    string rkKHytxskYWGmbt = string("suXVbdHKlVsjEWrcGBcxjNaTiYzwdurTIaTvVfVogEKKLEWwtIUfSQQQjXqJsRunmdYkxmGtpRnRhwaBvjfMPZvSAJbgnBVySmCBiZOvhWJHIFiLCpYtNsvRkgGerjTEyIeFpawjfiGtkkrkSOQPNEabGEnNTzDZToONFBvBCVBlDMQKUdaawHSIKPTLKgTWYmNdc");
    bool tqZsGRE = true;
    int ehfHmGQYsAcdBWb = -643602172;
    int HTVOVO = -863112708;
    string AGVaFJMBVJJ = string("DGUwPltZvFTEqiWLCILtaVexNADtOjFTGZixZCmCCQAvQbOclwvpKUO");
    bool MBDsB = false;

    if (utMJjhRTpBnus != string("yxAYFOuDpjEPFeUTILdLqYLyqaCXLOHCUDXTfrzMWBDieQvpSrANAxOvbPkRbQDdcWUYSBWnKMuLOqxmpXSMcmTRlNhGnXHflzMpIwSWpMBdjeSXvPbbxaFbgIhU")) {
        for (int prtwMMoFqMMLn = 1040413812; prtwMMoFqMMLn > 0; prtwMMoFqMMLn--) {
            AGVaFJMBVJJ = utMJjhRTpBnus;
        }
    }

    if (duDqzQbUjQs > -863112708) {
        for (int BbzTWUSMB = 2010409636; BbzTWUSMB > 0; BbzTWUSMB--) {
            OdDPrTDJjqLDx += OdDPrTDJjqLDx;
            rkKHytxskYWGmbt = AGVaFJMBVJJ;
        }
    }

    for (int qnMQJaytHBD = 72852068; qnMQJaytHBD > 0; qnMQJaytHBD--) {
        RcdBsZapwDQvhyG = RcdBsZapwDQvhyG;
    }

    if (OdDPrTDJjqLDx >= -643602172) {
        for (int ZbrAgOZ = 2021842948; ZbrAgOZ > 0; ZbrAgOZ--) {
            utMJjhRTpBnus = rkKHytxskYWGmbt;
            OdDPrTDJjqLDx -= duDqzQbUjQs;
            HTVOVO = HTVOVO;
        }
    }

    if (utMJjhRTpBnus == string("yxAYFOuDpjEPFeUTILdLqYLyqaCXLOHCUDXTfrzMWBDieQvpSrANAxOvbPkRbQDdcWUYSBWnKMuLOqxmpXSMcmTRlNhGnXHflzMpIwSWpMBdjeSXvPbbxaFbgIhU")) {
        for (int XHtky = 1400961272; XHtky > 0; XHtky--) {
            continue;
        }
    }

    return HTVOVO;
}

int sYRuNWINQTObHU::gAXvsiSJMacQ(bool JtcbkT, bool CsOjhgCnkpO, bool WfHOyACdGvbyPjNP, int BLxMgFbJmnV, double ELKhMVCpZTHFeE)
{
    double USAUuXUvnT = 311792.83684907795;
    string BTszyYMIdBELRsUf = string("gKQkElqSXVGcnLUUWFWaRAXwvmkHHanhERncmKhlxIymxBNtnhKfswvPXYKVgBwesCsadrDCWrc");
    bool RTqEQ = true;
    double IUzcFotBGw = -643037.8628492545;
    double BynPjEjZcifjK = -369615.66053009155;
    int TrYCvJNMAPRRRh = -287462099;

    for (int ksaYJUwhv = 1338409940; ksaYJUwhv > 0; ksaYJUwhv--) {
        USAUuXUvnT += IUzcFotBGw;
        USAUuXUvnT /= IUzcFotBGw;
        CsOjhgCnkpO = JtcbkT;
        BynPjEjZcifjK += USAUuXUvnT;
        IUzcFotBGw /= ELKhMVCpZTHFeE;
        WfHOyACdGvbyPjNP = CsOjhgCnkpO;
    }

    return TrYCvJNMAPRRRh;
}

void sYRuNWINQTObHU::JSwiHdGFaYrZh(string HkUyz, string GaHtsLDVXAgc)
{
    int kVPtFe = 430043212;
    int wzHiKAutfkmgw = -739603656;
    bool dLCmXOvqmamX = false;

    for (int lZdXP = 2016584231; lZdXP > 0; lZdXP--) {
        HkUyz += GaHtsLDVXAgc;
        HkUyz = GaHtsLDVXAgc;
        kVPtFe -= kVPtFe;
    }
}

void sYRuNWINQTObHU::OqcqvgyZUKhcG(int EDdxykE, string kMlrtJqVU, double moUNkawiTRRmXAp, double jvXqosi)
{
    bool MJgHwhzdkUjn = false;
    string AUuaQntlQvd = string("ixqpdbHRKQfDeJTmmRcNAclGIaIodoCeNQZDyejWuBQRguLbTxVYrBvdzTsojFZdKmQTKrBEtmqcgMUVTtaSHseTXIxGqUKwaeWURhTDtsSShGJQGYamYDDTtstacdIosksZqXVxBKLHQLPbVSIRxAEePCCliiwCGFMuIFRyQvWFarDcgoq");
    string enhrnAPrvrqvm = string("AOiUKOJSWmwfuMKlzlvkKGUjtnSbTrDFcnEYVTyKwLNgCTKtkyuGOjjGPtNPJYcPkuOESjItPdTfCNEDiXoQpDBWZiuKGQniKxWhkRiYRxRjTDyDhNXsmxiEiTGGHVFSuLhfhveDtoNIBwrzzHhVCXHEEnfEXQORBnxBProffhwcHwTEvLbXVmGhtYDZkipYNCRJWfFKNNFoGpoJshaMtoHbWGgcG");
    double fndnABvlw = -109725.76979658616;
    double tLXMku = 777943.8355693019;
    int WkzOBtbEPSPKUpyO = -1109431025;
    int VGKSGT = -1565196617;
    bool FaAuyi = true;
    int zEyLcEhCtrlqPx = 613696179;
    double ZRzSOGoegAQ = 860151.1643653195;

    if (zEyLcEhCtrlqPx > -1109431025) {
        for (int tBdPZoh = 1930753733; tBdPZoh > 0; tBdPZoh--) {
            FaAuyi = ! MJgHwhzdkUjn;
        }
    }
}

string sYRuNWINQTObHU::pJuJkfFUJaTz(int DJtXTdmGjxVl, string sfJZi, bool HZPEvgz)
{
    int OsEYU = -77810355;
    bool vxIAGDd = true;
    string JoYEgbmhDXnqp = string("qsYIQoYpKUlPjjQDpyDVCXIWlsBzOVExHdVDFTlpvREZrtauXsjuQERIUquloamUVIMMCmpbPsFniKZqICQuQCIJAhyHfQxsyUILDIjiAOlENedoDJkGZjytQkgiutqgiETvAERLKW");
    string fVWXZUY = string("wFULxcJtolbtPGwnKtxVQVjeuAmfEcVRSnNCqRUrHnusXQdrJudlvchPHDoeJFezufNKqceRiparGZVUTFTvlXrRBMRszRfwWkZnvgCJnHUtoPHlWMUJyfPnodGeJBdfAHslTHHmoaDfimqCJmkgZBJlBfxojqRfHjlOlUWvrpRfNNXDImMBVqcMThjXuVOYmOKwIxzaJtwHNAFEpGKSKiUSgoQMrqPWguNVTZgWTxfyhHnsg");
    string qMyZrppeGHTqko = string("sQPHdkiWlDABWKsXcSKhmLhNokbAiUwyaaUPSqvyMjGstthMIMzBfEbpjqCzzpceEIzlqyjBJDCy");
    int WKYwPeh = -645666114;
    string LrrdHzMClT = string("hEOgrbdALSiWcmFiJhNGSQBaCCeyTzHFgMIWNfoXmAowdfnWCUbogNkNBjOMUcONUugoOKFAEGAXOSJ");
    string VxPKUbwCHao = string("DBxgljetJwOwoVGjesDGRuOsbDbj");

    return VxPKUbwCHao;
}

string sYRuNWINQTObHU::xZcuLNRCAVAO(string dKSrcCkDYygpAbE, bool PDprSZPWqY)
{
    double HqCBnxsFqzVVR = -791393.3459490843;
    bool vimRMmarlQ = false;

    for (int EfSxcXhs = 1329371001; EfSxcXhs > 0; EfSxcXhs--) {
        vimRMmarlQ = PDprSZPWqY;
        PDprSZPWqY = ! vimRMmarlQ;
        dKSrcCkDYygpAbE = dKSrcCkDYygpAbE;
        PDprSZPWqY = PDprSZPWqY;
    }

    if (vimRMmarlQ != true) {
        for (int NRZyo = 2018841488; NRZyo > 0; NRZyo--) {
            PDprSZPWqY = ! vimRMmarlQ;
            vimRMmarlQ = ! vimRMmarlQ;
            vimRMmarlQ = ! PDprSZPWqY;
            vimRMmarlQ = ! vimRMmarlQ;
        }
    }

    if (vimRMmarlQ == true) {
        for (int IGqiIrz = 163547655; IGqiIrz > 0; IGqiIrz--) {
            vimRMmarlQ = vimRMmarlQ;
            PDprSZPWqY = vimRMmarlQ;
        }
    }

    for (int nwPCCRwBikeFU = 76952420; nwPCCRwBikeFU > 0; nwPCCRwBikeFU--) {
        vimRMmarlQ = ! PDprSZPWqY;
    }

    for (int ZopRFStZzLxnbc = 377438109; ZopRFStZzLxnbc > 0; ZopRFStZzLxnbc--) {
        HqCBnxsFqzVVR = HqCBnxsFqzVVR;
        vimRMmarlQ = PDprSZPWqY;
    }

    return dKSrcCkDYygpAbE;
}

double sYRuNWINQTObHU::CJhUisevdxtDb(string onGJAY, int SmuRhZdoletb)
{
    string LEEJJznFKlVDFlv = string("GqcZolktWAdkVBnPSJeNbfGgweCKJvFxoGvLOvARxhnELOfovmfNsXfkNElmSTxUupRMAesmdHuAMTODhzXQkaUSIlSRNQJMwDZqtobtKBVZaJmnjxCBYeCARQAvMRkWViVjcUzKlNrBnIuGJZBWYXSBzSfMtGpuvwoAXGmpMTisBuoPSuSHNhoOWBZDXtAnzBfXZylLoMpNVIlvMATAgOswIsZlyiJKCcanNCuXBUELGpMAUHszX");

    if (onGJAY < string("hAcMqLrhfRnwroewDpIZMcBIEcGAPWEEMxaEtzVNYtxftfWZaWeulERisCMLEEpytnxIAeKoIvzffeCSVkdIWphkJjBCbhneCHRieOvQsnuXmNIcSpPFQfyceTbkPqSMHcsOSYUgkrzTdqdUkjBipBWkuFpxhmXYPCDiMOUZXPLbPBrGQeSagMtoVLWrjtVqf")) {
        for (int qQlApdv = 676142419; qQlApdv > 0; qQlApdv--) {
            SmuRhZdoletb -= SmuRhZdoletb;
            onGJAY = onGJAY;
            onGJAY = onGJAY;
        }
    }

    for (int yElVM = 49720219; yElVM > 0; yElVM--) {
        SmuRhZdoletb -= SmuRhZdoletb;
        SmuRhZdoletb *= SmuRhZdoletb;
        SmuRhZdoletb -= SmuRhZdoletb;
        onGJAY += LEEJJznFKlVDFlv;
        SmuRhZdoletb *= SmuRhZdoletb;
    }

    for (int AdAxcCbnIp = 1347474067; AdAxcCbnIp > 0; AdAxcCbnIp--) {
        LEEJJznFKlVDFlv += onGJAY;
        onGJAY += onGJAY;
        onGJAY = LEEJJznFKlVDFlv;
        onGJAY = onGJAY;
        onGJAY = LEEJJznFKlVDFlv;
    }

    if (SmuRhZdoletb != -2022881126) {
        for (int WztFVEGGllFFfjK = 1477396270; WztFVEGGllFFfjK > 0; WztFVEGGllFFfjK--) {
            SmuRhZdoletb /= SmuRhZdoletb;
            onGJAY = LEEJJznFKlVDFlv;
            LEEJJznFKlVDFlv = LEEJJznFKlVDFlv;
        }
    }

    return 778061.1709519014;
}

string sYRuNWINQTObHU::CfuTgKooWrEjwfY(double TmGPIYnhOAZsr)
{
    double IEUFnumnTPv = 861098.6705489517;
    int IJKmGrgjr = -851609060;
    int ywXFZFEfeVHU = -218162392;
    int GfIDFfoSbmVNvfc = 1214711428;
    bool uMAHbbTrKFJxB = true;
    double NHdQgPnpyWSv = 404732.60792525596;
    double npKuGxkEqthSpZgl = 839729.3382564276;
    string MtXrxEqQEDLqO = string("ZiOhwSVmOxanZLNAhwCzOvlXepaHkkjOobgWKksNMtxnkBuuoEQiWMvSXoayqZbjxZRjlvcSnWCLvCfIhoNtqBPfnYihsObKfLiSlRisxctIRcNYyBGuVIVghODPvyjHSVXjlVSBWannkaPiXEmeUiDpifXUmQlzqFWuZeKCIyXfpkipqnIOmDTfrLb");
    bool bnGQshOhaHl = false;
    string gTYvshgWXDfaUVtZ = string("HcOZeDIAmkXBLoJuBsSnBGjwsnidvsQbItZMocAuzRhhJSsvYYRzcjGVlEieVVWxmrwInaGrTTSohSaqMwYZbAtDANzBYUQmXYTsgidhyOxVXJWbiCNhuhUPESrYyZmnhrVTuocIcYvVTkgKmrqnRTTaDxQFZAEksKraIlafsyhLBpDtzlaXCGazdEyAuzwsKnzSZcxCgkZEgzquDOWifkXnpaYjAgHhugqXBVKJNiiOdTAwLQGVdfMDykA");

    for (int LjGgeW = 480483259; LjGgeW > 0; LjGgeW--) {
        IJKmGrgjr -= ywXFZFEfeVHU;
        NHdQgPnpyWSv -= IEUFnumnTPv;
        GfIDFfoSbmVNvfc /= GfIDFfoSbmVNvfc;
    }

    for (int iwSNFRIj = 890695306; iwSNFRIj > 0; iwSNFRIj--) {
        TmGPIYnhOAZsr += TmGPIYnhOAZsr;
        gTYvshgWXDfaUVtZ += MtXrxEqQEDLqO;
        uMAHbbTrKFJxB = ! bnGQshOhaHl;
        NHdQgPnpyWSv *= npKuGxkEqthSpZgl;
    }

    if (GfIDFfoSbmVNvfc <= 1214711428) {
        for (int GNSaJnPEEfsP = 1674705170; GNSaJnPEEfsP > 0; GNSaJnPEEfsP--) {
            npKuGxkEqthSpZgl += npKuGxkEqthSpZgl;
            IEUFnumnTPv += IEUFnumnTPv;
        }
    }

    for (int eDhasvss = 357250079; eDhasvss > 0; eDhasvss--) {
        gTYvshgWXDfaUVtZ = gTYvshgWXDfaUVtZ;
    }

    if (NHdQgPnpyWSv != 861098.6705489517) {
        for (int SmLmqnU = 1610756878; SmLmqnU > 0; SmLmqnU--) {
            continue;
        }
    }

    return gTYvshgWXDfaUVtZ;
}

void sYRuNWINQTObHU::pNWYEIqloLeYLlJ(string JLGRFs, double jtxyz)
{
    string imjIzchSeX = string("pJHZjoUIYIPZuiFpoWJHzGWzhNwKGGCKNIrnCHDcvAXtpbSkFnWWMrtevBbHwquwALbaoEfKmcZGfiPRuuFgHpoTFEGvzfnfkfEjQFLCTkIUDdjVVvAyuxTAaqdlmqCTzSaBIKowokihFsgVSekRxEXKWoNBexdBMdAXYXAQAZNzNHFkbklIHwPpsKXFuhxrKOunMaSNDPbKtsSRwAFBTQVwarQrxXauArChUyQdgNYoLXVMeMyfYZmGjKSHI");
    bool PNJkGG = false;

    if (JLGRFs >= string("wneeUNJgfChIspfLNKmSlZwsBEIvWvFgnmQMonzApghuRdJMYVfcAudnjgUKgOFtordVnFqoWyrBkjBhfCgLvBPYRXAgMXcDUlEXahDKhaRsIAnJfFCCBkMSUtZTgSVFYeSOMYtsIPkUDyzMBeGIFWHFEtApWzTfZOeINpwwgiHf")) {
        for (int vzWWfveQHFFvWb = 1301746396; vzWWfveQHFFvWb > 0; vzWWfveQHFFvWb--) {
            continue;
        }
    }

    for (int SsnxLGwhsLunUbPN = 1193298524; SsnxLGwhsLunUbPN > 0; SsnxLGwhsLunUbPN--) {
        jtxyz *= jtxyz;
        imjIzchSeX += JLGRFs;
        jtxyz = jtxyz;
        imjIzchSeX += JLGRFs;
    }

    for (int XFvphriDBLBw = 419207553; XFvphriDBLBw > 0; XFvphriDBLBw--) {
        JLGRFs += imjIzchSeX;
        PNJkGG = PNJkGG;
    }
}

double sYRuNWINQTObHU::qXGjelghkefnNncI(string ehfQhFSfVXSzCyzm, bool JtFxYBjPTzbznj, double qvUvuF, bool UqdZElDGe)
{
    string hCpjLnJlCdcP = string("upbyxxDNmMgQJWiZXbqlz");
    string FjyWLcdkaUo = string("ixcbgNHjMOfMcAzwBIJXYfMUHKjGPaPDxwFDXPzJXuVEEWEVAgIzrZLCEwLGyLtsPLOPFgUmkZnHaCjQpFcBxAMhdqhjafPPhbSKpSZauTBRPwclsFbyOxBvAgGNOdMwxVlQDiMOqxvIBdbLNHdMCkzoTQwvHdEuhHlwLFqwmgCevTvwHmoBOxBDTQugpywnCR");
    string qgKVMXGlHxIPQBxr = string("usinzzjoYNrMEjhLORLOFvOmzmmFfkVbYtCFeGoWHdMiTAFxValWzqbQwwqFDQSrmLtflGFpqvGnUuhUaIkxEAOfASltgtTtNHejHAftNLokEvxkrXU");

    for (int njHuIJAKPx = 669140660; njHuIJAKPx > 0; njHuIJAKPx--) {
        FjyWLcdkaUo += qgKVMXGlHxIPQBxr;
        JtFxYBjPTzbznj = UqdZElDGe;
    }

    return qvUvuF;
}

int sYRuNWINQTObHU::MvUZrJxwbWjGVYs(bool KFXXZSEhRs, bool uHETPwcOld, string alYLfUpR, bool XBeObSIUlPc, bool dlkbVBjVd)
{
    int qqGzbsNACk = -1666511528;
    bool mwKthwnwjaTa = true;
    double mKMRbTUpK = -672473.1856144159;
    int luFjYZJEjhwJ = 1530112650;

    return luFjYZJEjhwJ;
}

void sYRuNWINQTObHU::PFlrzv(string IJQCDrn, int YFYruEp, bool zFgmSLExfYyiOGi)
{
    string VBFXeTj = string("WjlNoMBqdnPxdYmZPMdlAvpYApZSPQOoHZoQxUisJzQtPpRprFeRrgqrrXvkuGtLxAbXGWQxUJdiZYZESlbpFzpfJEEaiJvKnuiPrclFZxGbEeljgOsXyAjWGuvihGgTVMslUhdxHQUxQyawSxIoHRGYCOAwMeUtfTFTBZiHDGSTmaJuiQZUJaWna");
    double FhzTjeOGdnM = -317562.26469294383;

    if (VBFXeTj == string("iuGAdyaQGtdQlRBZhZysJPDDm")) {
        for (int KEIdxyJPt = 980535518; KEIdxyJPt > 0; KEIdxyJPt--) {
            FhzTjeOGdnM = FhzTjeOGdnM;
        }
    }
}

string sYRuNWINQTObHU::QLumqJcofBfQznDn()
{
    int jMYxMabg = -1112218298;
    bool TIQge = true;
    double lhOZZ = -603037.5762746431;
    double PlKOrrRfQVP = 288112.92040215316;
    int UTivwkapZwYlT = -1002884543;
    string aneKarPseePJe = string("rZmWjDvduyuRbeqfAIiHMKDSmzpaGv");
    bool pZaxL = false;

    if (UTivwkapZwYlT <= -1002884543) {
        for (int ezLbHs = 1418288888; ezLbHs > 0; ezLbHs--) {
            jMYxMabg = jMYxMabg;
            TIQge = ! pZaxL;
            TIQge = ! TIQge;
            TIQge = ! pZaxL;
            UTivwkapZwYlT -= UTivwkapZwYlT;
        }
    }

    for (int ZGSGiKExappXdmyH = 1619609847; ZGSGiKExappXdmyH > 0; ZGSGiKExappXdmyH--) {
        TIQge = ! pZaxL;
    }

    for (int QkPPTGbtZsobyXOt = 1957029137; QkPPTGbtZsobyXOt > 0; QkPPTGbtZsobyXOt--) {
        continue;
    }

    for (int ywRMGexOy = 97103885; ywRMGexOy > 0; ywRMGexOy--) {
        lhOZZ /= lhOZZ;
    }

    return aneKarPseePJe;
}

bool sYRuNWINQTObHU::bCvqFsVIpoFJBq()
{
    double bPrAEJgTsYPHimZr = 135847.44137226438;

    if (bPrAEJgTsYPHimZr < 135847.44137226438) {
        for (int FBfFtWMtefywnq = 1820306870; FBfFtWMtefywnq > 0; FBfFtWMtefywnq--) {
            bPrAEJgTsYPHimZr = bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr /= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr = bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr += bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr += bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr /= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr *= bPrAEJgTsYPHimZr;
        }
    }

    if (bPrAEJgTsYPHimZr >= 135847.44137226438) {
        for (int YlfmOHBJmUH = 2068018536; YlfmOHBJmUH > 0; YlfmOHBJmUH--) {
            bPrAEJgTsYPHimZr -= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr *= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr /= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr /= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr -= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr = bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr *= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr += bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr /= bPrAEJgTsYPHimZr;
        }
    }

    if (bPrAEJgTsYPHimZr > 135847.44137226438) {
        for (int qXNpVHUWgcQfrnh = 24842974; qXNpVHUWgcQfrnh > 0; qXNpVHUWgcQfrnh--) {
            bPrAEJgTsYPHimZr *= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr *= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr += bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr = bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr -= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr /= bPrAEJgTsYPHimZr;
            bPrAEJgTsYPHimZr /= bPrAEJgTsYPHimZr;
        }
    }

    return true;
}

double sYRuNWINQTObHU::EZXuoHRXAhZ(bool EPPotO, double LMpig, string JGKLWymMTIYi, string uAnWRyR, bool GqPZmEJCBXXxAk)
{
    bool jNZRqcPDl = false;
    bool IeIWqAlvaPO = false;
    bool WCaslqQedMokQssz = true;

    for (int eGBniNbFCCBG = 882063048; eGBniNbFCCBG > 0; eGBniNbFCCBG--) {
        LMpig += LMpig;
    }

    if (jNZRqcPDl != false) {
        for (int ChKmiECVwrQ = 812131462; ChKmiECVwrQ > 0; ChKmiECVwrQ--) {
            IeIWqAlvaPO = ! WCaslqQedMokQssz;
            IeIWqAlvaPO = IeIWqAlvaPO;
        }
    }

    return LMpig;
}

string sYRuNWINQTObHU::aYahEYBEovWnfE(int pSQpBMfefT)
{
    int DswHFMQNaEiSyk = 982505689;
    string sFEQWbA = string("TzIFkjUBfnTPuwkdhPsNMqSmusQuRiIgofCPRIBpszIKcpqtRvVYcetGntYyCaXQpImLcnfvbLCnJQgXlddssTfUvasWxLWZuGy");
    string TRqbH = string("rffYrygXKalCPvSWERpqQiPLIUNXamKQiwrjcJkdMDRKgESMoEixMIwylkTvXQQQOVJAUwQPQWqihjaLpBGZGsvXhYjmfxqdtppKgmcvlDUvHeWAVuAHXDfOBdROaqUApLXVJtQCAxyZjPQt");
    double DQckY = -404894.8021777777;
    int LqWKQl = 1661236594;
    bool VWygXOBTw = true;
    double WhHBB = -979837.2621495834;

    for (int fuYTitOGqYsG = 583668375; fuYTitOGqYsG > 0; fuYTitOGqYsG--) {
        DswHFMQNaEiSyk -= DswHFMQNaEiSyk;
    }

    for (int cfeSAqXhTkQ = 785602128; cfeSAqXhTkQ > 0; cfeSAqXhTkQ--) {
        sFEQWbA = TRqbH;
        sFEQWbA = sFEQWbA;
        sFEQWbA += TRqbH;
    }

    for (int Uofyt = 636987416; Uofyt > 0; Uofyt--) {
        LqWKQl -= DswHFMQNaEiSyk;
    }

    for (int EjSnkGXngivoXyi = 1262655581; EjSnkGXngivoXyi > 0; EjSnkGXngivoXyi--) {
        WhHBB /= WhHBB;
    }

    if (DswHFMQNaEiSyk == 1661236594) {
        for (int WQqkga = 196634715; WQqkga > 0; WQqkga--) {
            pSQpBMfefT /= pSQpBMfefT;
            sFEQWbA += TRqbH;
            pSQpBMfefT += DswHFMQNaEiSyk;
        }
    }

    for (int ehHCJ = 146386579; ehHCJ > 0; ehHCJ--) {
        continue;
    }

    return TRqbH;
}

double sYRuNWINQTObHU::ZvepINgoZdDhGd(string gncEaIASCcmDBdUF, string LSigEOZdvFTn, string uHKVq, string oaRUTXCCNkzvg)
{
    double cZEFuWuDfqz = -869268.2922713875;
    bool FMFCRnqPiYAwzv = true;
    string xZMTYpPmOtfwu = string("iJpTEToMUuxDcaThIQWYrNCSCUZAyfCHbxcFnBPyiGIzVXKlzYupMjJaRIaxHCctAjvMFHXNKeBQxFyVflVrGpyjVpPhoGIGtgTKZWAGrBQYgebpkDNCAWCvwuNxVyMttdmrkkFZPgKXXMkygdGuMtECRBDEEmGQjHpxBbHRAYMUQlEz");
    int dJOPnECRXotZgphL = 343007752;
    int iRKETfC = -786226966;
    int aXOHWwLvm = -1701135530;

    for (int OdzPjTnQi = 897390162; OdzPjTnQi > 0; OdzPjTnQi--) {
        FMFCRnqPiYAwzv = ! FMFCRnqPiYAwzv;
        cZEFuWuDfqz += cZEFuWuDfqz;
    }

    for (int dsxbXwoTfQrfHQu = 1010698969; dsxbXwoTfQrfHQu > 0; dsxbXwoTfQrfHQu--) {
        iRKETfC -= dJOPnECRXotZgphL;
    }

    return cZEFuWuDfqz;
}

bool sYRuNWINQTObHU::UGphpkoocx(string eTdVGoXyqed, double vnppkm)
{
    double wfrGmFzzvC = 786793.105524779;

    if (wfrGmFzzvC < 786793.105524779) {
        for (int HUusCMgFtZuuTmS = 1681749305; HUusCMgFtZuuTmS > 0; HUusCMgFtZuuTmS--) {
            wfrGmFzzvC = wfrGmFzzvC;
        }
    }

    if (vnppkm < -928927.7421827666) {
        for (int sHfPVdDLTXRDIDn = 28157136; sHfPVdDLTXRDIDn > 0; sHfPVdDLTXRDIDn--) {
            continue;
        }
    }

    if (eTdVGoXyqed <= string("wSUkNFSStsLfhVKVHfEbuTEZLvzjFHieCzRDYZDOFZwQyzdGlmUdwsYlNhQDjxGCiwcwDiyLEpVT")) {
        for (int vskacCHOeWXJoiC = 352414943; vskacCHOeWXJoiC > 0; vskacCHOeWXJoiC--) {
            vnppkm = wfrGmFzzvC;
        }
    }

    return true;
}

double sYRuNWINQTObHU::AfLbxohTISi(bool sfWdisMnyQukJ, string AxaUsB, int HIZrXwNFWrqHo)
{
    int WshCOrkamWdHL = -1857085918;
    bool nniVEzvVh = true;
    bool mRHtEQiymh = true;
    string ZnNvBAMEbhnFsf = string("mqfvrOkfKUltRTgVyolcNthTCnJgSdSnqYqHsyaqnzwicZhBPuNlPnlfwQUkkAGrbUMMuNFLWDCnXR");
    double mjWYX = 591037.5525015959;
    bool PsgUR = false;
    int HjHcKPEZvFeTHl = 484427163;
    int yzjNfneVLAskMRn = 1597870356;
    bool ZlhzmSfSXQCsq = true;

    return mjWYX;
}

int sYRuNWINQTObHU::PnGLmtgOBqFWg(double KjlhItoVBOZxsO, string ncdbImZRBsvLa, double zOUuUCmCkvjst, int MtBSnOvx, int LXcVXpeiZXI)
{
    int pJxAdbPGpn = 965394234;

    for (int FoIXGqVvTj = 2146167974; FoIXGqVvTj > 0; FoIXGqVvTj--) {
        zOUuUCmCkvjst /= zOUuUCmCkvjst;
    }

    for (int WOfvLDHhcjIV = 1807074454; WOfvLDHhcjIV > 0; WOfvLDHhcjIV--) {
        zOUuUCmCkvjst = zOUuUCmCkvjst;
        MtBSnOvx -= MtBSnOvx;
    }

    return pJxAdbPGpn;
}

sYRuNWINQTObHU::sYRuNWINQTObHU()
{
    this->JyBTUrZaoMawFMU(-1952655406, -811154.7077625521, -203629.87404502925);
    this->gAXvsiSJMacQ(false, false, true, 417234932, -907594.7009959323);
    this->JSwiHdGFaYrZh(string("PnzBSlQyJzzpCZNvCRceDkxsZxpHVuDMyBiVjxTvOXSfrbjHkOplVSELmxDKvDTWgCjOCZwvqMdGJImqQTfDyphbGrKberRezSGdWtgUsBhIrcfZvSVeiHzOKyvccGDiLUOOAigSkfbtqqOooVarHrrFlACsGutepAsPAQuvBnYqg"), string("HfGsnraxoGrxOGCxKFVnPSXYFcFMBIFgucBpRkEQlENiDFBwwGOlZSIKtSKQZBJlJTTRAHPRTlxTPepGrPGJaMqpdjdLBBdoPkJifrWcpSomCIEWJXPhJKcNpyaBEtrysyQCcOSAgsRegnoDMI"));
    this->OqcqvgyZUKhcG(-1139538824, string("qIUiVPGVvCXXxDWZMgeLxKBkeSbkrPvdKohmXpMnaKTjdpBQhUTLJvUILRniETAMYSTibbhlhmNc"), 633843.4133081915, 662209.0636294886);
    this->pJuJkfFUJaTz(-151529238, string("wvdfrosODbbrIytWFzsqfACEbWAPxNancXkplQIWAxAQMVwsQZgTDPGOPmQihTipzVofEBoZAfErvUxODikAbLdMXS"), false);
    this->xZcuLNRCAVAO(string("WWlUNjL"), true);
    this->CJhUisevdxtDb(string("hAcMqLrhfRnwroewDpIZMcBIEcGAPWEEMxaEtzVNYtxftfWZaWeulERisCMLEEpytnxIAeKoIvzffeCSVkdIWphkJjBCbhneCHRieOvQsnuXmNIcSpPFQfyceTbkPqSMHcsOSYUgkrzTdqdUkjBipBWkuFpxhmXYPCDiMOUZXPLbPBrGQeSagMtoVLWrjtVqf"), -2022881126);
    this->CfuTgKooWrEjwfY(-428621.93374548864);
    this->pNWYEIqloLeYLlJ(string("wneeUNJgfChIspfLNKmSlZwsBEIvWvFgnmQMonzApghuRdJMYVfcAudnjgUKgOFtordVnFqoWyrBkjBhfCgLvBPYRXAgMXcDUlEXahDKhaRsIAnJfFCCBkMSUtZTgSVFYeSOMYtsIPkUDyzMBeGIFWHFEtApWzTfZOeINpwwgiHf"), 187440.84400837639);
    this->qXGjelghkefnNncI(string("UwkStJGrGSUXZCfuMrIyEytBpOMAzFVTjiPicijBurWVKEAqoOHxqfmwpcwMbRlTjbxDTBvrgNhXILbGjQzujxnlPKbVigjTmqLATRucJuqiOMjiAaAUkwpBHrwowoInKiGBVjEMaGkHVkWZYCEgwfoYUOqOjlcTbXxdYNxqnkXcEhRxVCFGuAr"), false, -466748.26963721245, true);
    this->MvUZrJxwbWjGVYs(true, true, string("tOHXTbHEOgFObKdfjRHyUuaRKHbrFceqHKbybadHbzQkrKxBhxzFqoyrFvmarsBgfhoWybzKOvjkcsjiUzIJMiyKzAGJcUDKJvHFKbGJwQFDR"), false, false);
    this->PFlrzv(string("iuGAdyaQGtdQlRBZhZysJPDDm"), 376547324, true);
    this->QLumqJcofBfQznDn();
    this->bCvqFsVIpoFJBq();
    this->EZXuoHRXAhZ(false, 325645.27329080616, string("SpqqEukSjEnKGrIbjSMYCkt"), string("dgOWmCXWARlCiGtiRJqDOUXuqLzUKZoDcUHWUAcWWDKHYpxScMCYzDFCiFyKzNbezienbsVLgkMbwCQnKypDEvoAjXqseLHCOOoBofkVLEoPLQawcXpztlagBDbHAltjoBwAUoDOHLDJfcnFsQlkzHxQCXqzfJqZoQaYfcoTHraYYOpyb"), false);
    this->aYahEYBEovWnfE(1992145113);
    this->ZvepINgoZdDhGd(string("xQPSjbCVRgFojPqiAtCihKiOzMOGcxTuTyaKUdnLweBUFjLAJPoOrRgjkbHGZFSAIDgnkWtsUxIRvYciIfspszbaFkmttdDgBDeviAIENebSUxzRcl"), string("GRyjMnorbeJBPqAGJkpEZxRNFwSpzFHJHbAuTKQcXjPoxOnOZGCkUaeVXwsVSitdYtTJbGASXQtUqDcYXzuYiNTRJpmJTSFRaaueHMUFQyZhTuYnUiRqVpybLIvPRlaYVhPGvOaARUUSmVtAAZeAdrsiGTHmFDzyGmYYODhMcskgaaPNCaFiNnpQvXfNjlNNMfkeaVslqdumJrwNOlikNSrJSMPSabwJLlciyrnGu"), string("isUjWuWbsLKUlMunzTjyKXRBhShSabhcgzmADWjuNzDYbeNoZXVzGWePKKrEuRlZwAjVijoubdMbVvGVZuOIbLYGEpmclHsJAACwqijCqVcgPEnugAQKOTXobEuWBmRsvgsCjJLeVitvmaOURyNWp"), string("FWxfhOICkIotqtpfPsFPWOiADfNkFGObkUzAFqQfyyoxgQkfqH"));
    this->UGphpkoocx(string("wSUkNFSStsLfhVKVHfEbuTEZLvzjFHieCzRDYZDOFZwQyzdGlmUdwsYlNhQDjxGCiwcwDiyLEpVT"), -928927.7421827666);
    this->AfLbxohTISi(false, string("SXwBFCdHbEuakNYtmTyrTfQalXKdoGzoXoRJGoPGtQzTlmuUXAPVABuvuUtLgmOEkUOoRIjgVGVXYPJWWDxPbOoIzIqbxWyfijwnSPIGmzDMTPisnkmoybWHHsIIGLdhytTmYYCYspCRcyWROoZQTShrqUEjmkLAcFGDDVnldFHqxHsTWNHfzWVPxbaw"), -1485500182);
    this->PnGLmtgOBqFWg(-127113.03697466373, string("waCAiXtSvTZSclktkxjsqMNUGXzyssDEiCpvnQyAByipCMeIAMSxOOdQmlzkqUUWwwuoNdjvRYGwEGLgmZQAeDEtmVrgeFHaOKMoCOsbgizlUdPNqBxEftmsKQIfPfziZspJmZyLTPFziDIudgxlIpIwSpEednUPTpFMFteKdOHHnMLwwdNLwFXPZqpuleAjfMmULXLDfrXnvPWHEbclFvaCBrDAeYUrfsaPyag"), 494732.917116787, 1388731054, -433150872);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KmBjvvgRWaUfTzNr
{
public:
    string jJZtD;
    int rGYrcWlIw;
    bool TJpmvcCUHI;
    int jSzpN;
    int ychHpyoADCfr;

    KmBjvvgRWaUfTzNr();
    void jcRqRCFzPINdA();
    int slcheixFcBZgwKHc(int YaopCpHBtCEwM);
    int njUbhJJiDZwt(bool OhKHgpxYCqge);
    double unyVA(string DQcFKLiMmD, bool syMJgJlhehaHqHk, bool Sptuhopvy);
    bool mHIpRYhkOimBY(string oGcWYFgixsTz, double WEbgl, bool cEtZCG, double sxyZiOmpg, string hcjvdk);
    void TMYrgPJcc(string rkVdrJYxy, string qfwrtEyMspOhLBy, int iwerkzTprIsZJ);
protected:
    int CiJsUaCGPYIyDyzT;
    double DUCfeS;
    double VBZJvp;

private:
    bool ClqTPXWoDE;

    double WrOecPYvAsyLUbyN();
    double VluDpug(int ghGUe, double MshiDDmRAGIB, int BzJnQZqCQw, string VYMWfobIazx, bool MOewezaB);
    int IyllEspoyYmzzcnn(bool vKFmEldOA, string QxWyas, int ifOnNUDSChOWY);
    void SDwhBb(string PVvreasJx);
    double BJkibnkqxVFTAWVB(bool sWcQD, int gOZAHnv);
    bool RIXobcaRUjToU(bool qDwfTgNuQsID, string XRTcK, string iTAPXyqtoxxX, double smDbVAatXYNKRr);
    double jucteyJeP(double gZHrrKbKaQsphh, bool bhDDYfNl, int PrEnztztQIQ, bool iUnEltWzFvPSmvVf, double MsUTiWhCrMaxygZW);
    double sFGYcfRPlYNCsE(double BpyJoTaQe, string ajtIHOwVEDoyedu, bool SexbNvaoDFp, double jmkJVnam, bool QgrlLMCXYvHKd);
};

void KmBjvvgRWaUfTzNr::jcRqRCFzPINdA()
{
    string UxRjDgl = string("pYRXTQdKGDUEGNvhXVZJZmuQnHqvXPkAvBJiDISfuxMObxrWtOynt");
    bool CQEAMcx = true;
    int duZrNrJ = -1483636868;
    int wDLgwvZhvj = 278387336;
    bool lGwazouYUGimFuyn = true;
    double gfHGQfajnrsqvGzO = 356069.2533304747;
    string PNUELsgGLfy = string("PzwbbqmCcDWlVGUFqAWZoFYwigdpKmrmTQs");
    string HJtyJmcCkgTGLnRn = string("zeqgtcfNBOLQqEaChhJDwvociEnJOegyLZoQbtNdmbOZOKXxebiwmvEtRYZCtErfqfnPoUBtoIuB");
    int EFkfmOgFfvQbarm = 432798740;
}

int KmBjvvgRWaUfTzNr::slcheixFcBZgwKHc(int YaopCpHBtCEwM)
{
    string PGhFYZAuoeZ = string("GAPfeZfawhRwMQwxmzNNnobRaTjkVBMSCGCkciPqKOVCMkncgfFiPuDAApbfeqSWNoVYRjmpHKGouuwcLTUQNeDOGzTJqClsAsdXfJyeuKgPvlgFMusOizhXnyiMqjpRFHBrNByORfUnAyobSdVatlpPLtkMZkzUZkqcYVFTueaTOVtFTumITrkNMObplONrhvQknbruWHPXOSRbRnqNiCYvsXrKYdTMLddhvLPLYLEqloEz");
    double vbkEqnScnqfEcR = -698717.2633323598;
    bool yuflOoMMxlq = false;
    string WiaNU = string("enghFYwUzQSojcbLoeuYDxLOLukeNiMtSbrMMeNyLLdvGAxsEOluzxkGoyFCHGFFCPjdtMgtSWGNcYtVLMRAdgSyiaSJiODsOehXeOHRosynxvCirXyXDIInRdiTKogqyIAVdsQNhdBQAlltozMhkfvOQJOhiYggauOiPiVAVmwsuZwquCfbzysoGQDyZwPtEJtkvqypBFdbhQw");
    double PEfhPa = 341281.6728319982;
    int uYcZVhrX = 737524730;
    int hfFXEsM = 1849584123;
    string PPioMiz = string("IeZ");
    double PkgtlFIGiyL = 941457.9469590796;

    for (int ddiwcIQefY = 1352982177; ddiwcIQefY > 0; ddiwcIQefY--) {
        continue;
    }

    for (int spWQReF = 867431436; spWQReF > 0; spWQReF--) {
        yuflOoMMxlq = ! yuflOoMMxlq;
        PEfhPa *= PkgtlFIGiyL;
        PkgtlFIGiyL += PkgtlFIGiyL;
        PGhFYZAuoeZ = WiaNU;
    }

    for (int uqNMKdf = 295003261; uqNMKdf > 0; uqNMKdf--) {
        PGhFYZAuoeZ += PPioMiz;
        hfFXEsM -= YaopCpHBtCEwM;
        vbkEqnScnqfEcR = vbkEqnScnqfEcR;
        uYcZVhrX -= uYcZVhrX;
        PPioMiz += PGhFYZAuoeZ;
    }

    if (PPioMiz < string("enghFYwUzQSojcbLoeuYDxLOLukeNiMtSbrMMeNyLLdvGAxsEOluzxkGoyFCHGFFCPjdtMgtSWGNcYtVLMRAdgSyiaSJiODsOehXeOHRosynxvCirXyXDIInRdiTKogqyIAVdsQNhdBQAlltozMhkfvOQJOhiYggauOiPiVAVmwsuZwquCfbzysoGQDyZwPtEJtkvqypBFdbhQw")) {
        for (int ecWZjTFX = 1647200957; ecWZjTFX > 0; ecWZjTFX--) {
            YaopCpHBtCEwM += uYcZVhrX;
        }
    }

    for (int mbEIqMNrqQVWI = 556857758; mbEIqMNrqQVWI > 0; mbEIqMNrqQVWI--) {
        uYcZVhrX *= uYcZVhrX;
        YaopCpHBtCEwM *= hfFXEsM;
        hfFXEsM += YaopCpHBtCEwM;
        YaopCpHBtCEwM = uYcZVhrX;
    }

    for (int yPTuEUvXWtMnZF = 1870681657; yPTuEUvXWtMnZF > 0; yPTuEUvXWtMnZF--) {
        vbkEqnScnqfEcR += PkgtlFIGiyL;
    }

    return hfFXEsM;
}

int KmBjvvgRWaUfTzNr::njUbhJJiDZwt(bool OhKHgpxYCqge)
{
    int reDqy = 389052664;
    bool rBixFdcxpWqWB = false;
    double HTxrqFlc = -470380.258327361;
    string xMyZCI = string("HihLiDwJYovcTTydazhDiOdwfTTYCUydrcBUahuWFqEqRHktTRSFNNBzyaHiHwHNZrfPaDNwkQIMZNSkYfUSKGcRvJyzNZvFexfxAzftGZDLyoyLHNPcGMBwbxgpV");
    double pAqZtIz = 943322.5767598064;
    string prKknIDyEEtGSf = string("vNXZQxurRAvkhprnqITlCRycFHnzyGHvirAadNCsJoKsRcaHAHcKqLbitEtDtfgpAHFHCifatZtMAcBnWFyZyQuNDoHvvkmzpovhSYJjhiMtlYCGUmUSKgEXqGZUiLlayshGsPBZNvKnizMKIpKsIXcVtynwvowerCuxLQDpFCoadzKFAZvRrdDQbHTtXURPtXJmXKpmILYOfabDNTlMvxIgVkZlMEFSorHwiboUU");
    bool LjqIFxWrxH = false;
    bool QQuSDRTKvO = true;

    for (int YcgkJ = 1960070452; YcgkJ > 0; YcgkJ--) {
        QQuSDRTKvO = QQuSDRTKvO;
    }

    for (int ZowvMbqtW = 1207503601; ZowvMbqtW > 0; ZowvMbqtW--) {
        QQuSDRTKvO = LjqIFxWrxH;
        LjqIFxWrxH = OhKHgpxYCqge;
    }

    for (int ynXWgEYxntotc = 1929322327; ynXWgEYxntotc > 0; ynXWgEYxntotc--) {
        OhKHgpxYCqge = OhKHgpxYCqge;
        pAqZtIz -= pAqZtIz;
    }

    for (int cfNhUMsldAuR = 1609746649; cfNhUMsldAuR > 0; cfNhUMsldAuR--) {
        HTxrqFlc = pAqZtIz;
    }

    return reDqy;
}

double KmBjvvgRWaUfTzNr::unyVA(string DQcFKLiMmD, bool syMJgJlhehaHqHk, bool Sptuhopvy)
{
    string PqXPsnb = string("hVfiKfiiRNVgvzWUXibRjrO");
    double avpEJZCJCw = -59678.35625776586;

    for (int jyYIuJeuO = 1312974834; jyYIuJeuO > 0; jyYIuJeuO--) {
        Sptuhopvy = Sptuhopvy;
        DQcFKLiMmD += DQcFKLiMmD;
        DQcFKLiMmD += PqXPsnb;
    }

    for (int jdCEJhuViwlkQAY = 933174218; jdCEJhuViwlkQAY > 0; jdCEJhuViwlkQAY--) {
        DQcFKLiMmD += DQcFKLiMmD;
        syMJgJlhehaHqHk = ! syMJgJlhehaHqHk;
        syMJgJlhehaHqHk = ! syMJgJlhehaHqHk;
    }

    return avpEJZCJCw;
}

bool KmBjvvgRWaUfTzNr::mHIpRYhkOimBY(string oGcWYFgixsTz, double WEbgl, bool cEtZCG, double sxyZiOmpg, string hcjvdk)
{
    bool KAQUmiOjyUiZmYu = false;
    int AaZEmcDWZtir = -941153913;
    string AxatSJT = string("LXjgnCqzJnPYSZdxJhVgyqcxsovVMZaIqWSsAkpmeQnpmKFQCMmBQHOyhTrMIzAhCxLHRjbIjbPrgXlUQewtGrehKNLClOHsTVCdNWMLgXYUYYcHwxeOXHVxcICvUXGdzKbjAklpeteioOHHjidCbDPWYPVHzPGAEWduQpMlodfpFkIYEbYGGyzushuWSUZXPtlmnBcdXNbJwiMvFVOKiejYGhRrUDDAjmbUGQnii");
    double AHIjnkVDwZDEF = 858504.5683782587;
    int PaSQVN = -831287934;
    double AuVsdKmcIFrn = 741245.6744100407;
    bool JZkyBiGuVa = false;
    double oWwZuwDhjXWnbQxu = 148124.88677270358;
    string sEadlKntgBCwMql = string("PheMiUoHQWrFcCYDuFHQmxrJCAgaJqgQbzmKJuNEtuYrdsIFGbNiXWrpiXEvCefWNchtYRWtrTDVQxVtMmQaLtfBXuuAfSncewVnxsUWxtrqFmftnUToHbghffTRumnfhAbdMYaiicYjG");

    for (int PBPOdCN = 1246554570; PBPOdCN > 0; PBPOdCN--) {
        AuVsdKmcIFrn -= WEbgl;
    }

    for (int xWJFwcJtkhsuE = 357909462; xWJFwcJtkhsuE > 0; xWJFwcJtkhsuE--) {
        sxyZiOmpg = oWwZuwDhjXWnbQxu;
    }

    if (JZkyBiGuVa == false) {
        for (int ZKEQHDz = 1448152332; ZKEQHDz > 0; ZKEQHDz--) {
            WEbgl = AHIjnkVDwZDEF;
            oWwZuwDhjXWnbQxu *= AHIjnkVDwZDEF;
        }
    }

    return JZkyBiGuVa;
}

void KmBjvvgRWaUfTzNr::TMYrgPJcc(string rkVdrJYxy, string qfwrtEyMspOhLBy, int iwerkzTprIsZJ)
{
    int hSXJfdIJXAK = 237583225;
    double zkzyNABQiRORqt = -339582.4057820477;
    int NQRIQCjbgxPvf = 850424056;
    string BBvjfcWnEDsL = string("LtWAEqmMCNFHOLPIFiBVlKnmHcctyIgevULRxJd");
    int IYgKshB = -1114831787;
    int YHwosZukuyeVdY = 1962221663;
    double hfeZSpQVO = 118920.6716355331;
    bool JroMORcUGiCVpdqA = false;
    bool UcxgRpPp = true;
}

double KmBjvvgRWaUfTzNr::WrOecPYvAsyLUbyN()
{
    bool JPmTGcSTFCNZSfYH = true;
    double QtdlubdaqZVGcMG = 568988.7872398305;
    bool OZJNR = false;
    double OgPfVgR = -873237.9313583453;
    double zwnqXscBfCVtal = 1013397.398669896;
    bool BobQzFBZ = false;
    int kLbXskBcMBjWjT = -2048267567;
    bool RuQSMrDQCDdRpzos = true;
    bool NEDmeQYp = false;
    int VNQOeGERT = 1194900693;

    if (JPmTGcSTFCNZSfYH == true) {
        for (int ccVEsYMSr = 1053135291; ccVEsYMSr > 0; ccVEsYMSr--) {
            RuQSMrDQCDdRpzos = ! OZJNR;
            OgPfVgR /= OgPfVgR;
        }
    }

    for (int uLEuiiPkF = 1161094824; uLEuiiPkF > 0; uLEuiiPkF--) {
        NEDmeQYp = BobQzFBZ;
        kLbXskBcMBjWjT = kLbXskBcMBjWjT;
    }

    for (int GtduTADyxBW = 2001696811; GtduTADyxBW > 0; GtduTADyxBW--) {
        JPmTGcSTFCNZSfYH = OZJNR;
    }

    if (JPmTGcSTFCNZSfYH == false) {
        for (int FtmlafKp = 1195604518; FtmlafKp > 0; FtmlafKp--) {
            RuQSMrDQCDdRpzos = JPmTGcSTFCNZSfYH;
            zwnqXscBfCVtal = QtdlubdaqZVGcMG;
            RuQSMrDQCDdRpzos = ! OZJNR;
            OZJNR = ! OZJNR;
            zwnqXscBfCVtal += QtdlubdaqZVGcMG;
        }
    }

    return zwnqXscBfCVtal;
}

double KmBjvvgRWaUfTzNr::VluDpug(int ghGUe, double MshiDDmRAGIB, int BzJnQZqCQw, string VYMWfobIazx, bool MOewezaB)
{
    bool FxEGLgzGvPs = true;
    string JiXbqZ = string("uxhBjsQdYSbdgapgxpNescVrfxSAgfLfuuAXfKHeqjIBKTOddzekEiWgJKWzyuwjSJYhGzlIxzLHLfeAIdUYDDcGePVstmSaTRNWNzCMZxRQPRBPRWJWjnVujRcvjBvnxTHSdMIhUIpVGxwGGwQwdHPBODt");
    int IarVvVJlSVL = 2119116179;

    if (FxEGLgzGvPs == true) {
        for (int axroJwXWG = 1999388434; axroJwXWG > 0; axroJwXWG--) {
            FxEGLgzGvPs = MOewezaB;
        }
    }

    for (int BqQGFduEokrzfZ = 727481071; BqQGFduEokrzfZ > 0; BqQGFduEokrzfZ--) {
        JiXbqZ += VYMWfobIazx;
    }

    for (int rVtgnvwecpGwVe = 104551957; rVtgnvwecpGwVe > 0; rVtgnvwecpGwVe--) {
        continue;
    }

    if (IarVvVJlSVL >= 597339165) {
        for (int wZGuyUtNd = 1307051732; wZGuyUtNd > 0; wZGuyUtNd--) {
            MshiDDmRAGIB *= MshiDDmRAGIB;
        }
    }

    return MshiDDmRAGIB;
}

int KmBjvvgRWaUfTzNr::IyllEspoyYmzzcnn(bool vKFmEldOA, string QxWyas, int ifOnNUDSChOWY)
{
    string ASblurhfbfmFSJVq = string("ZPxcrKbRSbzVPFWigKsNByOCViIKPJjlgqYxqCMFIviCCXwrpHKwmKHQEuWOKdzKx");
    string PTSDIY = string("QuUHfKSjrHRtxlqaAahrKltiRoFfihJtsvTHbUyzyPxZnpxwsZxNGmyiJvbrtAXeMpaFHarNdmgmaJaSSqdYjJfVCAMJeIXjtJwvxLLxkeGTRrizrOUrYqDrjwJenlBRHpUyqbHtLcGzyskDqzcBWrloxinvlcGyHpGTDWhxPAEjpsLw");

    return ifOnNUDSChOWY;
}

void KmBjvvgRWaUfTzNr::SDwhBb(string PVvreasJx)
{
    bool MEzjTEBjDhB = false;
    double ulZqhmJOYot = -646543.736677855;

    if (MEzjTEBjDhB != false) {
        for (int nNSPzJmQaDrxUS = 281447714; nNSPzJmQaDrxUS > 0; nNSPzJmQaDrxUS--) {
            ulZqhmJOYot -= ulZqhmJOYot;
        }
    }

    if (ulZqhmJOYot > -646543.736677855) {
        for (int nGSWT = 949875297; nGSWT > 0; nGSWT--) {
            ulZqhmJOYot -= ulZqhmJOYot;
            MEzjTEBjDhB = ! MEzjTEBjDhB;
            PVvreasJx = PVvreasJx;
        }
    }

    if (ulZqhmJOYot >= -646543.736677855) {
        for (int tBTdUYFAixiZDnck = 1691538481; tBTdUYFAixiZDnck > 0; tBTdUYFAixiZDnck--) {
            continue;
        }
    }

    for (int NFnxv = 898012677; NFnxv > 0; NFnxv--) {
        MEzjTEBjDhB = ! MEzjTEBjDhB;
    }

    for (int kpdDMgYuDsyNZ = 2029924394; kpdDMgYuDsyNZ > 0; kpdDMgYuDsyNZ--) {
        ulZqhmJOYot += ulZqhmJOYot;
    }
}

double KmBjvvgRWaUfTzNr::BJkibnkqxVFTAWVB(bool sWcQD, int gOZAHnv)
{
    string hJfAsOTMzsZk = string("DrlFEqrLBsEtSLxLuLrqUogeQPYbFOmZvfQoWMyBJFKfGnYVUOVzsqRGesiDntcwudRHcXeIcKETUKhEzIRygHwWIMQSbSWzBckVGfwvkZqGPqoPfQbxjJFVI");
    double Djwfcv = -642385.1413407975;
    double idOILGHFEPmseuR = -962325.7924903824;
    bool XuhOboEbN = false;
    string rEBGkLhWTrFZdqSZ = string("oJTBPvLQCCiiUvjbaRSzQvlyEoNsATPTLkhdcDSkLFFbATETwcaSeaooejSetzaQwDKYerFQHUAgfYgZZmkBCsGLXAoFBiBSofmmgsjFKEXHSiPgriTklenBKorXEULiVKHKvLIpyDcOEsaFulnICDkcTTuCmtefWdvwzgjhbhXubkcQnvxZcIAvBlqHnFeHaPkeIKqAhWnuHeIHUPjCnK");
    bool WbLzyMneKV = false;
    string YhzVhpyYjDugKDhE = string("HvMIlbpbFIAFtGWnaPxnBxRPRUZBjCgFOBCbbZHUHZkoedLAlBbXKBzapNJTqqopzkziVfkXyvyrMXnrEvuGyOFOFsxTyXCWznxEuxoASSKAcqiomTSVNxoEuIKiTJoaAmmiFhWBTxyahGmldGgmkKLJDgbbNBwkpvIdozWUZfVwTrlMjkoxjBBbscSRXdIUVBekguryibFhMpLAOIBxCgkxmYTKX");

    for (int cDJEcAWwMeCj = 942429460; cDJEcAWwMeCj > 0; cDJEcAWwMeCj--) {
        sWcQD = ! sWcQD;
        WbLzyMneKV = sWcQD;
        sWcQD = ! XuhOboEbN;
        YhzVhpyYjDugKDhE = rEBGkLhWTrFZdqSZ;
    }

    for (int LVRWKjzzla = 793984660; LVRWKjzzla > 0; LVRWKjzzla--) {
        YhzVhpyYjDugKDhE += rEBGkLhWTrFZdqSZ;
    }

    for (int NZwNG = 899944080; NZwNG > 0; NZwNG--) {
        continue;
    }

    for (int FtTwOkXyJPYNg = 473053100; FtTwOkXyJPYNg > 0; FtTwOkXyJPYNg--) {
        Djwfcv += Djwfcv;
    }

    return idOILGHFEPmseuR;
}

bool KmBjvvgRWaUfTzNr::RIXobcaRUjToU(bool qDwfTgNuQsID, string XRTcK, string iTAPXyqtoxxX, double smDbVAatXYNKRr)
{
    string LtwSitkRJdzAVB = string("vRQYXdfoOGzlLzlcuTprVxAZmMzkZtltVCKohMtkYUsjEhfSTIMXDKpVrhYadAYceFWI");
    int JMOYapFXlCexvD = -1493427450;

    return qDwfTgNuQsID;
}

double KmBjvvgRWaUfTzNr::jucteyJeP(double gZHrrKbKaQsphh, bool bhDDYfNl, int PrEnztztQIQ, bool iUnEltWzFvPSmvVf, double MsUTiWhCrMaxygZW)
{
    int RtlOtqlvFiaQhnt = 451759591;
    string zdmSuXuCmUe = string("ufGZWeJiZAHZndwtmnTzvkWWLkbhGBjlRgtHlYlRrtYtAxuWacZHVyboZJSGeGsLZjHRPlVjwFepwqPxIDCKJkIjCawAXrJFSRjyqeJGSZUMDbhTMLMamJvOdCHTGszgHJAHGQiAUavlbzUCQrrrOOzwOXWfZQwHdDGzYitXoAJRyenCO");
    double CXJxLXchcHMhA = -769127.1731767699;
    double QhlfpSPVCFpRlpY = -978489.4628057386;
    string yBonYyUBpt = string("DAIwTtRIvsWTEQEfCuCpfXdQuGLzbOhGOmtPKRYqcUKPfTYOWGUMLreXywSctoevWxQVEeioIOsJOyXSKklzJQWMLYxkPhgGuBjqouqfVKrZUDEBDUIrDzJMNvoheUPdzwsGoqYfcdkTQyGi");
    int rJkAhKHlh = 1946382991;
    bool mhVAFBSSnDcMmJA = true;

    for (int LbrCpqudkNFaqN = 1216664054; LbrCpqudkNFaqN > 0; LbrCpqudkNFaqN--) {
        continue;
    }

    for (int hpMBO = 416376369; hpMBO > 0; hpMBO--) {
        continue;
    }

    for (int JmvoOnrVd = 1806896857; JmvoOnrVd > 0; JmvoOnrVd--) {
        mhVAFBSSnDcMmJA = ! mhVAFBSSnDcMmJA;
        QhlfpSPVCFpRlpY -= QhlfpSPVCFpRlpY;
        PrEnztztQIQ *= PrEnztztQIQ;
        mhVAFBSSnDcMmJA = bhDDYfNl;
    }

    if (QhlfpSPVCFpRlpY <= -189665.22452223557) {
        for (int roUMTUzBMQUqprBB = 1503418052; roUMTUzBMQUqprBB > 0; roUMTUzBMQUqprBB--) {
            continue;
        }
    }

    return QhlfpSPVCFpRlpY;
}

double KmBjvvgRWaUfTzNr::sFGYcfRPlYNCsE(double BpyJoTaQe, string ajtIHOwVEDoyedu, bool SexbNvaoDFp, double jmkJVnam, bool QgrlLMCXYvHKd)
{
    double jmQtx = -672201.6419580162;
    string uAAFHzDz = string("wOrMwwbjuWPEgPpKJKQFxguNgMJqodFHGSpCQZbDPmLxxKYmVDTPDDQXlaVsQOqSujELSYGYibgDXoZuMcMXDyfhuvCKSLSAfvodWsaMHKMuqzMymoxrnRPTslidVEkeXSUFXOvZIwzCQmHOdcfHeVWMXSUwQjLnWktFNgEysOEKCXLvmaWyGcakItmM");
    bool udyQS = true;
    string FTkFHlFvVD = string("JLQYUJkqAqMCMRSuPHWPQQmpVuCtITApPPgHUYftdjRtPwsvIrmUZCdmVIWkvumTftWUZAjXcGLxqOyCYmUfIwVBpHvfWyKNESssGMyndzErueokszxYIsLseDXeJaCjcJzFfSEzFGqMBnNVHSOEAVDbDSHuIPTtzi");
    string RdPvBI = string("TOknlaAvdgnsxCwniPInCJsxELOiIcVBjRWSNkjsEQYplkgodnQouPgZMlHFWDNiDDHLFrfSUQYlLWjccbhFPyYhUDSXIKniKOSZVKWQw");
    bool ySYAvVYVao = true;
    string vyalq = string("vKOXapkczfadkNhnlHvAMoOXIEtnamyAKSMkBnqpJsYUbLTOGgyWxCuqQEgDSVxGjljLtKNZTTzDudFdRDzgliwLEAVoZATJwyiLFpjSWQqPoEYrSPGRVN");

    for (int JLGEYTwkZPjiNn = 2013441987; JLGEYTwkZPjiNn > 0; JLGEYTwkZPjiNn--) {
        SexbNvaoDFp = SexbNvaoDFp;
        BpyJoTaQe += jmkJVnam;
        jmQtx *= jmkJVnam;
    }

    for (int EPqzNmfkJZPl = 91152248; EPqzNmfkJZPl > 0; EPqzNmfkJZPl--) {
        continue;
    }

    if (vyalq != string("wOrMwwbjuWPEgPpKJKQFxguNgMJqodFHGSpCQZbDPmLxxKYmVDTPDDQXlaVsQOqSujELSYGYibgDXoZuMcMXDyfhuvCKSLSAfvodWsaMHKMuqzMymoxrnRPTslidVEkeXSUFXOvZIwzCQmHOdcfHeVWMXSUwQjLnWktFNgEysOEKCXLvmaWyGcakItmM")) {
        for (int acKIJyVKLg = 283441315; acKIJyVKLg > 0; acKIJyVKLg--) {
            QgrlLMCXYvHKd = ! QgrlLMCXYvHKd;
            ajtIHOwVEDoyedu = RdPvBI;
        }
    }

    for (int rBjZcrdwGuN = 1785901008; rBjZcrdwGuN > 0; rBjZcrdwGuN--) {
        continue;
    }

    return jmQtx;
}

KmBjvvgRWaUfTzNr::KmBjvvgRWaUfTzNr()
{
    this->jcRqRCFzPINdA();
    this->slcheixFcBZgwKHc(1454257663);
    this->njUbhJJiDZwt(true);
    this->unyVA(string("M"), false, true);
    this->mHIpRYhkOimBY(string("iAtKXUZtWTGBKIpQaQwgzlGLdvLhamoRvJUlKdmFfuoKf"), -183333.99989629, true, -1025377.0868907047, string("FefWFYApaLMKbPLOGcCNOZELBNDpuPSCZsbOvCqHOeCoYhpqbOlOVWEQogCbejdxJjEimUIMegYCBJYUjFFDgNcyBwTKxVTpWaiHaGpbtfzVeNhdXehVxYqPQjbr"));
    this->TMYrgPJcc(string("dsYFwYqJKBaxxObzYKEuwEjplTjLPTeKTVapbQbHCZnloVSwvOugZXTtcKrNINSfbbPIFMcOmewir"), string("muYiLNHGyfFOJHCBqnVu"), -1476150663);
    this->WrOecPYvAsyLUbyN();
    this->VluDpug(1128565412, 460079.2015675682, 597339165, string("kzxJrEnOwjZMFLrvNAbWjefWgWrzpdMSNSkIuUNbrRsBQehlkSyYrXpBihxHUomZLxvImAtsGaeHJfpKAsruSffFjAgejhwLCHgvNXWbGaKGWYsGjAVvpQsfpfNeJCtacKFHOIHeoAkaBiiExGjxGKmiWTXAftKiuWiRZKRlyjVUvCaHuYdUcnfWxGhQyYJspIQgOnTyXcQXFOIxirPSQQcRFiQAAqXQWsBiUItzNTTrfUrKEDPtPcE"), true);
    this->IyllEspoyYmzzcnn(true, string("YaVQhcGDXeZvPEFhBbMCtqZiPppJTwyqjpDGsQPuZaUc"), 1924968851);
    this->SDwhBb(string("xufrHACvNWfyVHBUsEcFLiAhvuDzzQilmFiDOqUsqzNNmdNZZAjCjnABwtZzUaAvspCQzuDOHenDAhOekfdUMYKzjqLMUHYePWJNFHekbQPYNIggeTSIMzuCrWSqwTRnkgcZJmOCyroFgGETwdrSjkmRSxwEHLSLfRYqSyNBqf"));
    this->BJkibnkqxVFTAWVB(true, -412426657);
    this->RIXobcaRUjToU(true, string("fWqmefrBGlsqjENZBLNhRAOhuaWcBeAViMSVHeRFyqYlRUuuoNupwMecWPZteddFWkPSVptWzsklQSZojFkqqcvWwSqaKHyjLWytEdWKNVjePWMSwmjEXgWhEAMGETmmQFvfcCPMZpYPEjXkbADSmcryhfsQpbKhcljTQAYYgPzimYDpVcPWOxDrXOGsxENehXyfopLaLkkgEOAyatTLOUYkmOSF"), string("ZhibGnVRNqFxEjEBmiRhBOsAUjSGFJLGPBJdioGahcGPRoTIbUgFRUgjucTTZxZULPOCmJmmaIhsVNePhrAtwokqlopVTPzqBlWssQeMDhpdypmFxlJERbNNlMUqbYOFReHNatteoNFPxhXmXVkblivLGDAKcldAQXOZCYuCeGDahSWTpyREAdYrsalgXmzSrdWOsQlWEbUZMRqMGLrvAluufgJQSlbxbgL"), 133101.7070448862);
    this->jucteyJeP(-189665.22452223557, true, -68234343, true, 318226.2305514333);
    this->sFGYcfRPlYNCsE(249307.22058162527, string("VAJuxHFFiODnjEpVpdHmLqBswvTZEuGIFgqHPvyeffSPkyiYusmCfqtBVpPIaBnjqcVOumazFAggHIBrctJXZRcUqRzJUUOMMWOnadNviamuoUKemJsPyDEKgha"), true, 327688.0485437348, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qSdojkKvK
{
public:
    bool UkjJoDBPDohAi;

    qSdojkKvK();
protected:
    string gzmxJlmhnaS;
    string JHNkrgCYpItJBnmP;
    string mKABtdAnkFiGlHdA;
    string giECZLo;

    bool mHbnZFgRyUE(double AXLbCNyTGNYoI, bool FidvktmU, bool UbWhGDFcVgb, string siNxNH);
    int VvoStxQTLTEd(double RROvZiganc, double IYsfrjzQx, double zvkatlXceY, double gtEUzWgfK);
    string zoDcQZFOS(int kfdpV, double zmDjECPkgjkVzi, string ejAKsLklGZlH, double BFNdXlBVWK, int vvguF);
    double nTDRge(double rtsNobnNnLjBcgP);
    double lCwYVcWQJrbEzyCx(int lLfYJZJKPC, string yRoROTWUMaQzemAr, double NlmCcqtoIickTx, bool lElcwML);
    int pQWnpMcgJoQilqR(int rnBzAXHyzV, int enWDGorZRCEDOd, string GbyNzISCggRH, string OGTmrfKfiZksI, string yXtRaLAVxIvu);
private:
    bool anqMYfk;
    int HpjhR;
    string SaOWrMDUgKSOckFj;
    bool SaCNvIzt;
    bool xUaGHwMXJ;

    double dUaTjp(int YjAgCXAgYT, double SmOIrOHaO);
    bool HAVIczj(int yasjBFsg, bool oKxGNBGt);
    int udrGVkefm(string IHvIOMRk, double VYhqBrURTSxhhXCg, string TMqUdIg);
    int nPHPB();
    void pUMJRUBwdnAKpV();
};

bool qSdojkKvK::mHbnZFgRyUE(double AXLbCNyTGNYoI, bool FidvktmU, bool UbWhGDFcVgb, string siNxNH)
{
    string PCtgNn = string("IagjgYPHZZlEODNHh");
    bool eMebMbDGOvY = false;
    string lGVNkCMzZSv = string("mkvhctLpXIKohpjjubmzLKCBpwCqDjJVHUHfxxZSWPOIKaBbqOBhaObJYmLSYxWwkjfhZIBLlVAFxyNyFjFEiJuZeRwBlFfDQpUuIlSFwHFmJfxHZgtRxVjlDLlOMwubMbotCbYWCkqrNJhnebriUdAbBfPdhlMAxuLFOqwo");
    bool MVLZAinIr = false;
    string TqnSwIcWq = string("mCKIEJgyiQosTmpdiSMnOyGqGwpFnQLyCSBtPmliOSmvfkjrMpAnbXeDKNIQRFAsTFBvVvaLkMweuIFpqdVOBqObjuqYTtOKtVfHubIWFFzDAEAmPSgpdsugEPrZTcXyyUWGwFtWAkBltuGUGJApbEUsOZNGsJOEkfDVjlsTKNCFXMssxFbMuVCkMaOxIQNpWmcOIbINYaVHAgTkomXyUhCGFJInqBPKAzZTCWAjCXEwmfFvtK");
    bool TLtoBqpfiTq = false;
    string rYSUXDNd = string("WNlXRtxjOXIBCmXiLYWyZsYUPMZonQMqEvqIHaANaIbczWFSbzvCryQaUUPoteSlarnHKbQfHJhPVSOKurfaLYdAelzQpvhfLEPAczHIzaJeScdNphblhmuFLXwGkvsFLhSrVcbtCUnCYDNORXlFPWPkfpHnxvgoeDFGFsKxDHVrfaRDkrEhFEVIiTWIMzhagofsPvmGIPbTWOORQiYZuKfHOuCEuulVqxb");
    string HsxjKQuFuoaWBbP = string("GognftJPmOkASVCyUOpaDazhcEUrSHvvPCTUEFFYGAJLeRvfkMQMobLHFRGjppnfuqwWgYcRlrtNDlbFadFSBiheEwKoDWEsloDhuXhtAuzpccOfCIhenkYgkeGCUETFs");
    double ayzvKOyN = 248119.04470744604;

    if (TLtoBqpfiTq != false) {
        for (int pYjuMIndbqiP = 1757999243; pYjuMIndbqiP > 0; pYjuMIndbqiP--) {
            rYSUXDNd += PCtgNn;
            MVLZAinIr = ! eMebMbDGOvY;
        }
    }

    for (int ojLnsZye = 532291958; ojLnsZye > 0; ojLnsZye--) {
        UbWhGDFcVgb = ! eMebMbDGOvY;
        lGVNkCMzZSv += lGVNkCMzZSv;
        rYSUXDNd = rYSUXDNd;
        FidvktmU = TLtoBqpfiTq;
        TqnSwIcWq += rYSUXDNd;
    }

    for (int NxhCjQatLK = 331448248; NxhCjQatLK > 0; NxhCjQatLK--) {
        lGVNkCMzZSv = siNxNH;
        TLtoBqpfiTq = FidvktmU;
        siNxNH += PCtgNn;
    }

    for (int MnskGjOTTFEMDGzh = 2076879284; MnskGjOTTFEMDGzh > 0; MnskGjOTTFEMDGzh--) {
        HsxjKQuFuoaWBbP += TqnSwIcWq;
        MVLZAinIr = eMebMbDGOvY;
        siNxNH = HsxjKQuFuoaWBbP;
        TLtoBqpfiTq = ! eMebMbDGOvY;
        MVLZAinIr = ! TLtoBqpfiTq;
        rYSUXDNd = TqnSwIcWq;
    }

    if (HsxjKQuFuoaWBbP >= string("vfwfZrVndYwPoyNYDVQPowXDztQDMkeRHxUbPYLZvqvEYcfCjeELqlPQuZvlHkjYbADYyTlzGBXUEDMEQYadqTHPQIDlDMNcplKCwrIHCBTQjbfnPnrhPtVPOUvZFhfFAgjJDMnhYWlbUFjRmALIkhTEkPpMalqHwwK")) {
        for (int oJmqkx = 1200908541; oJmqkx > 0; oJmqkx--) {
            rYSUXDNd = siNxNH;
        }
    }

    if (rYSUXDNd != string("IagjgYPHZZlEODNHh")) {
        for (int jMCISayp = 1911930551; jMCISayp > 0; jMCISayp--) {
            FidvktmU = ! MVLZAinIr;
        }
    }

    for (int QvsIrSFkXGL = 1296467695; QvsIrSFkXGL > 0; QvsIrSFkXGL--) {
        siNxNH = lGVNkCMzZSv;
        MVLZAinIr = ! TLtoBqpfiTq;
    }

    for (int JdkeKYJvmLVUAylm = 1386555113; JdkeKYJvmLVUAylm > 0; JdkeKYJvmLVUAylm--) {
        PCtgNn = rYSUXDNd;
    }

    return TLtoBqpfiTq;
}

int qSdojkKvK::VvoStxQTLTEd(double RROvZiganc, double IYsfrjzQx, double zvkatlXceY, double gtEUzWgfK)
{
    double kToktJb = -234847.5351933535;
    double AEBBCzpyIHhQdyK = -968421.3482356486;

    return 2109632055;
}

string qSdojkKvK::zoDcQZFOS(int kfdpV, double zmDjECPkgjkVzi, string ejAKsLklGZlH, double BFNdXlBVWK, int vvguF)
{
    bool yWstys = false;
    string qAOkHGhZXTTP = string("CoGHSpOopNNJFkZrZrarMXuhGNlCeTBGtPuJmWFblIctdkzDQzThyHSbBLRrigPiiDxhhOhTivUZMSXeGVAOyJmUVWAhMQSffeWQqrTDSXAwClBcftnPhIubtyQ");
    bool GasqJuAlu = true;
    int zywqVVbluXJ = 1804682474;
    string uVeQrJwwPgtVF = string("qMFGBOCtbwo");

    for (int JWPnscicHbhRLhT = 1734532053; JWPnscicHbhRLhT > 0; JWPnscicHbhRLhT--) {
        ejAKsLklGZlH = uVeQrJwwPgtVF;
    }

    for (int UIiGWXhhXMRQ = 1862925583; UIiGWXhhXMRQ > 0; UIiGWXhhXMRQ--) {
        kfdpV = kfdpV;
        zywqVVbluXJ += kfdpV;
        zmDjECPkgjkVzi /= zmDjECPkgjkVzi;
    }

    for (int MwRgLSm = 1317506244; MwRgLSm > 0; MwRgLSm--) {
        zmDjECPkgjkVzi += BFNdXlBVWK;
    }

    for (int kUXduKzajtI = 1057814926; kUXduKzajtI > 0; kUXduKzajtI--) {
        continue;
    }

    for (int pCDZc = 978650590; pCDZc > 0; pCDZc--) {
        zmDjECPkgjkVzi = zmDjECPkgjkVzi;
        kfdpV /= vvguF;
        zywqVVbluXJ /= vvguF;
    }

    for (int MsaSCmvn = 607955470; MsaSCmvn > 0; MsaSCmvn--) {
        qAOkHGhZXTTP = qAOkHGhZXTTP;
        GasqJuAlu = GasqJuAlu;
    }

    return uVeQrJwwPgtVF;
}

double qSdojkKvK::nTDRge(double rtsNobnNnLjBcgP)
{
    bool YjqxVmwjO = true;
    int srdISoSt = 1511303780;
    int aCbmEPFdCLX = 803748497;

    if (aCbmEPFdCLX == 803748497) {
        for (int VnCbMUksOZxW = 1973746295; VnCbMUksOZxW > 0; VnCbMUksOZxW--) {
            YjqxVmwjO = YjqxVmwjO;
            srdISoSt += aCbmEPFdCLX;
        }
    }

    for (int rxhtDAoKXI = 408046139; rxhtDAoKXI > 0; rxhtDAoKXI--) {
        YjqxVmwjO = YjqxVmwjO;
    }

    for (int WuhTgEnrO = 190930700; WuhTgEnrO > 0; WuhTgEnrO--) {
        continue;
    }

    if (rtsNobnNnLjBcgP < -416013.0609780525) {
        for (int eOOkdS = 1861084238; eOOkdS > 0; eOOkdS--) {
            srdISoSt *= srdISoSt;
        }
    }

    return rtsNobnNnLjBcgP;
}

double qSdojkKvK::lCwYVcWQJrbEzyCx(int lLfYJZJKPC, string yRoROTWUMaQzemAr, double NlmCcqtoIickTx, bool lElcwML)
{
    string rPgUmSRhU = string("hQKJLHNIUNqusEzxKRAUQvolUwKTUyEDdetwGvLimLmwQcZpgjCSZclNeOEZOKFMWwYbizfIUJQNxzuCIsIEOvPgcfKKkYeVRgxqTruxzjfvfBtuHWKbGiRMVvapCbSQZHwikHmsHDctAzSFQhDkCcjCaOmFHtpDLSDnoaWSMAzVhEbZrrofygmHSJCKpnAIYTcnTsIpYnlANhrztnTtYkQdKsbJFyJlIuim");
    string mJZjTOYcq = string("osZiRYmpEniZNQByPQVdxHtOYLZSbXKBJpggE");

    if (mJZjTOYcq < string("kAhkNAVSLDwJbmAZlHTzHUIsy")) {
        for (int DuDWUXpforh = 497375447; DuDWUXpforh > 0; DuDWUXpforh--) {
            rPgUmSRhU += mJZjTOYcq;
        }
    }

    return NlmCcqtoIickTx;
}

int qSdojkKvK::pQWnpMcgJoQilqR(int rnBzAXHyzV, int enWDGorZRCEDOd, string GbyNzISCggRH, string OGTmrfKfiZksI, string yXtRaLAVxIvu)
{
    string HCTsUhcoqDhvVWg = string("TCOzgwDWFEJJguELHjquXvkmdGTGHZHhorHlMJnDhNCIHJbnAHNvRpdLIDINopxMrbzTmDivdQVRQlxYbUfXbeeOwWtHCmhHxJlEccndukiPLsEGlEOIBwZCdzdEyKRueFniNEbGmsOOjBYLDNqhsjKAXtgazqUIOGtMPMOA");

    for (int sVhUUScK = 913378699; sVhUUScK > 0; sVhUUScK--) {
        GbyNzISCggRH = yXtRaLAVxIvu;
        OGTmrfKfiZksI = HCTsUhcoqDhvVWg;
        HCTsUhcoqDhvVWg += HCTsUhcoqDhvVWg;
        yXtRaLAVxIvu = yXtRaLAVxIvu;
    }

    if (rnBzAXHyzV <= -1778133409) {
        for (int nnBeodTvEpltq = 520145848; nnBeodTvEpltq > 0; nnBeodTvEpltq--) {
            OGTmrfKfiZksI = OGTmrfKfiZksI;
        }
    }

    if (GbyNzISCggRH > string("YIPUZhcoxqClwCfTKpagZVmJBMvnkODakfROIqDajZFDgDzuMSFLQOYmHXaEYt")) {
        for (int TKCkpLA = 1902659378; TKCkpLA > 0; TKCkpLA--) {
            GbyNzISCggRH += OGTmrfKfiZksI;
        }
    }

    if (HCTsUhcoqDhvVWg > string("IwyfKrFjBrFINDvPRAlugpIxiAymmmtQPGiDbnpxovQesxuWn")) {
        for (int yEhawbdJiE = 1880745368; yEhawbdJiE > 0; yEhawbdJiE--) {
            GbyNzISCggRH = GbyNzISCggRH;
            enWDGorZRCEDOd *= enWDGorZRCEDOd;
        }
    }

    return enWDGorZRCEDOd;
}

double qSdojkKvK::dUaTjp(int YjAgCXAgYT, double SmOIrOHaO)
{
    bool aaNimY = true;
    double MHuzFnEAytUDLC = 465717.25934239116;
    bool ZTowjoU = true;

    for (int ltZxcQdJ = 1911244804; ltZxcQdJ > 0; ltZxcQdJ--) {
        ZTowjoU = ZTowjoU;
        ZTowjoU = ! ZTowjoU;
    }

    if (ZTowjoU == true) {
        for (int zuqXvyfHAqoFtA = 1566735574; zuqXvyfHAqoFtA > 0; zuqXvyfHAqoFtA--) {
            MHuzFnEAytUDLC /= SmOIrOHaO;
            aaNimY = ZTowjoU;
            YjAgCXAgYT += YjAgCXAgYT;
        }
    }

    for (int ZPhxTAhChON = 1624035130; ZPhxTAhChON > 0; ZPhxTAhChON--) {
        MHuzFnEAytUDLC -= SmOIrOHaO;
        SmOIrOHaO -= SmOIrOHaO;
        ZTowjoU = ZTowjoU;
    }

    for (int hqWZRZwKPmo = 779614923; hqWZRZwKPmo > 0; hqWZRZwKPmo--) {
        SmOIrOHaO -= MHuzFnEAytUDLC;
    }

    return MHuzFnEAytUDLC;
}

bool qSdojkKvK::HAVIczj(int yasjBFsg, bool oKxGNBGt)
{
    bool cPYLSCe = false;
    string dfdZyYxkap = string("zHWLSrdfgAUVvbJMQlVBQepbweSEShPeBlddXJdkSrsFjfsHfyrrSLiZXACGiAGhwGBjPxgtrITKEAaeBNSJxeiTtomWAqqChzIWCCyyaKRaoiMuGZCVsRmAEtNPMrGZXTEHKeWGBzlEffaYVdUgp");
    int UvIqaGIihNVstW = -1029395495;
    string siNNHiV = string("sEHmnUQqZKzKkQJdigfRrHxUvQWxNoalAmQKuWoixswujzL");
    double EpyCbz = 502461.8851966085;

    for (int grrJlMOc = 1341789534; grrJlMOc > 0; grrJlMOc--) {
        continue;
    }

    for (int YwAopL = 99458079; YwAopL > 0; YwAopL--) {
        oKxGNBGt = ! oKxGNBGt;
        siNNHiV += dfdZyYxkap;
    }

    return cPYLSCe;
}

int qSdojkKvK::udrGVkefm(string IHvIOMRk, double VYhqBrURTSxhhXCg, string TMqUdIg)
{
    string JLmRip = string("mzURRmTxONHzxDffEkMyXHPrQBfxuqXYVPlnOFHyTNiqnnkGjYWSguAuuaxhpfLMzaZsnzPNgdrqxvskAYYFFKduSBwMrFnXIjfPSSFilKddFjzDUejRRaTjbNnDdpKyXwEnWGIAViWfukzVQZVWreXylGitpnvUcadeTaiMqAcFZLdjiwaXmzxtrfXqPTaFLbgrInbVCUmOafSDIzBroACtXkduKhtHBRKHxTZKNEVfLqbnW");
    double ffEiifrVfLCigBH = 878054.5795915098;
    double WuuVzwZYXSL = 33892.79152865815;
    bool wyfmSRJhnzvS = true;

    return -714496502;
}

int qSdojkKvK::nPHPB()
{
    int QRFCnYZGLymj = 961528442;
    bool JzOdVNJ = true;
    int BOkcQhfo = -1140359500;
    int WFCyi = -1841017108;
    bool iTZDBSuil = true;

    if (QRFCnYZGLymj < -1841017108) {
        for (int fvAFlWSxyy = 537777763; fvAFlWSxyy > 0; fvAFlWSxyy--) {
            WFCyi *= BOkcQhfo;
            JzOdVNJ = ! iTZDBSuil;
            QRFCnYZGLymj -= WFCyi;
        }
    }

    if (JzOdVNJ != true) {
        for (int JkZdkQOhMzkjhLv = 1579568071; JkZdkQOhMzkjhLv > 0; JkZdkQOhMzkjhLv--) {
            QRFCnYZGLymj -= QRFCnYZGLymj;
        }
    }

    if (BOkcQhfo == -1140359500) {
        for (int QdpBiCUxWzoDZ = 118256646; QdpBiCUxWzoDZ > 0; QdpBiCUxWzoDZ--) {
            BOkcQhfo = BOkcQhfo;
            QRFCnYZGLymj *= BOkcQhfo;
        }
    }

    for (int iKHLp = 800610520; iKHLp > 0; iKHLp--) {
        iTZDBSuil = ! iTZDBSuil;
        WFCyi /= WFCyi;
        WFCyi -= WFCyi;
    }

    return WFCyi;
}

void qSdojkKvK::pUMJRUBwdnAKpV()
{
    string nwxnXqYBn = string("JvNiWDLaTSjRqHzOlViBFcdnLwFuLdjXAYJTesVPQgDCJNdSWPtZhxVCodzSWOmKGBhJTTpavILkvWVBhlvCPrrZlENYIlNdqDpUgsGCwJEktcXkgK");
    int ASEmJrOgOKnXXH = 874395241;
    bool JIaGXrYFKYmgJoE = false;
    bool JnNFSAvGp = true;
    int BKRvmprdHzsEUtB = -471062696;

    for (int eTjPLkthDbCSHr = 674762895; eTjPLkthDbCSHr > 0; eTjPLkthDbCSHr--) {
        JnNFSAvGp = ! JIaGXrYFKYmgJoE;
        ASEmJrOgOKnXXH *= BKRvmprdHzsEUtB;
    }
}

qSdojkKvK::qSdojkKvK()
{
    this->mHbnZFgRyUE(-615929.5702030956, false, false, string("vfwfZrVndYwPoyNYDVQPowXDztQDMkeRHxUbPYLZvqvEYcfCjeELqlPQuZvlHkjYbADYyTlzGBXUEDMEQYadqTHPQIDlDMNcplKCwrIHCBTQjbfnPnrhPtVPOUvZFhfFAgjJDMnhYWlbUFjRmALIkhTEkPpMalqHwwK"));
    this->VvoStxQTLTEd(959945.984244472, -722894.4909119133, 376284.24608703825, -874827.3868589768);
    this->zoDcQZFOS(-1144093017, 948238.4434725393, string("EwnmYHCaadzJulatJMTIawkmLQryibYozYYDbcMpbVMDvWbtxWMvCIQBmrCQPaKgBPXHEIZRCCLStXfZArpwvjZJzIJYMQgmcDlIblrDnOsqSWvOcSbweXCjFAHgGCudmMSwkKAFuIBZmOpzlxsMeoOwVzUj"), -103132.89788515077, -950301323);
    this->nTDRge(-416013.0609780525);
    this->lCwYVcWQJrbEzyCx(1555991483, string("kAhkNAVSLDwJbmAZlHTzHUIsy"), -247253.6207335973, true);
    this->pQWnpMcgJoQilqR(-1414335558, -1778133409, string("CxdxcgkkpKUPfspNTnhIgOwrmYgtScszoZfGiFcTGdwPBoRREmtrEzQsLYAWPCOrYMNQlawGIdRsDilGsiiWKuZlxzagPScHfpuVzQRPPrGlDULfNwkpoCClOOdlNqmEdrUhFUqAqUioRTLRMBYdVNjHdgbZNmxfC"), string("YIPUZhcoxqClwCfTKpagZVmJBMvnkODakfROIqDajZFDgDzuMSFLQOYmHXaEYt"), string("IwyfKrFjBrFINDvPRAlugpIxiAymmmtQPGiDbnpxovQesxuWn"));
    this->dUaTjp(-273537535, -861816.8429492591);
    this->HAVIczj(525079398, true);
    this->udrGVkefm(string("QclLbWnhBLlBTorNLFXtAotfKBdnONIXVYVHannrvzDOy"), -421869.37439732533, string("kLBCqDmRQYOFtwDPNFYKKRsdHulibESxXGyrrpCPkRWxlLJOXmmGtZLPINCUydHEXVcAEgbWUndoorxscxwTwIaLRjwqOFRsvMSxNarXXosYXaBPFcYALCzJEUGOBBKsrCGWaRJzcXoWAeylobdwIvmifKhzOZKMewzguuujrOIksgPZydOGsLCznlxxVOUqwzDgeyuedHj"));
    this->nPHPB();
    this->pUMJRUBwdnAKpV();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cZRWMtLYEVK
{
public:
    int NnAjVYc;

    cZRWMtLYEVK();
    string SdTzF(bool ZLMMtJneZyJlZB, string xgTkWbxx, int wxnYUNxYelonIQ);
    string rkYdses(double aHXzwgAa, string bLsCWwBGbasfXtxd, double HnEGlFo);
    int vFpcKlbjd(int HIOwJmFhqE, double yyBJpFXXoTMI);
    bool awnKUqLJfdSNfC(double PHBhSkMnfJUqF, bool NoMvmVt, string yDrhUbmBLpd, int FdwsSHZJnhjyU);
    double XnoMuyBBuTErwcj(int fwkGojodZbui, int RoPyjOgRTqzAzg, bool sHdblawXdytD, double mjsIeViNWT, bool DdREKAELQQ);
    string onbAoCwUccWiaIM(string fIlyJiG);
    int GYTvJbGxwkfCRcsa(bool UOqNPivdhnE, int rbkXYBxBtcgu, bool GmVzEjWKNhuDp, string vukEKGHwTCoxHbiu, int kRgWEP);
    double WCFewfXFBOTBAaRO(double wGKwoNqGIQWUOWY, int trzIUtaqbtqTj, string wdBPVJYxwkcAi);
protected:
    int qtAcrEQZQGLgY;

    int yHCvCZeFsdGyNZGH();
    double CVLZRRFBZTVEpYg(double pOKqIah, double ikbpDfQZVb, double tFHlcWuLZJIz, string CnUWdLOZvuWcg, bool nTUHFauXmObcOrtb);
    void UgFFvRNxcY();
    double eiaRsyUnhcaXl(double JXfaAotGvGpjXH, double PVhheaPmiyvQs, string lGfzT, bool UUqdKqdDpR);
    void LtDNHwk(bool qwsNK, double IHIMEEwKi, string vcjlQkOznzqvC, string Kuryk, string yolZHaxF);
private:
    bool lbYMxgzfWTtdrUy;
    int zEfKRVOtobivc;
    string leHZTmMu;
    bool zUsDGDOSPVc;
    int cEjrpzWSuDU;
    int gkevMpKIClA;

    double blshWT(bool maKyNfLFYyFVD, bool gVQdblWFVFVBPepN, double CvdvOQK);
    void oCqJzLv();
    int xfSGrhDLaM(double vJfngMQxyE, double RQZEYVkoRGoHACQ);
    void cJLLQb(bool jgezLzPxtJka, double NtZsVIL, string OwkoNpzPlNpwylfv, double WDMOOJhuBmm);
};

string cZRWMtLYEVK::SdTzF(bool ZLMMtJneZyJlZB, string xgTkWbxx, int wxnYUNxYelonIQ)
{
    bool tXZUDAzeVED = true;
    bool LjUGBHEGrvJA = true;
    bool iSFWCknLSILirjA = true;
    bool LaxUYL = true;
    bool xWHkUJhVDqIrrHn = true;
    double zGXPDCpQOwY = 179581.83530273673;
    double fndlmUtaOeTqSWc = -377830.4577739725;
    double FQXqYnpsFZwH = -38427.82379876758;
    double fIukSaSqRvDGQI = 366721.98842522525;

    if (LjUGBHEGrvJA == true) {
        for (int TMFuPHoYvKDTig = 1155662165; TMFuPHoYvKDTig > 0; TMFuPHoYvKDTig--) {
            LjUGBHEGrvJA = tXZUDAzeVED;
            xWHkUJhVDqIrrHn = ! LjUGBHEGrvJA;
            zGXPDCpQOwY *= zGXPDCpQOwY;
        }
    }

    for (int VFiJzCBrCeU = 2141311303; VFiJzCBrCeU > 0; VFiJzCBrCeU--) {
        ZLMMtJneZyJlZB = tXZUDAzeVED;
    }

    if (iSFWCknLSILirjA != true) {
        for (int arJoFCk = 1476805363; arJoFCk > 0; arJoFCk--) {
            ZLMMtJneZyJlZB = LaxUYL;
        }
    }

    for (int EJpoZsTqIqbBteC = 705373904; EJpoZsTqIqbBteC > 0; EJpoZsTqIqbBteC--) {
        fIukSaSqRvDGQI *= FQXqYnpsFZwH;
        xWHkUJhVDqIrrHn = LjUGBHEGrvJA;
    }

    return xgTkWbxx;
}

string cZRWMtLYEVK::rkYdses(double aHXzwgAa, string bLsCWwBGbasfXtxd, double HnEGlFo)
{
    bool CEFEJeBuUyog = true;

    for (int EbFSsotGqFr = 693713788; EbFSsotGqFr > 0; EbFSsotGqFr--) {
        bLsCWwBGbasfXtxd += bLsCWwBGbasfXtxd;
        aHXzwgAa = aHXzwgAa;
    }

    return bLsCWwBGbasfXtxd;
}

int cZRWMtLYEVK::vFpcKlbjd(int HIOwJmFhqE, double yyBJpFXXoTMI)
{
    double lUQvWjegPXmEs = 568898.8559941285;
    string SLlLmlximdmvgHjC = string("YXvKwvLJPahjxybCvcHoOzTkocyxfGUfkOXRMzRtGHsFPRyIIPCnmUMMHyHQsHIwGSpatvKONUuQguyQVTdLaDGksKrvXRHtDwJqfHLOophEFVZnKHISGkGweHSIivVqZwMluNHlGFvUqHkPbUqmPFagMCHLyXcNZminOxdYrGNqKaIgmDwrTFzVoTNiRWqxcXOhcKWNATPrBvGpKevdsGussZkIcvnyuA");
    int GgwPPfmSqUo = -1876235104;
    bool ESgyeWstcjAmR = false;
    double cPkraIwpuzRfZHJ = 444474.7651442621;
    double peksWIhKti = 228626.33530588087;

    for (int RWyoVUpXEYOX = 1879474450; RWyoVUpXEYOX > 0; RWyoVUpXEYOX--) {
        peksWIhKti += peksWIhKti;
        peksWIhKti = cPkraIwpuzRfZHJ;
        lUQvWjegPXmEs += cPkraIwpuzRfZHJ;
        peksWIhKti /= cPkraIwpuzRfZHJ;
    }

    for (int wWYfcrkLtMaGqT = 1121856049; wWYfcrkLtMaGqT > 0; wWYfcrkLtMaGqT--) {
        cPkraIwpuzRfZHJ = peksWIhKti;
    }

    if (yyBJpFXXoTMI > -656770.1168356808) {
        for (int EvhOE = 923237686; EvhOE > 0; EvhOE--) {
            yyBJpFXXoTMI -= peksWIhKti;
        }
    }

    if (lUQvWjegPXmEs > 568898.8559941285) {
        for (int PDUqR = 1763952214; PDUqR > 0; PDUqR--) {
            GgwPPfmSqUo = GgwPPfmSqUo;
        }
    }

    if (GgwPPfmSqUo <= -1876235104) {
        for (int wYEzgxveqIc = 1107170035; wYEzgxveqIc > 0; wYEzgxveqIc--) {
            HIOwJmFhqE /= GgwPPfmSqUo;
        }
    }

    return GgwPPfmSqUo;
}

bool cZRWMtLYEVK::awnKUqLJfdSNfC(double PHBhSkMnfJUqF, bool NoMvmVt, string yDrhUbmBLpd, int FdwsSHZJnhjyU)
{
    double AxTqqmZ = 953864.5421808842;
    double lJmroNGRUXZD = 109763.97263183788;

    for (int QwSxlglttufvu = 72270628; QwSxlglttufvu > 0; QwSxlglttufvu--) {
        FdwsSHZJnhjyU += FdwsSHZJnhjyU;
        FdwsSHZJnhjyU *= FdwsSHZJnhjyU;
    }

    return NoMvmVt;
}

double cZRWMtLYEVK::XnoMuyBBuTErwcj(int fwkGojodZbui, int RoPyjOgRTqzAzg, bool sHdblawXdytD, double mjsIeViNWT, bool DdREKAELQQ)
{
    int kZNNRDTSlveS = 191683987;
    double TuvAT = 202246.38880143673;
    double tbtdgGPYVxgooxUR = -440019.1387098397;
    string cqvVHaALYVxBw = string("RVvYQCpGjFuDomvVcfqycTMmrRvcsqZaMqLMHCpsviUxZSIAOCslIlCgZGIEIrDJRJFhweRNqWmOHpzRJJvnjsgdDWgXwZdbJKXYRWgNeBGXwgaSIZFVNJXaZGEmyKwPqQetfmElmgIiyycWqqFtToSBVnKUJHltqfoQUhexrkDqMYdxKrMuvm");
    double qsVraxYIL = -146136.14872559416;
    string pdavdfVkXEAkbEye = string("VQboDjPKQsQnlMWVQXNpKXfduWeEefsVJSqClsWFvOHbanAjciTjYkjYWcQpRhvkHiQYlOrkYpTAXueDBHpyrTXuDGrVdHTwiUNnVNKrlyDBfjJUAhIfdlsyxAtIXiefInhzeoCdT");
    int cIMjfoPSjx = 1775399293;

    for (int ZOqrG = 1465410438; ZOqrG > 0; ZOqrG--) {
        kZNNRDTSlveS += fwkGojodZbui;
    }

    if (cIMjfoPSjx > 2037221221) {
        for (int vALKwqqjcKlCDiX = 140991068; vALKwqqjcKlCDiX > 0; vALKwqqjcKlCDiX--) {
            continue;
        }
    }

    return qsVraxYIL;
}

string cZRWMtLYEVK::onbAoCwUccWiaIM(string fIlyJiG)
{
    string eEgHSIEbBGwq = string("IJGjFuEnTiLiLIaTQFyFWskfdmmUsIhhYXpEXZnwRQuHnzvRTsmpvBnTKcxhHSIJKmSlfyJEprCAcxwCqJVsDdDhsKYlYQGPfTkxUIYJvwWLJUPfAldHbWeoatVIcIBlfukAeqmkoTbYMihvscJdtXRnJxHrkEBBDHKqBxBUVWQigsJQPcztKsWmwjfFWSIhDctyvZmHgNJePNqiPnkhVEvPwfFJmsrijYdOdjDZQEZsvGXxWUGwkslwDs");
    double tcqiF = -244959.21680067247;
    double rHUQkEHbb = -62165.259965355945;
    double BvjEUzVmRhvrIOTt = 661102.6755944409;
    double tfeCJCUTUgCAE = -893784.7926448464;
    int LSZwJ = -721566615;
    int PmRYeaInFdTrKH = 1620557616;
    string LgSFrQ = string("JOumMMCffzwfPsHuSEvVuP");
    string QCltW = string("aCWKDhVOwJcjErKqSHpbSAAnDaHIRkJDJYTUdaFrmoPleftkxRZgQQLLMdWRFARRPytgSlerefGrWLhiQtohTczSCFXrcUjsyhiiVKayDmZqbsqKBqPdjXBCvtpSQFkpTTovFCOLtAfVIJmQNmeooDjligklsCkkViuEuXBqbewMTsysQawNlUtMcOJwSsZUUgqewYqcutCvpGqJHdHHFuF");

    for (int OyKEcwc = 2023026822; OyKEcwc > 0; OyKEcwc--) {
        fIlyJiG = fIlyJiG;
        BvjEUzVmRhvrIOTt += BvjEUzVmRhvrIOTt;
        QCltW += fIlyJiG;
        rHUQkEHbb = BvjEUzVmRhvrIOTt;
    }

    if (PmRYeaInFdTrKH == -721566615) {
        for (int RVfksBexwepbO = 1816573344; RVfksBexwepbO > 0; RVfksBexwepbO--) {
            LgSFrQ += LgSFrQ;
            QCltW = QCltW;
        }
    }

    return QCltW;
}

int cZRWMtLYEVK::GYTvJbGxwkfCRcsa(bool UOqNPivdhnE, int rbkXYBxBtcgu, bool GmVzEjWKNhuDp, string vukEKGHwTCoxHbiu, int kRgWEP)
{
    string teTptBp = string("AQNupjxGEdOrWkzkFGevmfqKwMnFtHahEqhYwOoZKgzBMHqSjrfQUqIxXVffZIUQmvproHaEhdJuvCDJJZXmEYhHWWVmuargGUBIjwMdvMZsukdgNnYvFcgLnlJdyyHS");
    double rbUaleG = -519031.09240323625;
    string NkVMbNmyIXa = string("eGqmgyqqjh");
    bool xkvQXhlZ = true;
    double AaGABNgpg = 622798.7456982731;
    bool dfralNk = false;
    double eWGsCIoZZsolJ = -2606.662354039397;
    bool IkZUoLCpIQj = true;
    bool VMoilXuD = false;
    double dBDPGto = 153458.99684511177;

    for (int MIGszTHSN = 347341354; MIGszTHSN > 0; MIGszTHSN--) {
        dfralNk = ! xkvQXhlZ;
        UOqNPivdhnE = ! dfralNk;
    }

    if (IkZUoLCpIQj == false) {
        for (int GaRNTrHBDcXK = 1388949036; GaRNTrHBDcXK > 0; GaRNTrHBDcXK--) {
            VMoilXuD = IkZUoLCpIQj;
            eWGsCIoZZsolJ /= dBDPGto;
            vukEKGHwTCoxHbiu = NkVMbNmyIXa;
        }
    }

    return kRgWEP;
}

double cZRWMtLYEVK::WCFewfXFBOTBAaRO(double wGKwoNqGIQWUOWY, int trzIUtaqbtqTj, string wdBPVJYxwkcAi)
{
    string KNBkUZA = string("BjUaguIPFntXmffRYlUoqQfAwq");
    bool VtzlI = true;
    double lYBlbdXFKvhx = -702078.8341109662;
    double ENqCokTCrFxCp = 688178.046348244;
    string uQOzHcdSjrpc = string("lcPDJiILXPpVzQZUqYJPQpWLNiAPEsprveOBSCgsLTAjhkMudOmpMOrlqfvtllhaMhBNrbpTYBSimHpVVluLBzclcgFfWsNpcF");

    for (int IJWgwaFPLTwgdAn = 154768487; IJWgwaFPLTwgdAn > 0; IJWgwaFPLTwgdAn--) {
        wdBPVJYxwkcAi += wdBPVJYxwkcAi;
        wGKwoNqGIQWUOWY = wGKwoNqGIQWUOWY;
    }

    return ENqCokTCrFxCp;
}

int cZRWMtLYEVK::yHCvCZeFsdGyNZGH()
{
    bool fAcPUkVihCsux = true;
    string jbhKdvOrY = string("FEqrXLtBaItihCFgQDvFqQVtrYiBExYOeGfsacyMEFOlQgABYPFFHiAOEkixQIoiLZkiNmIAomNOJTdYwvMSNcCsJZSDhlHTrDEniSRVtHdDheVDnEBRhwKtHUpIYMArLaDEEVWFMcEuQWRxOxDxGNTTNqLmQujzLxhbFctoISVDXhAiVkDjrleKmvgDyMgDKJQwDPLKAeehenmnMgMvyxpXPHTauaUNcWaffsuLukchpNJnLlLlc");
    bool fawvrPY = true;
    string CdKwxDZrJWlki = string("CvIwzCDQgvflNcRuTyAkaiazaDiRYwTpsDgrvdlGFTSJQtYvkyNr");
    string yIcGsnN = string("BmTyjiCTImSqlZIIIlYmMSkuGUdermggVfjXRyaRHalaYHrVFJyBsxJcysfvRmzLDPtBTpdJiqTeAaTHCNAqhAwpiQGOehkPKPrRaSKxKZxplXbfumHuujznDOolsezjijJXNeurbx");
    string GyRbVEMSvD = string("kUTECLMeIKJxUaCSHZLMHRnHYGfRSZIuruxcVEdWtLGzexFHwcjqKSWIQnRDrFswrjjZVeUfqMtRqeAMYIhrRdbgbaHVabPkgkYfprsvUaKBSrJlsQQDTzAkxZjiSStkPPeChFnjotQKAKyFaGbNliGUhnfDEQjxFiDTXRMNIFXwPDEfmZbbLCUCqTevZhPpTwgtxZQVSjMYNoeyhj");
    string aduZAWHjWkN = string("eSPlWjYUXCKyaUpuNjlCwaaciMYFBVBMILhRlghHmWXdP");

    for (int KfrdaBWRywzO = 75013688; KfrdaBWRywzO > 0; KfrdaBWRywzO--) {
        aduZAWHjWkN = yIcGsnN;
        jbhKdvOrY += GyRbVEMSvD;
    }

    if (GyRbVEMSvD <= string("kUTECLMeIKJxUaCSHZLMHRnHYGfRSZIuruxcVEdWtLGzexFHwcjqKSWIQnRDrFswrjjZVeUfqMtRqeAMYIhrRdbgbaHVabPkgkYfprsvUaKBSrJlsQQDTzAkxZjiSStkPPeChFnjotQKAKyFaGbNliGUhnfDEQjxFiDTXRMNIFXwPDEfmZbbLCUCqTevZhPpTwgtxZQVSjMYNoeyhj")) {
        for (int lUMzuyKT = 251683598; lUMzuyKT > 0; lUMzuyKT--) {
            CdKwxDZrJWlki = aduZAWHjWkN;
        }
    }

    return -2052125635;
}

double cZRWMtLYEVK::CVLZRRFBZTVEpYg(double pOKqIah, double ikbpDfQZVb, double tFHlcWuLZJIz, string CnUWdLOZvuWcg, bool nTUHFauXmObcOrtb)
{
    bool jSabqk = false;
    bool NIINhZnDQH = true;
    string sjggsW = string("bxysiVnBwxBcaqJENFgFucFWNgZrkqjVehYYXuGHHNizHhozoQjKTcyfwSxIOlhtWgwQUSnPyKYGMHmkXWIjSFnOdzxhymxCOgpKaNQHcZOBBZsiluKUZxFMJfXZXkLwBPBOBLisoYgYFFgCoCcEBenUwpAUrtvporoZpAUcIgaMaHMpfYhleXJAYyE");
    string YnNeJwdksFQ = string("SJnBxxpBySJOtBQWKfwbHMpIyndQlbEMDNLNyVEedTsbYlLdHSM");
    bool nmsaPNSswtoS = false;
    bool tgaxzqAfPG = false;
    string EtJxg = string("ZnvzrxcrzMbjYNWfJsVbnsdketIkaNgNuPSUUUPSiSsaLxpWVQiFQflEllLCQjxAAwPyIrukQvhMFxKXgVjVVDUAVkILCybhhUdgGcYoJVVBxPniwHbFEiFbhIVnMbESrYdKNDWWifaPdKnZvtWjJOvxvwWTgnJGZteWJfCZtqR");

    if (pOKqIah <= 985362.2025487178) {
        for (int BpdLrBhrWIYmyo = 1462710217; BpdLrBhrWIYmyo > 0; BpdLrBhrWIYmyo--) {
            tFHlcWuLZJIz = tFHlcWuLZJIz;
            jSabqk = ! jSabqk;
            EtJxg += EtJxg;
            YnNeJwdksFQ += sjggsW;
            jSabqk = tgaxzqAfPG;
        }
    }

    if (NIINhZnDQH != true) {
        for (int TgFsHDOFnmI = 315121504; TgFsHDOFnmI > 0; TgFsHDOFnmI--) {
            continue;
        }
    }

    return tFHlcWuLZJIz;
}

void cZRWMtLYEVK::UgFFvRNxcY()
{
    double OezgwbFkFZSow = 951333.9025711577;
    double mUhrzP = -774191.4079408438;
    bool tnAGVxPpbIKZB = true;
    int VeFSMWgTrIZz = -728338835;
    int cqhEajV = 73362657;
    bool DDhENGmcB = false;
    bool wWEcqBnZDXIRdH = false;

    if (DDhENGmcB != false) {
        for (int IdsUSUKsowLBG = 531803639; IdsUSUKsowLBG > 0; IdsUSUKsowLBG--) {
            cqhEajV += cqhEajV;
            OezgwbFkFZSow -= mUhrzP;
        }
    }
}

double cZRWMtLYEVK::eiaRsyUnhcaXl(double JXfaAotGvGpjXH, double PVhheaPmiyvQs, string lGfzT, bool UUqdKqdDpR)
{
    bool gSFwiQmpOvX = false;
    int DDMuvyYrkbVXVEZ = 6765417;

    return PVhheaPmiyvQs;
}

void cZRWMtLYEVK::LtDNHwk(bool qwsNK, double IHIMEEwKi, string vcjlQkOznzqvC, string Kuryk, string yolZHaxF)
{
    string QZMVyfcWb = string("TrrguewQHGLsfibdKIiyMndUEmRBoPGTyijfmlXKXFOcQDDIEVLReKhIevCelFRIRcrVjyvEQlbTD");
    bool oyCWrktbU = true;
    int QTbMAmWamNTsebA = -1558432048;
    bool LZrFTeOjV = true;
    double yHSrsvtegvxj = 915035.3059318732;
    string pxyOt = string("ZxSsJPJyGstDhnuginlEPSDIVCPPMzKEpdMigLvlxWXhyHvBqIVRAccYRzuHCTGRIEknobusXHvoExwadNPztWziBJaXtqaSsyjfHPukXuNSYrLZgtZNJIFQOTdJwJHtTzUmfxjIvIBbqST");
    int fbDWrjhisbnZ = -1284358000;
    double xyYqjCBJeIFlXfY = 852049.5057221352;
    int LgauvD = 1822657249;
    int Iiskc = 1204914695;

    for (int TaDuPqK = 810511230; TaDuPqK > 0; TaDuPqK--) {
        continue;
    }

    for (int aqfTHRJpqgWrR = 655340451; aqfTHRJpqgWrR > 0; aqfTHRJpqgWrR--) {
        qwsNK = ! qwsNK;
        xyYqjCBJeIFlXfY -= xyYqjCBJeIFlXfY;
        LZrFTeOjV = oyCWrktbU;
    }
}

double cZRWMtLYEVK::blshWT(bool maKyNfLFYyFVD, bool gVQdblWFVFVBPepN, double CvdvOQK)
{
    string VLqVcPPlanaUvBNH = string("QwLDYHmbgfzOSTWhwFAZdLPoFNFwHJckAsXISlWibYpjidTEOwFAzXctzwqRoVEMZbvsNCbNwOhbYHtxCzRQfeoQlUpRRZwlRTIdYgpsDDnKTdOLTdAiEcXulkhAgc");

    for (int UxiQfE = 1094228986; UxiQfE > 0; UxiQfE--) {
        CvdvOQK /= CvdvOQK;
    }

    for (int yhgJthEoDfPqys = 1119830676; yhgJthEoDfPqys > 0; yhgJthEoDfPqys--) {
        maKyNfLFYyFVD = ! gVQdblWFVFVBPepN;
        maKyNfLFYyFVD = maKyNfLFYyFVD;
        CvdvOQK -= CvdvOQK;
    }

    return CvdvOQK;
}

void cZRWMtLYEVK::oCqJzLv()
{
    double awQDhGnSNUtoK = -1025711.3129658109;
    int PFDOonZjDApadj = 666689153;
    double VrubXdwRefN = 880917.424964192;
    int UVcUjkqZXsae = 303534832;
    int TPdOWTYmhVcgLqei = -1123090104;
    double mpDpCjktlmXqMMub = -289892.6633738837;
    string UrwbbnfrOVHB = string("pCdVIlOLwctzMNUxwRThnPNZVRpGgpEucPxklkcRMEHkSMXOCVtLEdhXlUixWwmfUZUHJGFqVcbYxEZFgRYhkJzmXnCeyyREboxopwpglXlrhxlUiPOUC");
    string BPgRbFMdauOg = string("RicYnDNjePxaogoPEslCtDwTJrANEJcYHJaQpHuRzaPCJADcLpmmsyAnQZfSDCSeaXJCuHeBjNUJWwpKqChxYmOIkTyNaHNMiQPdkqwzJrKftgOvQDycWyLajXCFRvnzriLbVWLsOgdgXZfqqRjSFETwMWjhstnWgNjSWpBwcwwdtqzeTtkqhPhUDpcsHJVPbVSfItTDDxtwNAWmNzbftVFpweSYDcxxJuJQkVPfEgrMJQ");
    string yMviSabNWXddFXA = string("mLBzPnNYFhGbhIWdiiWNMnxRLNtTEUhIUzWUVbZexkHdfIkJJDccqbLqnYGewtxuTuOvjQHQfnxulRJPagShBIakCdtHWquYMLlGdDPMfmEZeLlJsYwXMoMrfFuWRlCEghezoyqwcBYOWfKHHZkQLVrZQautdZFjvKGYwnpLzeBCmBvjqcuWBzAcgqAltkiILxdwjIVzPJAPgHLINUKhn");

    if (UVcUjkqZXsae > 666689153) {
        for (int ktMUoSPib = 1401904940; ktMUoSPib > 0; ktMUoSPib--) {
            continue;
        }
    }

    if (PFDOonZjDApadj < 303534832) {
        for (int psNnPpURof = 2051582378; psNnPpURof > 0; psNnPpURof--) {
            UrwbbnfrOVHB += BPgRbFMdauOg;
        }
    }
}

int cZRWMtLYEVK::xfSGrhDLaM(double vJfngMQxyE, double RQZEYVkoRGoHACQ)
{
    bool qSAdgddHskkW = true;
    string UCtBDHiq = string("AxarvkJzRWmApdLXwHOfNrCSSfvJBECVDrInutcgVmnDvZlmzSkfdmuhWnhwetbhmIdMGPhINmeVYwjPgejlGLplAwrByBOCbOGqorZkhjhQqByvtOBHciNYZmebSCmaxDHAFcBCtSwtBKGodQkhxghuMKlOnnGQbmuDrYEmfOvHZaUFamiuCQZBUFzDpvwkFiRydYiSpUdljPAaOeBdqXIGbhEyXEa");
    double WfmWwNycxaHxwYM = 134301.050689438;
    double kqzMLMTPUDzpP = -505544.1041117373;
    int lEfPJsBydgwdvL = 557071005;
    string VKvSDBBPPB = string("LKIeTFMrHGFJFUgOavpzuQxtoFGaMfuaNciEbLywUaPVNKCSvsdvIfEQYcQstKtQXwxQHobKAXCaJbSDecwVBtAbabmPrpSEHbeQXDriqjBBEIueZLoTeGpnflZWMkXceGQSPqpeXlnFYJHAicWEIlfcxOrkGTIkBVPmqvGTppWcCmlfefDjuIRkHwPeWPwCEKfHTlcNUygzEquwkZdgTUmGPeejirYWtpDrAQBmjOseIHMyyxgymsr");
    string rTInCKRZHgzXl = string("uHxggeNHvtXaiwRJGGjknZTvYzMYWqzZoPxQxaUDtMHoREefgAirnmLdUoowbvzGNXqlDxLHDtrTtrDEFWxPxKPMJLjYjqJvUAnmWwZhV");
    int YplkVWg = -1689492889;
    string KUqbdgmHvPQy = string("VaKHxwpdcVPdGyUJPRLDYBGiHwNrhXAoopugDiXSDRHRyYQMQjBWEMcOqVOFmnewFtYcwuFgeDJHSnpWEXhvklzGyRiMhGydGQSjIqhgQWiknmunSHuVlvwWrDNjOCtVNjcdJeswqYlMupwLJmXUHpICYuFawDzu");

    for (int MjtAEHuTTjZMiYcL = 1961914870; MjtAEHuTTjZMiYcL > 0; MjtAEHuTTjZMiYcL--) {
        continue;
    }

    if (kqzMLMTPUDzpP >= 134301.050689438) {
        for (int weSAZxEfPbMET = 1964389961; weSAZxEfPbMET > 0; weSAZxEfPbMET--) {
            YplkVWg /= lEfPJsBydgwdvL;
            KUqbdgmHvPQy = UCtBDHiq;
        }
    }

    for (int wSCnXvUOCgsvsv = 1174819892; wSCnXvUOCgsvsv > 0; wSCnXvUOCgsvsv--) {
        qSAdgddHskkW = qSAdgddHskkW;
    }

    for (int xJLMKiAuNsyDs = 1814756974; xJLMKiAuNsyDs > 0; xJLMKiAuNsyDs--) {
        rTInCKRZHgzXl += KUqbdgmHvPQy;
        YplkVWg *= YplkVWg;
    }

    if (rTInCKRZHgzXl != string("VaKHxwpdcVPdGyUJPRLDYBGiHwNrhXAoopugDiXSDRHRyYQMQjBWEMcOqVOFmnewFtYcwuFgeDJHSnpWEXhvklzGyRiMhGydGQSjIqhgQWiknmunSHuVlvwWrDNjOCtVNjcdJeswqYlMupwLJmXUHpICYuFawDzu")) {
        for (int QNwmiHMapSjr = 1742782577; QNwmiHMapSjr > 0; QNwmiHMapSjr--) {
            vJfngMQxyE += vJfngMQxyE;
        }
    }

    return YplkVWg;
}

void cZRWMtLYEVK::cJLLQb(bool jgezLzPxtJka, double NtZsVIL, string OwkoNpzPlNpwylfv, double WDMOOJhuBmm)
{
    string KTAtTodf = string("oEjKAMAngBgfpyuWETVovudRzaNQErDVgrSpKTT");
    int ZzHcaSAhDjnY = 1362553774;
    double lYQFo = 91586.77525065499;
    int SEJPWz = -980243937;
    double fEsuZIDInNyqeX = -61090.800654882485;
    double ihlOfB = 694632.0432751423;
    int MDrYAnyloR = -1132262513;
    string wKblI = string("bGhjQFqokSqIsbYpenKklxjNVNRUsAqVzTjYqoxfzGtrQyMAIfBRVafynQbZmwzGpahKnTFoWZr");
    bool UBrmMosrcDp = false;
    string DPUrwC = string("PFidQrCbIUxuACsXRnWuTVRdQmN");

    for (int OasHF = 1382754224; OasHF > 0; OasHF--) {
        continue;
    }
}

cZRWMtLYEVK::cZRWMtLYEVK()
{
    this->SdTzF(false, string("xQDmMJFzsqMacIkXBMkcjwgVBYXogteCoLYyWUMVDTEmdqJLfvTYqMBNoGMQoyWbFBuPqaPboNFZfhBfonupVRpEauieTQRHwdqxMbeEgkwGqacxXufuZgcyjdjnLcEIvoPoBwEMJMWfhmWlmEZcPf"), -549265236);
    this->rkYdses(522810.24806648376, string("aSyzYpwwedoHUdTYkTplrvPrOdSieNZwwJRVJICMvHBqjUITUzumWUnVQmQeBfWkmTAcFaZQhgeFgMGoYSmiuCkjlMEjpm"), -610278.4651419491);
    this->vFpcKlbjd(2019167960, -656770.1168356808);
    this->awnKUqLJfdSNfC(578109.9256173909, false, string("PyXLkGAzixlkwKiRFjwoFRIOdlTMcOcoPokbORiBKDbpSbRMjEmNvEcdHmWAfngKgGxnxkcDGdG"), 237097357);
    this->XnoMuyBBuTErwcj(1671306422, 2037221221, true, 965458.1672195885, false);
    this->onbAoCwUccWiaIM(string("BJRQjArhfrtzwPJjXzHSQxDiXaNda"));
    this->GYTvJbGxwkfCRcsa(true, 1998076940, false, string("YREVXphvoDyJsoKNGIUDyZzQlEdzhInSpmZmdJyiCeevWxHhtbQLsvQUXVaqHTrkyNnDXAaQiXTREvduOJGCRHsbPUPkTDSSTomBktnGXkTTamCiBvDbIRNtThLywzFeXzebNdNMHyCSOeXfaBvykbzMkYatvNILdtjMnQOqLTbuXjgRZAGFmKBjFzIZsWBJmjjFsbKgOPLNvPQBPs"), -1616541809);
    this->WCFewfXFBOTBAaRO(49915.84659629039, 1324578076, string("ykMCJfQZPtDOjrRppqJLXmNAslTmZumNRUjeVnSItQtPFIEzmeGfkOygDlzWDLDJlSLKJAqMegowpynVaWZoxQzKsBMStgPYroAzdCEloCyjyXAITfKfBIFpvxjDRpaVTjnil"));
    this->yHCvCZeFsdGyNZGH();
    this->CVLZRRFBZTVEpYg(985362.2025487178, 1023910.9604372164, -189301.96606248722, string("UgnQjdIwRpfiNzwPRNejaojkgaidhmoANPmtiQcKHuwZUnBPzdFSWYMZUhLAmsRAhnAPzrWkCbGPrklDhcCfUFlVVIBugoQljKjCFwRwfKeEUHQagegIcbNZURUWnvkVEKeknUOoOVwUwNjgDgRnBGSSjcdcxlRKHXodkXHGuyIreXJUsnNMeXwG"), true);
    this->UgFFvRNxcY();
    this->eiaRsyUnhcaXl(-677025.7352949546, -156526.22731499714, string("rlSlIgKWioIkjYznmrFCcdUEtMLJXHhxSTwbFBmNUuBzBDSRGHWgngOjMmBXunpkWyUrtIbmciGzGjBrANrdbwvmevAxUHlRPFUwGNFlstDwRiRWBPvPiWeBTOZXNcKiGFWuLiOgmfmcFacZPzKKUSJkOCKJATAchZWTyL"), true);
    this->LtDNHwk(true, -83228.73865555643, string("WchCooWeKaWAHoRymFicZOBDGxffxriPfHFCZdEpyhTfEaDQugrpFhvQgnaDHpxOkMxuOiXhJWcCbuMBblVgdJdMqZVEiWUswHXPrHOUEwKJNySflPOhFZluALvyTta"), string("NrTiMDnnnBstTxrCDwYOmsVgpQtAOROljzgupvSbrAwwnciwjeBqHmkCsVmtpgMZhJNCHFxqsPPswzLwpAuelbqEgjITZdUIKFNhBweACDydmltvtqwCWdeLAXafFvzACFIhaTspBqFBAIUdvJAKBgcrUDFsy"), string("VfXVpbrJWGzLCvWiHftHDjuwMLQWjkrHUdNcKcJmSOaCiLvQlZadLIb"));
    this->blshWT(false, true, -756533.2725993412);
    this->oCqJzLv();
    this->xfSGrhDLaM(-135667.11360683184, -394937.59661170474);
    this->cJLLQb(true, 251712.5950279284, string("yYixmbtguwDinLXvSSycZCXrvqSWdXrLGBniFdTxKdZdtTCiVylLIJhIrUdNEUBjnEbImoQIqxtLXjAcPxXTVkLvQlkECNJMiMXWErkUYlowdQjjQIsOLvkMPEFrdCtEEONyXtmsZeXOddlfiSWVPFPlkPGGJqFmJmLzrxAtmRd"), -435823.7074927679);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fEfFcDvhIfEoUrLA
{
public:
    double UXZLgxUVlsryqh;

    fEfFcDvhIfEoUrLA();
    int gswonQuprBK(double TTUeXgpbDexr, bool fVaMU, double RijvTRJACHJp, bool quIEvOALrxlQzp);
    string rRGLuCUk();
    void ErBPGJduekwi(int snePyZXWlkx, int YLdXFpceIacHnRx, bool CGqDb, double YzmBbZRZaZyQC);
    string jcSdFzern(string hOalZGh);
    void JAMTkfndbiLpIsgF(double zhYUnmEfbW, string KyBndV, double DEIOH, string TnyMCkGgB);
    void zLsWsBf(bool BWsNdDP, double svFVUQ, string pzrcs, string OWvXYXotKPdSkbx);
    bool bNPZWoarPDgoX();
    string rjSnQDTwRfu();
protected:
    bool quJhdDES;
    string OEdwoItJGKhQ;

    string OdNhH(int blhdxPULM, int yDwzA);
    double ydXjB();
    int kGXgpbhBYTwi(string bxvHCcZVuiIhcY, double fEuZVXsXIf);
    double YldmxxalqUywAb(double nfiigy, int vSNOeq, int eZfLZBIIwOlDuufE);
private:
    int wBTUd;

    string OULoyhEQdOPxBzY(bool mcLVtDou, string OnqtfcrItoZU, bool TNaLuOxFFO, double wIpgQ);
    string yDvIFVDyQlg(string JAfrxNvrw, bool BxCbEhwLuWgnIpMo);
    int SjygZ(int hbeYzK, double fziLcGymwGVtv, int hKhEsQMewg);
    int bQwfLmjpC(int dRoLsmrio, string aApjgZ, double YcZOo, string sdGwZHDVk, double aFOvXJF);
    string onIwAYyYYhrDwE(int SYQEufVLjX, double QcAJhSoWGE, double BWXqpTpnMgEjCBm);
    double PuXvLK(double OpJgcNQlIuRrAlk, double nWQBL);
    void sfXkNwD();
};

int fEfFcDvhIfEoUrLA::gswonQuprBK(double TTUeXgpbDexr, bool fVaMU, double RijvTRJACHJp, bool quIEvOALrxlQzp)
{
    string jOOUDgsrOzyum = string("ZAcLOuEGuQBJtHnLjnMkmTcxjxXcKOgmdSxewCgPivRVLsDiSgRmHPEThlaOpIMYvOxeUyOqsFqHdwnWNxAOMTPlapTUXZfQJySdsCuKNiRzSUdHFeRbS");
    bool yzKSFB = true;
    int yiiEdACiMjj = -189960512;
    bool zJzWpIXGtA = false;
    bool IaleoW = true;
    double MzfFggaARd = 234869.4650128647;
    string cnPMcCxyB = string("VBYxOitHyfuOJULUQhfbEAwbvvYAugkrNaMYzyiVgAJrxxxRTuLeDqXDTduCTRyzuyAARckuZYwQHpvDbEkTCFiHhGhNaNhcXLJKrsVLvlgnSIVdWdSJlksIghHlxMJJlMpmLTBrrPYtdKeuAqbWOEQflUmWQugZJUckZtNTzQjDnKCHTlbRPFYLwJwdrxXJjsQqMqND");
    double hOcBjzYUYNtNqL = -879401.8097159974;

    for (int WKQLEYm = 505259481; WKQLEYm > 0; WKQLEYm--) {
        zJzWpIXGtA = ! zJzWpIXGtA;
        quIEvOALrxlQzp = ! quIEvOALrxlQzp;
        TTUeXgpbDexr *= MzfFggaARd;
    }

    if (fVaMU == false) {
        for (int cUjGd = 1240026003; cUjGd > 0; cUjGd--) {
            RijvTRJACHJp = MzfFggaARd;
            hOcBjzYUYNtNqL *= TTUeXgpbDexr;
            hOcBjzYUYNtNqL += RijvTRJACHJp;
        }
    }

    if (MzfFggaARd < 596251.0410516819) {
        for (int zctiLLItVbEbQAP = 2002248926; zctiLLItVbEbQAP > 0; zctiLLItVbEbQAP--) {
            cnPMcCxyB += jOOUDgsrOzyum;
            quIEvOALrxlQzp = zJzWpIXGtA;
            TTUeXgpbDexr += TTUeXgpbDexr;
        }
    }

    for (int AKkREo = 575893101; AKkREo > 0; AKkREo--) {
        jOOUDgsrOzyum += jOOUDgsrOzyum;
    }

    return yiiEdACiMjj;
}

string fEfFcDvhIfEoUrLA::rRGLuCUk()
{
    int KkWlpmMqAIoyQ = 74752413;
    bool rTeJJXZTSGuDIC = true;
    double GcGXOWIsHilGFE = -102314.54311424712;
    string VeeyFaKvW = string("qExFqrldCmAUelJdTwTBJSqFnCJbdMrfbuuXwSLXLzPMiqUMPQZYafIxLcnUzZQKpDwNKlMZFHRat");
    double XnHjmYYDExBwDvz = -1017959.930999856;
    string glAxndYw = string("jVgDkYDkJYeAjueONByXslocyeVIZVJzQAgsHLVNvoskIfzUBTwlAyyDsziGA");
    int sutNWKVeOEZkmiB = 1538938884;
    bool eYwWjyYxkB = true;

    for (int HPZKzT = 228986534; HPZKzT > 0; HPZKzT--) {
        glAxndYw = glAxndYw;
    }

    return glAxndYw;
}

void fEfFcDvhIfEoUrLA::ErBPGJduekwi(int snePyZXWlkx, int YLdXFpceIacHnRx, bool CGqDb, double YzmBbZRZaZyQC)
{
    double YwiGDQRe = -187801.98604997332;
    double UAuMtzcgViH = -180205.55456431574;
    string WDOeNvndmQSnZkm = string("VUarHOljXlDhXYOrgtIalerGabDcjKZDjUnxNqhEnNFJzSUclOCvypGFlulcgzHwgFZPdVbbhRhRCYgRoUYxbcWQHXMcLxKdtnifAzgCdtLtVOwUtbZGyMLLMySGByPddSYChUPoPcFLqwpvMLjCGxcRnaehESX");
    int fEpGsTT = -771061868;
    double pzpnDGG = -995723.8926918275;
    int vTkiyHVjM = 170589819;
    double uwiQFNQfggRQdww = -850461.7210478391;
    double nnGghYfgrYODZk = 174997.79148070177;
    double FHMMdYtK = 741132.2395747002;

    if (YzmBbZRZaZyQC >= -180205.55456431574) {
        for (int XoRpbylWVmDcYc = 274926484; XoRpbylWVmDcYc > 0; XoRpbylWVmDcYc--) {
            continue;
        }
    }

    if (uwiQFNQfggRQdww >= -995723.8926918275) {
        for (int SdsjHJfr = 702450508; SdsjHJfr > 0; SdsjHJfr--) {
            continue;
        }
    }

    for (int TujuNhbmqL = 323669894; TujuNhbmqL > 0; TujuNhbmqL--) {
        pzpnDGG /= YzmBbZRZaZyQC;
    }
}

string fEfFcDvhIfEoUrLA::jcSdFzern(string hOalZGh)
{
    int hehJToxZs = -676064626;
    string rILEWbtOmL = string("wASzBsDPDfquaFdcihLcSMDjlhpXInrmkzMThmwSdvmOCxupYQfPyHTBMXUbuaeKXdhZtxvRSHosqSEhZlTSAiWAGLRKITUHFvVXyJZkFRnDaqqBulLXVPNMZenqsNQVkqgWOlsGpRgYJSOuViBdwmgcLTsUVFaKKWNqBjHlGnZZCetjCPUIFLdcOWarXyyNWmQKrfjLSNSUkGHFUNVmEbPWoBARGlPHQino");
    int CXWrJCftQvby = -1888338395;
    double wXUBaNCWc = -881195.576779842;
    bool ZDarkw = false;
    int LImFnlTQ = -1537607388;
    double aOXmR = -245903.3686267616;
    bool jHjDeNxeqbYHkB = false;
    double kdnIjmmbvkHB = 1797.3625453314353;

    for (int pLbyahUQ = 17401558; pLbyahUQ > 0; pLbyahUQ--) {
        LImFnlTQ -= hehJToxZs;
    }

    for (int fHlnAmCiimYgCf = 678312965; fHlnAmCiimYgCf > 0; fHlnAmCiimYgCf--) {
        hOalZGh = hOalZGh;
        LImFnlTQ -= CXWrJCftQvby;
    }

    return rILEWbtOmL;
}

void fEfFcDvhIfEoUrLA::JAMTkfndbiLpIsgF(double zhYUnmEfbW, string KyBndV, double DEIOH, string TnyMCkGgB)
{
    int dOKtr = 2100430724;

    if (KyBndV >= string("FVhYuMoOKtDdrNDaBzmIhxONjFAqLnbEIuqOzubyTWQjQTVPdYyyPPSJcAJmvHIlwepEAvIyoRZPsutEHjswsqtchDZsHSHfTzBkHOLAazNfd")) {
        for (int BUjQdIDi = 363192865; BUjQdIDi > 0; BUjQdIDi--) {
            KyBndV = TnyMCkGgB;
            zhYUnmEfbW = DEIOH;
            DEIOH /= zhYUnmEfbW;
        }
    }

    for (int qTtRzFREiOX = 438053573; qTtRzFREiOX > 0; qTtRzFREiOX--) {
        TnyMCkGgB = TnyMCkGgB;
    }
}

void fEfFcDvhIfEoUrLA::zLsWsBf(bool BWsNdDP, double svFVUQ, string pzrcs, string OWvXYXotKPdSkbx)
{
    int kOSbAU = 228354344;
    int bXeREfohqIwAyR = -79434299;
    bool kadBGDf = false;
    string qrvLokjUS = string("CkJkZfhTcyVpACynFtuKbSEqhIDMcBpbxnbhqzHITKeZKSUlgYCHSflREheLwHPfYsLjXmVEhyaywAgDYBQPPbOvmcdjqRLqzvyvFtF");
    int lQtzKADJ = 1823712489;
    string jlXLt = string("dODcwteWHmDemlCLwCIyMpfEImvKAhEvxvwcHlngSnnjgXIOkvcYahceMKOvjlzZxQqttIWdFYzUoogyTQqXLfasGhKnAUtYxUU");
    double CalqmKaubCqHcn = 498414.3670354881;
    string BAksTyL = string("zNqRGTtCqHzNYaYFWowlXoaIEiYRmVRMOfGXZwqTrzbzuVslEDllXdbjzimtkitMROqtTTVoryzLUBekopLAHanGsMVQuVnudFrOpAkYIWUUQDYmIvciumatCHtJpDpRCwSSAtOeWXJfvbuuVWhVnflRcQgrodvuGusRkguitjhNJoyTtaiYZSWvBedvGIQxyASdVwZWcmGnMNCUmxhVlhosUxWECVFIqwhWcfPUnKBWCHWWqoibyoHXgHXjdB");
    int gLXeJnzvstGZek = -935019209;

    for (int DizDNGN = 215508313; DizDNGN > 0; DizDNGN--) {
        BAksTyL = pzrcs;
        jlXLt += pzrcs;
        BWsNdDP = BWsNdDP;
        OWvXYXotKPdSkbx = BAksTyL;
    }
}

bool fEfFcDvhIfEoUrLA::bNPZWoarPDgoX()
{
    bool qCKPuKKomBk = true;
    int qAgbQoBxLvaw = 1141806207;
    double PdRzZwBWTEpNEkHA = -843444.0506567211;
    bool hhTZcmiLlqybqR = false;
    string wEFaRMGTHCWIEc = string("YYjShINxKyLpYyDolSodWNSEJUsFPwrcwAhTHJcstnTwebrlAZzbSwZSJGPsVwwvLvbcQLryTuOhcVDAPUpEIngBnAoJeOzAxCHdjgFgYeriAGRsVUTWpEZvcbHpFdNCtgRCTqhGoyKwDEjDOnUwTQusjImKGSWaSOhKrZwmRRulPpHZbeMiRSPWUJlIYEajSkGPfXkcRscyqHRFllkIUfrEGkWufMzscACxAc");
    string TRIJfn = string("VKORYZJpwuaKkiqcSHKgWtedTxBRyhVyEDnUpZaLTpdxUsjGfwCSiNjjCcuLkLAyIiRBTIkFsUckyqHfZpwDVahGCMFfYTUXbwQnTTvKBYVvuWBNzCuuxeVKEXtZxttqsVNJQqaIqlBDSNuKkSViJUhlflCJfwYLFwhtAfBDBCPC");
    double DJWfFeJ = -842802.3606844376;
    bool zRSrVUpQnXst = false;
    double xZfNhathalYlsUHk = -649901.2625192516;
    bool YwYkPhd = false;

    if (hhTZcmiLlqybqR == false) {
        for (int yUoWYIsipy = 167995537; yUoWYIsipy > 0; yUoWYIsipy--) {
            PdRzZwBWTEpNEkHA *= DJWfFeJ;
            xZfNhathalYlsUHk += DJWfFeJ;
            hhTZcmiLlqybqR = zRSrVUpQnXst;
        }
    }

    for (int bBaCNthaL = 1291760354; bBaCNthaL > 0; bBaCNthaL--) {
        continue;
    }

    for (int ZZjzrigU = 916104003; ZZjzrigU > 0; ZZjzrigU--) {
        wEFaRMGTHCWIEc = wEFaRMGTHCWIEc;
        qCKPuKKomBk = hhTZcmiLlqybqR;
        hhTZcmiLlqybqR = hhTZcmiLlqybqR;
    }

    for (int CGFmTdxGhN = 1555839422; CGFmTdxGhN > 0; CGFmTdxGhN--) {
        continue;
    }

    if (zRSrVUpQnXst != true) {
        for (int ANGjQ = 775231591; ANGjQ > 0; ANGjQ--) {
            wEFaRMGTHCWIEc = wEFaRMGTHCWIEc;
            hhTZcmiLlqybqR = zRSrVUpQnXst;
        }
    }

    if (YwYkPhd == false) {
        for (int szyumo = 455575716; szyumo > 0; szyumo--) {
            continue;
        }
    }

    for (int RmOMOdQiKufGhl = 640109617; RmOMOdQiKufGhl > 0; RmOMOdQiKufGhl--) {
        TRIJfn = TRIJfn;
        zRSrVUpQnXst = zRSrVUpQnXst;
        PdRzZwBWTEpNEkHA -= xZfNhathalYlsUHk;
    }

    return YwYkPhd;
}

string fEfFcDvhIfEoUrLA::rjSnQDTwRfu()
{
    bool wwLMYZfELq = true;
    int YPewyxfQV = -2091520668;
    double rKAPykD = 382952.44317188044;
    string JTghRsAQB = string("LeWAWjpRnsFABLHdBDpJLsUqfkHJWCOGfVSIEhYoFpKljdBhRwuYgfcbofehQOboYYwtLmjeufVJBSWiCqrcdDmjzphQFntDebbRqJNqtZtYhJCtfQtSrpEiHutSnAYolIfsgSOlZBbYVqCoaGqqKGoVhkYNboJwooviRZhYHpgBeXTPDPeiqhiQUaiMxWlDYSPkbXLjRdhNsasbdvwwdfpIKZpogbSPVY");
    int APeujnklBqfeRNd = 1860893158;
    double mhBtuxbR = -1023366.8172777642;

    return JTghRsAQB;
}

string fEfFcDvhIfEoUrLA::OdNhH(int blhdxPULM, int yDwzA)
{
    bool zpPEnJZxKpWEvu = false;
    string cVRrteDQWU = string("yoPZCqvzGuMAjmJmYAiHFHHSMzDUdtHrnCqLaxZZSZzpCMJIrRAwsOdVaXOpexSQxISaonuRLpTCcGIgwczlMwJERtRcoUdcsnAuhZsOIzsYmadXPsAUOREpIOKcosFccmMgMsjwteiLTiUJyw");
    bool MYmDrOMqxBPQ = true;
    double ozIwfTp = -242384.07936727875;
    string djYHtbtYgPzsuK = string("iQcYWmFJVslQH");
    bool whYAlVSAjUsxboGE = true;
    bool ximuD = false;
    string AsuaLqagDaugk = string("aaBARnZEamaCWBXhnVtwqcXYKnSyvMnUImxxzgMXWBerDMLnvPIQyqTruNnYSiJHWXFDFsydoKNmLbagWopfaaAUasWphIokDcTqJKsVfmeKrkbDXyRALUDMAITVFWbOeBlNFRSNUygdZqfghzVIqnSqTQRTaOXhdOJglkuGKCVwaqvcUReCIzoiXMtazBgHWbTneGe");
    int JtCkbWP = -918405752;
    double MhnGN = -865968.7829937456;

    for (int rUuSCHNem = 1575936167; rUuSCHNem > 0; rUuSCHNem--) {
        continue;
    }

    if (AsuaLqagDaugk > string("iQcYWmFJVslQH")) {
        for (int IpjVPMidGaqdkoL = 2005293301; IpjVPMidGaqdkoL > 0; IpjVPMidGaqdkoL--) {
            continue;
        }
    }

    for (int hSomcsFdDb = 1325797994; hSomcsFdDb > 0; hSomcsFdDb--) {
        djYHtbtYgPzsuK += cVRrteDQWU;
        djYHtbtYgPzsuK = djYHtbtYgPzsuK;
        ximuD = zpPEnJZxKpWEvu;
        MYmDrOMqxBPQ = MYmDrOMqxBPQ;
        MYmDrOMqxBPQ = zpPEnJZxKpWEvu;
    }

    return AsuaLqagDaugk;
}

double fEfFcDvhIfEoUrLA::ydXjB()
{
    double GtofiV = -543611.5430332217;
    bool SoUJAV = true;
    string vVVQvToCsXVH = string("BkZejZkbPfcYrwauUWLZtKRUZLmiNFueXNItffetJeHCMCCStStyAQRCmvMuadvMskzFLDUObUOZctBpTgPEOFLPVjFoNEGgNUFsjznbjZwNkkkfjrlXygJQNlJXcNQkRvTHB");
    bool bMtrKSkqjKYAbi = true;
    double oTtmKByz = 121508.68843601139;
    double TJEfYxDaJczI = 922223.5457547809;
    bool yTAvLGbNIJpL = false;

    if (GtofiV >= 121508.68843601139) {
        for (int aKttquuoY = 1130461245; aKttquuoY > 0; aKttquuoY--) {
            yTAvLGbNIJpL = ! yTAvLGbNIJpL;
            vVVQvToCsXVH += vVVQvToCsXVH;
            TJEfYxDaJczI -= TJEfYxDaJczI;
        }
    }

    return TJEfYxDaJczI;
}

int fEfFcDvhIfEoUrLA::kGXgpbhBYTwi(string bxvHCcZVuiIhcY, double fEuZVXsXIf)
{
    bool bBAmEuNuTyCFR = true;
    string BNbZlvyDKDpGDdb = string("maHCxDEqzaSXjgPnfpHXUDFKEuiFZdUPXPuJmtIaHfVnSDXxxv");
    bool XMJXsSdoNj = true;

    if (bxvHCcZVuiIhcY != string("RAJXdvgYJEEYcwNmySpzymTqstqMmvWVNSSHWOSKfTlLcXoEswPZJCzRwNbhIavhoSjaOWDEFsplUGEyFRPQfNqHRWlpWkOOrpFzZkTZcvsACroVlaSWUfhPUsqEdnuuyJWvgCp")) {
        for (int RlswoL = 1338067377; RlswoL > 0; RlswoL--) {
            continue;
        }
    }

    for (int CMWVMCicovuYy = 1469390231; CMWVMCicovuYy > 0; CMWVMCicovuYy--) {
        XMJXsSdoNj = XMJXsSdoNj;
        bBAmEuNuTyCFR = bBAmEuNuTyCFR;
    }

    if (bBAmEuNuTyCFR != true) {
        for (int kxdnUbGiVwJtMT = 2025307445; kxdnUbGiVwJtMT > 0; kxdnUbGiVwJtMT--) {
            fEuZVXsXIf -= fEuZVXsXIf;
            BNbZlvyDKDpGDdb += BNbZlvyDKDpGDdb;
            fEuZVXsXIf /= fEuZVXsXIf;
        }
    }

    if (fEuZVXsXIf == -804018.8293573883) {
        for (int hoHOHm = 188160925; hoHOHm > 0; hoHOHm--) {
            continue;
        }
    }

    return -1098822332;
}

double fEfFcDvhIfEoUrLA::YldmxxalqUywAb(double nfiigy, int vSNOeq, int eZfLZBIIwOlDuufE)
{
    int rmRYFJBUTvyI = -856625434;
    double zauBgMTSlRoxyyT = 545492.6027910312;
    int IQDBy = -196191447;
    double pDicfwwqPcdLoWrl = 145978.41532490423;
    double POqQyUTDRGXrh = 283023.44117506966;
    string jBuUseyWVqnlUkit = string("arTcLdoohZObtjhLpKEauSJDOIqhQtMPSdbEudrvxZGzpnKsZrWbMZxysvDmaKdJRmesBZtYuRiseAIaBuCyrFIftyEGvirHDMMWeNYpBUtvVyZSuuwCgQzTmhLRUGNCpptLQkZGCFFaGIjsWEfmUTHkHuhrslURPTIbALKQOJCUrWsoXkTfaVLJIQMocjcyTdgywgFHlQsusjAzUqyShWRmWDMkXErBLhELMyOaFOACbETePIIPSjpLwjbNL");
    bool NEKjxduMaY = true;
    bool wfYPILFVhez = false;
    double TQrscwdSeNBE = -746361.3851056736;
    double lUxrkbNCrEj = -746781.4225691727;

    for (int lEWSTMzjQBIruDNu = 1960879977; lEWSTMzjQBIruDNu > 0; lEWSTMzjQBIruDNu--) {
        continue;
    }

    if (pDicfwwqPcdLoWrl > 545492.6027910312) {
        for (int WvLXmXrRCP = 1928044515; WvLXmXrRCP > 0; WvLXmXrRCP--) {
            rmRYFJBUTvyI *= IQDBy;
        }
    }

    return lUxrkbNCrEj;
}

string fEfFcDvhIfEoUrLA::OULoyhEQdOPxBzY(bool mcLVtDou, string OnqtfcrItoZU, bool TNaLuOxFFO, double wIpgQ)
{
    int yREcdN = -426742399;

    for (int nQhVqjmhevwZTy = 1950089116; nQhVqjmhevwZTy > 0; nQhVqjmhevwZTy--) {
        TNaLuOxFFO = ! TNaLuOxFFO;
    }

    if (wIpgQ < -810135.0333129521) {
        for (int SMRReEOC = 1905649928; SMRReEOC > 0; SMRReEOC--) {
            continue;
        }
    }

    for (int bZpjtQtXDUjrR = 806286173; bZpjtQtXDUjrR > 0; bZpjtQtXDUjrR--) {
        OnqtfcrItoZU = OnqtfcrItoZU;
    }

    if (TNaLuOxFFO != true) {
        for (int xGVDjCnxilszFSE = 1485654474; xGVDjCnxilszFSE > 0; xGVDjCnxilszFSE--) {
            TNaLuOxFFO = ! mcLVtDou;
        }
    }

    return OnqtfcrItoZU;
}

string fEfFcDvhIfEoUrLA::yDvIFVDyQlg(string JAfrxNvrw, bool BxCbEhwLuWgnIpMo)
{
    string KHJNzvmbRmJCtqCr = string("BfBLOiITnxmmxmyOWJptwHGEqqbcFXKwoXkxyxITaxHCwmaTgfzAiHWAzbzkZhdrZuokZmKGPFBuhaOvWiNphPQsfg");
    string NgYFWZhe = string("CbvWAJcVTnuKBgWVtoRIhbDyXvPUKAAHFBjVEvlgUlWOyOpTfzYMtGGQMn");
    int mNZckn = 740089241;
    double oocVgEanxhNvwQ = -611857.3789394639;
    string IoHZSmaJcYgxJOvV = string("ziHpTjGUkGVWWVqnJpTOGuxmlTaAfhUhUftAShsJNPHZmCTewOsnHDsQSUkJwuxDEKYYYNwkCKgLudIKuyDmPdGflyNliDzammMhSHRNpWkbcFAyJAalAZyWcSCmGpwNRU");
    int RtOzjz = -745189657;
    bool yrsYp = true;
    string CiNjoVKFJvzE = string("QfUpvNuUkKtFYTCdzgoPhCLonrHLNXcbpknickOxBRdWrGpscGjxhyoVYsIUSvRcJtJvpNdpeWOAgBxaTRxWxpidqmUdJaibKAXdpsWZtizbvnLZvSUSkJtehAAziVcERxhFGIjSGCPisupHmXCrqPsxOdfkEmIcOqacoEeNflvjHvNfDQZnhfuJhknpHHdVzSeadhMtnOjSXCqGWXxIjiLLtrxpdMMDbWphbBRSATKjMjZdodK");
    string nyrRLCST = string("NIPFiLLFjkvpsKgiGWqRAbOjlsfEazkMtdlPksyFwZMrERrPOCXdFFNhGRtiuoTQZLqEGvHKMXrLYoXzmqIIEktChwws");

    return nyrRLCST;
}

int fEfFcDvhIfEoUrLA::SjygZ(int hbeYzK, double fziLcGymwGVtv, int hKhEsQMewg)
{
    string MfHdkKz = string("FlNEQKBhKuDOyvWZMXaSdvRJcCNwpiOBGIAHoXDlyWGubHhKQcbUEmyOMAmmkMizNcJRAkLWSExuiZuolwWHPuqDJZnVbqBQzuZAKlaDluvfJtFjQlvDAMgmaQQppjBxGcsklpiqVdYhXhfHvOIirsOhQWBPgvZtaCaWKdAMuSLbXO");
    double IgyRloRXPpile = 144997.81372551626;

    for (int GEdYgkB = 1163901349; GEdYgkB > 0; GEdYgkB--) {
        fziLcGymwGVtv += fziLcGymwGVtv;
        fziLcGymwGVtv /= fziLcGymwGVtv;
    }

    for (int PKFzQrvCfPQK = 773357169; PKFzQrvCfPQK > 0; PKFzQrvCfPQK--) {
        IgyRloRXPpile /= IgyRloRXPpile;
    }

    for (int dbaAVdM = 91255564; dbaAVdM > 0; dbaAVdM--) {
        continue;
    }

    if (hKhEsQMewg < 826145816) {
        for (int mlYiLjbr = 1073818263; mlYiLjbr > 0; mlYiLjbr--) {
            fziLcGymwGVtv *= IgyRloRXPpile;
            hKhEsQMewg *= hbeYzK;
            hbeYzK *= hKhEsQMewg;
        }
    }

    return hKhEsQMewg;
}

int fEfFcDvhIfEoUrLA::bQwfLmjpC(int dRoLsmrio, string aApjgZ, double YcZOo, string sdGwZHDVk, double aFOvXJF)
{
    bool ExTujFZLEsRLq = true;
    string bCqLOqLtSlUhnRJ = string("WgwPxsrBwgfjsBkpvlMINJkHREWhjzIBcPSAuPranJQQkUVilQzZjr");
    int vdMJsl = -208339383;
    string MfMeq = string("RsrZcyfNpeahrSPlNADFukLYumwMkNLyNudqagsCBTOwDlziPcRtRCYPzVevAUhTaPMMfNALRAwwdFDZJITdNkxTPrMwTkyieecGXFXJuNvYFvAKMiZWvFnmsjaaiSReoMjhKqEABSNEDkSed");
    bool vvvkH = false;

    for (int uPAhySJpd = 41101177; uPAhySJpd > 0; uPAhySJpd--) {
        continue;
    }

    return vdMJsl;
}

string fEfFcDvhIfEoUrLA::onIwAYyYYhrDwE(int SYQEufVLjX, double QcAJhSoWGE, double BWXqpTpnMgEjCBm)
{
    double goyxarW = -1031477.6365506861;
    bool dfymH = false;
    bool otzLohHwJRZEV = false;
    string alwIGDtal = string("JalHCjYUfYAKbqdrBUjbTlvJWHtkJXZYcmLcFWqzOqAIYgmxONVWmWZuXeBMj");

    for (int TsJeeZlbByRUYPT = 74385378; TsJeeZlbByRUYPT > 0; TsJeeZlbByRUYPT--) {
        goyxarW /= QcAJhSoWGE;
        BWXqpTpnMgEjCBm *= BWXqpTpnMgEjCBm;
        goyxarW += QcAJhSoWGE;
    }

    return alwIGDtal;
}

double fEfFcDvhIfEoUrLA::PuXvLK(double OpJgcNQlIuRrAlk, double nWQBL)
{
    double lfDeaffeS = -59095.82587376132;
    string UMxDFrNCUvVyb = string("lDHsCzQwtYuBxHPoRcQSXRCIjfMTmowMmrvCqrhoXdNbyYKMIvbwrnxpCHFpAsukiMKdMBUoNJSzLFvhtHsXmDnvgllJTjCsiTEZXJIr");
    string VNbKVbnFS = string("etshlbuqVRsSDuoWqLlNRyXLCOMdLspASAjrExOcxlhyrKJOknMKuDXQyIiGMRvHOFGJLWAATJQImSvAlPPLBMWZJWBLTKsibdOVThFOGXiTNJcImOsFyZzliBpTHUQ");
    int HKCDtpeT = 97057794;
    int ZYWGRXxI = 1748904127;
    string sfXYN = string("EDCcMbEjhecKmJYzbvFKwziuNLZom");
    double RPbXf = -36060.4578867323;
    double IJQysQe = -406068.16587187664;
    double UiPiJdnZ = -965629.4860179912;
    int DEmPQajmFJka = -2089343072;

    for (int tOLDcjnfXuLWZb = 1563070572; tOLDcjnfXuLWZb > 0; tOLDcjnfXuLWZb--) {
        lfDeaffeS -= RPbXf;
    }

    for (int GdFcSVtWd = 1615301800; GdFcSVtWd > 0; GdFcSVtWd--) {
        OpJgcNQlIuRrAlk *= UiPiJdnZ;
        nWQBL /= nWQBL;
        lfDeaffeS *= UiPiJdnZ;
    }

    return UiPiJdnZ;
}

void fEfFcDvhIfEoUrLA::sfXkNwD()
{
    int EvehvNnEkYIRZZqo = 2107021698;
    int pgoLhLrqGBGY = 111470938;
    bool MLHcnBG = true;
    double SwUsZnXc = 117561.97931454697;
    double OUrPAsdlspVc = -658698.7277462455;
    int BycvEdcYJ = -1008280532;
    int sjUSyZLJp = 30393161;
    bool vQRWAmokwvtKfn = false;
    bool zXyFAODka = false;
    bool IFHDKs = false;

    for (int DqvCzZgbmVlvPTgJ = 846564933; DqvCzZgbmVlvPTgJ > 0; DqvCzZgbmVlvPTgJ--) {
        vQRWAmokwvtKfn = ! MLHcnBG;
    }

    if (OUrPAsdlspVc >= -658698.7277462455) {
        for (int nFxlCNRzmsXb = 1670807267; nFxlCNRzmsXb > 0; nFxlCNRzmsXb--) {
            MLHcnBG = ! IFHDKs;
            SwUsZnXc = SwUsZnXc;
            pgoLhLrqGBGY += EvehvNnEkYIRZZqo;
        }
    }

    for (int BezEsEdoHB = 1503665033; BezEsEdoHB > 0; BezEsEdoHB--) {
        SwUsZnXc -= OUrPAsdlspVc;
    }

    for (int xSxVemmRw = 1498931556; xSxVemmRw > 0; xSxVemmRw--) {
        pgoLhLrqGBGY += EvehvNnEkYIRZZqo;
        pgoLhLrqGBGY /= BycvEdcYJ;
    }
}

fEfFcDvhIfEoUrLA::fEfFcDvhIfEoUrLA()
{
    this->gswonQuprBK(-106136.44251303142, false, 596251.0410516819, false);
    this->rRGLuCUk();
    this->ErBPGJduekwi(-1150726798, 2055489689, true, -6425.334001356);
    this->jcSdFzern(string("ZSXYyuzfqysMzvJTHBBEyebjOZAAGgsnKwiRsTMNFBPdlzmILtEDoGNBmIssLecgatjHEqdfISIIWEjtD"));
    this->JAMTkfndbiLpIsgF(-429564.13502657664, string("FVhYuMoOKtDdrNDaBzmIhxONjFAqLnbEIuqOzubyTWQjQTVPdYyyPPSJcAJmvHIlwepEAvIyoRZPsutEHjswsqtchDZsHSHfTzBkHOLAazNfd"), 303621.3297744958, string("EzOhiCvUOyxdqtyaGPUryXokDPuNFJhVvihKmCiVHSLjXXTIXDPDZTQaRHDNutLnbVRGPEMQSQbjcIlQhJkqNeFBEGrYSOJoBEEEnrukjrMFhtyAWUaGpDtABsMJHpCsqIsDNQMABGhSxLsefmpOkJfodlHAnQeTQZUXomlWilLeMgwdjBqSmDcJkSpkDsoPKentutmmnLXWIlmDGdwIKpkMdsaEi"));
    this->zLsWsBf(true, -128540.43800024099, string("CBKsXvusnZkSowJJgtdEZoCSmyftirNWFuYWphObZlNrcYokrExzTsiNADKIVqiBRrAspsmxvrwFvoWAbliAysnVWdNLasNfGiCYhKZUSYirWqtNIqXJWkGzKPrVjynjwUpvfusPxdmyfhOBXwXDMe"), string("mYYRDdBjEAotPVuJHJTZomQXDJdHArsMwmbUVNMPeWjcSrrgQsiOXbEBAHhCLUrAZNtGWeUozMoqLSYUtltWOlhjBFHDZjgNmZRoOCPmqqedZLRjEEoDqgHRtL"));
    this->bNPZWoarPDgoX();
    this->rjSnQDTwRfu();
    this->OdNhH(-636063983, 1046110330);
    this->ydXjB();
    this->kGXgpbhBYTwi(string("RAJXdvgYJEEYcwNmySpzymTqstqMmvWVNSSHWOSKfTlLcXoEswPZJCzRwNbhIavhoSjaOWDEFsplUGEyFRPQfNqHRWlpWkOOrpFzZkTZcvsACroVlaSWUfhPUsqEdnuuyJWvgCp"), -804018.8293573883);
    this->YldmxxalqUywAb(822728.1620523719, 1112129090, -1274353275);
    this->OULoyhEQdOPxBzY(false, string("LCxeyKdCfjGvPOCbqDrGMRmxELLUAehvmWSesqIoJtoYZkalxknPAljksNBYBPVcTSDNxLOKayauRuRobsbqvFKKaNOAlnwEQPzfBzprIRgSXKnTAwfUeiXmlRcVmFwma"), true, -810135.0333129521);
    this->yDvIFVDyQlg(string("nseUDUqpcCATKgFvVQvwPtfBboMYzXqwUNJxcUAIDwxkXcemCFyZPZHcoVddECDtDDNuaYLiMDNxubNSMGFVaYgRE"), false);
    this->SjygZ(2067395568, 989739.9840931707, 826145816);
    this->bQwfLmjpC(1107920979, string("HXKXdOQkJbfnTLTAJhLIrhoAEFwSRDQjiYxgkQjfcfwRpHZrgnJpvarJtfElsabpkFYsvhSkQeuhEBoNZMxPDUHtiukzRJJPMcEqnAODxkUopeRqhFzZQKwZJDmvYJWedhPOtlrzCF"), -732085.2304195397, string("gdzynSEsMnBom"), -906184.7266518758);
    this->onIwAYyYYhrDwE(400877630, -216565.24452704372, -274370.2433931765);
    this->PuXvLK(-773001.3651576119, 160020.7971664808);
    this->sfXkNwD();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ymeVeWfZmW
{
public:
    double rASuiENxNOXw;
    string vxAJhduDzEPe;
    int KPhZqFY;
    int KLJnJ;

    ymeVeWfZmW();
    string EOgrmr(int gOjDmID, string YyLunTaEzcU, string zpDqdrNFsCRSDinp);
protected:
    int BbeIoF;

    double SjNLntBJWAcR(string dNrCcB, bool RRJkTmXXzBIqALB);
private:
    string LHIFhNZtOpdlU;
    string AVbNBgkWr;
    double tMsMPR;

};

string ymeVeWfZmW::EOgrmr(int gOjDmID, string YyLunTaEzcU, string zpDqdrNFsCRSDinp)
{
    string rmeVhvCHRVdVPEXM = string("wAmXhnppIoVZkyzggcjGzITLbqHvihRgDCMsesPQVIMsDcwuhNXuAmZoAEBuOEpKEGexPWoTLQzXeOfHhntZQLKOvjrbxqKDJvnHDxzWhwhJTnSZcXxeUpbWwWGoZZGbtlwIHpqfXUPczobTFpqpTCIyGyFauDSabGnxjIbSOECdGNSYErLSMFowbOYUWVcpVrxbYBYEKIWXkuUCIZnkDTJEgxxCcLDZ");
    string sHffw = string("GfkjSqYycSorlJVOYgNAaDLRCTcbIpkPxTLVdnZCSttLvOXAfOGoYuEoWfCbRzwXVXhFnNRLYWDedGPixKZqVxkDaBWnZKdKfyBRHmoFQqaWQXCDPasGjpUumSNycQuqIbAkocvcrNgatTbKUiKxwffGvXCSkeRkvoWanRAQzQgxjiGhfDjUMFsCdHifc");
    int ISlVAuGx = -1106735184;
    string vJCqrESjVDVfcBG = string("jFOlTXRyoqtKziSXzGQbMDgpNzaeVTjVuSHlhTinyRfLaiqMohBEjkXLMcXUehqdQHmmDUjuxnvjxNciVQSjpofZBBcDVlCLPOLzmuCrAAgtFaYIPFCxBvhFUyktChGxncXLeIcSZKkAIerQeljSQPVdNOOkQZUdsjPIradcDjMboyRtIzJAyPCFaMvnGPpz");

    for (int dngaEkK = 450671553; dngaEkK > 0; dngaEkK--) {
        gOjDmID /= gOjDmID;
        rmeVhvCHRVdVPEXM += YyLunTaEzcU;
        sHffw += YyLunTaEzcU;
        gOjDmID -= gOjDmID;
        vJCqrESjVDVfcBG = vJCqrESjVDVfcBG;
    }

    for (int qnMAvVAJ = 1633213694; qnMAvVAJ > 0; qnMAvVAJ--) {
        vJCqrESjVDVfcBG += rmeVhvCHRVdVPEXM;
        rmeVhvCHRVdVPEXM += sHffw;
        gOjDmID *= gOjDmID;
        zpDqdrNFsCRSDinp = vJCqrESjVDVfcBG;
        rmeVhvCHRVdVPEXM += rmeVhvCHRVdVPEXM;
        vJCqrESjVDVfcBG += sHffw;
        zpDqdrNFsCRSDinp += sHffw;
    }

    if (zpDqdrNFsCRSDinp <= string("pXiYHKpBTMCHUKOJwuQuwrYGkkaPdVmfhgRnUtbsyJpzOyCVpslpKcqQDJSlgNlVGEGzYAVSfcQpPdJhsVFkpLVCfZrhrrOrcBqpehpDrsTZryafkVEzfaOrwwTTlNnmslySwNrpzdJUGsKJINBNJSSazvJTTQzbRPjrAmenjtiWiRdeKwKbhBJrWWvhbUHwPFwFyEdCsBxGMDMBZMzVErTQHiYHBi")) {
        for (int cOKrTYNb = 1596214189; cOKrTYNb > 0; cOKrTYNb--) {
            sHffw += vJCqrESjVDVfcBG;
            sHffw += YyLunTaEzcU;
        }
    }

    return vJCqrESjVDVfcBG;
}

double ymeVeWfZmW::SjNLntBJWAcR(string dNrCcB, bool RRJkTmXXzBIqALB)
{
    bool ECSvyCnVpWh = false;
    string JnQpvWPtlSw = string("YSqDPIEKSrnlgRVQt");
    int MQpoYIU = -1816569907;
    int WBELJjsrNcC = -1490233535;
    string KBZYKxvYh = string("RlDrUmRaOouWhxroLrcrugbGlYrLrmpCQoShx");
    double HphWeIPkYo = 262111.78683962545;

    return HphWeIPkYo;
}

ymeVeWfZmW::ymeVeWfZmW()
{
    this->EOgrmr(1776855353, string("VfifscxKAwaOrfOOzxaNOhCxQJTRCFDAfxJVvmjqhTUkMRlLOWFRyYuBAUvwBcfVnRcJrQbuJfcLZLmWJBiGAdyzUwFHIIckSRlslLhcGeekPsPNEbUueUlRPNGBEIFWXPeOvdZQBNfGAYNsLvusFRhgRIwYKDTyLxHBxSvykYh"), string("pXiYHKpBTMCHUKOJwuQuwrYGkkaPdVmfhgRnUtbsyJpzOyCVpslpKcqQDJSlgNlVGEGzYAVSfcQpPdJhsVFkpLVCfZrhrrOrcBqpehpDrsTZryafkVEzfaOrwwTTlNnmslySwNrpzdJUGsKJINBNJSSazvJTTQzbRPjrAmenjtiWiRdeKwKbhBJrWWvhbUHwPFwFyEdCsBxGMDMBZMzVErTQHiYHBi"));
    this->SjNLntBJWAcR(string("WjBZXoFTzeIOfyK"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GUCvxkjmDMJbcLwP
{
public:
    int SaDbhX;
    double gvNKvS;
    bool UfItIoWBSvANpVGt;
    int WaPAWYGpeyo;
    double qlSzh;
    bool PKoqDe;

    GUCvxkjmDMJbcLwP();
    string pVFofAaBHAcmmwxB(string qFYNdYGOqDMB, bool uAwMbaluH, double KiArgAVLa);
    int gyMUqOJMUmjtxevU(bool kbjvQJrfqhJb);
    void VPOSxDvJwfn(int YpJkdSvvRi, double TpDTiilOv, int LVJPGt, bool uziCiNnomjmd);
    bool lwZccLXhIYQc(int zIgaHmUeOBwBQ, string SYHXnqGgkTSFp, double SspVHa, bool fGymDBe);
    double lkwdM(double rydHb);
    void KqGMbrzyvb();
protected:
    bool lZKxSyBgGBeIzWM;
    bool SlfZWRofCfh;
    bool ezIUTCXLYEe;
    int oMBzrciyt;

    double FurhyfbhqVuj();
private:
    bool baVPRPiSW;
    bool Hsvkaty;

    bool kdFegODKnQg(double IugkEXGljqZDhTA, bool ggnzaLERb, string xkKRDzqfessPWlPd, bool RJbFi);
};

string GUCvxkjmDMJbcLwP::pVFofAaBHAcmmwxB(string qFYNdYGOqDMB, bool uAwMbaluH, double KiArgAVLa)
{
    string FjquBrTfR = string("wYiBCCuamKvAMbHePIxPKQrtlGWyTGSsagjwIMEqNnmLbqyCXxFzTYPmxmQmdtTCYrhSVJEGodBXIHPDwaaLKiXOOZGfDpysYFWcXMrwgCekqffWbVEwoIjidaSiRqsEzQJUORcdGjJhYgmiYQLpgqVNUDxYITGApWfEiBzfRfmfkwzKOPzGmlVCEHwDcQWnAFqiCOPkHddvmdpqLLQiWSspDCGHBkvcNsCIVUkrqpzmZsKjWpfKaHxYCK");

    for (int fPdyRZc = 1786448503; fPdyRZc > 0; fPdyRZc--) {
        KiArgAVLa /= KiArgAVLa;
        qFYNdYGOqDMB = qFYNdYGOqDMB;
    }

    for (int nHpznno = 1624526513; nHpznno > 0; nHpznno--) {
        qFYNdYGOqDMB += qFYNdYGOqDMB;
    }

    if (FjquBrTfR <= string("wYiBCCuamKvAMbHePIxPKQrtlGWyTGSsagjwIMEqNnmLbqyCXxFzTYPmxmQmdtTCYrhSVJEGodBXIHPDwaaLKiXOOZGfDpysYFWcXMrwgCekqffWbVEwoIjidaSiRqsEzQJUORcdGjJhYgmiYQLpgqVNUDxYITGApWfEiBzfRfmfkwzKOPzGmlVCEHwDcQWnAFqiCOPkHddvmdpqLLQiWSspDCGHBkvcNsCIVUkrqpzmZsKjWpfKaHxYCK")) {
        for (int dSQKkd = 1236357177; dSQKkd > 0; dSQKkd--) {
            FjquBrTfR = qFYNdYGOqDMB;
            uAwMbaluH = ! uAwMbaluH;
        }
    }

    if (FjquBrTfR > string("VgniGZyczQEyPIGuhJsbWPSzPVcfwnRXyqUCZBjGahmmZPquBAKZSXMByylguRcqHmHWadhexkYpjaTVlgLgRvpwIpOBBHELEZexHnIdBjsNUVPSfKQWiucOSLtMIYftQosXiXCrkQIwFpzuCeEIpQqhizBSulFhEaLdYHXLUqJuFFfNBBsBqBVnXlczJKLdbG")) {
        for (int twZazYT = 253398518; twZazYT > 0; twZazYT--) {
            uAwMbaluH = ! uAwMbaluH;
            qFYNdYGOqDMB = qFYNdYGOqDMB;
        }
    }

    return FjquBrTfR;
}

int GUCvxkjmDMJbcLwP::gyMUqOJMUmjtxevU(bool kbjvQJrfqhJb)
{
    int gnPpLCYVFCsw = 30384181;
    double MDWbCQ = -1011393.6688791991;
    string IaruJ = string("csspwBcNnpSpHRbfnlNIaAIqDijhAjqRsteIbmQTCEJgFLURKdbjSjivCStAkyHRxPjFZGYyaOjOUqahGdCGbLPqrwbTPAFZfqdhxQcaLOzMEsMyscYZZOSzBCmurgELfOaQprbsoQxsMxPDHYYaeXzCJNXsOOgyuigoesaxLWWRmypLYCyyJzpMUbUZBvBFtoVOSGDAftRmGNuISMtIYcvtqHcGhNrNaIeVSlLa");

    for (int bkkDvomJJrzrjOL = 1353400232; bkkDvomJJrzrjOL > 0; bkkDvomJJrzrjOL--) {
        continue;
    }

    for (int CdMNZXgS = 1844136882; CdMNZXgS > 0; CdMNZXgS--) {
        continue;
    }

    for (int rYrYQsJmFgmAcX = 833908678; rYrYQsJmFgmAcX > 0; rYrYQsJmFgmAcX--) {
        IaruJ += IaruJ;
    }

    for (int zmIPKLcYjmc = 166476183; zmIPKLcYjmc > 0; zmIPKLcYjmc--) {
        continue;
    }

    return gnPpLCYVFCsw;
}

void GUCvxkjmDMJbcLwP::VPOSxDvJwfn(int YpJkdSvvRi, double TpDTiilOv, int LVJPGt, bool uziCiNnomjmd)
{
    int CiTDqmNbg = -891968735;
    string EChtIpr = string("iEvDDzTnhfZNaFvqCTRSsEzCYhPFbLJWlZqFBpEuvSZBEjRnKcsYbVNiPQPejkAgmzFDGwshNJiaZrZNpFyQfXyRYBmvMYCaxPtjWVjAaEcMRkryTlEUaR");
    string jwMSWVnp = string("xEKbPNiIRfOytZJcgvfLHbaXSssmgxUToplaihFpxfGpDVLwKpAnydMywCJycbbYOIjAaNXeFauCCspIowUeHJIcmlNRzbtqFTUvJRjLyNamZAfIxfXdkcDkbcIboGbFVPQQtlqIwOECNGAfjLXcLMJPyg");
    string QPVfJEHQAqsuKozE = string("lmmU");
    int ANLlQI = -1420822109;
    bool YCFKWDGPdgJTemXG = true;

    for (int pvAmUunPa = 450691994; pvAmUunPa > 0; pvAmUunPa--) {
        jwMSWVnp += EChtIpr;
    }

    for (int dAisIggAjAYymjc = 570984277; dAisIggAjAYymjc > 0; dAisIggAjAYymjc--) {
        TpDTiilOv = TpDTiilOv;
    }
}

bool GUCvxkjmDMJbcLwP::lwZccLXhIYQc(int zIgaHmUeOBwBQ, string SYHXnqGgkTSFp, double SspVHa, bool fGymDBe)
{
    double KcJLTpxhIvws = -298567.30724035983;
    double wtDDNAjyNV = -375446.6434037145;
    double MckpCjsTR = 258514.7985567113;
    string LUDNMuoPAIyDURIx = string("OtvWNQbAqXosYabTWbERmJclhvgybqnDEfsuSScmlASMMhBGUNHumufEWYAPAwoUSxCsdLClPHMRiCRotQyQySFBUGBNFgmCEKIdgTOmftJxlFLToNNanhaDYBUOzWZGWglrBgoZwHYAxyAmukVXKVXrQlmduDirgLoxHkSEdSJummburUhdxCqwGYIaOlWlRPKYQxBLhpmdBukRRVfmNUSOfhENyFTNChWGShBiJBlNDtsvkIshBvOppysOk");
    string JHnLVYU = string("NmCrKFNLgTvMpnkHNGzODahMLmFGyZMuuxCqiohkvHElyGVTQ");
    double FjugByjJl = -392376.50746082515;
    int RYXil = -1719451162;
    double hPTWGBEUhgQzoFeT = 138344.44688964053;
    int yutvUvLE = -228534806;
    double kFtorCvdc = -320468.9073308356;

    for (int vwKitPnvT = 762697344; vwKitPnvT > 0; vwKitPnvT--) {
        JHnLVYU += JHnLVYU;
    }

    for (int baAzOVcgmBl = 1317120221; baAzOVcgmBl > 0; baAzOVcgmBl--) {
        SspVHa /= SspVHa;
    }

    return fGymDBe;
}

double GUCvxkjmDMJbcLwP::lkwdM(double rydHb)
{
    string XbIeVHeaWYnrpxF = string("EkgQKrjOZHwcdAZaInQJtmzBKHUKxcKSwIIzDwEiRaHjYDCLDBtlcoiqgGKpEXRRXymGrTRNwPzrzPnkbVSIzfShMvdyoVxvdkUyApaYudAzjfDaqqptUwCUQPUsKPXmpUbUjglgXgNhguifDPjCPwQZllgwEYGbcCrMfRYdunpddJNVJ");
    bool TnWeoKQ = false;
    int Htjzr = -132371119;
    string oTweg = string("IMZJyLghBIJEnhFvBYVQbkmaGAQHSCxLAAMUewuBQYWgXaUKNQmkMnsOyYCAxUqVsZQNMoQocKWNFAqbuvxjJAGxqgUWDAYpGFWOHqYQZaTiz");
    bool lmjkaydfUh = true;
    double lMcMgrRDU = -956298.006542735;
    bool dwVblJwMcgMFAKop = false;
    int UvYzS = -858726506;

    return lMcMgrRDU;
}

void GUCvxkjmDMJbcLwP::KqGMbrzyvb()
{
    int LKzyYzVXeAtApEkr = -979989523;
    int aqNNiIEjzo = -1511592078;
    bool sRFCenmUZZSXJ = false;
    double jfugjFUJu = -686241.6254827497;
    double oWPOvrirmcpplq = -34740.75471722102;
    double AoDfHWUTYPbHvH = -185678.5202956127;
    double knrViimhS = -747591.1743114004;
    string eYahM = string("IcOJgFUzwvxRxqMMRAdewxJzRrNErNfjNlKdkUuzGMzBCisMtLXbjkqRAgeFocvdcmDVWVbcMeiu");
    bool kTpRNnkM = true;
    int seCJLifiBQExyb = 1603650331;

    for (int GpZYe = 216804151; GpZYe > 0; GpZYe--) {
        AoDfHWUTYPbHvH /= AoDfHWUTYPbHvH;
        sRFCenmUZZSXJ = ! kTpRNnkM;
    }

    for (int rqkyKv = 44779816; rqkyKv > 0; rqkyKv--) {
        seCJLifiBQExyb -= seCJLifiBQExyb;
        LKzyYzVXeAtApEkr *= LKzyYzVXeAtApEkr;
    }

    for (int wukWFuhe = 1604079360; wukWFuhe > 0; wukWFuhe--) {
        AoDfHWUTYPbHvH += jfugjFUJu;
    }

    if (AoDfHWUTYPbHvH != -185678.5202956127) {
        for (int wEaItkKtb = 221049964; wEaItkKtb > 0; wEaItkKtb--) {
            LKzyYzVXeAtApEkr /= LKzyYzVXeAtApEkr;
            knrViimhS *= knrViimhS;
        }
    }

    for (int YobIR = 215974328; YobIR > 0; YobIR--) {
        aqNNiIEjzo *= seCJLifiBQExyb;
        oWPOvrirmcpplq *= oWPOvrirmcpplq;
        oWPOvrirmcpplq = knrViimhS;
    }

    for (int MaKkZEzCDHQhCp = 1842788396; MaKkZEzCDHQhCp > 0; MaKkZEzCDHQhCp--) {
        knrViimhS -= jfugjFUJu;
    }
}

double GUCvxkjmDMJbcLwP::FurhyfbhqVuj()
{
    double zwpLTprjEgHfFf = 697354.9997958806;
    double PzEsOD = -591669.4920372954;

    if (zwpLTprjEgHfFf != -591669.4920372954) {
        for (int MuwjsViuTf = 717474146; MuwjsViuTf > 0; MuwjsViuTf--) {
            PzEsOD -= PzEsOD;
            PzEsOD /= zwpLTprjEgHfFf;
            zwpLTprjEgHfFf -= PzEsOD;
            zwpLTprjEgHfFf -= PzEsOD;
            zwpLTprjEgHfFf += zwpLTprjEgHfFf;
            PzEsOD /= zwpLTprjEgHfFf;
            zwpLTprjEgHfFf = zwpLTprjEgHfFf;
        }
    }

    if (zwpLTprjEgHfFf >= 697354.9997958806) {
        for (int IlvnRZkgYTErXK = 538556006; IlvnRZkgYTErXK > 0; IlvnRZkgYTErXK--) {
            PzEsOD /= PzEsOD;
            zwpLTprjEgHfFf += zwpLTprjEgHfFf;
            zwpLTprjEgHfFf /= PzEsOD;
            zwpLTprjEgHfFf *= PzEsOD;
            zwpLTprjEgHfFf /= PzEsOD;
            PzEsOD -= PzEsOD;
            zwpLTprjEgHfFf = PzEsOD;
            PzEsOD *= PzEsOD;
        }
    }

    if (PzEsOD == 697354.9997958806) {
        for (int YHzwQmLbtjlWbpbS = 2097780077; YHzwQmLbtjlWbpbS > 0; YHzwQmLbtjlWbpbS--) {
            zwpLTprjEgHfFf += zwpLTprjEgHfFf;
            PzEsOD -= zwpLTprjEgHfFf;
            zwpLTprjEgHfFf = zwpLTprjEgHfFf;
            zwpLTprjEgHfFf += zwpLTprjEgHfFf;
            PzEsOD += PzEsOD;
            PzEsOD -= PzEsOD;
            PzEsOD -= PzEsOD;
            zwpLTprjEgHfFf = PzEsOD;
            zwpLTprjEgHfFf += PzEsOD;
        }
    }

    if (zwpLTprjEgHfFf > -591669.4920372954) {
        for (int lEiHVUkU = 1399663129; lEiHVUkU > 0; lEiHVUkU--) {
            PzEsOD += PzEsOD;
            PzEsOD = PzEsOD;
            PzEsOD = PzEsOD;
            PzEsOD += PzEsOD;
        }
    }

    return PzEsOD;
}

bool GUCvxkjmDMJbcLwP::kdFegODKnQg(double IugkEXGljqZDhTA, bool ggnzaLERb, string xkKRDzqfessPWlPd, bool RJbFi)
{
    bool pIBrpcKJFIKnht = false;
    bool WNtrZjkhV = true;
    string gCvas = string("NUQVWkfbbphpSRMLlyhZSBzbSUsbHZGyIncSeQKRwrlvsMYJevljoBvfaPwGp");
    bool OvMRwuQeQWzhSEEw = true;
    int fVVKouvDeFzkc = 1910291984;
    int hbBgxskCfYzg = 760571329;
    string MFruEfqU = string("QsmcQkyHVlXObJYrnBUWeYIUIdsPXvJgQfCWOuGdEdhKXPrhyFlVtaUHkLJPEwIVXgEmrcwhWQEnZLMuGdumTozrpmUuhesjLKdzVamYpNbPwueaGpsqGAaQafuLBbyvPBbacDLAOLPoNaabTI");

    if (hbBgxskCfYzg < 760571329) {
        for (int UAgOMdqSpG = 250527807; UAgOMdqSpG > 0; UAgOMdqSpG--) {
            continue;
        }
    }

    for (int daMIPTu = 585660132; daMIPTu > 0; daMIPTu--) {
        xkKRDzqfessPWlPd += MFruEfqU;
        gCvas = MFruEfqU;
    }

    return OvMRwuQeQWzhSEEw;
}

GUCvxkjmDMJbcLwP::GUCvxkjmDMJbcLwP()
{
    this->pVFofAaBHAcmmwxB(string("VgniGZyczQEyPIGuhJsbWPSzPVcfwnRXyqUCZBjGahmmZPquBAKZSXMByylguRcqHmHWadhexkYpjaTVlgLgRvpwIpOBBHELEZexHnIdBjsNUVPSfKQWiucOSLtMIYftQosXiXCrkQIwFpzuCeEIpQqhizBSulFhEaLdYHXLUqJuFFfNBBsBqBVnXlczJKLdbG"), true, -410193.7764759277);
    this->gyMUqOJMUmjtxevU(true);
    this->VPOSxDvJwfn(-310713444, 470154.43200630386, -1562931510, false);
    this->lwZccLXhIYQc(-1631342293, string("KxqPKxzFXaxwBrpoJVKtgJCtNuRRGimGVWjLfVvxMBqrtTCTlcTLIsJpUzmQnbmiNNiFBcKwTnGaAmUqRatoGyikYsHIcZIPL"), 421403.17673161416, false);
    this->lkwdM(244364.53729861256);
    this->KqGMbrzyvb();
    this->FurhyfbhqVuj();
    this->kdFegODKnQg(-393838.6274605756, true, string("HZuahTCaUhXgbFWeyovPUkxfXxNxesHdsYonuUBuuXdhAeltDxJUZMVOKYWblPkSvxxCXfIgToVbPDkODIohRNMVZwECacnCHWiynrjHWXWeifYJCUeFupSvJZLsyNkQJwfxCFXMDwEqZugFptGWfifShCVxmVyZoRRAxrbcCbzAxm"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xakmgjfwDRpVvxr
{
public:
    bool AATZQadhSjexpCW;
    double RIyGstMMmdg;
    bool pxhGsrIYvQ;
    bool wkgKtQ;
    int MLLdBM;
    bool uzyvWkX;

    xakmgjfwDRpVvxr();
    string yRHiCPXcMUyMgxoh(int mBNeXRzk, bool bSgngrUlJxFL, string uURNyG, string xQDxCfNsntkwwphp);
    string xVBuhxKvYop(int lsMAhtXaoGChZag, double QpDiFjYoBZ, string eCAsMWiZmVf);
    double KYUzXciloHIAlS(string IQjsB, int zojAhHlSV);
    int eSSuVzNQXGeIiNrw(int bpZjUKdE);
protected:
    bool zQuqgVhZ;
    bool CENsxWBHvEvIFo;
    double JhMdNk;
    string zfMncQLCQ;
    bool qiKvGYEvzOG;

    int fdlqPBABOFfDp(int WvTqq, string KbUbsgQgUd, double KljmkGnCAsMbBA);
    int KWBXXDvWSobvcx();
    double lYSfgqeDucTMGv(string hpfRndFiUlZgGDB, double LIeLjpbxwMUUmT, int ElXCFsSTbr, string elUIQpDRiurJSFvV);
    int umZhFTUy(string WEvXFsN, bool dpSVUwrZproPI, string WEPViSHliqQ, int jclRxUuqckXxZ);
    bool CogJE(int CKkcmK, double NqikwRIzdWFgaph, bool eXcEEGLOQ, double FneFiVGxgrAVPoh);
    double BbXjzhmtxxx(int DTHvHJTB);
private:
    bool lNUYo;

    void Ucozifz(string eZmymZBJyxfVLpZM, bool xKGeRMfdUg);
};

string xakmgjfwDRpVvxr::yRHiCPXcMUyMgxoh(int mBNeXRzk, bool bSgngrUlJxFL, string uURNyG, string xQDxCfNsntkwwphp)
{
    string BzVsekgtlhbcy = string("HSWfzLyjyLYJSmgcElJRmVFLBasuyYozMsLBkMFvxaiLjfbmeJMDHhgQPspGfppQSeFkscjPghHaurCCrtnMJbDANkXtNXRrJwFBCtKnvjNsluBIUduRMRXQoEiJzdTDHWOrbzilKBWYrBYIWlSDzOEEUVOwMLglBpwIdMRldXmtIdNwbNShyLDkqVKUfDvlAMqMUeaFMNSYQDqsRNVIuhG");
    string YefAlPN = string("JLPiEmERzoDqgodFoQADekilOFapftRzdLAatOarrmVLxxHHlAPISZdwnvpHDyoDPEAcrdctiGPQBLJbGawYVApuASsdDcPZCFDILIyPa");
    int daWXmhSddltcRlPp = 1833845332;
    bool FasvQIoq = true;
    double FXLoCKBQj = 926755.5581671087;

    for (int KxXZaSj = 1513846949; KxXZaSj > 0; KxXZaSj--) {
        FasvQIoq = FasvQIoq;
        daWXmhSddltcRlPp += daWXmhSddltcRlPp;
        YefAlPN += xQDxCfNsntkwwphp;
    }

    for (int CncfyHXxIuVaOYf = 1931364784; CncfyHXxIuVaOYf > 0; CncfyHXxIuVaOYf--) {
        FXLoCKBQj -= FXLoCKBQj;
    }

    return YefAlPN;
}

string xakmgjfwDRpVvxr::xVBuhxKvYop(int lsMAhtXaoGChZag, double QpDiFjYoBZ, string eCAsMWiZmVf)
{
    bool BqWeb = false;
    double sWpDcjkSw = 997194.3069512821;
    bool OmXXegiOWrHpcC = true;

    for (int oOJJwMbYyBavfoGi = 139920287; oOJJwMbYyBavfoGi > 0; oOJJwMbYyBavfoGi--) {
        continue;
    }

    for (int BhSaXRAntu = 780612923; BhSaXRAntu > 0; BhSaXRAntu--) {
        eCAsMWiZmVf += eCAsMWiZmVf;
    }

    return eCAsMWiZmVf;
}

double xakmgjfwDRpVvxr::KYUzXciloHIAlS(string IQjsB, int zojAhHlSV)
{
    double htlJECv = 844029.558038657;
    double jnBaDyXj = 896387.64815428;

    for (int tCuhThYFtdAsL = 267057369; tCuhThYFtdAsL > 0; tCuhThYFtdAsL--) {
        continue;
    }

    for (int DXcyfOgOUfqVbKiv = 1112314106; DXcyfOgOUfqVbKiv > 0; DXcyfOgOUfqVbKiv--) {
        continue;
    }

    if (jnBaDyXj <= 896387.64815428) {
        for (int OVMbpUhf = 1072621342; OVMbpUhf > 0; OVMbpUhf--) {
            htlJECv = htlJECv;
            htlJECv /= htlJECv;
        }
    }

    return jnBaDyXj;
}

int xakmgjfwDRpVvxr::eSSuVzNQXGeIiNrw(int bpZjUKdE)
{
    int GnNRmWIdkfmYuYh = -1516742980;

    if (bpZjUKdE < -1516742980) {
        for (int AKVMaRI = 648750558; AKVMaRI > 0; AKVMaRI--) {
            bpZjUKdE /= GnNRmWIdkfmYuYh;
            bpZjUKdE = bpZjUKdE;
            bpZjUKdE -= bpZjUKdE;
            bpZjUKdE -= bpZjUKdE;
            bpZjUKdE /= GnNRmWIdkfmYuYh;
            bpZjUKdE -= GnNRmWIdkfmYuYh;
            GnNRmWIdkfmYuYh = bpZjUKdE;
            GnNRmWIdkfmYuYh += bpZjUKdE;
        }
    }

    return GnNRmWIdkfmYuYh;
}

int xakmgjfwDRpVvxr::fdlqPBABOFfDp(int WvTqq, string KbUbsgQgUd, double KljmkGnCAsMbBA)
{
    int touLS = 2025555743;
    bool MzLwMsyuy = false;
    int LydSoPatbztaf = -1995641447;

    for (int bIGUSIDVirtES = 1249775074; bIGUSIDVirtES > 0; bIGUSIDVirtES--) {
        touLS /= LydSoPatbztaf;
    }

    for (int rIEkHW = 2097794441; rIEkHW > 0; rIEkHW--) {
        MzLwMsyuy = MzLwMsyuy;
        touLS *= WvTqq;
        LydSoPatbztaf *= WvTqq;
    }

    return LydSoPatbztaf;
}

int xakmgjfwDRpVvxr::KWBXXDvWSobvcx()
{
    int WuuGATJdgOCSCc = 1500178105;
    int bzARFQiEYn = 1207104636;
    string XFkLXPmBFU = string("MXsLoLcpjywIqujMTtbKFy");
    double YIGhHVjJoudqk = 612181.1673119202;
    int IVfIfcSQfjU = -1893414558;

    for (int FTADa = 1997021546; FTADa > 0; FTADa--) {
        continue;
    }

    if (bzARFQiEYn >= 1207104636) {
        for (int zZQVzjgYY = 1196765975; zZQVzjgYY > 0; zZQVzjgYY--) {
            IVfIfcSQfjU *= WuuGATJdgOCSCc;
            bzARFQiEYn = bzARFQiEYn;
            YIGhHVjJoudqk -= YIGhHVjJoudqk;
        }
    }

    if (IVfIfcSQfjU == -1893414558) {
        for (int zhSPFWioWhvS = 363456163; zhSPFWioWhvS > 0; zhSPFWioWhvS--) {
            YIGhHVjJoudqk /= YIGhHVjJoudqk;
        }
    }

    for (int qtJnHRDyyBh = 1107309386; qtJnHRDyyBh > 0; qtJnHRDyyBh--) {
        YIGhHVjJoudqk += YIGhHVjJoudqk;
    }

    if (bzARFQiEYn <= -1893414558) {
        for (int mSlFQs = 2017322399; mSlFQs > 0; mSlFQs--) {
            WuuGATJdgOCSCc /= WuuGATJdgOCSCc;
            IVfIfcSQfjU /= bzARFQiEYn;
        }
    }

    return IVfIfcSQfjU;
}

double xakmgjfwDRpVvxr::lYSfgqeDucTMGv(string hpfRndFiUlZgGDB, double LIeLjpbxwMUUmT, int ElXCFsSTbr, string elUIQpDRiurJSFvV)
{
    bool ozOPFEn = true;
    int wYDwZQ = -195066591;

    for (int tNWaI = 1938210430; tNWaI > 0; tNWaI--) {
        elUIQpDRiurJSFvV = elUIQpDRiurJSFvV;
    }

    for (int rYTYWKunzfc = 1992217000; rYTYWKunzfc > 0; rYTYWKunzfc--) {
        wYDwZQ *= wYDwZQ;
        ozOPFEn = ! ozOPFEn;
    }

    for (int kodATC = 1169135151; kodATC > 0; kodATC--) {
        continue;
    }

    if (wYDwZQ == 636429230) {
        for (int XBcZA = 1733837961; XBcZA > 0; XBcZA--) {
            ElXCFsSTbr *= wYDwZQ;
            ElXCFsSTbr *= wYDwZQ;
        }
    }

    return LIeLjpbxwMUUmT;
}

int xakmgjfwDRpVvxr::umZhFTUy(string WEvXFsN, bool dpSVUwrZproPI, string WEPViSHliqQ, int jclRxUuqckXxZ)
{
    bool NBmzDCgBvW = false;
    double UxsLuy = 929764.3122922671;
    int MoCpuhVtIWLzPa = -494620894;
    bool FTKdolHJtWqSzTI = true;
    double HXqfFWam = -108467.29974968762;
    int XfufhSyLuIvwUG = 157753731;
    string DJiWGDAC = string("jkSHKjNagLTPMowXHnuxeUXvwZlMgNZTkTXHeMboKKMWlcJzpoIUxZTaOfVXowcskUbiVwWLYXOebJqRqXNQLnwemYSXjCGcYwVqAGcvpAkTHpADuoQyjyPOVHGOikcqxHahCILqDWFkMCmFeaoCWxnYcmkkBnLGxopcQCOlkTTejhNfkYMgJPArCwUWoVjnAVRQwjnsUIyXTAosggkEYPLlATFzeXDpHHweojmdqjCCbmtISkJfDJB");
    string eifvXqVIkQDHdWq = string("tYqhFZkVdfYAqpGuZJkBBJJMVmRUnHgCwkbswphmMsaUuNaQvhGHOxtSuaAAIAJbcyKppsnqkNDkbPMPnbGOjikpUMPcWvrvaquHQMevrQQdqVnePGFzThgkkeNrsCdnxFIjobVDcjiqAjujxiyEmAgPUuNTpAzoPMHStPLMEojgLMjTgGmUCDDoBdULszBCMXdXpOzUL");

    if (dpSVUwrZproPI != false) {
        for (int qpHNJW = 609937197; qpHNJW > 0; qpHNJW--) {
            XfufhSyLuIvwUG += XfufhSyLuIvwUG;
        }
    }

    for (int owFcOtT = 540930587; owFcOtT > 0; owFcOtT--) {
        XfufhSyLuIvwUG /= MoCpuhVtIWLzPa;
        UxsLuy /= HXqfFWam;
    }

    for (int eBFhqoxIGQfXbsm = 2005128332; eBFhqoxIGQfXbsm > 0; eBFhqoxIGQfXbsm--) {
        DJiWGDAC += WEPViSHliqQ;
    }

    if (WEvXFsN <= string("tYqhFZkVdfYAqpGuZJkBBJJMVmRUnHgCwkbswphmMsaUuNaQvhGHOxtSuaAAIAJbcyKppsnqkNDkbPMPnbGOjikpUMPcWvrvaquHQMevrQQdqVnePGFzThgkkeNrsCdnxFIjobVDcjiqAjujxiyEmAgPUuNTpAzoPMHStPLMEojgLMjTgGmUCDDoBdULszBCMXdXpOzUL")) {
        for (int pOAScoEYWeKj = 954164359; pOAScoEYWeKj > 0; pOAScoEYWeKj--) {
            dpSVUwrZproPI = ! NBmzDCgBvW;
            WEPViSHliqQ += DJiWGDAC;
        }
    }

    return XfufhSyLuIvwUG;
}

bool xakmgjfwDRpVvxr::CogJE(int CKkcmK, double NqikwRIzdWFgaph, bool eXcEEGLOQ, double FneFiVGxgrAVPoh)
{
    int BxHsxNCXy = 1948044407;
    int XXSPQbIdaKr = 1691154508;
    string ydyXWjgSUstVa = string("KnSbbyawMHPPzIT");
    string IVBzCfNDH = string("uelyMJNeHWfWvUsYRXzpyNeCSuulcprcRSxKRDQMRNlWIiYhkVapaxkbCdlqjYHjsZLhqwRAsiWfawaOKMrkqlZyNCrUSZOSHGPCcVRVIlYSztHMSXhNhZexztqmEuLaXvmJcYJqsbJWWItAkovIyFuuYiJieMiwxZOAFdVbxSJHFCLktchLqFMysKYFliXuXvfLWPIWpnmsePpqQGojkATNwexQPhkNpYDWXbggbxTLPBnAUG");
    double NLoGDtqr = -507200.1115882337;
    int NqjmiEjJFh = 1833471090;
    bool BoQqSCjxtsk = false;
    string sfhjBA = string("MPlpehJDcQlWQBgWsgSAathJVNyUDMEmFOuMSGxsQpAfZLTEoFcVtdBCageOGiebXCjSbYNgMJVGQbIqUtBiJdzxMLzlyIMDgAHcRuKHKzvhjSGZkMvqVUqqnjlvVuAAqMJAdbKLwTGJembXZqYEbHRXvFXmbjylwOEedltLsEDMmLfxP");

    for (int zMUFDGnFJVif = 626905937; zMUFDGnFJVif > 0; zMUFDGnFJVif--) {
        continue;
    }

    for (int oMmuYCUbaqUmi = 1618236927; oMmuYCUbaqUmi > 0; oMmuYCUbaqUmi--) {
        continue;
    }

    if (BoQqSCjxtsk == false) {
        for (int YITYUV = 1007794251; YITYUV > 0; YITYUV--) {
            eXcEEGLOQ = eXcEEGLOQ;
        }
    }

    return BoQqSCjxtsk;
}

double xakmgjfwDRpVvxr::BbXjzhmtxxx(int DTHvHJTB)
{
    int vnQKkGbaXe = 789830758;
    bool LbiEzlOxWd = false;
    bool XtBpWmFlQJ = true;
    string yGYKxZryhtenZ = string("hZBVhdTQUFSypyLaDzGiJgmFwsUpLKggQFqWVyMawOLxzFeFKnyPFPGUbtjCxyjbHbOUWsvCSQunoraChTbvicQLlXfayYMtifAEuoAfvSukPvVscKbZFBPpYESMNEKZnwKjvSwtyANjvbiPRnxyCJQkds");
    bool JAUsDhbOdEEIlTt = false;
    bool JLPZVgovXWB = true;

    for (int daMFIKiM = 219976017; daMFIKiM > 0; daMFIKiM--) {
        JLPZVgovXWB = ! JAUsDhbOdEEIlTt;
        JAUsDhbOdEEIlTt = ! JLPZVgovXWB;
        vnQKkGbaXe -= DTHvHJTB;
        DTHvHJTB += DTHvHJTB;
    }

    if (yGYKxZryhtenZ > string("hZBVhdTQUFSypyLaDzGiJgmFwsUpLKggQFqWVyMawOLxzFeFKnyPFPGUbtjCxyjbHbOUWsvCSQunoraChTbvicQLlXfayYMtifAEuoAfvSukPvVscKbZFBPpYESMNEKZnwKjvSwtyANjvbiPRnxyCJQkds")) {
        for (int dNiMFOTXwUYri = 111909180; dNiMFOTXwUYri > 0; dNiMFOTXwUYri--) {
            continue;
        }
    }

    for (int esboATL = 2101392653; esboATL > 0; esboATL--) {
        XtBpWmFlQJ = LbiEzlOxWd;
        JLPZVgovXWB = ! XtBpWmFlQJ;
        JAUsDhbOdEEIlTt = JLPZVgovXWB;
        XtBpWmFlQJ = LbiEzlOxWd;
    }

    for (int SfzwVZXNgHTOkk = 52603999; SfzwVZXNgHTOkk > 0; SfzwVZXNgHTOkk--) {
        JAUsDhbOdEEIlTt = ! LbiEzlOxWd;
        JLPZVgovXWB = JAUsDhbOdEEIlTt;
        yGYKxZryhtenZ = yGYKxZryhtenZ;
    }

    return 365328.0797332017;
}

void xakmgjfwDRpVvxr::Ucozifz(string eZmymZBJyxfVLpZM, bool xKGeRMfdUg)
{
    int qMNja = -26813985;
    int EUWWTCUfntPIJ = -491703803;
    int aBzxEhknfMgN = 347426451;
    bool mRhqXIVxa = false;
    string oqjncTtOkGicoLC = string("GPIrCjMaPTJfDhcYvwvQOVOQdrDhfqGNAHEudMQkXSyKiQFOaInzUqrCLmHaMDSzAbDGmJXCqmDIWHcxBLqyKIhmFWtOiWUQPBcWEBDtOohxZSjKMrDoJASBLJKgAujRJueUvRkjnQopyinReG");
    double iRiDiPAQlEVrDFH = -154903.38981988092;
    string hYZodS = string("vPYguAmUjuzhHvCmAOSAtnUKoULMByLOAGQciSiBgIJMroMyuDdxoIwPdbMDcrmDhuwTWfYppKNUhDSXFaOSzLajFLlzzsRAgBxONaaawyEPgeAgiYeENkzHehnlFAInCOzNXoDHMxswrnLBJfGzYebpSuKIFkarqgAhIkpPnmTFTsfOwMoWktlllOGikamvlLKV");
    double TPswyxxktcvP = 158691.831391024;
    double YqlsD = 359918.7712335752;
    bool GiFoNMwQxFynH = false;

    for (int jGeeyqlhhXc = 577437278; jGeeyqlhhXc > 0; jGeeyqlhhXc--) {
        eZmymZBJyxfVLpZM = hYZodS;
        mRhqXIVxa = ! xKGeRMfdUg;
        eZmymZBJyxfVLpZM = eZmymZBJyxfVLpZM;
        xKGeRMfdUg = xKGeRMfdUg;
    }

    if (iRiDiPAQlEVrDFH == -154903.38981988092) {
        for (int moPSVihwhu = 624291373; moPSVihwhu > 0; moPSVihwhu--) {
            iRiDiPAQlEVrDFH *= YqlsD;
        }
    }

    for (int wwxyrudsUUEno = 1035424982; wwxyrudsUUEno > 0; wwxyrudsUUEno--) {
        continue;
    }

    for (int HGyDeetkIec = 179476054; HGyDeetkIec > 0; HGyDeetkIec--) {
        oqjncTtOkGicoLC = eZmymZBJyxfVLpZM;
    }

    for (int nkAxYbGrFhr = 1166399917; nkAxYbGrFhr > 0; nkAxYbGrFhr--) {
        TPswyxxktcvP += YqlsD;
    }
}

xakmgjfwDRpVvxr::xakmgjfwDRpVvxr()
{
    this->yRHiCPXcMUyMgxoh(-300772346, true, string("BHnywSlEubqzEikdBaoLYQyPzJscWmvfyWhFRiUIgBvNATVbWlPMovQpcSGqgfDZkxEJCFRWLEbFXzYFshQkksuseNMStUltubRwKEQDKgSLPfoqwkrMjpXWKJCyzfQGA"), string("NOfgncyzlWRDFfaLyqEYQciloqPMwswKQpJatVhtmNFRPdUqAFtutgsDXpWVlVMVpIpLLPdhRCYpZAwFWgMotbBJtBEtlGDbeSXZrZwTgdvEAWKpkirgHEfWmxUFqeLrMvnEXHshGemWTvjKXHLPgCQEWrIhigOggvlpDQkQmvFCkclpKIWnAwlyFBZhcstpXDTWoCbskEUCEMfsBEBsHfrAUyeyGVD"));
    this->xVBuhxKvYop(1407856581, -708348.4975863181, string("ctCrbwhxOGTqRaISwAYoLfTKyjhDmyRSpLbfONw"));
    this->KYUzXciloHIAlS(string("QSYnOeSLUMHZdLZXSuljBDFXtUogwSZBYcSmiPhAawXKzJPQV"), 1865425241);
    this->eSSuVzNQXGeIiNrw(839464257);
    this->fdlqPBABOFfDp(1435297783, string("GgNKlypXvHEgGrsQTWDCOHjQGTrbtjvbTTdSdeLQexDSnggZkdBZxlphOjNjitKKZBKBdouugIjivjcXbPITbPFMQlcYSXTyOgbFEgnnociUOpIrXWdwiIModGLDkXxioxvWcyFZGFZHtfmQkeSrdtzcRXIbFlALpkdjfFUMHWoEWdStJvqcrDzgCrQAwTGlDDAzAEwVhWACQzLBcwoVGlmJiXNQnmFZoVfqSpaUqhgdOgb"), -697879.8839835591);
    this->KWBXXDvWSobvcx();
    this->lYSfgqeDucTMGv(string("RoflJsjbJTBPeKPBGYuidpuZtCOFkSYsUlhiRNUyHwJSvHUHfdyGqZnxmfCejnMxiBEwpQHIvYDgZznSVpgqGLvSIgMoyEBdhV"), 642888.8336094216, 636429230, string("jNbDxiQGRSyzdoloaCJhWQOYlwFOgESgrCvAdRxLzSwQTXeDhtAYbGMlSfgkXGrLJyiXtxJIKMPonSIzjfHRWsSYHJIlolmKyHnFbxXLzRpLlaolgnRENSHePXcUyyvhCubhyxdPwVCHnsNPZOsCztxPTGUeCWtawjvruJiYSUASuKkvYdUJdMCWFfhFYGaDPXdIMrbXrvkWIAUfkeENnGCnnijkhzosThWkUWlhmpVaHrbgLsHjuPhhX"));
    this->umZhFTUy(string("FlBTEuohkTJUCJIPGvpmEruBESjEJNugwYJFAtUkacfTkgQRJmZTDoZpD"), true, string("MBkittldUUMeHOiNiotaPpIPFjxdRMXzJqAUyVxHYuLyWOzxuNmRAQduqNmkgtXoxHvYlcfCKKHSrEWrmeEBvGqtcUOzXOCMweNjgJfmZOHDGOWWSOrvzRsYqWQqtaTPEcHhXCoJfeWtfioyEcgErcegRIkeSejNHusbUcwdnvwwUECPPzXSYNTdmEidAeOhGfygfIbVzgffBVdMtOlWNkggVmtErLWNdUOxEluaVgboTglNYnOrPOdvmcvjJEg"), -1489064367);
    this->CogJE(1764230630, 256385.82365556454, false, 233965.34424447047);
    this->BbXjzhmtxxx(-727134609);
    this->Ucozifz(string("YsTwkUcfTdTRjsYzGuTFZYZiETWzSvNJdUgTplbFsGILtOtQvRPUaqJWNPROkmlzsOEjOBiGwQRqMhtmEOvYxDbEMCevcvGBiikVGxCMnBEmNndqlEbwEnbCAiIHTmdqYYXTnPPGCqxyDNYebkeHxDQZevadEUwoWFfLuFrBHuZYtIdOUYEhLFCjDQbMyie"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yXzDiI
{
public:
    bool MUhlrcLVj;
    bool gyijcbPTSJlx;
    string ixMfSjlPFBvDF;
    double UARLcHwNLqQcrZP;
    string sQvjHBdEo;
    bool NvvKOKCMIYtXNATb;

    yXzDiI();
    bool QEfSJSVgwSPh(string QEncrMSbQQYh, double yWnMMSyQddPeJSes, double ZxleflxsNEGJJOup, double uxVspCgMkSdsjR, double mHpUY);
    bool URgYcnm(int RheHfrGteqq, bool EFWlmJmX, int tGeWpxtrRCzvI, bool KNScuXEcXDFSyWAw);
    double ZfomBNXXMeiPAkaD(double jjvUKmru);
    string fWFsR(string VLwEcMJdeO);
    string ZzFYfdehLouYj(bool gobenlJpQcS);
    int dvbCHLGbrAwZQfo(int caCTI, double rwolR);
    string DRhYXXsdKgulYml(string tGvKCoN, int TZRpWnceKpgpd, bool zKSaLoTErtNSj);
    int WhGjnRyEgj(int DHvKxzWQrqTRnc);
protected:
    string POMLPtrFyCeW;
    bool gkpHr;
    int aRVoGONKTtL;

    int lOoOwjRDzqhO(int vwhFqL, bool jdTGkzcCCKGnBRwP, string HceDEwPGqabGEFK, string AylAxBCr, double AMdKo);
    double SCRYdarLzoHx(bool jBgfpaCMevZWMfkC, bool rNqxruo, int TjaydnYdxMKHWgA, bool tAZYrt, double hLLoo);
    void QffZGGvqDfpTY(double eHjmyBPCC, int GAdYlkdIAJMYOGFk);
    bool LglpKagVxsj();
    double ILRUGCdBR();
    double zmJmzFvusQ();
    void LRGOSAuonoVQc(int nedVMkNKfSVWXeL, bool bpzahTr, string ecwRM, int WLSTyKcpGBqa);
private:
    string eWKWXcpKDnImqw;
    double IXWskenKxblEbuLQ;
    string vilXz;
    int cPfcqy;
    int wnrjFPmMR;
    bool xZsfjv;

    string yVybyfCv(double ZNtkHOzqsuSAFet, double OsruHoWto, int hwCmIKXpZnre, bool eZamUOBUyQVG, bool YAhGomWC);
    bool BVaveZyxz(int UvijfxjBTASKTE, string BQyHV, int krYBYKixPqvHXDvk, int Uzhoee);
    bool iczjWtnu(double edgYAkFmZzuKFW);
    int UFOxvwYwrx(double womynaXamJxL, double UuljjWFJ, double VHXpLGm, int RKTTbZziE);
    string wVfqDIiblko(string uAHQeSRBllEDAv);
};

bool yXzDiI::QEfSJSVgwSPh(string QEncrMSbQQYh, double yWnMMSyQddPeJSes, double ZxleflxsNEGJJOup, double uxVspCgMkSdsjR, double mHpUY)
{
    double pkjrQVLhkxXMF = -411063.5154745634;
    bool NdUnEtMkRPsJ = false;
    int QgrbKHpiatmwd = 980531808;
    int vdKAYhr = 209411844;
    string wKvGPkr = string("NdKuZcytUj");
    bool OdIhBvBfAMzAS = false;

    for (int zkgJlFLV = 2058865503; zkgJlFLV > 0; zkgJlFLV--) {
        continue;
    }

    return OdIhBvBfAMzAS;
}

bool yXzDiI::URgYcnm(int RheHfrGteqq, bool EFWlmJmX, int tGeWpxtrRCzvI, bool KNScuXEcXDFSyWAw)
{
    bool hGuixpNXJVhjRz = false;
    bool PkjmDYnyYz = true;
    bool KzHdvPAqqOx = true;
    double RHrDD = -167638.24152152683;
    string zYuXoZCOXqnclwkN = string("CiCOcXlXHQKxXOJaFgNUMGLkPnrdSTDmxuRrGLWTopsNlcdD");
    bool mzldku = true;
    bool gowHiKT = true;
    bool xwInDdRbJJCQy = true;
    double junTT = -1035827.5734003321;

    for (int gudGQNc = 1866278260; gudGQNc > 0; gudGQNc--) {
        RheHfrGteqq += RheHfrGteqq;
        PkjmDYnyYz = ! gowHiKT;
        EFWlmJmX = ! gowHiKT;
        KzHdvPAqqOx = ! EFWlmJmX;
    }

    for (int lWuQwrhZoOLgazqE = 1010938420; lWuQwrhZoOLgazqE > 0; lWuQwrhZoOLgazqE--) {
        RheHfrGteqq += tGeWpxtrRCzvI;
        mzldku = ! hGuixpNXJVhjRz;
    }

    return xwInDdRbJJCQy;
}

double yXzDiI::ZfomBNXXMeiPAkaD(double jjvUKmru)
{
    double eUFeZNnX = -992026.6822206515;
    string pRwoqxiSpNRzYmT = string("XVWAvIHykzIaKKmPYsVJwHlPIJoDgxQSbIGiIHsYlveLhJhqYArByGtEGyHNqaSnibAhThaPkofowTWygEHlQPYvzsvOUxUpTcpUWmXIPPqBsOLwY");
    int ypzFYYwkIn = -1062554885;
    string XYTHMWmN = string("FAndIiQYQvThGrEndzLwoqtEVByyvqUMEFXvGbCnzAcrkpNZEtWRpoylVeNLmcbkWmMBFlWVEggThEvayAVhbffpTeaPCocDuQBCwVxuElRWacFYLAUIjITbLcBvQMXImWoKBJhvfJMGQkjvfGjnSKuvmCHGVWKmpzgzyidWyAvfpePbLPDBrxbRYYRlpsNGCeGyeYfOoUBpavqeicmyuEYjTprxbTu");
    int TUMLP = 493643511;
    int jeIiLbtd = 853971794;
    string vrINxiZxZvrwi = string("uGGIefLKQfFKKlIQpGHlcbrnDLbPyUtToFsYJTVOJNIZrlw");
    string dygbEvDRpdXdMP = string("xxrGNWs");

    return eUFeZNnX;
}

string yXzDiI::fWFsR(string VLwEcMJdeO)
{
    int dWwApp = -272257448;
    int chDKxm = -882050100;
    int qhAkluEO = 1225713147;
    int OXhxCRp = 621435021;
    string yWBFeuCQOpFoP = string("VJItSYJfqPdFGSRkSFKZfebUtaYSHIPWQxyeiBzxpwhLZMmAVxHSuWUyDAIaUfvTMPttnQzeGYNUARrCojGzpcUodnJbiOKaEeHqffIBfaEdgRZnKphskCMrZfncCDoEYKjfxutqVFkYsTcTMCRXNgNTrcOABRklrStvNztvzgAnpscZCqIFIVcVWVKZNxI");
    int tqPfQYYrOeshpy = -1657145894;
    bool oyGvyjkTuXHqjS = false;
    bool PssGXjUwKldouMIt = false;
    double ZknoAg = -494016.71623485815;
    bool SeujHBR = true;

    if (oyGvyjkTuXHqjS != false) {
        for (int OmsHpfinfoAGZ = 39552483; OmsHpfinfoAGZ > 0; OmsHpfinfoAGZ--) {
            OXhxCRp /= tqPfQYYrOeshpy;
            SeujHBR = ! oyGvyjkTuXHqjS;
        }
    }

    for (int OfeCtEqm = 1782110718; OfeCtEqm > 0; OfeCtEqm--) {
        oyGvyjkTuXHqjS = SeujHBR;
    }

    for (int vmWTd = 1778877846; vmWTd > 0; vmWTd--) {
        PssGXjUwKldouMIt = PssGXjUwKldouMIt;
        dWwApp /= tqPfQYYrOeshpy;
        dWwApp = qhAkluEO;
        tqPfQYYrOeshpy += dWwApp;
        tqPfQYYrOeshpy /= OXhxCRp;
        PssGXjUwKldouMIt = oyGvyjkTuXHqjS;
        yWBFeuCQOpFoP += VLwEcMJdeO;
    }

    return yWBFeuCQOpFoP;
}

string yXzDiI::ZzFYfdehLouYj(bool gobenlJpQcS)
{
    bool acVgU = false;
    string XJbVvNAFxj = string("gwzunqzPFjqeZNcT");
    string IVMGpkcJ = string("oGjKtRgFtJnsvtrjQDZhZhhQwWELHvrDiOpcOlzWuAvZkTZACHUUAkqFBltnvXICuzpKpJFlNGWLRsdzWNVxtvjfdmOgywKRWdFyhpMopKLAmDiRouBuoWDiupnmlRdc");
    double iAFnwuEkygwasE = 530483.671808146;
    int afYMXPgTfNSpLjp = 411145205;
    int jAWshF = -1366448363;

    for (int lmaqk = 1771879326; lmaqk > 0; lmaqk--) {
        continue;
    }

    for (int IChuCNiz = 232573266; IChuCNiz > 0; IChuCNiz--) {
        IVMGpkcJ = IVMGpkcJ;
        afYMXPgTfNSpLjp /= jAWshF;
    }

    return IVMGpkcJ;
}

int yXzDiI::dvbCHLGbrAwZQfo(int caCTI, double rwolR)
{
    double eqUyUtANnZFusvHS = 916669.2423384583;
    double DacYcAplH = -518830.5570312894;
    double KGJNqoivQJMiHhm = 929102.711050158;
    int qtgyg = -226436464;
    int uLkVGFsN = 672295889;
    bool ZAnTZy = false;
    int RyzLlySIfN = -1945129217;
    double VEvnWL = -564222.3287804972;
    bool mZrqjfGYjrZr = true;

    return RyzLlySIfN;
}

string yXzDiI::DRhYXXsdKgulYml(string tGvKCoN, int TZRpWnceKpgpd, bool zKSaLoTErtNSj)
{
    double AXynTETVeIzu = 675960.6011012342;
    string BJwsPjLmLJbOsqR = string("aYMQzDwZSEQBQRmzHiRQSZqcUuAPqfeiSpSAatYFFqOhflMTaehYvfuZVqySvPlZpFdERnBIMwxiMiZFrIruXmHPyFYvMDAACcoFEhYXUIeXWZemEbeCHLNjhibDwDEnMmpvtMrcignlndqAWhLbmvvxohflDONArwfSbeOPWvnyYDGX");
    string arcvplXeIVBJDaEb = string("YBFVckZaQWcxriQfDXLUQZzLywctlJKFvqMNgAlrvAPabUsMzNbKSBzLFdStjGyinWRsMwibVhXgiuvwSojEpPsows");
    double WUtLAaUXtmqVC = -929101.6862823988;
    int jcYcGiOphpqf = 725328402;
    double vFSgmRROpUbB = 275351.3404168349;
    double edbSIGfgpB = 816297.1123556055;
    bool kVamCxT = false;
    int PwWwoMctDMPHgxI = -157143370;
    string defTwSu = string("tGodgfpwyTeqJeAIWWHowvsWAavKfHuCEnyrezDGTiuZPnSGfZswIDUEHNhsLxemWMFlZYJZRMpAwlsMNpfOwdJpFDTOkrqtByLUWHsLlfYXACNnTsvCIOtghROWmkSePjZG");

    for (int qgxXWJbO = 924497603; qgxXWJbO > 0; qgxXWJbO--) {
        PwWwoMctDMPHgxI *= TZRpWnceKpgpd;
        defTwSu += arcvplXeIVBJDaEb;
    }

    for (int NDlcVuUYHL = 764407988; NDlcVuUYHL > 0; NDlcVuUYHL--) {
        WUtLAaUXtmqVC += AXynTETVeIzu;
        tGvKCoN += arcvplXeIVBJDaEb;
        WUtLAaUXtmqVC = AXynTETVeIzu;
        WUtLAaUXtmqVC = WUtLAaUXtmqVC;
    }

    if (TZRpWnceKpgpd > -157143370) {
        for (int fylCnzOPgxfHIfd = 465174794; fylCnzOPgxfHIfd > 0; fylCnzOPgxfHIfd--) {
            AXynTETVeIzu -= WUtLAaUXtmqVC;
            vFSgmRROpUbB *= WUtLAaUXtmqVC;
        }
    }

    for (int ZSExSOFq = 1825521280; ZSExSOFq > 0; ZSExSOFq--) {
        AXynTETVeIzu /= vFSgmRROpUbB;
    }

    return defTwSu;
}

int yXzDiI::WhGjnRyEgj(int DHvKxzWQrqTRnc)
{
    int oxYsbqM = -546449436;
    int OwjexxpbetFVBvAH = 380441740;
    string gTncrJpLMmXkm = string("NAXOeMOpQaQxWWLbrkfbPrYmCGEVLxXZOBDZwbDbhvSHMZNJZuUXQnOlcJrJSvTQadDPRlSEfPttmZvUSqYUpqbEJRNYdSBjpjPqRRoiPncRVnuWidIIglgqYIjfmwaIzTfhNjOenCzTIligDKnKnHDgBEYXzPZloEoVCodLtsGEGjCqmAeLRSMCyAvsa");

    return OwjexxpbetFVBvAH;
}

int yXzDiI::lOoOwjRDzqhO(int vwhFqL, bool jdTGkzcCCKGnBRwP, string HceDEwPGqabGEFK, string AylAxBCr, double AMdKo)
{
    double AXInpMlIOwvS = 284227.0469765819;
    bool ryYweFSrKnqs = false;
    string mxFqElpZojOwxKYS = string("XlNsLqKlBgUPvxfweUEtzCsICgsWmFMykFqCWXJbRPihZlIL");
    double yvNGKV = 500685.6723447263;
    bool BNyLvvSBxHCi = false;
    double XeIihZh = 481530.4400363828;
    double ikmgnVtnFfZgs = 368899.6919915935;
    bool eQEXShUZwNTxOp = false;
    string tTXwHzdWwUVrKzXY = string("aRgEYoybIwssMnWqhrYuIGBFrTxiFJGBZAIGrqrrnGfsGxAOskZnIfSGdwiLcXVVNknLHYXfATFKdXpFuenRYzmPTinAhArZlqKELjIyqZDNmteQPpNrmMugGtaYpBXZmhHvuRvheYUgYGHeyWhPjgCKoaXFtFRAyTnTCwgxsNQaZCUibLhVJOYgjrZSVPIcssrTsOZflFAwVNvlcfTv");

    for (int pBgAbLe = 2033243398; pBgAbLe > 0; pBgAbLe--) {
        vwhFqL += vwhFqL;
    }

    if (jdTGkzcCCKGnBRwP != false) {
        for (int NhVBoSfUx = 693664804; NhVBoSfUx > 0; NhVBoSfUx--) {
            XeIihZh *= AXInpMlIOwvS;
        }
    }

    if (ikmgnVtnFfZgs >= 500685.6723447263) {
        for (int bmDLGKG = 1519977771; bmDLGKG > 0; bmDLGKG--) {
            continue;
        }
    }

    return vwhFqL;
}

double yXzDiI::SCRYdarLzoHx(bool jBgfpaCMevZWMfkC, bool rNqxruo, int TjaydnYdxMKHWgA, bool tAZYrt, double hLLoo)
{
    string eNzKhfzVoeCOW = string("NWmXQFDkVPjhEAlOOvsxKNyEEGIMObpWtJXiNVclMQFIDGEMwBxGtxrDbjaZQnqLkhboKBgqoqrjEpWupREphbzA");

    return hLLoo;
}

void yXzDiI::QffZGGvqDfpTY(double eHjmyBPCC, int GAdYlkdIAJMYOGFk)
{
    int kBtZidyScmvMLS = 1071473210;

    if (eHjmyBPCC < -286313.81483235414) {
        for (int zyGGdHppxWiTcFVX = 904945525; zyGGdHppxWiTcFVX > 0; zyGGdHppxWiTcFVX--) {
            eHjmyBPCC *= eHjmyBPCC;
            GAdYlkdIAJMYOGFk += kBtZidyScmvMLS;
            kBtZidyScmvMLS = GAdYlkdIAJMYOGFk;
            GAdYlkdIAJMYOGFk = GAdYlkdIAJMYOGFk;
        }
    }

    if (eHjmyBPCC <= -286313.81483235414) {
        for (int zskDj = 1369279177; zskDj > 0; zskDj--) {
            kBtZidyScmvMLS *= kBtZidyScmvMLS;
            kBtZidyScmvMLS -= GAdYlkdIAJMYOGFk;
            GAdYlkdIAJMYOGFk /= GAdYlkdIAJMYOGFk;
        }
    }

    for (int tkNxnlpitfz = 1320192954; tkNxnlpitfz > 0; tkNxnlpitfz--) {
        GAdYlkdIAJMYOGFk = GAdYlkdIAJMYOGFk;
        GAdYlkdIAJMYOGFk = kBtZidyScmvMLS;
        kBtZidyScmvMLS = kBtZidyScmvMLS;
    }
}

bool yXzDiI::LglpKagVxsj()
{
    bool aaTxRBPTjNq = false;
    double vpDMrsskukq = -694648.4735699294;
    double YtnVimVEngnR = 315893.8138816533;
    string QzHJZDq = string("UMvhaikaJzjJzkpgTzQXfNokYGxcdXFIsYTTaPPFDUcguMZKiMlQuxzXXPTuxtcfXJoTsXmPlYsIGMXULlCVwVjihNxAFKlEqXRdsCyqJVQTpRrQXbagdulAEPPFBLsjLtkZmdwDufVgUKCmSIbkRqunFKbPyDHssOHeepXlYrsgdszAyNSXAqWWYpXEGIYPQIyeL");
    string jYbQg = string("bDhxrzVqTZaRTbFTcjzmhjuMMStLcHzbOoueyPZXtBQOZjYwBSwbKCdhriUVLGpbfCNVwWPReVtyeRXfmmojapWiPzEHsEWOftbQJYatllwTxnnzLukSrLwaEMwhkasGaJhGsGecOkNREnBdVSfqFXslmbHHsDwEWbxXZboAzQjkMujJoVyLCWgSmhpJuFLuLKhhFGNFVuvinXyZcWmZEwedmwuwUXPUbXAWuYaw");
    bool ejDyRbKpHKBWldd = true;
    bool euDZDmb = false;

    if (jYbQg < string("UMvhaikaJzjJzkpgTzQXfNokYGxcdXFIsYTTaPPFDUcguMZKiMlQuxzXXPTuxtcfXJoTsXmPlYsIGMXULlCVwVjihNxAFKlEqXRdsCyqJVQTpRrQXbagdulAEPPFBLsjLtkZmdwDufVgUKCmSIbkRqunFKbPyDHssOHeepXlYrsgdszAyNSXAqWWYpXEGIYPQIyeL")) {
        for (int ZLmKCgqTB = 1951278921; ZLmKCgqTB > 0; ZLmKCgqTB--) {
            YtnVimVEngnR += YtnVimVEngnR;
        }
    }

    if (vpDMrsskukq != 315893.8138816533) {
        for (int cznVlDla = 36577748; cznVlDla > 0; cznVlDla--) {
            vpDMrsskukq = YtnVimVEngnR;
            ejDyRbKpHKBWldd = euDZDmb;
            aaTxRBPTjNq = aaTxRBPTjNq;
            QzHJZDq += jYbQg;
        }
    }

    return euDZDmb;
}

double yXzDiI::ILRUGCdBR()
{
    string sFjRRyVXmqcXCC = string("koNABnEtozsadfBzvADMeGEGUPzktdwLzpUHCamkIptxpLokNbFSfwpPYVpkVsSQZlZUAezmwvoGDvaySeYaikERdgZDSEvIHRijKfNIW");

    if (sFjRRyVXmqcXCC > string("koNABnEtozsadfBzvADMeGEGUPzktdwLzpUHCamkIptxpLokNbFSfwpPYVpkVsSQZlZUAezmwvoGDvaySeYaikERdgZDSEvIHRijKfNIW")) {
        for (int JWkYZGNuagJMjHO = 1295496852; JWkYZGNuagJMjHO > 0; JWkYZGNuagJMjHO--) {
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
        }
    }

    if (sFjRRyVXmqcXCC > string("koNABnEtozsadfBzvADMeGEGUPzktdwLzpUHCamkIptxpLokNbFSfwpPYVpkVsSQZlZUAezmwvoGDvaySeYaikERdgZDSEvIHRijKfNIW")) {
        for (int mxGplHB = 229250104; mxGplHB > 0; mxGplHB--) {
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
        }
    }

    if (sFjRRyVXmqcXCC <= string("koNABnEtozsadfBzvADMeGEGUPzktdwLzpUHCamkIptxpLokNbFSfwpPYVpkVsSQZlZUAezmwvoGDvaySeYaikERdgZDSEvIHRijKfNIW")) {
        for (int rVovHigIrSX = 1626809421; rVovHigIrSX > 0; rVovHigIrSX--) {
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
        }
    }

    if (sFjRRyVXmqcXCC > string("koNABnEtozsadfBzvADMeGEGUPzktdwLzpUHCamkIptxpLokNbFSfwpPYVpkVsSQZlZUAezmwvoGDvaySeYaikERdgZDSEvIHRijKfNIW")) {
        for (int uVnFyTCSgfdOZXn = 822196423; uVnFyTCSgfdOZXn > 0; uVnFyTCSgfdOZXn--) {
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
        }
    }

    if (sFjRRyVXmqcXCC < string("koNABnEtozsadfBzvADMeGEGUPzktdwLzpUHCamkIptxpLokNbFSfwpPYVpkVsSQZlZUAezmwvoGDvaySeYaikERdgZDSEvIHRijKfNIW")) {
        for (int YYJkhic = 104369116; YYJkhic > 0; YYJkhic--) {
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
        }
    }

    if (sFjRRyVXmqcXCC >= string("koNABnEtozsadfBzvADMeGEGUPzktdwLzpUHCamkIptxpLokNbFSfwpPYVpkVsSQZlZUAezmwvoGDvaySeYaikERdgZDSEvIHRijKfNIW")) {
        for (int ehCBwg = 295962821; ehCBwg > 0; ehCBwg--) {
            sFjRRyVXmqcXCC += sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
            sFjRRyVXmqcXCC = sFjRRyVXmqcXCC;
        }
    }

    return 839193.9182131618;
}

double yXzDiI::zmJmzFvusQ()
{
    string LuwOkFLSUA = string("cnvwCpWGDybFYwJwuLWPbWYYJhFQuSC");
    bool XamEAZ = false;
    string PnsOdgdgtICvju = string("pfwQaDbDWPvRhvTrSMLmUNHGzcFVSyAjESxtNIVnUiTLYkaIUnjaKwJzBlcpVWXgeGSkBYnuaPUcKBTRalqJTowanDqWmesCpsFpNdvYCLIzHlXugrnKopLcVzeyLDHvBTQhZGayTCuDmiIdWKvFcjiMjtahLriHntvNRzhrqQEybXYFeSbsWjtcJWpbpuMalvKFaIUfAQVwOSGqGDeQwAwTqOfPfk");

    for (int EwNcgHgVjxHGnH = 2144100301; EwNcgHgVjxHGnH > 0; EwNcgHgVjxHGnH--) {
        PnsOdgdgtICvju += PnsOdgdgtICvju;
        LuwOkFLSUA += PnsOdgdgtICvju;
    }

    for (int EiHcewKxXqDFhuin = 693140622; EiHcewKxXqDFhuin > 0; EiHcewKxXqDFhuin--) {
        continue;
    }

    return 301055.42855557735;
}

void yXzDiI::LRGOSAuonoVQc(int nedVMkNKfSVWXeL, bool bpzahTr, string ecwRM, int WLSTyKcpGBqa)
{
    bool bOSTVAtX = true;
    int oybbDLuvQb = 1514560750;
    bool uWPKq = false;
    double ruMlxDvp = -813594.3795830422;

    if (bpzahTr == true) {
        for (int syJomRxxDEiqSWlP = 1471942965; syJomRxxDEiqSWlP > 0; syJomRxxDEiqSWlP--) {
            WLSTyKcpGBqa -= oybbDLuvQb;
            WLSTyKcpGBqa /= oybbDLuvQb;
        }
    }

    for (int RrOSKztjgsyuj = 1919692655; RrOSKztjgsyuj > 0; RrOSKztjgsyuj--) {
        nedVMkNKfSVWXeL /= WLSTyKcpGBqa;
    }
}

string yXzDiI::yVybyfCv(double ZNtkHOzqsuSAFet, double OsruHoWto, int hwCmIKXpZnre, bool eZamUOBUyQVG, bool YAhGomWC)
{
    int NJwEPcHxPhca = 1405237476;
    string VHsiig = string("IXZZchFLJzUcMAeEBjLhzNinUAkTntwiFlpvhBPGwtQeyIQXRrcXJZvOAIvVxgAeOqqlsjCaKnlJMZjQsYcuW");
    double xpSVhOUAVtEqaF = -1017131.9238261986;
    double nOuwxHMwSZcbCtor = -261523.38436525932;
    bool saHDpsROLfOoJxu = false;
    double soyWzvNyu = 578988.787453476;

    return VHsiig;
}

bool yXzDiI::BVaveZyxz(int UvijfxjBTASKTE, string BQyHV, int krYBYKixPqvHXDvk, int Uzhoee)
{
    int mZiNop = -896632645;
    int hYPUYgLDJVYYu = 1578806454;
    int gtiZzhXAYGIlrFsF = 1306885508;
    bool GlPRGaNgqiYkccFE = false;
    string nIxIaJtcxa = string("GgVXNCGNFokaKjyyhBgJDOXUgONLGTjpWefsCrmhNNBIQzzCtzDBZDFJSheKgJxnBtvfRGTNxKOZErbqHpNESeALgcBmHRMKwnurvqzntPJjBCcqjsEKrJPQsSyrJMZGOpKmBVgIoUtSkaEyoWvjlEcmeWbgLHO");

    if (gtiZzhXAYGIlrFsF != -1844477083) {
        for (int vneJMRh = 902795050; vneJMRh > 0; vneJMRh--) {
            BQyHV += nIxIaJtcxa;
            gtiZzhXAYGIlrFsF /= gtiZzhXAYGIlrFsF;
        }
    }

    for (int SHtYe = 2065317186; SHtYe > 0; SHtYe--) {
        BQyHV += BQyHV;
        UvijfxjBTASKTE = gtiZzhXAYGIlrFsF;
        Uzhoee += UvijfxjBTASKTE;
    }

    return GlPRGaNgqiYkccFE;
}

bool yXzDiI::iczjWtnu(double edgYAkFmZzuKFW)
{
    string GnNIaFsm = string("LUKQKaUUOjBahRfZIrYafEozLgfXjsaScXKmWO");
    bool jvrQmasKskBx = true;
    string lnpAMTZid = string("aYelFPoUSMvVXztpVspvIhGWcJiiPZWgRkEXqgohORCvvwBTSfIHlPjOflGnlyGDTGMwuTnchhsxc");
    string LPXEPxaROUFhoL = string("kkzUDrjDuuRMoCneLbtEbwicayKpPNgwXFnYqCekAerZBxkuuStxYAGIjOHImaXwGhucgWVRERVdtGDmBkZFqtjNaQGXwLCBRtbDKUbraDxCapreTKBRTrYgbuQhv");
    bool aZcGtaaWldH = true;
    bool ErYZedTFefpgUeAc = true;
    bool UuAlkotZRoDVtC = false;
    int kelcUSrsqvIgXnkY = 1685526154;
    double CRfXDutrcRNZTk = -491446.4316061749;

    for (int hADBqViMlpdYAsN = 1888340776; hADBqViMlpdYAsN > 0; hADBqViMlpdYAsN--) {
        continue;
    }

    if (lnpAMTZid < string("LUKQKaUUOjBahRfZIrYafEozLgfXjsaScXKmWO")) {
        for (int FGfhuwHgIBfYlVN = 1894725078; FGfhuwHgIBfYlVN > 0; FGfhuwHgIBfYlVN--) {
            continue;
        }
    }

    if (jvrQmasKskBx != true) {
        for (int BxiSMQKYU = 203461737; BxiSMQKYU > 0; BxiSMQKYU--) {
            lnpAMTZid += lnpAMTZid;
            ErYZedTFefpgUeAc = aZcGtaaWldH;
        }
    }

    for (int lvTLA = 46308907; lvTLA > 0; lvTLA--) {
        edgYAkFmZzuKFW = CRfXDutrcRNZTk;
        edgYAkFmZzuKFW = CRfXDutrcRNZTk;
    }

    return UuAlkotZRoDVtC;
}

int yXzDiI::UFOxvwYwrx(double womynaXamJxL, double UuljjWFJ, double VHXpLGm, int RKTTbZziE)
{
    double MlPloKzbGEo = 320383.61873533676;
    bool IXKaFnLX = true;
    string MwFmrhs = string("ZQvEATAewXccSudAZmtYIGpvUtGEhNuDLMybUtMyvZycdMMaIbHYmfBcpDCuQrRltAqmzXPDnvZqOJGvdCOkgkIJQgDjmZeFfayfxSaomiYcVZEUdfrlFrbwMLNGGrPPcmiTBxsfSwdapssUHLDeMGfYU");
    bool dwfDrjzYXLEQUUfB = true;
    string lhAFV = string("pfwaooABuSECKNeUjiqvZbjqGpqbgqaGbarzlbTTaFbfUsyRCzORfOjetIhkJFHGZyPWTqXnxrVLgFvakPlkkClpzlnXVQOImXXhwACRoXMukRrujpEcfkVPuxAjKHnyjtJhUFdKPrZpEoYqBABVkGXiIybKErxkSqzxfuWrwKrqawwgVEuzCdULkWTcULiFwSiAkkJgpUlDMCLABufqkskFWbOCpqebRxSmGG");
    string wcSAws = string("sWSOxaWKhaSYVPwBxmmjqbDLJyqbILOtGhLVehrTvjbLnTgIMLYuFtNZJfjUuRRHlaBXzaivQmgriZPIngTYn");

    if (MwFmrhs < string("pfwaooABuSECKNeUjiqvZbjqGpqbgqaGbarzlbTTaFbfUsyRCzORfOjetIhkJFHGZyPWTqXnxrVLgFvakPlkkClpzlnXVQOImXXhwACRoXMukRrujpEcfkVPuxAjKHnyjtJhUFdKPrZpEoYqBABVkGXiIybKErxkSqzxfuWrwKrqawwgVEuzCdULkWTcULiFwSiAkkJgpUlDMCLABufqkskFWbOCpqebRxSmGG")) {
        for (int jkWVvcgTvpUIWfF = 63189917; jkWVvcgTvpUIWfF > 0; jkWVvcgTvpUIWfF--) {
            UuljjWFJ /= MlPloKzbGEo;
        }
    }

    if (wcSAws <= string("pfwaooABuSECKNeUjiqvZbjqGpqbgqaGbarzlbTTaFbfUsyRCzORfOjetIhkJFHGZyPWTqXnxrVLgFvakPlkkClpzlnXVQOImXXhwACRoXMukRrujpEcfkVPuxAjKHnyjtJhUFdKPrZpEoYqBABVkGXiIybKErxkSqzxfuWrwKrqawwgVEuzCdULkWTcULiFwSiAkkJgpUlDMCLABufqkskFWbOCpqebRxSmGG")) {
        for (int vfZZDYZLyKXT = 237784056; vfZZDYZLyKXT > 0; vfZZDYZLyKXT--) {
            womynaXamJxL -= VHXpLGm;
        }
    }

    if (MlPloKzbGEo < 320383.61873533676) {
        for (int KshbDIt = 42030771; KshbDIt > 0; KshbDIt--) {
            dwfDrjzYXLEQUUfB = ! dwfDrjzYXLEQUUfB;
            UuljjWFJ *= VHXpLGm;
        }
    }

    return RKTTbZziE;
}

string yXzDiI::wVfqDIiblko(string uAHQeSRBllEDAv)
{
    bool coLeozWBRaDHS = false;
    bool YpuOKksfGm = true;
    string fRJybtKqqIPx = string("GepBwDMJfnDoTICECpmPOcrwZrdNcVBHorZRlsQwbvfLhBcpCHQGlqcYFhVeKpUXOipsYBJUMIDJSpoaraZhmJCRYYKxQhdSxkitLnYAAQrGJyFXcGNglnlTJFuiBMilPKSRvrkxNPeCqFHgJYqsKuzHkirzNEJoWdHVhltmfymikQOZrpXqApAUpprBoSghyVydeUChzFUvDVNCWGdHpYJcJYzyIwMFYMaqCB");
    string pynnohYwVSpMjasS = string("mWJtxYwBkrzZDU");
    int PmCeFDzpG = -1642328415;
    bool AfNgc = false;
    string xiGktiN = string("dpeRLtpiJOkBCAkksUqptkNWBkBcUdrUGCTALhdHOkaBMSngKE");
    double MmbZJVcSjP = -205366.91633073796;
    double zryhAriYwsd = -947742.136058507;
    double NGqDfVppXOm = -913463.0656261205;

    for (int fkMFfkuXna = 1305815385; fkMFfkuXna > 0; fkMFfkuXna--) {
        xiGktiN = xiGktiN;
    }

    if (fRJybtKqqIPx != string("dpeRLtpiJOkBCAkksUqptkNWBkBcUdrUGCTALhdHOkaBMSngKE")) {
        for (int KPEYOWLnHtIrW = 1865201139; KPEYOWLnHtIrW > 0; KPEYOWLnHtIrW--) {
            pynnohYwVSpMjasS += xiGktiN;
        }
    }

    for (int QSEdJ = 1760263264; QSEdJ > 0; QSEdJ--) {
        continue;
    }

    for (int vzNUravHNdz = 872202295; vzNUravHNdz > 0; vzNUravHNdz--) {
        uAHQeSRBllEDAv = uAHQeSRBllEDAv;
        YpuOKksfGm = coLeozWBRaDHS;
    }

    return xiGktiN;
}

yXzDiI::yXzDiI()
{
    this->QEfSJSVgwSPh(string("ZAwYkyJcbVSjoaDQFlEdlgpzAnxBCfqIsSRtVnpMjSvVSDpHSRIryiiscTtmbzZZcKuJXaREtxHJMBTJptkyHqdQkAeDhErtlEQHkAmQezvUFBgrfoFzKzExmhdGgNQkCtpUOsfIgpfJoxAgpleVLHmRZCuQ"), 485364.5986953949, -904167.8379310229, -911749.1573911016, 608115.5558380325);
    this->URgYcnm(788787360, false, -767119307, false);
    this->ZfomBNXXMeiPAkaD(-655410.0047042385);
    this->fWFsR(string("rVsMYRCyAplUmDTvNxHEnSmYjxNhesleKuCFnrrcFZnRpGMXJHkDMuQxmsxmEYbbeFFrUSHPiSuSldTVogbQpKZyuKaENdwrlbZ"));
    this->ZzFYfdehLouYj(true);
    this->dvbCHLGbrAwZQfo(1764558964, -425085.1395678773);
    this->DRhYXXsdKgulYml(string("MBZxvcHCWWMwzPUvzRyWuTVkRcaPhaJMWWRVQlRKySsvWjyVcTNmHhSBRxjojHdpZfBwngCluFMngMEWtbkGCpqvPFJLsgkVOCuZyV"), 1654786029, true);
    this->WhGjnRyEgj(989281415);
    this->lOoOwjRDzqhO(1529991698, false, string("QUoQTeTQHzTdWCyWsWgHfhmDkzA"), string("NyzWaFHGNPYwUirAMlsHrbDYJpRummgCMJNqifAfDrJBrFvQBNOWGVGlhDJyiRIUzecneNtvGiBTdiHddaBGsaixVEZOxBhjsbuQmAgfnXoUODSmAUuUNOiUHvRSLA"), -522054.01629335736);
    this->SCRYdarLzoHx(false, false, -1143499915, true, -161584.82652109032);
    this->QffZGGvqDfpTY(-286313.81483235414, -389333310);
    this->LglpKagVxsj();
    this->ILRUGCdBR();
    this->zmJmzFvusQ();
    this->LRGOSAuonoVQc(-1831322879, true, string("PYYizoOFjCFsBwipvAkceaiTwoYUhLYuMngrgKicxQDifQVlP"), -1302779582);
    this->yVybyfCv(-634472.2569846273, -156044.82846453207, 1336558402, false, true);
    this->BVaveZyxz(-1844477083, string("oYq"), -283075817, 1147335555);
    this->iczjWtnu(-817597.6892119845);
    this->UFOxvwYwrx(392802.3419848286, 591777.3415973682, -859117.9200583891, -183753386);
    this->wVfqDIiblko(string("SKFMDGukEHKoeVIxHOAtLgGGqZiivIWLaBJgauSTnGyZwUlCNKqFacvoXeaQZLXHMiOxPEDftndoZqoIhDISXPSRXlpDZLfhvqixjfcIhchpcihvyAqUAWazEdMoGzNSqNWQXIJlJalXHWtTPnEmZqwUTyJLLzrzHviMMzVoRCsvHkoKsDPOkjGztFyMQjvNwhGKDCMMUxcrcZBsvGzLmCgemmPlLoV"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pxAwoLz
{
public:
    int OjbiPvkwa;
    double GXrKwUroU;
    bool HhTnumgwKBDxnMPS;
    bool jSqroLTqLhX;
    string yDlJvLntwa;
    bool jUxvBcce;

    pxAwoLz();
    double QdsRG(bool wMezurQoK, int TDvxKZxoecKK, bool KHrlKziYFfS);
    double mLHYiDSBdbwu(bool SKaXSPFukTQGRIm, bool GtOJrzDvuzxO, bool CfAnLjlDBNeXU, int CYMqwlTSdEwjdkCk);
    bool laQvDCsSu(double QvEuJmoi);
    int kTLvDjSUhCROiWIB(string VCMZSmTepLDQ, string hEaeyDjGuIAA);
protected:
    double kkihWQhEilxzg;
    double QUHTpjUZCA;
    double nKVrLvf;

    void dqnYmtItuwiulIWR(int cWmYHdjqJtO);
    bool sLjzghPNeQG(int qLWREuK, int koxuJMWca, bool RuzGN, int BSBFFFNF);
    string RtNdnIQ(double CVIrsj, bool nYUPfN, bool wUDfGn);
private:
    string XkPChDFso;
    string UWguekr;
    bool UArutnxBizKNlF;
    int NycFBLkxOnzBqP;
    double pcUeTavOGzXs;
    string OSeXCEoJIjCwsQ;

    string BsuBssIRVgey(string vSApiWr, string nanUN, bool CHLgpeENdEsNZp, double LrGwTlISA);
    bool aiEdJxwJ(double mVrpyvgn, double vajfEP);
    bool CJUCpiKqJUt(string XhzNKNKnOBAofkle, string STIRNJFo, int slOMzNWwQiY, int jNrePLdFCJUH);
    double fJSQOBYFs(double IRHXWW, bool YfCxlor, bool BauqUtYspQ, string GszSlN);
    bool nkqRXVCWHbhLbea();
    string HAvQwWsUTp(int DwBRBEXajRJBvFE, double RYmikYUvgYKvTcma, int lEWfQeTvCbD, double HsmWZAjB);
};

double pxAwoLz::QdsRG(bool wMezurQoK, int TDvxKZxoecKK, bool KHrlKziYFfS)
{
    double LErnOMvK = 810762.6678456158;

    for (int TjYfHRPFQdSymq = 1732437944; TjYfHRPFQdSymq > 0; TjYfHRPFQdSymq--) {
        continue;
    }

    return LErnOMvK;
}

double pxAwoLz::mLHYiDSBdbwu(bool SKaXSPFukTQGRIm, bool GtOJrzDvuzxO, bool CfAnLjlDBNeXU, int CYMqwlTSdEwjdkCk)
{
    string uAQPrdbce = string("uOwcVPLCxOtdKjuQwJFfRjCAQMMyoCFdPuqRAwuytqjPlUUzZhJwQilVpioXWQWMJDIltVrNqcgRwMWjhkXIzBuYgnVLumurWyTsoDevwBeLxaFUhfeRprBLBMRXlHJfMGUtnbtLmVSOdbWAkzhqlDOqrNwUkkhduKgiwdTv");
    int hIkvvPOYbcuT = -1323508345;
    int UzzlN = -1372068591;
    double ScmOWuqXQgSc = -1033584.0519618823;
    string njzTiKVWjMbI = string("CqpGcjzNTeOEcLvzxpxTazWPYksdlMbcyDiQHLfWCsiteDQbwNylNHpuNNtWEANJHfeSjAVsjbdUxJBIeNHCiaruiUhDYvXEQyKaYsnbCHhIUbVdziYSjeGbRlmMkszlYILoTzCIZjpoIIwHbfgBoqrIMtexdIxlG");
    double zcVCfToeb = 581900.4605461777;
    double WdJFZEBC = -901269.9293382508;
    double KhRhAQOdx = 463728.1788080744;

    if (hIkvvPOYbcuT < -306841090) {
        for (int yezxQBFsYPAIDf = 536928018; yezxQBFsYPAIDf > 0; yezxQBFsYPAIDf--) {
            hIkvvPOYbcuT = CYMqwlTSdEwjdkCk;
        }
    }

    return KhRhAQOdx;
}

bool pxAwoLz::laQvDCsSu(double QvEuJmoi)
{
    string LioBckvesIzPAWO = string("V");
    double xFYawrtHzUw = 501327.3088484831;
    string BbwlqoSILvArAAJJ = string("ZxCcOFEETVMBIMukUZbBBnhvjJOXeFOVLNlvXlzteqesplirRIKVcorPGOghufzBKHWlNGULafVIfhgqRuVxAgDdIqotclfGsThMdoZeEkSarpfLiyerGPM");
    int VrZHGavpQXikdvb = -872457951;
    double rdsPiiGqy = 861896.5208817854;

    for (int LpRZtjoeiwO = 1923345158; LpRZtjoeiwO > 0; LpRZtjoeiwO--) {
        xFYawrtHzUw += QvEuJmoi;
        rdsPiiGqy = QvEuJmoi;
        rdsPiiGqy += rdsPiiGqy;
    }

    for (int QwMmjakMdASgU = 1432989000; QwMmjakMdASgU > 0; QwMmjakMdASgU--) {
        xFYawrtHzUw /= QvEuJmoi;
        QvEuJmoi *= QvEuJmoi;
        QvEuJmoi /= QvEuJmoi;
        VrZHGavpQXikdvb = VrZHGavpQXikdvb;
    }

    if (rdsPiiGqy == 501327.3088484831) {
        for (int dytEQmUNH = 721632190; dytEQmUNH > 0; dytEQmUNH--) {
            continue;
        }
    }

    for (int KsYuVDCuVbskdkfd = 1170124456; KsYuVDCuVbskdkfd > 0; KsYuVDCuVbskdkfd--) {
        xFYawrtHzUw *= xFYawrtHzUw;
        BbwlqoSILvArAAJJ = BbwlqoSILvArAAJJ;
        rdsPiiGqy *= rdsPiiGqy;
        LioBckvesIzPAWO = BbwlqoSILvArAAJJ;
        rdsPiiGqy *= rdsPiiGqy;
    }

    return true;
}

int pxAwoLz::kTLvDjSUhCROiWIB(string VCMZSmTepLDQ, string hEaeyDjGuIAA)
{
    string LinnYjP = string("VfmNNuXIzrWICnjaJbVhNrNcqLKenPzaGgyjOezarIscHFOVZzroOodGRuuFRfyTCXPKjAxhNFOvQGfTuyovDbviKOKKdLDDozaRUIOArZofbFuCMfwdBnaRqWaAVybFGiIxBTfnTRwjicGNcnFINWojdYtqyPkMCEuUvsOhcMugFzGgeTJqboDRULUmaUPYwXNfHWtbDYvQeZZkDweKyXEASOWNVmAMCPGudpmVdxfbTr");
    double MOIdTNbc = 112495.96256407685;
    double AwwdzqrvPjZMt = -538252.6880202127;

    for (int hfWCXUus = 1229117704; hfWCXUus > 0; hfWCXUus--) {
        continue;
    }

    for (int vBJUMGBQLuzl = 1857986492; vBJUMGBQLuzl > 0; vBJUMGBQLuzl--) {
        hEaeyDjGuIAA += hEaeyDjGuIAA;
    }

    if (VCMZSmTepLDQ >= string("aykCvdfgTZOjAbmtIepquRvIAAFoDXDVjFiyhBIvsJdwRNhiGdoYJfydSlQhHFwdyHFZEmAAIdKXjJxuhknaLaWQjLoGZgBXIGopoGDNbQmjqJVMMiYOLysyLDCnxtZmqXOtdfJLDCLCFiFhyzRmmkZxSMwopyWCcXeUdXWuHwddEQpTYYMoWqxDefdjcMrEbqSQoetwQNvTuUSISlmALcAZXnNnNIEdfWKxlcAcgkwib")) {
        for (int aqxblUBR = 1648714016; aqxblUBR > 0; aqxblUBR--) {
            VCMZSmTepLDQ += LinnYjP;
        }
    }

    for (int NAeqB = 1080837160; NAeqB > 0; NAeqB--) {
        hEaeyDjGuIAA += hEaeyDjGuIAA;
    }

    if (AwwdzqrvPjZMt == 112495.96256407685) {
        for (int LzYtyoRuZrKiwX = 1572365636; LzYtyoRuZrKiwX > 0; LzYtyoRuZrKiwX--) {
            continue;
        }
    }

    return -844439125;
}

void pxAwoLz::dqnYmtItuwiulIWR(int cWmYHdjqJtO)
{
    int sUgAnAC = 79411956;
    string CyRzHPbUVX = string("DkgsbqtfXYbpeUeogrsfYgrbBwQVmcNRMChEIJWyqvnxHxqABJngMjWLFiephpuYJsgcpJBEeOMLbHXND");

    for (int yvfKohnApO = 70820617; yvfKohnApO > 0; yvfKohnApO--) {
        continue;
    }

    if (sUgAnAC > 79411956) {
        for (int YhVmWzEbNKZLWx = 1767165182; YhVmWzEbNKZLWx > 0; YhVmWzEbNKZLWx--) {
            cWmYHdjqJtO -= cWmYHdjqJtO;
            sUgAnAC -= sUgAnAC;
            cWmYHdjqJtO += cWmYHdjqJtO;
            sUgAnAC *= sUgAnAC;
        }
    }

    if (cWmYHdjqJtO < 95762663) {
        for (int RONOhqPVQPKozM = 2104333799; RONOhqPVQPKozM > 0; RONOhqPVQPKozM--) {
            cWmYHdjqJtO = cWmYHdjqJtO;
            sUgAnAC = cWmYHdjqJtO;
        }
    }
}

bool pxAwoLz::sLjzghPNeQG(int qLWREuK, int koxuJMWca, bool RuzGN, int BSBFFFNF)
{
    string dBfHXuFRc = string("yRjuScUIZFcIRpQGCNOQcXQOhtHcfaedkQhJybYAkVXhHvhVGpcQYZRUwKefXDGjDESxchsKTPsJLnHgaNHpxEhaghLmxSKGrPqPquCNfLmgQbCgxSKwUSPoPNtVIFQXMUvrwLUzya");
    bool kxVEZFfBeBC = false;
    int hCEBEqVgw = 1070307869;
    int mNwyqPAwnGvTcMtU = -1148870878;

    return kxVEZFfBeBC;
}

string pxAwoLz::RtNdnIQ(double CVIrsj, bool nYUPfN, bool wUDfGn)
{
    string hqUOAWPA = string("moQROZoSQwpipqwxGgCb");
    string FPglaGlRYYFzpDRF = string("JRxAHKRFVbtzlshjXDBMkekspLKEhufkvdbKPgrSjEYnZaQPFFhHgoFdpIbMlylerQewLLAdPeqFbMdGwrFuuFVlBgxAzMLdNwJZaXlxbFSKxGDiaGdHgqwQIPLtwihKiTjDhNqwVflDeLAOwWqQGEUUjQLbibieoKgeNevRx");
    string oqvbWRGVHjCp = string("VdagKZSKuHfHlHVeqAoKFSlVeMGUywqpJPgeTIsiBFEKwgbzmjsZgtmtBOzNGFdwngqUYYUoHohDwIjpWbjxwCUAaVUBXEmiUGPVYCJidiDpeZhJnKchTQQqCTAEhYHKwcdHrTdSvgakxwwCBbkNRGqHljaygjBzrpJhPJAnDQIofzLsFEVJOjNYhwsGowrMJtgRJxW");
    bool sIoufJZcCb = false;
    bool qPkBEpEACWteuBfp = true;
    int UMKoUhI = 876339498;

    return oqvbWRGVHjCp;
}

string pxAwoLz::BsuBssIRVgey(string vSApiWr, string nanUN, bool CHLgpeENdEsNZp, double LrGwTlISA)
{
    int NRBIdWWAe = 1073149177;
    bool jXPWuOyNpDUBnm = true;
    string eJzLqFx = string("UrhUSgFQqDligcJalubETnAZMJbwHcBPWIMLeeTWaLQEfclgLCWgJMkTJBiJvmHbxhYUMvvqZEADdxdKJdtJZEoBHFzwhSGsxdFutZIdtXxJmPtFjMjxxrDlBDZuzZdQOTUDKzNGqvfLAuqxLOTaGLdoyiLrgmgxjNBjNhiWmGLWXUNOyICpVCLWzUlhlqPrGvSpJ");

    for (int HucOUidUslEC = 1125165681; HucOUidUslEC > 0; HucOUidUslEC--) {
        eJzLqFx = nanUN;
        eJzLqFx += eJzLqFx;
    }

    for (int HivCAjHVOZGYxf = 2012857986; HivCAjHVOZGYxf > 0; HivCAjHVOZGYxf--) {
        eJzLqFx += vSApiWr;
        LrGwTlISA *= LrGwTlISA;
        nanUN += vSApiWr;
    }

    return eJzLqFx;
}

bool pxAwoLz::aiEdJxwJ(double mVrpyvgn, double vajfEP)
{
    double hnmDTpwlVDrSH = -645707.0798320642;
    int XJHhuKhEhrxOm = 185302022;
    bool EoRjxSX = false;
    int yjNivbXteqQVQ = -684818893;
    int xEzSNfyBkprJM = 1522477219;
    double wQQPw = -293451.6949156839;
    bool qzGAK = true;
    string URPPKCKpBKAGwxv = string("cwrXNyWXyWKyBsxydfFLphGcfQYzkZMfleQUhcpFSTozqPXFoHhnamvSNurwKWNzNGJTNvofLFXmyoXPudaeLRaJIqKodtuEzQXBHrYchvFoopDhfhPPTAlksRiycMzYkWdUMVZMZOmaqXdEmeruWTwZmXutqfWOcDjbdAgVJVsMgkvCp");
    bool VFWWGypbNKVw = true;
    bool GsMJgafuca = false;

    for (int lyiqpVB = 687142178; lyiqpVB > 0; lyiqpVB--) {
        xEzSNfyBkprJM += xEzSNfyBkprJM;
        qzGAK = ! qzGAK;
        EoRjxSX = ! GsMJgafuca;
    }

    for (int UqlTST = 190500827; UqlTST > 0; UqlTST--) {
        continue;
    }

    if (qzGAK != true) {
        for (int AfgJwFpnrDHWthn = 1984438623; AfgJwFpnrDHWthn > 0; AfgJwFpnrDHWthn--) {
            continue;
        }
    }

    return GsMJgafuca;
}

bool pxAwoLz::CJUCpiKqJUt(string XhzNKNKnOBAofkle, string STIRNJFo, int slOMzNWwQiY, int jNrePLdFCJUH)
{
    double pHYqzugFF = -197683.2125438631;
    string rAntSyiD = string("eblICzBjkaCcTOBJiurUWDJXdJYvTcnvvSBuHrCBMZfzFnAYINYDKjebyrFIAfNFqjzhzkxNhtXhqAULeIPWHUxDeQRlbFpDAtZbZoTcWUTNfxrUeoTFemDoukzNt");
    string VykrFvVRa = string("lKiDZGQdJCgKxMcZmX");
    string CcuZARnMH = string("FGYheFxjIAHYRgkVmerAPNRNeAEWxzFjKDmYoffqZwIQgeONWmYUlevQpBrPIPgEdscFQSjxISTyHUAgsdAtdhjgvBgZlacgKoIBgNVRyBvmRsltFkZjPjrdVoAiwUosHJakPCskGCdzuUFXqJxOShpTpkYmAQljLKteekhOjHwXmClfpzWBoZLtlPCMFKnvPiMzbxDjriNPNIVteUwyuLzLHvVrSCzzBmJDiJK");
    string iYcwKHnlwCAZU = string("BtozQxVFMJxCQogAKwYPGAtRpcLThVcLSdhgeEFapfAYfeVpAboGknJVjkXsnQzOufcAtfvwXjnwzDNRPSCAViTsZHgZrefvbynpjpaduJoOMoxQGkIGKUKtuagjCFCVeRJQYSLKschJXXshHvqrFJSlTrQgyyDXYVsPtlxgPBiHPAAwFsDFGXAfOxjvsVGppmvdAtRqqaHzaqA");
    int UqFuxqonVAvEo = -1607976712;
    string vnTBgIrjMqYQUoAK = string("SteMxbOHyLBdJoZGuWYWKAlcBkmQnbDRlXHVzguXxNahCRcxvmQfcvYvVqQwnLlirjyOSYEKoFveqfnsPWPLNvSKmBrPZredLtiNdNsWOizcVoObnzRouPsPtkGRTb");
    double qVUcwIhTVwHIzZ = 669747.807725601;

    for (int ZsiXJNaaEtKN = 1332133021; ZsiXJNaaEtKN > 0; ZsiXJNaaEtKN--) {
        qVUcwIhTVwHIzZ *= pHYqzugFF;
        VykrFvVRa = rAntSyiD;
        vnTBgIrjMqYQUoAK = XhzNKNKnOBAofkle;
        jNrePLdFCJUH *= UqFuxqonVAvEo;
    }

    if (slOMzNWwQiY < -1607976712) {
        for (int BWoMKhl = 280634370; BWoMKhl > 0; BWoMKhl--) {
            rAntSyiD = VykrFvVRa;
        }
    }

    return false;
}

double pxAwoLz::fJSQOBYFs(double IRHXWW, bool YfCxlor, bool BauqUtYspQ, string GszSlN)
{
    double TmDMd = -12555.162953219964;
    string ahwKoCTEcjcQai = string("LBQjQVsziqRGszdgtSrBEZRjYsCLcGqZhHmjLYBpJFyrnfasmAWvlkQykbhsyKbRPNmdHCLikcZxBiYyIIXwiTHjbtqKbLdQgmdkwvuxjASsYqOQswvCgtEXNLncUBrTnvSVsgIQhBszwbiiAsSwcXiueaAYCJFoVivjUwGkfVvyaYCJRofwvGHvDpEypqvOsweNkhspUStkXXjfRxMzNdnPzCwpf");
    double FGpnwlx = -649537.4931439079;
    bool jbHoiCwRLhQj = false;
    string FfDBXypT = string("LxqUgObgqAERvTGfPQlUxcikxnUswovVNq");
    int jGYOXTlkTBdj = -1945044189;
    double ztSSo = -377910.8823208562;
    string pmGazrpsGDA = string("wBKpUHwDapfvnAZApeNSmEOmNWvahhXcIrAksDS");
    string rRhBwoci = string("OheqLQkhUCBXuKgCiAFTYYJJUDarTLXtaiaqbqLaayrQoKPyORJcDibphPDgiFRSZYMIOstZkaondOtConAAVxuJZPtJvJxQDzcOGoOjaqJyiRLhcvDHwZGCEwNCeoDuvwUfmFbYLuSgUWrirtjmWR");
    bool AtcsQTnqOhQPebYk = true;

    for (int qitoPtvHLcLlaq = 255618816; qitoPtvHLcLlaq > 0; qitoPtvHLcLlaq--) {
        rRhBwoci += pmGazrpsGDA;
        ahwKoCTEcjcQai = FfDBXypT;
        rRhBwoci = pmGazrpsGDA;
    }

    return ztSSo;
}

bool pxAwoLz::nkqRXVCWHbhLbea()
{
    string WtNNTjw = string("DcDNTGtRbLwQEPvbHntfqeJnBKXdCDoiIKvkiAFTOOzZlDcefqFOfyaHsSFBsFccpXoNrhpUrHFBLPcYZCVAWdCSuzdGqLvyIj");
    int sNXGtymRr = -1268116302;

    if (sNXGtymRr <= -1268116302) {
        for (int egHGeCiOtmAK = 1571078026; egHGeCiOtmAK > 0; egHGeCiOtmAK--) {
            sNXGtymRr *= sNXGtymRr;
        }
    }

    return true;
}

string pxAwoLz::HAvQwWsUTp(int DwBRBEXajRJBvFE, double RYmikYUvgYKvTcma, int lEWfQeTvCbD, double HsmWZAjB)
{
    double HBQUpqU = -912695.5259003296;
    bool uuMKK = false;
    bool VxToRKUB = true;

    if (HsmWZAjB == -912695.5259003296) {
        for (int ykHIkPdKIlhy = 143853102; ykHIkPdKIlhy > 0; ykHIkPdKIlhy--) {
            HBQUpqU += HBQUpqU;
        }
    }

    return string("RVRkXKmQGkQSUIMIilgHMqhlR");
}

pxAwoLz::pxAwoLz()
{
    this->QdsRG(true, -1228696306, true);
    this->mLHYiDSBdbwu(false, true, false, -306841090);
    this->laQvDCsSu(72244.46620064387);
    this->kTLvDjSUhCROiWIB(string("aykCvdfgTZOjAbmtIepquRvIAAFoDXDVjFiyhBIvsJdwRNhiGdoYJfydSlQhHFwdyHFZEmAAIdKXjJxuhknaLaWQjLoGZgBXIGopoGDNbQmjqJVMMiYOLysyLDCnxtZmqXOtdfJLDCLCFiFhyzRmmkZxSMwopyWCcXeUdXWuHwddEQpTYYMoWqxDefdjcMrEbqSQoetwQNvTuUSISlmALcAZXnNnNIEdfWKxlcAcgkwib"), string("otuLLfabWdhHVhRpVLmrZBmAkfoCMahEsEcjfSFFzXUtubxcpiSphvJACeljGwVFQEaINWpHaJrygUPfVsFVdRxLGMDWukIdGGBYGbpGMRzXZtYKbcPKHQMFNcrbetOtiFdfYbsAVAInJKCKHTqXIlbTtWsFdOMJbSJHdOEZtagzvqPhECZggKAmLcSqJnvxpFLFzwGtPBFGcaAVCoSoObDWESNxEzVdQXDWxvpubn"));
    this->dqnYmtItuwiulIWR(95762663);
    this->sLjzghPNeQG(-88364794, 95668971, true, -1406841966);
    this->RtNdnIQ(503996.78544674645, true, true);
    this->BsuBssIRVgey(string("qmKTaduOnqFsQPpydylFawnAOtDMGUZtwiuxEdWKKTcHDlMFgrcvEakDvZmYotUopVOrKlpralDCLIzvaJBQKDZAoTyYkYXYNlZSeTGXdyTRnNbAdcrZzrhjWHoEIrIpBePZfaiEKmvqOPOvh"), string("bTwgIbVaMVEztfZzCffhQTqMroFNxqncXhDMZeulRmJJDgGilFCCnKCTFICSWHqHJ"), true, 663520.7172542483);
    this->aiEdJxwJ(839091.9577911483, 765620.9204708259);
    this->CJUCpiKqJUt(string("FsXGowhRBLFtzKQXpPsWaTgGOtujOxFuLHPDiUjKqRlciTjEaYdSRrabAoECBTivPOxdbDYajdzmwsiPRBJRNmZxfJQJjWqFGNctamBhwYYiljX"), string("IrYIIqeycfRPnmkoPdSo"), -1782600503, 2024152924);
    this->fJSQOBYFs(-929623.5100396827, true, false, string("sptrtFEBUxDnsUvZddebQaBXaLbUrfceCJfAirxpmVuDViQmhwxNESOkjUscZSQOzFNFdmnhWsnUgRDswHcwDEypkTccRrOYMbsxXJBILUhYBnbrzrDUdHQbFihXWPwuLdHfMgVUcsArurJGugquLKHeKmkukfWmcTkXBJVMZheXNIqDPMpMqbSDEnSnBYGgCBcWWZkAFugaqAkdTMoIkGxWUPWIY"));
    this->nkqRXVCWHbhLbea();
    this->HAvQwWsUTp(806100979, -724378.2094372567, 11110180, 762191.6900159962);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EPSpfqSVU
{
public:
    int OeeNYlGva;
    bool UkdYQMGLaRZguC;
    double NsOGVNPfaLtLfwIS;

    EPSpfqSVU();
    void jeocxkoLvsHEYhZ(bool cMfilQwHRIsU);
    int JNywyrGzhpNxRcDB(bool lZWraODPJy, bool tPKlyrsluG, double AEhHuteA, double AqHekGdlY);
    string DLtqyFyVniPOqde(int kbOgMpBfoI, bool kGrTOgSBuguE, double YjcyeYdXvLMFWmN, int rclQULjRGCbYpF);
    void oPKttRRz(string ZoHIc, string zEMAblZOAJHL);
    int qhoIoocWX(string vMfGxcXSfvqCQdN);
protected:
    double eHOltKbVhXjXA;
    bool tnpTVBLSsmIXdbiq;
    string TJUWAqpXYYpGM;
    string cEJqjA;
    string ZRpzGoRkAH;
    int qcAEZ;

    string uLwiC(bool dqxUSm, int JoITGWkuzM, int veWpIebNINn, bool ffDrecjMDQCgNGj, bool TDxhRXflagknwjkq);
    void DTertuBuiS(string zEeiekBs, string zUStOEIPTGFV, int nDuXSlLgCZ);
    string pKeeTKB(string PyTeSzmynvFt, string WdGHzsRxqe, string CMOaAVwWl, string qIXewCaFZzMagah, double bTBUUXatfHN);
private:
    bool MlQnJXpKKzvdN;

    bool VHlOqzXJcaFfwjR(string rTwnsTQurKbocQA, bool xuFBvbBzPEYQpxZ);
    int AXjVtlnueeVrZg(int uXbVrKbKrIrTRZwS, bool bxfkUJBNuG, double kFVebbAVuh, bool leoZotsgfP, string kiHIdsygzzVH);
    double CklkdMuJ(int lVlnKfAq, int sldMI, string dPWPRmbVC, double rypurwGiQVW);
    string yrhsUtrDrOEnL();
};

void EPSpfqSVU::jeocxkoLvsHEYhZ(bool cMfilQwHRIsU)
{
    int YliajvWDRZ = -933346050;
    int BsEUk = 43637349;
    int jsrRKBNHKJymuxR = -1879590387;
    bool cfcJnYcHcmrpF = true;

    if (cfcJnYcHcmrpF != false) {
        for (int UUIgHTxXZvyL = 800731445; UUIgHTxXZvyL > 0; UUIgHTxXZvyL--) {
            BsEUk += jsrRKBNHKJymuxR;
            jsrRKBNHKJymuxR += YliajvWDRZ;
            cMfilQwHRIsU = cfcJnYcHcmrpF;
            BsEUk += jsrRKBNHKJymuxR;
            jsrRKBNHKJymuxR = YliajvWDRZ;
        }
    }

    for (int hZDEpEWEkCaOJeTp = 1603019675; hZDEpEWEkCaOJeTp > 0; hZDEpEWEkCaOJeTp--) {
        cfcJnYcHcmrpF = ! cfcJnYcHcmrpF;
        cMfilQwHRIsU = cfcJnYcHcmrpF;
        YliajvWDRZ /= jsrRKBNHKJymuxR;
    }

    for (int drdYmyqPWrEn = 561640890; drdYmyqPWrEn > 0; drdYmyqPWrEn--) {
        BsEUk *= BsEUk;
    }
}

int EPSpfqSVU::JNywyrGzhpNxRcDB(bool lZWraODPJy, bool tPKlyrsluG, double AEhHuteA, double AqHekGdlY)
{
    double UGkRrfAWvkHazg = 789194.9192528356;
    bool JfxyiyRsEtXd = true;

    if (UGkRrfAWvkHazg > 354135.21244612045) {
        for (int IBwrlpBupOXuWp = 553166144; IBwrlpBupOXuWp > 0; IBwrlpBupOXuWp--) {
            lZWraODPJy = ! JfxyiyRsEtXd;
            tPKlyrsluG = ! tPKlyrsluG;
            AEhHuteA += UGkRrfAWvkHazg;
            JfxyiyRsEtXd = ! lZWraODPJy;
        }
    }

    if (AEhHuteA >= 789194.9192528356) {
        for (int HGGPDvvcJXSvoNi = 141552704; HGGPDvvcJXSvoNi > 0; HGGPDvvcJXSvoNi--) {
            lZWraODPJy = JfxyiyRsEtXd;
            AEhHuteA -= AEhHuteA;
            JfxyiyRsEtXd = ! lZWraODPJy;
        }
    }

    return -1581698561;
}

string EPSpfqSVU::DLtqyFyVniPOqde(int kbOgMpBfoI, bool kGrTOgSBuguE, double YjcyeYdXvLMFWmN, int rclQULjRGCbYpF)
{
    int SHvpscF = -1261411576;
    bool sPMhnQpw = false;
    bool CmxQgPmpdoR = true;
    double lrpZuUmK = 957902.6467248646;
    bool tXDNfjAX = true;
    bool EpcYCO = true;
    bool ZGASTGLE = false;
    int VtoBh = -1572030522;
    double myoFxFaPuOrsvIe = -871447.5846689356;

    for (int AVGEeEOWwhPmVC = 1945351764; AVGEeEOWwhPmVC > 0; AVGEeEOWwhPmVC--) {
        ZGASTGLE = ! tXDNfjAX;
        rclQULjRGCbYpF /= kbOgMpBfoI;
    }

    return string("WHIBzVNzsuttrYLXkQWQKVMHXnsiKnOveVygDBjXvPizDQSLBaAqonHEDJkaAZkebwAxMdkHEzaDMVFUhUeKMkYeYdrmYfeeZIaTMcDvrqYolCINCjhUPkCmkHYGXIYHVvkaJvYYWXnhnZrOjoRwLTAEOlgNVkwrGwWulLDXjAAMkWJJHCRnAP");
}

void EPSpfqSVU::oPKttRRz(string ZoHIc, string zEMAblZOAJHL)
{
    string nEEgrDYrYywhBoF = string("xSPAFFbLhfbqwCwqQHdIxUgGoCcXuGTVKrtFKOZEddNMSnUUefVytWPYjUByWRTPONMDHePCHBDuNBGBVORQiOcspmeyEpjEKMLQMEbiKZVOqfQ");
    double pIDqtiJzTJsxtIgV = 800699.5246553004;

    for (int SJrMpsvcGaVAM = 197577007; SJrMpsvcGaVAM > 0; SJrMpsvcGaVAM--) {
        continue;
    }
}

int EPSpfqSVU::qhoIoocWX(string vMfGxcXSfvqCQdN)
{
    bool AoMTuCyw = false;
    string VEJdGwSqgjzUYeGp = string("yTbScatdvNWeGolFdQtrCimzPRmvJTDaAJrHKMcfIBgDqzeNStWchghDFWINWZyzDuNrJSORUWNMAZ");
    int oTzUpCJAyXwhwLST = 279268117;
    int xxmveuO = -657874;
    double RXHghkuAzY = -972149.2430724273;
    double LagoVYXapjcVty = -243796.06173283694;
    int begwtJeokbR = -1858723277;
    string ePOPYckkq = string("xNfMeNsiDgvVVrOiIPA");
    bool ZotRIGdUKFspp = false;

    for (int MmkGnjved = 982691027; MmkGnjved > 0; MmkGnjved--) {
        vMfGxcXSfvqCQdN = ePOPYckkq;
    }

    for (int OYvDNoodeCxw = 871672565; OYvDNoodeCxw > 0; OYvDNoodeCxw--) {
        vMfGxcXSfvqCQdN = ePOPYckkq;
        oTzUpCJAyXwhwLST *= begwtJeokbR;
    }

    for (int fPNJE = 1561341412; fPNJE > 0; fPNJE--) {
        begwtJeokbR -= oTzUpCJAyXwhwLST;
    }

    if (AoMTuCyw == false) {
        for (int curQmKMlGOHN = 288228965; curQmKMlGOHN > 0; curQmKMlGOHN--) {
            LagoVYXapjcVty /= LagoVYXapjcVty;
            begwtJeokbR += begwtJeokbR;
            ePOPYckkq += VEJdGwSqgjzUYeGp;
            xxmveuO -= xxmveuO;
            ePOPYckkq = vMfGxcXSfvqCQdN;
        }
    }

    for (int dWTcB = 483373286; dWTcB > 0; dWTcB--) {
        VEJdGwSqgjzUYeGp += ePOPYckkq;
    }

    return begwtJeokbR;
}

string EPSpfqSVU::uLwiC(bool dqxUSm, int JoITGWkuzM, int veWpIebNINn, bool ffDrecjMDQCgNGj, bool TDxhRXflagknwjkq)
{
    string cISdSzjfUAsD = string("AMOOWUPHxKkvimmdHYjFCNSFnjQtugfmiBOYknnxMVLSVDyIBiCtpFxvBEXdTbvLOwUySmycVJQIplwynfSFOMRzOTntzzeZLoNvIJOjnALmmrrbqoAEHlAsaEHSQYGXgMnfjRiihfXcnJqGOuFuXsQffknHqaaVct");
    int OdyXqMQUcapyrYK = 1903690911;
    double frkAzlYgRBccJuZ = 216602.57801020885;
    string rNGlN = string("cTEWgjVVKxcCIEQeHklNtWxjCyEeWblJSAmymrzHcunBmhVcYGkSsnlUwpOHLHKlztRsxKCfbEoGiCcHWLlqlrIiUADnYOMSCNqnPZfHeJeZOHXZErImmUTpvxEXmSQuoZsLiSscfiyWUEIXQMXufqWYkndlvNnXddchobApNJLdNgqiWKtLVLakSafTwiXiAbRIZpwZjoyCVJVAyzjaheCdWkngBFgcfgVqOiR");
    bool nYJWWw = true;
    string OtBJSwGVonNo = string("SNadjCZkIMCzvGGVHdFSLGbuYREsVnaaIayuzzJcSYvgzPgcnTFOZgHwUAdFcYufUA");
    bool ydoqvF = true;
    bool eWCvaJxoutXlnu = true;
    int DkGIPtbOM = 43360328;

    if (ydoqvF != true) {
        for (int yJfbZVqtIYss = 737881797; yJfbZVqtIYss > 0; yJfbZVqtIYss--) {
            continue;
        }
    }

    return OtBJSwGVonNo;
}

void EPSpfqSVU::DTertuBuiS(string zEeiekBs, string zUStOEIPTGFV, int nDuXSlLgCZ)
{
    string kSikdGKrMU = string("xhBAonBLWtWjl");

    for (int wwJTo = 827085042; wwJTo > 0; wwJTo--) {
        zEeiekBs += zUStOEIPTGFV;
        zEeiekBs += kSikdGKrMU;
        zUStOEIPTGFV = zEeiekBs;
        kSikdGKrMU = kSikdGKrMU;
        zUStOEIPTGFV = zEeiekBs;
        nDuXSlLgCZ *= nDuXSlLgCZ;
    }
}

string EPSpfqSVU::pKeeTKB(string PyTeSzmynvFt, string WdGHzsRxqe, string CMOaAVwWl, string qIXewCaFZzMagah, double bTBUUXatfHN)
{
    bool DOmZOXRZvHq = true;
    string wFeRSuztOreK = string("ImDWevLsZdvQczlmESzZifiweUplvMHKaDszDKsSByGfIrKiiWJvWGTceFrGZtPRwIrxsrZhPKildnwVitobafEqG");

    return wFeRSuztOreK;
}

bool EPSpfqSVU::VHlOqzXJcaFfwjR(string rTwnsTQurKbocQA, bool xuFBvbBzPEYQpxZ)
{
    double XKMShPgHlioFliG = -163697.15821346102;
    bool qrAwQYaoAbyqi = true;
    int GoAwfBCVxSrXmbmF = 60725408;
    string OdiCzgpQw = string("pBYvbkpLIavAEswEILDzCagJAPXfeAFtHnbcOanSTRVZSVLEPWrNkPIzZIFwAONnjVLJleMnnwpRmRkslkRUoSjdJKuUEXtwcISBlPjYyznDCyRwxhWavZkWkYBfIHMVAHKDAJYtgDlQdbIlniGJHLuPHLsSOQmIHToAlBLYkHwiAmJloctGSmGwkoKtvtDqnQfgninTdwfRhejFATdAmEtMdgtavDduhDM");
    bool JNguEdjxO = true;
    double smsHh = -826010.3604870861;
    bool reIoYJfeaeoYDESn = true;
    int rRdqbA = 1749531348;
    bool hfhDTVoIlZnV = true;
    bool YqTCqYuKegeqqjYO = true;

    if (hfhDTVoIlZnV == true) {
        for (int FcvKvkSjZuSPYH = 74072188; FcvKvkSjZuSPYH > 0; FcvKvkSjZuSPYH--) {
            continue;
        }
    }

    for (int EqUSnMVMnSxbpYuc = 1618467468; EqUSnMVMnSxbpYuc > 0; EqUSnMVMnSxbpYuc--) {
        YqTCqYuKegeqqjYO = ! qrAwQYaoAbyqi;
        JNguEdjxO = JNguEdjxO;
        reIoYJfeaeoYDESn = qrAwQYaoAbyqi;
        reIoYJfeaeoYDESn = ! qrAwQYaoAbyqi;
    }

    for (int govEPqu = 367567666; govEPqu > 0; govEPqu--) {
        reIoYJfeaeoYDESn = YqTCqYuKegeqqjYO;
        rRdqbA /= rRdqbA;
        rRdqbA += rRdqbA;
    }

    for (int OpgjEooFlrB = 586780787; OpgjEooFlrB > 0; OpgjEooFlrB--) {
        YqTCqYuKegeqqjYO = ! reIoYJfeaeoYDESn;
        JNguEdjxO = qrAwQYaoAbyqi;
        qrAwQYaoAbyqi = ! JNguEdjxO;
        rTwnsTQurKbocQA = rTwnsTQurKbocQA;
        qrAwQYaoAbyqi = ! qrAwQYaoAbyqi;
    }

    for (int yyRRJlVy = 83497709; yyRRJlVy > 0; yyRRJlVy--) {
        continue;
    }

    return YqTCqYuKegeqqjYO;
}

int EPSpfqSVU::AXjVtlnueeVrZg(int uXbVrKbKrIrTRZwS, bool bxfkUJBNuG, double kFVebbAVuh, bool leoZotsgfP, string kiHIdsygzzVH)
{
    bool iPuyyZGRogxPEq = true;

    if (leoZotsgfP != false) {
        for (int wXwrzWosckb = 1784651352; wXwrzWosckb > 0; wXwrzWosckb--) {
            continue;
        }
    }

    return uXbVrKbKrIrTRZwS;
}

double EPSpfqSVU::CklkdMuJ(int lVlnKfAq, int sldMI, string dPWPRmbVC, double rypurwGiQVW)
{
    string KZOWWjnYn = string("BlmpnGlSDAYTwKmSbmAuvQGmFOjwRJbIHglQcdlWtgzekVxrCNqZLeWXMkiqrRfCUjNsrebangadBGdScyxOhsKKEtCRIKhxiLqduzrOHpaCztpzFrUOuFYwClqDRfqkoskUPzMWNxpEvFmriHQOAPTAgamvdEkpQrnHlIjNvTKrKJMjBWCtYBgQjkX");
    int vsgbe = 1252732114;
    string VfJCiEpigVqDAuDO = string("ynCeQbiBCmDGqIpIsHGRyrSOoZGnZmKQrNzbcOFRweArUQCDfdJlaB");
    double tadQKF = 608462.4714737755;

    if (dPWPRmbVC > string("ynCeQbiBCmDGqIpIsHGRyrSOoZGnZmKQrNzbcOFRweArUQCDfdJlaB")) {
        for (int GpynWcALszCCYL = 1053520468; GpynWcALszCCYL > 0; GpynWcALszCCYL--) {
            continue;
        }
    }

    if (sldMI <= 1252732114) {
        for (int DkmSlHkLX = 905529370; DkmSlHkLX > 0; DkmSlHkLX--) {
            continue;
        }
    }

    for (int XjiqhMZjRT = 12839370; XjiqhMZjRT > 0; XjiqhMZjRT--) {
        continue;
    }

    if (tadQKF >= 290214.984179441) {
        for (int wBRlpHcIn = 225670020; wBRlpHcIn > 0; wBRlpHcIn--) {
            tadQKF += tadQKF;
            KZOWWjnYn = VfJCiEpigVqDAuDO;
        }
    }

    return tadQKF;
}

string EPSpfqSVU::yrhsUtrDrOEnL()
{
    int MgbELMDoKqGK = -790915686;
    int tnSgpSzRa = -1712358705;
    int oaEYIhG = 473786115;
    int heXhmxaGbMqZOa = -1931453674;
    int HykNbPkKSmCGSDK = 1885389458;
    string laOTqymJFhVxcXaL = string("zrcDUMBwjeMyqdGaGqDEcobOlyLXptkauvMbNnqdRxTeSVTweQTeEVTkVsQsQuYTbSsmLguAjSGvHLQSdTKLthZJTvNWQEvMLGyRANyjHGylWlLMuowniQHnHfysbsIXEFQiacatTYSFFTDjavruCM");
    int EvakVajzqkvdSt = -668030992;

    for (int YuPFQEvql = 842387039; YuPFQEvql > 0; YuPFQEvql--) {
        EvakVajzqkvdSt *= EvakVajzqkvdSt;
    }

    if (HykNbPkKSmCGSDK == -1931453674) {
        for (int PRQRDvmvWM = 657749182; PRQRDvmvWM > 0; PRQRDvmvWM--) {
            heXhmxaGbMqZOa += HykNbPkKSmCGSDK;
            MgbELMDoKqGK *= tnSgpSzRa;
            HykNbPkKSmCGSDK /= HykNbPkKSmCGSDK;
            tnSgpSzRa -= MgbELMDoKqGK;
        }
    }

    if (oaEYIhG == -1712358705) {
        for (int CfObXOjLm = 1025156507; CfObXOjLm > 0; CfObXOjLm--) {
            HykNbPkKSmCGSDK += EvakVajzqkvdSt;
            heXhmxaGbMqZOa += EvakVajzqkvdSt;
            oaEYIhG += heXhmxaGbMqZOa;
            EvakVajzqkvdSt *= tnSgpSzRa;
            heXhmxaGbMqZOa *= oaEYIhG;
        }
    }

    if (oaEYIhG > -668030992) {
        for (int eBlEgJMx = 734658156; eBlEgJMx > 0; eBlEgJMx--) {
            continue;
        }
    }

    if (HykNbPkKSmCGSDK == -668030992) {
        for (int oeVnCYTQJ = 18139979; oeVnCYTQJ > 0; oeVnCYTQJ--) {
            heXhmxaGbMqZOa = tnSgpSzRa;
            oaEYIhG *= tnSgpSzRa;
            laOTqymJFhVxcXaL = laOTqymJFhVxcXaL;
            EvakVajzqkvdSt *= heXhmxaGbMqZOa;
            heXhmxaGbMqZOa *= HykNbPkKSmCGSDK;
            MgbELMDoKqGK /= MgbELMDoKqGK;
            HykNbPkKSmCGSDK += heXhmxaGbMqZOa;
            MgbELMDoKqGK = HykNbPkKSmCGSDK;
        }
    }

    return laOTqymJFhVxcXaL;
}

EPSpfqSVU::EPSpfqSVU()
{
    this->jeocxkoLvsHEYhZ(false);
    this->JNywyrGzhpNxRcDB(false, false, -558343.5708646382, 354135.21244612045);
    this->DLtqyFyVniPOqde(-660991838, false, 458060.7690065859, 1071087362);
    this->oPKttRRz(string("xGxwpaOMFrZbRVJLwLXbsrMleyXxoBBiGOunknQTNmLOgWyjpnzOjPuwTIhyAmfckhFHRiLzwOgMPZVanttgxBwqEJcWSMYnHsJPulhJNCqXQrjauqMIYNfGcowkQcMhPCmnocnXYaOwXDVVKkeRPVYNUxfXhzynEUoiRrcjJClZFHRJRrSXbtkiHMsvaioQTWlGtcOlLHqByMDPEJAsDIsqQNwtbmogrMZRGSaqcQsX"), string("lsmetgfSWcHNTOjVZtYPmyadJSphZMOyldxcirGcRzTUerbjCcdoGkWmwqlFASd"));
    this->qhoIoocWX(string("QBglflTCrpwrZpwWhiobCxGreLbusuJqbGPExHAErcKToTaLQQvmFeEIHBUpnLhlzvWioFnJHSnpTtBJReLNDCdnclMfDQvgXfpUknUnlVlQbnAorsm"));
    this->uLwiC(true, 808100014, -1915270994, false, false);
    this->DTertuBuiS(string("KduCccBenvmwTWVBjUcMOntUaXBYR"), string("ISZlQZBhFcpuFChnOmVSQllzgJWObHFFfeQQtWPAKXFsKYxVqrcGKDjjNFhaVGUjPEfYKEugcXJUGmvnOtrrnsgZMHDXELdnQMyzELtVsfwdOJjVQwIVkDEIlBxlnqghOUiUWBGFBTyCZKbVPStX"), 1812118763);
    this->pKeeTKB(string("JMvEMdiSJugYSsciKDajYGCwHLKPOmWpLikgfPmxUMOdXWQzJwDAcGDzCAFHTNhjseDfHiEnFjshLqcwSlOqUqJLnhnNKcFSfiOTihKcresFXqFYBXaJSOVgQxzTvFASkEptIiUXvHKDhJRgTuAqbSqhdgvcevNOMlhpSIUPyykeaMbDqhlWJREqHLxntrPTGGCPeInBgnciqdPJWdOELBqZQiUHYQoTLrzQiuBGBIh"), string("dJynVRgeweBNOCkkSmMDzoBBaMdunPoUwWqFSFbKBcgSYAWonMWRHqxsmHHWcohSItxxRsDjvpcSJwjxhjQiYlCaBhzeiRAmCeqLVsrJjrWMyQop"), string("rpGjPuAnKrOjWynqNaKMdPJiPvEZARKpVdciriDPCHEaCuFdYPudxWlBcNVlSNufcOzZBshVIeWzpQSwdCtdMACGhMWVKBGgcOeRfkhVUVJGxZgSOGrMgDWhCGcAYzWEAMgGdKsWybJgEpRFxztPLukXPvkAspShpBKxZNFXhr"), string("kxihETRicJcVTdPzNBOupidXfaW"), 319762.4924104034);
    this->VHlOqzXJcaFfwjR(string("SoKKxioeuVcoZvtPapAGwQCJhbyZYgZnueNtsoijhKCNhfIEBOYnwFhkupTOQpyXhGIqUgrDrwbYpnPzoJHEnyCwHYzneUdjYuEDUmcvWKyRGPZshtFLhOaWibniIlYQTweodwStkLTNAOuikAJUvgKHWSLLNAmendlZMiTPNZoHVqWZonDmzTADHDiyxCStQUhBftECucVaNParCVObURacEaGyUVKoNSsNOHMQyPwFPYQLvczy"), true);
    this->AXjVtlnueeVrZg(1957149110, true, -278447.9518046714, false, string("wDVSZrovIlUbZfcgRTpbgsVIhRAFlXrLVE"));
    this->CklkdMuJ(283150501, -467486820, string("wgrljTwHw"), 290214.984179441);
    this->yrhsUtrDrOEnL();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LqKJHPUoQR
{
public:
    double DygVEJzJR;
    double JLdSdbKQQT;
    int oYKThPcLfIjAIk;
    int CyrkufYXIsus;

    LqKJHPUoQR();
    int oNmzWiZdalwYyH(int xkJDCuxJFv, string vxvqAKAGcD, double bFTtAaRWdDPZXcN, bool yGaIA);
    double lbSjHC(bool enRiLGkyjOB, double ymMslXuEPCOQjtCv, double MXKQgFNKJv, bool jsnDprtZnwAjvaEL);
protected:
    bool ctlcm;
    int USVVRlnAhUme;
    bool xqGAuvETWI;
    double AZvchpgbqAIfBfqK;
    double usZhR;
    bool dqegKjObSAaYkrX;

    string MwGfvQnafXToUOk();
    int NiVbWRtqB(int ULgYVJCmFsPUZCd, bool geSjNJlPWJMGoTy, int jIHYrgVoIWCkX, bool micMLKwSpF, string LfwVSewixhRp);
    void egRjpqE(int rbShfNClQnucQEdU, string IacSbmNvnB, double tYavfXfokWV, double esyujlkHe, string HpiAahLXzinCEhtv);
    int FfLjojzLjjcEU(double iNJDnXyEiRxdunx, bool qXInEpdPaGYrDRsQ);
    int rpEcy(int oNPMpZ, int DyPGXgvV, string vSGXPxOJEbhIBe);
    void HpQrPqty(double iFyAyhHizDlWjMyF);
    double DuSgcc(bool IwsvYSYPHVswSid, int gRwqtvbFDMQx, int ILzQgSY, string ZCJpWwxB, double QYzMbrvgrwjLqQ);
    void qQYDR(bool NWkQwClPhXhuWRX, string nqDhGmNfwCf, bool uFIWN, bool nIuDlDHhl, double pseAgDt);
private:
    string ZxbZjhFTVf;

};

int LqKJHPUoQR::oNmzWiZdalwYyH(int xkJDCuxJFv, string vxvqAKAGcD, double bFTtAaRWdDPZXcN, bool yGaIA)
{
    double RBaCwDArKKjoIM = -738364.4181544728;
    bool EOeBMOFoVdUPSnm = true;
    string indCfgjPkbHoM = string("lYgPgGYSqpqCVtiOrNtuzQuBracJNWohOFdnHdGbGZFRvSUublgLHMyQaKJJynJwxDCZlQvDzuVkvIMPCQfIhxjYpewgrdDxwVNPnwyWutuFnMxHpCAcEdyORSDqtFWzCqaeLPTXvmaeTERoucilWWJcycmNxTQmXRTwLmPQqKpRLrOfqY");

    for (int CdKcvpUWurzUPmGd = 784878003; CdKcvpUWurzUPmGd > 0; CdKcvpUWurzUPmGd--) {
        RBaCwDArKKjoIM -= bFTtAaRWdDPZXcN;
        EOeBMOFoVdUPSnm = ! yGaIA;
    }

    for (int YDxpVtmFLo = 1372366023; YDxpVtmFLo > 0; YDxpVtmFLo--) {
        yGaIA = yGaIA;
    }

    for (int DjItYt = 1387258094; DjItYt > 0; DjItYt--) {
        yGaIA = yGaIA;
    }

    return xkJDCuxJFv;
}

double LqKJHPUoQR::lbSjHC(bool enRiLGkyjOB, double ymMslXuEPCOQjtCv, double MXKQgFNKJv, bool jsnDprtZnwAjvaEL)
{
    double NOlcwB = 353537.1517899872;
    bool DGgmQFLbQeHO = true;
    int CMFDU = -621278913;

    return NOlcwB;
}

string LqKJHPUoQR::MwGfvQnafXToUOk()
{
    double GtzYbGsYyo = -378735.1190894725;
    double DCGhNf = -1036946.5905360566;
    bool QJfWvplkBvoi = true;
    int UDlJgyCjJxR = 525928916;
    int uWrfJNzGmYalHJ = -588537823;
    bool zTRVoJvgdeDiSXvC = true;
    string BKsiuRAQhF = string("IsspPkpyIugbWJBJoQ");

    for (int YrMOHoRsNLQ = 1112636242; YrMOHoRsNLQ > 0; YrMOHoRsNLQ--) {
        continue;
    }

    for (int megZexVoobDz = 1991954406; megZexVoobDz > 0; megZexVoobDz--) {
        zTRVoJvgdeDiSXvC = zTRVoJvgdeDiSXvC;
        DCGhNf = DCGhNf;
        GtzYbGsYyo = GtzYbGsYyo;
    }

    for (int YWXsxuGAPIsVPCj = 62271797; YWXsxuGAPIsVPCj > 0; YWXsxuGAPIsVPCj--) {
        UDlJgyCjJxR -= uWrfJNzGmYalHJ;
        BKsiuRAQhF = BKsiuRAQhF;
        DCGhNf += GtzYbGsYyo;
    }

    return BKsiuRAQhF;
}

int LqKJHPUoQR::NiVbWRtqB(int ULgYVJCmFsPUZCd, bool geSjNJlPWJMGoTy, int jIHYrgVoIWCkX, bool micMLKwSpF, string LfwVSewixhRp)
{
    bool QhWYhPh = false;
    string oXrdAQEwMKTW = string("NVjjIdkMEzelsfEtAOmzbOihQfBEyHhaxEbgoCGsNDsjMPFkopeeOWTirrwZScqEGXFKmuvOoCcJoeLmdqxuLjbzLxwPsReHTTvNtJqJaXfwlbqFbSHUtsbZXjDFEXbwGMLXwuAxSwrGACxXFJOnEu");
    int QAcsuDhJnj = -1715314127;
    string HWcHtxPWfA = string("LeYUElYyydsyeJyYzqCsPwvXSjPdmFeStOoudglHuebSNjEGSQvsNZAkNxHvGpcMLWdIoigpM");
    double LjrhNPfpXnNeTyVF = -859769.2123719385;
    string oNTpYhTecjEr = string("mIXrKGsXBLb");
    double dlGQHBnM = -849823.8147411942;
    string FvVlpySt = string("beEKdkUrFLjGGWEbuIveZAlKaIikyfUccnxpludptEfGubaHpYPelReglOHcUidxXe");

    if (FvVlpySt < string("beEKdkUrFLjGGWEbuIveZAlKaIikyfUccnxpludptEfGubaHpYPelReglOHcUidxXe")) {
        for (int nFzMjvdYGq = 1083884152; nFzMjvdYGq > 0; nFzMjvdYGq--) {
            oXrdAQEwMKTW = oXrdAQEwMKTW;
            oNTpYhTecjEr = HWcHtxPWfA;
        }
    }

    for (int npEkzcIlvIVrP = 698536515; npEkzcIlvIVrP > 0; npEkzcIlvIVrP--) {
        oNTpYhTecjEr += FvVlpySt;
    }

    if (ULgYVJCmFsPUZCd != 1219099383) {
        for (int DIqGHLxI = 2097114663; DIqGHLxI > 0; DIqGHLxI--) {
            LjrhNPfpXnNeTyVF -= LjrhNPfpXnNeTyVF;
            dlGQHBnM += dlGQHBnM;
        }
    }

    for (int pZLBEVFVXsPtaG = 975462865; pZLBEVFVXsPtaG > 0; pZLBEVFVXsPtaG--) {
        continue;
    }

    return QAcsuDhJnj;
}

void LqKJHPUoQR::egRjpqE(int rbShfNClQnucQEdU, string IacSbmNvnB, double tYavfXfokWV, double esyujlkHe, string HpiAahLXzinCEhtv)
{
    int ulEmybmwYcUBPGF = -338307177;
    string meoCgLLYvpK = string("AiYDRWAzXkTGduuZJciIAUluagJlyiQaaZXFFHwdWWYyDyZEgEDXBCowEITeBYOCLckMSJIPLsqLvGSNUzCotxGCjoOMxNbiHlmvPdzMxlTXxBgPAjZrdTORKdijFSFEeGLIpYUWBnoAgkxlNuAPGMpCRKjVlzbNxJMPSGPRTMzM");
    double oGhXUNjpy = 520941.74271569744;
    double LGpLTUpVqqq = 420439.9441459963;
    double enAfuPjOBsfq = -654800.1152452698;
    int symZKTmUE = 690099446;
    int QDSVk = -1719711795;
    string ZtmOEne = string("PWspGXAGvUIZykadgmPIyBKurebYuIEAVnxHjxCQmKQEnOpOAKqVRmNptMOhaGxasvDzWrZKruYXvEhfrQNLjwzorCl");
    int yjlCNIaSWAqrkWjR = -1378717339;

    for (int FpLnsWNaEvNLYx = 1389510895; FpLnsWNaEvNLYx > 0; FpLnsWNaEvNLYx--) {
        ulEmybmwYcUBPGF /= ulEmybmwYcUBPGF;
        rbShfNClQnucQEdU += rbShfNClQnucQEdU;
    }

    if (oGhXUNjpy != -654800.1152452698) {
        for (int xeOvNwOrcuLUkmNB = 1144715800; xeOvNwOrcuLUkmNB > 0; xeOvNwOrcuLUkmNB--) {
            symZKTmUE -= rbShfNClQnucQEdU;
        }
    }

    if (symZKTmUE == -1719711795) {
        for (int oUSKZQfC = 727952733; oUSKZQfC > 0; oUSKZQfC--) {
            oGhXUNjpy += esyujlkHe;
            QDSVk *= QDSVk;
        }
    }

    if (oGhXUNjpy != 471119.797213983) {
        for (int srpHgEQTw = 362641571; srpHgEQTw > 0; srpHgEQTw--) {
            rbShfNClQnucQEdU /= ulEmybmwYcUBPGF;
            QDSVk *= QDSVk;
            ulEmybmwYcUBPGF /= symZKTmUE;
        }
    }

    for (int qWNwSJrTptvs = 2139706504; qWNwSJrTptvs > 0; qWNwSJrTptvs--) {
        ulEmybmwYcUBPGF = rbShfNClQnucQEdU;
    }

    for (int JMMUJruTfyDVvC = 948501308; JMMUJruTfyDVvC > 0; JMMUJruTfyDVvC--) {
        IacSbmNvnB += IacSbmNvnB;
        oGhXUNjpy += LGpLTUpVqqq;
    }
}

int LqKJHPUoQR::FfLjojzLjjcEU(double iNJDnXyEiRxdunx, bool qXInEpdPaGYrDRsQ)
{
    int EEAxQwjYq = 2102383326;
    bool pMubNGxRxcNVWp = true;
    int avRQK = -1718408394;

    if (EEAxQwjYq < 2102383326) {
        for (int MVvNSHcRgnQZBEXn = 478756899; MVvNSHcRgnQZBEXn > 0; MVvNSHcRgnQZBEXn--) {
            pMubNGxRxcNVWp = ! pMubNGxRxcNVWp;
        }
    }

    for (int cwMeGHBW = 1752033359; cwMeGHBW > 0; cwMeGHBW--) {
        avRQK = avRQK;
        avRQK *= avRQK;
        qXInEpdPaGYrDRsQ = ! qXInEpdPaGYrDRsQ;
    }

    for (int qgrYHpevp = 626588637; qgrYHpevp > 0; qgrYHpevp--) {
        EEAxQwjYq = EEAxQwjYq;
    }

    return avRQK;
}

int LqKJHPUoQR::rpEcy(int oNPMpZ, int DyPGXgvV, string vSGXPxOJEbhIBe)
{
    int RJhvWgKTW = 736406241;
    int EmTGbcbEn = 1712063853;
    string JktVXQG = string("vhDircslOIYfHgQRPGPcApLdIFLCjNmwNqqDMEzYYkokJyZpwZIWtUqLDehiGzYQWbPqwQEsEsyumvuNrMbGfePECPngeZcDfysziHEEWwuIWTdiyvQSagpREKIJzZAhHvZBCPUrMfQEViveFhCXGFZWVvFReFeGwgXJscpSCVtfTrUqkURTZIocRbwuFrRmVEDYPhtukVmlKXqJeTaCNujchGuxKKuNVoCitwyxN");
    string eNFMvTFpaCcDET = string("ktdYCInMIsMOWayszGVDJoJNuKgbkxrqokTfDKZlWNHOExjdkfSzESqvBjGgpfBGbNzEVsTXHmqFBhQkhYkhjlOJBFkShwvOPveVkyuxnrefXBLPOYehPCbifhuPcSGVUWUI");
    string AoHIkZwzSKR = string("nCBfCyDyuyafBGgwsbVnojbSIEMTkrVhtxsveLFGURvUynqyVdfRnaILMjyKYpOEGgBkIfGDKJUewOgmCwLEu");
    bool iLThayjHgrJLTpv = false;
    int rYzJzBXsY = 353073281;

    return rYzJzBXsY;
}

void LqKJHPUoQR::HpQrPqty(double iFyAyhHizDlWjMyF)
{
    int MsODlWcSMt = -1746884266;
    int zqCBvSvZ = 752232236;
    double GQgfcClqsCmLQn = -782382.5598764861;

    for (int SwsbqpCyNQl = 1270702291; SwsbqpCyNQl > 0; SwsbqpCyNQl--) {
        GQgfcClqsCmLQn += iFyAyhHizDlWjMyF;
        zqCBvSvZ /= zqCBvSvZ;
        zqCBvSvZ += zqCBvSvZ;
        GQgfcClqsCmLQn = iFyAyhHizDlWjMyF;
        zqCBvSvZ -= zqCBvSvZ;
    }

    for (int KUMwjYxCO = 685084100; KUMwjYxCO > 0; KUMwjYxCO--) {
        MsODlWcSMt /= MsODlWcSMt;
        iFyAyhHizDlWjMyF -= iFyAyhHizDlWjMyF;
        zqCBvSvZ = zqCBvSvZ;
        GQgfcClqsCmLQn *= GQgfcClqsCmLQn;
    }

    for (int FUjujqsE = 156963750; FUjujqsE > 0; FUjujqsE--) {
        zqCBvSvZ += zqCBvSvZ;
        zqCBvSvZ += zqCBvSvZ;
        GQgfcClqsCmLQn *= GQgfcClqsCmLQn;
        iFyAyhHizDlWjMyF /= iFyAyhHizDlWjMyF;
        MsODlWcSMt *= zqCBvSvZ;
        zqCBvSvZ += zqCBvSvZ;
        iFyAyhHizDlWjMyF *= iFyAyhHizDlWjMyF;
        GQgfcClqsCmLQn *= GQgfcClqsCmLQn;
    }

    if (MsODlWcSMt != 752232236) {
        for (int SCaBPDINy = 2055667326; SCaBPDINy > 0; SCaBPDINy--) {
            MsODlWcSMt = MsODlWcSMt;
            iFyAyhHizDlWjMyF += GQgfcClqsCmLQn;
            iFyAyhHizDlWjMyF -= iFyAyhHizDlWjMyF;
        }
    }

    for (int GluOMa = 684747801; GluOMa > 0; GluOMa--) {
        zqCBvSvZ -= zqCBvSvZ;
        iFyAyhHizDlWjMyF *= GQgfcClqsCmLQn;
        iFyAyhHizDlWjMyF -= GQgfcClqsCmLQn;
        GQgfcClqsCmLQn = iFyAyhHizDlWjMyF;
        zqCBvSvZ = zqCBvSvZ;
    }

    if (iFyAyhHizDlWjMyF != -782382.5598764861) {
        for (int AthfmhcheaR = 1083913792; AthfmhcheaR > 0; AthfmhcheaR--) {
            continue;
        }
    }
}

double LqKJHPUoQR::DuSgcc(bool IwsvYSYPHVswSid, int gRwqtvbFDMQx, int ILzQgSY, string ZCJpWwxB, double QYzMbrvgrwjLqQ)
{
    bool twNsFAuP = false;
    double qpwzT = -1061.4645143110533;
    string ESiCQDvl = string("KcbcDrTeRmiCkhqJSjobAVAnDektVWeCcWHbwHJCEKHRryHkBqvrhXIJvBZcAsCMXBcXrxzMLnnowRNXuedZKrSBtfeSMwFUdKvlGnSgFkpFPHnLJtCASfHQBwdiPIkFOCkakMMYjovwnKRHmZqfuyMtnOXaoipnQjJcRZhkpnnHfxHdPeALedCsQzsSGsRDwiBTUXcTDRvUkbckAJhUeluInVXMPvC");
    bool rlVCMtljIWfk = false;
    bool wgQtoCYYolEMR = false;

    for (int SyYBCFkpt = 722680823; SyYBCFkpt > 0; SyYBCFkpt--) {
        IwsvYSYPHVswSid = IwsvYSYPHVswSid;
        rlVCMtljIWfk = ! wgQtoCYYolEMR;
        twNsFAuP = twNsFAuP;
    }

    return qpwzT;
}

void LqKJHPUoQR::qQYDR(bool NWkQwClPhXhuWRX, string nqDhGmNfwCf, bool uFIWN, bool nIuDlDHhl, double pseAgDt)
{
    double uFXZWQbMJxoHmUQq = 544406.5555946948;
    bool ndUbBLWxuI = true;
    int KRAWlXKAcLgkg = 2104313183;
    double aifXtsaboWhY = 241474.8419771525;
    int fIfqQw = 593783939;
    bool sXgVUCYTbSH = false;
    double pmdssAStMjRVlR = -258716.69127777623;
    double BjyGOcaWlsvZg = 272504.35784581484;
}

LqKJHPUoQR::LqKJHPUoQR()
{
    this->oNmzWiZdalwYyH(102914482, string("CiYqCeFhtKkMhRwctzqomRClabvvobnaAlRrMeOYiHZOSsSUCxgnWqQawVHwXdyACaNcYJoKLiehEtwgjLZnkoMfspWtBnBvzZTHARBnZoGHkcMbSQFpJeNrMEyyXAGaekKOMUmTdAUFgzOZvlrJUuvIacJYhbSNyAzH"), -140433.85147847922, true);
    this->lbSjHC(false, -757728.5354612699, -329129.2800355674, true);
    this->MwGfvQnafXToUOk();
    this->NiVbWRtqB(-788781242, false, 1219099383, false, string("NnuNvLkbYdbIclWBsrMnUAboHBGynGQtuAGzZgSAnQzQEaKKXZZYaMyEROlxsyQeHwbEhVxtqjHQoeLfNgIyJxLyVKyZZgkJmMpenHeRiwzqKqbCCcawZNOlmCTjTBupnFuh"));
    this->egRjpqE(1876909003, string("yvfinBDeErgIScWAZdIoZnUXoyJnhLeDNvwRgKdUUBTJgHjYrihctphOKaKYaPnpdbhGpbx"), 471119.797213983, -1043979.3781037353, string("WPPydZBbtybJGxFfcqDgGtzPplqRaDWwdmfaHHrZCbjNBkpgaryEePbyaeOuCWWuZWupaMXXwvAIspmVqmbGYTbYlymWHLuREZassUPpNHCKFRTyZggpEJYTTPwHuilBrILiZYjuqnNHkbaKYruxDOzDdbRYIXMpUQRZpmQyvwQVXpbeoexPSUdahVcACkBJnwRHpRHqEsuYCcNEKGdaggkVhwfdbSMYZCWJfIGxxSE"));
    this->FfLjojzLjjcEU(-319746.90132329596, false);
    this->rpEcy(647055650, -1230504126, string("EwSbSLemtFhjizodnxftimdBCoXuvWjFdpAynxljZxMhNxLiyGAGjtIyaDwyIinypgtWhfbgBkSHTPjXzDsfplyUVbCJspSSppZzlDZwfBzVCbNUTeRtvwEwhpCiTiuMKuOFNqcEIYJtzhptbgjKfLyJYDvInmvAV"));
    this->HpQrPqty(-769141.0066540434);
    this->DuSgcc(false, -2083955171, -559048977, string("EDhxnKkEtcdkoKuHtMZvjwfQGvzxHynxzmHMgclLEtVavcxSJWwCqVnzONntFIWJPcSfWQzdJOXaLEKsUOhjAvDOyBpdSlugEBOljbIfvRnwrcYUVtirCdaZOsidafwKPLvwetSBSrXKgPRhVytoQepMUTverruPHGYTLtRIOfcPZjuUtDomQvCMCUDfeZtkGSXpNXzEDgS"), 644826.0729622397);
    this->qQYDR(true, string("VkhluUckrEQjGgwBgccrJLUNNCYaJgldBJBvYVSHBvCyrraNYUdtlCJjqDYTFYyVeJwUivOeHhodZy"), true, true, -356605.64068780275);
}
