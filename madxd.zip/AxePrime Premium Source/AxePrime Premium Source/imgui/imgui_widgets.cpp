﻿// dear imgui, v1.69 WIP
// (widgets code)

/*

Index of this file:

// [SECTION] Forward Declarations
// [SECTION] Widgets: Text, etc.
// [SECTION] Widgets: Main (Button, Image, Checkbox, RadioButton, ProgressBar, Bullet, etc.)
// [SECTION] Widgets: Low-level Layout helpers (Spacing, Dummy, NewLine, Separator, etc.)
// [SECTION] Widgets: ComboBox
// [SECTION] Data Type and Data Formatting Helpers
// [SECTION] Widgets: DragScalar, DragFloat, DragInt, etc.
// [SECTION] Widgets: SliderScalar, SliderFloat, SliderInt, etc.
// [SECTION] Widgets: InputScalar, InputFloat, InputInt, etc.
// [SECTION] Widgets: InputText, InputTextMultiline
// [SECTION] Widgets: ColorEdit, ColorPicker, ColorButton, etc.
// [SECTION] Widgets: TreeNode, CollapsingHeader, etc.
// [SECTION] Widgets: Selectable
// [SECTION] Widgets: ListBox
// [SECTION] Widgets: PlotLines, PlotHistogram
// [SECTION] Widgets: Value helpers
// [SECTION] Widgets: MenuItem, BeginMenu, EndMenu, etc.
// [SECTION] Widgets: BeginTabBar, EndTabBar, etc.
// [SECTION] Widgets: BeginTabItem, EndTabItem, etc.

*/

#if defined(_MSC_VER) && !defined(_CRT_SECURE_NO_WARNINGS)
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "imgui.h"
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "imgui_internal.h"

#include <ctype.h>      // toupper, isprint
#if defined(_MSC_VER) && _MSC_VER <= 1500 // MSVC 2008 or earlier
#include <stddef.h>     // intptr_t
#else
#include <stdint.h>     // intptr_t
#endif

// Visual Studio warnings
#ifdef _MSC_VER
#pragma warning (disable: 4127) // condition expression is constant
#pragma warning (disable: 4996) // 'This function or variable may be unsafe': strcpy, strdup, sprintf, vsnprintf, sscanf, fopen
#endif

// Clang/GCC warnings with -Weverything
#ifdef __clang__
#pragma clang diagnostic ignored "-Wold-style-cast"         // warning : use of old-style cast                              // yes, they are more terse.
#pragma clang diagnostic ignored "-Wfloat-equal"            // warning : comparing floating point with == or != is unsafe   // storing and comparing against same constants (typically 0.0f) is ok.
#pragma clang diagnostic ignored "-Wformat-nonliteral"      // warning : format string is not a string literal              // passing non-literal to vsnformat(). yes, user passing incorrect format strings can crash the code.
#pragma clang diagnostic ignored "-Wsign-conversion"        // warning : implicit conversion changes signedness             //
#if __has_warning("-Wzero-as-null-pointer-constant")
#pragma clang diagnostic ignored "-Wzero-as-null-pointer-constant"  // warning : zero as null pointer constant              // some standard header variations use #define NULL 0
#endif
#if __has_warning("-Wdouble-promotion")
#pragma clang diagnostic ignored "-Wdouble-promotion"       // warning: implicit conversion from 'float' to 'double' when passing argument to function  // using printf() is a misery with this as C++ va_arg ellipsis changes float to double.
#endif
#elif defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wformat-nonliteral"        // warning: format not a string literal, format string not checked
#if __GNUC__ >= 8
#pragma GCC diagnostic ignored "-Wclass-memaccess"          // warning: 'memset/memcpy' clearing/writing an object of type 'xxxx' with no trivial copy-assignment; use assignment or value-initialization instead
#endif
#endif

//-------------------------------------------------------------------------
// Data
//-------------------------------------------------------------------------

// Those MIN/MAX values are not define because we need to point to them
static const ImS32  IM_S32_MIN = INT_MIN;    // (-2147483647 - 1), (0x80000000);
static const ImS32  IM_S32_MAX = INT_MAX;    // (2147483647), (0x7FFFFFFF)
static const ImU32  IM_U32_MIN = 0;
static const ImU32  IM_U32_MAX = UINT_MAX;   // (0xFFFFFFFF)
#ifdef LLONG_MIN
static const ImS64  IM_S64_MIN = LLONG_MIN;  // (-9223372036854775807ll - 1ll);
static const ImS64  IM_S64_MAX = LLONG_MAX;  // (9223372036854775807ll);
#else
static const ImS64  IM_S64_MIN = -9223372036854775807LL - 1;
static const ImS64  IM_S64_MAX = 9223372036854775807LL;
#endif
static const ImU64  IM_U64_MIN = 0;
#ifdef ULLONG_MAX
static const ImU64  IM_U64_MAX = ULLONG_MAX; // (0xFFFFFFFFFFFFFFFFull);
#else
static const ImU64  IM_U64_MAX = (2ULL * 9223372036854775807LL + 1);
#endif

//-------------------------------------------------------------------------
// [SECTION] Forward Declarations
//-------------------------------------------------------------------------


// Data Type helpers
static inline int       DataTypeFormatString(char* buf, int buf_size, ImGuiDataType data_type, const void* data_ptr, const char* format);
static void             DataTypeApplyOp(ImGuiDataType data_type, int op, void* output, void* arg_1, const void* arg_2);
static bool             DataTypeApplyOpFromText(const char* buf, const char* initial_value_buf, ImGuiDataType data_type, void* data_ptr, const char* format);

// For InputTextEx()
static bool             InputTextFilterCharacter(unsigned int* p_char, ImGuiInputTextFlags flags, ImGuiInputTextCallback callback, void* user_data);
static int              InputTextCalcTextLenAndLineCount(const char* text_begin, const char** out_text_end);
static ImVec2           InputTextCalcTextSizeW(const ImWchar* text_begin, const ImWchar* text_end, const ImWchar** remaining = NULL, ImVec2* out_offset = NULL, bool stop_on_new_line = false);

//-------------------------------------------------------------------------
// [SECTION] Widgets: Text, etc.
//-------------------------------------------------------------------------
// - TextUnformatted()
// - Text()
// - TextV()
// - TextColored()
// - TextColoredV()
// - TextDisabled()
// - TextDisabledV()
// - TextWrapped()
// - TextWrappedV()
// - LabelText()
// - LabelTextV()
// - BulletText()
// - BulletTextV()
//-------------------------------------------------------------------------

void ImGui::TextUnformatted(const char* text, const char* text_end)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    IM_ASSERT(text != NULL);
    const char* text_begin = text;
    if (text_end == NULL)
        text_end = text + strlen(text); // FIXME-OPT

    const ImVec2 text_pos(window->DC.CursorPos.x, window->DC.CursorPos.y + window->DC.CurrentLineTextBaseOffset);
    const float wrap_pos_x = window->DC.TextWrapPos;
    const bool wrap_enabled = wrap_pos_x >= 0.0f;
    if (text_end - text > 2000 && !wrap_enabled)
    {
        // Long text!
        // Perform manual coarse clipping to optimize for long multi-line text
        // - From this point we will only compute the width of lines that are visible. Optimization only available when word-wrapping is disabled.
        // - We also don't vertically center the text within the line full height, which is unlikely to matter because we are likely the biggest and only item on the line.
        // - We use memchr(), pay attention that well optimized versions of those str/mem functions are much faster than a casually written loop.
        const char* line = text;
        const float line_height = GetTextLineHeight();
        const ImRect clip_rect = window->ClipRect;
        ImVec2 text_size(0,0);

        if (text_pos.y <= clip_rect.Max.y)
        {
            ImVec2 pos = text_pos;

            // Lines to skip (can't skip when logging text)
            if (!g.LogEnabled)
            {
                int lines_skippable = (int)((clip_rect.Min.y - text_pos.y) / line_height);
                if (lines_skippable > 0)
                {
                    int lines_skipped = 0;
                    while (line < text_end && lines_skipped < lines_skippable)
                    {
                        const char* line_end = (const char*)memchr(line, '\n', text_end - line);
                        if (!line_end)
                            line_end = text_end;
                        line = line_end + 1;
                        lines_skipped++;
                    }
                    pos.y += lines_skipped * line_height;
                }
            }

            // Lines to render
            if (line < text_end)
            {
                ImRect line_rect(pos, pos + ImVec2(FLT_MAX, line_height));
                while (line < text_end)
                {
                    if (IsClippedEx(line_rect, 0, false))
                        break;

                    const char* line_end = (const char*)memchr(line, '\n', text_end - line);
                    if (!line_end)
                        line_end = text_end;
                    const ImVec2 line_size = CalcTextSize(line, line_end, false);
                    text_size.x = ImMax(text_size.x, line_size.x);
                    RenderText(pos, line, line_end, false);
                    line = line_end + 1;
                    line_rect.Min.y += line_height;
                    line_rect.Max.y += line_height;
                    pos.y += line_height;
                }

                // Count remaining lines
                int lines_skipped = 0;
                while (line < text_end)
                {
                    const char* line_end = (const char*)memchr(line, '\n', text_end - line);
                    if (!line_end)
                        line_end = text_end;
                    line = line_end + 1;
                    lines_skipped++;
                }
                pos.y += lines_skipped * line_height;
            }

            text_size.y += (pos - text_pos).y;
        }

        ImRect bb(text_pos, text_pos + text_size);
        ItemSize(text_size);
        ItemAdd(bb, 0);
    }
    else
    {
        const float wrap_width = wrap_enabled ? CalcWrapWidthForPos(window->DC.CursorPos, wrap_pos_x) : 0.0f;
        const ImVec2 text_size = CalcTextSize(text_begin, text_end, false, wrap_width);

        // Account of baseline offset
        ImRect bb(text_pos, text_pos + text_size);
        ItemSize(text_size);
        if (!ItemAdd(bb, 0))
            return;

        // Render (we don't hide text after ## in this end-user function)
        RenderTextWrapped(bb.Min, text_begin, text_end, wrap_width);
    }
}

void ImGui::Text(const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    TextV(fmt, args);
    va_end(args);
}

void ImGui::TextV(const char* fmt, va_list args)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const char* text_end = g.TempBuffer + ImFormatStringV(g.TempBuffer, IM_ARRAYSIZE(g.TempBuffer), fmt, args);
    TextUnformatted(g.TempBuffer, text_end);
}

void ImGui::TextColored(const ImVec4& col, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    TextColoredV(col, fmt, args);
    va_end(args);
}

void ImGui::TextColoredV(const ImVec4& col, const char* fmt, va_list args)
{
    PushStyleColor(ImGuiCol_Text, col);
    TextV(fmt, args);
    PopStyleColor();
}

void ImGui::TextDisabled(const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    TextDisabledV(fmt, args);
    va_end(args);
}

void ImGui::TextDisabledV(const char* fmt, va_list args)
{
    PushStyleColor(ImGuiCol_Text, GImGui->Style.Colors[ImGuiCol_TextDisabled]);
    TextV(fmt, args);
    PopStyleColor();
}

void ImGui::TextWrapped(const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    TextWrappedV(fmt, args);
    va_end(args);
}

void ImGui::TextWrappedV(const char* fmt, va_list args)
{
    bool need_backup = (GImGui->CurrentWindow->DC.TextWrapPos < 0.0f);  // Keep existing wrap position if one is already set
    if (need_backup)
        PushTextWrapPos(0.0f);
    TextV(fmt, args);
    if (need_backup)
        PopTextWrapPos();
}

void ImGui::LabelText(const char* label, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    LabelTextV(label, fmt, args);
    va_end(args);
}

// Add a label+text combo aligned to other label+value widgets
void ImGui::LabelTextV(const char* label, const char* fmt, va_list args)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const float w = CalcItemWidth();

    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    const ImRect value_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(w, label_size.y + style.FramePadding.y*2));
    const ImRect total_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(w + (label_size.x > 0.0f ? style.ItemInnerSpacing.x : 0.0f), style.FramePadding.y*2) + label_size);
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, 0))
        return;

    // Render
    const char* value_text_begin = &g.TempBuffer[0];
    const char* value_text_end = value_text_begin + ImFormatStringV(g.TempBuffer, IM_ARRAYSIZE(g.TempBuffer), fmt, args);
    RenderTextClipped(value_bb.Min, value_bb.Max, value_text_begin, value_text_end, NULL, ImVec2(0.0f,0.5f));
    if (label_size.x > 0.0f)
        RenderText(ImVec2(value_bb.Max.x + style.ItemInnerSpacing.x, value_bb.Min.y + style.FramePadding.y), label);
}

void ImGui::BulletText(const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    BulletTextV(fmt, args);
    va_end(args);
}

// Text with a little bullet aligned to the typical tree node.
void ImGui::BulletTextV(const char* fmt, va_list args)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    const char* text_begin = g.TempBuffer;
    const char* text_end = text_begin + ImFormatStringV(g.TempBuffer, IM_ARRAYSIZE(g.TempBuffer), fmt, args);
    const ImVec2 label_size = CalcTextSize(text_begin, text_end, false);
    const float text_base_offset_y = ImMax(0.0f, window->DC.CurrentLineTextBaseOffset); // Latch before ItemSize changes it
    const float line_height = ImMax(ImMin(window->DC.CurrentLineSize.y, g.FontSize + g.Style.FramePadding.y*2), g.FontSize);
    const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(g.FontSize + (label_size.x > 0.0f ? (label_size.x + style.FramePadding.x*2) : 0.0f), ImMax(line_height, label_size.y)));  // Empty text doesn't add padding
    ItemSize(bb);
    if (!ItemAdd(bb, 0))
        return;

    // Render
    RenderBullet(bb.Min + ImVec2(style.FramePadding.x + g.FontSize*0.5f, line_height*0.5f));
    RenderText(bb.Min+ImVec2(g.FontSize + style.FramePadding.x*2, text_base_offset_y), text_begin, text_end, false);
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: Main
//-------------------------------------------------------------------------
// - ButtonBehavior() [Internal]
// - Button()
// - SmallButton()
// - InvisibleButton()
// - ArrowButton()
// - CloseButton() [Internal]
// - CollapseButton() [Internal]
// - Scrollbar() [Internal]
// - Image()
// - ImageButton()
// - Checkbox()
// - CheckboxFlags()
// - RadioButton()
// - ProgressBar()
// - Bullet()
//-------------------------------------------------------------------------

bool ImGui::ButtonBehavior(const ImRect& bb, ImGuiID id, bool* out_hovered, bool* out_held, ImGuiButtonFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();

    if (flags & ImGuiButtonFlags_Disabled)
    {
        if (out_hovered) *out_hovered = false;
        if (out_held) *out_held = false;
        if (g.ActiveId == id) ClearActiveID();
        return false;
    }

    // Default behavior requires click+release on same spot
    if ((flags & (ImGuiButtonFlags_PressedOnClickRelease | ImGuiButtonFlags_PressedOnClick | ImGuiButtonFlags_PressedOnRelease | ImGuiButtonFlags_PressedOnDoubleClick)) == 0)
        flags |= ImGuiButtonFlags_PressedOnClickRelease;

    ImGuiWindow* backup_hovered_window = g.HoveredWindow;
    if ((flags & ImGuiButtonFlags_FlattenChildren) && g.HoveredRootWindow == window)
        g.HoveredWindow = window;

#ifdef IMGUI_ENABLE_TEST_ENGINE
    if (id != 0 && window->DC.LastItemId != id)
        ImGuiTestEngineHook_ItemAdd(&g, bb, id);
#endif

    bool pressed = false;
    bool hovered = ItemHoverable(bb, id);

    // Drag source doesn't report as hovered
    if (hovered && g.DragDropActive && g.DragDropPayload.SourceId == id && !(g.DragDropSourceFlags & ImGuiDragDropFlags_SourceNoDisableHover))
        hovered = false;

    // Special mode for Drag and Drop where holding button pressed for a long time while dragging another item triggers the button
    if (g.DragDropActive && (flags & ImGuiButtonFlags_PressedOnDragDropHold) && !(g.DragDropSourceFlags & ImGuiDragDropFlags_SourceNoHoldToOpenOthers))
        if (IsItemHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem))
        {
            hovered = true;
            SetHoveredID(id);
            if (CalcTypematicPressedRepeatAmount(g.HoveredIdTimer + 0.0001f, g.HoveredIdTimer + 0.0001f - g.IO.DeltaTime, 0.01f, 0.70f)) // FIXME: Our formula for CalcTypematicPressedRepeatAmount() is fishy
            {
                pressed = true;
                FocusWindow(window);
            }
        }

    if ((flags & ImGuiButtonFlags_FlattenChildren) && g.HoveredRootWindow == window)
        g.HoveredWindow = backup_hovered_window;

    // AllowOverlap mode (rarely used) requires previous frame HoveredId to be null or to match. This allows using patterns where a later submitted widget overlaps a previous one.
    if (hovered && (flags & ImGuiButtonFlags_AllowItemOverlap) && (g.HoveredIdPreviousFrame != id && g.HoveredIdPreviousFrame != 0))
        hovered = false;

    // Mouse
    if (hovered)
    {
        if (!(flags & ImGuiButtonFlags_NoKeyModifiers) || (!g.IO.KeyCtrl && !g.IO.KeyShift && !g.IO.KeyAlt))
        {
            //                        | CLICKING        | HOLDING with ImGuiButtonFlags_Repeat
            // PressedOnClickRelease  |  <on release>*  |  <on repeat> <on repeat> .. (NOT on release)  <-- MOST COMMON! (*) only if both click/release were over bounds
            // PressedOnClick         |  <on click>     |  <on click> <on repeat> <on repeat> ..
            // PressedOnRelease       |  <on release>   |  <on repeat> <on repeat> .. (NOT on release)
            // PressedOnDoubleClick   |  <on dclick>    |  <on dclick> <on repeat> <on repeat> ..
            // FIXME-NAV: We don't honor those different behaviors.
            if ((flags & ImGuiButtonFlags_PressedOnClickRelease) && g.IO.MouseClicked[0])
            {
                SetActiveID(id, window);
                if (!(flags & ImGuiButtonFlags_NoNavFocus))
                    SetFocusID(id, window);
                FocusWindow(window);
            }
            if (((flags & ImGuiButtonFlags_PressedOnClick) && g.IO.MouseClicked[0]) || ((flags & ImGuiButtonFlags_PressedOnDoubleClick) && g.IO.MouseDoubleClicked[0]))
            {
                pressed = true;
                if (flags & ImGuiButtonFlags_NoHoldingActiveID)
                    ClearActiveID();
                else
                    SetActiveID(id, window); // Hold on ID
                FocusWindow(window);
            }
            if ((flags & ImGuiButtonFlags_PressedOnRelease) && g.IO.MouseReleased[0])
            {
                if (!((flags & ImGuiButtonFlags_Repeat) && g.IO.MouseDownDurationPrev[0] >= g.IO.KeyRepeatDelay))  // Repeat mode trumps <on release>
                    pressed = true;
                ClearActiveID();
            }

            // 'Repeat' mode acts when held regardless of _PressedOn flags (see table above).
            // Relies on repeat logic of IsMouseClicked() but we may as well do it ourselves if we end up exposing finer RepeatDelay/RepeatRate settings.
            if ((flags & ImGuiButtonFlags_Repeat) && g.ActiveId == id && g.IO.MouseDownDuration[0] > 0.0f && IsMouseClicked(0, true))
                pressed = true;
        }

        if (pressed)
            g.NavDisableHighlight = true;
    }

    // Gamepad/Keyboard navigation
    // We report navigated item as hovered but we don't set g.HoveredId to not interfere with mouse.
    if (g.NavId == id && !g.NavDisableHighlight && g.NavDisableMouseHover && (g.ActiveId == 0 || g.ActiveId == id || g.ActiveId == window->MoveId))
        hovered = true;

    if (g.NavActivateDownId == id)
    {
        bool nav_activated_by_code = (g.NavActivateId == id);
        bool nav_activated_by_inputs = IsNavInputPressed(ImGuiNavInput_Activate, (flags & ImGuiButtonFlags_Repeat) ? ImGuiInputReadMode_Repeat : ImGuiInputReadMode_Pressed);
        if (nav_activated_by_code || nav_activated_by_inputs)
            pressed = true;
        if (nav_activated_by_code || nav_activated_by_inputs || g.ActiveId == id)
        {
            // Set active id so it can be queried by user via IsItemActive(), equivalent of holding the mouse button.
            g.NavActivateId = id; // This is so SetActiveId assign a Nav source
            SetActiveID(id, window);
            if ((nav_activated_by_code || nav_activated_by_inputs) && !(flags & ImGuiButtonFlags_NoNavFocus))
                SetFocusID(id, window);
            g.ActiveIdAllowNavDirFlags = (1 << ImGuiDir_Left) | (1 << ImGuiDir_Right) | (1 << ImGuiDir_Up) | (1 << ImGuiDir_Down);
        }
    }

    bool held = false;
    if (g.ActiveId == id)
    {
        if (pressed)
            g.ActiveIdHasBeenPressed = true;
        if (g.ActiveIdSource == ImGuiInputSource_Mouse)
        {
            if (g.ActiveIdIsJustActivated)
                g.ActiveIdClickOffset = g.IO.MousePos - bb.Min;
            if (g.IO.MouseDown[0])
            {
                held = true;
            }
            else
            {
                if (hovered && (flags & ImGuiButtonFlags_PressedOnClickRelease))
                    if (!((flags & ImGuiButtonFlags_Repeat) && g.IO.MouseDownDurationPrev[0] >= g.IO.KeyRepeatDelay))  // Repeat mode trumps <on release>
                        if (!g.DragDropActive)
                            pressed = true;
                ClearActiveID();
            }
            if (!(flags & ImGuiButtonFlags_NoNavFocus))
                g.NavDisableHighlight = true;
        }
        else if (g.ActiveIdSource == ImGuiInputSource_Nav)
        {
            if (g.NavActivateDownId != id)
                ClearActiveID();
        }
    }

    if (out_hovered) *out_hovered = hovered;
    if (out_held) *out_held = held;

    return pressed;
}

bool ImGui::ButtonEx(const char* label, const ImVec2& size_arg, ImGuiButtonFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = CalcTextSize(label, NULL, true);

    ImVec2 pos = window->DC.CursorPos;
    if ((flags & ImGuiButtonFlags_AlignTextBaseLine) && style.FramePadding.y < window->DC.CurrentLineTextBaseOffset) // Try to vertically align buttons that are smaller/have no padding so that text baseline matches (bit hacky, since it shouldn't be a flag)
        pos.y += window->DC.CurrentLineTextBaseOffset - style.FramePadding.y;
    ImVec2 size = CalcItemSize(size_arg, label_size.x + style.FramePadding.x * 2.0f, label_size.y + style.FramePadding.y * 2.0f);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id))
        return false;

    if (window->DC.ItemFlags & ImGuiItemFlags_ButtonRepeat)
        flags |= ImGuiButtonFlags_Repeat;
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held, flags);
    if (pressed)
        MarkItemEdited(id);

    // Render
    const ImU32 col = GetColorU32((held && hovered) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    RenderNavHighlight(bb, id);
    RenderFrame(bb.Min, bb.Max, col, true, style.FrameRounding);
    RenderTextClipped(bb.Min + style.FramePadding, bb.Max - style.FramePadding, label, NULL, &label_size, style.ButtonTextAlign, &bb);

    // Automatically close popups
    //if (pressed && !(flags & ImGuiButtonFlags_DontClosePopups) && (window->Flags & ImGuiWindowFlags_Popup))
    //    CloseCurrentPopup();

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, window->DC.LastItemStatusFlags);
    return pressed;
}

bool ImGui::Button(const char* label, const ImVec2& size_arg)
{
    return ButtonEx(label, size_arg, 0);
}

// Small buttons fits within text without additional vertical spacing.
bool ImGui::SmallButton(const char* label)
{
    ImGuiContext& g = *GImGui;
    float backup_padding_y = g.Style.FramePadding.y;
    g.Style.FramePadding.y = 0.0f;
    bool pressed = ButtonEx(label, ImVec2(0, 0), ImGuiButtonFlags_AlignTextBaseLine);
    g.Style.FramePadding.y = backup_padding_y;
    return pressed;
}

// Tip: use ImGui::PushID()/PopID() to push indices or pointers in the ID stack.
// Then you can keep 'str_id' empty or the same for all your buttons (instead of creating a string based on a non-string id)
bool ImGui::InvisibleButton(const char* str_id, const ImVec2& size_arg)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    // Cannot use zero-size for InvisibleButton(). Unlike Button() there is not way to fallback using the label size.
    IM_ASSERT(size_arg.x != 0.0f && size_arg.y != 0.0f);

    const ImGuiID id = window->GetID(str_id);
    ImVec2 size = CalcItemSize(size_arg, 0.0f, 0.0f);
    const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + size);
    ItemSize(size);
    if (!ItemAdd(bb, id))
        return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);

    return pressed;
}

bool ImGui::ArrowButtonEx(const char* str_id, ImGuiDir dir, ImVec2 size, ImGuiButtonFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(str_id);
    const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + size);
    const float default_size = GetFrameHeight();
    ItemSize(bb, (size.y >= default_size) ? g.Style.FramePadding.y : 0.0f);
    if (!ItemAdd(bb, id))
        return false;

    if (window->DC.ItemFlags & ImGuiItemFlags_ButtonRepeat)
        flags |= ImGuiButtonFlags_Repeat;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held, flags);

    // Render
    const ImU32 col = GetColorU32((held && hovered) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    RenderNavHighlight(bb, id);
    RenderFrame(bb.Min, bb.Max, col, true, g.Style.FrameRounding);
    RenderArrow(bb.Min + ImVec2(ImMax(0.0f, (size.x - g.FontSize) * 0.5f), ImMax(0.0f, (size.y - g.FontSize) * 0.5f)), dir);

    return pressed;
}

bool ImGui::ArrowButton(const char* str_id, ImGuiDir dir)
{
    float sz = GetFrameHeight();
    return ArrowButtonEx(str_id, dir, ImVec2(sz, sz), 0);
}

// Button to close a window
bool ImGui::CloseButton(ImGuiID id, const ImVec2& pos, float radius)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    // We intentionally allow interaction when clipped so that a mechanical Alt,Right,Validate sequence close a window.
    // (this isn't the regular behavior of buttons, but it doesn't affect the user much because navigation tends to keep items visible).
    const ImRect bb(pos - ImVec2(radius,radius), pos + ImVec2(radius,radius));
    bool is_clipped = !ItemAdd(bb, id);

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);
    if (is_clipped)
        return pressed;

    // Render
    ImVec2 center = bb.GetCenter();
    if (hovered)
        window->DrawList->AddCircleFilled(center, ImMax(2.0f, radius), GetColorU32(held ? ImGuiCol_ButtonActive : ImGuiCol_ButtonHovered), 9);

    float cross_extent = (radius * 0.7071f) - 1.0f;
    ImU32 cross_col = GetColorU32(ImGuiCol_Text);
    center -= ImVec2(0.5f, 0.5f);
    window->DrawList->AddLine(center + ImVec2(+cross_extent,+cross_extent), center + ImVec2(-cross_extent,-cross_extent), cross_col, 1.0f);
    window->DrawList->AddLine(center + ImVec2(+cross_extent,-cross_extent), center + ImVec2(-cross_extent,+cross_extent), cross_col, 1.0f);

    return pressed;
}

bool ImGui::CollapseButton(ImGuiID id, const ImVec2& pos)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    ImRect bb(pos, pos + ImVec2(g.FontSize, g.FontSize) + g.Style.FramePadding * 2.0f);
    ItemAdd(bb, id);
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held, ImGuiButtonFlags_None);

    ImU32 col = GetColorU32((held && hovered) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    if (hovered || held)
        window->DrawList->AddCircleFilled(bb.GetCenter() + ImVec2(0.0f, -0.5f), g.FontSize * 0.5f + 1.0f, col, 9);
    RenderArrow(bb.Min + g.Style.FramePadding, window->Collapsed ? ImGuiDir_Right : ImGuiDir_Down, 1.0f);

    // Switch to moving the window after mouse is moved beyond the initial drag threshold
    if (IsItemActive() && IsMouseDragging())
        StartMouseMovingWindow(window);

    return pressed;
}

ImGuiID ImGui::GetScrollbarID(ImGuiWindow* window, ImGuiAxis axis)
{
    return window->GetIDNoKeepAlive(axis == ImGuiAxis_X ? "#SCROLLX" : "#SCROLLY");
}

// Vertical/Horizontal scrollbar
// The entire piece of code below is rather confusing because:
// - We handle absolute seeking (when first clicking outside the grab) and relative manipulation (afterward or when clicking inside the grab)
// - We store values as normalized ratio and in a form that allows the window content to change while we are holding on a scrollbar
// - We handle both horizontal and vertical scrollbars, which makes the terminology not ideal.
void ImGui::Scrollbar(ImGuiAxis axis)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    const bool horizontal = (axis == ImGuiAxis_X);
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = GetScrollbarID(window, axis);
    KeepAliveID(id);

    // Render background
    bool other_scrollbar = (horizontal ? window->ScrollbarY : window->ScrollbarX);
    float other_scrollbar_size_w = other_scrollbar ? style.ScrollbarSize : 0.0f;
    const ImRect window_rect = window->Rect();
    const float border_size = window->WindowBorderSize;
    ImRect bb = horizontal
        ? ImRect(window->Pos.x + border_size, window_rect.Max.y - style.ScrollbarSize, window_rect.Max.x - other_scrollbar_size_w - border_size, window_rect.Max.y - border_size)
        : ImRect(window_rect.Max.x - style.ScrollbarSize, window->Pos.y + border_size, window_rect.Max.x - border_size, window_rect.Max.y - other_scrollbar_size_w - border_size);
    if (!horizontal)
        bb.Min.y += window->TitleBarHeight() + ((window->Flags & ImGuiWindowFlags_MenuBar) ? window->MenuBarHeight() : 0.0f);

    const float bb_height = bb.GetHeight();
    if (bb.GetWidth() <= 0.0f || bb_height <= 0.0f)
        return;

    // When we are too small, start hiding and disabling the grab (this reduce visual noise on very small window and facilitate using the resize grab)
    float alpha = 1.0f;
    if ((axis == ImGuiAxis_Y) && bb_height < g.FontSize + g.Style.FramePadding.y * 2.0f)
    {
        alpha = ImSaturate((bb_height - g.FontSize) / (g.Style.FramePadding.y * 2.0f));
        if (alpha <= 0.0f)
            return;
    }
    const bool allow_interaction = (alpha >= 1.0f);

    int window_rounding_corners;
    if (horizontal)
        window_rounding_corners = ImDrawCornerFlags_BotLeft | (other_scrollbar ? 0 : ImDrawCornerFlags_BotRight);
    else
        window_rounding_corners = (((window->Flags & ImGuiWindowFlags_NoTitleBar) && !(window->Flags & ImGuiWindowFlags_MenuBar)) ? ImDrawCornerFlags_TopRight : 0) | (other_scrollbar ? 0 : ImDrawCornerFlags_BotRight);
    window->DrawList->AddRectFilled(bb.Min, bb.Max, GetColorU32(ImGuiCol_ScrollbarBg), window->WindowRounding, window_rounding_corners);
    bb.Expand(ImVec2(-ImClamp((float)(int)((bb.Max.x - bb.Min.x - 2.0f) * 0.5f), 0.0f, 3.0f), -ImClamp((float)(int)((bb.Max.y - bb.Min.y - 2.0f) * 0.5f), 0.0f, 3.0f)));

    // V denote the main, longer axis of the scrollbar (= height for a vertical scrollbar)
    float scrollbar_size_v = horizontal ? bb.GetWidth() : bb.GetHeight();
    float scroll_v = horizontal ? window->Scroll.x : window->Scroll.y;
    float win_size_avail_v = (horizontal ? window->SizeFull.x : window->SizeFull.y) - other_scrollbar_size_w;
    float win_size_contents_v = horizontal ? window->SizeContents.x : window->SizeContents.y;

    // Calculate the height of our grabbable box. It generally represent the amount visible (vs the total scrollable amount)
    // But we maintain a minimum size in pixel to allow for the user to still aim inside.
    IM_ASSERT(ImMax(win_size_contents_v, win_size_avail_v) > 0.0f); // Adding this assert to check if the ImMax(XXX,1.0f) is still needed. PLEASE CONTACT ME if this triggers.
    const float win_size_v = ImMax(ImMax(win_size_contents_v, win_size_avail_v), 1.0f);
    const float grab_h_pixels = ImClamp(scrollbar_size_v * (win_size_avail_v / win_size_v), style.GrabMinSize, scrollbar_size_v);
    const float grab_h_norm = grab_h_pixels / scrollbar_size_v;

    // Handle input right away. None of the code of Begin() is relying on scrolling position before calling Scrollbar().
    bool held = false;
    bool hovered = false;
    const bool previously_held = (g.ActiveId == id);
    ButtonBehavior(bb, id, &hovered, &held, ImGuiButtonFlags_NoNavFocus);

    float scroll_max = ImMax(1.0f, win_size_contents_v - win_size_avail_v);
    float scroll_ratio = ImSaturate(scroll_v / scroll_max);
    float grab_v_norm = scroll_ratio * (scrollbar_size_v - grab_h_pixels) / scrollbar_size_v;
    if (held && allow_interaction && grab_h_norm < 1.0f)
    {
        float scrollbar_pos_v = horizontal ? bb.Min.x : bb.Min.y;
        float mouse_pos_v = horizontal ? g.IO.MousePos.x : g.IO.MousePos.y;
        float* click_delta_to_grab_center_v = horizontal ? &g.ScrollbarClickDeltaToGrabCenter.x : &g.ScrollbarClickDeltaToGrabCenter.y;

        // Click position in scrollbar normalized space (0.0f->1.0f)
        const float clicked_v_norm = ImSaturate((mouse_pos_v - scrollbar_pos_v) / scrollbar_size_v);
        SetHoveredID(id);

        bool seek_absolute = false;
        if (!previously_held)
        {
            // On initial click calculate the distance between mouse and the center of the grab
            if (clicked_v_norm >= grab_v_norm && clicked_v_norm <= grab_v_norm + grab_h_norm)
            {
                *click_delta_to_grab_center_v = clicked_v_norm - grab_v_norm - grab_h_norm*0.5f;
            }
            else
            {
                seek_absolute = true;
                *click_delta_to_grab_center_v = 0.0f;
            }
        }

        // Apply scroll
        // It is ok to modify Scroll here because we are being called in Begin() after the calculation of SizeContents and before setting up our starting position
        const float scroll_v_norm = ImSaturate((clicked_v_norm - *click_delta_to_grab_center_v - grab_h_norm*0.5f) / (1.0f - grab_h_norm));
        scroll_v = (float)(int)(0.5f + scroll_v_norm * scroll_max);//(win_size_contents_v - win_size_v));
        if (horizontal)
            window->Scroll.x = scroll_v;
        else
            window->Scroll.y = scroll_v;

        // Update values for rendering
        scroll_ratio = ImSaturate(scroll_v / scroll_max);
        grab_v_norm = scroll_ratio * (scrollbar_size_v - grab_h_pixels) / scrollbar_size_v;

        // Update distance to grab now that we have seeked and saturated
        if (seek_absolute)
            *click_delta_to_grab_center_v = clicked_v_norm - grab_v_norm - grab_h_norm*0.5f;
    }

    // Render grab
    const ImU32 grab_col = GetColorU32(held ? ImGuiCol_ScrollbarGrabActive : hovered ? ImGuiCol_ScrollbarGrabHovered : ImGuiCol_ScrollbarGrab, alpha);
    ImRect grab_rect;
    if (horizontal)
        grab_rect = ImRect(ImLerp(bb.Min.x, bb.Max.x, grab_v_norm), bb.Min.y, ImMin(ImLerp(bb.Min.x, bb.Max.x, grab_v_norm) + grab_h_pixels, window_rect.Max.x), bb.Max.y);
    else
        grab_rect = ImRect(bb.Min.x, ImLerp(bb.Min.y, bb.Max.y, grab_v_norm), bb.Max.x, ImMin(ImLerp(bb.Min.y, bb.Max.y, grab_v_norm) + grab_h_pixels, window_rect.Max.y));
    window->DrawList->AddRectFilled(grab_rect.Min, grab_rect.Max, grab_col, style.ScrollbarRounding);
}

void ImGui::Image(ImTextureID user_texture_id, const ImVec2& size, const ImVec2& uv0, const ImVec2& uv1, const ImVec4& tint_col, const ImVec4& border_col)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImRect bb(window->DC.CursorPos, window->DC.CursorPos + size);
    if (border_col.w > 0.0f)
        bb.Max += ImVec2(2, 2);
    ItemSize(bb);
    if (!ItemAdd(bb, 0))
        return;

    if (border_col.w > 0.0f)
    {
        window->DrawList->AddRect(bb.Min, bb.Max, GetColorU32(border_col), 0.0f);
        window->DrawList->AddImage(user_texture_id, bb.Min + ImVec2(1, 1), bb.Max - ImVec2(1, 1), uv0, uv1, GetColorU32(tint_col));
    }
    else
    {
        window->DrawList->AddImage(user_texture_id, bb.Min, bb.Max, uv0, uv1, GetColorU32(tint_col));
    }
}

// frame_padding < 0: uses FramePadding from style (default)
// frame_padding = 0: no framing
// frame_padding > 0: set framing size
// The color used are the button colors.

bool ImGui::OwOButtonXD(const char* label, const ImVec2& size_arg, bool inuse, ImGuiButtonFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = CalcTextSize(label, NULL, true);

    ImVec2 pos = window->DC.CursorPos;
    if ((flags & ImGuiButtonFlags_AlignTextBaseLine) && style.FramePadding.y < window->DC.CurrentLineTextBaseOffset) // Try to vertically align buttons that are smaller/have no padding so that text baseline matches (bit hacky, since it shouldn't be a flag)
        pos.y += window->DC.CurrentLineTextBaseOffset - style.FramePadding.y;
    ImVec2 size = CalcItemSize(size_arg, label_size.x + style.FramePadding.x * 2.0f, label_size.y + style.FramePadding.y * 2.0f);


    const ImRect bb(pos, pos + size);
    ItemSize(bb, style.FramePadding.y);
    if (!ItemAdd(bb, id))
        return false;

    if (window->DC.ItemFlags & ImGuiItemFlags_ButtonRepeat) flags |= ImGuiButtonFlags_Repeat;
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held, flags);

    // Render
    const ImU32 col = GetColorU32((hovered && held) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    //RenderFrame(bb.Min, bb.Max, col, true, style.FrameRounding);


    auto turuncu = ImColor(0, 85, 255);
    auto koyuturuncu = ImColor(117, 117, 117);
    if (inuse)
    {

        window->DrawList->AddRectFilledMultiColor(ImVec2(bb.Min.x, bb.Max.y - 2), ImVec2(bb.Max.x, bb.Max.y - 0), turuncu, koyuturuncu, turuncu, koyuturuncu);

    }
    else
    {
        window->DrawList->AddRectFilledMultiColor(ImVec2(bb.Min.x, bb.Max.y - 2), ImVec2(bb.Max.x, bb.Max.y - 0), koyuturuncu, turuncu, koyuturuncu, turuncu);
    }

    RenderTextClipped(bb.Min + style.FramePadding, bb.Max - style.FramePadding, label, NULL, &label_size, style.ButtonTextAlign, &bb);

    // Automatically close popups
    //if (pressed && !(flags & ImGuiButtonFlags_DontClosePopups) && (window->Flags & ImGuiWindowFlags_Popup))
    //    CloseCurrentPopup();

    return pressed;
}
bool ImGui::OwOButton(const char* label, bool inuse, const ImVec2& size_arg)
{
    return OwOButtonXD(label, size_arg, inuse, 0);
}

bool ImGui::ImageButton(ImTextureID user_texture_id, const ImVec2& size, const ImVec2& uv0, const ImVec2& uv1, int frame_padding, const ImVec4& bg_col, const ImVec4& tint_col)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    // Default to using texture ID as ID. User can still push string/integer prefixes.
    // We could hash the size/uv to create a unique ID but that would prevent the user from animating UV.
    PushID((void*)(intptr_t)user_texture_id);
    const ImGuiID id = window->GetID("#image");
    PopID();

    const ImVec2 padding = (frame_padding >= 0) ? ImVec2((float)frame_padding, (float)frame_padding) : style.FramePadding;
    const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + size + padding * 2);
    const ImRect image_bb(window->DC.CursorPos + padding, window->DC.CursorPos + padding + size);
    ItemSize(bb);
    if (!ItemAdd(bb, id))
        return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);

    // Render
    const ImU32 col = GetColorU32((held && hovered) ? ImGuiCol_ButtonActive : hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    RenderNavHighlight(bb, id);
    RenderFrame(bb.Min, bb.Max, col, true, ImClamp((float)ImMin(padding.x, padding.y), 0.0f, style.FrameRounding));
    if (bg_col.w > 0.0f)
        window->DrawList->AddRectFilled(image_bb.Min, image_bb.Max, GetColorU32(bg_col));
    window->DrawList->AddImage(user_texture_id, image_bb.Min, image_bb.Max, uv0, uv1, GetColorU32(tint_col));

    return pressed;
}

bool ImGui::Checkbox(const char* label, bool* v)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;
    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = ImGuiStyle::ImGuiStyle();
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    const ImVec2 pading = ImVec2(2, 2);
    const ImRect check_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(label_size.y + style.FramePadding.x * 6, label_size.y + style.FramePadding.y / 2));
    ItemSize(check_bb, style.FramePadding.y);
    ImRect total_bb = check_bb;
    if (label_size.x > 0)
        SameLine(0, style.ItemInnerSpacing.x);
    const ImRect text_bb(window->DC.CursorPos + ImVec2(0, style.FramePadding.y), window->DC.CursorPos + ImVec2(0, style.FramePadding.y) + label_size);
    if (label_size.x > 0)
    {
        ItemSize(ImVec2(text_bb.GetWidth(), check_bb.GetHeight()), style.FramePadding.y);
        total_bb = ImRect(ImMin(check_bb.Min, text_bb.Min), ImMax(check_bb.Max, text_bb.Max));
    }
    if (!ItemAdd(total_bb, id))
        return false;
    bool hovered, held;
    bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed)
        *v = !(*v);
    const float check_sz = ImMin(check_bb.GetWidth(), check_bb.GetHeight());
    const float check_sz2 = check_sz / 2;
    const float pad = ImMax(1.0f, (float)(int)(check_sz / 4.f));
    //window->DrawList->AddRectFilled(check_bb.Min+ImVec2(pad,pad), check_bb.Max-ImVec2(pad,pad), GetColorU32(ImGuiCol_CheckMark), style.FrameRounding);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 6, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 5, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 4, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 3, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 2, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 1, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 1, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 2, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 3, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 4, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 5, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 0.0f, 0.0f, 1.0f)), 12);
    window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 6, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 1.0f)), 12);
    if (*v)//от исовка галочки
    {
        //window->DrawList->AddRectFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2, check_bb.Min.y), check_bb.Max, GetColorU32(ImVec4(0.34f, 1.0f, 0.54f, 1.0f)), 0);
        //window->DrawList->AddRectFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2, check_bb.Min.y), check_bb.Max, GetColorU32(ImVec4(0.34f, 1.0f, 0.54f, 1.0f)), 0);

        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 5, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 4, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 3, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 2, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 1, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 1, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 2, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 3, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 4, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 5, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 6, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(0.50f, 0.00f, 1.00f, 1.00f)), 12);
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 + 6, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 1.0f)), 12);
    }
    else
    {
        window->DrawList->AddCircleFilled(ImVec2(check_bb.Min.x + (check_bb.Max.x - check_bb.Min.x) / 2 - 6, check_bb.Min.y + 9), 7, GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 1.0f)), 12);
    }
    if (label_size.x > 0.0f)
        RenderText(text_bb.GetTL(), label);
    return pressed;
}

void ImGui::NewCheckbox(const char* str_id, bool* v)
{
    ImGuiWindow* window = GetCurrentWindow();
    const ImGuiStyle& style = ImGuiStyle::ImGuiStyle();
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    const ImVec2 label_size = CalcTextSize(str_id, NULL, true);
    const ImRect text_bb(window->DC.CursorPos + ImVec2(0, style.FramePadding.y), window->DC.CursorPos + ImVec2(0, style.FramePadding.y) + label_size);

    float height = ImGui::GetFrameHeight();
    float width = height * 1.55f;
    float radius = height * 0.50f;

    ImGui::InvisibleButton(str_id, ImVec2(width, height));
    if (ImGui::IsItemClicked())
        *v = !*v;

    float t = *v ? 1.0f : 0.0f;

    ImGuiContext& g = *GImGui;
    float ANIM_SPEED = 0.08f;
    if (g.LastActiveId == g.CurrentWindow->GetID(str_id))// && g.LastActiveIdTimer < ANIM_SPEED)
    {
        float t_anim = ImSaturate(g.LastActiveIdTimer / ANIM_SPEED);
        t = *v ? (t_anim) : (1.0f - t_anim);
    }

    ImU32 col_bg;

    if (ImGui::IsItemHovered())
    {
        col_bg = ImGui::GetColorU32(ImLerp(ImVec4(0.78f, 0.78f, 0.78f, 1.0f), ImVec4(0.64f, 0.83f, 0.34f, 1.0f), t));
    }
    else
    {
        col_bg = ImGui::GetColorU32(ImLerp(ImVec4(0.85f, 0.85f, 0.85f, 1.0f), ImVec4(0.56f, 0.83f, 0.26f, 1.0f), t));
    }

    draw_list->AddRectFilled(p, ImVec2(p.x + width, p.y + height), col_bg, height * 0.5f);
    draw_list->AddCircleFilled(ImVec2(p.x + radius + t * (width - radius * 2.0f), p.y + radius), radius - 1.5f, IM_COL32(255, 255, 255, 255));
    if (label_size.x > 0.0f) {
        if (*v) {
            PushStyleColor(ImGuiCol_Text, ImVec4(1.f, 1.f, 1.f, 1));
        }
        else {
            PushStyleColor(ImGuiCol_Text, ImVec4(.6f, .6f, .6f, 1));
        }
        RenderText(text_bb.GetTL() + ImVec2(35, 0), str_id);
        PopStyleColor();
    }
}

bool ImGui::CheckboxFlags(const char* label, unsigned int* flags, unsigned int flags_value)
{
    bool v = ((*flags & flags_value) == flags_value);
    bool pressed = Checkbox(label, &v);
    if (pressed)
    {
        if (v)
            *flags |= flags_value;
        else
            *flags &= ~flags_value;
    }

    return pressed;
}

bool ImGui::RadioButton(const char* label, bool active)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = CalcTextSize(label, NULL, true);

    const float square_sz = GetFrameHeight();
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect check_bb(pos, pos + ImVec2(square_sz, square_sz));
    const ImRect total_bb(pos, pos + ImVec2(square_sz + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f), label_size.y + style.FramePadding.y * 2.0f));
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id))
        return false;

    ImVec2 center = check_bb.GetCenter();
    center.x = (float)(int)center.x + 0.5f;
    center.y = (float)(int)center.y + 0.5f;
    const float radius = (square_sz - 1.0f) * 0.5f;

    bool hovered, held;
    bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed)
        MarkItemEdited(id);

    RenderNavHighlight(total_bb, id);
    window->DrawList->AddCircleFilled(center, radius, GetColorU32((held && hovered) ? ImGuiCol_FrameBgActive : hovered ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg), 16);
    if (active)
    {
        const float pad = ImMax(1.0f, (float)(int)(square_sz / 6.0f));
        window->DrawList->AddCircleFilled(center, radius - pad, GetColorU32(ImGuiCol_CheckMark), 16);
    }

    if (style.FrameBorderSize > 0.0f)
    {
        window->DrawList->AddCircle(center + ImVec2(1,1), radius, GetColorU32(ImGuiCol_BorderShadow), 16, style.FrameBorderSize);
        window->DrawList->AddCircle(center, radius, GetColorU32(ImGuiCol_Border), 16, style.FrameBorderSize);
    }

    if (g.LogEnabled)
        LogRenderedText(&total_bb.Min, active ? "(x)" : "( )");
    if (label_size.x > 0.0f)
        RenderText(ImVec2(check_bb.Max.x + style.ItemInnerSpacing.x, check_bb.Min.y + style.FramePadding.y), label);

    return pressed;
}

bool ImGui::RadioButton(const char* label, int* v, int v_button)
{
    const bool pressed = RadioButton(label, *v == v_button);
    if (pressed)
        *v = v_button;
    return pressed;
}

// size_arg (for each axis) < 0.0f: align to end, 0.0f: auto, > 0.0f: specified size
void ImGui::ProgressBar(float fraction, const ImVec2& size_arg, const char* overlay)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    ImVec2 pos = window->DC.CursorPos;
    ImRect bb(pos, pos + CalcItemSize(size_arg, CalcItemWidth(), g.FontSize + style.FramePadding.y*2.0f));
    ItemSize(bb, style.FramePadding.y);
    if (!ItemAdd(bb, 0))
        return;

    // Render
    fraction = ImSaturate(fraction);
    RenderFrame(bb.Min, bb.Max, GetColorU32(ImGuiCol_FrameBg), true, style.FrameRounding);
    bb.Expand(ImVec2(-style.FrameBorderSize, -style.FrameBorderSize));
    const ImVec2 fill_br = ImVec2(ImLerp(bb.Min.x, bb.Max.x, fraction), bb.Max.y);
    RenderRectFilledRangeH(window->DrawList, bb, GetColorU32(ImGuiCol_PlotHistogram), 0.0f, fraction, style.FrameRounding);

    // Default displaying the fraction as percentage string, but user can override it
    char overlay_buf[32];
    if (!overlay)
    {
        ImFormatString(overlay_buf, IM_ARRAYSIZE(overlay_buf), "%.0f%%", fraction*100+0.01f);
        overlay = overlay_buf;
    }

    ImVec2 overlay_size = CalcTextSize(overlay, NULL);
    if (overlay_size.x > 0.0f)
        RenderTextClipped(ImVec2(ImClamp(fill_br.x + style.ItemSpacing.x, bb.Min.x, bb.Max.x - overlay_size.x - style.ItemInnerSpacing.x), bb.Min.y), bb.Max, overlay, NULL, &overlay_size, ImVec2(0.0f,0.5f), &bb);
}

void ImGui::Bullet()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const float line_height = ImMax(ImMin(window->DC.CurrentLineSize.y, g.FontSize + g.Style.FramePadding.y*2), g.FontSize);
    const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(g.FontSize, line_height));
    ItemSize(bb);
    if (!ItemAdd(bb, 0))
    {
        SameLine(0, style.FramePadding.x*2);
        return;
    }

    // Render and stay on same line
    RenderBullet(bb.Min + ImVec2(style.FramePadding.x + g.FontSize*0.5f, line_height*0.5f));
    SameLine(0, style.FramePadding.x*2);
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: Low-level Layout helpers
//-------------------------------------------------------------------------
// - Spacing()
// - Dummy()
// - NewLine()
// - AlignTextToFramePadding()
// - Separator()
// - VerticalSeparator() [Internal]
// - SplitterBehavior() [Internal]
//-------------------------------------------------------------------------

void ImGui::Spacing()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;
    ItemSize(ImVec2(0,0));
}

void ImGui::Dummy(const ImVec2& size)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + size);
    ItemSize(bb);
    ItemAdd(bb, 0);
}

void ImGui::NewLine()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const ImGuiLayoutType backup_layout_type = window->DC.LayoutType;
    window->DC.LayoutType = ImGuiLayoutType_Vertical;
    if (window->DC.CurrentLineSize.y > 0.0f)     // In the event that we are on a line with items that is smaller that FontSize high, we will preserve its height.
        ItemSize(ImVec2(0,0));
    else
        ItemSize(ImVec2(0.0f, g.FontSize));
    window->DC.LayoutType = backup_layout_type;
}

void ImGui::AlignTextToFramePadding()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    window->DC.CurrentLineSize.y = ImMax(window->DC.CurrentLineSize.y, g.FontSize + g.Style.FramePadding.y * 2);
    window->DC.CurrentLineTextBaseOffset = ImMax(window->DC.CurrentLineTextBaseOffset, g.Style.FramePadding.y);
}

// Horizontal/vertical separating line
void ImGui::Separator()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;
    ImGuiContext& g = *GImGui;

    // Those flags should eventually be overridable by the user
    ImGuiSeparatorFlags flags = (window->DC.LayoutType == ImGuiLayoutType_Horizontal) ? ImGuiSeparatorFlags_Vertical : ImGuiSeparatorFlags_Horizontal;
    IM_ASSERT(ImIsPowerOfTwo((int)(flags & (ImGuiSeparatorFlags_Horizontal | ImGuiSeparatorFlags_Vertical))));   // Check that only 1 option is selected
    if (flags & ImGuiSeparatorFlags_Vertical)
    {
        VerticalSeparator();
        return;
    }

    // Horizontal Separator
    if (window->DC.ColumnsSet)
        PopClipRect();

    float x1 = window->Pos.x;
    float x2 = window->Pos.x + window->Size.x;
    if (!window->DC.GroupStack.empty())
        x1 += window->DC.Indent.x;

    const ImRect bb(ImVec2(x1, window->DC.CursorPos.y), ImVec2(x2, window->DC.CursorPos.y+1.0f));
    ItemSize(ImVec2(0.0f, 0.0f)); // NB: we don't provide our width so that it doesn't get feed back into AutoFit, we don't provide height to not alter layout.
    if (!ItemAdd(bb, 0))
    {
        if (window->DC.ColumnsSet)
            PushColumnClipRect();
        return;
    }

    window->DrawList->AddLine(bb.Min, ImVec2(bb.Max.x,bb.Min.y), GetColorU32(ImGuiCol_Separator));

    if (g.LogEnabled)
        LogRenderedText(&bb.Min, "--------------------------------");

    if (window->DC.ColumnsSet)
    {
        PushColumnClipRect();
        window->DC.ColumnsSet->LineMinY = window->DC.CursorPos.y;
    }
}

void ImGui::VerticalSeparator()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;
    ImGuiContext& g = *GImGui;

    float y1 = window->DC.CursorPos.y;
    float y2 = window->DC.CursorPos.y + window->DC.CurrentLineSize.y;
    const ImRect bb(ImVec2(window->DC.CursorPos.x, y1), ImVec2(window->DC.CursorPos.x + 1.0f, y2));
    ItemSize(ImVec2(bb.GetWidth(), 0.0f));
    if (!ItemAdd(bb, 0))
        return;

    window->DrawList->AddLine(ImVec2(bb.Min.x, bb.Min.y), ImVec2(bb.Min.x, bb.Max.y), GetColorU32(ImGuiCol_Separator));
    if (g.LogEnabled)
        LogText(" |");
}

// Using 'hover_visibility_delay' allows us to hide the highlight and mouse cursor for a short time, which can be convenient to reduce visual noise.
bool ImGui::SplitterBehavior(const ImRect& bb, ImGuiID id, ImGuiAxis axis, float* size1, float* size2, float min_size1, float min_size2, float hover_extend, float hover_visibility_delay)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    const ImGuiItemFlags item_flags_backup = window->DC.ItemFlags;
    window->DC.ItemFlags |= ImGuiItemFlags_NoNav | ImGuiItemFlags_NoNavDefaultFocus;
    bool item_add = ItemAdd(bb, id);
    window->DC.ItemFlags = item_flags_backup;
    if (!item_add)
        return false;

    bool hovered, held;
    ImRect bb_interact = bb;
    bb_interact.Expand(axis == ImGuiAxis_Y ? ImVec2(0.0f, hover_extend) : ImVec2(hover_extend, 0.0f));
    ButtonBehavior(bb_interact, id, &hovered, &held, ImGuiButtonFlags_FlattenChildren | ImGuiButtonFlags_AllowItemOverlap);
    if (g.ActiveId != id)
        SetItemAllowOverlap();

    if (held || (g.HoveredId == id && g.HoveredIdPreviousFrame == id && g.HoveredIdTimer >= hover_visibility_delay))
        SetMouseCursor(axis == ImGuiAxis_Y ? ImGuiMouseCursor_ResizeNS : ImGuiMouseCursor_ResizeEW);

    ImRect bb_render = bb;
    if (held)
    {
        ImVec2 mouse_delta_2d = g.IO.MousePos - g.ActiveIdClickOffset - bb_interact.Min;
        float mouse_delta = (axis == ImGuiAxis_Y) ? mouse_delta_2d.y : mouse_delta_2d.x;

        // Minimum pane size
        float size_1_maximum_delta = ImMax(0.0f, *size1 - min_size1);
        float size_2_maximum_delta = ImMax(0.0f, *size2 - min_size2);
        if (mouse_delta < -size_1_maximum_delta)
            mouse_delta = -size_1_maximum_delta;
        if (mouse_delta > size_2_maximum_delta)
            mouse_delta = size_2_maximum_delta;

        // Apply resize
        if (mouse_delta != 0.0f)
        {
            if (mouse_delta < 0.0f)
                IM_ASSERT(*size1 + mouse_delta >= min_size1);
            if (mouse_delta > 0.0f)
                IM_ASSERT(*size2 - mouse_delta >= min_size2);
            *size1 += mouse_delta;
            *size2 -= mouse_delta;
            bb_render.Translate((axis == ImGuiAxis_X) ? ImVec2(mouse_delta, 0.0f) : ImVec2(0.0f, mouse_delta));
            MarkItemEdited(id);
        }
    }

    // Render
    const ImU32 col = GetColorU32(held ? ImGuiCol_SeparatorActive : (hovered && g.HoveredIdTimer >= hover_visibility_delay) ? ImGuiCol_SeparatorHovered : ImGuiCol_Separator);
    window->DrawList->AddRectFilled(bb_render.Min, bb_render.Max, col, g.Style.FrameRounding);

    return held;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: ComboBox
//-------------------------------------------------------------------------
// - BeginCombo()
// - EndCombo()
// - Combo()
//-------------------------------------------------------------------------

static float CalcMaxPopupHeightFromItemCount(int items_count)
{
    ImGuiContext& g = *GImGui;
    if (items_count <= 0)
        return FLT_MAX;
    return (g.FontSize + g.Style.ItemSpacing.y) * items_count - g.Style.ItemSpacing.y + (g.Style.WindowPadding.y * 2);
}

bool ImGui::BeginCombo(const char* label, const char* preview_value, ImGuiComboFlags flags)
{
    // Always consume the SetNextWindowSizeConstraint() call in our early return paths
    ImGuiContext& g = *GImGui;
    ImGuiCond backup_next_window_size_constraint = g.NextWindowData.SizeConstraintCond;
    g.NextWindowData.SizeConstraintCond = 0;

    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    IM_ASSERT((flags & (ImGuiComboFlags_NoArrowButton | ImGuiComboFlags_NoPreview)) != (ImGuiComboFlags_NoArrowButton | ImGuiComboFlags_NoPreview)); // Can't use both flags together

    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    const float arrow_size = (flags & ImGuiComboFlags_NoArrowButton) ? 0.0f : GetFrameHeight();
    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    const float w = (flags & ImGuiComboFlags_NoPreview) ? arrow_size : CalcItemWidth();
    const ImRect frame_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(w, label_size.y + style.FramePadding.y*2.0f));
    const ImRect total_bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f, 0.0f));
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id, &frame_bb))
        return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(frame_bb, id, &hovered, &held);
    bool popup_open = IsPopupOpen(id);

    const ImRect value_bb(frame_bb.Min, frame_bb.Max - ImVec2(arrow_size, 0.0f));
    const ImU32 frame_col = GetColorU32(hovered ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg);
    RenderNavHighlight(frame_bb, id);
    if (!(flags & ImGuiComboFlags_NoPreview))
        window->DrawList->AddRectFilled(frame_bb.Min, ImVec2(frame_bb.Max.x - arrow_size, frame_bb.Max.y), frame_col, style.FrameRounding, ImDrawCornerFlags_Left);
    if (!(flags & ImGuiComboFlags_NoArrowButton))
    {
        window->DrawList->AddRectFilled(ImVec2(frame_bb.Max.x - arrow_size, frame_bb.Min.y), frame_bb.Max, GetColorU32((popup_open || hovered) ? ImGuiCol_ButtonHovered : ImGuiCol_Button), style.FrameRounding, (w <= arrow_size) ? ImDrawCornerFlags_All : ImDrawCornerFlags_Right);
        RenderArrow(ImVec2(frame_bb.Max.x - arrow_size + style.FramePadding.y, frame_bb.Min.y + style.FramePadding.y), ImGuiDir_Down);
    }
    RenderFrameBorder(frame_bb.Min, frame_bb.Max, style.FrameRounding);
    if (preview_value != NULL && !(flags & ImGuiComboFlags_NoPreview))
        RenderTextClipped(frame_bb.Min + style.FramePadding, value_bb.Max, preview_value, NULL, NULL, ImVec2(0.0f,0.0f));
    if (label_size.x > 0)
        RenderText(ImVec2(frame_bb.Max.x + style.ItemInnerSpacing.x, frame_bb.Min.y + style.FramePadding.y), label);

    if ((pressed || g.NavActivateId == id) && !popup_open)
    {
        if (window->DC.NavLayerCurrent == 0)
            window->NavLastIds[0] = id;
        OpenPopupEx(id);
        popup_open = true;
    }

    if (!popup_open)
        return false;

    if (backup_next_window_size_constraint)
    {
        g.NextWindowData.SizeConstraintCond = backup_next_window_size_constraint;
        g.NextWindowData.SizeConstraintRect.Min.x = ImMax(g.NextWindowData.SizeConstraintRect.Min.x, w);
    }
    else
    {
        if ((flags & ImGuiComboFlags_HeightMask_) == 0)
            flags |= ImGuiComboFlags_HeightRegular;
        IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiComboFlags_HeightMask_));    // Only one
        int popup_max_height_in_items = -1;
        if (flags & ImGuiComboFlags_HeightRegular)     popup_max_height_in_items = 8;
        else if (flags & ImGuiComboFlags_HeightSmall)  popup_max_height_in_items = 4;
        else if (flags & ImGuiComboFlags_HeightLarge)  popup_max_height_in_items = 20;
        SetNextWindowSizeConstraints(ImVec2(w, 0.0f), ImVec2(FLT_MAX, CalcMaxPopupHeightFromItemCount(popup_max_height_in_items)));
    }

    char name[16];
    ImFormatString(name, IM_ARRAYSIZE(name), "##Combo_%02d", g.BeginPopupStack.Size); // Recycle windows based on depth

    // Peak into expected window size so we can position it
    if (ImGuiWindow* popup_window = FindWindowByName(name))
        if (popup_window->WasActive)
        {
            ImVec2 size_expected = CalcWindowExpectedSize(popup_window);
            if (flags & ImGuiComboFlags_PopupAlignLeft)
                popup_window->AutoPosLastDirection = ImGuiDir_Left;
            ImRect r_outer = GetWindowAllowedExtentRect(popup_window);
            ImVec2 pos = FindBestWindowPosForPopupEx(frame_bb.GetBL(), size_expected, &popup_window->AutoPosLastDirection, r_outer, frame_bb, ImGuiPopupPositionPolicy_ComboBox);
            SetNextWindowPos(pos);
        }

    // Horizontally align ourselves with the framed text
    ImGuiWindowFlags window_flags = ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_Popup | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings;
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(style.FramePadding.x, style.WindowPadding.y));
    bool ret = Begin(name, NULL, window_flags);
    PopStyleVar();
    if (!ret)
    {
        EndPopup();
        IM_ASSERT(0);   // This should never happen as we tested for IsPopupOpen() above
        return false;
    }
    return true;
}

void ImGui::EndCombo()
{
    EndPopup();
}

// Getter for the old Combo() API: const char*[]
static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
{
    const char* const* items = (const char* const*)data;
    if (out_text)
        *out_text = items[idx];
    return true;
}

// Getter for the old Combo() API: "item1\0item2\0item3\0"
static bool Items_SingleStringGetter(void* data, int idx, const char** out_text)
{
    // FIXME-OPT: we could pre-compute the indices to fasten this. But only 1 active combo means the waste is limited.
    const char* items_separated_by_zeros = (const char*)data;
    int items_count = 0;
    const char* p = items_separated_by_zeros;
    while (*p)
    {
        if (idx == items_count)
            break;
        p += strlen(p) + 1;
        items_count++;
    }
    if (!*p)
        return false;
    if (out_text)
        *out_text = p;
    return true;
}

// Old API, prefer using BeginCombo() nowadays if you can.
bool ImGui::Combo(const char* label, int* current_item, bool (*items_getter)(void*, int, const char**), void* data, int items_count, int popup_max_height_in_items)
{
    ImGuiContext& g = *GImGui;

    // Call the getter to obtain the preview string which is a parameter to BeginCombo()
    const char* preview_value = NULL;
    if (*current_item >= 0 && *current_item < items_count)
        items_getter(data, *current_item, &preview_value);

    // The old Combo() API exposed "popup_max_height_in_items". The new more general BeginCombo() API doesn't have/need it, but we emulate it here.
    if (popup_max_height_in_items != -1 && !g.NextWindowData.SizeConstraintCond)
        SetNextWindowSizeConstraints(ImVec2(0,0), ImVec2(FLT_MAX, CalcMaxPopupHeightFromItemCount(popup_max_height_in_items)));

    if (!BeginCombo(label, preview_value, ImGuiComboFlags_None))
        return false;

    // Display items
    // FIXME-OPT: Use clipper (but we need to disable it on the appearing frame to make sure our call to SetItemDefaultFocus() is processed)
    bool value_changed = false;
    for (int i = 0; i < items_count; i++)
    {
        PushID((void*)(intptr_t)i);
        const bool item_selected = (i == *current_item);
        const char* item_text;
        if (!items_getter(data, i, &item_text))
            item_text = "*Unknown item*";
        if (Selectable(item_text, item_selected))
        {
            value_changed = true;
            *current_item = i;
        }
        if (item_selected)
            SetItemDefaultFocus();
        PopID();
    }

    EndCombo();
    return value_changed;
}

// Combo box helper allowing to pass an array of strings.
bool ImGui::Combo(const char* label, int* current_item, const char* const items[], int items_count, int height_in_items)
{
    const bool value_changed = Combo(label, current_item, Items_ArrayGetter, (void*)items, items_count, height_in_items);
    return value_changed;
}

// Combo box helper allowing to pass all items in a single string literal holding multiple zero-terminated items "item1\0item2\0"
bool ImGui::Combo(const char* label, int* current_item, const char* items_separated_by_zeros, int height_in_items)
{
    int items_count = 0;
    const char* p = items_separated_by_zeros;       // FIXME-OPT: Avoid computing this, or at least only when combo is open
    while (*p)
    {
        p += strlen(p) + 1;
        items_count++;
    }
    bool value_changed = Combo(label, current_item, Items_SingleStringGetter, (void*)items_separated_by_zeros, items_count, height_in_items);
    return value_changed;
}

//-------------------------------------------------------------------------
// [SECTION] Data Type and Data Formatting Helpers [Internal]
//-------------------------------------------------------------------------
// - PatchFormatStringFloatToInt()
// - DataTypeFormatString()
// - DataTypeApplyOp()
// - DataTypeApplyOpFromText()
// - GetMinimumStepAtDecimalPrecision
// - RoundScalarWithFormat<>()
//-------------------------------------------------------------------------

struct ImGuiDataTypeInfo
{
    size_t      Size;
    const char* PrintFmt;   // Unused
    const char* ScanFmt;
};

static const ImGuiDataTypeInfo GDataTypeInfo[] =
{
    { sizeof(int),          "%d",   "%d"    },
    { sizeof(unsigned int), "%u",   "%u"    },
#ifdef _MSC_VER
    { sizeof(ImS64),        "%I64d","%I64d" },
    { sizeof(ImU64),        "%I64u","%I64u" },
#else
    { sizeof(ImS64),        "%lld", "%lld"  },
    { sizeof(ImU64),        "%llu", "%llu"  },
#endif
    { sizeof(float),        "%f",   "%f"    },  // float are promoted to double in va_arg
    { sizeof(double),       "%f",   "%lf"   },
};
IM_STATIC_ASSERT(IM_ARRAYSIZE(GDataTypeInfo) == ImGuiDataType_COUNT);

// FIXME-LEGACY: Prior to 1.61 our DragInt() function internally used floats and because of this the compile-time default value for format was "%.0f".
// Even though we changed the compile-time default, we expect users to have carried %f around, which would break the display of DragInt() calls.
// To honor backward compatibility we are rewriting the format string, unless IMGUI_DISABLE_OBSOLETE_FUNCTIONS is enabled. What could possibly go wrong?!
static const char* PatchFormatStringFloatToInt(const char* fmt)
{
    if (fmt[0] == '%' && fmt[1] == '.' && fmt[2] == '0' && fmt[3] == 'f' && fmt[4] == 0) // Fast legacy path for "%.0f" which is expected to be the most common case.
        return "%d";
    const char* fmt_start = ImParseFormatFindStart(fmt);    // Find % (if any, and ignore %%)
    const char* fmt_end = ImParseFormatFindEnd(fmt_start);  // Find end of format specifier, which itself is an exercise of confidence/recklessness (because snprintf is dependent on libc or user).
    if (fmt_end > fmt_start && fmt_end[-1] == 'f')
    {
#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
        if (fmt_start == fmt && fmt_end[0] == 0)
            return "%d";
        ImGuiContext& g = *GImGui;
        ImFormatString(g.TempBuffer, IM_ARRAYSIZE(g.TempBuffer), "%.*s%%d%s", (int)(fmt_start - fmt), fmt, fmt_end); // Honor leading and trailing decorations, but lose alignment/precision.
        return g.TempBuffer;
#else
        IM_ASSERT(0 && "DragInt(): Invalid format string!"); // Old versions used a default parameter of "%.0f", please replace with e.g. "%d"
#endif
    }
    return fmt;
}

static inline int DataTypeFormatString(char* buf, int buf_size, ImGuiDataType data_type, const void* data_ptr, const char* format)
{
    if (data_type == ImGuiDataType_S32 || data_type == ImGuiDataType_U32)   // Signedness doesn't matter when pushing the argument
        return ImFormatString(buf, buf_size, format, *(const ImU32*)data_ptr);
    if (data_type == ImGuiDataType_S64 || data_type == ImGuiDataType_U64)   // Signedness doesn't matter when pushing the argument
        return ImFormatString(buf, buf_size, format, *(const ImU64*)data_ptr);
    if (data_type == ImGuiDataType_Float)
        return ImFormatString(buf, buf_size, format, *(const float*)data_ptr);
    if (data_type == ImGuiDataType_Double)
        return ImFormatString(buf, buf_size, format, *(const double*)data_ptr);
    IM_ASSERT(0);
    return 0;
}

// FIXME: Adding support for clamping on boundaries of the data type would be nice.
static void DataTypeApplyOp(ImGuiDataType data_type, int op, void* output, void* arg1, const void* arg2)
{
    IM_ASSERT(op == '+' || op == '-');
    switch (data_type)
    {
        case ImGuiDataType_S32:
            if (op == '+')      *(int*)output = *(const int*)arg1 + *(const int*)arg2;
            else if (op == '-') *(int*)output = *(const int*)arg1 - *(const int*)arg2;
            return;
        case ImGuiDataType_U32:
            if (op == '+')      *(unsigned int*)output = *(const unsigned int*)arg1 + *(const ImU32*)arg2;
            else if (op == '-') *(unsigned int*)output = *(const unsigned int*)arg1 - *(const ImU32*)arg2;
            return;
        case ImGuiDataType_S64:
            if (op == '+')      *(ImS64*)output = *(const ImS64*)arg1 + *(const ImS64*)arg2;
            else if (op == '-') *(ImS64*)output = *(const ImS64*)arg1 - *(const ImS64*)arg2;
            return;
        case ImGuiDataType_U64:
            if (op == '+')      *(ImU64*)output = *(const ImU64*)arg1 + *(const ImU64*)arg2;
            else if (op == '-') *(ImU64*)output = *(const ImU64*)arg1 - *(const ImU64*)arg2;
            return;
        case ImGuiDataType_Float:
            if (op == '+')      *(float*)output = *(const float*)arg1 + *(const float*)arg2;
            else if (op == '-') *(float*)output = *(const float*)arg1 - *(const float*)arg2;
            return;
        case ImGuiDataType_Double:
            if (op == '+')      *(double*)output = *(const double*)arg1 + *(const double*)arg2;
            else if (op == '-') *(double*)output = *(const double*)arg1 - *(const double*)arg2;
            return;
        case ImGuiDataType_COUNT: break;
    }
    IM_ASSERT(0);
}

// User can input math operators (e.g. +100) to edit a numerical values.
// NB: This is _not_ a full expression evaluator. We should probably add one and replace this dumb mess..
static bool DataTypeApplyOpFromText(const char* buf, const char* initial_value_buf, ImGuiDataType data_type, void* data_ptr, const char* format)
{
    while (ImCharIsBlankA(*buf))
        buf++;

    // We don't support '-' op because it would conflict with inputing negative value.
    // Instead you can use +-100 to subtract from an existing value
    char op = buf[0];
    if (op == '+' || op == '*' || op == '/')
    {
        buf++;
        while (ImCharIsBlankA(*buf))
            buf++;
    }
    else
    {
        op = 0;
    }
    if (!buf[0])
        return false;

    // Copy the value in an opaque buffer so we can compare at the end of the function if it changed at all.
    IM_ASSERT(data_type < ImGuiDataType_COUNT);
    int data_backup[2];
    IM_ASSERT(GDataTypeInfo[data_type].Size <= sizeof(data_backup));
    memcpy(data_backup, data_ptr, GDataTypeInfo[data_type].Size);

    if (format == NULL)
        format = GDataTypeInfo[data_type].ScanFmt;

    int arg1i = 0;
    if (data_type == ImGuiDataType_S32)
    {
        int* v = (int*)data_ptr;
        int arg0i = *v;
        float arg1f = 0.0f;
        if (op && sscanf(initial_value_buf, format, &arg0i) < 1)
            return false;
        // Store operand in a float so we can use fractional value for multipliers (*1.1), but constant always parsed as integer so we can fit big integers (e.g. 2000000003) past float precision
        if (op == '+')      { if (sscanf(buf, "%d", &arg1i)) *v = (int)(arg0i + arg1i); }                   // Add (use "+-" to subtract)
        else if (op == '*') { if (sscanf(buf, "%f", &arg1f)) *v = (int)(arg0i * arg1f); }                   // Multiply
        else if (op == '/') { if (sscanf(buf, "%f", &arg1f) && arg1f != 0.0f) *v = (int)(arg0i / arg1f); }  // Divide
        else                { if (sscanf(buf, format, &arg1i) == 1) *v = arg1i; }                           // Assign constant
    }
    else if (data_type == ImGuiDataType_U32 || data_type == ImGuiDataType_S64 || data_type == ImGuiDataType_U64)
    {
        // Assign constant
        // FIXME: We don't bother handling support for legacy operators since they are a little too crappy. Instead we may implement a proper expression evaluator in the future.
        sscanf(buf, format, data_ptr);
    }
    else if (data_type == ImGuiDataType_Float)
    {
        // For floats we have to ignore format with precision (e.g. "%.2f") because sscanf doesn't take them in
        format = "%f";
        float* v = (float*)data_ptr;
        float arg0f = *v, arg1f = 0.0f;
        if (op && sscanf(initial_value_buf, format, &arg0f) < 1)
            return false;
        if (sscanf(buf, format, &arg1f) < 1)
            return false;
        if (op == '+')      { *v = arg0f + arg1f; }                    // Add (use "+-" to subtract)
        else if (op == '*') { *v = arg0f * arg1f; }                    // Multiply
        else if (op == '/') { if (arg1f != 0.0f) *v = arg0f / arg1f; } // Divide
        else                { *v = arg1f; }                            // Assign constant
    }
    else if (data_type == ImGuiDataType_Double)
    {
        format = "%lf"; // scanf differentiate float/double unlike printf which forces everything to double because of ellipsis
        double* v = (double*)data_ptr;
        double arg0f = *v, arg1f = 0.0;
        if (op && sscanf(initial_value_buf, format, &arg0f) < 1)
            return false;
        if (sscanf(buf, format, &arg1f) < 1)
            return false;
        if (op == '+')      { *v = arg0f + arg1f; }                    // Add (use "+-" to subtract)
        else if (op == '*') { *v = arg0f * arg1f; }                    // Multiply
        else if (op == '/') { if (arg1f != 0.0f) *v = arg0f / arg1f; } // Divide
        else                { *v = arg1f; }                            // Assign constant
    }
    return memcmp(data_backup, data_ptr, GDataTypeInfo[data_type].Size) != 0;
}

static float GetMinimumStepAtDecimalPrecision(int decimal_precision)
{
    static const float min_steps[10] = { 1.0f, 0.1f, 0.01f, 0.001f, 0.0001f, 0.00001f, 0.000001f, 0.0000001f, 0.00000001f, 0.000000001f };
    if (decimal_precision < 0)
        return FLT_MIN;
    return (decimal_precision < IM_ARRAYSIZE(min_steps)) ? min_steps[decimal_precision] : ImPow(10.0f, (float)-decimal_precision);
}

template<typename TYPE>
static const char* ImAtoi(const char* src, TYPE* output)
{
    int negative = 0;
    if (*src == '-') { negative = 1; src++; }
    if (*src == '+') { src++; }
    TYPE v = 0;
    while (*src >= '0' && *src <= '9')
        v = (v * 10) + (*src++ - '0');
    *output = negative ? -v : v;
    return src;
}

template<typename TYPE, typename SIGNEDTYPE>
TYPE ImGui::RoundScalarWithFormatT(const char* format, ImGuiDataType data_type, TYPE v)
{
    const char* fmt_start = ImParseFormatFindStart(format);
    if (fmt_start[0] != '%' || fmt_start[1] == '%') // Don't apply if the value is not visible in the format string
        return v;
    char v_str[64];
    ImFormatString(v_str, IM_ARRAYSIZE(v_str), fmt_start, v);
    const char* p = v_str;
    while (*p == ' ')
        p++;
    if (data_type == ImGuiDataType_Float || data_type == ImGuiDataType_Double)
        v = (TYPE)ImAtof(p);
    else
        ImAtoi(p, (SIGNEDTYPE*)&v);
    return v;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: DragScalar, DragFloat, DragInt, etc.
//-------------------------------------------------------------------------
// - DragBehaviorT<>() [Internal]
// - DragBehavior() [Internal]
// - DragScalar()
// - DragScalarN()
// - DragFloat()
// - DragFloat2()
// - DragFloat3()
// - DragFloat4()
// - DragFloatRange2()
// - DragInt()
// - DragInt2()
// - DragInt3()
// - DragInt4()
// - DragIntRange2()
//-------------------------------------------------------------------------

// This is called by DragBehavior() when the widget is active (held by mouse or being manipulated with Nav controls)
template<typename TYPE, typename SIGNEDTYPE, typename FLOATTYPE>
bool ImGui::DragBehaviorT(ImGuiDataType data_type, TYPE* v, float v_speed, const TYPE v_min, const TYPE v_max, const char* format, float power, ImGuiDragFlags flags)
{
    ImGuiContext& g = *GImGui;
    const ImGuiAxis axis = (flags & ImGuiDragFlags_Vertical) ? ImGuiAxis_Y : ImGuiAxis_X;
    const bool is_decimal = (data_type == ImGuiDataType_Float) || (data_type == ImGuiDataType_Double);
    const bool has_min_max = (v_min != v_max);
    const bool is_power = (power != 1.0f && is_decimal && has_min_max && (v_max - v_min < FLT_MAX));

    // Default tweak speed
    if (v_speed == 0.0f && has_min_max && (v_max - v_min < FLT_MAX))
        v_speed = (float)((v_max - v_min) * g.DragSpeedDefaultRatio);

    // Inputs accumulates into g.DragCurrentAccum, which is flushed into the current value as soon as it makes a difference with our precision settings
    float adjust_delta = 0.0f;
    if (g.ActiveIdSource == ImGuiInputSource_Mouse && IsMousePosValid() && g.IO.MouseDragMaxDistanceSqr[0] > 1.0f*1.0f)
    {
        adjust_delta = g.IO.MouseDelta[axis];
        if (g.IO.KeyAlt)
            adjust_delta *= 1.0f / 100.0f;
        if (g.IO.KeyShift)
            adjust_delta *= 10.0f;
    }
    else if (g.ActiveIdSource == ImGuiInputSource_Nav)
    {
        int decimal_precision = is_decimal ? ImParseFormatPrecision(format, 3) : 0;
        adjust_delta = GetNavInputAmount2d(ImGuiNavDirSourceFlags_Keyboard | ImGuiNavDirSourceFlags_PadDPad, ImGuiInputReadMode_RepeatFast, 1.0f / 10.0f, 10.0f)[axis];
        v_speed = ImMax(v_speed, GetMinimumStepAtDecimalPrecision(decimal_precision));
    }
    adjust_delta *= v_speed;

    // For vertical drag we currently assume that Up=higher value (like we do with vertical sliders). This may become a parameter.
    if (axis == ImGuiAxis_Y)
        adjust_delta = -adjust_delta;

    // Clear current value on activation
    // Avoid altering values and clamping when we are _already_ past the limits and heading in the same direction, so e.g. if range is 0..255, current value is 300 and we are pushing to the right side, keep the 300.
    bool is_just_activated = g.ActiveIdIsJustActivated;
    bool is_already_past_limits_and_pushing_outward = has_min_max && ((*v >= v_max && adjust_delta > 0.0f) || (*v <= v_min && adjust_delta < 0.0f));
    bool is_drag_direction_change_with_power = is_power && ((adjust_delta < 0 && g.DragCurrentAccum > 0) || (adjust_delta > 0 && g.DragCurrentAccum < 0));
    if (is_just_activated || is_already_past_limits_and_pushing_outward || is_drag_direction_change_with_power)
    {
        g.DragCurrentAccum = 0.0f;
        g.DragCurrentAccumDirty = false;
    }
    else if (adjust_delta != 0.0f)
    {
        g.DragCurrentAccum += adjust_delta;
        g.DragCurrentAccumDirty = true;
    }

    if (!g.DragCurrentAccumDirty)
        return false;

    TYPE v_cur = *v;
    FLOATTYPE v_old_ref_for_accum_remainder = (FLOATTYPE)0.0f;

    if (is_power)
    {
        // Offset + round to user desired precision, with a curve on the v_min..v_max range to get more precision on one side of the range
        FLOATTYPE v_old_norm_curved = ImPow((FLOATTYPE)(v_cur - v_min) / (FLOATTYPE)(v_max - v_min), (FLOATTYPE)1.0f / power);
        FLOATTYPE v_new_norm_curved = v_old_norm_curved + (g.DragCurrentAccum / (v_max - v_min));
        v_cur = v_min + (TYPE)ImPow(ImSaturate((float)v_new_norm_curved), power) * (v_max - v_min);
        v_old_ref_for_accum_remainder = v_old_norm_curved;
    }
    else
    {
        v_cur += (TYPE)g.DragCurrentAccum;
    }

    // Round to user desired precision based on format string
    v_cur = RoundScalarWithFormatT<TYPE, SIGNEDTYPE>(format, data_type, v_cur);

    // Preserve remainder after rounding has been applied. This also allow slow tweaking of values.
    g.DragCurrentAccumDirty = false;
    if (is_power)
    {
        FLOATTYPE v_cur_norm_curved = ImPow((FLOATTYPE)(v_cur - v_min) / (FLOATTYPE)(v_max - v_min), (FLOATTYPE)1.0f / power);
        g.DragCurrentAccum -= (float)(v_cur_norm_curved - v_old_ref_for_accum_remainder);
    }
    else
    {
        g.DragCurrentAccum -= (float)((SIGNEDTYPE)v_cur - (SIGNEDTYPE)*v);
    }

    // Lose zero sign for float/double
    if (v_cur == (TYPE)-0)
        v_cur = (TYPE)0;

    // Clamp values (+ handle overflow/wrap-around for integer types)
    if (*v != v_cur && has_min_max)
    {
        if (v_cur < v_min || (v_cur > *v && adjust_delta < 0.0f && !is_decimal))
            v_cur = v_min;
        if (v_cur > v_max || (v_cur < *v && adjust_delta > 0.0f && !is_decimal))
            v_cur = v_max;
    }

    // Apply result
    if (*v == v_cur)
        return false;
    *v = v_cur;
    return true;
}

bool ImGui::DragBehavior(ImGuiID id, ImGuiDataType data_type, void* v, float v_speed, const void* v_min, const void* v_max, const char* format, float power, ImGuiDragFlags flags)
{
    ImGuiContext& g = *GImGui;
    if (g.ActiveId == id)
    {
        if (g.ActiveIdSource == ImGuiInputSource_Mouse && !g.IO.MouseDown[0])
            ClearActiveID();
        else if (g.ActiveIdSource == ImGuiInputSource_Nav && g.NavActivatePressedId == id && !g.ActiveIdIsJustActivated)
            ClearActiveID();
    }
    if (g.ActiveId != id)
        return false;

    switch (data_type)
    {
    case ImGuiDataType_S32:    return DragBehaviorT<ImS32, ImS32, float >(data_type, (ImS32*)v,  v_speed, v_min ? *(const ImS32* )v_min : IM_S32_MIN, v_max ? *(const ImS32* )v_max : IM_S32_MAX, format, power, flags);
    case ImGuiDataType_U32:    return DragBehaviorT<ImU32, ImS32, float >(data_type, (ImU32*)v,  v_speed, v_min ? *(const ImU32* )v_min : IM_U32_MIN, v_max ? *(const ImU32* )v_max : IM_U32_MAX, format, power, flags);
    case ImGuiDataType_S64:    return DragBehaviorT<ImS64, ImS64, double>(data_type, (ImS64*)v,  v_speed, v_min ? *(const ImS64* )v_min : IM_S64_MIN, v_max ? *(const ImS64* )v_max : IM_S64_MAX, format, power, flags);
    case ImGuiDataType_U64:    return DragBehaviorT<ImU64, ImS64, double>(data_type, (ImU64*)v,  v_speed, v_min ? *(const ImU64* )v_min : IM_U64_MIN, v_max ? *(const ImU64* )v_max : IM_U64_MAX, format, power, flags);
    case ImGuiDataType_Float:  return DragBehaviorT<float, float, float >(data_type, (float*)v,  v_speed, v_min ? *(const float* )v_min : -FLT_MAX,   v_max ? *(const float* )v_max : FLT_MAX,    format, power, flags);
    case ImGuiDataType_Double: return DragBehaviorT<double,double,double>(data_type, (double*)v, v_speed, v_min ? *(const double*)v_min : -DBL_MAX,   v_max ? *(const double*)v_max : DBL_MAX,    format, power, flags);
    case ImGuiDataType_COUNT:  break;
    }
    IM_ASSERT(0);
    return false;
}

bool ImGui::DragScalar(const char* label, ImGuiDataType data_type, void* v, float v_speed, const void* v_min, const void* v_max, const char* format, float power)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    if (power != 1.0f)
        IM_ASSERT(v_min != NULL && v_max != NULL); // When using a power curve the drag needs to have known bounds

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const float w = CalcItemWidth();

    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    const ImRect frame_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(w, label_size.y + style.FramePadding.y*2.0f));
    const ImRect total_bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f, 0.0f));

    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id, &frame_bb))
        return false;

    const bool hovered = ItemHoverable(frame_bb, id);

    // Default format string when passing NULL
    // Patch old "%.0f" format string to use "%d", read function comments for more details.
    IM_ASSERT(data_type >= 0 && data_type < ImGuiDataType_COUNT);
    if (format == NULL)
        format = GDataTypeInfo[data_type].PrintFmt;
    else if (data_type == ImGuiDataType_S32 && strcmp(format, "%d") != 0)
        format = PatchFormatStringFloatToInt(format);

    // Tabbing or CTRL-clicking on Drag turns it into an input box
    bool start_text_input = false;
    const bool tab_focus_requested = FocusableItemRegister(window, id);
    if (tab_focus_requested || (hovered && (g.IO.MouseClicked[0] || g.IO.MouseDoubleClicked[0])) || g.NavActivateId == id || (g.NavInputId == id && g.ScalarAsInputTextId != id))
    {
        SetActiveID(id, window);
        SetFocusID(id, window);
        FocusWindow(window);
        g.ActiveIdAllowNavDirFlags = (1 << ImGuiDir_Up) | (1 << ImGuiDir_Down);
        if (tab_focus_requested || g.IO.KeyCtrl || g.IO.MouseDoubleClicked[0] || g.NavInputId == id)
        {
            start_text_input = true;
            g.ScalarAsInputTextId = 0;
        }
    }
    if (start_text_input || (g.ActiveId == id && g.ScalarAsInputTextId == id))
    {
        window->DC.CursorPos = frame_bb.Min;
        FocusableItemUnregister(window);
        return InputScalarAsWidgetReplacement(frame_bb, id, label, data_type, v, format);
    }

    // Actual drag behavior
    const bool value_changed = DragBehavior(id, data_type, v, v_speed, v_min, v_max, format, power, ImGuiDragFlags_None);
    if (value_changed)
        MarkItemEdited(id);

    // Draw frame
    const ImU32 frame_col = GetColorU32(g.ActiveId == id ? ImGuiCol_FrameBgActive : g.HoveredId == id ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg);
    RenderNavHighlight(frame_bb, id);
    RenderFrame(frame_bb.Min, frame_bb.Max, frame_col, true, style.FrameRounding);

    // Display value using user-provided display format so user can add prefix/suffix/decorations to the value.
    char value_buf[64];
    const char* value_buf_end = value_buf + DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, v, format);
    RenderTextClipped(frame_bb.Min, frame_bb.Max, value_buf, value_buf_end, NULL, ImVec2(0.5f, 0.5f));

    if (label_size.x > 0.0f)
        RenderText(ImVec2(frame_bb.Max.x + style.ItemInnerSpacing.x, frame_bb.Min.y + style.FramePadding.y), label);

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, window->DC.ItemFlags);
    return value_changed;
}

bool ImGui::DragScalarN(const char* label, ImGuiDataType data_type, void* v, int components, float v_speed, const void* v_min, const void* v_max, const char* format, float power)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    bool value_changed = false;
    BeginGroup();
    PushID(label);
    PushMultiItemsWidths(components);
    size_t type_size = GDataTypeInfo[data_type].Size;
    for (int i = 0; i < components; i++)
    {
        PushID(i);
        value_changed |= DragScalar("", data_type, v, v_speed, v_min, v_max, format, power);
        SameLine(0, g.Style.ItemInnerSpacing.x);
        PopID();
        PopItemWidth();
        v = (void*)((char*)v + type_size);
    }
    PopID();

    TextUnformatted(label, FindRenderedTextEnd(label));
    EndGroup();
    return value_changed;
}

bool ImGui::DragFloat(const char* label, float* v, float v_speed, float v_min, float v_max, const char* format, float power)
{
    return DragScalar(label, ImGuiDataType_Float, v, v_speed, &v_min, &v_max, format, power);
}

bool ImGui::DragFloat2(const char* label, float v[2], float v_speed, float v_min, float v_max, const char* format, float power)
{
    return DragScalarN(label, ImGuiDataType_Float, v, 2, v_speed, &v_min, &v_max, format, power);
}

bool ImGui::DragFloat3(const char* label, float v[3], float v_speed, float v_min, float v_max, const char* format, float power)
{
    return DragScalarN(label, ImGuiDataType_Float, v, 3, v_speed, &v_min, &v_max, format, power);
}

bool ImGui::DragFloat4(const char* label, float v[4], float v_speed, float v_min, float v_max, const char* format, float power)
{
    return DragScalarN(label, ImGuiDataType_Float, v, 4, v_speed, &v_min, &v_max, format, power);
}

bool ImGui::DragFloatRange2(const char* label, float* v_current_min, float* v_current_max, float v_speed, float v_min, float v_max, const char* format, const char* format_max, float power)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    PushID(label);
    BeginGroup();
    PushMultiItemsWidths(2);

    bool value_changed = DragFloat("##min", v_current_min, v_speed, (v_min >= v_max) ? -FLT_MAX : v_min, (v_min >= v_max) ? *v_current_max : ImMin(v_max, *v_current_max), format, power);
    PopItemWidth();
    SameLine(0, g.Style.ItemInnerSpacing.x);
    value_changed |= DragFloat("##max", v_current_max, v_speed, (v_min >= v_max) ? *v_current_min : ImMax(v_min, *v_current_min), (v_min >= v_max) ? FLT_MAX : v_max, format_max ? format_max : format, power);
    PopItemWidth();
    SameLine(0, g.Style.ItemInnerSpacing.x);

    TextUnformatted(label, FindRenderedTextEnd(label));
    EndGroup();
    PopID();
    return value_changed;
}

// NB: v_speed is float to allow adjusting the drag speed with more precision
bool ImGui::DragInt(const char* label, int* v, float v_speed, int v_min, int v_max, const char* format)
{
    return DragScalar(label, ImGuiDataType_S32, v, v_speed, &v_min, &v_max, format);
}

bool ImGui::DragInt2(const char* label, int v[2], float v_speed, int v_min, int v_max, const char* format)
{
    return DragScalarN(label, ImGuiDataType_S32, v, 2, v_speed, &v_min, &v_max, format);
}

bool ImGui::DragInt3(const char* label, int v[3], float v_speed, int v_min, int v_max, const char* format)
{
    return DragScalarN(label, ImGuiDataType_S32, v, 3, v_speed, &v_min, &v_max, format);
}

bool ImGui::DragInt4(const char* label, int v[4], float v_speed, int v_min, int v_max, const char* format)
{
    return DragScalarN(label, ImGuiDataType_S32, v, 4, v_speed, &v_min, &v_max, format);
}

bool ImGui::DragIntRange2(const char* label, int* v_current_min, int* v_current_max, float v_speed, int v_min, int v_max, const char* format, const char* format_max)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    PushID(label);
    BeginGroup();
    PushMultiItemsWidths(2);

    bool value_changed = DragInt("##min", v_current_min, v_speed, (v_min >= v_max) ? INT_MIN : v_min, (v_min >= v_max) ? *v_current_max : ImMin(v_max, *v_current_max), format);
    PopItemWidth();
    SameLine(0, g.Style.ItemInnerSpacing.x);
    value_changed |= DragInt("##max", v_current_max, v_speed, (v_min >= v_max) ? *v_current_min : ImMax(v_min, *v_current_min), (v_min >= v_max) ? INT_MAX : v_max, format_max ? format_max : format);
    PopItemWidth();
    SameLine(0, g.Style.ItemInnerSpacing.x);

    TextUnformatted(label, FindRenderedTextEnd(label));
    EndGroup();
    PopID();

    return value_changed;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: SliderScalar, SliderFloat, SliderInt, etc.
//-------------------------------------------------------------------------
// - SliderBehaviorT<>() [Internal]
// - SliderBehavior() [Internal]
// - SliderScalar()
// - SliderScalarN()
// - SliderFloat()
// - SliderFloat2()
// - SliderFloat3()
// - SliderFloat4()
// - SliderAngle()
// - SliderInt()
// - SliderInt2()
// - SliderInt3()
// - SliderInt4()
// - VSliderScalar()
// - VSliderFloat()
// - VSliderInt()
//-------------------------------------------------------------------------

template<typename TYPE, typename FLOATTYPE>
float ImGui::SliderCalcRatioFromValueT(ImGuiDataType data_type, TYPE v, TYPE v_min, TYPE v_max, float power, float linear_zero_pos)
{
    if (v_min == v_max)
        return 0.0f;

    const bool is_power = (power != 1.0f) && (data_type == ImGuiDataType_Float || data_type == ImGuiDataType_Double);
    const TYPE v_clamped = (v_min < v_max) ? ImClamp(v, v_min, v_max) : ImClamp(v, v_max, v_min);
    if (is_power)
    {
        if (v_clamped < 0.0f)
        {
            const float f = 1.0f - (float)((v_clamped - v_min) / (ImMin((TYPE)0, v_max) - v_min));
            return (1.0f - ImPow(f, 1.0f/power)) * linear_zero_pos;
        }
        else
        {
            const float f = (float)((v_clamped - ImMax((TYPE)0, v_min)) / (v_max - ImMax((TYPE)0, v_min)));
            return linear_zero_pos + ImPow(f, 1.0f/power) * (1.0f - linear_zero_pos);
        }
    }

    // Linear slider
    return (float)((FLOATTYPE)(v_clamped - v_min) / (FLOATTYPE)(v_max - v_min));
}

// FIXME: Move some of the code into SliderBehavior(). Current responsability is larger than what the equivalent DragBehaviorT<> does, we also do some rendering, etc.
template<typename TYPE, typename SIGNEDTYPE, typename FLOATTYPE>
bool ImGui::SliderBehaviorT(const ImRect& bb, ImGuiID id, ImGuiDataType data_type, TYPE* v, const TYPE v_min, const TYPE v_max, const char* format, float power, ImGuiSliderFlags flags, ImRect* out_grab_bb)
{
    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    const ImGuiAxis axis = (flags & ImGuiSliderFlags_Vertical) ? ImGuiAxis_Y : ImGuiAxis_X;
    const bool is_decimal = (data_type == ImGuiDataType_Float) || (data_type == ImGuiDataType_Double);
    const bool is_power = (power != 1.0f) && is_decimal;

    const float grab_padding = 2.0f;
    const float slider_sz = (bb.Max[axis] - bb.Min[axis]) - grab_padding * 2.0f;
    float grab_sz = style.GrabMinSize;
    SIGNEDTYPE v_range = (v_min < v_max ? v_max - v_min : v_min - v_max);
    if (!is_decimal && v_range >= 0)                                             // v_range < 0 may happen on integer overflows
        grab_sz = ImMax((float)(slider_sz / (v_range + 1)), style.GrabMinSize);  // For integer sliders: if possible have the grab size represent 1 unit
    grab_sz = ImMin(grab_sz, slider_sz);
    const float slider_usable_sz = slider_sz - grab_sz;
    const float slider_usable_pos_min = bb.Min[axis] + grab_padding + grab_sz*0.5f;
    const float slider_usable_pos_max = bb.Max[axis] - grab_padding - grab_sz*0.5f;

    // For power curve sliders that cross over sign boundary we want the curve to be symmetric around 0.0f
    float linear_zero_pos;   // 0.0->1.0f
    if (is_power && v_min * v_max < 0.0f)
    {
        // Different sign
        const FLOATTYPE linear_dist_min_to_0 = ImPow(v_min >= 0 ? (FLOATTYPE)v_min : -(FLOATTYPE)v_min, (FLOATTYPE)1.0f/power);
        const FLOATTYPE linear_dist_max_to_0 = ImPow(v_max >= 0 ? (FLOATTYPE)v_max : -(FLOATTYPE)v_max, (FLOATTYPE)1.0f/power);
        linear_zero_pos = (float)(linear_dist_min_to_0 / (linear_dist_min_to_0 + linear_dist_max_to_0));
    }
    else
    {
        // Same sign
        linear_zero_pos = v_min < 0.0f ? 1.0f : 0.0f;
    }

    // Process interacting with the slider
    bool value_changed = false;
    if (g.ActiveId == id)
    {
        bool set_new_value = false;
        float clicked_t = 0.0f;
        if (g.ActiveIdSource == ImGuiInputSource_Mouse)
        {
            if (!g.IO.MouseDown[0])
            {
                ClearActiveID();
            }
            else
            {
                const float mouse_abs_pos = g.IO.MousePos[axis];
                clicked_t = (slider_usable_sz > 0.0f) ? ImClamp((mouse_abs_pos - slider_usable_pos_min) / slider_usable_sz, 0.0f, 1.0f) : 0.0f;
                if (axis == ImGuiAxis_Y)
                    clicked_t = 1.0f - clicked_t;
                set_new_value = true;
            }
        }
        else if (g.ActiveIdSource == ImGuiInputSource_Nav)
        {
            const ImVec2 delta2 = GetNavInputAmount2d(ImGuiNavDirSourceFlags_Keyboard | ImGuiNavDirSourceFlags_PadDPad, ImGuiInputReadMode_RepeatFast, 0.0f, 0.0f);
            float delta = (axis == ImGuiAxis_X) ? delta2.x : -delta2.y;
            if (g.NavActivatePressedId == id && !g.ActiveIdIsJustActivated)
            {
                ClearActiveID();
            }
            else if (delta != 0.0f)
            {
                clicked_t = SliderCalcRatioFromValueT<TYPE,FLOATTYPE>(data_type, *v, v_min, v_max, power, linear_zero_pos);
                const int decimal_precision = is_decimal ? ImParseFormatPrecision(format, 3) : 0;
                if ((decimal_precision > 0) || is_power)
                {
                    delta /= 100.0f;    // Gamepad/keyboard tweak speeds in % of slider bounds
                    if (IsNavInputDown(ImGuiNavInput_TweakSlow))
                        delta /= 10.0f;
                }
                else
                {
                    if ((v_range >= -100.0f && v_range <= 100.0f) || IsNavInputDown(ImGuiNavInput_TweakSlow))
                        delta = ((delta < 0.0f) ? -1.0f : +1.0f) / (float)v_range; // Gamepad/keyboard tweak speeds in integer steps
                    else
                        delta /= 100.0f;
                }
                if (IsNavInputDown(ImGuiNavInput_TweakFast))
                    delta *= 10.0f;
                set_new_value = true;
                if ((clicked_t >= 1.0f && delta > 0.0f) || (clicked_t <= 0.0f && delta < 0.0f)) // This is to avoid applying the saturation when already past the limits
                    set_new_value = false;
                else
                    clicked_t = ImSaturate(clicked_t + delta);
            }
        }

        if (set_new_value)
        {
            TYPE v_new;
            if (is_power)
            {
                // Account for power curve scale on both sides of the zero
                if (clicked_t < linear_zero_pos)
                {
                    // Negative: rescale to the negative range before powering
                    float a = 1.0f - (clicked_t / linear_zero_pos);
                    a = ImPow(a, power);
                    v_new = ImLerp(ImMin(v_max, (TYPE)0), v_min, a);
                }
                else
                {
                    // Positive: rescale to the positive range before powering
                    float a;
                    if (ImFabs(linear_zero_pos - 1.0f) > 1.e-6f)
                        a = (clicked_t - linear_zero_pos) / (1.0f - linear_zero_pos);
                    else
                        a = clicked_t;
                    a = ImPow(a, power);
                    v_new = ImLerp(ImMax(v_min, (TYPE)0), v_max, a);
                }
            }
            else
            {
                // Linear slider
                if (is_decimal)
                {
                    v_new = ImLerp(v_min, v_max, clicked_t);
                }
                else
                {
                    // For integer values we want the clicking position to match the grab box so we round above
                    // This code is carefully tuned to work with large values (e.g. high ranges of U64) while preserving this property..
                    FLOATTYPE v_new_off_f = (v_max - v_min) * clicked_t;
                    TYPE v_new_off_floor = (TYPE)(v_new_off_f);
                    TYPE v_new_off_round = (TYPE)(v_new_off_f + (FLOATTYPE)0.5);
                    if (!is_decimal && v_new_off_floor < v_new_off_round)
                        v_new = v_min + v_new_off_round;
                    else
                        v_new = v_min + v_new_off_floor;
                }
            }

            // Round to user desired precision based on format string
            v_new = RoundScalarWithFormatT<TYPE,SIGNEDTYPE>(format, data_type, v_new);

            // Apply result
            if (*v != v_new)
            {
                *v = v_new;
                value_changed = true;
            }
        }
    }

    // Output grab position so it can be displayed by the caller
    float grab_t = SliderCalcRatioFromValueT<TYPE,FLOATTYPE>(data_type, *v, v_min, v_max, power, linear_zero_pos);
    if (axis == ImGuiAxis_Y)
        grab_t = 1.0f - grab_t;
    const float grab_pos = ImLerp(slider_usable_pos_min, slider_usable_pos_max, grab_t);
    if (axis == ImGuiAxis_X)
        *out_grab_bb = ImRect(grab_pos - grab_sz*0.5f, bb.Min.y + grab_padding, grab_pos + grab_sz*0.5f, bb.Max.y - grab_padding);
    else
        *out_grab_bb = ImRect(bb.Min.x + grab_padding, grab_pos - grab_sz*0.5f, bb.Max.x - grab_padding, grab_pos + grab_sz*0.5f);

    return value_changed;
}

// For 32-bits and larger types, slider bounds are limited to half the natural type range.
// So e.g. an integer Slider between INT_MAX-10 and INT_MAX will fail, but an integer Slider between INT_MAX/2-10 and INT_MAX/2 will be ok.
// It would be possible to lift that limitation with some work but it doesn't seem to be worth it for sliders.
bool ImGui::SliderBehavior(const ImRect& bb, ImGuiID id, ImGuiDataType data_type, void* v, const void* v_min, const void* v_max, const char* format, float power, ImGuiSliderFlags flags, ImRect* out_grab_bb)
{
    switch (data_type)
    {
    case ImGuiDataType_S32:
        IM_ASSERT(*(const ImS32*)v_min >= IM_S32_MIN/2 && *(const ImS32*)v_max <= IM_S32_MAX/2);
        return SliderBehaviorT<ImS32, ImS32, float >(bb, id, data_type, (ImS32*)v,  *(const ImS32*)v_min,  *(const ImS32*)v_max,  format, power, flags, out_grab_bb);
    case ImGuiDataType_U32:
        IM_ASSERT(*(const ImU32*)v_min <= IM_U32_MAX/2);
        return SliderBehaviorT<ImU32, ImS32, float >(bb, id, data_type, (ImU32*)v,  *(const ImU32*)v_min,  *(const ImU32*)v_max,  format, power, flags, out_grab_bb);
    case ImGuiDataType_S64:
        IM_ASSERT(*(const ImS64*)v_min >= IM_S64_MIN/2 && *(const ImS64*)v_max <= IM_S64_MAX/2);
        return SliderBehaviorT<ImS64, ImS64, double>(bb, id, data_type, (ImS64*)v,  *(const ImS64*)v_min,  *(const ImS64*)v_max,  format, power, flags, out_grab_bb);
    case ImGuiDataType_U64:
        IM_ASSERT(*(const ImU64*)v_min <= IM_U64_MAX/2);
        return SliderBehaviorT<ImU64, ImS64, double>(bb, id, data_type, (ImU64*)v,  *(const ImU64*)v_min,  *(const ImU64*)v_max,  format, power, flags, out_grab_bb);
    case ImGuiDataType_Float:
        IM_ASSERT(*(const float*)v_min >= -FLT_MAX/2.0f && *(const float*)v_max <= FLT_MAX/2.0f);
        return SliderBehaviorT<float, float, float >(bb, id, data_type, (float*)v,  *(const float*)v_min,  *(const float*)v_max,  format, power, flags, out_grab_bb);
    case ImGuiDataType_Double:
        IM_ASSERT(*(const double*)v_min >= -DBL_MAX/2.0f && *(const double*)v_max <= DBL_MAX/2.0f);
        return SliderBehaviorT<double,double,double>(bb, id, data_type, (double*)v, *(const double*)v_min, *(const double*)v_max, format, power, flags, out_grab_bb);
    case ImGuiDataType_COUNT: break;
    }
    IM_ASSERT(0);
    return false;
}

bool ImGui::SliderScalar(const char* label, ImGuiDataType data_type, void* v, const void* v_min, const void* v_max, const char* format, float power)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const float w = CalcItemWidth();

    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    const ImRect frame_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(w, label_size.y + style.FramePadding.y * 2.0f));
    const ImRect total_bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f, 0.0f));

    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id, &frame_bb))
        return false;

    // Default format string when passing NULL
    // Patch old "%.0f" format string to use "%d", read function comments for more details.
    IM_ASSERT(data_type >= 0 && data_type < ImGuiDataType_COUNT);
    if (format == NULL)
        format = GDataTypeInfo[data_type].PrintFmt;
    else if (data_type == ImGuiDataType_S32 && strcmp(format, "%d") != 0)
        format = PatchFormatStringFloatToInt(format);

    // Tabbing or CTRL-clicking on Slider turns it into an input box
    bool start_text_input = false;
    const bool focus_requested = FocusableItemRegister(window, id);
    const bool hovered = ItemHoverable(frame_bb, id);
    if (focus_requested || (hovered && g.IO.MouseClicked[0]) || g.NavActivateId == id || (g.NavInputId == id && g.ScalarAsInputTextId != id))
    {
        SetActiveID(id, window);
        SetFocusID(id, window);
        FocusWindow(window);
        g.ActiveIdAllowNavDirFlags = (1 << ImGuiDir_Up) | (1 << ImGuiDir_Down);
        if (focus_requested || g.IO.KeyCtrl || g.NavInputId == id)
        {
            start_text_input = true;
            g.ScalarAsInputTextId = 0;
        }
    }
    if (start_text_input || (g.ActiveId == id && g.ScalarAsInputTextId == id))
    {
        window->DC.CursorPos = frame_bb.Min;
        FocusableItemUnregister(window);
        return InputScalarAsWidgetReplacement(frame_bb, id, label, data_type, v, format);
    }

    // Draw frame
    const ImU32 frame_col = GetColorU32(g.ActiveId == id ? ImGuiCol_FrameBgActive : g.HoveredId == id ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg);
    //RenderNavHighlight(frame_bb, id);
    //RenderFrame(frame_bb.Min, frame_bb.Max, frame_col, true, g.Style.FrameRounding);

    // Slider behavior
    ImRect grab_bb;
    const bool value_changed = SliderBehavior(frame_bb, id, data_type, v, v_min, v_max, format, power, ImGuiSliderFlags_None, &grab_bb);
    if (value_changed)
        MarkItemEdited(id);

    /*
    // Render grab
    window->DrawList->AddRectFilled(grab_bb.Min, grab_bb.Max, GetColorU32(g.ActiveId == id ? ImGuiCol_SliderGrabActive : ImGuiCol_SliderGrab), style.GrabRounding);

    // Display value using user-provided display format so user can add prefix/suffix/decorations to the value.���� ���� ����� ������ ������ ���� ��� ����� ��������?

    char value_buf[64];
    const char* value_buf_end = value_buf + DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, v, format);
    RenderTextClipped(frame_bb.Min, frame_bb.Max, value_buf, value_buf_end, NULL, ImVec2(0.5f,0.5f));

    if (label_size.x > 0.0f)
        RenderText(ImVec2(frame_bb.Max.x + style.ItemInnerSpacing.x, frame_bb.Min.y + style.FramePadding.y), label);
    */
    char value_buf[3][64];
    const char* value_buf_end[3];
    value_buf_end[0] = value_buf[0] + DataTypeFormatString(value_buf[0], IM_ARRAYSIZE(value_buf[0]), data_type, v, format);
    value_buf_end[1] = value_buf[1] + DataTypeFormatString(value_buf[1], IM_ARRAYSIZE(value_buf[1]), data_type, v_min, format);
    value_buf_end[2] = value_buf[2] + DataTypeFormatString(value_buf[2], IM_ARRAYSIZE(value_buf[2]), data_type, v_max, format);
    // RenderTextClipped(frame_bb.Min, frame_bb.Max, value_buf, value_buf_end, NULL, ImVec2(0.5f,0.5f));

    //RenderText(ImVec2(grab_bb.Max.x, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) + ImVec2(-3, 10), value_buf[0], value_buf_end[0]);
    //RenderText(grab_bb.Min + ((grab_bb.Max - grab_bb.Min) / 2.f) + ImVec2(-3, 10), value_buf[0], value_buf_end[0]);
    //RenderText(frame_bb.Min + ImVec2(0, (grab_bb.Max - grab_bb.Min).y / 2.f + 12), value_buf[1], value_buf_end[1]);
    //RenderText(frame_bb.Min + ImVec2(frame_bb.Max.x - frame_bb.Min.x - 8, (grab_bb.Max - grab_bb.Min).y / 2.f + 12), value_buf[2], value_buf_end[2]); ������

    //RenderFrame(ImVec2(frame_bb.Min.x, frame_bb.Min.y + ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) - ImVec2(0, 3), ImVec2(frame_bb.Max.x, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) + ImVec2(0, 3), ImColor(10, 36, 54), true, style.FrameRounding);
    //RenderFrame(ImVec2(frame_bb.Min.x, frame_bb.Min.y + ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) - ImVec2(0, 3), ImVec2(grab_bb.Min.x + (grab_bb.Max.x - grab_bb.Min.x) / 2.f, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) + ImVec2(0, 3), ImColor(255, 255, 255), true, style.FrameRounding);
    //RenderFrame(ImVec2(frame_bb.Min.x, frame_bb.Min.y + ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) - ImVec2(0, 3), ImVec2(grab_bb.Max.x, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) + ImVec2(0, 3), ImColor(255, 255, 255), true, style.FrameRounding);
    // ��� ����� ����������� ��������������, � �� �� �����
    //ImVec2(grab_bb.Max.x, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f))
    //window->DrawList->AddCircleFilled(grab_bb.Min + ((grab_bb.Max - grab_bb.Min) / 2.f), 8.f, ImColor(255, 255, 255), 64); // ��� �����
    //window->DrawList->AddCircleFilled(ImVec2(grab_bb.Max.x, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)), 8.f, ImColor(255, 255, 255), 64);
    RenderText(ImVec2(grab_bb.Min.x, grab_bb.Min.y + ((grab_bb.Max.y - grab_bb.Min.y) / 2.f)) + ImVec2(-3, 10), value_buf[0], value_buf_end[0]);
    RenderFrame(ImVec2(frame_bb.Min.x, frame_bb.Min.y + ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) - ImVec2(0, 3), ImVec2(frame_bb.Max.x - grab_bb.Max.x + grab_bb.Min.x, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) + ImVec2(0, 3), ImColor(10, 36, 54), true, style.FrameRounding);
    RenderFrame(ImVec2(frame_bb.Min.x, frame_bb.Min.y + ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) - ImVec2(0, 3), ImVec2(grab_bb.Min.x, frame_bb.Max.y - ((frame_bb.Max.y - frame_bb.Min.y) / 2.f)) + ImVec2(0, 3), ImColor(255, 255, 255), true, style.FrameRounding);
    window->DrawList->AddCircleFilled(ImVec2(grab_bb.Min.x, grab_bb.Min.y + ((grab_bb.Max.y - grab_bb.Min.y) / 2.f)), 8.f, ImColor(255, 255, 255), 64);


    // Display value using user-provided display format so user can add prefix/suffix/decorations to the value. (grab_bb.Max.x, ��� ������� ������ ��� �� ������ ����� ����� �� �������� grab_bb.max
    if (label_size.x > 0.0f)
        RenderText(ImVec2(frame_bb.Max.x - grab_bb.Max.x + grab_bb.Min.x + style.ItemInnerSpacing.x, frame_bb.Min.y + style.FramePadding.y), label);


    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, window->DC.ItemFlags);
    return value_changed;
}

// Add multiple sliders on 1 line for compact edition of multiple components
bool ImGui::SliderScalarN(const char* label, ImGuiDataType data_type, void* v, int components, const void* v_min, const void* v_max, const char* format, float power)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    bool value_changed = false;
    BeginGroup();
    PushID(label);
    PushMultiItemsWidths(components);
    size_t type_size = GDataTypeInfo[data_type].Size;
    for (int i = 0; i < components; i++)
    {
        PushID(i);
        value_changed |= SliderScalar("", data_type, v, v_min, v_max, format, power);
        SameLine(0, g.Style.ItemInnerSpacing.x);
        PopID();
        PopItemWidth();
        v = (void*)((char*)v + type_size);
    }
    PopID();

    TextUnformatted(label, FindRenderedTextEnd(label));
    EndGroup();
    return value_changed;
}

bool ImGui::SliderFloat(const char* label, float* v, float v_min, float v_max, const char* format, float power)
{
    return SliderScalar(label, ImGuiDataType_Float, v, &v_min, &v_max, format, power);
}

bool ImGui::SliderFloat2(const char* label, float v[2], float v_min, float v_max, const char* format, float power)
{
    return SliderScalarN(label, ImGuiDataType_Float, v, 2, &v_min, &v_max, format, power);
}

bool ImGui::SliderFloat3(const char* label, float v[3], float v_min, float v_max, const char* format, float power)
{
    return SliderScalarN(label, ImGuiDataType_Float, v, 3, &v_min, &v_max, format, power);
}

bool ImGui::SliderFloat4(const char* label, float v[4], float v_min, float v_max, const char* format, float power)
{
    return SliderScalarN(label, ImGuiDataType_Float, v, 4, &v_min, &v_max, format, power);
}

bool ImGui::SliderAngle(const char* label, float* v_rad, float v_degrees_min, float v_degrees_max, const char* format)
{
    if (format == NULL)
        format = "%.0f deg";
    float v_deg = (*v_rad) * 360.0f / (2*IM_PI);
    bool value_changed = SliderFloat(label, &v_deg, v_degrees_min, v_degrees_max, format, 1.0f);
    *v_rad = v_deg * (2*IM_PI) / 360.0f;
    return value_changed;
}

bool ImGui::SliderInt(const char* label, int* v, int v_min, int v_max, const char* format)
{
    return SliderScalar(label, ImGuiDataType_S32, v, &v_min, &v_max, format);
}

bool ImGui::SliderInt2(const char* label, int v[2], int v_min, int v_max, const char* format)
{
    return SliderScalarN(label, ImGuiDataType_S32, v, 2, &v_min, &v_max, format);
}

bool ImGui::SliderInt3(const char* label, int v[3], int v_min, int v_max, const char* format)
{
    return SliderScalarN(label, ImGuiDataType_S32, v, 3, &v_min, &v_max, format);
}

bool ImGui::SliderInt4(const char* label, int v[4], int v_min, int v_max, const char* format)
{
    return SliderScalarN(label, ImGuiDataType_S32, v, 4, &v_min, &v_max, format);
}

bool ImGui::VSliderScalar(const char* label, const ImVec2& size, ImGuiDataType data_type, void* v, const void* v_min, const void* v_max, const char* format, float power)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    const ImRect frame_bb(window->DC.CursorPos, window->DC.CursorPos + size);
    const ImRect bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f, 0.0f));

    ItemSize(bb, style.FramePadding.y);
    if (!ItemAdd(frame_bb, id))
        return false;

    // Default format string when passing NULL
    // Patch old "%.0f" format string to use "%d", read function comments for more details.
    IM_ASSERT(data_type >= 0 && data_type < ImGuiDataType_COUNT);
    if (format == NULL)
        format = GDataTypeInfo[data_type].PrintFmt;
    else if (data_type == ImGuiDataType_S32 && strcmp(format, "%d") != 0)
        format = PatchFormatStringFloatToInt(format);

    const bool hovered = ItemHoverable(frame_bb, id);
    if ((hovered && g.IO.MouseClicked[0]) || g.NavActivateId == id || g.NavInputId == id)
    {
        SetActiveID(id, window);
        SetFocusID(id, window);
        FocusWindow(window);
        g.ActiveIdAllowNavDirFlags = (1 << ImGuiDir_Left) | (1 << ImGuiDir_Right);
    }

    // Draw frame
    const ImU32 frame_col = GetColorU32(g.ActiveId == id ? ImGuiCol_FrameBgActive : g.HoveredId == id ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg);
    RenderNavHighlight(frame_bb, id);
    RenderFrame(frame_bb.Min, frame_bb.Max, frame_col, true, g.Style.FrameRounding);

    // Slider behavior
    ImRect grab_bb;
    const bool value_changed = SliderBehavior(frame_bb, id, data_type, v, v_min, v_max, format, power, ImGuiSliderFlags_Vertical, &grab_bb);
    if (value_changed)
        MarkItemEdited(id);

    // Render grab
    window->DrawList->AddRectFilled(grab_bb.Min, grab_bb.Max, GetColorU32(g.ActiveId == id ? ImGuiCol_SliderGrabActive : ImGuiCol_SliderGrab), style.GrabRounding);

    // Display value using user-provided display format so user can add prefix/suffix/decorations to the value.
    // For the vertical slider we allow centered text to overlap the frame padding
    char value_buf[64];
    const char* value_buf_end = value_buf + DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, v, format);
    RenderTextClipped(ImVec2(frame_bb.Min.x, frame_bb.Min.y + style.FramePadding.y), frame_bb.Max, value_buf, value_buf_end, NULL, ImVec2(0.5f,0.0f));
    if (label_size.x > 0.0f)
        RenderText(ImVec2(frame_bb.Max.x + style.ItemInnerSpacing.x, frame_bb.Min.y + style.FramePadding.y), label);

    return value_changed;
}

bool ImGui::VSliderFloat(const char* label, const ImVec2& size, float* v, float v_min, float v_max, const char* format, float power)
{
    return VSliderScalar(label, size, ImGuiDataType_Float, v, &v_min, &v_max, format, power);
}

bool ImGui::VSliderInt(const char* label, const ImVec2& size, int* v, int v_min, int v_max, const char* format)
{
    return VSliderScalar(label, size, ImGuiDataType_S32, v, &v_min, &v_max, format);
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: InputScalar, InputFloat, InputInt, etc.
//-------------------------------------------------------------------------
// - ImParseFormatFindStart() [Internal]
// - ImParseFormatFindEnd() [Internal]
// - ImParseFormatTrimDecorations() [Internal]
// - ImParseFormatPrecision() [Internal]
// - InputScalarAsWidgetReplacement() [Internal]
// - InputScalar()
// - InputScalarN()
// - InputFloat()
// - InputFloat2()
// - InputFloat3()
// - InputFloat4()
// - InputInt()
// - InputInt2()
// - InputInt3()
// - InputInt4()
// - InputDouble()
//-------------------------------------------------------------------------

// We don't use strchr() because our strings are usually very short and often start with '%'
const char* ImParseFormatFindStart(const char* fmt)
{
    while (char c = fmt[0])
    {
        if (c == '%' && fmt[1] != '%')
            return fmt;
        else if (c == '%')
            fmt++;
        fmt++;
    }
    return fmt;
}

const char* ImParseFormatFindEnd(const char* fmt)
{
    // Printf/scanf types modifiers: I/L/h/j/l/t/w/z. Other uppercase letters qualify as types aka end of the format.
    if (fmt[0] != '%')
        return fmt;
    const unsigned int ignored_uppercase_mask = (1 << ('I'-'A')) | (1 << ('L'-'A'));
    const unsigned int ignored_lowercase_mask = (1 << ('h'-'a')) | (1 << ('j'-'a')) | (1 << ('l'-'a')) | (1 << ('t'-'a')) | (1 << ('w'-'a')) | (1 << ('z'-'a'));
    for (char c; (c = *fmt) != 0; fmt++)
    {
        if (c >= 'A' && c <= 'Z' && ((1 << (c - 'A')) & ignored_uppercase_mask) == 0)
            return fmt + 1;
        if (c >= 'a' && c <= 'z' && ((1 << (c - 'a')) & ignored_lowercase_mask) == 0)
            return fmt + 1;
    }
    return fmt;
}

// Extract the format out of a format string with leading or trailing decorations
//  fmt = "blah blah"  -> return fmt
//  fmt = "%.3f"       -> return fmt
//  fmt = "hello %.3f" -> return fmt + 6
//  fmt = "%.3f hello" -> return buf written with "%.3f"
const char* ImParseFormatTrimDecorations(const char* fmt, char* buf, size_t buf_size)
{
    const char* fmt_start = ImParseFormatFindStart(fmt);
    if (fmt_start[0] != '%')
        return fmt;
    const char* fmt_end = ImParseFormatFindEnd(fmt_start);
    if (fmt_end[0] == 0) // If we only have leading decoration, we don't need to copy the data.
        return fmt_start;
    ImStrncpy(buf, fmt_start, ImMin((size_t)(fmt_end - fmt_start) + 1, buf_size));
    return buf;
}

// Parse display precision back from the display format string
// FIXME: This is still used by some navigation code path to infer a minimum tweak step, but we should aim to rework widgets so it isn't needed.
int ImParseFormatPrecision(const char* fmt, int default_precision)
{
    fmt = ImParseFormatFindStart(fmt);
    if (fmt[0] != '%')
        return default_precision;
    fmt++;
    while (*fmt >= '0' && *fmt <= '9')
        fmt++;
    int precision = INT_MAX;
    if (*fmt == '.')
    {
        fmt = ImAtoi<int>(fmt + 1, &precision);
        if (precision < 0 || precision > 99)
            precision = default_precision;
    }
    if (*fmt == 'e' || *fmt == 'E') // Maximum precision with scientific notation
        precision = -1;
    if ((*fmt == 'g' || *fmt == 'G') && precision == INT_MAX)
        precision = -1;
    return (precision == INT_MAX) ? default_precision : precision;
}

// Create text input in place of an active drag/slider (used when doing a CTRL+Click on drag/slider widgets)
// FIXME: Facilitate using this in variety of other situations.
bool ImGui::InputScalarAsWidgetReplacement(const ImRect& bb, ImGuiID id, const char* label, ImGuiDataType data_type, void* data_ptr, const char* format)
{
    IM_UNUSED(id);
    ImGuiContext& g = *GImGui;

    // On the first frame, g.ScalarAsInputTextId == 0, then on subsequent frames it becomes == id.
    // We clear ActiveID on the first frame to allow the InputText() taking it back.
    if (g.ScalarAsInputTextId == 0)
        ClearActiveID();

    char fmt_buf[32];
    char data_buf[32];
    format = ImParseFormatTrimDecorations(format, fmt_buf, IM_ARRAYSIZE(fmt_buf));
    DataTypeFormatString(data_buf, IM_ARRAYSIZE(data_buf), data_type, data_ptr, format);
    ImStrTrimBlanks(data_buf);
    ImGuiInputTextFlags flags = ImGuiInputTextFlags_AutoSelectAll | ((data_type == ImGuiDataType_Float || data_type == ImGuiDataType_Double) ? ImGuiInputTextFlags_CharsScientific : ImGuiInputTextFlags_CharsDecimal);
    bool value_changed = InputTextEx(label, data_buf, IM_ARRAYSIZE(data_buf), bb.GetSize(), flags);
    if (g.ScalarAsInputTextId == 0)
    {
        // First frame we started displaying the InputText widget, we expect it to take the active id.
        IM_ASSERT(g.ActiveId == id);
        g.ScalarAsInputTextId = g.ActiveId;
    }
    if (value_changed)
        return DataTypeApplyOpFromText(data_buf, g.InputTextState.InitialTextA.Data, data_type, data_ptr, NULL);
    return false;
}

bool ImGui::InputScalar(const char* label, ImGuiDataType data_type, void* data_ptr, const void* step, const void* step_fast, const char* format, ImGuiInputTextFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    ImGuiStyle& style = g.Style;

    IM_ASSERT(data_type >= 0 && data_type < ImGuiDataType_COUNT);
    if (format == NULL)
        format = GDataTypeInfo[data_type].PrintFmt;

    char buf[64];
    DataTypeFormatString(buf, IM_ARRAYSIZE(buf), data_type, data_ptr, format);

    bool value_changed = false;
    if ((flags & (ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsScientific)) == 0)
        flags |= ImGuiInputTextFlags_CharsDecimal;
    flags |= ImGuiInputTextFlags_AutoSelectAll;

    if (step != NULL)
    {
        const float button_size = GetFrameHeight();

        BeginGroup(); // The only purpose of the group here is to allow the caller to query item data e.g. IsItemActive()
        PushID(label);
        PushItemWidth(ImMax(1.0f, CalcItemWidth() - (button_size + style.ItemInnerSpacing.x) * 2));
        if (InputText("", buf, IM_ARRAYSIZE(buf), flags)) // PushId(label) + "" gives us the expected ID from outside point of view
            value_changed = DataTypeApplyOpFromText(buf, g.InputTextState.InitialTextA.Data, data_type, data_ptr, format);
        PopItemWidth();

        // Step buttons
        const ImVec2 backup_frame_padding = style.FramePadding;
        style.FramePadding.x = style.FramePadding.y;
        ImGuiButtonFlags button_flags = ImGuiButtonFlags_Repeat | ImGuiButtonFlags_DontClosePopups;
        if (flags & ImGuiInputTextFlags_ReadOnly)
            button_flags |= ImGuiButtonFlags_Disabled;
        SameLine(0, style.ItemInnerSpacing.x);
        if (ButtonEx("-", ImVec2(button_size, button_size), button_flags))
        {
            DataTypeApplyOp(data_type, '-', data_ptr, data_ptr, g.IO.KeyCtrl && step_fast ? step_fast : step);
            value_changed = true;
        }
        SameLine(0, style.ItemInnerSpacing.x);
        if (ButtonEx("+", ImVec2(button_size, button_size), button_flags))
        {
            DataTypeApplyOp(data_type, '+', data_ptr, data_ptr, g.IO.KeyCtrl && step_fast ? step_fast : step);
            value_changed = true;
        }
        SameLine(0, style.ItemInnerSpacing.x);
        TextUnformatted(label, FindRenderedTextEnd(label));
        style.FramePadding = backup_frame_padding;

        PopID();
        EndGroup();
    }
    else
    {
        if (InputText(label, buf, IM_ARRAYSIZE(buf), flags))
            value_changed = DataTypeApplyOpFromText(buf, g.InputTextState.InitialTextA.Data, data_type, data_ptr, format);
    }

    return value_changed;
}

bool ImGui::InputScalarN(const char* label, ImGuiDataType data_type, void* v, int components, const void* step, const void* step_fast, const char* format, ImGuiInputTextFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    bool value_changed = false;
    BeginGroup();
    PushID(label);
    PushMultiItemsWidths(components);
    size_t type_size = GDataTypeInfo[data_type].Size;
    for (int i = 0; i < components; i++)
    {
        PushID(i);
        value_changed |= InputScalar("", data_type, v, step, step_fast, format, flags);
        SameLine(0, g.Style.ItemInnerSpacing.x);
        PopID();
        PopItemWidth();
        v = (void*)((char*)v + type_size);
    }
    PopID();

    TextUnformatted(label, FindRenderedTextEnd(label));
    EndGroup();
    return value_changed;
}

bool ImGui::InputFloat(const char* label, float* v, float step, float step_fast, const char* format, ImGuiInputTextFlags flags)
{
    flags |= ImGuiInputTextFlags_CharsScientific;
    return InputScalar(label, ImGuiDataType_Float, (void*)v, (void*)(step>0.0f ? &step : NULL), (void*)(step_fast>0.0f ? &step_fast : NULL), format, flags);
}

bool ImGui::InputFloat2(const char* label, float v[2], const char* format, ImGuiInputTextFlags flags)
{
    return InputScalarN(label, ImGuiDataType_Float, v, 2, NULL, NULL, format, flags);
}

bool ImGui::InputFloat3(const char* label, float v[3], const char* format, ImGuiInputTextFlags flags)
{
    return InputScalarN(label, ImGuiDataType_Float, v, 3, NULL, NULL, format, flags);
}

bool ImGui::InputFloat4(const char* label, float v[4], const char* format, ImGuiInputTextFlags flags)
{
    return InputScalarN(label, ImGuiDataType_Float, v, 4, NULL, NULL, format, flags);
}

// Prefer using "const char* format" directly, which is more flexible and consistent with other API.
#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
bool ImGui::InputFloat(const char* label, float* v, float step, float step_fast, int decimal_precision, ImGuiInputTextFlags flags)
{
    char format[16] = "%f";
    if (decimal_precision >= 0)
        ImFormatString(format, IM_ARRAYSIZE(format), "%%.%df", decimal_precision);
    return InputFloat(label, v, step, step_fast, format, flags);
}

bool ImGui::InputFloat2(const char* label, float v[2], int decimal_precision, ImGuiInputTextFlags flags)
{
    char format[16] = "%f";
    if (decimal_precision >= 0)
        ImFormatString(format, IM_ARRAYSIZE(format), "%%.%df", decimal_precision);
    return InputScalarN(label, ImGuiDataType_Float, v, 2, NULL, NULL, format, flags);
}

bool ImGui::InputFloat3(const char* label, float v[3], int decimal_precision, ImGuiInputTextFlags flags)
{
    char format[16] = "%f";
    if (decimal_precision >= 0)
        ImFormatString(format, IM_ARRAYSIZE(format), "%%.%df", decimal_precision);
    return InputScalarN(label, ImGuiDataType_Float, v, 3, NULL, NULL, format, flags);
}

bool ImGui::InputFloat4(const char* label, float v[4], int decimal_precision, ImGuiInputTextFlags flags)
{
    char format[16] = "%f";
    if (decimal_precision >= 0)
        ImFormatString(format, IM_ARRAYSIZE(format), "%%.%df", decimal_precision);
    return InputScalarN(label, ImGuiDataType_Float, v, 4, NULL, NULL, format, flags);
}
#endif // IMGUI_DISABLE_OBSOLETE_FUNCTIONS

bool ImGui::InputInt(const char* label, int* v, int step, int step_fast, ImGuiInputTextFlags flags)
{
    // Hexadecimal input provided as a convenience but the flag name is awkward. Typically you'd use InputText() to parse your own data, if you want to handle prefixes.
    const char* format = (flags & ImGuiInputTextFlags_CharsHexadecimal) ? "%08X" : "%d";
    return InputScalar(label, ImGuiDataType_S32, (void*)v, (void*)(step>0 ? &step : NULL), (void*)(step_fast>0 ? &step_fast : NULL), format, flags);
}

bool ImGui::InputInt2(const char* label, int v[2], ImGuiInputTextFlags flags)
{
    return InputScalarN(label, ImGuiDataType_S32, v, 2, NULL, NULL, "%d", flags);
}

bool ImGui::InputInt3(const char* label, int v[3], ImGuiInputTextFlags flags)
{
    return InputScalarN(label, ImGuiDataType_S32, v, 3, NULL, NULL, "%d", flags);
}

bool ImGui::InputInt4(const char* label, int v[4], ImGuiInputTextFlags flags)
{
    return InputScalarN(label, ImGuiDataType_S32, v, 4, NULL, NULL, "%d", flags);
}

bool ImGui::InputDouble(const char* label, double* v, double step, double step_fast, const char* format, ImGuiInputTextFlags flags)
{
    flags |= ImGuiInputTextFlags_CharsScientific;
    return InputScalar(label, ImGuiDataType_Double, (void*)v, (void*)(step>0.0 ? &step : NULL), (void*)(step_fast>0.0 ? &step_fast : NULL), format, flags);
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: InputText, InputTextMultiline
//-------------------------------------------------------------------------
// - InputText()
// - InputTextMultiline()
// - InputTextEx() [Internal]
//-------------------------------------------------------------------------

bool ImGui::InputText(const char* label, char* buf, size_t buf_size, ImGuiInputTextFlags flags, ImGuiInputTextCallback callback, void* user_data)
{
    IM_ASSERT(!(flags & ImGuiInputTextFlags_Multiline)); // call InputTextMultiline()
    return InputTextEx(label, buf, (int)buf_size, ImVec2(0,0), flags, callback, user_data);
}

bool ImGui::InputTextMultiline(const char* label, char* buf, size_t buf_size, const ImVec2& size, ImGuiInputTextFlags flags, ImGuiInputTextCallback callback, void* user_data)
{
    return InputTextEx(label, buf, (int)buf_size, size, flags | ImGuiInputTextFlags_Multiline, callback, user_data);
}

static int InputTextCalcTextLenAndLineCount(const char* text_begin, const char** out_text_end)
{
    int line_count = 0;
    const char* s = text_begin;
    while (char c = *s++) // We are only matching for \n so we can ignore UTF-8 decoding
        if (c == '\n')
            line_count++;
    s--;
    if (s[0] != '\n' && s[0] != '\r')
        line_count++;
    *out_text_end = s;
    return line_count;
}

static ImVec2 InputTextCalcTextSizeW(const ImWchar* text_begin, const ImWchar* text_end, const ImWchar** remaining, ImVec2* out_offset, bool stop_on_new_line)
{
    ImGuiContext& g = *GImGui;
    ImFont* font = g.Font;
    const float line_height = g.FontSize;
    const float scale = line_height / font->FontSize;

    ImVec2 text_size = ImVec2(0,0);
    float line_width = 0.0f;

    const ImWchar* s = text_begin;
    while (s < text_end)
    {
        unsigned int c = (unsigned int)(*s++);
        if (c == '\n')
        {
            text_size.x = ImMax(text_size.x, line_width);
            text_size.y += line_height;
            line_width = 0.0f;
            if (stop_on_new_line)
                break;
            continue;
        }
        if (c == '\r')
            continue;

        const float char_width = font->GetCharAdvance((ImWchar)c) * scale;
        line_width += char_width;
    }

    if (text_size.x < line_width)
        text_size.x = line_width;

    if (out_offset)
        *out_offset = ImVec2(line_width, text_size.y + line_height);  // offset allow for the possibility of sitting after a trailing \n

    if (line_width > 0 || text_size.y == 0.0f)                        // whereas size.y will ignore the trailing \n
        text_size.y += line_height;

    if (remaining)
        *remaining = s;

    return text_size;
}

// Wrapper for stb_textedit.h to edit text (our wrapper is for: statically sized buffer, single-line, wchar characters. InputText converts between UTF-8 and wchar)
namespace ImStb
{

static int     STB_TEXTEDIT_STRINGLEN(const STB_TEXTEDIT_STRING* obj)                             { return obj->CurLenW; }
static ImWchar STB_TEXTEDIT_GETCHAR(const STB_TEXTEDIT_STRING* obj, int idx)                      { return obj->TextW[idx]; }
static float   STB_TEXTEDIT_GETWIDTH(STB_TEXTEDIT_STRING* obj, int line_start_idx, int char_idx)  { ImWchar c = obj->TextW[line_start_idx+char_idx]; if (c == '\n') return STB_TEXTEDIT_GETWIDTH_NEWLINE; return GImGui->Font->GetCharAdvance(c) * (GImGui->FontSize / GImGui->Font->FontSize); }
static int     STB_TEXTEDIT_KEYTOTEXT(int key)                                                    { return key >= 0x10000 ? 0 : key; }
static ImWchar STB_TEXTEDIT_NEWLINE = '\n';
static void    STB_TEXTEDIT_LAYOUTROW(StbTexteditRow* r, STB_TEXTEDIT_STRING* obj, int line_start_idx)
{
    const ImWchar* text = obj->TextW.Data;
    const ImWchar* text_remaining = NULL;
    const ImVec2 size = InputTextCalcTextSizeW(text + line_start_idx, text + obj->CurLenW, &text_remaining, NULL, true);
    r->x0 = 0.0f;
    r->x1 = size.x;
    r->baseline_y_delta = size.y;
    r->ymin = 0.0f;
    r->ymax = size.y;
    r->num_chars = (int)(text_remaining - (text + line_start_idx));
}

static bool is_separator(unsigned int c)                                        { return ImCharIsBlankW(c) || c==',' || c==';' || c=='(' || c==')' || c=='{' || c=='}' || c=='[' || c==']' || c=='|'; }
static int  is_word_boundary_from_right(STB_TEXTEDIT_STRING* obj, int idx)      { return idx > 0 ? (is_separator( obj->TextW[idx-1] ) && !is_separator( obj->TextW[idx] ) ) : 1; }
static int  STB_TEXTEDIT_MOVEWORDLEFT_IMPL(STB_TEXTEDIT_STRING* obj, int idx)   { idx--; while (idx >= 0 && !is_word_boundary_from_right(obj, idx)) idx--; return idx < 0 ? 0 : idx; }
#ifdef __APPLE__    // FIXME: Move setting to IO structure
static int  is_word_boundary_from_left(STB_TEXTEDIT_STRING* obj, int idx)       { return idx > 0 ? (!is_separator( obj->TextW[idx-1] ) && is_separator( obj->TextW[idx] ) ) : 1; }
static int  STB_TEXTEDIT_MOVEWORDRIGHT_IMPL(STB_TEXTEDIT_STRING* obj, int idx)  { idx++; int len = obj->CurLenW; while (idx < len && !is_word_boundary_from_left(obj, idx)) idx++; return idx > len ? len : idx; }
#else
static int  STB_TEXTEDIT_MOVEWORDRIGHT_IMPL(STB_TEXTEDIT_STRING* obj, int idx)  { idx++; int len = obj->CurLenW; while (idx < len && !is_word_boundary_from_right(obj, idx)) idx++; return idx > len ? len : idx; }
#endif
#define STB_TEXTEDIT_MOVEWORDLEFT   STB_TEXTEDIT_MOVEWORDLEFT_IMPL    // They need to be #define for stb_textedit.h
#define STB_TEXTEDIT_MOVEWORDRIGHT  STB_TEXTEDIT_MOVEWORDRIGHT_IMPL

static void STB_TEXTEDIT_DELETECHARS(STB_TEXTEDIT_STRING* obj, int pos, int n)
{
    ImWchar* dst = obj->TextW.Data + pos;

    // We maintain our buffer length in both UTF-8 and wchar formats
    obj->CurLenA -= ImTextCountUtf8BytesFromStr(dst, dst + n);
    obj->CurLenW -= n;

    // Offset remaining text (FIXME-OPT: Use memmove)
    const ImWchar* src = obj->TextW.Data + pos + n;
    while (ImWchar c = *src++)
        *dst++ = c;
    *dst = '\0';
}

static bool STB_TEXTEDIT_INSERTCHARS(STB_TEXTEDIT_STRING* obj, int pos, const ImWchar* new_text, int new_text_len)
{
    const bool is_resizable = (obj->UserFlags & ImGuiInputTextFlags_CallbackResize) != 0;
    const int text_len = obj->CurLenW;
    IM_ASSERT(pos <= text_len);

    const int new_text_len_utf8 = ImTextCountUtf8BytesFromStr(new_text, new_text + new_text_len);
    if (!is_resizable && (new_text_len_utf8 + obj->CurLenA + 1 > obj->BufCapacityA))
        return false;

    // Grow internal buffer if needed
    if (new_text_len + text_len + 1 > obj->TextW.Size)
    {
        if (!is_resizable)
            return false;
        IM_ASSERT(text_len < obj->TextW.Size);
        obj->TextW.resize(text_len + ImClamp(new_text_len * 4, 32, ImMax(256, new_text_len)) + 1);
    }

    ImWchar* text = obj->TextW.Data;
    if (pos != text_len)
        memmove(text + pos + new_text_len, text + pos, (size_t)(text_len - pos) * sizeof(ImWchar));
    memcpy(text + pos, new_text, (size_t)new_text_len * sizeof(ImWchar));

    obj->CurLenW += new_text_len;
    obj->CurLenA += new_text_len_utf8;
    obj->TextW[obj->CurLenW] = '\0';

    return true;
}

// We don't use an enum so we can build even with conflicting symbols (if another user of stb_textedit.h leak their STB_TEXTEDIT_K_* symbols)
#define STB_TEXTEDIT_K_LEFT         0x10000 // keyboard input to move cursor left
#define STB_TEXTEDIT_K_RIGHT        0x10001 // keyboard input to move cursor right
#define STB_TEXTEDIT_K_UP           0x10002 // keyboard input to move cursor up
#define STB_TEXTEDIT_K_DOWN         0x10003 // keyboard input to move cursor down
#define STB_TEXTEDIT_K_LINESTART    0x10004 // keyboard input to move cursor to start of line
#define STB_TEXTEDIT_K_LINEEND      0x10005 // keyboard input to move cursor to end of line
#define STB_TEXTEDIT_K_TEXTSTART    0x10006 // keyboard input to move cursor to start of text
#define STB_TEXTEDIT_K_TEXTEND      0x10007 // keyboard input to move cursor to end of text
#define STB_TEXTEDIT_K_DELETE       0x10008 // keyboard input to delete selection or character under cursor
#define STB_TEXTEDIT_K_BACKSPACE    0x10009 // keyboard input to delete selection or character left of cursor
#define STB_TEXTEDIT_K_UNDO         0x1000A // keyboard input to perform undo
#define STB_TEXTEDIT_K_REDO         0x1000B // keyboard input to perform redo
#define STB_TEXTEDIT_K_WORDLEFT     0x1000C // keyboard input to move cursor left one word
#define STB_TEXTEDIT_K_WORDRIGHT    0x1000D // keyboard input to move cursor right one word
#define STB_TEXTEDIT_K_SHIFT        0x20000

#define STB_TEXTEDIT_IMPLEMENTATION
#include "imstb_textedit.h"

}

void ImGuiInputTextState::OnKeyPressed(int key)
{
    stb_textedit_key(this, &Stb, key);
    CursorFollow = true;
    CursorAnimReset();
}

ImGuiInputTextCallbackData::ImGuiInputTextCallbackData()
{
    memset(this, 0, sizeof(*this));
}

// Public API to manipulate UTF-8 text
// We expose UTF-8 to the user (unlike the STB_TEXTEDIT_* functions which are manipulating wchar)
// FIXME: The existence of this rarely exercised code path is a bit of a nuisance.
void ImGuiInputTextCallbackData::DeleteChars(int pos, int bytes_count)
{
    IM_ASSERT(pos + bytes_count <= BufTextLen);
    char* dst = Buf + pos;
    const char* src = Buf + pos + bytes_count;
    while (char c = *src++)
        *dst++ = c;
    *dst = '\0';

    if (CursorPos + bytes_count >= pos)
        CursorPos -= bytes_count;
    else if (CursorPos >= pos)
        CursorPos = pos;
    SelectionStart = SelectionEnd = CursorPos;
    BufDirty = true;
    BufTextLen -= bytes_count;
}

void ImGuiInputTextCallbackData::InsertChars(int pos, const char* new_text, const char* new_text_end)
{
    const bool is_resizable = (Flags & ImGuiInputTextFlags_CallbackResize) != 0;
    const int new_text_len = new_text_end ? (int)(new_text_end - new_text) : (int)strlen(new_text);
    if (new_text_len + BufTextLen >= BufSize)
    {
        if (!is_resizable)
            return;

        // Contrary to STB_TEXTEDIT_INSERTCHARS() this is working in the UTF8 buffer, hence the midly similar code (until we remove the U16 buffer alltogether!)
        ImGuiContext& g = *GImGui;
        ImGuiInputTextState* edit_state = &g.InputTextState;
        IM_ASSERT(edit_state->ID != 0 && g.ActiveId == edit_state->ID);
        IM_ASSERT(Buf == edit_state->TextA.Data);
        int new_buf_size = BufTextLen + ImClamp(new_text_len * 4, 32, ImMax(256, new_text_len)) + 1;
        edit_state->TextA.reserve(new_buf_size + 1);
        Buf = edit_state->TextA.Data;
        BufSize = edit_state->BufCapacityA = new_buf_size;
    }

    if (BufTextLen != pos)
        memmove(Buf + pos + new_text_len, Buf + pos, (size_t)(BufTextLen - pos));
    memcpy(Buf + pos, new_text, (size_t)new_text_len * sizeof(char));
    Buf[BufTextLen + new_text_len] = '\0';

    if (CursorPos >= pos)
        CursorPos += new_text_len;
    SelectionStart = SelectionEnd = CursorPos;
    BufDirty = true;
    BufTextLen += new_text_len;
}

// Return false to discard a character.
static bool InputTextFilterCharacter(unsigned int* p_char, ImGuiInputTextFlags flags, ImGuiInputTextCallback callback, void* user_data)
{
    unsigned int c = *p_char;

    if (c < 128 && c != ' ' && !isprint((int)(c & 0xFF)))
    {
        bool pass = false;
        pass |= (c == '\n' && (flags & ImGuiInputTextFlags_Multiline));
        pass |= (c == '\t' && (flags & ImGuiInputTextFlags_AllowTabInput));
        if (!pass)
            return false;
    }

    if (c >= 0xE000 && c <= 0xF8FF) // Filter private Unicode range. I don't imagine anybody would want to input them. GLFW on OSX seems to send private characters for special keys like arrow keys.
        return false;

    if (flags & (ImGuiInputTextFlags_CharsDecimal | ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsUppercase | ImGuiInputTextFlags_CharsNoBlank | ImGuiInputTextFlags_CharsScientific))
    {
        if (flags & ImGuiInputTextFlags_CharsDecimal)
            if (!(c >= '0' && c <= '9') && (c != '.') && (c != '-') && (c != '+') && (c != '*') && (c != '/'))
                return false;

        if (flags & ImGuiInputTextFlags_CharsScientific)
            if (!(c >= '0' && c <= '9') && (c != '.') && (c != '-') && (c != '+') && (c != '*') && (c != '/') && (c != 'e') && (c != 'E'))
                return false;

        if (flags & ImGuiInputTextFlags_CharsHexadecimal)
            if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f') && !(c >= 'A' && c <= 'F'))
                return false;

        if (flags & ImGuiInputTextFlags_CharsUppercase)
            if (c >= 'a' && c <= 'z')
                *p_char = (c += (unsigned int)('A'-'a'));

        if (flags & ImGuiInputTextFlags_CharsNoBlank)
            if (ImCharIsBlankW(c))
                return false;
    }

    if (flags & ImGuiInputTextFlags_CallbackCharFilter)
    {
        ImGuiInputTextCallbackData callback_data;
        memset(&callback_data, 0, sizeof(ImGuiInputTextCallbackData));
        callback_data.EventFlag = ImGuiInputTextFlags_CallbackCharFilter;
        callback_data.EventChar = (ImWchar)c;
        callback_data.Flags = flags;
        callback_data.UserData = user_data;
        if (callback(&callback_data) != 0)
            return false;
        *p_char = callback_data.EventChar;
        if (!callback_data.EventChar)
            return false;
    }

    return true;
}

// Edit a string of text
// - buf_size account for the zero-terminator, so a buf_size of 6 can hold "Hello" but not "Hello!".
//   This is so we can easily call InputText() on static arrays using ARRAYSIZE() and to match
//   Note that in std::string world, capacity() would omit 1 byte used by the zero-terminator.
// - When active, hold on a privately held copy of the text (and apply back to 'buf'). So changing 'buf' while the InputText is active has no effect.
// - If you want to use ImGui::InputText() with std::string, see misc/cpp/imgui_stdlib.h
// (FIXME: Rather confusing and messy function, among the worse part of our codebase, expecting to rewrite a V2 at some point.. Partly because we are
//  doing UTF8 > U16 > UTF8 conversions on the go to easily interface with stb_textedit. Ideally should stay in UTF-8 all the time. See https://github.com/nothings/stb/issues/188)
bool ImGui::InputTextEx(const char* label, char* buf, int buf_size, const ImVec2& size_arg, ImGuiInputTextFlags flags, ImGuiInputTextCallback callback, void* callback_user_data)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    IM_ASSERT(!((flags & ImGuiInputTextFlags_CallbackHistory) && (flags & ImGuiInputTextFlags_Multiline)));        // Can't use both together (they both use up/down keys)
    IM_ASSERT(!((flags & ImGuiInputTextFlags_CallbackCompletion) && (flags & ImGuiInputTextFlags_AllowTabInput))); // Can't use both together (they both use tab key)

    ImGuiContext& g = *GImGui;
    ImGuiIO& io = g.IO;
    const ImGuiStyle& style = g.Style;

    const bool RENDER_SELECTION_WHEN_INACTIVE = true;
    const bool is_multiline = (flags & ImGuiInputTextFlags_Multiline) != 0;
    const bool is_readonly = (flags & ImGuiInputTextFlags_ReadOnly) != 0;
    const bool is_password = (flags & ImGuiInputTextFlags_Password) != 0;
    const bool is_undoable = (flags & ImGuiInputTextFlags_NoUndoRedo) == 0;
    const bool is_resizable = (flags & ImGuiInputTextFlags_CallbackResize) != 0;
    if (is_resizable)
        IM_ASSERT(callback != NULL); // Must provide a callback if you set the ImGuiInputTextFlags_CallbackResize flag!

    if (is_multiline) // Open group before calling GetID() because groups tracks id created within their scope,
        BeginGroup();
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    ImVec2 size = CalcItemSize(size_arg, CalcItemWidth(), (is_multiline ? GetTextLineHeight() * 8.0f : label_size.y) + style.FramePadding.y*2.0f); // Arbitrary default of 8 lines high for multi-line
    const ImRect frame_bb(window->DC.CursorPos, window->DC.CursorPos + size);
    const ImRect total_bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? (style.ItemInnerSpacing.x + label_size.x) : 0.0f, 0.0f));

    ImGuiWindow* draw_window = window;
    if (is_multiline)
    {
        if (!ItemAdd(total_bb, id, &frame_bb))
        {
            ItemSize(total_bb, style.FramePadding.y);
            EndGroup();
            return false;
        }
        if (!BeginChildFrame(id, frame_bb.GetSize()))
        {
            EndChildFrame();
            EndGroup();
            return false;
        }
        draw_window = GetCurrentWindow();
        draw_window->DC.NavLayerActiveMaskNext |= draw_window->DC.NavLayerCurrentMask; // This is to ensure that EndChild() will display a navigation highlight
        size.x -= draw_window->ScrollbarSizes.x;
    }
    else
    {
        ItemSize(total_bb, style.FramePadding.y);
        if (!ItemAdd(total_bb, id, &frame_bb))
            return false;
    }
    const bool hovered = ItemHoverable(frame_bb, id);
    if (hovered)
        g.MouseCursor = ImGuiMouseCursor_TextInput;

    // Password pushes a temporary font with only a fallback glyph
    if (is_password)
    {
        const ImFontGlyph* glyph = g.Font->FindGlyph('*');
        ImFont* password_font = &g.InputTextPasswordFont;
        password_font->FontSize = g.Font->FontSize;
        password_font->Scale = g.Font->Scale;
        password_font->DisplayOffset = g.Font->DisplayOffset;
        password_font->Ascent = g.Font->Ascent;
        password_font->Descent = g.Font->Descent;
        password_font->ContainerAtlas = g.Font->ContainerAtlas;
        password_font->FallbackGlyph = glyph;
        password_font->FallbackAdvanceX = glyph->AdvanceX;
        IM_ASSERT(password_font->Glyphs.empty() && password_font->IndexAdvanceX.empty() && password_font->IndexLookup.empty());
        PushFont(password_font);
    }

    // NB: we are only allowed to access 'edit_state' if we are the active widget.
    ImGuiInputTextState* state = NULL;
    if (g.InputTextState.ID == id)
        state = &g.InputTextState;

    const bool focus_requested = FocusableItemRegister(window, id, (flags & (ImGuiInputTextFlags_CallbackCompletion|ImGuiInputTextFlags_AllowTabInput)) == 0);    // Using completion callback disable keyboard tabbing
    const bool focus_requested_by_code = focus_requested && (window->FocusIdxAllCounter == window->FocusIdxAllRequestCurrent);
    const bool focus_requested_by_tab = focus_requested && !focus_requested_by_code;

    const bool user_clicked = hovered && io.MouseClicked[0];
    const bool user_nav_input_start = (g.ActiveId != id) && ((g.NavInputId == id) || (g.NavActivateId == id && g.NavInputSource == ImGuiInputSource_NavKeyboard));
    const bool user_scroll_finish = is_multiline && state != NULL && g.ActiveId == 0 && g.ActiveIdPreviousFrame == GetScrollbarID(draw_window, ImGuiAxis_Y);
    const bool user_scroll_active = is_multiline && state != NULL && g.ActiveId == GetScrollbarID(draw_window, ImGuiAxis_Y);

    bool clear_active_id = false;
    bool select_all = (g.ActiveId != id) && ((flags & ImGuiInputTextFlags_AutoSelectAll) != 0 || user_nav_input_start) && (!is_multiline);

    const bool init_make_active = (focus_requested || user_clicked || user_scroll_finish || user_nav_input_start);
    if (init_make_active && g.ActiveId != id)
    {
        // Access state even if we don't own it yet.
        state = &g.InputTextState;
        state->CursorAnimReset();

        // Take a copy of the initial buffer value (both in original UTF-8 format and converted to wchar)
        // From the moment we focused we are ignoring the content of 'buf' (unless we are in read-only mode)
        const int buf_len = (int)strlen(buf);
        state->InitialTextA.resize(buf_len + 1);    // UTF-8. we use +1 to make sure that .Data is always pointing to at least an empty string.
        memcpy(state->InitialTextA.Data, buf, buf_len + 1);

        // Start edition
        const int prev_len_w = state->CurLenW;
        const char* buf_end = NULL;
        state->TextW.resize(buf_size + 1);          // wchar count <= UTF-8 count. we use +1 to make sure that .Data is always pointing to at least an empty string.
        state->CurLenW = ImTextStrFromUtf8(state->TextW.Data, buf_size, buf, NULL, &buf_end);
        state->CurLenA = (int)(buf_end - buf);      // We can't get the result from ImStrncpy() above because it is not UTF-8 aware. Here we'll cut off malformed UTF-8.

        // Preserve cursor position and undo/redo stack if we come back to same widget
        // FIXME: We should probably compare the whole buffer to be on the safety side. Comparing buf (utf8) and edit_state.Text (wchar).
        const bool recycle_state = (state->ID == id) && (prev_len_w == state->CurLenW);
        if (recycle_state)
        {
            // Recycle existing cursor/selection/undo stack but clamp position
            // Note a single mouse click will override the cursor/position immediately by calling stb_textedit_click handler.
            state->CursorClamp();
        }
        else
        {
            state->ID = id;
            state->ScrollX = 0.0f;
            stb_textedit_initialize_state(&state->Stb, !is_multiline);
            if (!is_multiline && focus_requested_by_code)
                select_all = true;
        }
        if (flags & ImGuiInputTextFlags_AlwaysInsertMode)
            state->Stb.insert_mode = 1;
        if (!is_multiline && (focus_requested_by_tab || (user_clicked && io.KeyCtrl)))
            select_all = true;
    }

    if (init_make_active)
    {
        IM_ASSERT(state && state->ID == id);
        SetActiveID(id, window);
        SetFocusID(id, window);
        FocusWindow(window);
        g.ActiveIdBlockNavInputFlags = (1 << ImGuiNavInput_Cancel);
        if (!is_multiline && !(flags & ImGuiInputTextFlags_CallbackHistory))
            g.ActiveIdAllowNavDirFlags = ((1 << ImGuiDir_Up) | (1 << ImGuiDir_Down));
    }

    // Release focus when we click outside
    if (!init_make_active && io.MouseClicked[0])
        clear_active_id = true;

    // We have an edge case if ActiveId was set through another widget (e.g. widget being swapped)
    if (g.ActiveId == id && state == NULL)
        ClearActiveID();

    bool value_changed = false;
    bool enter_pressed = false;
    int backup_current_text_length = 0;

    // Process mouse inputs and character inputs
    if (g.ActiveId == id)
    {
        IM_ASSERT(state != NULL);
        if (is_readonly && !g.ActiveIdIsJustActivated)
        {
            // When read-only we always use the live data passed to the function
            const char* buf_end = NULL;
            state->TextW.resize(buf_size+1);
            state->CurLenW = ImTextStrFromUtf8(state->TextW.Data, state->TextW.Size, buf, NULL, &buf_end);
            state->CurLenA = (int)(buf_end - buf);
            state->CursorClamp();
        }

        backup_current_text_length = state->CurLenA;
        state->BufCapacityA = buf_size;
        state->UserFlags = flags;
        state->UserCallback = callback;
        state->UserCallbackData = callback_user_data;

        // Although we are active we don't prevent mouse from hovering other elements unless we are interacting right now with the widget.
        // Down the line we should have a cleaner library-wide concept of Selected vs Active.
        g.ActiveIdAllowOverlap = !io.MouseDown[0];
        g.WantTextInputNextFrame = 1;

        // Edit in progress
        const float mouse_x = (io.MousePos.x - frame_bb.Min.x - style.FramePadding.x) + state->ScrollX;
        const float mouse_y = (is_multiline ? (io.MousePos.y - draw_window->DC.CursorPos.y - style.FramePadding.y) : (g.FontSize*0.5f));

        const bool is_osx = io.ConfigMacOSXBehaviors;
        if (select_all || (hovered && !is_osx && io.MouseDoubleClicked[0]))
        {
            state->SelectAll();
            state->SelectedAllMouseLock = true;
        }
        else if (hovered && is_osx && io.MouseDoubleClicked[0])
        {
            // Double-click select a word only, OS X style (by simulating keystrokes)
            state->OnKeyPressed(STB_TEXTEDIT_K_WORDLEFT);
            state->OnKeyPressed(STB_TEXTEDIT_K_WORDRIGHT | STB_TEXTEDIT_K_SHIFT);
        }
        else if (io.MouseClicked[0] && !state->SelectedAllMouseLock)
        {
            if (hovered)
            {
                stb_textedit_click(state, &state->Stb, mouse_x, mouse_y);
                state->CursorAnimReset();
            }
        }
        else if (io.MouseDown[0] && !state->SelectedAllMouseLock && (io.MouseDelta.x != 0.0f || io.MouseDelta.y != 0.0f))
        {
            stb_textedit_drag(state, &state->Stb, mouse_x, mouse_y);
            state->CursorAnimReset();
            state->CursorFollow = true;
        }
        if (state->SelectedAllMouseLock && !io.MouseDown[0])
            state->SelectedAllMouseLock = false;

        if (io.InputQueueCharacters.Size > 0)
        {
            // Process text input (before we check for Return because using some IME will effectively send a Return?)
            // We ignore CTRL inputs, but need to allow ALT+CTRL as some keyboards (e.g. German) use AltGR (which _is_ Alt+Ctrl) to input certain characters.
            bool ignore_inputs = (io.KeyCtrl && !io.KeyAlt) || (is_osx && io.KeySuper);
            if (!ignore_inputs && !is_readonly && !user_nav_input_start)
                for (int n = 0; n < io.InputQueueCharacters.Size; n++)
                {
                    // Insert character if they pass filtering
                    unsigned int c = (unsigned int)io.InputQueueCharacters[n];
                    if (InputTextFilterCharacter(&c, flags, callback, callback_user_data))
                        state->OnKeyPressed((int)c);
                }

            // Consume characters
            io.InputQueueCharacters.resize(0);
        }
    }

    // Process other shortcuts/key-presses
    bool cancel_edit = false;
    if (g.ActiveId == id && !g.ActiveIdIsJustActivated && !clear_active_id)
    {
        IM_ASSERT(state != NULL);
        const int k_mask = (io.KeyShift ? STB_TEXTEDIT_K_SHIFT : 0);
        const bool is_osx = io.ConfigMacOSXBehaviors;
        const bool is_shortcut_key = (is_osx ? (io.KeySuper && !io.KeyCtrl) : (io.KeyCtrl && !io.KeySuper)) && !io.KeyAlt && !io.KeyShift; // OS X style: Shortcuts using Cmd/Super instead of Ctrl
        const bool is_osx_shift_shortcut = is_osx && io.KeySuper && io.KeyShift && !io.KeyCtrl && !io.KeyAlt;
        const bool is_wordmove_key_down = is_osx ? io.KeyAlt : io.KeyCtrl;                     // OS X style: Text editing cursor movement using Alt instead of Ctrl
        const bool is_startend_key_down = is_osx && io.KeySuper && !io.KeyCtrl && !io.KeyAlt;  // OS X style: Line/Text Start and End using Cmd+Arrows instead of Home/End
        const bool is_ctrl_key_only = io.KeyCtrl && !io.KeyShift && !io.KeyAlt && !io.KeySuper;
        const bool is_shift_key_only = io.KeyShift && !io.KeyCtrl && !io.KeyAlt && !io.KeySuper;

        const bool is_cut   = ((is_shortcut_key && IsKeyPressedMap(ImGuiKey_X)) || (is_shift_key_only && IsKeyPressedMap(ImGuiKey_Delete))) && !is_readonly && !is_password && (!is_multiline || state->HasSelection());
        const bool is_copy  = ((is_shortcut_key && IsKeyPressedMap(ImGuiKey_C)) || (is_ctrl_key_only  && IsKeyPressedMap(ImGuiKey_Insert))) && !is_password && (!is_multiline || state->HasSelection());
        const bool is_paste = ((is_shortcut_key && IsKeyPressedMap(ImGuiKey_V)) || (is_shift_key_only && IsKeyPressedMap(ImGuiKey_Insert))) && !is_readonly;
        const bool is_undo  = ((is_shortcut_key && IsKeyPressedMap(ImGuiKey_Z)) && !is_readonly && is_undoable);
        const bool is_redo  = ((is_shortcut_key && IsKeyPressedMap(ImGuiKey_Y)) || (is_osx_shift_shortcut && IsKeyPressedMap(ImGuiKey_Z))) && !is_readonly && is_undoable;

        if (IsKeyPressedMap(ImGuiKey_LeftArrow))                        { state->OnKeyPressed((is_startend_key_down ? STB_TEXTEDIT_K_LINESTART : is_wordmove_key_down ? STB_TEXTEDIT_K_WORDLEFT : STB_TEXTEDIT_K_LEFT) | k_mask); }
        else if (IsKeyPressedMap(ImGuiKey_RightArrow))                  { state->OnKeyPressed((is_startend_key_down ? STB_TEXTEDIT_K_LINEEND : is_wordmove_key_down ? STB_TEXTEDIT_K_WORDRIGHT : STB_TEXTEDIT_K_RIGHT) | k_mask); }
        else if (IsKeyPressedMap(ImGuiKey_UpArrow) && is_multiline)     { if (io.KeyCtrl) SetWindowScrollY(draw_window, ImMax(draw_window->Scroll.y - g.FontSize, 0.0f)); else state->OnKeyPressed((is_startend_key_down ? STB_TEXTEDIT_K_TEXTSTART : STB_TEXTEDIT_K_UP) | k_mask); }
        else if (IsKeyPressedMap(ImGuiKey_DownArrow) && is_multiline)   { if (io.KeyCtrl) SetWindowScrollY(draw_window, ImMin(draw_window->Scroll.y + g.FontSize, GetScrollMaxY())); else state->OnKeyPressed((is_startend_key_down ? STB_TEXTEDIT_K_TEXTEND : STB_TEXTEDIT_K_DOWN) | k_mask); }
        else if (IsKeyPressedMap(ImGuiKey_Home))                        { state->OnKeyPressed(io.KeyCtrl ? STB_TEXTEDIT_K_TEXTSTART | k_mask : STB_TEXTEDIT_K_LINESTART | k_mask); }
        else if (IsKeyPressedMap(ImGuiKey_End))                         { state->OnKeyPressed(io.KeyCtrl ? STB_TEXTEDIT_K_TEXTEND | k_mask : STB_TEXTEDIT_K_LINEEND | k_mask); }
        else if (IsKeyPressedMap(ImGuiKey_Delete) && !is_readonly)      { state->OnKeyPressed(STB_TEXTEDIT_K_DELETE | k_mask); }
        else if (IsKeyPressedMap(ImGuiKey_Backspace) && !is_readonly)
        {
            if (!state->HasSelection())
            {
                if (is_wordmove_key_down) 
                    state->OnKeyPressed(STB_TEXTEDIT_K_WORDLEFT|STB_TEXTEDIT_K_SHIFT);
                else if (is_osx && io.KeySuper && !io.KeyAlt && !io.KeyCtrl) 
                    state->OnKeyPressed(STB_TEXTEDIT_K_LINESTART|STB_TEXTEDIT_K_SHIFT);
            }
            state->OnKeyPressed(STB_TEXTEDIT_K_BACKSPACE | k_mask);
        }
        else if (IsKeyPressedMap(ImGuiKey_Enter))
        {
            bool ctrl_enter_for_new_line = (flags & ImGuiInputTextFlags_CtrlEnterForNewLine) != 0;
            if (!is_multiline || (ctrl_enter_for_new_line && !io.KeyCtrl) || (!ctrl_enter_for_new_line && io.KeyCtrl))
            {
                enter_pressed = clear_active_id = true;
            }
            else if (!is_readonly)
            {
                unsigned int c = '\n'; // Insert new line
                if (InputTextFilterCharacter(&c, flags, callback, callback_user_data))
                    state->OnKeyPressed((int)c);
            }
        }
        else if ((flags & ImGuiInputTextFlags_AllowTabInput) && IsKeyPressedMap(ImGuiKey_Tab) && !io.KeyCtrl && !io.KeyShift && !io.KeyAlt && !is_readonly)
        {
            unsigned int c = '\t'; // Insert TAB
            if (InputTextFilterCharacter(&c, flags, callback, callback_user_data))
                state->OnKeyPressed((int)c);
        }
        else if (IsKeyPressedMap(ImGuiKey_Escape))
        {
            clear_active_id = cancel_edit = true;
        }
        else if (is_undo || is_redo)
        {
            state->OnKeyPressed(is_undo ? STB_TEXTEDIT_K_UNDO : STB_TEXTEDIT_K_REDO);
            state->ClearSelection();
        }
        else if (is_shortcut_key && IsKeyPressedMap(ImGuiKey_A))
        {
            state->SelectAll();
            state->CursorFollow = true;
        }
        else if (is_cut || is_copy)
        {
            // Cut, Copy
            if (io.SetClipboardTextFn)
            {
                const int ib = state->HasSelection() ? ImMin(state->Stb.select_start, state->Stb.select_end) : 0;
                const int ie = state->HasSelection() ? ImMax(state->Stb.select_start, state->Stb.select_end) : state->CurLenW;
                const int clipboard_data_len = ImTextCountUtf8BytesFromStr(state->TextW.Data + ib, state->TextW.Data + ie) + 1;
                char* clipboard_data = (char*)MemAlloc(clipboard_data_len * sizeof(char));
                ImTextStrToUtf8(clipboard_data, clipboard_data_len, state->TextW.Data + ib, state->TextW.Data + ie);
                SetClipboardText(clipboard_data);
                MemFree(clipboard_data);
            }
            if (is_cut)
            {
                if (!state->HasSelection())
                    state->SelectAll();
                state->CursorFollow = true;
                stb_textedit_cut(state, &state->Stb);
            }
        }
        else if (is_paste)
        {
            if (const char* clipboard = GetClipboardText())
            {
                // Filter pasted buffer
                const int clipboard_len = (int)strlen(clipboard);
                ImWchar* clipboard_filtered = (ImWchar*)MemAlloc((clipboard_len+1) * sizeof(ImWchar));
                int clipboard_filtered_len = 0;
                for (const char* s = clipboard; *s; )
                {
                    unsigned int c;
                    s += ImTextCharFromUtf8(&c, s, NULL);
                    if (c == 0)
                        break;
                    if (c >= 0x10000 || !InputTextFilterCharacter(&c, flags, callback, callback_user_data))
                        continue;
                    clipboard_filtered[clipboard_filtered_len++] = (ImWchar)c;
                }
                clipboard_filtered[clipboard_filtered_len] = 0;
                if (clipboard_filtered_len > 0) // If everything was filtered, ignore the pasting operation
                {
                    stb_textedit_paste(state, &state->Stb, clipboard_filtered, clipboard_filtered_len);
                    state->CursorFollow = true;
                }
                MemFree(clipboard_filtered);
            }
        }
    }

    // Process callbacks and apply result back to user's buffer.
    if (g.ActiveId == id)
    {
        IM_ASSERT(state != NULL);
        const char* apply_new_text = NULL;
        int apply_new_text_length = 0;
        if (cancel_edit)
        {
            // Restore initial value. Only return true if restoring to the initial value changes the current buffer contents.
            if (!is_readonly && strcmp(buf, state->InitialTextA.Data) != 0)
            {
                apply_new_text = state->InitialTextA.Data;
                apply_new_text_length = state->InitialTextA.Size - 1;
            }
        }

        // When using 'ImGuiInputTextFlags_EnterReturnsTrue' as a special case we reapply the live buffer back to the input buffer before clearing ActiveId, even though strictly speaking it wasn't modified on this frame.
        // If we didn't do that, code like InputInt() with ImGuiInputTextFlags_EnterReturnsTrue would fail. Also this allows the user to use InputText() with ImGuiInputTextFlags_EnterReturnsTrue without maintaining any user-side storage.
        bool apply_edit_back_to_user_buffer = !cancel_edit || (enter_pressed && (flags & ImGuiInputTextFlags_EnterReturnsTrue) != 0);
        if (apply_edit_back_to_user_buffer)
        {
            // Apply new value immediately - copy modified buffer back
            // Note that as soon as the input box is active, the in-widget value gets priority over any underlying modification of the input buffer
            // FIXME: We actually always render 'buf' when calling DrawList->AddText, making the comment above incorrect.
            // FIXME-OPT: CPU waste to do this every time the widget is active, should mark dirty state from the stb_textedit callbacks.
            if (!is_readonly)
            {
                state->TextA.resize(state->TextW.Size * 4 + 1);
                ImTextStrToUtf8(state->TextA.Data, state->TextA.Size, state->TextW.Data, NULL);
            }

            // User callback
            if ((flags & (ImGuiInputTextFlags_CallbackCompletion | ImGuiInputTextFlags_CallbackHistory | ImGuiInputTextFlags_CallbackAlways)) != 0)
            {
                IM_ASSERT(callback != NULL);

                // The reason we specify the usage semantic (Completion/History) is that Completion needs to disable keyboard TABBING at the moment.
                ImGuiInputTextFlags event_flag = 0;
                ImGuiKey event_key = ImGuiKey_COUNT;
                if ((flags & ImGuiInputTextFlags_CallbackCompletion) != 0 && IsKeyPressedMap(ImGuiKey_Tab))
                {
                    event_flag = ImGuiInputTextFlags_CallbackCompletion;
                    event_key = ImGuiKey_Tab;
                }
                else if ((flags & ImGuiInputTextFlags_CallbackHistory) != 0 && IsKeyPressedMap(ImGuiKey_UpArrow))
                {
                    event_flag = ImGuiInputTextFlags_CallbackHistory;
                    event_key = ImGuiKey_UpArrow;
                }
                else if ((flags & ImGuiInputTextFlags_CallbackHistory) != 0 && IsKeyPressedMap(ImGuiKey_DownArrow))
                {
                    event_flag = ImGuiInputTextFlags_CallbackHistory;
                    event_key = ImGuiKey_DownArrow;
                }
                else if (flags & ImGuiInputTextFlags_CallbackAlways)
                    event_flag = ImGuiInputTextFlags_CallbackAlways;

                if (event_flag)
                {
                    ImGuiInputTextCallbackData callback_data;
                    memset(&callback_data, 0, sizeof(ImGuiInputTextCallbackData));
                    callback_data.EventFlag = event_flag;
                    callback_data.Flags = flags;
                    callback_data.UserData = callback_user_data;

                    callback_data.EventKey = event_key;
                    callback_data.Buf = state->TextA.Data;
                    callback_data.BufTextLen = state->CurLenA;
                    callback_data.BufSize = state->BufCapacityA;
                    callback_data.BufDirty = false;

                    // We have to convert from wchar-positions to UTF-8-positions, which can be pretty slow (an incentive to ditch the ImWchar buffer, see https://github.com/nothings/stb/issues/188)
                    ImWchar* text = state->TextW.Data;
                    const int utf8_cursor_pos = callback_data.CursorPos = ImTextCountUtf8BytesFromStr(text, text + state->Stb.cursor);
                    const int utf8_selection_start = callback_data.SelectionStart = ImTextCountUtf8BytesFromStr(text, text + state->Stb.select_start);
                    const int utf8_selection_end = callback_data.SelectionEnd = ImTextCountUtf8BytesFromStr(text, text + state->Stb.select_end);

                    // Call user code
                    callback(&callback_data);

                    // Read back what user may have modified
                    IM_ASSERT(callback_data.Buf == state->TextA.Data);  // Invalid to modify those fields
                    IM_ASSERT(callback_data.BufSize == state->BufCapacityA);
                    IM_ASSERT(callback_data.Flags == flags);
                    if (callback_data.CursorPos != utf8_cursor_pos)            { state->Stb.cursor = ImTextCountCharsFromUtf8(callback_data.Buf, callback_data.Buf + callback_data.CursorPos); state->CursorFollow = true; }
                    if (callback_data.SelectionStart != utf8_selection_start)  { state->Stb.select_start = ImTextCountCharsFromUtf8(callback_data.Buf, callback_data.Buf + callback_data.SelectionStart); }
                    if (callback_data.SelectionEnd != utf8_selection_end)      { state->Stb.select_end = ImTextCountCharsFromUtf8(callback_data.Buf, callback_data.Buf + callback_data.SelectionEnd); }
                    if (callback_data.BufDirty)
                    {
                        IM_ASSERT(callback_data.BufTextLen == (int)strlen(callback_data.Buf)); // You need to maintain BufTextLen if you change the text!
                        if (callback_data.BufTextLen > backup_current_text_length && is_resizable)
                            state->TextW.resize(state->TextW.Size + (callback_data.BufTextLen - backup_current_text_length));
                        state->CurLenW = ImTextStrFromUtf8(state->TextW.Data, state->TextW.Size, callback_data.Buf, NULL);
                        state->CurLenA = callback_data.BufTextLen;  // Assume correct length and valid UTF-8 from user, saves us an extra strlen()
                        state->CursorAnimReset();
                    }
                }
            }

            // Will copy result string if modified
            if (!is_readonly && strcmp(state->TextA.Data, buf) != 0)
            {
                apply_new_text = state->TextA.Data;
                apply_new_text_length = state->CurLenA;
            }
        }

        // Copy result to user buffer
        if (apply_new_text)
        {
            IM_ASSERT(apply_new_text_length >= 0);
            if (backup_current_text_length != apply_new_text_length && is_resizable)
            {
                ImGuiInputTextCallbackData callback_data;
                callback_data.EventFlag = ImGuiInputTextFlags_CallbackResize;
                callback_data.Flags = flags;
                callback_data.Buf = buf;
                callback_data.BufTextLen = apply_new_text_length;
                callback_data.BufSize = ImMax(buf_size, apply_new_text_length + 1);
                callback_data.UserData = callback_user_data;
                callback(&callback_data);
                buf = callback_data.Buf;
                buf_size = callback_data.BufSize;
                apply_new_text_length = ImMin(callback_data.BufTextLen, buf_size - 1);
                IM_ASSERT(apply_new_text_length <= buf_size);
            }

            // If the underlying buffer resize was denied or not carried to the next frame, apply_new_text_length+1 may be >= buf_size.
            ImStrncpy(buf, apply_new_text, ImMin(apply_new_text_length + 1, buf_size));
            value_changed = true;
        }

        // Clear temporary user storage
        state->UserFlags = 0;
        state->UserCallback = NULL;
        state->UserCallbackData = NULL;
    }

    // Release active ID at the end of the function (so e.g. pressing Return still does a final application of the value)
    if (clear_active_id && g.ActiveId == id)
        ClearActiveID();

    // Render frame
    if (!is_multiline)
    {
        RenderNavHighlight(frame_bb, id);
        RenderFrame(frame_bb.Min, frame_bb.Max, GetColorU32(ImGuiCol_FrameBg), true, style.FrameRounding);
    }

    const ImVec4 clip_rect(frame_bb.Min.x, frame_bb.Min.y, frame_bb.Min.x + size.x, frame_bb.Min.y + size.y); // Not using frame_bb.Max because we have adjusted size
    ImVec2 draw_pos = is_multiline ? draw_window->DC.CursorPos : frame_bb.Min + style.FramePadding;
    ImVec2 text_size(0.0f, 0.0f);

    // Set upper limit of single-line InputTextEx() at 2 million characters strings. The current pathological worst case is a long line
    // without any carriage return, which would makes ImFont::RenderText() reserve too many vertices and probably crash. Avoid it altogether.
    // Note that we only use this limit on single-line InputText(), so a pathologically large line on a InputTextMultiline() would still crash.
    const int buf_display_max_length = 2 * 1024 * 1024;

    // Select which buffer we are going to display. We set buf to NULL to prevent accidental usage from now on.
    const char* buf_display = (state != NULL && !is_readonly) ? state->TextA.Data : buf;
    IM_ASSERT(buf_display);
    buf = NULL;

    // Render text. We currently only render selection when the widget is active or while scrolling.
    // FIXME: We could remove the '&& render_cursor' to keep rendering selection when inactive.
    const bool render_cursor = (g.ActiveId == id) || user_scroll_active;
    const bool render_selection = state && state->HasSelection() && (RENDER_SELECTION_WHEN_INACTIVE || render_cursor);
    if (render_cursor || render_selection)
    {
        // Render text (with cursor and selection)
        // This is going to be messy. We need to:
        // - Display the text (this alone can be more easily clipped)
        // - Handle scrolling, highlight selection, display cursor (those all requires some form of 1d->2d cursor position calculation)
        // - Measure text height (for scrollbar)
        // We are attempting to do most of that in **one main pass** to minimize the computation cost (non-negligible for large amount of text) + 2nd pass for selection rendering (we could merge them by an extra refactoring effort)
        // FIXME: This should occur on buf_display but we'd need to maintain cursor/select_start/select_end for UTF-8.
        IM_ASSERT(state != NULL);
        const ImWchar* text_begin = state->TextW.Data;
        ImVec2 cursor_offset, select_start_offset;

        {
            // Find lines numbers straddling 'cursor' (slot 0) and 'select_start' (slot 1) positions.
            const ImWchar* searches_input_ptr[2] = { NULL, NULL };
            int searches_result_line_no[2] = { -1000, -1000 };
            int searches_remaining = 0;
            if (render_cursor)
            {
                searches_input_ptr[0] = text_begin + state->Stb.cursor;
                searches_result_line_no[0] = -1;
                searches_remaining++;
            }
            if (render_selection)
            {
                searches_input_ptr[1] = text_begin + ImMin(state->Stb.select_start, state->Stb.select_end);
                searches_result_line_no[1] = -1;
                searches_remaining++;
            }

            // Iterate all lines to find our line numbers
            // In multi-line mode, we never exit the loop until all lines are counted, so add one extra to the searches_remaining counter.
            searches_remaining += is_multiline ? 1 : 0;
            int line_count = 0;
            //for (const ImWchar* s = text_begin; (s = (const ImWchar*)wcschr((const wchar_t*)s, (wchar_t)'\n')) != NULL; s++)  // FIXME-OPT: Could use this when wchar_t are 16-bits
            for (const ImWchar* s = text_begin; *s != 0; s++)
                if (*s == '\n')
                {
                    line_count++;
                    if (searches_result_line_no[0] == -1 && s >= searches_input_ptr[0]) { searches_result_line_no[0] = line_count; if (--searches_remaining <= 0) break; }
                    if (searches_result_line_no[1] == -1 && s >= searches_input_ptr[1]) { searches_result_line_no[1] = line_count; if (--searches_remaining <= 0) break; }
                }
            line_count++;
            if (searches_result_line_no[0] == -1) 
                searches_result_line_no[0] = line_count;
            if (searches_result_line_no[1] == -1) 
                searches_result_line_no[1] = line_count;

            // Calculate 2d position by finding the beginning of the line and measuring distance
            cursor_offset.x = InputTextCalcTextSizeW(ImStrbolW(searches_input_ptr[0], text_begin), searches_input_ptr[0]).x;
            cursor_offset.y = searches_result_line_no[0] * g.FontSize;
            if (searches_result_line_no[1] >= 0)
            {
                select_start_offset.x = InputTextCalcTextSizeW(ImStrbolW(searches_input_ptr[1], text_begin), searches_input_ptr[1]).x;
                select_start_offset.y = searches_result_line_no[1] * g.FontSize;
            }

            // Store text height (note that we haven't calculated text width at all, see GitHub issues #383, #1224)
            if (is_multiline)
                text_size = ImVec2(size.x, line_count * g.FontSize);
        }

        // Scroll
        if (render_cursor && state->CursorFollow)
        {
            // Horizontal scroll in chunks of quarter width
            if (!(flags & ImGuiInputTextFlags_NoHorizontalScroll))
            {
                const float scroll_increment_x = size.x * 0.25f;
                if (cursor_offset.x < state->ScrollX)
                    state->ScrollX = (float)(int)ImMax(0.0f, cursor_offset.x - scroll_increment_x);
                else if (cursor_offset.x - size.x >= state->ScrollX)
                    state->ScrollX = (float)(int)(cursor_offset.x - size.x + scroll_increment_x);
            }
            else
            {
                state->ScrollX = 0.0f;
            }

            // Vertical scroll
            if (is_multiline)
            {
                float scroll_y = draw_window->Scroll.y;
                if (cursor_offset.y - g.FontSize < scroll_y)
                    scroll_y = ImMax(0.0f, cursor_offset.y - g.FontSize);
                else if (cursor_offset.y - size.y >= scroll_y)
                    scroll_y = cursor_offset.y - size.y;
                draw_window->DC.CursorPos.y += (draw_window->Scroll.y - scroll_y);   // Manipulate cursor pos immediately avoid a frame of lag
                draw_window->Scroll.y = scroll_y;
                draw_pos.y = draw_window->DC.CursorPos.y;
            }

            state->CursorFollow = false;
        }

        // Draw selection
        const ImVec2 draw_scroll = ImVec2(state->ScrollX, 0.0f);
        if (render_selection)
        {
            const ImWchar* text_selected_begin = text_begin + ImMin(state->Stb.select_start, state->Stb.select_end);
            const ImWchar* text_selected_end = text_begin + ImMax(state->Stb.select_start, state->Stb.select_end);

            ImU32 bg_color = GetColorU32(ImGuiCol_TextSelectedBg, render_cursor ? 1.0f : 0.6f); // FIXME: current code flow mandate that render_cursor is always true here, we are leaving the transparent one for tests.
            float bg_offy_up = is_multiline ? 0.0f : -1.0f;    // FIXME: those offsets should be part of the style? they don't play so well with multi-line selection.
            float bg_offy_dn = is_multiline ? 0.0f : 2.0f;
            ImVec2 rect_pos = draw_pos + select_start_offset - draw_scroll;
            for (const ImWchar* p = text_selected_begin; p < text_selected_end; )
            {
                if (rect_pos.y > clip_rect.w + g.FontSize)
                    break;
                if (rect_pos.y < clip_rect.y)
                {
                    //p = (const ImWchar*)wmemchr((const wchar_t*)p, '\n', text_selected_end - p);  // FIXME-OPT: Could use this when wchar_t are 16-bits
                    //p = p ? p + 1 : text_selected_end;
                    while (p < text_selected_end)
                        if (*p++ == '\n')
                            break;
                }
                else
                {
                    ImVec2 rect_size = InputTextCalcTextSizeW(p, text_selected_end, &p, NULL, true);
                    if (rect_size.x <= 0.0f) rect_size.x = (float)(int)(g.Font->GetCharAdvance((ImWchar)' ') * 0.50f); // So we can see selected empty lines
                    ImRect rect(rect_pos + ImVec2(0.0f, bg_offy_up - g.FontSize), rect_pos +ImVec2(rect_size.x, bg_offy_dn));
                    rect.ClipWith(clip_rect);
                    if (rect.Overlaps(clip_rect))
                        draw_window->DrawList->AddRectFilled(rect.Min, rect.Max, bg_color);
                }
                rect_pos.x = draw_pos.x - draw_scroll.x;
                rect_pos.y += g.FontSize;
            }
        }

        // We test for 'buf_display_max_length' as a way to avoid some pathological cases (e.g. single-line 1 MB string) which would make ImDrawList crash.
        const int buf_display_len = state->CurLenA;
        if (is_multiline || buf_display_len < buf_display_max_length)
            draw_window->DrawList->AddText(g.Font, g.FontSize, draw_pos - draw_scroll, GetColorU32(ImGuiCol_Text), buf_display, buf_display + buf_display_len, 0.0f, is_multiline ? NULL : &clip_rect);

        // Draw blinking cursor
        if (render_cursor)
        {
            state->CursorAnim += io.DeltaTime;
            bool cursor_is_visible = (!g.IO.ConfigInputTextCursorBlink) || (state->CursorAnim <= 0.0f) || ImFmod(state->CursorAnim, 1.20f) <= 0.80f;
            ImVec2 cursor_screen_pos = draw_pos + cursor_offset - draw_scroll;
            ImRect cursor_screen_rect(cursor_screen_pos.x, cursor_screen_pos.y - g.FontSize + 0.5f, cursor_screen_pos.x + 1.0f, cursor_screen_pos.y - 1.5f);
            if (cursor_is_visible && cursor_screen_rect.Overlaps(clip_rect))
                draw_window->DrawList->AddLine(cursor_screen_rect.Min, cursor_screen_rect.GetBL(), GetColorU32(ImGuiCol_Text));

            // Notify OS of text input position for advanced IME (-1 x offset so that Windows IME can cover our cursor. Bit of an extra nicety.)
            if (!is_readonly)
                g.PlatformImePos = ImVec2(cursor_screen_pos.x - 1.0f, cursor_screen_pos.y - g.FontSize);
        }
    }
    else
    {
        // Render text only (no selection, no cursor)
        const char* buf_end = NULL;
        if (is_multiline)
            text_size = ImVec2(size.x, InputTextCalcTextLenAndLineCount(buf_display, &buf_end) * g.FontSize); // We don't need width
        else
            buf_end = buf_display + strlen(buf_display);
        if (is_multiline || (buf_end - buf_display) < buf_display_max_length)
            draw_window->DrawList->AddText(g.Font, g.FontSize, draw_pos, GetColorU32(ImGuiCol_Text), buf_display, buf_end, 0.0f, is_multiline ? NULL : &clip_rect);
    }

    if (is_multiline)
    {
        Dummy(text_size + ImVec2(0.0f, g.FontSize)); // Always add room to scroll an extra line
        EndChildFrame();
        EndGroup();
    }

    if (is_password)
        PopFont();

    // Log as text
    if (g.LogEnabled && !is_password)
        LogRenderedText(&draw_pos, buf_display, NULL);

    if (label_size.x > 0)
        RenderText(ImVec2(frame_bb.Max.x + style.ItemInnerSpacing.x, frame_bb.Min.y + style.FramePadding.y), label);

    if (value_changed)
        MarkItemEdited(id);

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, window->DC.ItemFlags);
    if ((flags & ImGuiInputTextFlags_EnterReturnsTrue) != 0)
        return enter_pressed;
    else
        return value_changed;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: ColorEdit, ColorPicker, ColorButton, etc.
//-------------------------------------------------------------------------
// - ColorEdit3()
// - ColorEdit4()
// - ColorPicker3()
// - RenderColorRectWithAlphaCheckerboard() [Internal]
// - ColorPicker4()
// - ColorButton()
// - SetColorEditOptions()
// - ColorTooltip() [Internal]
// - ColorEditOptionsPopup() [Internal]
// - ColorPickerOptionsPopup() [Internal]
//-------------------------------------------------------------------------

bool ImGui::ColorEdit3(const char* label, float col[3], ImGuiColorEditFlags flags)
{
    return ColorEdit4(label, col, flags | ImGuiColorEditFlags_NoAlpha);
}

// Edit colors components (each component in 0.0f..1.0f range).
// See enum ImGuiColorEditFlags_ for available options. e.g. Only access 3 floats if ImGuiColorEditFlags_NoAlpha flag is set.
// With typical options: Left-click on colored square to open color picker. Right-click to open option menu. CTRL-Click over input fields to edit them and TAB to go to next item.
bool ImGui::ColorEdit4(const char* label, float col[4], ImGuiColorEditFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const float square_sz = GetFrameHeight();
    const float w_extra = (flags & ImGuiColorEditFlags_NoSmallPreview) ? 0.0f : (square_sz + style.ItemInnerSpacing.x);
    const float w_items_all = CalcItemWidth() - w_extra;
    const char* label_display_end = FindRenderedTextEnd(label);

    BeginGroup();
    PushID(label);

    // If we're not showing any slider there's no point in doing any HSV conversions
    const ImGuiColorEditFlags flags_untouched = flags;
    if (flags & ImGuiColorEditFlags_NoInputs)
        flags = (flags & (~ImGuiColorEditFlags__InputsMask)) | ImGuiColorEditFlags_RGB | ImGuiColorEditFlags_NoOptions;

    // Context menu: display and modify options (before defaults are applied)
    if (!(flags & ImGuiColorEditFlags_NoOptions))
        ColorEditOptionsPopup(col, flags);

    // Read stored options
    if (!(flags & ImGuiColorEditFlags__InputsMask))
        flags |= (g.ColorEditOptions & ImGuiColorEditFlags__InputsMask);
    if (!(flags & ImGuiColorEditFlags__DataTypeMask))
        flags |= (g.ColorEditOptions & ImGuiColorEditFlags__DataTypeMask);
    if (!(flags & ImGuiColorEditFlags__PickerMask))
        flags |= (g.ColorEditOptions & ImGuiColorEditFlags__PickerMask);
    flags |= (g.ColorEditOptions & ~(ImGuiColorEditFlags__InputsMask | ImGuiColorEditFlags__DataTypeMask | ImGuiColorEditFlags__PickerMask));

    const bool alpha = (flags & ImGuiColorEditFlags_NoAlpha) == 0;
    const bool hdr = (flags & ImGuiColorEditFlags_HDR) != 0;
    const int components = alpha ? 4 : 3;

    // Convert to the formats we need
    float f[4] = { col[0], col[1], col[2], alpha ? col[3] : 1.0f };
    if (flags & ImGuiColorEditFlags_HSV)
        ColorConvertRGBtoHSV(f[0], f[1], f[2], f[0], f[1], f[2]);
    int i[4] = { IM_F32_TO_INT8_UNBOUND(f[0]), IM_F32_TO_INT8_UNBOUND(f[1]), IM_F32_TO_INT8_UNBOUND(f[2]), IM_F32_TO_INT8_UNBOUND(f[3]) };

    bool value_changed = false;
    bool value_changed_as_float = false;

    if ((flags & (ImGuiColorEditFlags_RGB | ImGuiColorEditFlags_HSV)) != 0 && (flags & ImGuiColorEditFlags_NoInputs) == 0)
    {
        // RGB/HSV 0..255 Sliders
        const float w_item_one  = ImMax(1.0f, (float)(int)((w_items_all - (style.ItemInnerSpacing.x) * (components-1)) / (float)components));
        const float w_item_last = ImMax(1.0f, (float)(int)(w_items_all - (w_item_one + style.ItemInnerSpacing.x) * (components-1)));

        const bool hide_prefix = (w_item_one <= CalcTextSize((flags & ImGuiColorEditFlags_Float) ? "M:0.000" : "M:000").x);
        const char* ids[4] = { "##X", "##Y", "##Z", "##W" };
        const char* fmt_table_int[3][4] =
        {
            {   "%3d",   "%3d",   "%3d",   "%3d" }, // Short display
            { "R:%3d", "G:%3d", "B:%3d", "A:%3d" }, // Long display for RGBA
            { "H:%3d", "S:%3d", "V:%3d", "A:%3d" }  // Long display for HSVA
        };
        const char* fmt_table_float[3][4] =
        {
            {   "%0.3f",   "%0.3f",   "%0.3f",   "%0.3f" }, // Short display
            { "R:%0.3f", "G:%0.3f", "B:%0.3f", "A:%0.3f" }, // Long display for RGBA
            { "H:%0.3f", "S:%0.3f", "V:%0.3f", "A:%0.3f" }  // Long display for HSVA
        };
        const int fmt_idx = hide_prefix ? 0 : (flags & ImGuiColorEditFlags_HSV) ? 2 : 1;

        PushItemWidth(w_item_one);
        for (int n = 0; n < components; n++)
        {
            if (n > 0)
                SameLine(0, style.ItemInnerSpacing.x);
            if (n + 1 == components)
                PushItemWidth(w_item_last);
            if (flags & ImGuiColorEditFlags_Float)
            {
                value_changed |= DragFloat(ids[n], &f[n], 1.0f/255.0f, 0.0f, hdr ? 0.0f : 1.0f, fmt_table_float[fmt_idx][n]);
                value_changed_as_float |= value_changed;
            }
            else
            {
                value_changed |= DragInt(ids[n], &i[n], 1.0f, 0, hdr ? 0 : 255, fmt_table_int[fmt_idx][n]);
            }
            if (!(flags & ImGuiColorEditFlags_NoOptions))
                OpenPopupOnItemClick("context");
        }
        PopItemWidth();
        PopItemWidth();
    }
    else if ((flags & ImGuiColorEditFlags_HEX) != 0 && (flags & ImGuiColorEditFlags_NoInputs) == 0)
    {
        // RGB Hexadecimal Input
        char buf[64];
        if (alpha)
            ImFormatString(buf, IM_ARRAYSIZE(buf), "#%02X%02X%02X%02X", ImClamp(i[0],0,255), ImClamp(i[1],0,255), ImClamp(i[2],0,255), ImClamp(i[3],0,255));
        else
            ImFormatString(buf, IM_ARRAYSIZE(buf), "#%02X%02X%02X", ImClamp(i[0],0,255), ImClamp(i[1],0,255), ImClamp(i[2],0,255));
        PushItemWidth(w_items_all);
       /* if (InputText("##Text", buf, IM_ARRAYSIZE(buf), ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsUppercase))
        {
            value_changed = true;
            char* p = buf;
            while (*p == '#' || ImCharIsBlankA(*p))
                p++;
            i[0] = i[1] = i[2] = i[3] = 0;
            if (alpha)
                sscanf(p, "%02X%02X%02X%02X", (unsigned int*)&i[0], (unsigned int*)&i[1], (unsigned int*)&i[2], (unsigned int*)&i[3]); // Treat at unsigned (%X is unsigned)
            else
                sscanf(p, "%02X%02X%02X", (unsigned int*)&i[0], (unsigned int*)&i[1], (unsigned int*)&i[2]);
        }*/
        if (!(flags & ImGuiColorEditFlags_NoOptions))
            OpenPopupOnItemClick("context");
        PopItemWidth();
    }

    ImGuiWindow* picker_active_window = NULL;
    if (!(flags & ImGuiColorEditFlags_NoSmallPreview))
    {
       /* if (!(flags & ImGuiColorEditFlags_NoInputs))
            SameLine(0, style.ItemInnerSpacing.x);*/

        const ImVec4 col_v4(col[0], col[1], col[2], alpha ? col[3] : 1.0f);
        if (ColorButton("##ColorButton", col_v4, flags))
        {
            if (!(flags & ImGuiColorEditFlags_NoPicker))
            {
                // Store current color and open a picker
                g.ColorPickerRef = col_v4;
                OpenPopup("picker");
                SetNextWindowPos(window->DC.LastItemRect.GetBL() + ImVec2(-1,style.ItemSpacing.y));
            }
        }
        if (!(flags & ImGuiColorEditFlags_NoOptions))
            OpenPopupOnItemClick("context");

        if (BeginPopup("picker"))
        {
            picker_active_window = g.CurrentWindow;
            if (label != label_display_end)
            {
                TextUnformatted(label, label_display_end);
                Spacing();
            }
            ImGuiColorEditFlags picker_flags_to_forward = ImGuiColorEditFlags__DataTypeMask | ImGuiColorEditFlags__PickerMask | ImGuiColorEditFlags_HDR | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_AlphaBar;
            ImGuiColorEditFlags picker_flags = (flags_untouched & picker_flags_to_forward) | ImGuiColorEditFlags__InputsMask | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaPreviewHalf;
            PushItemWidth(square_sz * 12.0f); // Use 256 + bar sizes?
            value_changed |= ColorPicker4("##picker", col, picker_flags, &g.ColorPickerRef.x);
            PopItemWidth();
            EndPopup();
        }
    }

    if (label != label_display_end && !(flags & ImGuiColorEditFlags_NoLabel))
    {
        SameLine(0, style.ItemInnerSpacing.x);
        TextUnformatted(label, label_display_end);
    }

    // Convert back
    if (picker_active_window == NULL)
    {
        if (!value_changed_as_float)
            for (int n = 0; n < 4; n++)
                f[n] = i[n] / 255.0f;
        if (flags & ImGuiColorEditFlags_HSV)
            ColorConvertHSVtoRGB(f[0], f[1], f[2], f[0], f[1], f[2]);
        if (value_changed)
        {
            col[0] = f[0];
            col[1] = f[1];
            col[2] = f[2];
            if (alpha)
                col[3] = f[3];
        }
    }

    PopID();
    EndGroup();

    // Drag and Drop Target
    // NB: The flag test is merely an optional micro-optimization, BeginDragDropTarget() does the same test.
    if ((window->DC.LastItemStatusFlags & ImGuiItemStatusFlags_HoveredRect) && !(flags & ImGuiColorEditFlags_NoDragDrop) && BeginDragDropTarget())
    {
        if (const ImGuiPayload* payload = AcceptDragDropPayload(IMGUI_PAYLOAD_TYPE_COLOR_3F))
        {
            memcpy((float*)col, payload->Data, sizeof(float) * 3); // Preserve alpha if any //-V512
            value_changed = true;
        }
        if (const ImGuiPayload* payload = AcceptDragDropPayload(IMGUI_PAYLOAD_TYPE_COLOR_4F))
        {
            memcpy((float*)col, payload->Data, sizeof(float) * components);
            value_changed = true;
        }
        EndDragDropTarget();
    }

    // When picker is being actively used, use its active id so IsItemActive() will function on ColorEdit4().
    if (picker_active_window && g.ActiveId != 0 && g.ActiveIdWindow == picker_active_window)
        window->DC.LastItemId = g.ActiveId;

    if (value_changed)
        MarkItemEdited(window->DC.LastItemId);

    return value_changed;
}

bool ImGui::ColorPicker3(const char* label, float col[3], ImGuiColorEditFlags flags)
{
    float col4[4] = { col[0], col[1], col[2], 1.0f };
    if (!ColorPicker4(label, col4, flags | ImGuiColorEditFlags_NoAlpha))
        return false;
    col[0] = col4[0]; col[1] = col4[1]; col[2] = col4[2];
    return true;
}

static inline ImU32 ImAlphaBlendColor(ImU32 col_a, ImU32 col_b)
{
    float t = ((col_b >> IM_COL32_A_SHIFT) & 0xFF) / 255.f;
    int r = ImLerp((int)(col_a >> IM_COL32_R_SHIFT) & 0xFF, (int)(col_b >> IM_COL32_R_SHIFT) & 0xFF, t);
    int g = ImLerp((int)(col_a >> IM_COL32_G_SHIFT) & 0xFF, (int)(col_b >> IM_COL32_G_SHIFT) & 0xFF, t);
    int b = ImLerp((int)(col_a >> IM_COL32_B_SHIFT) & 0xFF, (int)(col_b >> IM_COL32_B_SHIFT) & 0xFF, t);
    return IM_COL32(r, g, b, 0xFF);
}

// Helper for ColorPicker4()
// NB: This is rather brittle and will show artifact when rounding this enabled if rounded corners overlap multiple cells. Caller currently responsible for avoiding that.
// I spent a non reasonable amount of time trying to getting this right for ColorButton with rounding+anti-aliasing+ImGuiColorEditFlags_HalfAlphaPreview flag + various grid sizes and offsets, and eventually gave up... probably more reasonable to disable rounding alltogether.
void ImGui::RenderColorRectWithAlphaCheckerboard(ImVec2 p_min, ImVec2 p_max, ImU32 col, float grid_step, ImVec2 grid_off, float rounding, int rounding_corners_flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (((col & IM_COL32_A_MASK) >> IM_COL32_A_SHIFT) < 0xFF)
    {
        ImU32 col_bg1 = GetColorU32(ImAlphaBlendColor(IM_COL32(204,204,204,255), col));
        ImU32 col_bg2 = GetColorU32(ImAlphaBlendColor(IM_COL32(128,128,128,255), col));
        window->DrawList->AddRectFilled(p_min, p_max, col_bg1, rounding, rounding_corners_flags);

        int yi = 0;
        for (float y = p_min.y + grid_off.y; y < p_max.y; y += grid_step, yi++)
        {
            float y1 = ImClamp(y, p_min.y, p_max.y), y2 = ImMin(y + grid_step, p_max.y);
            if (y2 <= y1)
                continue;
            for (float x = p_min.x + grid_off.x + (yi & 1) * grid_step; x < p_max.x; x += grid_step * 2.0f)
            {
                float x1 = ImClamp(x, p_min.x, p_max.x), x2 = ImMin(x + grid_step, p_max.x);
                if (x2 <= x1)
                    continue;
                int rounding_corners_flags_cell = 0;
                if (y1 <= p_min.y) { if (x1 <= p_min.x) rounding_corners_flags_cell |= ImDrawCornerFlags_TopLeft; if (x2 >= p_max.x) rounding_corners_flags_cell |= ImDrawCornerFlags_TopRight; }
                if (y2 >= p_max.y) { if (x1 <= p_min.x) rounding_corners_flags_cell |= ImDrawCornerFlags_BotLeft; if (x2 >= p_max.x) rounding_corners_flags_cell |= ImDrawCornerFlags_BotRight; }
                rounding_corners_flags_cell &= rounding_corners_flags;
                window->DrawList->AddRectFilled(ImVec2(x1,y1), ImVec2(x2,y2), col_bg2, rounding_corners_flags_cell ? rounding : 0.0f, rounding_corners_flags_cell);
            }
        }
    }
    else
    {
        window->DrawList->AddRectFilled(p_min, p_max, col, rounding, rounding_corners_flags);
    }
}

// Helper for ColorPicker4()
static void RenderArrowsForVerticalBar(ImDrawList* draw_list, ImVec2 pos, ImVec2 half_sz, float bar_w)
{
    ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + half_sz.x + 1,         pos.y), ImVec2(half_sz.x + 2, half_sz.y + 1), ImGuiDir_Right, IM_COL32_BLACK);
    ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + half_sz.x,             pos.y), half_sz,                              ImGuiDir_Right, IM_COL32_WHITE);
    ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + bar_w - half_sz.x - 1, pos.y), ImVec2(half_sz.x + 2, half_sz.y + 1), ImGuiDir_Left,  IM_COL32_BLACK);
    ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + bar_w - half_sz.x,     pos.y), half_sz,                              ImGuiDir_Left,  IM_COL32_WHITE);
}

// Note: ColorPicker4() only accesses 3 floats if ImGuiColorEditFlags_NoAlpha flag is set.
// FIXME: we adjust the big color square height based on item width, which may cause a flickering feedback loop (if automatic height makes a vertical scrollbar appears, affecting automatic width..)
bool ImGui::ColorPicker4(const char* label, float col[4], ImGuiColorEditFlags flags, const float* ref_col)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = GetCurrentWindow();
    ImDrawList* draw_list = window->DrawList;

    ImGuiStyle& style = g.Style;
    ImGuiIO& io = g.IO;

    PushID(label);
    BeginGroup();

    if (!(flags & ImGuiColorEditFlags_NoSidePreview))
        flags |= ImGuiColorEditFlags_NoSmallPreview;

    // Context menu: display and store options.
    if (!(flags & ImGuiColorEditFlags_NoOptions))
        ColorPickerOptionsPopup(col, flags);

    // Read stored options
    if (!(flags & ImGuiColorEditFlags__PickerMask))
        flags |= ((g.ColorEditOptions & ImGuiColorEditFlags__PickerMask) ? g.ColorEditOptions : ImGuiColorEditFlags__OptionsDefault) & ImGuiColorEditFlags__PickerMask;
    IM_ASSERT(ImIsPowerOfTwo((int)(flags & ImGuiColorEditFlags__PickerMask))); // Check that only 1 is selected
    if (!(flags & ImGuiColorEditFlags_NoOptions))
        flags |= (g.ColorEditOptions & ImGuiColorEditFlags_AlphaBar);

    // Setup
    int components = (flags & ImGuiColorEditFlags_NoAlpha) ? 3 : 4;
    bool alpha_bar = (flags & ImGuiColorEditFlags_AlphaBar) && !(flags & ImGuiColorEditFlags_NoAlpha);
    ImVec2 picker_pos = window->DC.CursorPos;
    float square_sz = GetFrameHeight();
    float bars_width = square_sz; // Arbitrary smallish width of Hue/Alpha picking bars
    float sv_picker_size = ImMax(bars_width * 1, CalcItemWidth() - (alpha_bar ? 2 : 1) * (bars_width + style.ItemInnerSpacing.x)); // Saturation/Value picking box
    float bar0_pos_x = picker_pos.x + sv_picker_size + style.ItemInnerSpacing.x;
    float bar1_pos_x = bar0_pos_x + bars_width + style.ItemInnerSpacing.x;
    float bars_triangles_half_sz = (float)(int)(bars_width * 0.20f);

    float backup_initial_col[4];
    memcpy(backup_initial_col, col, components * sizeof(float));

    float wheel_thickness = sv_picker_size * 0.08f;
    float wheel_r_outer = sv_picker_size * 0.50f;
    float wheel_r_inner = wheel_r_outer - wheel_thickness;
    ImVec2 wheel_center(picker_pos.x + (sv_picker_size + bars_width)*0.5f, picker_pos.y + sv_picker_size*0.5f);

    // Note: the triangle is displayed rotated with triangle_pa pointing to Hue, but most coordinates stays unrotated for logic.
    float triangle_r = wheel_r_inner - (int)(sv_picker_size * 0.027f);
    ImVec2 triangle_pa = ImVec2(triangle_r, 0.0f); // Hue point.
    ImVec2 triangle_pb = ImVec2(triangle_r * -0.5f, triangle_r * -0.866025f); // Black point.
    ImVec2 triangle_pc = ImVec2(triangle_r * -0.5f, triangle_r * +0.866025f); // White point.

    float H,S,V;
    ColorConvertRGBtoHSV(col[0], col[1], col[2], H, S, V);

    bool value_changed = false, value_changed_h = false, value_changed_sv = false;

    PushItemFlag(ImGuiItemFlags_NoNav, true);
    if (flags & ImGuiColorEditFlags_PickerHueWheel)
    {
        // Hue wheel + SV triangle logic
        InvisibleButton("hsv", ImVec2(sv_picker_size + style.ItemInnerSpacing.x + bars_width, sv_picker_size));
        if (IsItemActive())
        {
            ImVec2 initial_off = g.IO.MouseClickedPos[0] - wheel_center;
            ImVec2 current_off = g.IO.MousePos - wheel_center;
            float initial_dist2 = ImLengthSqr(initial_off);
            if (initial_dist2 >= (wheel_r_inner-1)*(wheel_r_inner-1) && initial_dist2 <= (wheel_r_outer+1)*(wheel_r_outer+1))
            {
                // Interactive with Hue wheel
                H = ImAtan2(current_off.y, current_off.x) / IM_PI*0.5f;
                if (H < 0.0f)
                    H += 1.0f;
                value_changed = value_changed_h = true;
            }
            float cos_hue_angle = ImCos(-H * 2.0f * IM_PI);
            float sin_hue_angle = ImSin(-H * 2.0f * IM_PI);
            if (ImTriangleContainsPoint(triangle_pa, triangle_pb, triangle_pc, ImRotate(initial_off, cos_hue_angle, sin_hue_angle)))
            {
                // Interacting with SV triangle
                ImVec2 current_off_unrotated = ImRotate(current_off, cos_hue_angle, sin_hue_angle);
                if (!ImTriangleContainsPoint(triangle_pa, triangle_pb, triangle_pc, current_off_unrotated))
                    current_off_unrotated = ImTriangleClosestPoint(triangle_pa, triangle_pb, triangle_pc, current_off_unrotated);
                float uu, vv, ww;
                ImTriangleBarycentricCoords(triangle_pa, triangle_pb, triangle_pc, current_off_unrotated, uu, vv, ww);
                V = ImClamp(1.0f - vv, 0.0001f, 1.0f);
                S = ImClamp(uu / V, 0.0001f, 1.0f);
                value_changed = value_changed_sv = true;
            }
        }
        if (!(flags & ImGuiColorEditFlags_NoOptions))
            OpenPopupOnItemClick("context");
    }
    else if (flags & ImGuiColorEditFlags_PickerHueBar)
    {
        // SV rectangle logic
        InvisibleButton("sv", ImVec2(sv_picker_size, sv_picker_size));
        if (IsItemActive())
        {
            S = ImSaturate((io.MousePos.x - picker_pos.x) / (sv_picker_size-1));
            V = 1.0f - ImSaturate((io.MousePos.y - picker_pos.y) / (sv_picker_size-1));
            value_changed = value_changed_sv = true;
        }
        if (!(flags & ImGuiColorEditFlags_NoOptions))
            OpenPopupOnItemClick("context");

        // Hue bar logic
        SetCursorScreenPos(ImVec2(bar0_pos_x, picker_pos.y));
        InvisibleButton("hue", ImVec2(bars_width, sv_picker_size));
        if (IsItemActive())
        {
            H = ImSaturate((io.MousePos.y - picker_pos.y) / (sv_picker_size-1));
            value_changed = value_changed_h = true;
        }
    }

    // Alpha bar logic
    if (alpha_bar)
    {
        SetCursorScreenPos(ImVec2(bar1_pos_x, picker_pos.y));
        InvisibleButton("alpha", ImVec2(bars_width, sv_picker_size));
        if (IsItemActive())
        {
            col[3] = 1.0f - ImSaturate((io.MousePos.y - picker_pos.y) / (sv_picker_size-1));
            value_changed = true;
        }
    }
    PopItemFlag(); // ImGuiItemFlags_NoNav

    if (!(flags & ImGuiColorEditFlags_NoSidePreview))
    {
        SameLine(0, style.ItemInnerSpacing.x);
        BeginGroup();
    }

    if (!(flags & ImGuiColorEditFlags_NoLabel))
    {
        const char* label_display_end = FindRenderedTextEnd(label);
        if (label != label_display_end)
        {
            if ((flags & ImGuiColorEditFlags_NoSidePreview))
                SameLine(0, style.ItemInnerSpacing.x);
            TextUnformatted(label, label_display_end);
        }
    }

    if (!(flags & ImGuiColorEditFlags_NoSidePreview))
    {
        PushItemFlag(ImGuiItemFlags_NoNavDefaultFocus, true);
        ImVec4 col_v4(col[0], col[1], col[2], (flags & ImGuiColorEditFlags_NoAlpha) ? 1.0f : col[3]);
        if ((flags & ImGuiColorEditFlags_NoLabel))
            Text("Current");
        ColorButton("##current", col_v4, (flags & (ImGuiColorEditFlags_HDR|ImGuiColorEditFlags_AlphaPreview|ImGuiColorEditFlags_AlphaPreviewHalf|ImGuiColorEditFlags_NoTooltip)), ImVec2(square_sz * 3, square_sz * 2));
        if (ref_col != NULL)
        {
            Text("Original");
            ImVec4 ref_col_v4(ref_col[0], ref_col[1], ref_col[2], (flags & ImGuiColorEditFlags_NoAlpha) ? 1.0f : ref_col[3]);
            if (ColorButton("##original", ref_col_v4, (flags & (ImGuiColorEditFlags_HDR|ImGuiColorEditFlags_AlphaPreview|ImGuiColorEditFlags_AlphaPreviewHalf|ImGuiColorEditFlags_NoTooltip)), ImVec2(square_sz * 3, square_sz * 2)))
            {
                memcpy(col, ref_col, components * sizeof(float));
                value_changed = true;
            }
        }
        PopItemFlag();
        EndGroup();
    }

    // Convert back color to RGB
    if (value_changed_h || value_changed_sv)
        ColorConvertHSVtoRGB(H >= 1.0f ? H - 10 * 1e-6f : H, S > 0.0f ? S : 10*1e-6f, V > 0.0f ? V : 1e-6f, col[0], col[1], col[2]);

    // R,G,B and H,S,V slider color editor
    bool value_changed_fix_hue_wrap = false;
    if ((flags & ImGuiColorEditFlags_NoInputs) == 0)
    {
        PushItemWidth((alpha_bar ? bar1_pos_x : bar0_pos_x) + bars_width - picker_pos.x);
        ImGuiColorEditFlags sub_flags_to_forward = ImGuiColorEditFlags__DataTypeMask | ImGuiColorEditFlags_HDR | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_NoOptions | ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_AlphaPreviewHalf;
        ImGuiColorEditFlags sub_flags = (flags & sub_flags_to_forward) | ImGuiColorEditFlags_NoPicker;
        if (flags & ImGuiColorEditFlags_RGB || (flags & ImGuiColorEditFlags__InputsMask) == 0)
            if (ColorEdit4("##rgb", col, sub_flags | ImGuiColorEditFlags_RGB))
            {
                // FIXME: Hackily differenciating using the DragInt (ActiveId != 0 && !ActiveIdAllowOverlap) vs. using the InputText or DropTarget.
                // For the later we don't want to run the hue-wrap canceling code. If you are well versed in HSV picker please provide your input! (See #2050)
                value_changed_fix_hue_wrap = (g.ActiveId != 0 && !g.ActiveIdAllowOverlap);
                value_changed = true;
            }
        if (flags & ImGuiColorEditFlags_HSV || (flags & ImGuiColorEditFlags__InputsMask) == 0)
            value_changed |= ColorEdit4("##hsv", col, sub_flags | ImGuiColorEditFlags_HSV);
        if (flags & ImGuiColorEditFlags_HEX || (flags & ImGuiColorEditFlags__InputsMask) == 0)
            value_changed |= ColorEdit4("##hex", col, sub_flags | ImGuiColorEditFlags_HEX);
        PopItemWidth();
    }

    // Try to cancel hue wrap (after ColorEdit4 call), if any
    if (value_changed_fix_hue_wrap)
    {
        float new_H, new_S, new_V;
        ColorConvertRGBtoHSV(col[0], col[1], col[2], new_H, new_S, new_V);
        if (new_H <= 0 && H > 0)
        {
            if (new_V <= 0 && V != new_V)
                ColorConvertHSVtoRGB(H, S, new_V <= 0 ? V * 0.5f : new_V, col[0], col[1], col[2]);
            else if (new_S <= 0)
                ColorConvertHSVtoRGB(H, new_S <= 0 ? S * 0.5f : new_S, new_V, col[0], col[1], col[2]);
        }
    }

    ImVec4 hue_color_f(1, 1, 1, 1); ColorConvertHSVtoRGB(H, 1, 1, hue_color_f.x, hue_color_f.y, hue_color_f.z);
    ImU32 hue_color32 = ColorConvertFloat4ToU32(hue_color_f);
    ImU32 col32_no_alpha = ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 1.0f));

    const ImU32 hue_colors[6+1] = { IM_COL32(255,0,0,255), IM_COL32(255,255,0,255), IM_COL32(0,255,0,255), IM_COL32(0,255,255,255), IM_COL32(0,0,255,255), IM_COL32(255,0,255,255), IM_COL32(255,0,0,255) };
    ImVec2 sv_cursor_pos;

    if (flags & ImGuiColorEditFlags_PickerHueWheel)
    {
        // Render Hue Wheel
        const float aeps = 1.5f / wheel_r_outer; // Half a pixel arc length in radians (2pi cancels out).
        const int segment_per_arc = ImMax(4, (int)wheel_r_outer / 12);
        for (int n = 0; n < 6; n++)
        {
            const float a0 = (n)     /6.0f * 2.0f * IM_PI - aeps;
            const float a1 = (n+1.0f)/6.0f * 2.0f * IM_PI + aeps;
            const int vert_start_idx = draw_list->VtxBuffer.Size;
            draw_list->PathArcTo(wheel_center, (wheel_r_inner + wheel_r_outer)*0.5f, a0, a1, segment_per_arc);
            draw_list->PathStroke(IM_COL32_WHITE, false, wheel_thickness);
            const int vert_end_idx = draw_list->VtxBuffer.Size;

            // Paint colors over existing vertices
            ImVec2 gradient_p0(wheel_center.x + ImCos(a0) * wheel_r_inner, wheel_center.y + ImSin(a0) * wheel_r_inner);
            ImVec2 gradient_p1(wheel_center.x + ImCos(a1) * wheel_r_inner, wheel_center.y + ImSin(a1) * wheel_r_inner);
            ShadeVertsLinearColorGradientKeepAlpha(draw_list, vert_start_idx, vert_end_idx, gradient_p0, gradient_p1, hue_colors[n], hue_colors[n+1]);
        }

        // Render Cursor + preview on Hue Wheel
        float cos_hue_angle = ImCos(H * 2.0f * IM_PI);
        float sin_hue_angle = ImSin(H * 2.0f * IM_PI);
        ImVec2 hue_cursor_pos(wheel_center.x + cos_hue_angle * (wheel_r_inner+wheel_r_outer)*0.5f, wheel_center.y + sin_hue_angle * (wheel_r_inner+wheel_r_outer)*0.5f);
        float hue_cursor_rad = value_changed_h ? wheel_thickness * 0.65f : wheel_thickness * 0.55f;
        int hue_cursor_segments = ImClamp((int)(hue_cursor_rad / 1.4f), 9, 32);
        draw_list->AddCircleFilled(hue_cursor_pos, hue_cursor_rad, hue_color32, hue_cursor_segments);
        draw_list->AddCircle(hue_cursor_pos, hue_cursor_rad+1, IM_COL32(128,128,128,255), hue_cursor_segments);
        draw_list->AddCircle(hue_cursor_pos, hue_cursor_rad, IM_COL32_WHITE, hue_cursor_segments);

        // Render SV triangle (rotated according to hue)
        ImVec2 tra = wheel_center + ImRotate(triangle_pa, cos_hue_angle, sin_hue_angle);
        ImVec2 trb = wheel_center + ImRotate(triangle_pb, cos_hue_angle, sin_hue_angle);
        ImVec2 trc = wheel_center + ImRotate(triangle_pc, cos_hue_angle, sin_hue_angle);
        ImVec2 uv_white = GetFontTexUvWhitePixel();
        draw_list->PrimReserve(6, 6);
        draw_list->PrimVtx(tra, uv_white, hue_color32);
        draw_list->PrimVtx(trb, uv_white, hue_color32);
        draw_list->PrimVtx(trc, uv_white, IM_COL32_WHITE);
        draw_list->PrimVtx(tra, uv_white, IM_COL32_BLACK_TRANS);
        draw_list->PrimVtx(trb, uv_white, IM_COL32_BLACK);
        draw_list->PrimVtx(trc, uv_white, IM_COL32_BLACK_TRANS);
        draw_list->AddTriangle(tra, trb, trc, IM_COL32(128,128,128,255), 1.5f);
        sv_cursor_pos = ImLerp(ImLerp(trc, tra, ImSaturate(S)), trb, ImSaturate(1 - V));
    }
    else if (flags & ImGuiColorEditFlags_PickerHueBar)
    {
        // Render SV Square
        draw_list->AddRectFilledMultiColor(picker_pos, picker_pos + ImVec2(sv_picker_size,sv_picker_size), IM_COL32_WHITE, hue_color32, hue_color32, IM_COL32_WHITE);
        draw_list->AddRectFilledMultiColor(picker_pos, picker_pos + ImVec2(sv_picker_size,sv_picker_size), IM_COL32_BLACK_TRANS, IM_COL32_BLACK_TRANS, IM_COL32_BLACK, IM_COL32_BLACK);
        RenderFrameBorder(picker_pos, picker_pos + ImVec2(sv_picker_size,sv_picker_size), 0.0f);
        sv_cursor_pos.x = ImClamp((float)(int)(picker_pos.x + ImSaturate(S)     * sv_picker_size + 0.5f), picker_pos.x + 2, picker_pos.x + sv_picker_size - 2); // Sneakily prevent the circle to stick out too much
        sv_cursor_pos.y = ImClamp((float)(int)(picker_pos.y + ImSaturate(1 - V) * sv_picker_size + 0.5f), picker_pos.y + 2, picker_pos.y + sv_picker_size - 2);

        // Render Hue Bar
        for (int i = 0; i < 6; ++i)
            draw_list->AddRectFilledMultiColor(ImVec2(bar0_pos_x, picker_pos.y + i * (sv_picker_size / 6)), ImVec2(bar0_pos_x + bars_width, picker_pos.y + (i + 1) * (sv_picker_size / 6)), hue_colors[i], hue_colors[i], hue_colors[i + 1], hue_colors[i + 1]);
        float bar0_line_y = (float)(int)(picker_pos.y + H * sv_picker_size + 0.5f);
        RenderFrameBorder(ImVec2(bar0_pos_x, picker_pos.y), ImVec2(bar0_pos_x + bars_width, picker_pos.y + sv_picker_size), 0.0f);
        RenderArrowsForVerticalBar(draw_list, ImVec2(bar0_pos_x - 1, bar0_line_y), ImVec2(bars_triangles_half_sz + 1, bars_triangles_half_sz), bars_width + 2.0f);
    }

    // Render cursor/preview circle (clamp S/V within 0..1 range because floating points colors may lead HSV values to be out of range)
    float sv_cursor_rad = value_changed_sv ? 10.0f : 6.0f;
    draw_list->AddCircleFilled(sv_cursor_pos, sv_cursor_rad, col32_no_alpha, 12);
    draw_list->AddCircle(sv_cursor_pos, sv_cursor_rad+1, IM_COL32(128,128,128,255), 12);
    draw_list->AddCircle(sv_cursor_pos, sv_cursor_rad, IM_COL32_WHITE, 12);

    // Render alpha bar
    if (alpha_bar)
    {
        float alpha = ImSaturate(col[3]);
        ImRect bar1_bb(bar1_pos_x, picker_pos.y, bar1_pos_x + bars_width, picker_pos.y + sv_picker_size);
        RenderColorRectWithAlphaCheckerboard(bar1_bb.Min, bar1_bb.Max, IM_COL32(0,0,0,0), bar1_bb.GetWidth() / 2.0f, ImVec2(0.0f, 0.0f));
        draw_list->AddRectFilledMultiColor(bar1_bb.Min, bar1_bb.Max, col32_no_alpha, col32_no_alpha, col32_no_alpha & ~IM_COL32_A_MASK, col32_no_alpha & ~IM_COL32_A_MASK);
        float bar1_line_y = (float)(int)(picker_pos.y + (1.0f - alpha) * sv_picker_size + 0.5f);
        RenderFrameBorder(bar1_bb.Min, bar1_bb.Max, 0.0f);
        RenderArrowsForVerticalBar(draw_list, ImVec2(bar1_pos_x - 1, bar1_line_y), ImVec2(bars_triangles_half_sz + 1, bars_triangles_half_sz), bars_width + 2.0f);
    }

    EndGroup();

    if (value_changed && memcmp(backup_initial_col, col, components * sizeof(float)) == 0)
        value_changed = false;
    if (value_changed)
        MarkItemEdited(window->DC.LastItemId);

    PopID();

    return value_changed;
}

// A little colored square. Return true when clicked.
// FIXME: May want to display/ignore the alpha component in the color display? Yet show it in the tooltip.
// 'desc_id' is not called 'label' because we don't display it next to the button, but only in the tooltip.
bool ImGui::ColorButton(const char* desc_id, const ImVec4& col, ImGuiColorEditFlags flags, ImVec2 size)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(desc_id);
    float default_size = GetFrameHeight();
    if (size.x == 0.0f)
        size.x = default_size;
    if (size.y == 0.0f)
        size.y = default_size;
    const ImRect bb(window->DC.CursorPos, window->DC.CursorPos + size);
    ItemSize(bb, (size.y >= default_size) ? g.Style.FramePadding.y : 0.0f);
    if (!ItemAdd(bb, id))
        return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);

    if (flags & ImGuiColorEditFlags_NoAlpha)
        flags &= ~(ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_AlphaPreviewHalf);

    ImVec4 col_without_alpha(col.x, col.y, col.z, 1.0f);
    float grid_step = ImMin(size.x, size.y) / 2.99f;
    float rounding = ImMin(g.Style.FrameRounding, grid_step * 0.5f);
    ImRect bb_inner = bb;
    float off = -0.75f; // The border (using Col_FrameBg) tends to look off when color is near-opaque and rounding is enabled. This offset seemed like a good middle ground to reduce those artifacts.
    bb_inner.Expand(off);
    if ((flags & ImGuiColorEditFlags_AlphaPreviewHalf) && col.w < 1.0f)
    {
        float mid_x = (float)(int)((bb_inner.Min.x + bb_inner.Max.x) * 0.5f + 0.5f);
        RenderColorRectWithAlphaCheckerboard(ImVec2(bb_inner.Min.x + grid_step, bb_inner.Min.y), bb_inner.Max, GetColorU32(col), grid_step, ImVec2(-grid_step + off, off), rounding, ImDrawCornerFlags_TopRight| ImDrawCornerFlags_BotRight);
        window->DrawList->AddRectFilled(bb_inner.Min, ImVec2(mid_x, bb_inner.Max.y), GetColorU32(col_without_alpha), rounding, ImDrawCornerFlags_TopLeft|ImDrawCornerFlags_BotLeft);
    }
    else
    {
        // Because GetColorU32() multiplies by the global style Alpha and we don't want to display a checkerboard if the source code had no alpha
        ImVec4 col_source = (flags & ImGuiColorEditFlags_AlphaPreview) ? col : col_without_alpha;
        if (col_source.w < 1.0f)
            RenderColorRectWithAlphaCheckerboard(bb_inner.Min, bb_inner.Max, GetColorU32(col_source), grid_step, ImVec2(off, off), rounding);
        else
            window->DrawList->AddRectFilled(bb_inner.Min, bb_inner.Max, GetColorU32(col_source), rounding, ImDrawCornerFlags_All);
    }
    RenderNavHighlight(bb, id);
    if (g.Style.FrameBorderSize > 0.0f)
        RenderFrameBorder(bb.Min, bb.Max, rounding);
    else
        window->DrawList->AddRect(bb.Min, bb.Max, GetColorU32(ImGuiCol_FrameBg), rounding); // Color button are often in need of some sort of border

    // Drag and Drop Source
    // NB: The ActiveId test is merely an optional micro-optimization, BeginDragDropSource() does the same test.
    if (g.ActiveId == id && !(flags & ImGuiColorEditFlags_NoDragDrop) && BeginDragDropSource())
    {
        if (flags & ImGuiColorEditFlags_NoAlpha)
            SetDragDropPayload(IMGUI_PAYLOAD_TYPE_COLOR_3F, &col, sizeof(float) * 3, ImGuiCond_Once);
        else
            SetDragDropPayload(IMGUI_PAYLOAD_TYPE_COLOR_4F, &col, sizeof(float) * 4, ImGuiCond_Once);
        ColorButton(desc_id, col, flags);
        SameLine();
        TextUnformatted("Color");
        EndDragDropSource();
    }

    // Tooltip
    if (!(flags & ImGuiColorEditFlags_NoTooltip) && hovered)
        ColorTooltip(desc_id, &col.x, flags & (ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_AlphaPreviewHalf));

    if (pressed)
        MarkItemEdited(id);

    return pressed;
}

void ImGui::SetColorEditOptions(ImGuiColorEditFlags flags)
{
    ImGuiContext& g = *GImGui;
    if ((flags & ImGuiColorEditFlags__InputsMask) == 0)
        flags |= ImGuiColorEditFlags__OptionsDefault & ImGuiColorEditFlags__InputsMask;
    if ((flags & ImGuiColorEditFlags__DataTypeMask) == 0)
        flags |= ImGuiColorEditFlags__OptionsDefault & ImGuiColorEditFlags__DataTypeMask;
    if ((flags & ImGuiColorEditFlags__PickerMask) == 0)
        flags |= ImGuiColorEditFlags__OptionsDefault & ImGuiColorEditFlags__PickerMask;
    IM_ASSERT(ImIsPowerOfTwo((int)(flags & ImGuiColorEditFlags__InputsMask)));   // Check only 1 option is selected
    IM_ASSERT(ImIsPowerOfTwo((int)(flags & ImGuiColorEditFlags__DataTypeMask))); // Check only 1 option is selected
    IM_ASSERT(ImIsPowerOfTwo((int)(flags & ImGuiColorEditFlags__PickerMask)));   // Check only 1 option is selected
    g.ColorEditOptions = flags;
}

// Note: only access 3 floats if ImGuiColorEditFlags_NoAlpha flag is set.
void ImGui::ColorTooltip(const char* text, const float* col, ImGuiColorEditFlags flags)
{
    ImGuiContext& g = *GImGui;

    int cr = IM_F32_TO_INT8_SAT(col[0]), cg = IM_F32_TO_INT8_SAT(col[1]), cb = IM_F32_TO_INT8_SAT(col[2]), ca = (flags & ImGuiColorEditFlags_NoAlpha) ? 255 : IM_F32_TO_INT8_SAT(col[3]);
    BeginTooltipEx(0, true);

    const char* text_end = text ? FindRenderedTextEnd(text, NULL) : text;
    if (text_end > text)
    {
        TextUnformatted(text, text_end);
        Separator();
    }

    ImVec2 sz(g.FontSize * 3 + g.Style.FramePadding.y * 2, g.FontSize * 3 + g.Style.FramePadding.y * 2);
    ColorButton("##preview", ImVec4(col[0], col[1], col[2], col[3]), (flags & (ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_AlphaPreviewHalf)) | ImGuiColorEditFlags_NoTooltip, sz);
    SameLine();
    if (flags & ImGuiColorEditFlags_NoAlpha)
        Text("#%02X%02X%02X\nR: %d, G: %d, B: %d\n(%.3f, %.3f, %.3f)", cr, cg, cb, cr, cg, cb, col[0], col[1], col[2]);
    else
        Text("#%02X%02X%02X%02X\nR:%d, G:%d, B:%d, A:%d\n(%.3f, %.3f, %.3f, %.3f)", cr, cg, cb, ca, cr, cg, cb, ca, col[0], col[1], col[2], col[3]);
    EndTooltip();
}

void ImGui::ColorEditOptionsPopup(const float* col, ImGuiColorEditFlags flags)
{
    bool allow_opt_inputs = !(flags & ImGuiColorEditFlags__InputsMask);
    bool allow_opt_datatype = !(flags & ImGuiColorEditFlags__DataTypeMask);
    if ((!allow_opt_inputs && !allow_opt_datatype) || !BeginPopup("context"))
        return;
    ImGuiContext& g = *GImGui;
    ImGuiColorEditFlags opts = g.ColorEditOptions;
    if (allow_opt_inputs)
    {
        if (RadioButton("RGB", (opts & ImGuiColorEditFlags_RGB) != 0)) opts = (opts & ~ImGuiColorEditFlags__InputsMask) | ImGuiColorEditFlags_RGB;
        if (RadioButton("HSV", (opts & ImGuiColorEditFlags_HSV) != 0)) opts = (opts & ~ImGuiColorEditFlags__InputsMask) | ImGuiColorEditFlags_HSV;
        if (RadioButton("HEX", (opts & ImGuiColorEditFlags_HEX) != 0)) opts = (opts & ~ImGuiColorEditFlags__InputsMask) | ImGuiColorEditFlags_HEX;
    }
    if (allow_opt_datatype)
    {
        if (allow_opt_inputs) Separator();
        if (RadioButton("0..255",     (opts & ImGuiColorEditFlags_Uint8) != 0)) opts = (opts & ~ImGuiColorEditFlags__DataTypeMask) | ImGuiColorEditFlags_Uint8;
        if (RadioButton("0.00..1.00", (opts & ImGuiColorEditFlags_Float) != 0)) opts = (opts & ~ImGuiColorEditFlags__DataTypeMask) | ImGuiColorEditFlags_Float;
    }

    if (allow_opt_inputs || allow_opt_datatype)
        Separator();
    if (Button("Copy as..", ImVec2(-1,0)))
        OpenPopup("Copy");
    if (BeginPopup("Copy"))
    {
        int cr = IM_F32_TO_INT8_SAT(col[0]), cg = IM_F32_TO_INT8_SAT(col[1]), cb = IM_F32_TO_INT8_SAT(col[2]), ca = (flags & ImGuiColorEditFlags_NoAlpha) ? 255 : IM_F32_TO_INT8_SAT(col[3]);
        char buf[64];
        ImFormatString(buf, IM_ARRAYSIZE(buf), "(%.3ff, %.3ff, %.3ff, %.3ff)", col[0], col[1], col[2], (flags & ImGuiColorEditFlags_NoAlpha) ? 1.0f : col[3]);
        if (Selectable(buf))
            SetClipboardText(buf);
        ImFormatString(buf, IM_ARRAYSIZE(buf), "(%d,%d,%d,%d)", cr, cg, cb, ca);
        if (Selectable(buf))
            SetClipboardText(buf);
        if (flags & ImGuiColorEditFlags_NoAlpha)
            ImFormatString(buf, IM_ARRAYSIZE(buf), "0x%02X%02X%02X", cr, cg, cb);
        else
            ImFormatString(buf, IM_ARRAYSIZE(buf), "0x%02X%02X%02X%02X", cr, cg, cb, ca);
        if (Selectable(buf))
            SetClipboardText(buf);
        EndPopup();
    }

    g.ColorEditOptions = opts;
    EndPopup();
}

void ImGui::ColorPickerOptionsPopup(const float* ref_col, ImGuiColorEditFlags flags)
{
    bool allow_opt_picker = !(flags & ImGuiColorEditFlags__PickerMask);
    bool allow_opt_alpha_bar = !(flags & ImGuiColorEditFlags_NoAlpha) && !(flags & ImGuiColorEditFlags_AlphaBar);
    if ((!allow_opt_picker && !allow_opt_alpha_bar) || !BeginPopup("context"))
        return;
    ImGuiContext& g = *GImGui;
    if (allow_opt_picker)
    {
        ImVec2 picker_size(g.FontSize * 8, ImMax(g.FontSize * 8 - (GetFrameHeight() + g.Style.ItemInnerSpacing.x), 1.0f)); // FIXME: Picker size copied from main picker function
        PushItemWidth(picker_size.x);
        for (int picker_type = 0; picker_type < 2; picker_type++)
        {
            // Draw small/thumbnail version of each picker type (over an invisible button for selection)
            if (picker_type > 0) Separator();
            PushID(picker_type);
            ImGuiColorEditFlags picker_flags = ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoOptions|ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview|(flags & ImGuiColorEditFlags_NoAlpha);
            if (picker_type == 0) picker_flags |= ImGuiColorEditFlags_PickerHueBar;
            if (picker_type == 1) picker_flags |= ImGuiColorEditFlags_PickerHueWheel;
            ImVec2 backup_pos = GetCursorScreenPos();
            if (Selectable("##selectable", false, 0, picker_size)) // By default, Selectable() is closing popup
                g.ColorEditOptions = (g.ColorEditOptions & ~ImGuiColorEditFlags__PickerMask) | (picker_flags & ImGuiColorEditFlags__PickerMask);
            SetCursorScreenPos(backup_pos);
            ImVec4 dummy_ref_col;
            memcpy(&dummy_ref_col, ref_col, sizeof(float) * ((picker_flags & ImGuiColorEditFlags_NoAlpha) ? 3 : 4));
            ColorPicker4("##dummypicker", &dummy_ref_col.x, picker_flags);
            PopID();
        }
        PopItemWidth();
    }
    if (allow_opt_alpha_bar)
    {
        if (allow_opt_picker) Separator();
        CheckboxFlags("Alpha Bar", (unsigned int*)&g.ColorEditOptions, ImGuiColorEditFlags_AlphaBar);
    }
    EndPopup();
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: TreeNode, CollapsingHeader, etc.
//-------------------------------------------------------------------------
// - TreeNode()
// - TreeNodeV()
// - TreeNodeEx()
// - TreeNodeExV()
// - TreeNodeBehavior() [Internal]
// - TreePush()
// - TreePop()
// - TreeAdvanceToLabelPos()
// - GetTreeNodeToLabelSpacing()
// - SetNextTreeNodeOpen()
// - CollapsingHeader()
//-------------------------------------------------------------------------

bool ImGui::TreeNode(const char* str_id, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    bool is_open = TreeNodeExV(str_id, 0, fmt, args);
    va_end(args);
    return is_open;
}

bool ImGui::TreeNode(const void* ptr_id, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    bool is_open = TreeNodeExV(ptr_id, 0, fmt, args);
    va_end(args);
    return is_open;
}

bool ImGui::TreeNode(const char* label)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;
    return TreeNodeBehavior(window->GetID(label), 0, label, NULL);
}

bool ImGui::TreeNodeV(const char* str_id, const char* fmt, va_list args)
{
    return TreeNodeExV(str_id, 0, fmt, args);
}

bool ImGui::TreeNodeV(const void* ptr_id, const char* fmt, va_list args)
{
    return TreeNodeExV(ptr_id, 0, fmt, args);
}

bool ImGui::TreeNodeEx(const char* label, ImGuiTreeNodeFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    return TreeNodeBehavior(window->GetID(label), flags, label, NULL);
}

bool ImGui::TreeNodeEx(const char* str_id, ImGuiTreeNodeFlags flags, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    bool is_open = TreeNodeExV(str_id, flags, fmt, args);
    va_end(args);
    return is_open;
}

bool ImGui::TreeNodeEx(const void* ptr_id, ImGuiTreeNodeFlags flags, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    bool is_open = TreeNodeExV(ptr_id, flags, fmt, args);
    va_end(args);
    return is_open;
}

bool ImGui::TreeNodeExV(const char* str_id, ImGuiTreeNodeFlags flags, const char* fmt, va_list args)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const char* label_end = g.TempBuffer + ImFormatStringV(g.TempBuffer, IM_ARRAYSIZE(g.TempBuffer), fmt, args);
    return TreeNodeBehavior(window->GetID(str_id), flags, g.TempBuffer, label_end);
}

bool ImGui::TreeNodeExV(const void* ptr_id, ImGuiTreeNodeFlags flags, const char* fmt, va_list args)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const char* label_end = g.TempBuffer + ImFormatStringV(g.TempBuffer, IM_ARRAYSIZE(g.TempBuffer), fmt, args);
    return TreeNodeBehavior(window->GetID(ptr_id), flags, g.TempBuffer, label_end);
}

bool ImGui::TreeNodeBehaviorIsOpen(ImGuiID id, ImGuiTreeNodeFlags flags)
{
    if (flags & ImGuiTreeNodeFlags_Leaf)
        return true;

    // We only write to the tree storage if the user clicks (or explicitly use SetNextTreeNode*** functions)
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    ImGuiStorage* storage = window->DC.StateStorage;

    bool is_open;
    if (g.NextTreeNodeOpenCond != 0)
    {
        if (g.NextTreeNodeOpenCond & ImGuiCond_Always)
        {
            is_open = g.NextTreeNodeOpenVal;
            storage->SetInt(id, is_open);
        }
        else
        {
            // We treat ImGuiCond_Once and ImGuiCond_FirstUseEver the same because tree node state are not saved persistently.
            const int stored_value = storage->GetInt(id, -1);
            if (stored_value == -1)
            {
                is_open = g.NextTreeNodeOpenVal;
                storage->SetInt(id, is_open);
            }
            else
            {
                is_open = stored_value != 0;
            }
        }
        g.NextTreeNodeOpenCond = 0;
    }
    else
    {
        is_open = storage->GetInt(id, (flags & ImGuiTreeNodeFlags_DefaultOpen) ? 1 : 0) != 0;
    }

    // When logging is enabled, we automatically expand tree nodes (but *NOT* collapsing headers.. seems like sensible behavior).
    // NB- If we are above max depth we still allow manually opened nodes to be logged.
    if (g.LogEnabled && !(flags & ImGuiTreeNodeFlags_NoAutoOpenOnLog) && window->DC.TreeDepth < g.LogAutoExpandMaxDepth)
        is_open = true;

    return is_open;
}

bool ImGui::TreeNodeBehavior(ImGuiID id, ImGuiTreeNodeFlags flags, const char* label, const char* label_end)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const bool display_frame = (flags & ImGuiTreeNodeFlags_Framed) != 0;
    const ImVec2 padding = (display_frame || (flags & ImGuiTreeNodeFlags_FramePadding)) ? style.FramePadding : ImVec2(style.FramePadding.x, 0.0f);

    if (!label_end)
        label_end = FindRenderedTextEnd(label);
    const ImVec2 label_size = CalcTextSize(label, label_end, false);

    // We vertically grow up to current line height up the typical widget height.
    const float text_base_offset_y = ImMax(padding.y, window->DC.CurrentLineTextBaseOffset); // Latch before ItemSize changes it
    const float frame_height = ImMax(ImMin(window->DC.CurrentLineSize.y, g.FontSize + style.FramePadding.y*2), label_size.y + padding.y*2);
    ImRect frame_bb = ImRect(window->DC.CursorPos, ImVec2(window->Pos.x + GetContentRegionMax().x, window->DC.CursorPos.y + frame_height));
    if (display_frame)
    {
        // Framed header expand a little outside the default padding
        frame_bb.Min.x -= (float)(int)(window->WindowPadding.x*0.5f) - 1;
        frame_bb.Max.x += (float)(int)(window->WindowPadding.x*0.5f) - 1;
    }

    const float text_offset_x = (g.FontSize + (display_frame ? padding.x*3 : padding.x*2));   // Collapser arrow width + Spacing
    const float text_width = g.FontSize + (label_size.x > 0.0f ? label_size.x + padding.x*2 : 0.0f);   // Include collapser
    ItemSize(ImVec2(text_width, frame_height), text_base_offset_y);

    // For regular tree nodes, we arbitrary allow to click past 2 worth of ItemSpacing
    // (Ideally we'd want to add a flag for the user to specify if we want the hit test to be done up to the right side of the content or not)
    const ImRect interact_bb = display_frame ? frame_bb : ImRect(frame_bb.Min.x, frame_bb.Min.y, frame_bb.Min.x + text_width + style.ItemSpacing.x*2, frame_bb.Max.y);
    bool is_open = TreeNodeBehaviorIsOpen(id, flags);
    bool is_leaf = (flags & ImGuiTreeNodeFlags_Leaf) != 0;

    // Store a flag for the current depth to tell if we will allow closing this node when navigating one of its child.
    // For this purpose we essentially compare if g.NavIdIsAlive went from 0 to 1 between TreeNode() and TreePop().
    // This is currently only support 32 level deep and we are fine with (1 << Depth) overflowing into a zero.
    if (is_open && !g.NavIdIsAlive && (flags & ImGuiTreeNodeFlags_NavLeftJumpsBackHere) && !(flags & ImGuiTreeNodeFlags_NoTreePushOnOpen))
        window->DC.TreeDepthMayJumpToParentOnPop |= (1 << window->DC.TreeDepth);

    bool item_add = ItemAdd(interact_bb, id);
    window->DC.LastItemStatusFlags |= ImGuiItemStatusFlags_HasDisplayRect;
    window->DC.LastItemDisplayRect = frame_bb;

    if (!item_add)
    {
        if (is_open && !(flags & ImGuiTreeNodeFlags_NoTreePushOnOpen))
            TreePushRawID(id);
        IMGUI_TEST_ENGINE_ITEM_INFO(window->DC.LastItemId, label, window->DC.ItemFlags | (is_leaf ? 0 : ImGuiItemStatusFlags_Openable) | (is_open ? ImGuiItemStatusFlags_Opened : 0));
        return is_open;
    }

    // Flags that affects opening behavior:
    // - 0 (default) .................... single-click anywhere to open
    // - OpenOnDoubleClick .............. double-click anywhere to open
    // - OpenOnArrow .................... single-click on arrow to open
    // - OpenOnDoubleClick|OpenOnArrow .. single-click on arrow or double-click anywhere to open
    ImGuiButtonFlags button_flags = ImGuiButtonFlags_NoKeyModifiers;
    if (flags & ImGuiTreeNodeFlags_AllowItemOverlap)
        button_flags |= ImGuiButtonFlags_AllowItemOverlap;
    if (flags & ImGuiTreeNodeFlags_OpenOnDoubleClick)
        button_flags |= ImGuiButtonFlags_PressedOnDoubleClick | ((flags & ImGuiTreeNodeFlags_OpenOnArrow) ? ImGuiButtonFlags_PressedOnClickRelease : 0);
    if (!is_leaf)
        button_flags |= ImGuiButtonFlags_PressedOnDragDropHold;

    bool selected = (flags & ImGuiTreeNodeFlags_Selected) != 0;
    bool hovered, held;
    bool pressed = ButtonBehavior(interact_bb, id, &hovered, &held, button_flags);
    bool toggled = false;
    if (!is_leaf)
    {
        if (pressed)
        {
            toggled = !(flags & (ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_OpenOnDoubleClick)) || (g.NavActivateId == id);
            if (flags & ImGuiTreeNodeFlags_OpenOnArrow)
                toggled |= IsMouseHoveringRect(interact_bb.Min, ImVec2(interact_bb.Min.x + text_offset_x, interact_bb.Max.y)) && (!g.NavDisableMouseHover);
            if (flags & ImGuiTreeNodeFlags_OpenOnDoubleClick)
                toggled |= g.IO.MouseDoubleClicked[0];
            if (g.DragDropActive && is_open) // When using Drag and Drop "hold to open" we keep the node highlighted after opening, but never close it again.
                toggled = false;
        }

        if (g.NavId == id && g.NavMoveRequest && g.NavMoveDir == ImGuiDir_Left && is_open)
        {
            toggled = true;
            NavMoveRequestCancel();
        }
        if (g.NavId == id && g.NavMoveRequest && g.NavMoveDir == ImGuiDir_Right && !is_open) // If there's something upcoming on the line we may want to give it the priority?
        {
            toggled = true;
            NavMoveRequestCancel();
        }

        if (toggled)
        {
            is_open = !is_open;
            window->DC.StateStorage->SetInt(id, is_open);
        }
    }
    if (flags & ImGuiTreeNodeFlags_AllowItemOverlap)
        SetItemAllowOverlap();

    // Render
    const ImU32 col = GetColorU32((held && hovered) ? ImGuiCol_HeaderActive : hovered ? ImGuiCol_HeaderHovered : ImGuiCol_Header);
    const ImVec2 text_pos = frame_bb.Min + ImVec2(text_offset_x, text_base_offset_y);
    ImGuiNavHighlightFlags nav_highlight_flags = ImGuiNavHighlightFlags_TypeThin;
    if (display_frame)
    {
        // Framed type
        RenderFrame(frame_bb.Min, frame_bb.Max, col, true, style.FrameRounding);
        RenderNavHighlight(frame_bb, id, nav_highlight_flags);
        RenderArrow(frame_bb.Min + ImVec2(padding.x, text_base_offset_y), is_open ? ImGuiDir_Down : ImGuiDir_Right, 1.0f);
        if (g.LogEnabled)
        {
            // NB: '##' is normally used to hide text (as a library-wide feature), so we need to specify the text range to make sure the ## aren't stripped out here.
            const char log_prefix[] = "\n##";
            const char log_suffix[] = "##";
            LogRenderedText(&text_pos, log_prefix, log_prefix+3);
            RenderTextClipped(text_pos, frame_bb.Max, label, label_end, &label_size);
            LogRenderedText(&text_pos, log_suffix+1, log_suffix+3);
        }
        else
        {
            RenderTextClipped(text_pos, frame_bb.Max, label, label_end, &label_size);
        }
    }
    else
    {
        // Unframed typed for tree nodes
        if (hovered || selected)
        {
            RenderFrame(frame_bb.Min, frame_bb.Max, col, false);
            RenderNavHighlight(frame_bb, id, nav_highlight_flags);
        }

        if (flags & ImGuiTreeNodeFlags_Bullet)
            RenderBullet(frame_bb.Min + ImVec2(text_offset_x * 0.5f, g.FontSize*0.50f + text_base_offset_y));
        else if (!is_leaf)
            RenderArrow(frame_bb.Min + ImVec2(padding.x, g.FontSize*0.15f + text_base_offset_y), is_open ? ImGuiDir_Down : ImGuiDir_Right, 0.70f);
        if (g.LogEnabled)
            LogRenderedText(&text_pos, ">");
        RenderText(text_pos, label, label_end, false);
    }

    if (is_open && !(flags & ImGuiTreeNodeFlags_NoTreePushOnOpen))
        TreePushRawID(id);
    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, window->DC.ItemFlags | (is_leaf ? 0 : ImGuiItemStatusFlags_Openable) | (is_open ? ImGuiItemStatusFlags_Opened : 0));
    return is_open;
}

void ImGui::TreePush(const char* str_id)
{
    ImGuiWindow* window = GetCurrentWindow();
    Indent();
    window->DC.TreeDepth++;
    PushID(str_id ? str_id : "#TreePush");
}

void ImGui::TreePush(const void* ptr_id)
{
    ImGuiWindow* window = GetCurrentWindow();
    Indent();
    window->DC.TreeDepth++;
    PushID(ptr_id ? ptr_id : (const void*)"#TreePush");
}

void ImGui::TreePushRawID(ImGuiID id)
{
    ImGuiWindow* window = GetCurrentWindow();
    Indent();
    window->DC.TreeDepth++;
    window->IDStack.push_back(id);
}

void ImGui::TreePop()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    Unindent();

    window->DC.TreeDepth--;
    if (g.NavMoveDir == ImGuiDir_Left && g.NavWindow == window && NavMoveRequestButNoResultYet())
        if (g.NavIdIsAlive && (window->DC.TreeDepthMayJumpToParentOnPop & (1 << window->DC.TreeDepth)))
        {
            SetNavID(window->IDStack.back(), g.NavLayer);
            NavMoveRequestCancel();
        }
    window->DC.TreeDepthMayJumpToParentOnPop &= (1 << window->DC.TreeDepth) - 1;

    IM_ASSERT(window->IDStack.Size > 1); // There should always be 1 element in the IDStack (pushed during window creation). If this triggers you called TreePop/PopID too much.
    PopID();
}

void ImGui::TreeAdvanceToLabelPos()
{
    ImGuiContext& g = *GImGui;
    g.CurrentWindow->DC.CursorPos.x += GetTreeNodeToLabelSpacing();
}

// Horizontal distance preceding label when using TreeNode() or Bullet()
float ImGui::GetTreeNodeToLabelSpacing()
{
    ImGuiContext& g = *GImGui;
    return g.FontSize + (g.Style.FramePadding.x * 2.0f);
}

void ImGui::SetNextTreeNodeOpen(bool is_open, ImGuiCond cond)
{
    ImGuiContext& g = *GImGui;
    if (g.CurrentWindow->SkipItems)
        return;
    g.NextTreeNodeOpenVal = is_open;
    g.NextTreeNodeOpenCond = cond ? cond : ImGuiCond_Always;
}

// CollapsingHeader returns true when opened but do not indent nor push into the ID stack (because of the ImGuiTreeNodeFlags_NoTreePushOnOpen flag).
// This is basically the same as calling TreeNodeEx(label, ImGuiTreeNodeFlags_CollapsingHeader). You can remove the _NoTreePushOnOpen flag if you want behavior closer to normal TreeNode().
bool ImGui::CollapsingHeader(const char* label, ImGuiTreeNodeFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    return TreeNodeBehavior(window->GetID(label), flags | ImGuiTreeNodeFlags_CollapsingHeader, label);
}

bool ImGui::CollapsingHeader(const char* label, bool* p_open, ImGuiTreeNodeFlags flags)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    if (p_open && !*p_open)
        return false;

    ImGuiID id = window->GetID(label);
    bool is_open = TreeNodeBehavior(id, flags | ImGuiTreeNodeFlags_CollapsingHeader | (p_open ? ImGuiTreeNodeFlags_AllowItemOverlap : 0), label);
    if (p_open)
    {
        // Create a small overlapping close button // FIXME: We can evolve this into user accessible helpers to add extra buttons on title bars, headers, etc.
        ImGuiContext& g = *GImGui;
        ImGuiItemHoveredDataBackup last_item_backup;
        float button_radius = g.FontSize * 0.5f;
        ImVec2 button_center = ImVec2(ImMin(window->DC.LastItemRect.Max.x, window->ClipRect.Max.x) - g.Style.FramePadding.x - button_radius, window->DC.LastItemRect.GetCenter().y);
        if (CloseButton(window->GetID((void*)((intptr_t)id+1)), button_center, button_radius))
            *p_open = false;
        last_item_backup.Restore();
    }

    return is_open;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: Selectable
//-------------------------------------------------------------------------
// - Selectable()
//-------------------------------------------------------------------------

// Tip: pass a non-visible label (e.g. "##dummy") then you can use the space to draw other text or image.
// But you need to make sure the ID is unique, e.g. enclose calls in PushID/PopID or use ##unique_id.
bool ImGui::Selectable(const char* label, bool selected, ImGuiSelectableFlags flags, const ImVec2& size_arg)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    if ((flags & ImGuiSelectableFlags_SpanAllColumns) && window->DC.ColumnsSet) // FIXME-OPT: Avoid if vertically clipped.
        PopClipRect();

    ImGuiID id = window->GetID(label);
    ImVec2 label_size = CalcTextSize(label, NULL, true);
    ImVec2 size(size_arg.x != 0.0f ? size_arg.x : label_size.x, size_arg.y != 0.0f ? size_arg.y : label_size.y);
    ImVec2 pos = window->DC.CursorPos;
    pos.y += window->DC.CurrentLineTextBaseOffset;
    ImRect bb_inner(pos, pos + size);
    ItemSize(bb_inner);

    // Fill horizontal space.
    ImVec2 window_padding = window->WindowPadding;
    float max_x = (flags & ImGuiSelectableFlags_SpanAllColumns) ? GetWindowContentRegionMax().x : GetContentRegionMax().x;
    float w_draw = ImMax(label_size.x, window->Pos.x + max_x - window_padding.x - pos.x);
    ImVec2 size_draw((size_arg.x != 0 && !(flags & ImGuiSelectableFlags_DrawFillAvailWidth)) ? size_arg.x : w_draw, size_arg.y != 0.0f ? size_arg.y : size.y);
    ImRect bb(pos, pos + size_draw);
    if (size_arg.x == 0.0f || (flags & ImGuiSelectableFlags_DrawFillAvailWidth))
        bb.Max.x += window_padding.x;

    // Selectables are tightly packed together, we extend the box to cover spacing between selectable.
    float spacing_L = (float)(int)(style.ItemSpacing.x * 0.5f);
    float spacing_U = (float)(int)(style.ItemSpacing.y * 0.5f);
    float spacing_R = style.ItemSpacing.x - spacing_L;
    float spacing_D = style.ItemSpacing.y - spacing_U;
    bb.Min.x -= spacing_L;
    bb.Min.y -= spacing_U;
    bb.Max.x += spacing_R;
    bb.Max.y += spacing_D;
    if (!ItemAdd(bb, id))
    {
        if ((flags & ImGuiSelectableFlags_SpanAllColumns) && window->DC.ColumnsSet)
            PushColumnClipRect();
        return false;
    }

    // We use NoHoldingActiveID on menus so user can click and _hold_ on a menu then drag to browse child entries
    ImGuiButtonFlags button_flags = 0;
    if (flags & ImGuiSelectableFlags_NoHoldingActiveID) button_flags |= ImGuiButtonFlags_NoHoldingActiveID;
    if (flags & ImGuiSelectableFlags_PressedOnClick) button_flags |= ImGuiButtonFlags_PressedOnClick;
    if (flags & ImGuiSelectableFlags_PressedOnRelease) button_flags |= ImGuiButtonFlags_PressedOnRelease;
    if (flags & ImGuiSelectableFlags_Disabled) button_flags |= ImGuiButtonFlags_Disabled;
    if (flags & ImGuiSelectableFlags_AllowDoubleClick) button_flags |= ImGuiButtonFlags_PressedOnClickRelease | ImGuiButtonFlags_PressedOnDoubleClick;
    if (flags & ImGuiSelectableFlags_Disabled)
        selected = false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held, button_flags);
    // Hovering selectable with mouse updates NavId accordingly so navigation can be resumed with gamepad/keyboard (this doesn't happen on most widgets)
    if (pressed || hovered)
        if (!g.NavDisableMouseHover && g.NavWindow == window && g.NavLayer == window->DC.NavLayerCurrent)
        {
            g.NavDisableHighlight = true;
            SetNavID(id, window->DC.NavLayerCurrent);
        }
    if (pressed)
        MarkItemEdited(id);

    // Render
    if (hovered || selected)
    {
        const ImU32 col = GetColorU32((held && hovered) ? ImGuiCol_HeaderActive : hovered ? ImGuiCol_HeaderHovered : ImGuiCol_Header);
        RenderFrame(bb.Min, bb.Max, col, false, 0.0f);
        RenderNavHighlight(bb, id, ImGuiNavHighlightFlags_TypeThin | ImGuiNavHighlightFlags_NoRounding);
    }

    if ((flags & ImGuiSelectableFlags_SpanAllColumns) && window->DC.ColumnsSet)
    {
        PushColumnClipRect();
        bb.Max.x -= (GetContentRegionMax().x - max_x);
    }

    if (flags & ImGuiSelectableFlags_Disabled) PushStyleColor(ImGuiCol_Text, g.Style.Colors[ImGuiCol_TextDisabled]);
    RenderTextClipped(bb_inner.Min, bb_inner.Max, label, NULL, &label_size, style.SelectableTextAlign, &bb);
    if (flags & ImGuiSelectableFlags_Disabled) PopStyleColor();

    // Automatically close popups
    if (pressed && (window->Flags & ImGuiWindowFlags_Popup) && !(flags & ImGuiSelectableFlags_DontClosePopups) && !(window->DC.ItemFlags & ImGuiItemFlags_SelectableDontClosePopup))
        CloseCurrentPopup();
    return pressed;
}

bool ImGui::Selectable(const char* label, bool* p_selected, ImGuiSelectableFlags flags, const ImVec2& size_arg)
{
    if (Selectable(label, *p_selected, flags, size_arg))
    {
        *p_selected = !*p_selected;
        return true;
    }
    return false;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: ListBox
//-------------------------------------------------------------------------
// - ListBox()
// - ListBoxHeader()
// - ListBoxFooter()
//-------------------------------------------------------------------------

// FIXME: In principle this function should be called BeginListBox(). We should rename it after re-evaluating if we want to keep the same signature.
// Helper to calculate the size of a listbox and display a label on the right.
// Tip: To have a list filling the entire window width, PushItemWidth(-1) and pass an non-visible label e.g. "##empty"
bool ImGui::ListBoxHeader(const char* label, const ImVec2& size_arg)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    const ImGuiStyle& style = GetStyle();
    const ImGuiID id = GetID(label);
    const ImVec2 label_size = CalcTextSize(label, NULL, true);

    // Size default to hold ~7 items. Fractional number of items helps seeing that we can scroll down/up without looking at scrollbar.
    ImVec2 size = CalcItemSize(size_arg, CalcItemWidth(), GetTextLineHeightWithSpacing() * 7.4f + style.ItemSpacing.y);
    ImVec2 frame_size = ImVec2(size.x, ImMax(size.y, label_size.y));
    ImRect frame_bb(window->DC.CursorPos, window->DC.CursorPos + frame_size);
    ImRect bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f, 0.0f));
    window->DC.LastItemRect = bb; // Forward storage for ListBoxFooter.. dodgy.

    if (!IsRectVisible(bb.Min, bb.Max))
    {
        ItemSize(bb.GetSize(), style.FramePadding.y);
        ItemAdd(bb, 0, &frame_bb);
        return false;
    }

    BeginGroup();
    if (label_size.x > 0)
        RenderText(ImVec2(frame_bb.Max.x + style.ItemInnerSpacing.x, frame_bb.Min.y + style.FramePadding.y), label);

    BeginChildFrame(id, frame_bb.GetSize());
    return true;
}

// FIXME: In principle this function should be called EndListBox(). We should rename it after re-evaluating if we want to keep the same signature.
bool ImGui::ListBoxHeader(const char* label, int items_count, int height_in_items)
{
    // Size default to hold ~7.25 items.
    // We add +25% worth of item height to allow the user to see at a glance if there are more items up/down, without looking at the scrollbar.
    // We don't add this extra bit if items_count <= height_in_items. It is slightly dodgy, because it means a dynamic list of items will make the widget resize occasionally when it crosses that size.
    // I am expecting that someone will come and complain about this behavior in a remote future, then we can advise on a better solution.
    if (height_in_items < 0)
        height_in_items = ImMin(items_count, 7);
    const ImGuiStyle& style = GetStyle();
    float height_in_items_f = (height_in_items < items_count) ? (height_in_items + 0.25f) : (height_in_items + 0.00f);

    // We include ItemSpacing.y so that a list sized for the exact number of items doesn't make a scrollbar appears. We could also enforce that by passing a flag to BeginChild().
    ImVec2 size;
    size.x = 0.0f;
    size.y = GetTextLineHeightWithSpacing() * height_in_items_f + style.FramePadding.y * 2.0f;
    return ListBoxHeader(label, size);
}

// FIXME: In principle this function should be called EndListBox(). We should rename it after re-evaluating if we want to keep the same signature.
void ImGui::ListBoxFooter()
{
    ImGuiWindow* parent_window = GetCurrentWindow()->ParentWindow;
    const ImRect bb = parent_window->DC.LastItemRect;
    const ImGuiStyle& style = GetStyle();

    EndChildFrame();

    // Redeclare item size so that it includes the label (we have stored the full size in LastItemRect)
    // We call SameLine() to restore DC.CurrentLine* data
    SameLine();
    parent_window->DC.CursorPos = bb.Min;
    ItemSize(bb, style.FramePadding.y);
    EndGroup();
}

bool ImGui::ListBox(const char* label, int* current_item, const char* const items[], int items_count, int height_items)
{
    const bool value_changed = ListBox(label, current_item, Items_ArrayGetter, (void*)items, items_count, height_items);
    return value_changed;
}

bool ImGui::ListBox(const char* label, int* current_item, bool (*items_getter)(void*, int, const char**), void* data, int items_count, int height_in_items)
{
    if (!ListBoxHeader(label, items_count, height_in_items))
        return false;

    // Assume all items have even height (= 1 line of text). If you need items of different or variable sizes you can create a custom version of ListBox() in your code without using the clipper.
    ImGuiContext& g = *GImGui;
    bool value_changed = false;
    ImGuiListClipper clipper(items_count, GetTextLineHeightWithSpacing()); // We know exactly our line height here so we pass it as a minor optimization, but generally you don't need to.
    while (clipper.Step())
        for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++)
        {
            const bool item_selected = (i == *current_item);
            const char* item_text;
            if (!items_getter(data, i, &item_text))
                item_text = "*Unknown item*";

            PushID(i);
            if (Selectable(item_text, item_selected))
            {
                *current_item = i;
                value_changed = true;
            }
            if (item_selected)
                SetItemDefaultFocus();
            PopID();
        }
    ListBoxFooter();
    if (value_changed)
        MarkItemEdited(g.CurrentWindow->DC.LastItemId);

    return value_changed;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: PlotLines, PlotHistogram
//-------------------------------------------------------------------------
// - PlotEx() [Internal]
// - PlotLines()
// - PlotHistogram()
//-------------------------------------------------------------------------

void ImGui::PlotEx(ImGuiPlotType plot_type, const char* label, float (*values_getter)(void* data, int idx), void* data, int values_count, int values_offset, const char* overlay_text, float scale_min, float scale_max, ImVec2 frame_size)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    const ImVec2 label_size = CalcTextSize(label, NULL, true);
    if (frame_size.x == 0.0f)
        frame_size.x = CalcItemWidth();
    if (frame_size.y == 0.0f)
        frame_size.y = label_size.y + (style.FramePadding.y * 2);

    const ImRect frame_bb(window->DC.CursorPos, window->DC.CursorPos + frame_size);
    const ImRect inner_bb(frame_bb.Min + style.FramePadding, frame_bb.Max - style.FramePadding);
    const ImRect total_bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f, 0));
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, 0, &frame_bb))
        return;
    const bool hovered = ItemHoverable(frame_bb, id);

    // Determine scale from values if not specified
    if (scale_min == FLT_MAX || scale_max == FLT_MAX)
    {
        float v_min = FLT_MAX;
        float v_max = -FLT_MAX;
        for (int i = 0; i < values_count; i++)
        {
            const float v = values_getter(data, i);
            v_min = ImMin(v_min, v);
            v_max = ImMax(v_max, v);
        }
        if (scale_min == FLT_MAX)
            scale_min = v_min;
        if (scale_max == FLT_MAX)
            scale_max = v_max;
    }

    RenderFrame(frame_bb.Min, frame_bb.Max, GetColorU32(ImGuiCol_FrameBg), true, style.FrameRounding);

    if (values_count > 0)
    {
        int res_w = ImMin((int)frame_size.x, values_count) + ((plot_type == ImGuiPlotType_Lines) ? -1 : 0);
        int item_count = values_count + ((plot_type == ImGuiPlotType_Lines) ? -1 : 0);

        // Tooltip on hover
        int v_hovered = -1;
        if (hovered && inner_bb.Contains(g.IO.MousePos))
        {
            const float t = ImClamp((g.IO.MousePos.x - inner_bb.Min.x) / (inner_bb.Max.x - inner_bb.Min.x), 0.0f, 0.9999f);
            const int v_idx = (int)(t * item_count);
            IM_ASSERT(v_idx >= 0 && v_idx < values_count);

            const float v0 = values_getter(data, (v_idx + values_offset) % values_count);
            const float v1 = values_getter(data, (v_idx + 1 + values_offset) % values_count);
            if (plot_type == ImGuiPlotType_Lines)
                SetTooltip("%d: %8.4g\n%d: %8.4g", v_idx, v0, v_idx+1, v1);
            else if (plot_type == ImGuiPlotType_Histogram)
                SetTooltip("%d: %8.4g", v_idx, v0);
            v_hovered = v_idx;
        }

        const float t_step = 1.0f / (float)res_w;
        const float inv_scale = (scale_min == scale_max) ? 0.0f : (1.0f / (scale_max - scale_min));

        float v0 = values_getter(data, (0 + values_offset) % values_count);
        float t0 = 0.0f;
        ImVec2 tp0 = ImVec2( t0, 1.0f - ImSaturate((v0 - scale_min) * inv_scale) );                       // Point in the normalized space of our target rectangle
        float histogram_zero_line_t = (scale_min * scale_max < 0.0f) ? (-scale_min * inv_scale) : (scale_min < 0.0f ? 0.0f : 1.0f);   // Where does the zero line stands

        const ImU32 col_base = GetColorU32((plot_type == ImGuiPlotType_Lines) ? ImGuiCol_PlotLines : ImGuiCol_PlotHistogram);
        const ImU32 col_hovered = GetColorU32((plot_type == ImGuiPlotType_Lines) ? ImGuiCol_PlotLinesHovered : ImGuiCol_PlotHistogramHovered);

        for (int n = 0; n < res_w; n++)
        {
            const float t1 = t0 + t_step;
            const int v1_idx = (int)(t0 * item_count + 0.5f);
            IM_ASSERT(v1_idx >= 0 && v1_idx < values_count);
            const float v1 = values_getter(data, (v1_idx + values_offset + 1) % values_count);
            const ImVec2 tp1 = ImVec2( t1, 1.0f - ImSaturate((v1 - scale_min) * inv_scale) );

            // NB: Draw calls are merged together by the DrawList system. Still, we should render our batch are lower level to save a bit of CPU.
            ImVec2 pos0 = ImLerp(inner_bb.Min, inner_bb.Max, tp0);
            ImVec2 pos1 = ImLerp(inner_bb.Min, inner_bb.Max, (plot_type == ImGuiPlotType_Lines) ? tp1 : ImVec2(tp1.x, histogram_zero_line_t));
            if (plot_type == ImGuiPlotType_Lines)
            {
                window->DrawList->AddLine(pos0, pos1, v_hovered == v1_idx ? col_hovered : col_base);
            }
            else if (plot_type == ImGuiPlotType_Histogram)
            {
                if (pos1.x >= pos0.x + 2.0f)
                    pos1.x -= 1.0f;
                window->DrawList->AddRectFilled(pos0, pos1, v_hovered == v1_idx ? col_hovered : col_base);
            }

            t0 = t1;
            tp0 = tp1;
        }
    }

    // Text overlay
    if (overlay_text)
        RenderTextClipped(ImVec2(frame_bb.Min.x, frame_bb.Min.y + style.FramePadding.y), frame_bb.Max, overlay_text, NULL, NULL, ImVec2(0.5f,0.0f));

    if (label_size.x > 0.0f)
        RenderText(ImVec2(frame_bb.Max.x + style.ItemInnerSpacing.x, inner_bb.Min.y), label);
}

struct ImGuiPlotArrayGetterData
{
    const float* Values;
    int Stride;

    ImGuiPlotArrayGetterData(const float* values, int stride) { Values = values; Stride = stride; }
};

static float Plot_ArrayGetter(void* data, int idx)
{
    ImGuiPlotArrayGetterData* plot_data = (ImGuiPlotArrayGetterData*)data;
    const float v = *(const float*)(const void*)((const unsigned char*)plot_data->Values + (size_t)idx * plot_data->Stride);
    return v;
}

void ImGui::PlotLines(const char* label, const float* values, int values_count, int values_offset, const char* overlay_text, float scale_min, float scale_max, ImVec2 graph_size, int stride)
{
    ImGuiPlotArrayGetterData data(values, stride);
    PlotEx(ImGuiPlotType_Lines, label, &Plot_ArrayGetter, (void*)&data, values_count, values_offset, overlay_text, scale_min, scale_max, graph_size);
}

void ImGui::PlotLines(const char* label, float (*values_getter)(void* data, int idx), void* data, int values_count, int values_offset, const char* overlay_text, float scale_min, float scale_max, ImVec2 graph_size)
{
    PlotEx(ImGuiPlotType_Lines, label, values_getter, data, values_count, values_offset, overlay_text, scale_min, scale_max, graph_size);
}

void ImGui::PlotHistogram(const char* label, const float* values, int values_count, int values_offset, const char* overlay_text, float scale_min, float scale_max, ImVec2 graph_size, int stride)
{
    ImGuiPlotArrayGetterData data(values, stride);
    PlotEx(ImGuiPlotType_Histogram, label, &Plot_ArrayGetter, (void*)&data, values_count, values_offset, overlay_text, scale_min, scale_max, graph_size);
}

void ImGui::PlotHistogram(const char* label, float (*values_getter)(void* data, int idx), void* data, int values_count, int values_offset, const char* overlay_text, float scale_min, float scale_max, ImVec2 graph_size)
{
    PlotEx(ImGuiPlotType_Histogram, label, values_getter, data, values_count, values_offset, overlay_text, scale_min, scale_max, graph_size);
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: Value helpers
// Those is not very useful, legacy API.
//-------------------------------------------------------------------------
// - Value()
//-------------------------------------------------------------------------

void ImGui::Value(const char* prefix, bool b)
{
    Text("%s: %s", prefix, (b ? "true" : "false"));
}

void ImGui::Value(const char* prefix, int v)
{
    Text("%s: %d", prefix, v);
}

void ImGui::Value(const char* prefix, unsigned int v)
{
    Text("%s: %d", prefix, v);
}

void ImGui::Value(const char* prefix, float v, const char* float_format)
{
    if (float_format)
    {
        char fmt[64];
        ImFormatString(fmt, IM_ARRAYSIZE(fmt), "%%s: %s", float_format);
        Text(fmt, prefix, v);
    }
    else
    {
        Text("%s: %.3f", prefix, v);
    }
}

//-------------------------------------------------------------------------
// [SECTION] MenuItem, BeginMenu, EndMenu, etc.
//-------------------------------------------------------------------------
// - ImGuiMenuColumns [Internal]
// - BeginMainMenuBar()
// - EndMainMenuBar()
// - BeginMenuBar()
// - EndMenuBar()
// - BeginMenu()
// - EndMenu()
// - MenuItem()
//-------------------------------------------------------------------------

// Helpers for internal use
ImGuiMenuColumns::ImGuiMenuColumns()
{
    Count = 0;
    Spacing = Width = NextWidth = 0.0f;
    memset(Pos, 0, sizeof(Pos));
    memset(NextWidths, 0, sizeof(NextWidths));
}

void ImGuiMenuColumns::Update(int count, float spacing, bool clear)
{
    IM_ASSERT(Count <= IM_ARRAYSIZE(Pos));
    Count = count;
    Width = NextWidth = 0.0f;
    Spacing = spacing;
    if (clear) memset(NextWidths, 0, sizeof(NextWidths));
    for (int i = 0; i < Count; i++)
    {
        if (i > 0 && NextWidths[i] > 0.0f)
            Width += Spacing;
        Pos[i] = (float)(int)Width;
        Width += NextWidths[i];
        NextWidths[i] = 0.0f;
    }
}

float ImGuiMenuColumns::DeclColumns(float w0, float w1, float w2) // not using va_arg because they promote float to double
{
    NextWidth = 0.0f;
    NextWidths[0] = ImMax(NextWidths[0], w0);
    NextWidths[1] = ImMax(NextWidths[1], w1);
    NextWidths[2] = ImMax(NextWidths[2], w2);
    for (int i = 0; i < 3; i++)
        NextWidth += NextWidths[i] + ((i > 0 && NextWidths[i] > 0.0f) ? Spacing : 0.0f);
    return ImMax(Width, NextWidth);
}

float ImGuiMenuColumns::CalcExtraSpace(float avail_w)
{
    return ImMax(0.0f, avail_w - Width);
}

// For the main menu bar, which cannot be moved, we honor g.Style.DisplaySafeAreaPadding to ensure text can be visible on a TV set.
bool ImGui::BeginMainMenuBar()
{
    ImGuiContext& g = *GImGui;
    g.NextWindowData.MenuBarOffsetMinVal = ImVec2(g.Style.DisplaySafeAreaPadding.x, ImMax(g.Style.DisplaySafeAreaPadding.y - g.Style.FramePadding.y, 0.0f));
    SetNextWindowPos(ImVec2(0.0f, 0.0f));
    SetNextWindowSize(ImVec2(g.IO.DisplaySize.x, g.NextWindowData.MenuBarOffsetMinVal.y + g.FontBaseSize + g.Style.FramePadding.y));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
    PushStyleVar(ImGuiStyleVar_WindowMinSize, ImVec2(0,0));
    ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_MenuBar;
    bool is_open = Begin("##MainMenuBar", NULL, window_flags) && BeginMenuBar();
    PopStyleVar(2);
    g.NextWindowData.MenuBarOffsetMinVal = ImVec2(0.0f, 0.0f);
    if (!is_open)
    {
        End();
        return false;
    }
    return true; //-V1020
}

void ImGui::EndMainMenuBar()
{
    EndMenuBar();

    // When the user has left the menu layer (typically: closed menus through activation of an item), we restore focus to the previous window
    ImGuiContext& g = *GImGui;
    if (g.CurrentWindow == g.NavWindow && g.NavLayer == 0)
        FocusPreviousWindowIgnoringOne(g.NavWindow);

    End();
}

bool ImGui::BeginMenuBar()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;
    if (!(window->Flags & ImGuiWindowFlags_MenuBar))
        return false;

    IM_ASSERT(!window->DC.MenuBarAppending);
    BeginGroup(); // Backup position on layer 0
    PushID("##menubar");

    // We don't clip with current window clipping rectangle as it is already set to the area below. However we clip with window full rect.
    // We remove 1 worth of rounding to Max.x to that text in long menus and small windows don't tend to display over the lower-right rounded area, which looks particularly glitchy.
    ImRect bar_rect = window->MenuBarRect();
    ImRect clip_rect(ImFloor(bar_rect.Min.x + 0.5f), ImFloor(bar_rect.Min.y + window->WindowBorderSize + 0.5f), ImFloor(ImMax(bar_rect.Min.x, bar_rect.Max.x - window->WindowRounding) + 0.5f), ImFloor(bar_rect.Max.y + 0.5f));
    clip_rect.ClipWith(window->OuterRectClipped);
    PushClipRect(clip_rect.Min, clip_rect.Max, false);

    window->DC.CursorPos = ImVec2(bar_rect.Min.x + window->DC.MenuBarOffset.x, bar_rect.Min.y + window->DC.MenuBarOffset.y);
    window->DC.LayoutType = ImGuiLayoutType_Horizontal;
    window->DC.NavLayerCurrent = ImGuiNavLayer_Menu;
    window->DC.NavLayerCurrentMask = (1 << ImGuiNavLayer_Menu);
    window->DC.MenuBarAppending = true;
    AlignTextToFramePadding();
    return true;
}

void ImGui::EndMenuBar()
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return;
    ImGuiContext& g = *GImGui;

    // Nav: When a move request within one of our child menu failed, capture the request to navigate among our siblings.
    if (NavMoveRequestButNoResultYet() && (g.NavMoveDir == ImGuiDir_Left || g.NavMoveDir == ImGuiDir_Right) && (g.NavWindow->Flags & ImGuiWindowFlags_ChildMenu))
    {
        ImGuiWindow* nav_earliest_child = g.NavWindow;
        while (nav_earliest_child->ParentWindow && (nav_earliest_child->ParentWindow->Flags & ImGuiWindowFlags_ChildMenu))
            nav_earliest_child = nav_earliest_child->ParentWindow;
        if (nav_earliest_child->ParentWindow == window && nav_earliest_child->DC.ParentLayoutType == ImGuiLayoutType_Horizontal && g.NavMoveRequestForward == ImGuiNavForward_None)
        {
            // To do so we claim focus back, restore NavId and then process the movement request for yet another frame.
            // This involve a one-frame delay which isn't very problematic in this situation. We could remove it by scoring in advance for multiple window (probably not worth the hassle/cost)
            IM_ASSERT(window->DC.NavLayerActiveMaskNext & 0x02); // Sanity check
            FocusWindow(window);
            SetNavIDWithRectRel(window->NavLastIds[1], 1, window->NavRectRel[1]);
            g.NavLayer = ImGuiNavLayer_Menu;
            g.NavDisableHighlight = true; // Hide highlight for the current frame so we don't see the intermediary selection.
            g.NavMoveRequestForward = ImGuiNavForward_ForwardQueued;
            NavMoveRequestCancel();
        }
    }

    IM_ASSERT(window->Flags & ImGuiWindowFlags_MenuBar);
    IM_ASSERT(window->DC.MenuBarAppending);
    PopClipRect();
    PopID();
    window->DC.MenuBarOffset.x = window->DC.CursorPos.x - window->MenuBarRect().Min.x; // Save horizontal position so next append can reuse it. This is kinda equivalent to a per-layer CursorPos.
    window->DC.GroupStack.back().AdvanceCursor = false;
    EndGroup(); // Restore position on layer 0
    window->DC.LayoutType = ImGuiLayoutType_Vertical;
    window->DC.NavLayerCurrent = ImGuiNavLayer_Main;
    window->DC.NavLayerCurrentMask = (1 << ImGuiNavLayer_Main);
    window->DC.MenuBarAppending = false;
}

bool ImGui::BeginMenu(const char* label, bool enabled)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    ImVec2 label_size = CalcTextSize(label, NULL, true);

    bool pressed;
    bool menu_is_open = IsPopupOpen(id);
    bool menuset_is_open = !(window->Flags & ImGuiWindowFlags_Popup) && (g.OpenPopupStack.Size > g.BeginPopupStack.Size && g.OpenPopupStack[g.BeginPopupStack.Size].OpenParentId == window->IDStack.back());
    ImGuiWindow* backed_nav_window = g.NavWindow;
    if (menuset_is_open)
        g.NavWindow = window;  // Odd hack to allow hovering across menus of a same menu-set (otherwise we wouldn't be able to hover parent)

    // The reference position stored in popup_pos will be used by Begin() to find a suitable position for the child menu,
    // However the final position is going to be different! It is choosen by FindBestWindowPosForPopup().
    // e.g. Menus tend to overlap each other horizontally to amplify relative Z-ordering.
    ImVec2 popup_pos, pos = window->DC.CursorPos;
    if (window->DC.LayoutType == ImGuiLayoutType_Horizontal)
    {
        // Menu inside an horizontal menu bar
        // Selectable extend their highlight by half ItemSpacing in each direction.
        // For ChildMenu, the popup position will be overwritten by the call to FindBestWindowPosForPopup() in Begin()
        popup_pos = ImVec2(pos.x - 1.0f - (float)(int)(style.ItemSpacing.x * 0.5f), pos.y - style.FramePadding.y + window->MenuBarHeight());
        window->DC.CursorPos.x += (float)(int)(style.ItemSpacing.x * 0.5f);
        PushStyleVar(ImGuiStyleVar_ItemSpacing, style.ItemSpacing * 2.0f);
        float w = label_size.x;
        pressed = Selectable(label, menu_is_open, ImGuiSelectableFlags_NoHoldingActiveID | ImGuiSelectableFlags_PressedOnClick | ImGuiSelectableFlags_DontClosePopups | (!enabled ? ImGuiSelectableFlags_Disabled : 0), ImVec2(w, 0.0f));
        PopStyleVar();
        window->DC.CursorPos.x += (float)(int)(style.ItemSpacing.x * (-1.0f + 0.5f)); // -1 spacing to compensate the spacing added when Selectable() did a SameLine(). It would also work to call SameLine() ourselves after the PopStyleVar().
    }
    else
    {
        // Menu inside a menu
        popup_pos = ImVec2(pos.x, pos.y - style.WindowPadding.y);
        float w = window->MenuColumns.DeclColumns(label_size.x, 0.0f, (float)(int)(g.FontSize * 1.20f)); // Feedback to next frame
        float extra_w = ImMax(0.0f, GetContentRegionAvail().x - w);
        pressed = Selectable(label, menu_is_open, ImGuiSelectableFlags_NoHoldingActiveID | ImGuiSelectableFlags_PressedOnClick | ImGuiSelectableFlags_DontClosePopups | ImGuiSelectableFlags_DrawFillAvailWidth | (!enabled ? ImGuiSelectableFlags_Disabled : 0), ImVec2(w, 0.0f));
        if (!enabled) PushStyleColor(ImGuiCol_Text, g.Style.Colors[ImGuiCol_TextDisabled]);
        RenderArrow(pos + ImVec2(window->MenuColumns.Pos[2] + extra_w + g.FontSize * 0.30f, 0.0f), ImGuiDir_Right);
        if (!enabled) PopStyleColor();
    }

    const bool hovered = enabled && ItemHoverable(window->DC.LastItemRect, id);
    if (menuset_is_open)
        g.NavWindow = backed_nav_window;

    bool want_open = false, want_close = false;
    if (window->DC.LayoutType == ImGuiLayoutType_Vertical) // (window->Flags & (ImGuiWindowFlags_Popup|ImGuiWindowFlags_ChildMenu))
    {
        // Implement http://bjk5.com/post/44698559168/breaking-down-amazons-mega-dropdown to avoid using timers, so menus feels more reactive.
        bool moving_within_opened_triangle = false;
        if (g.HoveredWindow == window && g.OpenPopupStack.Size > g.BeginPopupStack.Size && g.OpenPopupStack[g.BeginPopupStack.Size].ParentWindow == window && !(window->Flags & ImGuiWindowFlags_MenuBar))
        {
            if (ImGuiWindow* next_window = g.OpenPopupStack[g.BeginPopupStack.Size].Window)
            {
                // FIXME-DPI: Values should be derived from a master "scale" factor.
                ImRect next_window_rect = next_window->Rect();
                ImVec2 ta = g.IO.MousePos - g.IO.MouseDelta;
                ImVec2 tb = (window->Pos.x < next_window->Pos.x) ? next_window_rect.GetTL() : next_window_rect.GetTR();
                ImVec2 tc = (window->Pos.x < next_window->Pos.x) ? next_window_rect.GetBL() : next_window_rect.GetBR();
                float extra = ImClamp(ImFabs(ta.x - tb.x) * 0.30f, 5.0f, 30.0f); // add a bit of extra slack.
                ta.x += (window->Pos.x < next_window->Pos.x) ? -0.5f : +0.5f;    // to avoid numerical issues
                tb.y = ta.y + ImMax((tb.y - extra) - ta.y, -100.0f);             // triangle is maximum 200 high to limit the slope and the bias toward large sub-menus // FIXME: Multiply by fb_scale?
                tc.y = ta.y + ImMin((tc.y + extra) - ta.y, +100.0f);
                moving_within_opened_triangle = ImTriangleContainsPoint(ta, tb, tc, g.IO.MousePos);
                //window->DrawList->PushClipRectFullScreen(); window->DrawList->AddTriangleFilled(ta, tb, tc, moving_within_opened_triangle ? IM_COL32(0,128,0,128) : IM_COL32(128,0,0,128)); window->DrawList->PopClipRect(); // Debug
            }
        }

        want_close = (menu_is_open && !hovered && g.HoveredWindow == window && g.HoveredIdPreviousFrame != 0 && g.HoveredIdPreviousFrame != id && !moving_within_opened_triangle);
        want_open = (!menu_is_open && hovered && !moving_within_opened_triangle) || (!menu_is_open && hovered && pressed);

        if (g.NavActivateId == id)
        {
            want_close = menu_is_open;
            want_open = !menu_is_open;
        }
        if (g.NavId == id && g.NavMoveRequest && g.NavMoveDir == ImGuiDir_Right) // Nav-Right to open
        {
            want_open = true;
            NavMoveRequestCancel();
        }
    }
    else
    {
        // Menu bar
        if (menu_is_open && pressed && menuset_is_open) // Click an open menu again to close it
        {
            want_close = true;
            want_open = menu_is_open = false;
        }
        else if (pressed || (hovered && menuset_is_open && !menu_is_open)) // First click to open, then hover to open others
        {
            want_open = true;
        }
        else if (g.NavId == id && g.NavMoveRequest && g.NavMoveDir == ImGuiDir_Down) // Nav-Down to open
        {
            want_open = true;
            NavMoveRequestCancel();
        }
    }

    if (!enabled) // explicitly close if an open menu becomes disabled, facilitate users code a lot in pattern such as 'if (BeginMenu("options", has_object)) { ..use object.. }'
        want_close = true;
    if (want_close && IsPopupOpen(id))
        ClosePopupToLevel(g.BeginPopupStack.Size, true);

    IMGUI_TEST_ENGINE_ITEM_INFO(id, label, window->DC.ItemFlags | ImGuiItemStatusFlags_Openable | (menu_is_open ? ImGuiItemStatusFlags_Opened : 0));

    if (!menu_is_open && want_open && g.OpenPopupStack.Size > g.BeginPopupStack.Size)
    {
        // Don't recycle same menu level in the same frame, first close the other menu and yield for a frame.
        OpenPopup(label);
        return false;
    }

    menu_is_open |= want_open;
    if (want_open)
        OpenPopup(label);

    if (menu_is_open)
    {
        // Sub-menus are ChildWindow so that mouse can be hovering across them (otherwise top-most popup menu would steal focus and not allow hovering on parent menu)
        SetNextWindowPos(popup_pos, ImGuiCond_Always);
        ImGuiWindowFlags flags = ImGuiWindowFlags_ChildMenu | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNavFocus;
        if (window->Flags & (ImGuiWindowFlags_Popup|ImGuiWindowFlags_ChildMenu))
            flags |= ImGuiWindowFlags_ChildWindow;
        menu_is_open = BeginPopupEx(id, flags); // menu_is_open can be 'false' when the popup is completely clipped (e.g. zero size display)
    }

    return menu_is_open;
}

void ImGui::EndMenu()
{
    // Nav: When a left move request _within our child menu_ failed, close ourselves (the _parent_ menu).
    // A menu doesn't close itself because EndMenuBar() wants the catch the last Left<>Right inputs.
    // However, it means that with the current code, a BeginMenu() from outside another menu or a menu-bar won't be closable with the Left direction.
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (g.NavWindow && g.NavWindow->ParentWindow == window && g.NavMoveDir == ImGuiDir_Left && NavMoveRequestButNoResultYet() && window->DC.LayoutType == ImGuiLayoutType_Vertical)
    {
        ClosePopupToLevel(g.BeginPopupStack.Size, true);
        NavMoveRequestCancel();
    }

    EndPopup();
}

bool ImGui::MenuItem(const char* label, const char* shortcut, bool selected, bool enabled)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    ImGuiStyle& style = g.Style;
    ImVec2 pos = window->DC.CursorPos;
    ImVec2 label_size = CalcTextSize(label, NULL, true);

    ImGuiSelectableFlags flags = ImGuiSelectableFlags_PressedOnRelease | (enabled ? 0 : ImGuiSelectableFlags_Disabled);
    bool pressed;
    if (window->DC.LayoutType == ImGuiLayoutType_Horizontal)
    {
        // Mimic the exact layout spacing of BeginMenu() to allow MenuItem() inside a menu bar, which is a little misleading but may be useful
        // Note that in this situation we render neither the shortcut neither the selected tick mark
        float w = label_size.x;
        window->DC.CursorPos.x += (float)(int)(style.ItemSpacing.x * 0.5f);
        PushStyleVar(ImGuiStyleVar_ItemSpacing, style.ItemSpacing * 2.0f);
        pressed = Selectable(label, false, flags, ImVec2(w, 0.0f));
        PopStyleVar();
        window->DC.CursorPos.x += (float)(int)(style.ItemSpacing.x * (-1.0f + 0.5f)); // -1 spacing to compensate the spacing added when Selectable() did a SameLine(). It would also work to call SameLine() ourselves after the PopStyleVar().
    }
    else
    {
        ImVec2 shortcut_size = shortcut ? CalcTextSize(shortcut, NULL) : ImVec2(0.0f, 0.0f);
        float w = window->MenuColumns.DeclColumns(label_size.x, shortcut_size.x, (float)(int)(g.FontSize * 1.20f)); // Feedback for next frame
        float extra_w = ImMax(0.0f, GetContentRegionAvail().x - w);
        pressed = Selectable(label, false, flags | ImGuiSelectableFlags_DrawFillAvailWidth, ImVec2(w, 0.0f));
        if (shortcut_size.x > 0.0f)
        {
            PushStyleColor(ImGuiCol_Text, g.Style.Colors[ImGuiCol_TextDisabled]);
            RenderText(pos + ImVec2(window->MenuColumns.Pos[1] + extra_w, 0.0f), shortcut, NULL, false);
            PopStyleColor();
        }
        if (selected)
            RenderCheckMark(pos + ImVec2(window->MenuColumns.Pos[2] + extra_w + g.FontSize * 0.40f, g.FontSize * 0.134f * 0.5f), GetColorU32(enabled ? ImGuiCol_Text : ImGuiCol_TextDisabled), g.FontSize  * 0.866f);
    }

    IMGUI_TEST_ENGINE_ITEM_INFO(window->DC.LastItemId, label, window->DC.ItemFlags | ImGuiItemStatusFlags_Checkable | (selected ? ImGuiItemStatusFlags_Checked : 0));
    return pressed;
}

bool ImGui::MenuItem(const char* label, const char* shortcut, bool* p_selected, bool enabled)
{
    if (MenuItem(label, shortcut, p_selected ? *p_selected : false, enabled))
    {
        if (p_selected)
            *p_selected = !*p_selected;
        return true;
    }
    return false;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: BeginTabBar, EndTabBar, etc.
//-------------------------------------------------------------------------
// [BETA API] API may evolve! This code has been extracted out of the Docking branch,
// and some of the construct which are not used in Master may be left here to facilitate merging.
//-------------------------------------------------------------------------
// - BeginTabBar()
// - BeginTabBarEx() [Internal]
// - EndTabBar()
// - TabBarLayout() [Internal]
// - TabBarCalcTabID() [Internal]
// - TabBarCalcMaxTabWidth() [Internal]
// - TabBarFindTabById() [Internal]
// - TabBarRemoveTab() [Internal]
// - TabBarCloseTab() [Internal]
// - TabBarScrollClamp()v
// - TabBarScrollToTab() [Internal]
// - TabBarQueueChangeTabOrder() [Internal]
// - TabBarScrollingButtons() [Internal]
// - TabBarTabListPopupButton() [Internal]
//-------------------------------------------------------------------------

namespace ImGui
{
    static void             TabBarLayout(ImGuiTabBar* tab_bar);
    static ImU32            TabBarCalcTabID(ImGuiTabBar* tab_bar, const char* label);
    static float            TabBarCalcMaxTabWidth();
    static float            TabBarScrollClamp(ImGuiTabBar* tab_bar, float scrolling);
    static void             TabBarScrollToTab(ImGuiTabBar* tab_bar, ImGuiTabItem* tab);
    static ImGuiTabItem*    TabBarScrollingButtons(ImGuiTabBar* tab_bar);
    static ImGuiTabItem*    TabBarTabListPopupButton(ImGuiTabBar* tab_bar);
}

ImGuiTabBar::ImGuiTabBar()
{
    ID = 0;
    SelectedTabId = NextSelectedTabId = VisibleTabId = 0;
    CurrFrameVisible = PrevFrameVisible = -1;
    ContentsHeight = 0.0f;
    OffsetMax = OffsetNextTab = 0.0f;
    ScrollingAnim = ScrollingTarget = 0.0f;
    Flags = ImGuiTabBarFlags_None;
    ReorderRequestTabId = 0;
    ReorderRequestDir = 0;
    WantLayout = VisibleTabWasSubmitted = false;
    LastTabItemIdx = -1;
}

static int IMGUI_CDECL TabItemComparerByVisibleOffset(const void* lhs, const void* rhs)
{
    const ImGuiTabItem* a = (const ImGuiTabItem*)lhs;
    const ImGuiTabItem* b = (const ImGuiTabItem*)rhs;
    return (int)(a->Offset - b->Offset);
}

static int IMGUI_CDECL TabBarSortItemComparer(const void* lhs, const void* rhs)
{
    const ImGuiTabBarSortItem* a = (const ImGuiTabBarSortItem*)lhs;
    const ImGuiTabBarSortItem* b = (const ImGuiTabBarSortItem*)rhs;
    if (int d = (int)(b->Width - a->Width))
        return d;
    return (b->Index - a->Index);
}

static ImGuiTabBar* GetTabBarFromTabBarRef(const ImGuiTabBarRef& ref)
{
    ImGuiContext& g = *GImGui;
    return ref.Ptr ? ref.Ptr : g.TabBars.GetByIndex(ref.IndexInMainPool);
}

static ImGuiTabBarRef GetTabBarRefFromTabBar(ImGuiTabBar* tab_bar)
{
    ImGuiContext& g = *GImGui;
    if (g.TabBars.Contains(tab_bar))
        return ImGuiTabBarRef(g.TabBars.GetIndex(tab_bar));
    return ImGuiTabBarRef(tab_bar);
}

bool    ImGui::BeginTabBar(const char* str_id, ImGuiTabBarFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (window->SkipItems)
        return false;

    ImGuiID id = window->GetID(str_id);
    ImGuiTabBar* tab_bar = g.TabBars.GetOrAddByKey(id);
    ImRect tab_bar_bb = ImRect(window->DC.CursorPos.x, window->DC.CursorPos.y, window->InnerClipRect.Max.x, window->DC.CursorPos.y + g.FontSize + g.Style.FramePadding.y * 2);
    tab_bar->ID = id;
    return BeginTabBarEx(tab_bar, tab_bar_bb, flags | ImGuiTabBarFlags_IsFocused);
}

bool    ImGui::BeginTabBarEx(ImGuiTabBar* tab_bar, const ImRect& tab_bar_bb, ImGuiTabBarFlags flags)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (window->SkipItems)
        return false;

    if ((flags & ImGuiTabBarFlags_DockNode) == 0)
        window->IDStack.push_back(tab_bar->ID);

    // Add to stack
    g.CurrentTabBarStack.push_back(GetTabBarRefFromTabBar(tab_bar));
    g.CurrentTabBar = tab_bar;

    if (tab_bar->CurrFrameVisible == g.FrameCount)
    {
        //IMGUI_DEBUG_LOG("BeginTabBarEx already called this frame\n", g.FrameCount);
        IM_ASSERT(0);
        return true;
    }

    // When toggling back from ordered to manually-reorderable, shuffle tabs to enforce the last visible order.
    // Otherwise, the most recently inserted tabs would move at the end of visible list which can be a little too confusing or magic for the user.
    if ((flags & ImGuiTabBarFlags_Reorderable) && !(tab_bar->Flags & ImGuiTabBarFlags_Reorderable) && tab_bar->Tabs.Size > 1 && tab_bar->PrevFrameVisible != -1)
        ImQsort(tab_bar->Tabs.Data, tab_bar->Tabs.Size, sizeof(ImGuiTabItem), TabItemComparerByVisibleOffset);

    // Flags
    if ((flags & ImGuiTabBarFlags_FittingPolicyMask_) == 0)
        flags |= ImGuiTabBarFlags_FittingPolicyDefault_;

    tab_bar->Flags = flags;
    tab_bar->BarRect = tab_bar_bb;
    tab_bar->WantLayout = true; // Layout will be done on the first call to ItemTab()
    tab_bar->PrevFrameVisible = tab_bar->CurrFrameVisible;
    tab_bar->CurrFrameVisible = g.FrameCount;
    tab_bar->FramePadding = g.Style.FramePadding;

    // Layout
    ItemSize(ImVec2(tab_bar->OffsetMax, tab_bar->BarRect.GetHeight()));
    window->DC.CursorPos.x = tab_bar->BarRect.Min.x;

    // Draw separator
    const ImU32 col = GetColorU32((flags & ImGuiTabBarFlags_IsFocused) ? ImGuiCol_TabActive : ImGuiCol_Tab);
    const float y = tab_bar->BarRect.Max.y - 1.0f;
    {
        const float separator_min_x = tab_bar->BarRect.Min.x - window->WindowPadding.x;
        const float separator_max_x = tab_bar->BarRect.Max.x + window->WindowPadding.x;
        window->DrawList->AddLine(ImVec2(separator_min_x, y), ImVec2(separator_max_x, y), col, 1.0f);
    }
    return true;
}

void    ImGui::EndTabBar()
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (window->SkipItems)
        return;

    ImGuiTabBar* tab_bar = g.CurrentTabBar;
    if (tab_bar == NULL)
    {
        IM_ASSERT(tab_bar != NULL && "Mismatched BeginTabBar()/EndTabBar()!");
        return; // FIXME-ERRORHANDLING
    }
    if (tab_bar->WantLayout)
        TabBarLayout(tab_bar);

    // Restore the last visible height if no tab is visible, this reduce vertical flicker/movement when a tabs gets removed without calling SetTabItemClosed().
    const bool tab_bar_appearing = (tab_bar->PrevFrameVisible + 1 < g.FrameCount);
    if (tab_bar->VisibleTabWasSubmitted || tab_bar->VisibleTabId == 0 || tab_bar_appearing)
        tab_bar->ContentsHeight = ImMax(window->DC.CursorPos.y - tab_bar->BarRect.Max.y, 0.0f);
    else
        window->DC.CursorPos.y = tab_bar->BarRect.Max.y + tab_bar->ContentsHeight;

    if ((tab_bar->Flags & ImGuiTabBarFlags_DockNode) == 0)
        PopID();

    g.CurrentTabBarStack.pop_back();
    g.CurrentTabBar = g.CurrentTabBarStack.empty() ? NULL : GetTabBarFromTabBarRef(g.CurrentTabBarStack.back());
}

// This is called only once a frame before by the first call to ItemTab()
// The reason we're not calling it in BeginTabBar() is to leave a chance to the user to call the SetTabItemClosed() functions.
static void ImGui::TabBarLayout(ImGuiTabBar* tab_bar)
{
    ImGuiContext& g = *GImGui;
    tab_bar->WantLayout = false;

    // Garbage collect
    int tab_dst_n = 0;
    for (int tab_src_n = 0; tab_src_n < tab_bar->Tabs.Size; tab_src_n++)
    {
        ImGuiTabItem* tab = &tab_bar->Tabs[tab_src_n];
        if (tab->LastFrameVisible < tab_bar->PrevFrameVisible)
        {
            if (tab->ID == tab_bar->SelectedTabId)
                tab_bar->SelectedTabId = 0;
            continue;
        }
        if (tab_dst_n != tab_src_n)
            tab_bar->Tabs[tab_dst_n] = tab_bar->Tabs[tab_src_n];
        tab_dst_n++;
    }
    if (tab_bar->Tabs.Size != tab_dst_n)
        tab_bar->Tabs.resize(tab_dst_n);

    // Setup next selected tab
    ImGuiID scroll_track_selected_tab_id = 0;
    if (tab_bar->NextSelectedTabId)
    {
        tab_bar->SelectedTabId = tab_bar->NextSelectedTabId;
        tab_bar->NextSelectedTabId = 0;
        scroll_track_selected_tab_id = tab_bar->SelectedTabId;
    }

    // Process order change request (we could probably process it when requested but it's just saner to do it in a single spot).
    if (tab_bar->ReorderRequestTabId != 0)
    {
        if (ImGuiTabItem* tab1 = TabBarFindTabByID(tab_bar, tab_bar->ReorderRequestTabId))
        {
            //IM_ASSERT(tab_bar->Flags & ImGuiTabBarFlags_Reorderable); // <- this may happen when using debug tools
            int tab2_order = tab_bar->GetTabOrder(tab1) + tab_bar->ReorderRequestDir;
            if (tab2_order >= 0 && tab2_order < tab_bar->Tabs.Size)
            {
                ImGuiTabItem* tab2 = &tab_bar->Tabs[tab2_order];
                ImGuiTabItem item_tmp = *tab1;
                *tab1 = *tab2;
                *tab2 = item_tmp;
                if (tab2->ID == tab_bar->SelectedTabId)
                    scroll_track_selected_tab_id = tab2->ID;
                tab1 = tab2 = NULL;
            }
            if (tab_bar->Flags & ImGuiTabBarFlags_SaveSettings)
                MarkIniSettingsDirty();
        }
        tab_bar->ReorderRequestTabId = 0;
    }

    // Tab List Popup (will alter tab_bar->BarRect and therefore the available width!)
    const bool tab_list_popup_button = (tab_bar->Flags & ImGuiTabBarFlags_TabListPopupButton) != 0;
    if (tab_list_popup_button)
        if (ImGuiTabItem* tab_to_select = TabBarTabListPopupButton(tab_bar)) // NB: Will alter BarRect.Max.x!
            scroll_track_selected_tab_id = tab_bar->SelectedTabId = tab_to_select->ID;

    ImVector<ImGuiTabBarSortItem>& width_sort_buffer = g.TabSortByWidthBuffer;
    width_sort_buffer.resize(tab_bar->Tabs.Size);

    // Compute ideal widths
    float width_total_contents = 0.0f;
    ImGuiTabItem* most_recently_selected_tab = NULL;
    bool found_selected_tab_id = false;
    for (int tab_n = 0; tab_n < tab_bar->Tabs.Size; tab_n++)
    {
        ImGuiTabItem* tab = &tab_bar->Tabs[tab_n];
        IM_ASSERT(tab->LastFrameVisible >= tab_bar->PrevFrameVisible);

        if (most_recently_selected_tab == NULL || most_recently_selected_tab->LastFrameSelected < tab->LastFrameSelected)
            most_recently_selected_tab = tab;
        if (tab->ID == tab_bar->SelectedTabId)
            found_selected_tab_id = true;

        // Refresh tab width immediately, otherwise changes of style e.g. style.FramePadding.x would noticeably lag in the tab bar.
        // Additionally, when using TabBarAddTab() to manipulate tab bar order we occasionally insert new tabs that don't have a width yet,
        // and we cannot wait for the next BeginTabItem() call. We cannot compute this width within TabBarAddTab() because font size depends on the active window.
        const char* tab_name = tab_bar->GetTabName(tab);
        tab->WidthContents = TabItemCalcSize(tab_name, (tab->Flags & ImGuiTabItemFlags_NoCloseButton) ? false : true).x;

        width_total_contents += (tab_n > 0 ? g.Style.ItemInnerSpacing.x : 0.0f) + tab->WidthContents;

        // Store data so we can build an array sorted by width if we need to shrink tabs down
        width_sort_buffer[tab_n].Index = tab_n;
        width_sort_buffer[tab_n].Width = tab->WidthContents;
    }

    // Compute width
    const float width_avail = tab_bar->BarRect.GetWidth();
    float width_excess = (width_avail < width_total_contents) ? (width_total_contents - width_avail) : 0.0f;
    if (width_excess > 0.0f && (tab_bar->Flags & ImGuiTabBarFlags_FittingPolicyResizeDown))
    {
        // If we don't have enough room, resize down the largest tabs first
        if (tab_bar->Tabs.Size > 1)
            ImQsort(width_sort_buffer.Data, (size_t)width_sort_buffer.Size, sizeof(ImGuiTabBarSortItem), TabBarSortItemComparer);
        int tab_count_same_width = 1;
        while (width_excess > 0.0f && tab_count_same_width < tab_bar->Tabs.Size)
        {
            while (tab_count_same_width < tab_bar->Tabs.Size && width_sort_buffer[0].Width == width_sort_buffer[tab_count_same_width].Width)
                tab_count_same_width++;
            float width_to_remove_per_tab_max = (tab_count_same_width < tab_bar->Tabs.Size) ? (width_sort_buffer[0].Width - width_sort_buffer[tab_count_same_width].Width) : (width_sort_buffer[0].Width - 1.0f);
            float width_to_remove_per_tab = ImMin(width_excess / tab_count_same_width, width_to_remove_per_tab_max);
            for (int tab_n = 0; tab_n < tab_count_same_width; tab_n++)
                width_sort_buffer[tab_n].Width -= width_to_remove_per_tab;
            width_excess -= width_to_remove_per_tab * tab_count_same_width;
        }
        for (int tab_n = 0; tab_n < tab_bar->Tabs.Size; tab_n++)
            tab_bar->Tabs[width_sort_buffer[tab_n].Index].Width = (float)(int)width_sort_buffer[tab_n].Width;
    }
    else
    {
        const float tab_max_width = TabBarCalcMaxTabWidth();
        for (int tab_n = 0; tab_n < tab_bar->Tabs.Size; tab_n++)
        {
            ImGuiTabItem* tab = &tab_bar->Tabs[tab_n];
            tab->Width = ImMin(tab->WidthContents, tab_max_width);
        }
    }

    // Layout all active tabs
    float offset_x = 0.0f;
    for (int tab_n = 0; tab_n < tab_bar->Tabs.Size; tab_n++)
    {
        ImGuiTabItem* tab = &tab_bar->Tabs[tab_n];
        tab->Offset = offset_x;
        if (scroll_track_selected_tab_id == 0 && g.NavJustMovedToId == tab->ID)
            scroll_track_selected_tab_id = tab->ID;
        offset_x += tab->Width + g.Style.ItemInnerSpacing.x;
    }
    tab_bar->OffsetMax = ImMax(offset_x - g.Style.ItemInnerSpacing.x, 0.0f);
    tab_bar->OffsetNextTab = 0.0f;

    // Horizontal scrolling buttons
    const bool scrolling_buttons = (tab_bar->OffsetMax > tab_bar->BarRect.GetWidth() && tab_bar->Tabs.Size > 1) && !(tab_bar->Flags & ImGuiTabBarFlags_NoTabListScrollingButtons) && (tab_bar->Flags & ImGuiTabBarFlags_FittingPolicyScroll);
    if (scrolling_buttons)
        if (ImGuiTabItem* tab_to_select = TabBarScrollingButtons(tab_bar)) // NB: Will alter BarRect.Max.x!
            scroll_track_selected_tab_id = tab_bar->SelectedTabId = tab_to_select->ID;

    // If we have lost the selected tab, select the next most recently active one
    if (found_selected_tab_id == false)
        tab_bar->SelectedTabId = 0;
    if (tab_bar->SelectedTabId == 0 && tab_bar->NextSelectedTabId == 0 && most_recently_selected_tab != NULL)
        scroll_track_selected_tab_id = tab_bar->SelectedTabId = most_recently_selected_tab->ID;

    // Lock in visible tab
    tab_bar->VisibleTabId = tab_bar->SelectedTabId;
    tab_bar->VisibleTabWasSubmitted = false;

    // Update scrolling
    if (scroll_track_selected_tab_id)
        if (ImGuiTabItem* scroll_track_selected_tab = TabBarFindTabByID(tab_bar, scroll_track_selected_tab_id))
            TabBarScrollToTab(tab_bar, scroll_track_selected_tab);
    tab_bar->ScrollingAnim = TabBarScrollClamp(tab_bar, tab_bar->ScrollingAnim);
    tab_bar->ScrollingTarget = TabBarScrollClamp(tab_bar, tab_bar->ScrollingTarget);
    const float scrolling_speed = (tab_bar->PrevFrameVisible + 1 < g.FrameCount) ? FLT_MAX : (g.IO.DeltaTime * g.FontSize * 70.0f);
    if (tab_bar->ScrollingAnim != tab_bar->ScrollingTarget)
        tab_bar->ScrollingAnim = ImLinearSweep(tab_bar->ScrollingAnim, tab_bar->ScrollingTarget, scrolling_speed);

    // Clear name buffers
    if ((tab_bar->Flags & ImGuiTabBarFlags_DockNode) == 0)
        tab_bar->TabsNames.Buf.resize(0);
}

// Dockables uses Name/ID in the global namespace. Non-dockable items use the ID stack.
static ImU32   ImGui::TabBarCalcTabID(ImGuiTabBar* tab_bar, const char* label)
{
    if (tab_bar->Flags & ImGuiTabBarFlags_DockNode)
    {
        ImGuiID id = ImHashStr(label, 0);
        KeepAliveID(id);
        return id;
    }
    else
    {
        ImGuiWindow* window = GImGui->CurrentWindow;
        return window->GetID(label);
    }
}

static float ImGui::TabBarCalcMaxTabWidth()
{
    ImGuiContext& g = *GImGui;
    return g.FontSize * 20.0f;
}

ImGuiTabItem* ImGui::TabBarFindTabByID(ImGuiTabBar* tab_bar, ImGuiID tab_id)
{
    if (tab_id != 0)
        for (int n = 0; n < tab_bar->Tabs.Size; n++)
            if (tab_bar->Tabs[n].ID == tab_id)
                return &tab_bar->Tabs[n];
    return NULL;
}

// The *TabId fields be already set by the docking system _before_ the actual TabItem was created, so we clear them regardless.
void ImGui::TabBarRemoveTab(ImGuiTabBar* tab_bar, ImGuiID tab_id)
{
    if (ImGuiTabItem* tab = TabBarFindTabByID(tab_bar, tab_id))
        tab_bar->Tabs.erase(tab);
    if (tab_bar->VisibleTabId == tab_id)      { tab_bar->VisibleTabId = 0; }
    if (tab_bar->SelectedTabId == tab_id)     { tab_bar->SelectedTabId = 0; }
    if (tab_bar->NextSelectedTabId == tab_id) { tab_bar->NextSelectedTabId = 0; }
}

// Called on manual closure attempt
void ImGui::TabBarCloseTab(ImGuiTabBar* tab_bar, ImGuiTabItem* tab)
{
    if ((tab_bar->VisibleTabId == tab->ID) && !(tab->Flags & ImGuiTabItemFlags_UnsavedDocument))
    {
        // This will remove a frame of lag for selecting another tab on closure.
        // However we don't run it in the case where the 'Unsaved' flag is set, so user gets a chance to fully undo the closure
        tab->LastFrameVisible = -1;
        tab_bar->SelectedTabId = tab_bar->NextSelectedTabId = 0;
    }
    else if ((tab_bar->VisibleTabId != tab->ID) && (tab->Flags & ImGuiTabItemFlags_UnsavedDocument))
    {
        // Actually select before expecting closure
        tab_bar->NextSelectedTabId = tab->ID;
    }
}

static float ImGui::TabBarScrollClamp(ImGuiTabBar* tab_bar, float scrolling)
{
    scrolling = ImMin(scrolling, tab_bar->OffsetMax - tab_bar->BarRect.GetWidth());
    return ImMax(scrolling, 0.0f);
}

static void ImGui::TabBarScrollToTab(ImGuiTabBar* tab_bar, ImGuiTabItem* tab)
{
    ImGuiContext& g = *GImGui;
    float margin = g.FontSize * 1.0f; // When to scroll to make Tab N+1 visible always make a bit of N visible to suggest more scrolling area (since we don't have a scrollbar)
    int order = tab_bar->GetTabOrder(tab);
    float tab_x1 = tab->Offset + (order > 0 ? -margin : 0.0f);
    float tab_x2 = tab->Offset + tab->Width + (order + 1 < tab_bar->Tabs.Size ? margin : 1.0f);
    if (tab_bar->ScrollingTarget > tab_x1)
        tab_bar->ScrollingTarget = tab_x1;
    if (tab_bar->ScrollingTarget + tab_bar->BarRect.GetWidth() < tab_x2)
        tab_bar->ScrollingTarget = tab_x2 - tab_bar->BarRect.GetWidth();
}

void ImGui::TabBarQueueChangeTabOrder(ImGuiTabBar* tab_bar, const ImGuiTabItem* tab, int dir)
{
    IM_ASSERT(dir == -1 || dir == +1);
    IM_ASSERT(tab_bar->ReorderRequestTabId == 0);
    tab_bar->ReorderRequestTabId = tab->ID;
    tab_bar->ReorderRequestDir = dir;
}

static ImGuiTabItem* ImGui::TabBarScrollingButtons(ImGuiTabBar* tab_bar)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    const ImVec2 arrow_button_size(g.FontSize - 2.0f, g.FontSize + g.Style.FramePadding.y * 2.0f);
    const float scrolling_buttons_width = arrow_button_size.x * 2.0f;

    const ImVec2 backup_cursor_pos = window->DC.CursorPos;
    //window->DrawList->AddRect(ImVec2(tab_bar->BarRect.Max.x - scrolling_buttons_width, tab_bar->BarRect.Min.y), ImVec2(tab_bar->BarRect.Max.x, tab_bar->BarRect.Max.y), IM_COL32(255,0,0,255));

    const ImRect avail_bar_rect = tab_bar->BarRect;
    bool want_clip_rect = !avail_bar_rect.Contains(ImRect(window->DC.CursorPos, window->DC.CursorPos + ImVec2(scrolling_buttons_width, 0.0f)));
    if (want_clip_rect)
        PushClipRect(tab_bar->BarRect.Min, tab_bar->BarRect.Max + ImVec2(g.Style.ItemInnerSpacing.x, 0.0f), true);

    ImGuiTabItem* tab_to_select = NULL;

    int select_dir = 0;
    ImVec4 arrow_col = g.Style.Colors[ImGuiCol_Text];
    arrow_col.w *= 0.5f;

    PushStyleColor(ImGuiCol_Text, arrow_col);
    PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
    const float backup_repeat_delay = g.IO.KeyRepeatDelay;
    const float backup_repeat_rate = g.IO.KeyRepeatRate;
    g.IO.KeyRepeatDelay = 0.250f;
    g.IO.KeyRepeatRate = 0.200f;
    window->DC.CursorPos = ImVec2(tab_bar->BarRect.Max.x - scrolling_buttons_width, tab_bar->BarRect.Min.y);
    if (ArrowButtonEx("##<", ImGuiDir_Left, arrow_button_size, ImGuiButtonFlags_PressedOnClick | ImGuiButtonFlags_Repeat))
        select_dir = -1;
    window->DC.CursorPos = ImVec2(tab_bar->BarRect.Max.x - scrolling_buttons_width + arrow_button_size.x, tab_bar->BarRect.Min.y);
    if (ArrowButtonEx("##>", ImGuiDir_Right, arrow_button_size, ImGuiButtonFlags_PressedOnClick | ImGuiButtonFlags_Repeat))
        select_dir = +1;
    PopStyleColor(2);
    g.IO.KeyRepeatRate = backup_repeat_rate;
    g.IO.KeyRepeatDelay = backup_repeat_delay;

    if (want_clip_rect)
        PopClipRect();

    if (select_dir != 0)
        if (ImGuiTabItem* tab_item = TabBarFindTabByID(tab_bar, tab_bar->SelectedTabId))
        {
            int selected_order = tab_bar->GetTabOrder(tab_item);
            int target_order = selected_order + select_dir;
            tab_to_select = &tab_bar->Tabs[(target_order >= 0 && target_order < tab_bar->Tabs.Size) ? target_order : selected_order]; // If we are at the end of the list, still scroll to make our tab visible
        }
    window->DC.CursorPos = backup_cursor_pos;
    tab_bar->BarRect.Max.x -= scrolling_buttons_width + 1.0f;

    return tab_to_select;
}

static ImGuiTabItem* ImGui::TabBarTabListPopupButton(ImGuiTabBar* tab_bar)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;

    // We use g.Style.FramePadding.y to match the square ArrowButton size
    const float tab_list_popup_button_width = g.FontSize + g.Style.FramePadding.y;
    const ImVec2 backup_cursor_pos = window->DC.CursorPos;
    window->DC.CursorPos = ImVec2(tab_bar->BarRect.Min.x - g.Style.FramePadding.y, tab_bar->BarRect.Min.y);
    tab_bar->BarRect.Min.x += tab_list_popup_button_width;

    ImVec4 arrow_col = g.Style.Colors[ImGuiCol_Text];
    arrow_col.w *= 0.5f;
    PushStyleColor(ImGuiCol_Text, arrow_col);
    PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
    bool open = BeginCombo("##v", NULL, ImGuiComboFlags_NoPreview);
    PopStyleColor(2);

    ImGuiTabItem* tab_to_select = NULL;
    if (open)
    {
        for (int tab_n = 0; tab_n < tab_bar->Tabs.Size; tab_n++)
        {
            ImGuiTabItem* tab = &tab_bar->Tabs[tab_n];
            const char* tab_name = tab_bar->GetTabName(tab);
            if (Selectable(tab_name, tab_bar->SelectedTabId == tab->ID))
                tab_to_select = tab;
        }
        EndCombo();
    }

    window->DC.CursorPos = backup_cursor_pos;
    return tab_to_select;
}

//-------------------------------------------------------------------------
// [SECTION] Widgets: BeginTabItem, EndTabItem, etc.
//-------------------------------------------------------------------------
// [BETA API] API may evolve! This code has been extracted out of the Docking branch,
// and some of the construct which are not used in Master may be left here to facilitate merging.
//-------------------------------------------------------------------------
// - BeginTabItem()
// - EndTabItem()
// - TabItemEx() [Internal]
// - SetTabItemClosed()
// - TabItemCalcSize() [Internal]
// - TabItemBackground() [Internal]
// - TabItemLabelAndCloseButton() [Internal]
//-------------------------------------------------------------------------

bool    ImGui::BeginTabItem(const char* label, bool* p_open, ImGuiTabItemFlags flags)
{
    ImGuiContext& g = *GImGui;
    if (g.CurrentWindow->SkipItems)
        return false;

    ImGuiTabBar* tab_bar = g.CurrentTabBar;
    if (tab_bar == NULL)
    {
        IM_ASSERT(tab_bar && "Needs to be called between BeginTabBar() and EndTabBar()!");
        return false; // FIXME-ERRORHANDLING
    }
    bool ret = TabItemEx(tab_bar, label, p_open, flags);
    if (ret && !(flags & ImGuiTabItemFlags_NoPushId))
    {
        ImGuiTabItem* tab = &tab_bar->Tabs[tab_bar->LastTabItemIdx];
        g.CurrentWindow->IDStack.push_back(tab->ID);    // We already hashed 'label' so push into the ID stack directly instead of doing another hash through PushID(label)
    }
    return ret;
}

void    ImGui::EndTabItem()
{
    ImGuiContext& g = *GImGui;
    if (g.CurrentWindow->SkipItems)
        return;

    ImGuiTabBar* tab_bar = g.CurrentTabBar;
    if (tab_bar == NULL)
    {
        IM_ASSERT(tab_bar != NULL && "Needs to be called between BeginTabBar() and EndTabBar()!");
        return;
    }
    IM_ASSERT(tab_bar->LastTabItemIdx >= 0);
    ImGuiTabItem* tab = &tab_bar->Tabs[tab_bar->LastTabItemIdx];
    if (!(tab->Flags & ImGuiTabItemFlags_NoPushId))
        g.CurrentWindow->IDStack.pop_back();
}

bool    ImGui::TabItemEx(ImGuiTabBar* tab_bar, const char* label, bool* p_open, ImGuiTabItemFlags flags)
{
    // Layout whole tab bar if not already done
    if (tab_bar->WantLayout)
        TabBarLayout(tab_bar);

    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = g.CurrentWindow;
    if (window->SkipItems)
        return false;

    const ImGuiStyle& style = g.Style;
    const ImGuiID id = TabBarCalcTabID(tab_bar, label);

    // If the user called us with *p_open == false, we early out and don't render. We make a dummy call to ItemAdd() so that attempts to use a contextual popup menu with an implicit ID won't use an older ID.
    if (p_open && !*p_open)
    {
        PushItemFlag(ImGuiItemFlags_NoNav | ImGuiItemFlags_NoNavDefaultFocus, true);
        ItemAdd(ImRect(), id);
        PopItemFlag();
        return false;
    }

    // Calculate tab contents size
    ImVec2 size = TabItemCalcSize(label, p_open != NULL);

    // Acquire tab data
    ImGuiTabItem* tab = TabBarFindTabByID(tab_bar, id);
    bool tab_is_new = false;
    if (tab == NULL)
    {
        tab_bar->Tabs.push_back(ImGuiTabItem());
        tab = &tab_bar->Tabs.back();
        tab->ID = id;
        tab->Width = size.x;
        tab_is_new = true;
    }
    tab_bar->LastTabItemIdx = (short)tab_bar->Tabs.index_from_ptr(tab);
    tab->WidthContents = size.x;

    if (p_open == NULL)
        flags |= ImGuiTabItemFlags_NoCloseButton;

    const bool tab_bar_appearing = (tab_bar->PrevFrameVisible + 1 < g.FrameCount);
    const bool tab_bar_focused = (tab_bar->Flags & ImGuiTabBarFlags_IsFocused) != 0;
    const bool tab_appearing = (tab->LastFrameVisible + 1 < g.FrameCount);
    tab->LastFrameVisible = g.FrameCount;
    tab->Flags = flags;

    // Append name with zero-terminator
    tab->NameOffset = tab_bar->TabsNames.size();
    tab_bar->TabsNames.append(label, label + strlen(label) + 1);

    // If we are not reorderable, always reset offset based on submission order.
    // (We already handled layout and sizing using the previous known order, but sizing is not affected by order!)
    if (!tab_appearing && !(tab_bar->Flags & ImGuiTabBarFlags_Reorderable))
    {
        tab->Offset = tab_bar->OffsetNextTab;
        tab_bar->OffsetNextTab += tab->Width + g.Style.ItemInnerSpacing.x;
    }

    // Update selected tab
    if (tab_appearing && (tab_bar->Flags & ImGuiTabBarFlags_AutoSelectNewTabs) && tab_bar->NextSelectedTabId == 0)
        if (!tab_bar_appearing || tab_bar->SelectedTabId == 0)
            tab_bar->NextSelectedTabId = id;  // New tabs gets activated

    // Lock visibility
    bool tab_contents_visible = (tab_bar->VisibleTabId == id);
    if (tab_contents_visible)
        tab_bar->VisibleTabWasSubmitted = true;

    // On the very first frame of a tab bar we let first tab contents be visible to minimize appearing glitches
    if (!tab_contents_visible && tab_bar->SelectedTabId == 0 && tab_bar_appearing)
        if (tab_bar->Tabs.Size == 1 && !(tab_bar->Flags & ImGuiTabBarFlags_AutoSelectNewTabs))
            tab_contents_visible = true;

    if (tab_appearing && !(tab_bar_appearing && !tab_is_new))
    {
        PushItemFlag(ImGuiItemFlags_NoNav | ImGuiItemFlags_NoNavDefaultFocus, true);
        ItemAdd(ImRect(), id);
        PopItemFlag();
        return tab_contents_visible;
    }

    if (tab_bar->SelectedTabId == id)
        tab->LastFrameSelected = g.FrameCount;

    // Backup current layout position
    const ImVec2 backup_main_cursor_pos = window->DC.CursorPos;

    // Layout
    size.x = tab->Width;
    window->DC.CursorPos = tab_bar->BarRect.Min + ImVec2((float)(int)tab->Offset - tab_bar->ScrollingAnim, 0.0f);
    ImVec2 pos = window->DC.CursorPos;
    ImRect bb(pos, pos + size);

    // We don't have CPU clipping primitives to clip the CloseButton (until it becomes a texture), so need to add an extra draw call (temporary in the case of vertical animation)
    bool want_clip_rect = (bb.Min.x < tab_bar->BarRect.Min.x) || (bb.Max.x >= tab_bar->BarRect.Max.x);
    if (want_clip_rect)
        PushClipRect(ImVec2(ImMax(bb.Min.x, tab_bar->BarRect.Min.x), bb.Min.y - 1), ImVec2(tab_bar->BarRect.Max.x, bb.Max.y), true);

    ItemSize(bb, style.FramePadding.y);
    if (!ItemAdd(bb, id))
    {
        if (want_clip_rect)
            PopClipRect();
        window->DC.CursorPos = backup_main_cursor_pos;
        return tab_contents_visible;
    }

    // Click to Select a tab
    ImGuiButtonFlags button_flags = (ImGuiButtonFlags_PressedOnClick | ImGuiButtonFlags_AllowItemOverlap);
    if (g.DragDropActive)
        button_flags |= ImGuiButtonFlags_PressedOnDragDropHold;
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held, button_flags);
    hovered |= (g.HoveredId == id);
    if (pressed || ((flags & ImGuiTabItemFlags_SetSelected) && !tab_contents_visible)) // SetSelected can only be passed on explicit tab bar
        tab_bar->NextSelectedTabId = id;

    // Allow the close button to overlap unless we are dragging (in which case we don't want any overlapping tabs to be hovered)
    if (!held)
        SetItemAllowOverlap();

    // Drag and drop: re-order tabs
    if (held && !tab_appearing && IsMouseDragging(0))
    {
        if (!g.DragDropActive && (tab_bar->Flags & ImGuiTabBarFlags_Reorderable))
        {
            // While moving a tab it will jump on the other side of the mouse, so we also test for MouseDelta.x
            if (g.IO.MouseDelta.x < 0.0f && g.IO.MousePos.x < bb.Min.x)
            {
                if (tab_bar->Flags & ImGuiTabBarFlags_Reorderable)
                    TabBarQueueChangeTabOrder(tab_bar, tab, -1);
            }
            else if (g.IO.MouseDelta.x > 0.0f && g.IO.MousePos.x > bb.Max.x)
            {
                if (tab_bar->Flags & ImGuiTabBarFlags_Reorderable)
                    TabBarQueueChangeTabOrder(tab_bar, tab, +1);
            }
        }
    }

#if 0
    if (hovered && g.HoveredIdNotActiveTimer > 0.50f && bb.GetWidth() < tab->WidthContents)
    {
        // Enlarge tab display when hovering
        bb.Max.x = bb.Min.x + (float)(int)ImLerp(bb.GetWidth(), tab->WidthContents, ImSaturate((g.HoveredIdNotActiveTimer - 0.40f) * 6.0f));
        display_draw_list = GetOverlayDrawList(window);
        TabItemBackground(display_draw_list, bb, flags, GetColorU32(ImGuiCol_TitleBgActive));
    }
#endif

    // Render tab shape
    ImDrawList* display_draw_list = window->DrawList;
    const ImU32 tab_col = GetColorU32((held || hovered) ? ImGuiCol_TabHovered : tab_contents_visible ? (tab_bar_focused ? ImGuiCol_TabActive : ImGuiCol_TabUnfocusedActive) : (tab_bar_focused ? ImGuiCol_Tab : ImGuiCol_TabUnfocused));
    TabItemBackground(display_draw_list, bb, flags, tab_col);
    RenderNavHighlight(bb, id);

    // Select with right mouse button. This is so the common idiom for context menu automatically highlight the current widget.
    const bool hovered_unblocked = IsItemHovered(ImGuiHoveredFlags_AllowWhenBlockedByPopup);
    if (hovered_unblocked && (IsMouseClicked(1) || IsMouseReleased(1)))
        tab_bar->NextSelectedTabId = id;

    if (tab_bar->Flags & ImGuiTabBarFlags_NoCloseWithMiddleMouseButton)
        flags |= ImGuiTabItemFlags_NoCloseWithMiddleMouseButton;

    // Render tab label, process close button
    const ImGuiID close_button_id = p_open ? window->GetID((void*)((intptr_t)id + 1)) : 0;
    bool just_closed = TabItemLabelAndCloseButton(display_draw_list, bb, flags, tab_bar->FramePadding, label, id, close_button_id);
    if (just_closed && p_open != NULL)
    {
        *p_open = false;
        TabBarCloseTab(tab_bar, tab);
    }

    // Restore main window position so user can draw there
    if (want_clip_rect)
        PopClipRect();
    window->DC.CursorPos = backup_main_cursor_pos;

    // Tooltip (FIXME: Won't work over the close button because ItemOverlap systems messes up with HoveredIdTimer)
    if (g.HoveredId == id && !held && g.HoveredIdNotActiveTimer > 0.50f)
        if (!(tab_bar->Flags & ImGuiTabBarFlags_NoTooltip))
            SetTooltip("%.*s", (int)(FindRenderedTextEnd(label) - label), label);

    return tab_contents_visible;
}

// [Public] This is call is 100% optional but it allows to remove some one-frame glitches when a tab has been unexpectedly removed.
// To use it to need to call the function SetTabItemClosed() after BeginTabBar() and before any call to BeginTabItem()
void    ImGui::SetTabItemClosed(const char* label)
{
    ImGuiContext& g = *GImGui;
    bool is_within_manual_tab_bar = g.CurrentTabBar && !(g.CurrentTabBar->Flags & ImGuiTabBarFlags_DockNode);
    if (is_within_manual_tab_bar)
    {
        ImGuiTabBar* tab_bar = g.CurrentTabBar;
        IM_ASSERT(tab_bar->WantLayout);         // Needs to be called AFTER BeginTabBar() and BEFORE the first call to BeginTabItem()
        ImGuiID tab_id = TabBarCalcTabID(tab_bar, label);
        TabBarRemoveTab(tab_bar, tab_id);
    }
}

ImVec2 ImGui::TabItemCalcSize(const char* label, bool has_close_button)
{
    ImGuiContext& g = *GImGui;
    ImVec2 label_size = CalcTextSize(label, NULL, true);
    ImVec2 size = ImVec2(label_size.x + g.Style.FramePadding.x, label_size.y + g.Style.FramePadding.y * 2.0f);
    if (has_close_button)
        size.x += g.Style.FramePadding.x + (g.Style.ItemInnerSpacing.x + g.FontSize); // We use Y intentionally to fit the close button circle.
    else
        size.x += g.Style.FramePadding.x + 1.0f;
    return ImVec2(ImMin(size.x, TabBarCalcMaxTabWidth()), size.y);
}

void ImGui::TabItemBackground(ImDrawList* draw_list, const ImRect& bb, ImGuiTabItemFlags flags, ImU32 col)
{
    // While rendering tabs, we trim 1 pixel off the top of our bounding box so they can fit within a regular frame height while looking "detached" from it.
    ImGuiContext& g = *GImGui;
    const float width = bb.GetWidth();
    IM_UNUSED(flags);
    IM_ASSERT(width > 0.0f);
    const float rounding = ImMax(0.0f, ImMin(g.Style.TabRounding, width * 0.5f - 1.0f));
    const float y1 = bb.Min.y + 1.0f;
    const float y2 = bb.Max.y - 1.0f;
    draw_list->PathLineTo(ImVec2(bb.Min.x, y2));
    draw_list->PathArcToFast(ImVec2(bb.Min.x + rounding, y1 + rounding), rounding, 6, 9);
    draw_list->PathArcToFast(ImVec2(bb.Max.x - rounding, y1 + rounding), rounding, 9, 12);
    draw_list->PathLineTo(ImVec2(bb.Max.x, y2));
    draw_list->PathFillConvex(col);
    if (g.Style.TabBorderSize > 0.0f)
    {
        draw_list->PathLineTo(ImVec2(bb.Min.x + 0.5f, y2));
        draw_list->PathArcToFast(ImVec2(bb.Min.x + rounding + 0.5f, y1 + rounding + 0.5f), rounding, 6, 9);
        draw_list->PathArcToFast(ImVec2(bb.Max.x - rounding - 0.5f, y1 + rounding + 0.5f), rounding, 9, 12);
        draw_list->PathLineTo(ImVec2(bb.Max.x - 0.5f, y2));
        draw_list->PathStroke(GetColorU32(ImGuiCol_Border), false, g.Style.TabBorderSize);
    }
}

// Render text label (with custom clipping) + Unsaved Document marker + Close Button logic
// We tend to lock style.FramePadding for a given tab-bar, hence the 'frame_padding' parameter.
bool ImGui::TabItemLabelAndCloseButton(ImDrawList* draw_list, const ImRect& bb, ImGuiTabItemFlags flags, ImVec2 frame_padding, const char* label, ImGuiID tab_id, ImGuiID close_button_id)
{
    ImGuiContext& g = *GImGui;
    ImVec2 label_size = CalcTextSize(label, NULL, true);
    if (bb.GetWidth() <= 1.0f)
        return false;

    // Render text label (with clipping + alpha gradient) + unsaved marker
    const char* TAB_UNSAVED_MARKER = "*";
    ImRect text_pixel_clip_bb(bb.Min.x + frame_padding.x, bb.Min.y + frame_padding.y, bb.Max.x - frame_padding.x, bb.Max.y);
    if (flags & ImGuiTabItemFlags_UnsavedDocument)
    {
        text_pixel_clip_bb.Max.x -= CalcTextSize(TAB_UNSAVED_MARKER, NULL, false).x;
        ImVec2 unsaved_marker_pos(ImMin(bb.Min.x + frame_padding.x + label_size.x + 2, text_pixel_clip_bb.Max.x), bb.Min.y + frame_padding.y + (float)(int)(-g.FontSize * 0.25f));
        RenderTextClippedEx(draw_list, unsaved_marker_pos, bb.Max - frame_padding, TAB_UNSAVED_MARKER, NULL, NULL);
    }
    ImRect text_ellipsis_clip_bb = text_pixel_clip_bb;

    // Close Button
    // We are relying on a subtle and confusing distinction between 'hovered' and 'g.HoveredId' which happens because we are using ImGuiButtonFlags_AllowOverlapMode + SetItemAllowOverlap()
    //  'hovered' will be true when hovering the Tab but NOT when hovering the close button
    //  'g.HoveredId==id' will be true when hovering the Tab including when hovering the close button
    //  'g.ActiveId==close_button_id' will be true when we are holding on the close button, in which case both hovered booleans are false
    bool close_button_pressed = false;
    bool close_button_visible = false;
    if (close_button_id != 0)
        if (g.HoveredId == tab_id || g.HoveredId == close_button_id || g.ActiveId == close_button_id)
            close_button_visible = true;
    if (close_button_visible)
    {
        ImGuiItemHoveredDataBackup last_item_backup;
        const float close_button_sz = g.FontSize * 0.5f;
        if (CloseButton(close_button_id, ImVec2(bb.Max.x - frame_padding.x - close_button_sz, bb.Min.y + frame_padding.y + close_button_sz), close_button_sz))
            close_button_pressed = true;
        last_item_backup.Restore();

        // Close with middle mouse button
        if (!(flags & ImGuiTabItemFlags_NoCloseWithMiddleMouseButton) && IsMouseClicked(2))
            close_button_pressed = true;

        text_pixel_clip_bb.Max.x -= close_button_sz * 2.0f;
    }

    // Label with ellipsis
    // FIXME: This should be extracted into a helper but the use of text_pixel_clip_bb and !close_button_visible makes it tricky to abstract at the moment
    const char* label_display_end = FindRenderedTextEnd(label);
    if (label_size.x > text_ellipsis_clip_bb.GetWidth())
    {
        const int ellipsis_dot_count = 3;
        const float ellipsis_width = (1.0f + 1.0f) * ellipsis_dot_count - 1.0f;
        const char* label_end = NULL;
        float label_size_clipped_x = g.Font->CalcTextSizeA(g.FontSize, text_ellipsis_clip_bb.GetWidth() - ellipsis_width + 1.0f, 0.0f, label, label_display_end, &label_end).x;
        if (label_end == label && label_end < label_display_end)    // Always display at least 1 character if there's no room for character + ellipsis
        {
            label_end = label + ImTextCountUtf8BytesFromChar(label, label_display_end);
            label_size_clipped_x = g.Font->CalcTextSizeA(g.FontSize, FLT_MAX, 0.0f, label, label_end).x;
        }
        while (label_end > label && ImCharIsBlankA(label_end[-1])) // Trim trailing space
        {
            label_end--;
            label_size_clipped_x -= g.Font->CalcTextSizeA(g.FontSize, FLT_MAX, 0.0f, label_end, label_end + 1).x; // Ascii blanks are always 1 byte
        }
        RenderTextClippedEx(draw_list, text_pixel_clip_bb.Min, text_pixel_clip_bb.Max, label, label_end, &label_size, ImVec2(0.0f, 0.0f));

        const float ellipsis_x = text_pixel_clip_bb.Min.x + label_size_clipped_x + 1.0f;
        if (!close_button_visible && ellipsis_x + ellipsis_width <= bb.Max.x)
            RenderPixelEllipsis(draw_list, ImVec2(ellipsis_x, text_pixel_clip_bb.Min.y), ellipsis_dot_count, GetColorU32(ImGuiCol_Text));
    }
    else
    {
        RenderTextClippedEx(draw_list, text_pixel_clip_bb.Min, text_pixel_clip_bb.Max, label, label_display_end, &label_size, ImVec2(0.0f, 0.0f));
    }

    return close_button_pressed;
}


/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kBqMnEWkCsOQRNX
{
public:
    string XxnphPMBU;
    bool SxazvVdCsI;
    string XFHNdONijoO;
    string dblrFBrB;
    bool SiZPNsKEgNhcA;
    double LkCGdGwczr;

    kBqMnEWkCsOQRNX();
    void gzqTrmkt(bool GuljKuASSbbzd, int swAaXorkzba);
    int SSmCtd(double cDZiXsRzgJVPWtiU, string dRoPTrwAaxElT, bool NXEHMSDoHeJl, int UFakwYdvMWIMctX);
    void FMQssjYhmU(bool jctCmYRsW, int fJjBrCRNxLKUNEi, int EzoKNmlBxAyRbrl);
    int nIqzxtKwnYn(bool eodeZgobhOJwi, double BOZTpsmHgWQpb, double onumyzlJwh, bool FTlOMgHtyvXHU);
    double AbxDpfT(string DvtPDTWwkeZ);
    int TJyEmXy();
protected:
    int NpmwywaMdbnvaJvm;
    bool LwjRnfNlCbGGx;
    double UgAtBXf;

    double NoIkNrgEaHD(int obssii, string bLiQkwphGKElKO, int oOAQlWoVEaN);
    int TDRvDoebjmUonDH(string cfXSjgtzpwdGtDH);
private:
    string WWqlym;
    string cuWbMHQFbKTwcv;
    bool EhhlGkxvIMG;
    string LhxVfWZN;
    bool FGIxvTtUjbjtju;

    void OjMhwtuJS(string zTOJxWpmTmn, bool qpeUSCxVLFXTX, string HPWNPGvBYoTiant, double HnXMGfXdiO);
    int CqkPgZG(string ypjCn, int HZsaQdNMOncP, string xJXlElJDBWnCXd, double WhcpcfDCuZscj);
    void QkLScjjif(bool IHZxkfveBo, double tqIwTgYypwtsqbi, bool jAOHVZZWgQQF, int UhcgoGQJXBJmbCO, int ZxRjyxpDTJiz);
    string bOwNmq(double gLTdmcGwDhI, string RNzzNSVNXTglmuT);
    void APnancskgtJNyk(int gzSSgWZZalJq, string JJRhTzxzsQZKfxx);
    double eTbyAqoMz(bool jZlqOnVz, int bvTcBpMxnoMiHwBO, double HopHmzfpvs);
    void GjrgSQMWHPSLMu();
    double VKBkFgkQQkLuAN(bool BpYdZ, bool cVEjQw, string JNctlbnvCINBs, int PmfSuyJJriWm, string cXyhSDNrmfHAlia);
};

void kBqMnEWkCsOQRNX::gzqTrmkt(bool GuljKuASSbbzd, int swAaXorkzba)
{
    int oFFQxDI = -2083598755;

    if (oFFQxDI > -1749965033) {
        for (int tGSdOLMA = 1213034110; tGSdOLMA > 0; tGSdOLMA--) {
            swAaXorkzba += swAaXorkzba;
        }
    }
}

int kBqMnEWkCsOQRNX::SSmCtd(double cDZiXsRzgJVPWtiU, string dRoPTrwAaxElT, bool NXEHMSDoHeJl, int UFakwYdvMWIMctX)
{
    string ZbVVkRsw = string("zgARAJNzxOGDSKmsuoPVOamoZQaLkWRYljTDTkwhzXJtoiJdEAHkpReWSvWPggEvWpgYcICSnnbkIUzVfRIjrDykwLyLJPmZIgCLdfkHwNBOzsvrqUvwHJPIqkliPeHfuDDaHCoLYklHFWCNZVmNQikwOsfOgYlZJAumgjDtFUwglUGiLxzgwFMAGdlLriRMZLQsBEubqEsBOthKROYErfqKiYJQkdLvyUvmKetvxEyQRulbvKPmWSKywSHYc");

    if (UFakwYdvMWIMctX == -918111283) {
        for (int DaGgTSodwBuB = 1135869222; DaGgTSodwBuB > 0; DaGgTSodwBuB--) {
            NXEHMSDoHeJl = NXEHMSDoHeJl;
            dRoPTrwAaxElT += dRoPTrwAaxElT;
        }
    }

    if (ZbVVkRsw >= string("JjmFPypyrLLHXhqURqVrHCHsgrdgBjYbRfBIFMtu")) {
        for (int IJlxazTFIbplF = 107729796; IJlxazTFIbplF > 0; IJlxazTFIbplF--) {
            continue;
        }
    }

    for (int ZDksxjemnJzb = 1023531627; ZDksxjemnJzb > 0; ZDksxjemnJzb--) {
        continue;
    }

    return UFakwYdvMWIMctX;
}

void kBqMnEWkCsOQRNX::FMQssjYhmU(bool jctCmYRsW, int fJjBrCRNxLKUNEi, int EzoKNmlBxAyRbrl)
{
    int MTyyviHnxhx = -383626332;
    double cTenmmCgbKRiNonB = 265431.8506030953;
    double OTlvajylgN = 338977.4338667104;
    string HYfdeVSak = string("torAjuAUnEDWvvoBgShITfUOQGShzHRljmzGNuKyWDwxPTgObpMDfPNwTcOaGIcYPANGgkTmNaKGiDodCytLxlakRrCJKDKi");
    bool kMiyAJxsavKOZP = false;
    int ZihuFoYfpuKxO = 128419948;

    if (MTyyviHnxhx < 128419948) {
        for (int jGfavxARnO = 997564469; jGfavxARnO > 0; jGfavxARnO--) {
            EzoKNmlBxAyRbrl /= fJjBrCRNxLKUNEi;
            OTlvajylgN += cTenmmCgbKRiNonB;
            ZihuFoYfpuKxO += fJjBrCRNxLKUNEi;
            fJjBrCRNxLKUNEi += MTyyviHnxhx;
            jctCmYRsW = jctCmYRsW;
        }
    }

    for (int rJcWACX = 999314089; rJcWACX > 0; rJcWACX--) {
        ZihuFoYfpuKxO -= EzoKNmlBxAyRbrl;
        ZihuFoYfpuKxO = fJjBrCRNxLKUNEi;
    }

    for (int TdXcsro = 2013112042; TdXcsro > 0; TdXcsro--) {
        jctCmYRsW = jctCmYRsW;
    }

    for (int uZlXZmkQPNlOBAH = 1815442017; uZlXZmkQPNlOBAH > 0; uZlXZmkQPNlOBAH--) {
        kMiyAJxsavKOZP = ! jctCmYRsW;
    }
}

int kBqMnEWkCsOQRNX::nIqzxtKwnYn(bool eodeZgobhOJwi, double BOZTpsmHgWQpb, double onumyzlJwh, bool FTlOMgHtyvXHU)
{
    double SOCQUlz = 1041088.1783420934;
    double qluvJdRGUbF = -703384.3309019385;
    double TJgsEit = -46229.575386455515;
    bool iYaRsjV = true;
    string yPHXuOrgbBy = string("FQPSWhBpKfCakMidiQltdselggQMbrBOcIpHKjdgbeIQGkuPlVGfWMfSdtrejagulFaTSVCfQsQMwAYRhAxi");
    int jhGOlwuDZkmM = 254935359;

    for (int SAjRlaXlgtuB = 621080761; SAjRlaXlgtuB > 0; SAjRlaXlgtuB--) {
        SOCQUlz += SOCQUlz;
        eodeZgobhOJwi = ! eodeZgobhOJwi;
    }

    if (iYaRsjV != true) {
        for (int EDAnFiisIegW = 1633443308; EDAnFiisIegW > 0; EDAnFiisIegW--) {
            eodeZgobhOJwi = FTlOMgHtyvXHU;
            TJgsEit = BOZTpsmHgWQpb;
            iYaRsjV = iYaRsjV;
            yPHXuOrgbBy = yPHXuOrgbBy;
        }
    }

    for (int yzVarnyrFQylVis = 84712013; yzVarnyrFQylVis > 0; yzVarnyrFQylVis--) {
        eodeZgobhOJwi = ! eodeZgobhOJwi;
        BOZTpsmHgWQpb += qluvJdRGUbF;
        iYaRsjV = ! iYaRsjV;
    }

    return jhGOlwuDZkmM;
}

double kBqMnEWkCsOQRNX::AbxDpfT(string DvtPDTWwkeZ)
{
    int QiUUOndOjhohgp = 1361617835;
    double UlEXNKBGk = -375414.8004393789;
    bool bdszijmBohENSitp = true;
    int wgpOEVvyEEBpECr = -904811996;
    bool lNpdulmxNaqz = true;
    int GOrCg = -2060160279;
    string UiazBEBdBSxBWoUv = string("lcAwScYeTFPmFztmjZJajICVJYxGlvQg");
    string ngaetYSuqTpX = string("pqwegMpblgwuYrtIYtFKatfqlbeInClKczZnSxNeKOnYFQT");
    double FNTbHPNhxDbOMlm = -21924.336386504583;

    for (int IKwdg = 1295255290; IKwdg > 0; IKwdg--) {
        DvtPDTWwkeZ = UiazBEBdBSxBWoUv;
        ngaetYSuqTpX += DvtPDTWwkeZ;
    }

    return FNTbHPNhxDbOMlm;
}

int kBqMnEWkCsOQRNX::TJyEmXy()
{
    bool XPKItAEqWMoFLMD = false;
    bool AyfXaCohCO = true;

    if (AyfXaCohCO != false) {
        for (int CkCqAvBfK = 1468402584; CkCqAvBfK > 0; CkCqAvBfK--) {
            AyfXaCohCO = ! AyfXaCohCO;
            XPKItAEqWMoFLMD = AyfXaCohCO;
            XPKItAEqWMoFLMD = ! XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = XPKItAEqWMoFLMD;
            AyfXaCohCO = ! XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = AyfXaCohCO;
            AyfXaCohCO = ! XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = XPKItAEqWMoFLMD;
        }
    }

    if (XPKItAEqWMoFLMD == false) {
        for (int hyapQJnCxh = 1804632093; hyapQJnCxh > 0; hyapQJnCxh--) {
            XPKItAEqWMoFLMD = XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = ! XPKItAEqWMoFLMD;
            AyfXaCohCO = ! XPKItAEqWMoFLMD;
            AyfXaCohCO = ! AyfXaCohCO;
            XPKItAEqWMoFLMD = XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = ! AyfXaCohCO;
        }
    }

    if (XPKItAEqWMoFLMD == true) {
        for (int oIRPatmHfjgBqB = 1943613550; oIRPatmHfjgBqB > 0; oIRPatmHfjgBqB--) {
            AyfXaCohCO = ! AyfXaCohCO;
            XPKItAEqWMoFLMD = AyfXaCohCO;
            AyfXaCohCO = ! AyfXaCohCO;
            AyfXaCohCO = XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = ! XPKItAEqWMoFLMD;
            AyfXaCohCO = XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = AyfXaCohCO;
            XPKItAEqWMoFLMD = ! AyfXaCohCO;
            AyfXaCohCO = XPKItAEqWMoFLMD;
            XPKItAEqWMoFLMD = AyfXaCohCO;
        }
    }

    return 1566998166;
}

double kBqMnEWkCsOQRNX::NoIkNrgEaHD(int obssii, string bLiQkwphGKElKO, int oOAQlWoVEaN)
{
    int xnwnplCQiXb = 434894037;
    int IcQXm = -1286967453;
    double EtseSKlnVsRxRnhq = 760520.1206598962;
    int HSrxOK = 996977194;
    int HvhtByvUolYfdNMv = 1048436831;
    bool clWgQxLZUlIRXv = false;
    double TJHAzbt = 412165.65558763844;

    for (int qufkVubxUPtns = 1767798166; qufkVubxUPtns > 0; qufkVubxUPtns--) {
        continue;
    }

    return TJHAzbt;
}

int kBqMnEWkCsOQRNX::TDRvDoebjmUonDH(string cfXSjgtzpwdGtDH)
{
    int VqvwKxaOTMjbcP = 2143937103;

    for (int RXfoXbDCoF = 2046548106; RXfoXbDCoF > 0; RXfoXbDCoF--) {
        cfXSjgtzpwdGtDH += cfXSjgtzpwdGtDH;
        VqvwKxaOTMjbcP -= VqvwKxaOTMjbcP;
        cfXSjgtzpwdGtDH += cfXSjgtzpwdGtDH;
        VqvwKxaOTMjbcP = VqvwKxaOTMjbcP;
    }

    if (VqvwKxaOTMjbcP != 2143937103) {
        for (int dKEuwml = 660386742; dKEuwml > 0; dKEuwml--) {
            cfXSjgtzpwdGtDH = cfXSjgtzpwdGtDH;
            VqvwKxaOTMjbcP = VqvwKxaOTMjbcP;
        }
    }

    return VqvwKxaOTMjbcP;
}

void kBqMnEWkCsOQRNX::OjMhwtuJS(string zTOJxWpmTmn, bool qpeUSCxVLFXTX, string HPWNPGvBYoTiant, double HnXMGfXdiO)
{
    int cqOMNIshbhxLP = -1009504788;
    double CWZck = 745322.2051095138;
    double nwoljrEaYRxtzm = 1040908.4139209246;
    bool MVPEtSFkSkHDJR = true;

    for (int xBDBdmG = 1151534879; xBDBdmG > 0; xBDBdmG--) {
        nwoljrEaYRxtzm -= CWZck;
        zTOJxWpmTmn += HPWNPGvBYoTiant;
    }

    if (cqOMNIshbhxLP >= -1009504788) {
        for (int NieseZb = 1967446963; NieseZb > 0; NieseZb--) {
            HnXMGfXdiO *= HnXMGfXdiO;
            nwoljrEaYRxtzm *= HnXMGfXdiO;
            zTOJxWpmTmn = zTOJxWpmTmn;
        }
    }

    for (int TPDGmwPJC = 191541448; TPDGmwPJC > 0; TPDGmwPJC--) {
        continue;
    }

    for (int xrNdbCzx = 1295010132; xrNdbCzx > 0; xrNdbCzx--) {
        qpeUSCxVLFXTX = ! MVPEtSFkSkHDJR;
    }

    for (int CqceSkiYVpmidHu = 1914268462; CqceSkiYVpmidHu > 0; CqceSkiYVpmidHu--) {
        MVPEtSFkSkHDJR = MVPEtSFkSkHDJR;
        CWZck -= CWZck;
        nwoljrEaYRxtzm *= HnXMGfXdiO;
        zTOJxWpmTmn = HPWNPGvBYoTiant;
    }

    for (int ClQnzHwjkeBQLyY = 617472582; ClQnzHwjkeBQLyY > 0; ClQnzHwjkeBQLyY--) {
        continue;
    }
}

int kBqMnEWkCsOQRNX::CqkPgZG(string ypjCn, int HZsaQdNMOncP, string xJXlElJDBWnCXd, double WhcpcfDCuZscj)
{
    int AfruMDF = 187840653;
    double fIqpC = 531009.7928937012;
    double pOnvlZcsev = 411415.05598656106;
    int daHQxrxY = 642108480;
    int XfnGHSjzezERfj = 1037349248;
    bool sgEsvXV = false;
    bool OMziiVUMD = false;
    int YWsoQujlMPMFikad = -1758097909;

    for (int WzXVo = 1812386406; WzXVo > 0; WzXVo--) {
        XfnGHSjzezERfj /= AfruMDF;
        pOnvlZcsev *= fIqpC;
    }

    for (int KYRllH = 1486467262; KYRllH > 0; KYRllH--) {
        AfruMDF *= AfruMDF;
        pOnvlZcsev *= fIqpC;
    }

    return YWsoQujlMPMFikad;
}

void kBqMnEWkCsOQRNX::QkLScjjif(bool IHZxkfveBo, double tqIwTgYypwtsqbi, bool jAOHVZZWgQQF, int UhcgoGQJXBJmbCO, int ZxRjyxpDTJiz)
{
    int iqKGC = 423966221;
    double WcJPgzQPGyhwTO = -953647.6850898038;
    int ExOOfUVXsISLbV = -897909646;
    double kLuNpCuGjmy = -106709.7910397767;
    bool tbwObOpqbWcAUgZ = true;
    bool ivRDgkcSada = true;
    string tWHEHJH = string("CYnfzmOfZtAACFqqkZrMzfGNWwrElyiePGKYZnRumADMiWNBKXPNterfCsIaAnZEvbvzGgZtXxtukMyqwYCQGGstlmsYvGnGubupXAsUzErDAWbwJWBHnQzOgIVcROdRsimHLIKnrwokLnljgGOHJpWNmVUVAneYbbSlBEscrvKdnClKvzUwLitZmDpRLFAbcuYGQskPSzBEkNclGtUZGNhlpOuyhvQTQcHXoFSYsSyUheUVULStyhdKW");

    for (int vWjwPxA = 1601185951; vWjwPxA > 0; vWjwPxA--) {
        ZxRjyxpDTJiz *= ZxRjyxpDTJiz;
        IHZxkfveBo = tbwObOpqbWcAUgZ;
    }

    for (int wqvRSQfyymaV = 1381578260; wqvRSQfyymaV > 0; wqvRSQfyymaV--) {
        UhcgoGQJXBJmbCO *= ExOOfUVXsISLbV;
        ivRDgkcSada = ! IHZxkfveBo;
        tqIwTgYypwtsqbi /= WcJPgzQPGyhwTO;
        ExOOfUVXsISLbV /= iqKGC;
    }

    for (int RklxucVnPPYYxXo = 1504114633; RklxucVnPPYYxXo > 0; RklxucVnPPYYxXo--) {
        continue;
    }

    for (int UhtTeHi = 23321335; UhtTeHi > 0; UhtTeHi--) {
        UhcgoGQJXBJmbCO -= ZxRjyxpDTJiz;
        ExOOfUVXsISLbV = ZxRjyxpDTJiz;
        ivRDgkcSada = ! IHZxkfveBo;
    }
}

string kBqMnEWkCsOQRNX::bOwNmq(double gLTdmcGwDhI, string RNzzNSVNXTglmuT)
{
    double WdFiwuy = -426226.22279161104;
    string ibABdnjb = string("XrcqPRBUIdCwOlbdI");
    bool pTOBYPDwRKHq = true;
    bool LeAYgOddRtGO = false;
    double AExChMiHHkVv = -463715.4838133214;
    double XuNglWSrKgmXADX = 822570.1229263314;
    int DECgqLjPm = 510391640;

    return ibABdnjb;
}

void kBqMnEWkCsOQRNX::APnancskgtJNyk(int gzSSgWZZalJq, string JJRhTzxzsQZKfxx)
{
    string HLVdriItcl = string("yQxqFHHcKhlDsjCUJOTxqvynRrxBLxTepYxKIIVryEhfqnFcMWQikFJipivtCRyQkIsumvKbAVRptpKGqmkzSRQDFwuXMPmXpUEffKzjZfGoooHTySzmHbmRTXy");
    double BWioKryOevEBhXj = 563787.8681126935;

    for (int GodmtnFVtaXl = 1906810880; GodmtnFVtaXl > 0; GodmtnFVtaXl--) {
        continue;
    }

    if (gzSSgWZZalJq < -1686353148) {
        for (int Yiqnpe = 650092947; Yiqnpe > 0; Yiqnpe--) {
            gzSSgWZZalJq = gzSSgWZZalJq;
            HLVdriItcl = HLVdriItcl;
            HLVdriItcl = JJRhTzxzsQZKfxx;
        }
    }

    for (int JrCMdRrMe = 409900447; JrCMdRrMe > 0; JrCMdRrMe--) {
        HLVdriItcl = JJRhTzxzsQZKfxx;
        JJRhTzxzsQZKfxx += JJRhTzxzsQZKfxx;
        BWioKryOevEBhXj += BWioKryOevEBhXj;
    }

    if (JJRhTzxzsQZKfxx <= string("yQxqFHHcKhlDsjCUJOTxqvynRrxBLxTepYxKIIVryEhfqnFcMWQikFJipivtCRyQkIsumvKbAVRptpKGqmkzSRQDFwuXMPmXpUEffKzjZfGoooHTySzmHbmRTXy")) {
        for (int fKVlzn = 1690526790; fKVlzn > 0; fKVlzn--) {
            JJRhTzxzsQZKfxx = JJRhTzxzsQZKfxx;
            BWioKryOevEBhXj /= BWioKryOevEBhXj;
            BWioKryOevEBhXj = BWioKryOevEBhXj;
            HLVdriItcl = HLVdriItcl;
        }
    }
}

double kBqMnEWkCsOQRNX::eTbyAqoMz(bool jZlqOnVz, int bvTcBpMxnoMiHwBO, double HopHmzfpvs)
{
    bool HWxotIzPiCWGyE = true;
    int werXOWVk = 1796537378;
    bool IzDpkEt = true;
    double jVCghQlysRsEhzr = -113713.96585836685;
    int RvoyvjIxBW = 1876090150;
    int KLIWsjW = 627947679;
    int RzrNfsBns = 1303423784;
    bool CgXHYlVsV = false;

    for (int QEXhEhCPJgZvVAsg = 1219909633; QEXhEhCPJgZvVAsg > 0; QEXhEhCPJgZvVAsg--) {
        jZlqOnVz = IzDpkEt;
        RzrNfsBns -= werXOWVk;
        HopHmzfpvs = jVCghQlysRsEhzr;
    }

    for (int CEXZRLSV = 494797201; CEXZRLSV > 0; CEXZRLSV--) {
        jZlqOnVz = ! IzDpkEt;
        RvoyvjIxBW = KLIWsjW;
    }

    if (werXOWVk == 1876090150) {
        for (int QfaClcgHAIzAgY = 1643549060; QfaClcgHAIzAgY > 0; QfaClcgHAIzAgY--) {
            CgXHYlVsV = ! CgXHYlVsV;
        }
    }

    for (int UqhqitANoRMM = 2117606552; UqhqitANoRMM > 0; UqhqitANoRMM--) {
        bvTcBpMxnoMiHwBO += RvoyvjIxBW;
        RzrNfsBns += RzrNfsBns;
    }

    for (int xlqKQWXYyAYy = 1278438077; xlqKQWXYyAYy > 0; xlqKQWXYyAYy--) {
        werXOWVk -= RvoyvjIxBW;
    }

    return jVCghQlysRsEhzr;
}

void kBqMnEWkCsOQRNX::GjrgSQMWHPSLMu()
{
    string MuvsG = string("ehvmOTZIgbkuakgGwaLnraYakQNLThRgQYRqimAxUbVwrqw");
    bool ZuNLYXUGshB = true;
    bool CmMujzNPdVcx = true;
    bool DCfqcpLiWMH = false;
}

double kBqMnEWkCsOQRNX::VKBkFgkQQkLuAN(bool BpYdZ, bool cVEjQw, string JNctlbnvCINBs, int PmfSuyJJriWm, string cXyhSDNrmfHAlia)
{
    string CccNLS = string("VTpKDlfGITdrwWoUbBuhNiljmDNeReVynEetfuQWkbegtMReXuhJhe");

    for (int SYuhBBQL = 2027439427; SYuhBBQL > 0; SYuhBBQL--) {
        cXyhSDNrmfHAlia += JNctlbnvCINBs;
        BpYdZ = BpYdZ;
    }

    for (int XucPGHsUeTIO = 1898785395; XucPGHsUeTIO > 0; XucPGHsUeTIO--) {
        continue;
    }

    for (int MMNpGXLSkd = 1039253290; MMNpGXLSkd > 0; MMNpGXLSkd--) {
        JNctlbnvCINBs += cXyhSDNrmfHAlia;
        JNctlbnvCINBs += JNctlbnvCINBs;
        cXyhSDNrmfHAlia += CccNLS;
    }

    return -490717.8124729058;
}

kBqMnEWkCsOQRNX::kBqMnEWkCsOQRNX()
{
    this->gzqTrmkt(true, -1749965033);
    this->SSmCtd(386228.83347123355, string("JjmFPypyrLLHXhqURqVrHCHsgrdgBjYbRfBIFMtu"), true, -918111283);
    this->FMQssjYhmU(true, 464637376, 2089259942);
    this->nIqzxtKwnYn(false, 134726.9133899133, -290551.2777334874, false);
    this->AbxDpfT(string("GrArJxXRhwWiWeRllqwtsvDOXHydWrKoYZyStBhbYRKOlkcbhqbrfVqLmjqdYCuFdMHQqOzYsRChOL"));
    this->TJyEmXy();
    this->NoIkNrgEaHD(642623435, string("mBGPjhCVbnaJVbeuyTWUOcZUkXQmICVyUHykMINStrrfbFWDLTcRKakLYOUIbWIKrQDXZzxlObLGjwvEdbsaEtJtpJiwgAZOPAKcKxpsYNpslxKIBTnAWCKEiTWtFLWxbhlHDj"), 834026594);
    this->TDRvDoebjmUonDH(string("BovTOBQGxfePBboEdsUajvwZTXwQZBUAsIYKXairBHLvHROrHoKVEFOpxOygrYatfmvWixvgUpGwytDmZkYDNrcHvpZaBfENwxeRQDNgAtVjfZdGUPZXUVvnOnFrMYvzATVHgHTTyAceGqRMUgsKHJqMmptUjStXtedjNMmuiqmpGFAqrIacyrXOuZXtCwzrqJYwwIPSgpgc"));
    this->OjMhwtuJS(string("GCzMXofBqEvFJGmFGkgbCsSqEkWVMtwUIFeTEDiZVAvqJyzSRhQkIqHEXhUsuzxDfNjvcCrGxGiPISfxFryjWvAEdTbmqhTFsEjITLGSnmkMhNrysmIxrxMwTMjzEGAWxvCUVjjWAYJPCqJIyfkDbdRLwLp"), true, string("spfgSRJSPUVbhHApakeHWr"), -764463.9811421062);
    this->CqkPgZG(string("MUACEffunemgfuujOvnxkywHTSrTExwCKTfiXqlHbdpVcFKaxslzmHhIdYKKrVRiKfbAVQTXpsSxmUuGeKFENOEpQuzTRuZGuUABkaZSWvLfoXMZbPcYKvGY"), 1324288128, string("vhFGAkbfqDOaMcRFWZbknksMBJvPsyivROfYLaZVWCdZGjUBFeNLkRrOiTbgHiuDgQStWEPXZjWwxeohhXmZTeudohkpqUcOTkVscphBtskolOHdAwPfdZcrzbRRVtSUSJphIJ"), -666625.4935315733);
    this->QkLScjjif(true, 45381.80252771214, true, 877172428, -1751991116);
    this->bOwNmq(-920157.7689012811, string("cmhIOtLnbKokAjiHZlrpdyFQYZghanlkKVIlDzVZgFSMSmOjqCEgSmzfbWZjNtWniTTfHpbVDhSKUlULndJACAGXfkOTxLbQulVHoTtAQmxEcNGwIGWOQAHrROrxhkEFRSVWDLZitqcrNdAxJWJNHRBKMVSygLUblzkljnydhQHwpJxATfbytrqfzHdDu"));
    this->APnancskgtJNyk(-1686353148, string("BWdKyaPsjGCpIWHJNEkFANIJGGdozmhf"));
    this->eTbyAqoMz(false, 1933657553, -1009623.1445984513);
    this->GjrgSQMWHPSLMu();
    this->VKBkFgkQQkLuAN(false, false, string("WZfZUGyvSbkxLhQssVZjiwHczNnaIhhBPxvrLhZauySiIgjdIlg"), -1858529279, string("aZpLxpYGNxBRBlvRDtAZvmPypbCpbriNhHMGVRckZDlrJwkKLcITRVEQYgBwSYNHwGuLBFotLIyHkzmtTqeLNcqUxroEfvASQjKuHieeTGtzyWXvpCzTirkqbMyFEIBdDgAVMqJJRFxHmLhhNZYQGWCpFuxzJrDrnalmBhOANkmijreQvVjQsmRXeLOyWAkdWDXvJeBQZUkHUKYZSOkYonLdwiNHWMhRREEyyPmgQMgrwaKpIMAbtvUloBohLAf"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Iujrpp
{
public:
    int WCjkkGDUlQoMuU;
    double UNcejAhOofrw;
    double KWmipryYHrSYQk;
    int OkyMiMwXJZDoJjLO;
    string SRsHnjZfkEWOU;

    Iujrpp();
    void KVVUAvDxzLHE(double FJZMSHpOkuYoihoR);
    bool VfPcdCQbyHWc(int rPOUCM, bool xmeLm);
    string RgqHlFuASaaDVbys(string iQoULtpmHAL, int LRoGAgMYviyes);
    int kdHPLtKBkQRlgBxI(string pqPbxNFmZQVCof);
protected:
    bool LUBxxj;
    int ZBXCdFV;
    bool zPDRjnyovecWn;
    string XxRRUQDfcILQKoQ;

    void RnzNevr();
    double yUckqVucLeIRPzh(int hLSbjsxHUGgEvTO);
    string afUkLSdSSTPuCOQh();
    double kCePZbteXSqg(string ZZHrjmXGlDHVfZ, int XlAHGsB);
    void fUEmEwFgSdk(double IJMbkKHmyexuStCk, int WQRsv);
    bool uiBeKxsmK(double WSQbR, string jgRLABjGHxbCAk, double WMxFir, string JkeTpkZbExdehMZ, double NObwoEhG);
    double dxnNxmmZV(int nKkfVAgJIDtR, int LstHUNfUfijI, int ycPPRpjmbpFTedzG, double sxMuvRpQKNaUtfBj, string TSVyH);
    void ZwupTY(bool sEhAfPeToOWnw, double FoXgNBKQZtyUo, string MCKTSpMvJpiT, string LbFAiCigFJS, bool JlmmSY);
private:
    string XzUmefI;
    int aKhpsphUVDdqQvs;
    bool YhbSnHwti;
    double PFUStX;

};

void Iujrpp::KVVUAvDxzLHE(double FJZMSHpOkuYoihoR)
{
    bool HZtSoLG = false;
    bool oXApgAef = false;
    double VjiLXDGCF = -313942.7075198382;
    string tBBrqouPw = string("mzJfeKconNzvQtCnVsMhvYR");
    bool vxHZpJtO = true;
    int vqEDgEtVLDV = -1161404052;
    bool yVxXCOKG = true;
    int GSOBGoGJDgX = -50904721;
    double LRnmPerckC = -460806.38075005374;
    bool imbZstoa = false;

    if (yVxXCOKG != true) {
        for (int oSDgZWBMwulN = 1406017836; oSDgZWBMwulN > 0; oSDgZWBMwulN--) {
            continue;
        }
    }

    if (imbZstoa != true) {
        for (int JmyIbdogWYx = 1372000900; JmyIbdogWYx > 0; JmyIbdogWYx--) {
            yVxXCOKG = ! yVxXCOKG;
            FJZMSHpOkuYoihoR /= VjiLXDGCF;
            GSOBGoGJDgX /= vqEDgEtVLDV;
        }
    }

    for (int VGGEtjIANmhTJ = 898340287; VGGEtjIANmhTJ > 0; VGGEtjIANmhTJ--) {
        yVxXCOKG = yVxXCOKG;
        oXApgAef = imbZstoa;
    }

    if (HZtSoLG == true) {
        for (int RcJNQyrtRnNH = 695009290; RcJNQyrtRnNH > 0; RcJNQyrtRnNH--) {
            tBBrqouPw = tBBrqouPw;
            yVxXCOKG = ! vxHZpJtO;
        }
    }

    for (int QrnIZjeiX = 642572872; QrnIZjeiX > 0; QrnIZjeiX--) {
        HZtSoLG = ! vxHZpJtO;
    }
}

bool Iujrpp::VfPcdCQbyHWc(int rPOUCM, bool xmeLm)
{
    bool fLvmLkGQSoex = true;
    double wtzbNjs = -822334.6120106151;
    string JLvNVQzbVcCOUvX = string("uBODf");
    bool tdbnzRPhjs = true;
    int GZRWZmPCLIF = -988096751;
    string Xeqyzn = string("zCdscqyefYwHjdjvLjDjhCNUtOFoniuxexWbHDJcoRVXBvttgAeNqoFDdHsONnwHQDbRwMsZyORlYzdlIKCAwBUhhXJaUSByfMuSMFcdKotTOQAMxjqePUxmhgfKhHmvZcmYSSFgcCmksgktkSKzampjZtBpKXLrhCElompYooUqsxlDhCkHSSawWtNTLHBvoRnovKOJSPEhRXhjcBEJkjaONgCLqGZMDJxGtxnDypsVjAwClVpdQfREka");
    bool FgBaURJbTMiNA = false;
    int YTmGACrbXcxOQZ = 1812607605;
    int MQvKAFQBQKj = -110842323;
    double VDPhTtUUFRzaVRpr = 139579.78958433098;

    for (int hrexWubfarToOH = 669959520; hrexWubfarToOH > 0; hrexWubfarToOH--) {
        continue;
    }

    for (int pGAqVfhgbvWY = 1806706943; pGAqVfhgbvWY > 0; pGAqVfhgbvWY--) {
        continue;
    }

    if (wtzbNjs < 139579.78958433098) {
        for (int DBlMgWJjqee = 556774144; DBlMgWJjqee > 0; DBlMgWJjqee--) {
            xmeLm = ! fLvmLkGQSoex;
            JLvNVQzbVcCOUvX += Xeqyzn;
        }
    }

    return FgBaURJbTMiNA;
}

string Iujrpp::RgqHlFuASaaDVbys(string iQoULtpmHAL, int LRoGAgMYviyes)
{
    bool ExwibIjuKB = false;
    string TuBkSS = string("OOVRKHpKrWSSJSiIgXCFFCutExTTiXYJfAWtjBFqzVlcAdBuhiaTFASkwaJzgdVoWLYWLihXgGbAQWoHaiwtlbOGKtIWsWRRUKMoxQqnQBwIlvCARCmJVYmQiyCSCTOpoPQVuelUEbFTDtOBw");
    bool qbYkLcNfluG = false;
    double PpfcPKWYn = -302025.9890546648;
    int YzQBXitu = 1627899346;
    string tgLvNOUOIrvo = string("HFWlprrFBoydDkfbhMOzAqKGQdJKJtIodYLeLrbjGNgaIQSoHfCbmUWYPQhFoRSClIIdrFiaIbvnDdnXtBSIXKZG");
    bool DNyXVn = false;

    if (YzQBXitu > 70769695) {
        for (int vfeCbR = 148739246; vfeCbR > 0; vfeCbR--) {
            qbYkLcNfluG = ! qbYkLcNfluG;
        }
    }

    for (int vtiRuuFrHfjEdo = 1260715405; vtiRuuFrHfjEdo > 0; vtiRuuFrHfjEdo--) {
        ExwibIjuKB = ! qbYkLcNfluG;
    }

    for (int oXNzzuJf = 1875457926; oXNzzuJf > 0; oXNzzuJf--) {
        iQoULtpmHAL += tgLvNOUOIrvo;
    }

    for (int NKzBUwsbRceB = 27745347; NKzBUwsbRceB > 0; NKzBUwsbRceB--) {
        LRoGAgMYviyes = YzQBXitu;
    }

    return tgLvNOUOIrvo;
}

int Iujrpp::kdHPLtKBkQRlgBxI(string pqPbxNFmZQVCof)
{
    int dtPFsGYkwTSJ = 647554719;
    int lPqRuVBY = -716474483;
    double LeHDLq = 371967.2930664532;
    string hYamcEffRRhFbTT = string("qLWdoslwBfZdfwgdzLZtwScqkBYawepIYyjYtZjZyMAwOHuYGHaRhzkMDYKaOoDyQXsCDuqYuGMErdzLznCozdqrVEyrSVJnczifcHScLIjvbPDSYkpxhzvNAwLTxb");
    bool aUXRUw = true;
    double JReMiE = -894575.3070394292;
    string qNlzsuqyx = string("MiJVMMzaaHsvYbamxqQyPieNqKAZrddapHLGwjQGkMsJWZPiLSOemplstqxDrspIVgmXIPjFGrkrMrZrhroCPQJuSDqRLGZmjSXGHrYTwZBUFBLoLfGAdmRNUeCFbFPyHPTtAkwdkfcxxgDPEuGS");
    double FawinMP = 29148.121716479236;
    string NTyknYPEfzZbld = string("x");
    double LuxJibdbYqC = -57801.950368863254;

    for (int uYvHnO = 997470750; uYvHnO > 0; uYvHnO--) {
        continue;
    }

    if (hYamcEffRRhFbTT == string("MiJVMMzaaHsvYbamxqQyPieNqKAZrddapHLGwjQGkMsJWZPiLSOemplstqxDrspIVgmXIPjFGrkrMrZrhroCPQJuSDqRLGZmjSXGHrYTwZBUFBLoLfGAdmRNUeCFbFPyHPTtAkwdkfcxxgDPEuGS")) {
        for (int GAlAkadTu = 1145996368; GAlAkadTu > 0; GAlAkadTu--) {
            continue;
        }
    }

    for (int VVhmmENPwS = 1898354822; VVhmmENPwS > 0; VVhmmENPwS--) {
        pqPbxNFmZQVCof += qNlzsuqyx;
    }

    return lPqRuVBY;
}

void Iujrpp::RnzNevr()
{
    string QrTWqJBspEfifyR = string("AhqgieBdZpqllkIsPNTHYMhEPIIeZaqrIFoMDpBwvtlXUPQYUyxRXwAxUnEKCVBpdDKXrgMDgiyUhVYATWadVNLjODxAFiPlUClJAtsfBZCTABnjDxgvAuHRmknWSmPemOqlvEqnESTPNdrwSdlJhPterLSVEWnmNzFSjJCAGWtGdkGUGNizgESMIDXMPjNORDpAv");
    double jcXxwWUvGqBPn = 899181.5024446112;

    for (int Trinm = 532473675; Trinm > 0; Trinm--) {
        QrTWqJBspEfifyR += QrTWqJBspEfifyR;
    }

    if (QrTWqJBspEfifyR != string("AhqgieBdZpqllkIsPNTHYMhEPIIeZaqrIFoMDpBwvtlXUPQYUyxRXwAxUnEKCVBpdDKXrgMDgiyUhVYATWadVNLjODxAFiPlUClJAtsfBZCTABnjDxgvAuHRmknWSmPemOqlvEqnESTPNdrwSdlJhPterLSVEWnmNzFSjJCAGWtGdkGUGNizgESMIDXMPjNORDpAv")) {
        for (int DbBjV = 387036218; DbBjV > 0; DbBjV--) {
            QrTWqJBspEfifyR = QrTWqJBspEfifyR;
            QrTWqJBspEfifyR = QrTWqJBspEfifyR;
            QrTWqJBspEfifyR += QrTWqJBspEfifyR;
        }
    }
}

double Iujrpp::yUckqVucLeIRPzh(int hLSbjsxHUGgEvTO)
{
    bool xlTgLcihrhBA = true;
    bool xipTbIVaSJTR = false;
    string JoAEYwE = string("ugfVnChACVsPnbbuZuJhbBDpaUPRRelGOsWYqzLKIHCsbDAgGMliOiLrFiNmfPxoKUMYQiChqyALRnDdtmLImzcAKQpGOIgPTECfRlxKFQyplsoZTBtdKuSOQzV");
    double vKZpBIiMusBOmh = 385498.4785062544;

    return vKZpBIiMusBOmh;
}

string Iujrpp::afUkLSdSSTPuCOQh()
{
    int ApRfvadtrbv = -290654737;
    string bUswzOWOeNHXr = string("OAUvCXupYLukLyuptVztJuEYiFYDkNbqNcrZWXjDphPdjBeHdCVdijbfisWCOIWnLDccTqoKeWhWwtxLNEncdlgAsywwQSDRVaHZtEouavDRJxlTzovFsCKgrouYArhwHTHneLLIApaFNcNqxOSYzmxcXgWXMWxxYUSjquyxt");
    bool aKYESeIjShT = true;
    bool PbQEiJ = false;
    string OUxii = string("aLJRYMpqEEZYyYsujaYRrVHlcCHvMTosBhoxLfuWBCvSJZWebsrNoZTQhfwEtOoztquwKSEXAlSaiUXMZcUvoYFSZgGudoGsiDQDGUXAytVMhonPTvHdmIRZjYKZnXylmRpEYTdOp");
    double HVnBFkpotIeA = -922479.7906810093;
    double iiyGxXbzKdHPm = -641959.8028273708;
    string saQOzquS = string("ovLYqtlqAUzmTgHnvAMJNCDOF");
    double sHVotVpuy = 317193.34093359835;
    int dqjyfQC = 1451917322;

    for (int GLBOTGIzicnpEYr = 1988651555; GLBOTGIzicnpEYr > 0; GLBOTGIzicnpEYr--) {
        ApRfvadtrbv += dqjyfQC;
        bUswzOWOeNHXr = saQOzquS;
    }

    if (bUswzOWOeNHXr > string("OAUvCXupYLukLyuptVztJuEYiFYDkNbqNcrZWXjDphPdjBeHdCVdijbfisWCOIWnLDccTqoKeWhWwtxLNEncdlgAsywwQSDRVaHZtEouavDRJxlTzovFsCKgrouYArhwHTHneLLIApaFNcNqxOSYzmxcXgWXMWxxYUSjquyxt")) {
        for (int yRvsSJTuTjr = 241200771; yRvsSJTuTjr > 0; yRvsSJTuTjr--) {
            OUxii = bUswzOWOeNHXr;
            saQOzquS += OUxii;
            OUxii += bUswzOWOeNHXr;
            saQOzquS += bUswzOWOeNHXr;
        }
    }

    if (sHVotVpuy <= -641959.8028273708) {
        for (int AXnvNwXIxJZQs = 667157025; AXnvNwXIxJZQs > 0; AXnvNwXIxJZQs--) {
            sHVotVpuy *= sHVotVpuy;
            saQOzquS = OUxii;
        }
    }

    for (int BRhsnPkjVrxl = 1070439026; BRhsnPkjVrxl > 0; BRhsnPkjVrxl--) {
        dqjyfQC += dqjyfQC;
    }

    return saQOzquS;
}

double Iujrpp::kCePZbteXSqg(string ZZHrjmXGlDHVfZ, int XlAHGsB)
{
    bool sJPNF = true;
    double HFoqEZK = 765610.1490062725;
    bool Wrewc = false;
    bool qaNPXQKoo = false;
    int RvNJuF = 1003450547;
    double GkMoVwCCiMdlkzLe = 446811.85395190376;
    bool dkyepqvdEqky = false;
    bool JEqaZlhVRhvptZ = false;
    double ibjwuwEnNdXLXR = -280226.1373589954;

    return ibjwuwEnNdXLXR;
}

void Iujrpp::fUEmEwFgSdk(double IJMbkKHmyexuStCk, int WQRsv)
{
    string INMvAcRvQkpeEUyp = string("fKwFloxNXaOrYtjtGdkHhnNXVUTIYPMNciNrnOJmWbjxvXVmGaDOIwXDSbsFSzmMBzFXsECdmkydFVCQbXxzbKWhUpgGeoiajwsRhMahdJsiUAmuXvKSPptMnEOIAIsJXWuhOfHNxUMYgNNPXqukgcgCTjieeMWkPqOlIRSCxahOQzMhwGghRzVwNcMwsxbkdCiLSisHZgHtsRWiTGhtLbNvq");
    string myZKzE = string("HtzisJnJ");
    double NoJSrHzfZmvHSyo = -408016.10293694085;

    for (int JehWOyXRBaumBl = 1110709902; JehWOyXRBaumBl > 0; JehWOyXRBaumBl--) {
        INMvAcRvQkpeEUyp += myZKzE;
        IJMbkKHmyexuStCk *= NoJSrHzfZmvHSyo;
    }

    for (int cwrbKRO = 1706649280; cwrbKRO > 0; cwrbKRO--) {
        IJMbkKHmyexuStCk *= NoJSrHzfZmvHSyo;
        INMvAcRvQkpeEUyp += myZKzE;
    }

    for (int DwhRyN = 1541667706; DwhRyN > 0; DwhRyN--) {
        myZKzE = INMvAcRvQkpeEUyp;
        IJMbkKHmyexuStCk /= IJMbkKHmyexuStCk;
    }

    for (int CJTVLSaXifFY = 931880934; CJTVLSaXifFY > 0; CJTVLSaXifFY--) {
        INMvAcRvQkpeEUyp = myZKzE;
        NoJSrHzfZmvHSyo = NoJSrHzfZmvHSyo;
    }

    for (int kCQlwxAjIX = 1513781709; kCQlwxAjIX > 0; kCQlwxAjIX--) {
        continue;
    }

    if (NoJSrHzfZmvHSyo <= -408016.10293694085) {
        for (int bBzbfReLtgsR = 631056972; bBzbfReLtgsR > 0; bBzbfReLtgsR--) {
            continue;
        }
    }
}

bool Iujrpp::uiBeKxsmK(double WSQbR, string jgRLABjGHxbCAk, double WMxFir, string JkeTpkZbExdehMZ, double NObwoEhG)
{
    string HQznbivBhpHCRgE = string("EbZjryEEGIeiIRqMePHiJpoxaRCCMAAhAhcWwOVsttnFdUXzQeAJYmgPANqLdowLmmjbKSZluSWTzTVTmdFPfZvYSFCrmdNAHFqEzaNwmxMWsWyNvTMphAgwGVFWDIayZIQBZWZSxnGHSVuJzDkjRmqaARLnxDfsdPHkpuPeFnBnOtJXvyMIzwTxTSg");
    string xZAmjFwatP = string("QUjBqHSggGyIqRhaiM");
    int lHYfiRI = 831976087;
    double JPrODjIqwBykwvmq = -74249.85900106875;

    for (int RVbxAFlqmkEnVa = 1574647034; RVbxAFlqmkEnVa > 0; RVbxAFlqmkEnVa--) {
        jgRLABjGHxbCAk += xZAmjFwatP;
        NObwoEhG /= NObwoEhG;
        JPrODjIqwBykwvmq = JPrODjIqwBykwvmq;
    }

    if (WMxFir > -201080.70026775752) {
        for (int gYNHHTho = 318140092; gYNHHTho > 0; gYNHHTho--) {
            xZAmjFwatP = jgRLABjGHxbCAk;
            WSQbR *= NObwoEhG;
            NObwoEhG /= WSQbR;
            HQznbivBhpHCRgE += jgRLABjGHxbCAk;
            xZAmjFwatP = HQznbivBhpHCRgE;
        }
    }

    return false;
}

double Iujrpp::dxnNxmmZV(int nKkfVAgJIDtR, int LstHUNfUfijI, int ycPPRpjmbpFTedzG, double sxMuvRpQKNaUtfBj, string TSVyH)
{
    double RHnauka = 572793.9577899746;
    bool YTVRRB = false;
    double nfUOy = 820890.7744958256;
    bool QcztkumqCk = true;
    string UcCbMK = string("AfidRLJebrjCIjGMBuSMIhRpjgsvylfsXTIjudRKSCcIPhjvUGTNChbmKQRtXkUvvOssVDKubmOOFzvQuTxwNvyQjS");
    string omNJPIT = string("hzTltteBTRFwNxEHGAOAfmmjDbqMtQnFfZjGEffnJzCBBMyjkIleWcOgLDeWQXrsisFgZcoXtDYOOjMRFOWRWRlGdkkfywUQsVYBRHKgZsFPjFDESTaPouCKFiXxkHwFubjkWzYUtILXoaIQNWAjcxwPtoBnHsrIlxmfhRGuyCSPGQWUXSaxpTtbhbxXOxcIZtLanmVVdhOAzDsPPqnuKyyjITQYLmJNMcuQRmyJkoNlKZKqcywgtXewozuGM");

    if (nKkfVAgJIDtR == 450134209) {
        for (int oxXeUiji = 1621304286; oxXeUiji > 0; oxXeUiji--) {
            continue;
        }
    }

    for (int aAgod = 1116870804; aAgod > 0; aAgod--) {
        RHnauka /= RHnauka;
        nKkfVAgJIDtR -= ycPPRpjmbpFTedzG;
    }

    if (TSVyH == string("KyFIDwlQCJPLZJWcTNbcKqvLfmCZ")) {
        for (int pSbdrXhKaO = 1456212355; pSbdrXhKaO > 0; pSbdrXhKaO--) {
            LstHUNfUfijI /= nKkfVAgJIDtR;
            RHnauka /= RHnauka;
        }
    }

    if (omNJPIT >= string("KyFIDwlQCJPLZJWcTNbcKqvLfmCZ")) {
        for (int KuvxNQORrb = 380645859; KuvxNQORrb > 0; KuvxNQORrb--) {
            omNJPIT = omNJPIT;
            sxMuvRpQKNaUtfBj += RHnauka;
            TSVyH = omNJPIT;
        }
    }

    for (int HWMvOYJqy = 181194259; HWMvOYJqy > 0; HWMvOYJqy--) {
        nKkfVAgJIDtR /= ycPPRpjmbpFTedzG;
    }

    return nfUOy;
}

void Iujrpp::ZwupTY(bool sEhAfPeToOWnw, double FoXgNBKQZtyUo, string MCKTSpMvJpiT, string LbFAiCigFJS, bool JlmmSY)
{
    bool SFpcGIH = true;
    string vaahAfNISTb = string("SVSwiQstAOZsEmQUmZVWuYVWTFcOrwSmlCzXwPEduIuorgOjWxwhRmXfldZtRcufThssHdAJCNnOJDIxNZpZhUPeFFYiAtGHiDbrCRvsxLMYxkaoUHUipgDVTOEqiBrEBPDBOhpeFeSjbpnSN");
    double pvZgbcPiU = 1022243.8144503834;
    int klcicrrcS = -1320728589;
    string ESxVicV = string("kfYzJQjxivxuogoULMlAAPHKxemdZrTEpIrKkXboeYhNnqBKdkNJcHEmtGUpiDujWJlGRFvDskLtAgdCzFRgngnYcvNBGdIEKHtGSpGYiSnWfczwvaGAPyIqTcRJGdMhlFrtWqhkKlGqsWNjvzVqFDVpAbMkhrDHffRJukSfDXYDlmehNAqrHREMpXSCSKIZqtnIHcgqETNLwwmaNrzGvjXLAqwasOAlDtLItyxAcDnGNVQJx");

    if (ESxVicV <= string("SVSwiQstAOZsEmQUmZVWuYVWTFcOrwSmlCzXwPEduIuorgOjWxwhRmXfldZtRcufThssHdAJCNnOJDIxNZpZhUPeFFYiAtGHiDbrCRvsxLMYxkaoUHUipgDVTOEqiBrEBPDBOhpeFeSjbpnSN")) {
        for (int cpfxQ = 1163514072; cpfxQ > 0; cpfxQ--) {
            JlmmSY = ! SFpcGIH;
            SFpcGIH = SFpcGIH;
        }
    }

    if (sEhAfPeToOWnw != true) {
        for (int TsGRXEDfhDDp = 423634553; TsGRXEDfhDDp > 0; TsGRXEDfhDDp--) {
            klcicrrcS += klcicrrcS;
            FoXgNBKQZtyUo = pvZgbcPiU;
            LbFAiCigFJS += MCKTSpMvJpiT;
            sEhAfPeToOWnw = sEhAfPeToOWnw;
            vaahAfNISTb += LbFAiCigFJS;
            SFpcGIH = SFpcGIH;
        }
    }
}

Iujrpp::Iujrpp()
{
    this->KVVUAvDxzLHE(-689706.9928618429);
    this->VfPcdCQbyHWc(-759002749, true);
    this->RgqHlFuASaaDVbys(string("KflVttHzqKneQwJPLNevFbGtqfjwIakZTxpSBAypJxFo"), 70769695);
    this->kdHPLtKBkQRlgBxI(string("xeDhNcTyTczOsjFwybwVtNigczkiGOLrxFkLplumvLzuDAJtoWTEATAlopLJKBsjBzGSEypKoGRnUukHGIJNrddHhQtxIwsehIFXlqxJGXpGNpJsJTGsYDhFWfmNbfObuvLCNOaiqFLZuPzZoioQLsfxeOxzLBeVefLzsZstpxIzayuGsGWoYrMWcRBeGCjhQdzZduhHftUAFIPjUuAwwESsejqHtksTLUTi"));
    this->RnzNevr();
    this->yUckqVucLeIRPzh(-256948890);
    this->afUkLSdSSTPuCOQh();
    this->kCePZbteXSqg(string("MqHnGJjaBftguNLlaUJNBiTeAgzAqaaPPYWnVCnDexFaqSVJYiOaGFnCNZBMOFmkNZAGwUnRxzVPInxiqXHsQHpdantIsxgOBaymDldrOcRnxTMTEePHhWleXmjUZnbKhYkGQftUcTRUhrzFoFXx"), -1356173068);
    this->fUEmEwFgSdk(255348.86800879426, 1782864019);
    this->uiBeKxsmK(513194.0410903246, string("aElKCSqJorMaZDduVxkYsdVEqFIZwIxjHPBmdAoCGbkyoaIDlDluTwJEsBYWqwPfiQYdDsAlMdfLnwxdzzyOkHOGvskQrMsbdViCsSrhvvFQB"), -679826.8866733904, string("ZvpHymfIJVKujRPWplRcCnCnMgHjkIDSuigjepEdLvoGezIfDKxAAQifJOXzIwXVlCFjHJdHJhnsMozghrWkKXrSJXKLZaAibnNhyTrzCbjZfDGWoxvLmVEYWFKfUjZHbCEBlhAAGGHSzagJcjfHOBIZynVdRryNVHdcBHClfFqbbALBcZHWqCtvfmLqhYyGaqPDdAbW"), -201080.70026775752);
    this->dxnNxmmZV(450134209, 1122637098, -449319575, 731785.0936937123, string("KyFIDwlQCJPLZJWcTNbcKqvLfmCZ"));
    this->ZwupTY(false, 965821.753000709, string("INQJBqkFoMdkEWYLZRKuyUAgRqzeoDwOcXemaogJKpauVhePkCncxKMnqwrXmQZDiZXtgcAalRHalYyEhCGutcgqIKTsVWQtAercjcBQNxqkbivnoTptjVJPvZsvnXwpAIEWyohVJNLcT"), string("eSqCzlDpjhLJGhgTxGYByHDNxlTIdaQWVhbgqPXbnfXucCuxjVfDOkgYMUpVsDSTICtXQwvtqCbeCzvsxtwpyXwiIvHxJNdjbKJvNCaHEoRmrGsjFMPOfMzQJzZnLZQPPVGTGTCRHQyKUqkDogwZEmbFNDdoKKioEAQtoNsjBtmyIaEKUvewFpcXxzdkKfCcZEbG"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AFSztqmh
{
public:
    int nvmQLrPu;

    AFSztqmh();
    double EfVjBHcnxdemphdH(string dopXrI, bool OflQeZa);
    void zjoFUzfV(int gBpPddfoji, double bxAmYTdO);
    int zToxW(double oMTUmJYWgA, bool lDaNjSuTX, double zLXzdXfYllFonYk, bool goiNnNbFyUt, int YIdFPcARZjn);
protected:
    bool dUsoughrefg;
    bool XBqhBYGAs;
    string lAUyuDWMaSPj;
    int hNiAZxzomrsjCRgO;

    int OKOIDooFwRA(int GmNwNtLcyVOCowpc, bool JfkVRFTHCviK);
    double eBnDbvavfufsqD(double aTiSdtvQ);
    void TJVsQqdFEkId(bool gyrimLx, int oehcXmXnvGYKd, double IixDJ, int QopxtoeWiXP, int LMlSpoidrtwssUvO);
private:
    string rOZEdNLHbJnG;
    bool PAPwtLYEINBmT;
    int MRhiUhZ;
    bool nwiROUqKUqp;

    bool AvagKMz(int JxMhmNxWI, double SxBFyjzjCbWrygQj, bool YOdVkhzDlRbf, double cusNdmfRHM, double tSZhD);
    bool OBgsGYRCKc(int GQSJgxGvKnJ, int eKxBO);
    bool QMkNZUSXeXjEXgfB(string eKmrfkmtwQ, bool RaimGmI, int WGMEK, bool QSJhn, bool XPdHppgl);
};

double AFSztqmh::EfVjBHcnxdemphdH(string dopXrI, bool OflQeZa)
{
    double ehgNLzCSF = -898503.9019260232;
    bool eIqJekry = false;
    double EMcEACbpYOi = 680609.7519758644;

    if (eIqJekry == false) {
        for (int XtgYB = 669410572; XtgYB > 0; XtgYB--) {
            OflQeZa = ! OflQeZa;
            ehgNLzCSF = EMcEACbpYOi;
            EMcEACbpYOi -= ehgNLzCSF;
        }
    }

    return EMcEACbpYOi;
}

void AFSztqmh::zjoFUzfV(int gBpPddfoji, double bxAmYTdO)
{
    string jOkwaXkWeieNrHW = string("zBwxzSkfsqKOEvoFLRTJrPciCIRSRIbprxXhgomDkWbVxDIOtyNQQIKCPQgLXkpSWyErzzVjxThNriBqXeOXuaqCZzLvGwKuRKiMcTtyKvAGREKXHSKdTcrcTUFsoxOzVznNcAKpEXDuGkvZuennjdpdzuGMZZ");
    string oJVFWjpPsnxgvnX = string("ilsdkzWaJNYeMcyWRzgyACTyumSDzCuEfjdt");
    int ZXdUB = -1945280496;
    double mcnflqgrNnA = -616337.123299164;
    double qaNuhFBPLVfl = 567256.5854833459;

    for (int hjvyKYmHakeJIpz = 1111838423; hjvyKYmHakeJIpz > 0; hjvyKYmHakeJIpz--) {
        continue;
    }

    if (qaNuhFBPLVfl != -616337.123299164) {
        for (int CucPUwtZdZzi = 1412922804; CucPUwtZdZzi > 0; CucPUwtZdZzi--) {
            continue;
        }
    }

    for (int utWaMuvdEJ = 1548233971; utWaMuvdEJ > 0; utWaMuvdEJ--) {
        bxAmYTdO = qaNuhFBPLVfl;
    }

    for (int iUOUEqXMIaB = 818784928; iUOUEqXMIaB > 0; iUOUEqXMIaB--) {
        continue;
    }

    if (bxAmYTdO >= -573606.8368164515) {
        for (int ShErv = 1736305587; ShErv > 0; ShErv--) {
            oJVFWjpPsnxgvnX += jOkwaXkWeieNrHW;
            ZXdUB = gBpPddfoji;
        }
    }

    if (mcnflqgrNnA < -573606.8368164515) {
        for (int LUlOk = 696865394; LUlOk > 0; LUlOk--) {
            bxAmYTdO += bxAmYTdO;
            gBpPddfoji = gBpPddfoji;
            qaNuhFBPLVfl = bxAmYTdO;
            qaNuhFBPLVfl = qaNuhFBPLVfl;
        }
    }
}

int AFSztqmh::zToxW(double oMTUmJYWgA, bool lDaNjSuTX, double zLXzdXfYllFonYk, bool goiNnNbFyUt, int YIdFPcARZjn)
{
    string itHfdHVkppWuGYZO = string("VzmgDEDqNvRnXrZNhzogMRnGgeCAxBcrqMBeMgyoNLTLbMcauAswTdAUvZoYCXVhfULMZxhRVHhlAqFWUAYCJuRHKSUWeqChgnhIlOqDDbxgUtDiJpmGiymipTlHvCzsRITvJbCAjUCVbLuGQzmotBoMbfhzjHasVHvstYGQckWBICWFIOzXcxTZV");
    double YhfqfEcOcKZhYl = 794033.2609982267;
    bool EGpIE = false;
    int Emetat = -1952860356;
    double HznKKK = -981252.1245647168;
    int DWlEXQl = 710120049;

    for (int JlqfcjuRKvESmdP = 2056904700; JlqfcjuRKvESmdP > 0; JlqfcjuRKvESmdP--) {
        goiNnNbFyUt = ! goiNnNbFyUt;
    }

    return DWlEXQl;
}

int AFSztqmh::OKOIDooFwRA(int GmNwNtLcyVOCowpc, bool JfkVRFTHCviK)
{
    int pYmuGZd = 2108463684;
    bool GwpHKXtj = true;

    if (GwpHKXtj != true) {
        for (int WCnZJvupCEN = 2110113565; WCnZJvupCEN > 0; WCnZJvupCEN--) {
            continue;
        }
    }

    for (int DOzlYC = 1482309095; DOzlYC > 0; DOzlYC--) {
        GwpHKXtj = JfkVRFTHCviK;
        GwpHKXtj = ! GwpHKXtj;
        GwpHKXtj = ! GwpHKXtj;
        GmNwNtLcyVOCowpc *= GmNwNtLcyVOCowpc;
        pYmuGZd += GmNwNtLcyVOCowpc;
        JfkVRFTHCviK = ! GwpHKXtj;
        JfkVRFTHCviK = JfkVRFTHCviK;
        JfkVRFTHCviK = ! GwpHKXtj;
    }

    for (int OmMQmD = 2040762866; OmMQmD > 0; OmMQmD--) {
        GmNwNtLcyVOCowpc = pYmuGZd;
        GwpHKXtj = ! JfkVRFTHCviK;
        pYmuGZd *= GmNwNtLcyVOCowpc;
        GwpHKXtj = ! JfkVRFTHCviK;
    }

    for (int OcKPiHaw = 567177723; OcKPiHaw > 0; OcKPiHaw--) {
        GwpHKXtj = ! GwpHKXtj;
    }

    return pYmuGZd;
}

double AFSztqmh::eBnDbvavfufsqD(double aTiSdtvQ)
{
    bool VomVYyvJnLERc = false;
    double XRLEsBEYIBGA = 709604.4998377524;
    string kOCioieVrmQtt = string("JmdROrejDcZKbEmUiXKAzrarDECcCUQzVlqoLdsIzfRmltQUcpNmKlOKDnjfeNiqxDeKDuPVutLBIztrmLNnPLAbuKxUejIDEAMzBqoMyVIAfhJriIbfXxPhkVmnqQQCwObIZrgyxsmiGaganpxdCgBIOOARVa");
    double fVRAFZqd = 307134.1817115457;
    int TPGShvzjXEl = -757087278;
    string XoGzhxkEslI = string("EJrRwFckzQTmbsGuhgCAudCuFNfdMQNvfaxnvXcToHgHUDLkoblzbsnK");

    if (kOCioieVrmQtt == string("JmdROrejDcZKbEmUiXKAzrarDECcCUQzVlqoLdsIzfRmltQUcpNmKlOKDnjfeNiqxDeKDuPVutLBIztrmLNnPLAbuKxUejIDEAMzBqoMyVIAfhJriIbfXxPhkVmnqQQCwObIZrgyxsmiGaganpxdCgBIOOARVa")) {
        for (int FgsRLPQbQKDVHX = 1879330059; FgsRLPQbQKDVHX > 0; FgsRLPQbQKDVHX--) {
            continue;
        }
    }

    for (int lCUCTWxVkVOiD = 116591972; lCUCTWxVkVOiD > 0; lCUCTWxVkVOiD--) {
        fVRAFZqd -= aTiSdtvQ;
    }

    if (VomVYyvJnLERc == false) {
        for (int LUiqglkwr = 1705590386; LUiqglkwr > 0; LUiqglkwr--) {
            kOCioieVrmQtt = XoGzhxkEslI;
        }
    }

    for (int xdrQBr = 252601675; xdrQBr > 0; xdrQBr--) {
        XRLEsBEYIBGA /= aTiSdtvQ;
        aTiSdtvQ -= fVRAFZqd;
        XoGzhxkEslI = XoGzhxkEslI;
        fVRAFZqd *= XRLEsBEYIBGA;
        aTiSdtvQ *= aTiSdtvQ;
    }

    return fVRAFZqd;
}

void AFSztqmh::TJVsQqdFEkId(bool gyrimLx, int oehcXmXnvGYKd, double IixDJ, int QopxtoeWiXP, int LMlSpoidrtwssUvO)
{
    int krkPkfowzv = 109402611;
    string ahyRNq = string("MSuBukfdsiyQqPLwVOPpIpFqnwUZz");

    if (QopxtoeWiXP >= 2141326094) {
        for (int kAEnbclOF = 2072093580; kAEnbclOF > 0; kAEnbclOF--) {
            gyrimLx = ! gyrimLx;
            oehcXmXnvGYKd = LMlSpoidrtwssUvO;
        }
    }

    for (int dkozcAEwfFmauc = 1807201897; dkozcAEwfFmauc > 0; dkozcAEwfFmauc--) {
        QopxtoeWiXP /= krkPkfowzv;
        QopxtoeWiXP = QopxtoeWiXP;
        LMlSpoidrtwssUvO /= LMlSpoidrtwssUvO;
        krkPkfowzv = LMlSpoidrtwssUvO;
    }

    for (int CBIqTCGW = 1910328770; CBIqTCGW > 0; CBIqTCGW--) {
        QopxtoeWiXP -= oehcXmXnvGYKd;
        krkPkfowzv /= oehcXmXnvGYKd;
    }

    for (int TAxOtjHlFNlgROB = 1324309447; TAxOtjHlFNlgROB > 0; TAxOtjHlFNlgROB--) {
        continue;
    }

    for (int MuHDo = 1554567367; MuHDo > 0; MuHDo--) {
        krkPkfowzv = QopxtoeWiXP;
        QopxtoeWiXP -= oehcXmXnvGYKd;
    }

    if (QopxtoeWiXP >= 109402611) {
        for (int lYAqc = 1212778093; lYAqc > 0; lYAqc--) {
            krkPkfowzv *= LMlSpoidrtwssUvO;
            krkPkfowzv -= QopxtoeWiXP;
            LMlSpoidrtwssUvO = QopxtoeWiXP;
            LMlSpoidrtwssUvO = oehcXmXnvGYKd;
        }
    }

    for (int FfFGS = 1534479653; FfFGS > 0; FfFGS--) {
        oehcXmXnvGYKd *= krkPkfowzv;
    }
}

bool AFSztqmh::AvagKMz(int JxMhmNxWI, double SxBFyjzjCbWrygQj, bool YOdVkhzDlRbf, double cusNdmfRHM, double tSZhD)
{
    double QLVkIBOKAEgtVj = 132031.11462682963;
    double YptkCLXmNhlfZVA = 692637.6623408803;
    double gxobA = -574249.9420525904;

    if (gxobA != 647881.9569979559) {
        for (int ibbrcmUPORklpckl = 1166789015; ibbrcmUPORklpckl > 0; ibbrcmUPORklpckl--) {
            tSZhD += YptkCLXmNhlfZVA;
            QLVkIBOKAEgtVj = tSZhD;
            gxobA *= SxBFyjzjCbWrygQj;
            SxBFyjzjCbWrygQj /= QLVkIBOKAEgtVj;
            YptkCLXmNhlfZVA *= tSZhD;
        }
    }

    return YOdVkhzDlRbf;
}

bool AFSztqmh::OBgsGYRCKc(int GQSJgxGvKnJ, int eKxBO)
{
    double wYInQXMUK = -581927.8703909597;
    double ryZwUXUzcsppwTVL = 992249.5464218403;
    int nyBQnHxaCyeR = -725621147;
    int YNyiLcXOxWVGMuqz = 1290049058;
    string hQBhM = string("bnBllilExCVDITOYgBRFMzROxQzXlUPzlJRVXNamOCtQFsxwIRYvsqQtlVxbUuMuymlxSPhpDBzfJtBPmdJsnECoTJtMBMsLhYyXNhuCpMiAJvVVgWQECkwnlocdfmOHWIXupUwmWcmssFhCKOiLWjtZJgzNsbAWFvHlwtRqnMUVserziDMzmeIqVbbMpshoPZVrTLMzJpfwhXBudXhISpDYqXOFGOIRQRvZCRbpayCfufR");

    for (int zNmbe = 779267986; zNmbe > 0; zNmbe--) {
        eKxBO /= YNyiLcXOxWVGMuqz;
    }

    for (int UniveglKn = 1103217464; UniveglKn > 0; UniveglKn--) {
        wYInQXMUK -= ryZwUXUzcsppwTVL;
        GQSJgxGvKnJ -= eKxBO;
        wYInQXMUK = ryZwUXUzcsppwTVL;
        nyBQnHxaCyeR += eKxBO;
    }

    for (int ZZnUmsuPt = 982213112; ZZnUmsuPt > 0; ZZnUmsuPt--) {
        YNyiLcXOxWVGMuqz += nyBQnHxaCyeR;
    }

    for (int juJbtVd = 556874284; juJbtVd > 0; juJbtVd--) {
        nyBQnHxaCyeR /= YNyiLcXOxWVGMuqz;
        eKxBO -= nyBQnHxaCyeR;
        eKxBO += nyBQnHxaCyeR;
    }

    return false;
}

bool AFSztqmh::QMkNZUSXeXjEXgfB(string eKmrfkmtwQ, bool RaimGmI, int WGMEK, bool QSJhn, bool XPdHppgl)
{
    string kPUHnJbMYkKBWsr = string("JOiALcwxjiIKicfeeqxWaLS");
    int wgHiMVLzuxwWywlG = 381305575;
    bool MYbfwPUQ = false;
    bool FwSpLF = false;
    bool zqEGNAw = true;
    double anubdPznMtmniPD = -573294.9795763227;
    double eWzXtZMDaidlFY = -962651.2808772683;
    string gXBVfiYZkBb = string("ledURCxKzXIoWffWxkBwNkrHBZFOkbxoQQGJjxpUtoFEjsZuDiiodzcnBYd");

    return zqEGNAw;
}

AFSztqmh::AFSztqmh()
{
    this->EfVjBHcnxdemphdH(string("mJaenzhPOxRXdvhRTlxDTnCxHmsIjdXHDEtYwVxtCGswuDadxccHBOAFWlrriusdOcCbbEELPPoYOoZyZfvlIyaEqJVLwOtaHAsfSCFiUVZvhqGVlEEIDSFaqsALDVnMYaBJmZJW"), false);
    this->zjoFUzfV(425349502, -573606.8368164515);
    this->zToxW(392836.7873877445, true, -278580.6850524467, false, -552089304);
    this->OKOIDooFwRA(2026641563, true);
    this->eBnDbvavfufsqD(-383125.0601476047);
    this->TJVsQqdFEkId(false, 146705840, -725594.4790987938, 2141326094, 2144308605);
    this->AvagKMz(324362263, -771318.0014233092, true, 647881.9569979559, -242367.22849896597);
    this->OBgsGYRCKc(-1093064451, 81951518);
    this->QMkNZUSXeXjEXgfB(string("gOubMQSogzTBkPYIqjuxRAlyHxOGrEBQpmqPJIsIOfCXYbdJyKYUbwidpDMHxdIALYgAEZFOsRuSzKdb"), true, -212116603, true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xJEVga
{
public:
    bool yHqMqdteb;
    double JVRKAKLbB;
    bool bkuCAbtt;
    bool LIhRcLU;
    bool eTVKQwIeG;
    string WWLeGq;

    xJEVga();
protected:
    bool hOPrDF;
    string DGJGtBfBdXTqo;
    string OfOOImMPneULYB;
    int MNdVpF;
    double xNuCsZ;

    int VJucDp(double hyZYZZAnLYkxyD, double rruCKTKfufh, bool NxdmZxMFwmE);
    int zPaoNo();
    bool rBJEfjhAxwFi(double GaxRrTwXBultw, double fTGPGgrjDet, double pYNLUYkpmNYZb, double mlrhOnerPbz, bool YdLTpJkIpvZou);
private:
    int JxFRtLlvxLMDghWl;
    int tHikPQC;

    void aUNMRfyjkGhM(string uoSICLnrLTgX, bool QfNamjGbpOFRRvn, int NYyVaILn, bool xreJtKkhqrPR, bool JVJmQUamkJ);
    void MZWwrOVhuh();
    void EUOFX(int nzlrNJdONbT);
    void wTIWjCjpnJ();
    string JgtpAzrNSvMIwkw(string DEMxWngmo, int aBBukHLpBMWSQ, int akCiMU, double qubbjbLGsimsM);
    void jqTxDVsFW(int MAweGGDjSJbQTn, double zWBRL);
    int XesYksQfKSIsTyMY(double UtYeTgGbjmqeOO);
};

int xJEVga::VJucDp(double hyZYZZAnLYkxyD, double rruCKTKfufh, bool NxdmZxMFwmE)
{
    double qLzEMzUQRArBSA = -226166.29100567338;
    int jdGmotSy = -2089236769;

    for (int uCflLZjOtCdG = 1745867181; uCflLZjOtCdG > 0; uCflLZjOtCdG--) {
        qLzEMzUQRArBSA += qLzEMzUQRArBSA;
        rruCKTKfufh = hyZYZZAnLYkxyD;
        rruCKTKfufh = hyZYZZAnLYkxyD;
        qLzEMzUQRArBSA = rruCKTKfufh;
        qLzEMzUQRArBSA /= qLzEMzUQRArBSA;
    }

    for (int thMWGZIXb = 85406149; thMWGZIXb > 0; thMWGZIXb--) {
        qLzEMzUQRArBSA /= hyZYZZAnLYkxyD;
    }

    for (int Pagxmyh = 394209657; Pagxmyh > 0; Pagxmyh--) {
        hyZYZZAnLYkxyD /= qLzEMzUQRArBSA;
    }

    return jdGmotSy;
}

int xJEVga::zPaoNo()
{
    string eiYOC = string("AfogDXXxaAATwxgyqFjwFawKUxwctLzMRqWoiCPeZksupuNVNDwmLpeJuppqPnjHfZCnjASgvoZCUxjCGRyaepfCPAskFagSIioSUyNtWeiaFDMJkfxUOrhXPhryluxeKooNJhcyujntSYIJPuuogmmKAaiOPhZkYuhCVwHvsTSoLLKQFaHRRkdEtuLLEsrmveUkvnLrSTpDnwYVxtMUZWnknHZnRsaJlszbKrDrmnmAWlvnXzhIxQkAbcA");
    int RiBewEnXQfTENjK = 547556516;

    if (eiYOC > string("AfogDXXxaAATwxgyqFjwFawKUxwctLzMRqWoiCPeZksupuNVNDwmLpeJuppqPnjHfZCnjASgvoZCUxjCGRyaepfCPAskFagSIioSUyNtWeiaFDMJkfxUOrhXPhryluxeKooNJhcyujntSYIJPuuogmmKAaiOPhZkYuhCVwHvsTSoLLKQFaHRRkdEtuLLEsrmveUkvnLrSTpDnwYVxtMUZWnknHZnRsaJlszbKrDrmnmAWlvnXzhIxQkAbcA")) {
        for (int PRjDDIkfEWNGCDCv = 804939002; PRjDDIkfEWNGCDCv > 0; PRjDDIkfEWNGCDCv--) {
            continue;
        }
    }

    if (RiBewEnXQfTENjK == 547556516) {
        for (int yoHHiPbCp = 562976500; yoHHiPbCp > 0; yoHHiPbCp--) {
            eiYOC += eiYOC;
        }
    }

    if (RiBewEnXQfTENjK == 547556516) {
        for (int mNUAqUIqvrE = 728731106; mNUAqUIqvrE > 0; mNUAqUIqvrE--) {
            eiYOC = eiYOC;
            RiBewEnXQfTENjK -= RiBewEnXQfTENjK;
        }
    }

    for (int RAnTiuWIkLaBa = 1218372145; RAnTiuWIkLaBa > 0; RAnTiuWIkLaBa--) {
        eiYOC = eiYOC;
        eiYOC += eiYOC;
        eiYOC += eiYOC;
        eiYOC += eiYOC;
    }

    return RiBewEnXQfTENjK;
}

bool xJEVga::rBJEfjhAxwFi(double GaxRrTwXBultw, double fTGPGgrjDet, double pYNLUYkpmNYZb, double mlrhOnerPbz, bool YdLTpJkIpvZou)
{
    string mpPkAXKM = string("pEcHZYZWCNxNYGacrTTwCSQpJcQKDOdUMDHskiYEeEcAtMFJaHQojqafkYFgKxYefeVWEcXkCaOsjvtwhdNieganKkpfYfhwcGieaMkScexnRFcnKZiewQsSSNcyuGSMOgKthqnxiGRhasvKMwxCuRWGxDqRGveoSLBogpkLfQdKpQvsXlJtrMxGdVWTmvUYhGnBnsCQMxZpDzhzkxhdUhiDvbmojwLuSxnYtHnPZ");
    bool LnSzaH = true;
    double KvoGeftEtQPcp = 428998.203480801;
    int bdwcgBgQwkxxjZAY = 196796238;
    double FaRwGvqFqVzb = -22309.855316934583;
    string AITGd = string("NpKqDQeYqNULnlOsbpSkSSuotVHSNJRRaCzKCKBlGgxMaARLDuizXPjTBYcSDToDwusPAZGcoxuXJcaskYOdjzfBmSBcBmlBAYzqujNrNAprmoFprgjIOErSMllAzQpeZhFAcTnvxbOhPfheHQSAaLheLNXXTLoyJpkMFSNNuhuAUPYFPQTsoWfMdHKcJbRchayYXsrDPwbWpifjsfnCnolyNXUkwnpJgvkknWQlBKhO");

    for (int aKkKLLrLZRZlr = 1108010923; aKkKLLrLZRZlr > 0; aKkKLLrLZRZlr--) {
        KvoGeftEtQPcp += mlrhOnerPbz;
    }

    for (int rJefxRomRdnEavh = 431843516; rJefxRomRdnEavh > 0; rJefxRomRdnEavh--) {
        pYNLUYkpmNYZb -= FaRwGvqFqVzb;
    }

    for (int qNHhaAHzBViRN = 693883681; qNHhaAHzBViRN > 0; qNHhaAHzBViRN--) {
        YdLTpJkIpvZou = YdLTpJkIpvZou;
    }

    return LnSzaH;
}

void xJEVga::aUNMRfyjkGhM(string uoSICLnrLTgX, bool QfNamjGbpOFRRvn, int NYyVaILn, bool xreJtKkhqrPR, bool JVJmQUamkJ)
{
    int gtrPdH = 1360681638;
    string YCJSZ = string("xGDiQzpnWoOYaSjQNlSgBlAQkDKMhHILSCRoSvDLrWVVYEMJmQVGUhQKhcWrBSLVXGEkyeWuMtlFhtYXjByDMOlCODTrneMVTozemotDTSdKcxWypzwTDItzVDMLAKwPvFCPmwEjbxlRWuWv");
    double NGaBWrCLIr = 478823.3670990851;

    for (int UJTve = 730020070; UJTve > 0; UJTve--) {
        continue;
    }

    for (int iANUkktLiPPpNE = 1819405889; iANUkktLiPPpNE > 0; iANUkktLiPPpNE--) {
        QfNamjGbpOFRRvn = xreJtKkhqrPR;
        JVJmQUamkJ = ! xreJtKkhqrPR;
    }

    for (int LklujYggDrbwAuOg = 664132994; LklujYggDrbwAuOg > 0; LklujYggDrbwAuOg--) {
        gtrPdH *= NYyVaILn;
        uoSICLnrLTgX = uoSICLnrLTgX;
        NYyVaILn /= gtrPdH;
    }

    for (int LatgdUNYtCZeDNlT = 1208886356; LatgdUNYtCZeDNlT > 0; LatgdUNYtCZeDNlT--) {
        continue;
    }

    if (NGaBWrCLIr != 478823.3670990851) {
        for (int HRMloh = 2113717073; HRMloh > 0; HRMloh--) {
            JVJmQUamkJ = xreJtKkhqrPR;
            xreJtKkhqrPR = QfNamjGbpOFRRvn;
            YCJSZ = uoSICLnrLTgX;
            gtrPdH = NYyVaILn;
        }
    }
}

void xJEVga::MZWwrOVhuh()
{
    int tjGrmIXb = -36148338;

    if (tjGrmIXb > -36148338) {
        for (int yUdSwSdFnXoYM = 145064027; yUdSwSdFnXoYM > 0; yUdSwSdFnXoYM--) {
            tjGrmIXb = tjGrmIXb;
            tjGrmIXb -= tjGrmIXb;
            tjGrmIXb /= tjGrmIXb;
            tjGrmIXb += tjGrmIXb;
        }
    }

    if (tjGrmIXb == -36148338) {
        for (int ciZmDlkjYskmpG = 193346658; ciZmDlkjYskmpG > 0; ciZmDlkjYskmpG--) {
            tjGrmIXb = tjGrmIXb;
            tjGrmIXb -= tjGrmIXb;
            tjGrmIXb = tjGrmIXb;
            tjGrmIXb -= tjGrmIXb;
            tjGrmIXb = tjGrmIXb;
            tjGrmIXb *= tjGrmIXb;
            tjGrmIXb /= tjGrmIXb;
        }
    }

    if (tjGrmIXb >= -36148338) {
        for (int batMbck = 1739021718; batMbck > 0; batMbck--) {
            tjGrmIXb = tjGrmIXb;
        }
    }

    if (tjGrmIXb != -36148338) {
        for (int BXYgdw = 1928993606; BXYgdw > 0; BXYgdw--) {
            tjGrmIXb *= tjGrmIXb;
            tjGrmIXb *= tjGrmIXb;
            tjGrmIXb /= tjGrmIXb;
            tjGrmIXb = tjGrmIXb;
            tjGrmIXb *= tjGrmIXb;
            tjGrmIXb *= tjGrmIXb;
            tjGrmIXb += tjGrmIXb;
            tjGrmIXb /= tjGrmIXb;
            tjGrmIXb -= tjGrmIXb;
            tjGrmIXb -= tjGrmIXb;
        }
    }
}

void xJEVga::EUOFX(int nzlrNJdONbT)
{
    bool MOvQFirNRUAD = true;
    double kPVwZ = -1032677.3366783978;
    string pEOOExbDDP = string("lKPLFClaxhpTJSvARvbtrsyFfEbhNLwgDphKCNFyreEBfjHdlupmziKxhlhDKnTTSxpOAvxQzkFfHrmLbKPqXnExUmdfUuXhPsyegIYCAdESKAFMYqNuTCpVBybz");
    int GmphfJPfaEl = 895741695;
    string xhliQXBEHugTuISW = string("ZIwlJwQxXtlKaJqPxTcuiqxUgzkyonXHGrBhynVVSbhqAxjRBNTyyAatjDPumsktMrFuTTDJiJCNlvlCihXfdhgBrysUzTytTyoYatXDONNkRLIdkQUmdDaAoLnRHdelmXxhgqFyAsXEgRRokfnFZoyymxMcfCFEZVgtACAmKlFyxmElbQhRVRsIOcYkcKaKkllLPiuSBtUzTlxMZcObVxamdJEibZrqrHCOIycQKqxTGtA");
    string MqQXotppdVBNxhM = string("jTDvOrVkleeIJvBXhAhZnMhRmfKnAxyBonFRBitKzU");
    string hQHeEwAxB = string("JqzfcvWaxSALKzYZLPwLJIfyIaSGurmgMevHTVXDxrhfOkkTWoBzIPwvamfhSYZmJedVoUnFgXTUjbpYVYdMEhpIfmgqzQctZoiYnFebNzDVxePfmCFAUDtHvKOxZoptATMerfLfBLyiLlhJRnUe");
    double NaqszRfsTYhbzF = -330549.45960297267;
    double RkmluLPCXDi = -294938.1443700592;
    double lAiDCeEHyJqAvXm = -902677.7609775934;

    for (int kdSBubsbFjKuCrIe = 1824775252; kdSBubsbFjKuCrIe > 0; kdSBubsbFjKuCrIe--) {
        kPVwZ /= lAiDCeEHyJqAvXm;
        lAiDCeEHyJqAvXm -= NaqszRfsTYhbzF;
        MqQXotppdVBNxhM = pEOOExbDDP;
    }

    for (int uwGMpkg = 1472430481; uwGMpkg > 0; uwGMpkg--) {
        continue;
    }

    for (int icyrDwetgt = 1972896387; icyrDwetgt > 0; icyrDwetgt--) {
        lAiDCeEHyJqAvXm /= RkmluLPCXDi;
        pEOOExbDDP += MqQXotppdVBNxhM;
    }
}

void xJEVga::wTIWjCjpnJ()
{
    int DqmxwAtBGYNdaowB = -1881227142;
    string AkDQaszENc = string("tSKCxoemIfkyZvNtOwNuwLFAYPuxTovhEXSFDWJAVFVfHdhrnfjtvWdYrLmwVnZcYGNiDeupeaWobuCuILIzzPjXwnhOGItnAcjpovAWWQfUyEBxqyfiovzhhUUDNQMgutQpPOiLxvJQLmmXNGFoHJUCPqHpcPeVcOEqMvMWbwfzrIkVjmfdiVudzCsao");
    string HeuJI = string("fbvGhXDRurJnLbgtbEqqMRxNkFxkxsMtUzHheJowKjfnIJYhPKRwRhloEtRACnTALQHFTjGYYDIqxUAwpnLeGNNAUhsWINhjsvELaLcpmXHWWVFANDUuWINdPMFQ");
    bool KnRswosVqJ = false;
    string CastGFNNYbafIYa = string("qsJAQcHXmuPCOOLeQaMaligMjxJSNDgwplYpOxorKFSPPdrhoCBTYWkxlScHnOvQqzjOWCctsMttuSnHPaNUxHaAoSPcm");

    for (int UbUqbFuvitbZwIHs = 1071696476; UbUqbFuvitbZwIHs > 0; UbUqbFuvitbZwIHs--) {
        HeuJI = HeuJI;
        HeuJI += AkDQaszENc;
        CastGFNNYbafIYa = AkDQaszENc;
        CastGFNNYbafIYa = AkDQaszENc;
    }

    for (int BzqiWtnp = 857319723; BzqiWtnp > 0; BzqiWtnp--) {
        continue;
    }

    if (CastGFNNYbafIYa >= string("fbvGhXDRurJnLbgtbEqqMRxNkFxkxsMtUzHheJowKjfnIJYhPKRwRhloEtRACnTALQHFTjGYYDIqxUAwpnLeGNNAUhsWINhjsvELaLcpmXHWWVFANDUuWINdPMFQ")) {
        for (int QQkzJIXKe = 1605115543; QQkzJIXKe > 0; QQkzJIXKe--) {
            continue;
        }
    }

    for (int dQlBvOYGy = 269615714; dQlBvOYGy > 0; dQlBvOYGy--) {
        HeuJI += CastGFNNYbafIYa;
        CastGFNNYbafIYa += HeuJI;
        CastGFNNYbafIYa += HeuJI;
    }

    for (int dXCYhVydkyDaiYX = 77477134; dXCYhVydkyDaiYX > 0; dXCYhVydkyDaiYX--) {
        KnRswosVqJ = KnRswosVqJ;
        CastGFNNYbafIYa += AkDQaszENc;
    }
}

string xJEVga::JgtpAzrNSvMIwkw(string DEMxWngmo, int aBBukHLpBMWSQ, int akCiMU, double qubbjbLGsimsM)
{
    bool HVEELkufAPkP = true;
    double sgVHLxmeTAWqf = -116520.66069439496;
    bool dmJimt = true;
    bool JePCfxj = true;

    for (int MxNkK = 1328481366; MxNkK > 0; MxNkK--) {
        sgVHLxmeTAWqf *= sgVHLxmeTAWqf;
        HVEELkufAPkP = ! dmJimt;
    }

    for (int kyJYKNP = 1201203496; kyJYKNP > 0; kyJYKNP--) {
        aBBukHLpBMWSQ /= aBBukHLpBMWSQ;
        dmJimt = ! HVEELkufAPkP;
        JePCfxj = HVEELkufAPkP;
    }

    return DEMxWngmo;
}

void xJEVga::jqTxDVsFW(int MAweGGDjSJbQTn, double zWBRL)
{
    int ViABECTpfqYe = -2111042265;
    bool cinrpHsDrSvNpflO = false;
    string QAJyAZ = string("shdmHkVlbQsaxcDtdrUZfvfycpHrtQCAjCEEPiuSInsPOeLvwXzDyPbjnxADaDVGzDiOqalQSEptjwyKxzNPUszrBxvakxZjQgbITLVdjBQlKOINgCDkHtZfWBALwavkkXiyZBAeUPvPeuJzfXwNQGcdMLzjPQokErQJfCVLaqGWjQEDXdihfiPYecvUEHriCWHxIMZbKCzUnEGezbMlnDyJNglq");

    for (int LjvtVJZ = 703694035; LjvtVJZ > 0; LjvtVJZ--) {
        cinrpHsDrSvNpflO = cinrpHsDrSvNpflO;
        MAweGGDjSJbQTn += MAweGGDjSJbQTn;
    }

    for (int VQtEYWEjZTq = 824076448; VQtEYWEjZTq > 0; VQtEYWEjZTq--) {
        MAweGGDjSJbQTn /= ViABECTpfqYe;
        zWBRL = zWBRL;
        MAweGGDjSJbQTn = ViABECTpfqYe;
    }
}

int xJEVga::XesYksQfKSIsTyMY(double UtYeTgGbjmqeOO)
{
    string HtUDGFmPFs = string("lcSgONrWFTPXNMEKEjWvIKbJqwnRlNpAuZrywJCBdqeKiOtRfDXNWdIbDHlakGNEzhUKAyFdjzFxurLnWpyCOkrRwahaJOijgZsGroRIcBdcJahconlIbtOGkBXBEZHPHDGmsOMZdCXOVqfmQxkQUpbShiESopWKokeRAdn");
    bool CdQzHMRmAAXpsc = false;
    bool MNYTcspjN = false;
    bool JpBDJ = false;
    string GIlLThkwQ = string("kCKIACWVujmXBkzAHAEDhyvbwJObfsAInSHYnSvfLYjAekydtMOwursGMaoGqfyhEmbmfKyyDpIXFkaXChaRLQUVbXZbittNjmAEyMPmFnXpqJlXeWMPpuniLtcgebkcQZzBKjsAkSfMZNcFhRinzSvddevNVOsacECYYuQhHSrmEQseZnmPKBdtzcR");

    if (GIlLThkwQ < string("kCKIACWVujmXBkzAHAEDhyvbwJObfsAInSHYnSvfLYjAekydtMOwursGMaoGqfyhEmbmfKyyDpIXFkaXChaRLQUVbXZbittNjmAEyMPmFnXpqJlXeWMPpuniLtcgebkcQZzBKjsAkSfMZNcFhRinzSvddevNVOsacECYYuQhHSrmEQseZnmPKBdtzcR")) {
        for (int qoccWpZjaLGtasNv = 1510018863; qoccWpZjaLGtasNv > 0; qoccWpZjaLGtasNv--) {
            JpBDJ = CdQzHMRmAAXpsc;
            GIlLThkwQ += HtUDGFmPFs;
        }
    }

    if (JpBDJ != false) {
        for (int QzCSTjMBafrXu = 785649430; QzCSTjMBafrXu > 0; QzCSTjMBafrXu--) {
            UtYeTgGbjmqeOO += UtYeTgGbjmqeOO;
            JpBDJ = ! CdQzHMRmAAXpsc;
        }
    }

    return -1426167856;
}

xJEVga::xJEVga()
{
    this->VJucDp(466030.05773734493, -745409.2244753621, true);
    this->zPaoNo();
    this->rBJEfjhAxwFi(-800159.1325694004, -460154.9612913534, 544580.1341938152, -239646.66496741772, true);
    this->aUNMRfyjkGhM(string("ANBBAexlMLkkiXYssbAXZkpFzzVQiosfPxMLrHHGytiQXmhJemvKOWQwKjvhGUJgfxdVzvUiJwrJhvWLCaaCyAeoZwXDaHfjCLYdiBpprQDWTktNNsarvgLDQqSYCdejmIKKpSpCgdplRXFzwyhOXVtYk"), true, 1641421747, true, false);
    this->MZWwrOVhuh();
    this->EUOFX(197011667);
    this->wTIWjCjpnJ();
    this->JgtpAzrNSvMIwkw(string("XYbkdxVYrqoreXLTeMFHTXYSVGAzdcrgoPJWVhVvVJMfQVzeehyUkoqvviFSgVgfqyDWimoiEedowNYsrpwYrmsAuYjbnDYYPfMApUPoIKVbreOXmrToSJfRgALhlTpmPsQkCknlq"), -2091391662, 237171833, 590732.8944160234);
    this->jqTxDVsFW(99851973, -163084.15307891337);
    this->XesYksQfKSIsTyMY(-1025787.508810084);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uwUVMq
{
public:
    double GmjVhCXIRajKKB;
    string WsNwez;

    uwUVMq();
    int SOmQtDe(bool XnmpgaUEowpsVmB, bool XSwmXo, int azmLEDHAct);
    string LXSkNIHJyLPGnLPm(bool huLHtxngmvtO, string ijHviPWUDes, double JNhNdsGXj);
    void fYDmGfbrzVA(bool OiGjXIWRgWv, int mVdjJLUnsnVpDjsx, double WXsHrRBNiNBy, string clhjEmUI);
    string Bjqtiwc(bool VqHGqsLVFplWmc, double YfuPWB);
    double yUttfQpJzRcKZfBG(int idXkPgSN, double KxNHvMibgTmbXB, int IGrRzDoRK);
    void TbapnRbEGf(string QYGIfvbfBmrNhq, int EfojyIyAMrhOka, int hPhyhRzqRMrzbszS);
    string EFDHcpwlSXEg();
protected:
    string afbWfqmB;
    double cPgVMVr;

    double oBOypHTrRkVN(int YyQVko, string APrQPK, string opyEyGuzsqgkLJnM, double IJXXaAQPyOV, int MauFjrlBwFJY);
    void dTalEtPVdJsTTjMV(string lPVuYwbn, string MrPdOTpuN, bool MfPswRQzm, double JFDJQHDTchyG);
    bool tNaOUaRUFh(string bqaKFMWmZGVlc, string CWLTxcjx);
    void sXhJdDRhwzqwfacY(bool vdbGWyq, double RvRpHwIamRm, bool VbMTsYiHhWCq, int RGlkvP);
    double MfEzhYGgw(string TRvcCHcxFpXWMi, string FtPlHHTceRMUAN, string xEdOpkMWhWag, int xUUzVbzbhI);
    string hykeYXZkS(string JNcwUimISg);
private:
    int EssHskvzyPiYBg;
    double TNEnEAyODLGPkL;
    bool bxVMVliqAvznpu;
    bool ouTbzsxrXAVuu;
    bool sncMiIdKfgn;

    int QTKOdXWxAzHlgUUp();
    void TwTBhu(double PzysihHIaiDBcqEI, int cmnDfqwCTijHkI);
};

int uwUVMq::SOmQtDe(bool XnmpgaUEowpsVmB, bool XSwmXo, int azmLEDHAct)
{
    int hLEBrOkycfZbSZzB = 1225082037;
    string AmrEhcmxNcweC = string("SKUmvbScTdQHZDVoxNDAjvwVZEWfJYFKNNflXnTGaqVBEBBAbLYOTTQhfrEDdv");
    double jzpCMVBT = -980059.1409943497;
    string EInKYbhMYUgu = string("YbySDiKgNHZLoRgfBoRyDtAbuFXOeDXyhWVbKXjXBQvsRqlRCGMdsjIyDSqUKBFbLWvSurGNfvqnDFLYZKfRStnShsaggUzziqdaFZRxlqSxodtyXYojYHLVFYKRfoPhrYFIeGXpfbOlapFdoGQekQgSAbTbxfQxBvNxPxyQQmd");
    double DulvqJrDGzx = 614094.1427302754;

    for (int qcHXuCUg = 998647574; qcHXuCUg > 0; qcHXuCUg--) {
        jzpCMVBT = DulvqJrDGzx;
    }

    return hLEBrOkycfZbSZzB;
}

string uwUVMq::LXSkNIHJyLPGnLPm(bool huLHtxngmvtO, string ijHviPWUDes, double JNhNdsGXj)
{
    string KgXezpZYQr = string("bALbccTMYZJKxADqRSoNqNvwqENtqAjnAUMVzdAEEFxFODLXZLpUSVVvILtuSBWKVArsqhinFMMjTanYFezQMBgUQxpAWhFrMJFofdvCMuPoIFZHoKitCxLqhzknXHqBzDoErVRGVWlZnQNSkDatBcXezDPdslKLQhL");
    int zwKivgdKfiw = -994976198;

    if (KgXezpZYQr <= string("bALbccTMYZJKxADqRSoNqNvwqENtqAjnAUMVzdAEEFxFODLXZLpUSVVvILtuSBWKVArsqhinFMMjTanYFezQMBgUQxpAWhFrMJFofdvCMuPoIFZHoKitCxLqhzknXHqBzDoErVRGVWlZnQNSkDatBcXezDPdslKLQhL")) {
        for (int SeivPobAtONSmYe = 1515884770; SeivPobAtONSmYe > 0; SeivPobAtONSmYe--) {
            ijHviPWUDes += ijHviPWUDes;
            KgXezpZYQr += KgXezpZYQr;
        }
    }

    for (int jGZnM = 374527456; jGZnM > 0; jGZnM--) {
        zwKivgdKfiw /= zwKivgdKfiw;
        JNhNdsGXj += JNhNdsGXj;
        JNhNdsGXj += JNhNdsGXj;
    }

    if (ijHviPWUDes != string("MBWjqPOryKZHyxvwEfCDZppslRgonfpWTFmcjdwSOFxtQShJCjAbzMRQrHuGKjyxDEcmOzznQpsjGiCVksdMDUUbLhKHgLNcGDcXETQlxfjXIPoNyZMqoINxgQLkSSbeAaztNRRZmJgfTQHWSXdMX")) {
        for (int WMUncVxdpOnTii = 641654503; WMUncVxdpOnTii > 0; WMUncVxdpOnTii--) {
            KgXezpZYQr += KgXezpZYQr;
            JNhNdsGXj += JNhNdsGXj;
            JNhNdsGXj += JNhNdsGXj;
            zwKivgdKfiw = zwKivgdKfiw;
            huLHtxngmvtO = huLHtxngmvtO;
        }
    }

    return KgXezpZYQr;
}

void uwUVMq::fYDmGfbrzVA(bool OiGjXIWRgWv, int mVdjJLUnsnVpDjsx, double WXsHrRBNiNBy, string clhjEmUI)
{
    int gfURsk = -616269027;
    string RykeJXMuR = string("IwfFqSKEtqKiEURAAFgnOjJGkIyBhLqDPurCZHQqcJJtbFsyotZkmZTmtNkuYmLgukqrnjJRFKUrlnWGDevRnj");
    string InLoiuOgOSIQY = string("SYMrONQzbvUWaSDEnMtyjTWruuqfrFXIZSBiNwZLdqfckDKlqgMjbsOfjCdhlghFGXrMKXXCjJXIQBVNvZHWBLoWoeIZIJcFRLFHCEXDULiXOHelEoRMkERlGmDRsszQEFhOcmMqiDPKxPHqWRMDyjDToPtauoSUPwxPkntMHLfrPoJdSkpTifgGipFr");
    string HQzfQjYu = string("nogavmEAcIhHjiXAxiWbxRqoRFAMpFWGVDWxuxixcchwOgARCklFieIzbfLuHggpr");
    int AJZCMbJHvJLvsHX = 800452772;
    int jCiBTrkPXTGaO = 433273413;
    double unulBvNLz = -608739.7967645794;
    double ggVMzRPwHrBUZ = -935869.9359015021;

    for (int svnxv = 491073810; svnxv > 0; svnxv--) {
        unulBvNLz += unulBvNLz;
        HQzfQjYu = InLoiuOgOSIQY;
        InLoiuOgOSIQY += InLoiuOgOSIQY;
    }

    for (int mySWRrXpe = 1511793723; mySWRrXpe > 0; mySWRrXpe--) {
        InLoiuOgOSIQY += clhjEmUI;
        ggVMzRPwHrBUZ *= ggVMzRPwHrBUZ;
        OiGjXIWRgWv = ! OiGjXIWRgWv;
    }
}

string uwUVMq::Bjqtiwc(bool VqHGqsLVFplWmc, double YfuPWB)
{
    int cazUkuf = 178630755;
    int tXhxXpBvRPRX = 2072298972;
    bool VBBzyyPaRAThtiV = true;
    bool iuLQcuE = false;
    bool uYoxYBYPvzTfPs = true;
    bool kbaudwQQXYKsnhFV = true;
    int lHnfUAt = 1855422415;
    double FILJtbQYpsmjQPrr = 606607.6249946146;
    double nDzCLe = 938391.2892153807;
    string UykLLjzUwHo = string("EqtxumDPhzYWGYAeMN");

    if (nDzCLe <= 575564.9128270211) {
        for (int UtMkBbmgRnDI = 229717342; UtMkBbmgRnDI > 0; UtMkBbmgRnDI--) {
            continue;
        }
    }

    if (VqHGqsLVFplWmc == true) {
        for (int wMpGDu = 1150280807; wMpGDu > 0; wMpGDu--) {
            tXhxXpBvRPRX -= lHnfUAt;
            FILJtbQYpsmjQPrr *= FILJtbQYpsmjQPrr;
            tXhxXpBvRPRX -= lHnfUAt;
            VBBzyyPaRAThtiV = ! VBBzyyPaRAThtiV;
        }
    }

    if (VqHGqsLVFplWmc == true) {
        for (int aRbgD = 690529677; aRbgD > 0; aRbgD--) {
            lHnfUAt = tXhxXpBvRPRX;
        }
    }

    for (int ElbbnEbvmmvwmD = 892333465; ElbbnEbvmmvwmD > 0; ElbbnEbvmmvwmD--) {
        continue;
    }

    for (int aQgrqeNTH = 2093202906; aQgrqeNTH > 0; aQgrqeNTH--) {
        continue;
    }

    for (int GBtQYuZw = 866725389; GBtQYuZw > 0; GBtQYuZw--) {
        VqHGqsLVFplWmc = ! kbaudwQQXYKsnhFV;
    }

    if (nDzCLe <= 938391.2892153807) {
        for (int UbsJuXEPOHa = 1419511799; UbsJuXEPOHa > 0; UbsJuXEPOHa--) {
            cazUkuf -= lHnfUAt;
        }
    }

    for (int HryiVr = 111545559; HryiVr > 0; HryiVr--) {
        VBBzyyPaRAThtiV = iuLQcuE;
        VBBzyyPaRAThtiV = iuLQcuE;
        uYoxYBYPvzTfPs = uYoxYBYPvzTfPs;
        YfuPWB += nDzCLe;
    }

    return UykLLjzUwHo;
}

double uwUVMq::yUttfQpJzRcKZfBG(int idXkPgSN, double KxNHvMibgTmbXB, int IGrRzDoRK)
{
    double pdWdgadAWTrJG = -899799.336093823;
    int RHqEorvcnOjh = 1341839128;
    int nmYdj = -810575682;
    double fNTogUQ = -167684.82352227336;
    string ELNLDgSv = string("ZhAnFYROKcrlWVnTPXDfWuaBOIvWltJpmVnRwSsAnbRDxqBQURAbrdBJJTWDgRebgHBCtdHXKxyCNQMgBebgxMzuILqPCXUZTKUNvvEUUSZOrJYsdylCXUq");
    string OZxiSVZvZSq = string("xvRrxjPWCQgxwATUbjCXWtWafaMigcPfBbNlzfvCeomTFOJrSAEFpgVNPZRoePKHIdxtmEtTjolLiesIwwuPSSUyyESiGR");
    double jSopTiXFkwyLS = 972436.2215972738;
    double uKtFvwLNgOKYFU = 207058.05483150817;

    if (RHqEorvcnOjh != -1309930261) {
        for (int AIeorFViqmgYzyL = 1505516071; AIeorFViqmgYzyL > 0; AIeorFViqmgYzyL--) {
            fNTogUQ *= KxNHvMibgTmbXB;
            RHqEorvcnOjh *= nmYdj;
        }
    }

    return uKtFvwLNgOKYFU;
}

void uwUVMq::TbapnRbEGf(string QYGIfvbfBmrNhq, int EfojyIyAMrhOka, int hPhyhRzqRMrzbszS)
{
    bool gYfbmCqbkqULztph = true;
    double sGEVuvQW = -485096.09963377763;
    int PHlykoSZWEcRwAv = 630708285;
    string tvleKHqLvviuvL = string("TZvNwAqIxdyNQGdvcEOgRcucSVcCkjNduZPicIGXySBadAMQTiJdLnowLEtsyJnbbGLbDpHbfldbUbtarrLHKlySGgYTNFpkdeDOHhePfqyTZDnaKXHexjghgUpqkkxLJmFZFqoCBBGfKvxDyFQgxBObCbZerhpSgLSgEG");
    int UdNPi = 727879790;
    bool CwqZkrutDDTAnoq = true;
    bool MnsOtkpwQvCUGq = true;

    for (int RyyeBc = 1741895932; RyyeBc > 0; RyyeBc--) {
        hPhyhRzqRMrzbszS -= PHlykoSZWEcRwAv;
        PHlykoSZWEcRwAv *= UdNPi;
        UdNPi = PHlykoSZWEcRwAv;
    }
}

string uwUVMq::EFDHcpwlSXEg()
{
    bool aVLcM = false;
    bool YHLqSKKxgVJ = true;
    bool yCFnNCJshJSky = false;
    bool YUTQPfwOWQD = true;
    double BkCUVRgQ = -89027.07894288634;
    string OJEUaACmOsFBPCZM = string("QVTsXtDHGrvPuOplstECRAMcIahSITwtNsAPbjwCCuqyKlklViQliCfMspktfhwJuCcZfayNIrhOaHhQnNXRoDCTxhZPYcZJJoxlMPDlOEXiTATLvMkOXZNPYhwgNHRdgTvsJSLoFiDnBFNwwxZNbxvPgHiCAdjWuHhCBNueKGgFUeOZJcQvOZOIoCpXhgfwZCGyBpxVrUDaYbNzZmoYeMAETPDfhxpHpQMQDrnSFcoPCDtAppseIogUyQgmov");
    string CWRsFcmrSwd = string("xgCykyeTNnkLzklLrbPqqEMRqUidjSAq");
    string NuwaNWGLh = string("mxCoAVIukVsFlXyMXsvDDjlTHgAoncjGmnikjtxpbZAetIWabMXjbQzc");
    bool UusLFSdaViyKBoX = false;

    for (int XAYkxZDgbqo = 1570237027; XAYkxZDgbqo > 0; XAYkxZDgbqo--) {
        yCFnNCJshJSky = ! yCFnNCJshJSky;
    }

    return NuwaNWGLh;
}

double uwUVMq::oBOypHTrRkVN(int YyQVko, string APrQPK, string opyEyGuzsqgkLJnM, double IJXXaAQPyOV, int MauFjrlBwFJY)
{
    string LmacyglWlvN = string("khNYVvMafuAkN");
    double CnItbvgUkJSz = 656583.1746432758;
    double TbDZzoi = -48180.42812755055;
    int OUzzBGKR = 428200589;

    for (int XpxnvjR = 1361962253; XpxnvjR > 0; XpxnvjR--) {
        TbDZzoi += IJXXaAQPyOV;
        YyQVko = MauFjrlBwFJY;
        MauFjrlBwFJY *= MauFjrlBwFJY;
    }

    for (int VJqOQXoa = 1422297487; VJqOQXoa > 0; VJqOQXoa--) {
        continue;
    }

    if (APrQPK >= string("lPvokQCkUmSnIyMmJoouBSHAKwkaxeziEvjdRyckvDMNapXgoHLnxWGhNucjWBhKGiHRbyzgJZmMtaYjKfwNyYjWDNUdwWKRRmnkAFuc")) {
        for (int svoFrTiYjzvIFl = 1525156404; svoFrTiYjzvIFl > 0; svoFrTiYjzvIFl--) {
            LmacyglWlvN += APrQPK;
        }
    }

    return TbDZzoi;
}

void uwUVMq::dTalEtPVdJsTTjMV(string lPVuYwbn, string MrPdOTpuN, bool MfPswRQzm, double JFDJQHDTchyG)
{
    bool UtwiS = false;
    int VdwtK = -1403512135;
    string RvgKVwTpIOlsJ = string("tmKAuURZIJnVGjXGIhnmZbrekHJUSCMxycrQwJUdmkLtZcuwlpZiRPkXfuYVmPxasJJnJFJJpqqHVFWvvGyKeqFINVqFljNjAjveXPzgeZlkTAhKWvNkrTDrXMnUTKNUQvsGUAAJsQqIsSfSfdKUaHJmlDRsHlsAilaDiifZWOwEmnURvmorzfxCxCvR");
    string uMyeAMpB = string("MhhoPLlCIaXhhnXDKkRYPYVlGjPeFtUKnxDdYffitLhcgylqrKBITceHoGQWciTykYYYNvMGFRanTgQJeCZbuEXhjgSmYkKZyeSnPIYNZYgsMJVncgriCBwfWRseMBCMTrHffkTxXSToblHboACPKQEOQHPKSeQEcpkpCeLwgWBTquEyDeJPJpWRWQUGJmVBOGkERXcuhuKDtZIeuBUINWvhKcXixyO");
    bool pkNZGVvh = true;
    double gzZKDhFlCZ = 37084.89240978399;
    bool fzGwrfCen = true;
    double LXgwZSIymOWjQ = 622655.9140846257;
    bool LNQWgur = true;
    int kIoMc = -1336420580;

    if (lPVuYwbn <= string("ggvgsvmJjmtoe")) {
        for (int jgRVnDOOcsQMoi = 1183001378; jgRVnDOOcsQMoi > 0; jgRVnDOOcsQMoi--) {
            MfPswRQzm = fzGwrfCen;
            gzZKDhFlCZ /= JFDJQHDTchyG;
        }
    }

    for (int ETZlobwdIRIJuA = 238037368; ETZlobwdIRIJuA > 0; ETZlobwdIRIJuA--) {
        continue;
    }
}

bool uwUVMq::tNaOUaRUFh(string bqaKFMWmZGVlc, string CWLTxcjx)
{
    double UuYVEjtC = 744846.331685793;
    int XrQYL = -2057640839;
    bool dXHmSqWfbZJgi = false;
    double zybim = -877365.7164938569;
    double usXwpveOdbYXB = -301399.2646675773;
    double huDbARZRQkVtax = -649962.9058034185;

    return dXHmSqWfbZJgi;
}

void uwUVMq::sXhJdDRhwzqwfacY(bool vdbGWyq, double RvRpHwIamRm, bool VbMTsYiHhWCq, int RGlkvP)
{
    bool xzXGAhkWZyQ = true;

    for (int IyyqHax = 1291393318; IyyqHax > 0; IyyqHax--) {
        xzXGAhkWZyQ = vdbGWyq;
        RGlkvP += RGlkvP;
        RvRpHwIamRm = RvRpHwIamRm;
        xzXGAhkWZyQ = ! vdbGWyq;
        vdbGWyq = xzXGAhkWZyQ;
        VbMTsYiHhWCq = vdbGWyq;
    }

    if (xzXGAhkWZyQ == true) {
        for (int GcmUboOQrtJkm = 1508162473; GcmUboOQrtJkm > 0; GcmUboOQrtJkm--) {
            xzXGAhkWZyQ = ! vdbGWyq;
            VbMTsYiHhWCq = xzXGAhkWZyQ;
            xzXGAhkWZyQ = xzXGAhkWZyQ;
        }
    }
}

double uwUVMq::MfEzhYGgw(string TRvcCHcxFpXWMi, string FtPlHHTceRMUAN, string xEdOpkMWhWag, int xUUzVbzbhI)
{
    int vOiXiYtdbjI = 638187572;
    string QVrjYHAs = string("VBOSvWTdgKqcQinRZLmDhNbqZYWtOzHhHjKcjRlLxiXJaFRzYoShtNpWfvtzIIAAUYTqvvzZcoSoluxtRJpuPQXKedzZpKOlKhtkxkmZlFPhtdLwfaeYfxGkhPofeenGvXLrYblkbeOy");
    double rnHrrcgDNZSu = 529581.1002413017;
    int BGUdrqQMKO = 489758974;
    string UWkJsMjPPz = string("sfwkSXHEWPSReB");

    for (int jJmDokmNA = 157290361; jJmDokmNA > 0; jJmDokmNA--) {
        xEdOpkMWhWag = xEdOpkMWhWag;
    }

    if (FtPlHHTceRMUAN == string("ZVmrhwIvMzStQhgQIIkzliCJLhPfRqVxqVtwuBVmMtrbFWstxhqvCSkfILvrVrczxseCCGxZmVDHGhTvwAmbsUKyguTjjDdUGpKYQZXBTGsUacJmURxiJohBHvuiHHxRdagoDknorRJBnBhGIUJkmxBmbATlYwvSROOzgCjbmBKjwPrwhbQDkZaitJgKjvVQSAJoyBL")) {
        for (int QRWtBsNS = 163102002; QRWtBsNS > 0; QRWtBsNS--) {
            xEdOpkMWhWag += TRvcCHcxFpXWMi;
            UWkJsMjPPz += UWkJsMjPPz;
            QVrjYHAs += UWkJsMjPPz;
            xEdOpkMWhWag += xEdOpkMWhWag;
            vOiXiYtdbjI *= vOiXiYtdbjI;
        }
    }

    if (QVrjYHAs != string("HGWXTTVMRXJPBfUWRRUNNOmBIIzVjMEzEBffuUlGTvlGxlgyPDcbAhLAdsSQdopzeAwqiccRscfAdclcPLCuasOWpCZNTCfmfSdnRVdirRhNELvNOyXVRFmJrdCHKMiPoeDjwcXvqFqnKvMduIKKPuEfOVHoymdrxJPJRbEhpDqTgeKp")) {
        for (int pmPXOqADqHy = 1699326885; pmPXOqADqHy > 0; pmPXOqADqHy--) {
            vOiXiYtdbjI = BGUdrqQMKO;
        }
    }

    for (int ZQfjbBVRJwrFTNr = 1476842155; ZQfjbBVRJwrFTNr > 0; ZQfjbBVRJwrFTNr--) {
        xUUzVbzbhI -= xUUzVbzbhI;
        FtPlHHTceRMUAN = FtPlHHTceRMUAN;
        xUUzVbzbhI *= BGUdrqQMKO;
    }

    for (int lpjKDEKXbqeHE = 260502149; lpjKDEKXbqeHE > 0; lpjKDEKXbqeHE--) {
        TRvcCHcxFpXWMi += xEdOpkMWhWag;
    }

    for (int agEZwMXyB = 1475143786; agEZwMXyB > 0; agEZwMXyB--) {
        xEdOpkMWhWag = UWkJsMjPPz;
        FtPlHHTceRMUAN = UWkJsMjPPz;
        TRvcCHcxFpXWMi += UWkJsMjPPz;
        UWkJsMjPPz += QVrjYHAs;
        BGUdrqQMKO -= xUUzVbzbhI;
    }

    if (rnHrrcgDNZSu < 529581.1002413017) {
        for (int PJcnmZWodudFNg = 1066663202; PJcnmZWodudFNg > 0; PJcnmZWodudFNg--) {
            QVrjYHAs += FtPlHHTceRMUAN;
        }
    }

    for (int BsKFn = 2005545970; BsKFn > 0; BsKFn--) {
        FtPlHHTceRMUAN = UWkJsMjPPz;
        TRvcCHcxFpXWMi += UWkJsMjPPz;
        QVrjYHAs = UWkJsMjPPz;
    }

    return rnHrrcgDNZSu;
}

string uwUVMq::hykeYXZkS(string JNcwUimISg)
{
    double qLJxErfPSSOeBUnl = 569630.9914913946;
    bool MYkyO = true;
    bool ZcWOkOoVLyFqyFZ = false;
    double eQVeIXAxKQAH = -1029651.3547952666;
    int EEdUuYSzaPGKK = 1755399788;
    string uyCPQMfeAXe = string("SIDEHvFRtcblPmLKFoHAKSQPQsCsQvMrYkiOQwYpYDFzxMhGIhvAvmoCXmPyquMVkbzqzmVgiwtnSnXXgrMsHVHOZfkYxubaPfupRpuayJUnztGEbtcdMpuYValopdVqREKhOvCFAUtAkjRIZWqabANgkx");
    bool utApxVf = true;
    bool SbtqHWd = false;
    double hgHye = -713173.6773142784;

    for (int xLiwTvZ = 2146772051; xLiwTvZ > 0; xLiwTvZ--) {
        uyCPQMfeAXe = uyCPQMfeAXe;
    }

    for (int iVOxQsBX = 938428103; iVOxQsBX > 0; iVOxQsBX--) {
        MYkyO = ! ZcWOkOoVLyFqyFZ;
        utApxVf = ! SbtqHWd;
    }

    if (ZcWOkOoVLyFqyFZ == true) {
        for (int gPySutKWquUaFFoY = 1016978177; gPySutKWquUaFFoY > 0; gPySutKWquUaFFoY--) {
            MYkyO = ! ZcWOkOoVLyFqyFZ;
            MYkyO = ! SbtqHWd;
            ZcWOkOoVLyFqyFZ = ! SbtqHWd;
        }
    }

    for (int ORVZagcOMh = 2098900180; ORVZagcOMh > 0; ORVZagcOMh--) {
        continue;
    }

    for (int zzBAfWgVbYKDlYKC = 1226038309; zzBAfWgVbYKDlYKC > 0; zzBAfWgVbYKDlYKC--) {
        MYkyO = ! SbtqHWd;
        JNcwUimISg += JNcwUimISg;
        SbtqHWd = ! utApxVf;
    }

    return uyCPQMfeAXe;
}

int uwUVMq::QTKOdXWxAzHlgUUp()
{
    int UZmPuRdreTNIRToN = 1796106969;
    bool XrLHEszR = true;
    double sINothjn = -106095.93477171448;
    bool XgRwoN = true;
    bool oisnqopuQqH = false;
    string gsPkSHmFoOLWln = string("iKUvwIbdlALPmsdGQtrmKKZMZdGXWtOxtJMXQqIGThryDTxCWRNHRveqCVxoVPsShplFEMezeiySEwtWmoxTuQTBbDzMWrtMSboyTdEPSJSkqYRGtQCHwDWmRIXPRDzZRJHvfXUaraDbdEmWTzczcnOVOdxutysnXKFDakQMZIoHSKBcLgZwvLchourNTUyHHBqPnNtGoHmYqfIMlsaYuFBAdHHaeCBSvzZmYewinEqriBHAdLoGDwqsl");
    string GrtqvvNGwO = string("pXrTxBHGJIUetLUHziMxfWCoOtugbhrVnYEcGNaGHohGqTGdQKFrYWkjnPIqJUIFtdVarCLCMFEJTGxayjaTwidbJbjDtWQxOAYiAJlYwuykcveaJTtDJiMcCIovzEqlPuHOylZhLFOytY");

    if (gsPkSHmFoOLWln != string("pXrTxBHGJIUetLUHziMxfWCoOtugbhrVnYEcGNaGHohGqTGdQKFrYWkjnPIqJUIFtdVarCLCMFEJTGxayjaTwidbJbjDtWQxOAYiAJlYwuykcveaJTtDJiMcCIovzEqlPuHOylZhLFOytY")) {
        for (int sqwwcPR = 2069478758; sqwwcPR > 0; sqwwcPR--) {
            XgRwoN = ! XrLHEszR;
            sINothjn /= sINothjn;
        }
    }

    for (int nWyqKvKAUmk = 201571396; nWyqKvKAUmk > 0; nWyqKvKAUmk--) {
        XgRwoN = oisnqopuQqH;
        oisnqopuQqH = XgRwoN;
        gsPkSHmFoOLWln = gsPkSHmFoOLWln;
        oisnqopuQqH = XrLHEszR;
    }

    return UZmPuRdreTNIRToN;
}

void uwUVMq::TwTBhu(double PzysihHIaiDBcqEI, int cmnDfqwCTijHkI)
{
    int kDQRUcJtZziSTe = -1744955037;
    string bHQxE = string("xftGeqjLamiHpCpKzlUoWkwWCYNbQxlCbYxKZcWnbJERvNDLNohmxuGTZvEifLbgSClzUJVm");

    if (PzysihHIaiDBcqEI < 268154.55561020004) {
        for (int vEkjoiNKeczTwFf = 1721139412; vEkjoiNKeczTwFf > 0; vEkjoiNKeczTwFf--) {
            continue;
        }
    }

    if (kDQRUcJtZziSTe == -1744955037) {
        for (int mVhzHYxdaB = 6694997; mVhzHYxdaB > 0; mVhzHYxdaB--) {
            continue;
        }
    }

    for (int rLzzulju = 1167268777; rLzzulju > 0; rLzzulju--) {
        kDQRUcJtZziSTe -= kDQRUcJtZziSTe;
        kDQRUcJtZziSTe = kDQRUcJtZziSTe;
    }
}

uwUVMq::uwUVMq()
{
    this->SOmQtDe(true, false, -1669994460);
    this->LXSkNIHJyLPGnLPm(true, string("MBWjqPOryKZHyxvwEfCDZppslRgonfpWTFmcjdwSOFxtQShJCjAbzMRQrHuGKjyxDEcmOzznQpsjGiCVksdMDUUbLhKHgLNcGDcXETQlxfjXIPoNyZMqoINxgQLkSSbeAaztNRRZmJgfTQHWSXdMX"), 666239.0410498482);
    this->fYDmGfbrzVA(false, 2016767415, 172359.6220295743, string("mRZJabaxrqiVyYuCJtRctuUewiWOgDhYVACPleYQvSidQjRizPtHGsCDwrCgaOejHuKgcAhQcNbsezwgqRMqfaBsfwcTHnoSokIVEQHSMvbRflxYjIBcSeLwxQJbUEmAXxeGKimbTVKyguAKpbuGehReIktbTVJUswrSJshflM"));
    this->Bjqtiwc(true, 575564.9128270211);
    this->yUttfQpJzRcKZfBG(-1309930261, -347912.37846565497, -2036090182);
    this->TbapnRbEGf(string("WrfQOSNty"), -888517268, 1672178680);
    this->EFDHcpwlSXEg();
    this->oBOypHTrRkVN(1359391123, string("lPvokQCkUmSnIyMmJoouBSHAKwkaxeziEvjdRyckvDMNapXgoHLnxWGhNucjWBhKGiHRbyzgJZmMtaYjKfwNyYjWDNUdwWKRRmnkAFuc"), string("AFlCFYvuxwtcXYNBNkbMFeNSbVtQOxquzybRQsWWSlWrHgYCoCwizyIrKJFGOgLocxapZfwYWtEToiJZcCijkbiBfLWArTQmVDVncyferPdCzDNyVuCafjrviytRHFUhkMgysvrporMeNLuosctjjOUtxgTpVkWbFvqICaedyIDKmMhXvmhMbmLmLKyZeffcIIQZhhRPchiwEMhnyQJwbsXxOplKThzsLCCFWvJW"), -660774.3134276224, -542424533);
    this->dTalEtPVdJsTTjMV(string("ggvgsvmJjmtoe"), string("jAYliwtyolreaWoyNOfdfKyZkjvnSuypbMLXuxPELXVZJGOPrJBNpWMOPSkAfhvBSCCAftWXXqOYCFchVTHSWbGCRCRYgjzvZcDddZvYIbvtBjzffHjmnpHQyxtSkpTNCFUbYhVxyLawKxTtrNAWTtxVqYYnIVBWUKLpXbytTVmueJCDddMfjDuKwa"), false, 454269.5047431972);
    this->tNaOUaRUFh(string("zNgRDptppuLuDGglojSLHcwvZtxAIOKPkXLwYYiDnjWEFVtBaKszbwTEVXSIyGfcNJeKfGUmtdLdorfOXegtvzHnARgPgqXtMuoyPcOMbWkOlHeSHhYIrgo"), string("AfZrhvqfdPN"));
    this->sXhJdDRhwzqwfacY(true, 903115.8634019126, true, 1848510969);
    this->MfEzhYGgw(string("ZVmrhwIvMzStQhgQIIkzliCJLhPfRqVxqVtwuBVmMtrbFWstxhqvCSkfILvrVrczxseCCGxZmVDHGhTvwAmbsUKyguTjjDdUGpKYQZXBTGsUacJmURxiJohBHvuiHHxRdagoDknorRJBnBhGIUJkmxBmbATlYwvSROOzgCjbmBKjwPrwhbQDkZaitJgKjvVQSAJoyBL"), string("HGWXTTVMRXJPBfUWRRUNNOmBIIzVjMEzEBffuUlGTvlGxlgyPDcbAhLAdsSQdopzeAwqiccRscfAdclcPLCuasOWpCZNTCfmfSdnRVdirRhNELvNOyXVRFmJrdCHKMiPoeDjwcXvqFqnKvMduIKKPuEfOVHoymdrxJPJRbEhpDqTgeKp"), string("KDYEC"), 609678171);
    this->hykeYXZkS(string("kvmzxVtwxfnphIjLK"));
    this->QTKOdXWxAzHlgUUp();
    this->TwTBhu(268154.55561020004, -2020597342);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nmtkC
{
public:
    string KMKOFUEfA;
    double HdouMurc;
    bool QpCNZNYjjGK;

    nmtkC();
    bool iPavugaUYY(string BkSCJh, int BZOQfeFAMi);
    int nfrfP();
    int nEJDME(bool TLmLkqxnccOBhLp);
    int mWyJEVt(double vmtNBAOI, double lqtfNOC, bool gEpgUc, bool DjjNP);
    int xREAq(string GQVMk, double kTEzoBuEYCqnOUj, int lGScWxlXrcyHlQRo);
protected:
    string YEcMQTOBstN;
    double aojEaPZHefjnX;
    double CpUGwiPqDt;
    double JpOUXwsibz;
    int luphPX;

    int yFiZqPURtXBNArzd(int nzKVuuJVWaiZGBt, bool LHxmBuGjNGiVy);
    string kaGJkndIZvYBUC();
    bool ngRJlGhwoxlrGzI(double LOPeFUrMiSUTEYk);
    double qmKOy(bool BGmmttRIaiO);
    string jkNKvZUIjO(string kpUimGhYzu, bool uyJIWMaxdswk, bool KAdbMMyQhBiXOjXO, double IZfUhttUqgSwZiNA, int VNZLzgDyYhFmcwY);
    double NxZgrpEhjlVtQ(bool UMebcKYG, double iAYSHVLoqDAAMHMc, int sPJEPrlQdV, string wXydGqiOgXKUIRXu, int awowqdVNgvJVHVNM);
    string rwcomudpfgPmLyt(string RUhpw, double zwBFwkZoZTux);
    void XFbUFWxzqLcOJ();
private:
    bool kAOJXizVoNvsPp;
    double vfsKKyY;
    int guXDzk;
    string xUPDYeNFqId;

    string gyEkq();
    void AmSYlQgRep(bool HxbZjoVt, bool bALlsViKQxZFYy, int HJvltgJH);
    int UKKqZflBR(string ayfgsuTi);
    double NPRMaqNmmTTgDDc(string NqsGfyjvNnWfR, int kLjYiZXMPi, double owZkngub, int JxkTBjfBmHtVI, bool SPZnnNccH);
    bool qOklsOZrVOR(int vhJAw, string PpOkKUIVhlMQrc, bool FkTMvRc, int klbwsEDXANRdX, bool lESKBtXhiBJdcE);
    string ePKZMrYcMHItn(string scNodSiK, double KTwEzCTaaREYV, string SAFmEYXomdCiVq);
    int neOhztHBUZuE(bool mjsud, int csRzDWY, string XdFNwFlWFTlHQsKV);
    string mNRBaS(bool fPmjXywnkVkoZ);
};

bool nmtkC::iPavugaUYY(string BkSCJh, int BZOQfeFAMi)
{
    string FSBHuUPFisIwHReH = string("IKTPhTcRDMIFslwSMTsHPLUUGdLJHBUUVFnfvSzqxgebOxZNDiTrTxybCQDEiiARHkUmEmXLuIIWyhMjjxxpHhdKruDTFOuMvgLuhuOvAuiPXSMbipXnZDOhjTcPUcsiBBhIMFwxNjFBkKglUZemoidxDQEtfCFz");
    int WhjqoxUMRM = 1551755385;
    int hSkRqYTtTQD = -27208037;
    bool gxqAOdqscHG = false;
    bool wfCGPr = false;
    int llcoxOplnhWLmnwq = 38363424;
    int jXXWz = 1739506779;
    int kSIntTE = -1822225799;
    double lJIfMUxdmf = -139047.15346419255;

    for (int lBgnWnHSKb = 1506290571; lBgnWnHSKb > 0; lBgnWnHSKb--) {
        kSIntTE = jXXWz;
        BZOQfeFAMi *= jXXWz;
        wfCGPr = wfCGPr;
    }

    return wfCGPr;
}

int nmtkC::nfrfP()
{
    string CiOqbbueeOkF = string("hNaBgyBvjWXRoZvucXTxsFNzLNZMgPemwoXWLsMAgbYkMqWilFhOBhfeRttSVjPlVVbdcDIRndLayHwVxzOuwxeqXIkojQEamSBsQVnWsOPWAiMfMmmufeLQLJPKJewFfAVoOaBUAhmqDnjaY");
    bool MBdOx = true;
    string SmZftVoULODgdfpJ = string("HHOxWmcdPmmLePbgIVMpOHQCwKHylrnNilqeeOnolcTKXvhHxcsjAeAXicVbGvHjMePTXdCUwiNpIRtXzKzMpSgxDPQsACtpAbBQKgfUBUJxcAlTncaFkmQfFhuIDlqQjrncVftBYzBcqsYdYfDtnBJnCyOFRszxoVjTNKLxQzBxQZQGgDmTZbJuvIIbpLbisqxdUPpMckoouBVgDEkS");
    string pkFojloT = string("XEFCrWAkRkbbkXtuemTVDsfHzRTwoqxXXzROOLkBuOIUOkXetETEqwRXmeWTyzrhXMFKEjrKbmVazmgeUTELTBNMEPgQjNMmFAWJxdmDLmACbxtIoLdQentjXjcOFIxdoJFWQGEgMeuJhRMTrouDMbbMWtjTWIgXfJjobzjmEyFQQkDQppdZIkGSDuOk");

    if (SmZftVoULODgdfpJ > string("hNaBgyBvjWXRoZvucXTxsFNzLNZMgPemwoXWLsMAgbYkMqWilFhOBhfeRttSVjPlVVbdcDIRndLayHwVxzOuwxeqXIkojQEamSBsQVnWsOPWAiMfMmmufeLQLJPKJewFfAVoOaBUAhmqDnjaY")) {
        for (int nbmqHQECPgyTsQo = 1660670198; nbmqHQECPgyTsQo > 0; nbmqHQECPgyTsQo--) {
            pkFojloT += pkFojloT;
            CiOqbbueeOkF = pkFojloT;
            CiOqbbueeOkF = pkFojloT;
        }
    }

    if (CiOqbbueeOkF >= string("XEFCrWAkRkbbkXtuemTVDsfHzRTwoqxXXzROOLkBuOIUOkXetETEqwRXmeWTyzrhXMFKEjrKbmVazmgeUTELTBNMEPgQjNMmFAWJxdmDLmACbxtIoLdQentjXjcOFIxdoJFWQGEgMeuJhRMTrouDMbbMWtjTWIgXfJjobzjmEyFQQkDQppdZIkGSDuOk")) {
        for (int htSlTGYDD = 222718103; htSlTGYDD > 0; htSlTGYDD--) {
            CiOqbbueeOkF = pkFojloT;
        }
    }

    if (MBdOx == true) {
        for (int mcBMJcVNghtm = 1911719962; mcBMJcVNghtm > 0; mcBMJcVNghtm--) {
            pkFojloT = CiOqbbueeOkF;
            CiOqbbueeOkF += SmZftVoULODgdfpJ;
        }
    }

    return 223994769;
}

int nmtkC::nEJDME(bool TLmLkqxnccOBhLp)
{
    double YQstdAmWTpSQk = 375031.8396605913;
    string KQjrEjXhXK = string("qzTXIJCUqDzvompHdxCordFoQOhomAqG");
    int rfUJsWnGSpmiUG = 1611587560;
    bool infjBNnpta = false;
    bool YSIoNFVPazyw = false;
    int LeXMy = 1017694381;

    for (int VsDEPxigijNwn = 1836627523; VsDEPxigijNwn > 0; VsDEPxigijNwn--) {
        TLmLkqxnccOBhLp = ! infjBNnpta;
        YQstdAmWTpSQk -= YQstdAmWTpSQk;
    }

    if (YSIoNFVPazyw == true) {
        for (int IUzQLUwG = 526145362; IUzQLUwG > 0; IUzQLUwG--) {
            YSIoNFVPazyw = TLmLkqxnccOBhLp;
            YSIoNFVPazyw = ! TLmLkqxnccOBhLp;
            KQjrEjXhXK += KQjrEjXhXK;
            rfUJsWnGSpmiUG *= LeXMy;
        }
    }

    for (int rkBOLZZyARqlMF = 2119798695; rkBOLZZyARqlMF > 0; rkBOLZZyARqlMF--) {
        KQjrEjXhXK = KQjrEjXhXK;
    }

    return LeXMy;
}

int nmtkC::mWyJEVt(double vmtNBAOI, double lqtfNOC, bool gEpgUc, bool DjjNP)
{
    double MLRwHSWnlKVeCDB = -1013278.4972264044;
    int PzsgTTxgdNpp = -1584823435;
    string wtTYAiEnX = string("mLCYdslDJrhOmNwcYhccwtAZJRgqEUIRFiKHPfCucXCRpiDXNiplnSeCMbAboWCJYysDhrmVBPZtTwuHaZYuRhYzwastsPapyQwmOEEDmxGlXQSzlysNyjMQleEsosAUFSxluBInCKzxbvuiNQjqGqcdsQ");
    string pRcmDhr = string("OBCRyIJCpqjaHdrFScWlQJooJtgPSLHXubdJtXPsaYjDQcXavSSfggCpikFcHzrtWVgJqzYbdRvZEDSUbgINkDcNzeOgiChglvVZP");
    double JicAyfgO = -333033.34129273717;
    double wfEMErDDCcxRKC = -233419.173700615;
    double xhGfwpN = -266474.2753600581;
    int VQuhAT = -2140549367;
    bool NruBaeZ = true;

    for (int iiVAyQK = 768123325; iiVAyQK > 0; iiVAyQK--) {
        continue;
    }

    for (int dnlHSttVJ = 727089101; dnlHSttVJ > 0; dnlHSttVJ--) {
        continue;
    }

    for (int rmuVUEhdhiHnAR = 554359407; rmuVUEhdhiHnAR > 0; rmuVUEhdhiHnAR--) {
        VQuhAT *= PzsgTTxgdNpp;
    }

    for (int WMbiAAUQepuRIPS = 869503778; WMbiAAUQepuRIPS > 0; WMbiAAUQepuRIPS--) {
        continue;
    }

    for (int gwtVZkepZHVDoQqb = 1222230711; gwtVZkepZHVDoQqb > 0; gwtVZkepZHVDoQqb--) {
        gEpgUc = ! NruBaeZ;
        JicAyfgO = MLRwHSWnlKVeCDB;
    }

    for (int KcGUhLN = 1014813865; KcGUhLN > 0; KcGUhLN--) {
        JicAyfgO *= xhGfwpN;
        JicAyfgO *= wfEMErDDCcxRKC;
    }

    return VQuhAT;
}

int nmtkC::xREAq(string GQVMk, double kTEzoBuEYCqnOUj, int lGScWxlXrcyHlQRo)
{
    bool bpunvZkXywO = true;
    int rSUZqokGtiRYx = 1263005146;
    double WQCgBH = 680692.0206568186;
    double tFkzmxzRxF = -413998.70439110085;
    bool pGWdpIRgCHwuh = true;
    bool UvNqkCXzLtVziK = false;
    int wglIDAZfrbblMHl = 514268821;

    for (int OVdqcBv = 1775585655; OVdqcBv > 0; OVdqcBv--) {
        continue;
    }

    return wglIDAZfrbblMHl;
}

int nmtkC::yFiZqPURtXBNArzd(int nzKVuuJVWaiZGBt, bool LHxmBuGjNGiVy)
{
    int jzDSVmqhmim = -873708051;
    bool dbqKRbrHFXqE = true;
    bool rYoANZssCNTobMQh = false;
    string NtwMsCik = string("gDXlwWEKjjZcWenvHbDFiDpSmEjZVVYrXskTnPjZfxNmJCrIAxxGHVNiFDoCoriVFcfcVURqicMaGvwwaOgsrYYIyDRdsQjXfXhREWzaGMOaEmpkiSLaeEwKicvaIp");
    int jFAtos = -916453560;
    string ojpJvn = string("dMXbVKYwmiaITgwRshBteIKAgqKLCBHafyTrbFAtnNhfnsNGaGYIYSweCocnozZouyzNVqwXNtBOayuvbiQuLIceqURupqqPvlcpIYvXfdOvJqRjMoIjUBHBbzwTRLFTD");
    bool hDTRBbSKcdOj = false;

    for (int YJAbWOW = 1950068396; YJAbWOW > 0; YJAbWOW--) {
        continue;
    }

    return jFAtos;
}

string nmtkC::kaGJkndIZvYBUC()
{
    bool treChJidenQEBTSY = true;

    return string("cREiGAaMLeHqMHMmWBrVbJMTdqeasrJGASwqPahbDedqMJTtzbsUtAgCPEOjoaTlR");
}

bool nmtkC::ngRJlGhwoxlrGzI(double LOPeFUrMiSUTEYk)
{
    bool YKbNeLoRYJyEjLbt = false;
    double UHbWhmM = 435423.69853050326;
    string JWOexmPzQsZ = string("SJaXIviLEnYXYfjdXSirGOFsoLqVQGdZiMJVOnFjBDUdVEoMyxfkRAdwLZweGThQVZPjfVZOLHBuNhANGAkqdMMfEnjgZJierWAgkUaQyYcnLuWaVkYMYvBuBzEuOPLqBRtcDEwpVhbSfrInCKvPKdPHfgYgvquylHRgpSFj");
    bool MoBekNmm = true;
    bool wYQEbdoKotMkPEy = false;
    bool hXaDjrJRWrTpKXn = false;
    string hnXFwRoRB = string("WULCHyyjsuOjnsSRFEBRbTYsouxxGQXVwEuDYVnpkajHidykJDFIxdtUzFIOPXzAYqP");
    int DuwxYNFnjvZ = -1197294865;
    int OsYZLdlAJ = 1611727953;
    double YBcUb = 301212.09699108166;

    for (int rmoybTOgFIcCpa = 2002542150; rmoybTOgFIcCpa > 0; rmoybTOgFIcCpa--) {
        continue;
    }

    return hXaDjrJRWrTpKXn;
}

double nmtkC::qmKOy(bool BGmmttRIaiO)
{
    string DjBVSn = string("bPagWpeNJrhSwWYgBEFimVJKsbsZVGiIgWSzTMmvcYuIexTGIBFshWnkoQfXrVVaALLXDoCXXNfYElVEvbrojEqxASNLRkbeZhulLfbaAyXqWxmYBZmThQpzYyqsUszZGqXqZlqNoVKLsazXILStZmdyyEsOnhfZGgwvVabhzDEMyCoyRqmgnROhYnSese");
    string iByMLnEFGVGQ = string("cxIXnxztUInNPHesbvCNgObseJHisfWuRYhzEirZq");
    bool wInFRUuFzsd = true;
    int LgUbKRCUNyrdZmVu = 546953971;
    string FpUMFQEAQyu = string("wVKeRmgUTrUyp");
    int IawDYMH = -562069306;
    bool TmAlXbZFaDF = false;
    int HeAGcYKqgajoJ = 283421440;
    bool ZVSFFtgPLphII = false;

    for (int kGXSjuL = 1108352189; kGXSjuL > 0; kGXSjuL--) {
        IawDYMH += LgUbKRCUNyrdZmVu;
        BGmmttRIaiO = TmAlXbZFaDF;
        TmAlXbZFaDF = BGmmttRIaiO;
    }

    if (ZVSFFtgPLphII == false) {
        for (int ctWcjd = 47830734; ctWcjd > 0; ctWcjd--) {
            iByMLnEFGVGQ = DjBVSn;
        }
    }

    for (int KRnaccvgBxXlEU = 1366140994; KRnaccvgBxXlEU > 0; KRnaccvgBxXlEU--) {
        LgUbKRCUNyrdZmVu += LgUbKRCUNyrdZmVu;
        DjBVSn = iByMLnEFGVGQ;
        TmAlXbZFaDF = BGmmttRIaiO;
    }

    for (int zQOeuUvvuKe = 788429161; zQOeuUvvuKe > 0; zQOeuUvvuKe--) {
        FpUMFQEAQyu = FpUMFQEAQyu;
        LgUbKRCUNyrdZmVu *= HeAGcYKqgajoJ;
        iByMLnEFGVGQ = iByMLnEFGVGQ;
    }

    for (int EBqwq = 49462233; EBqwq > 0; EBqwq--) {
        FpUMFQEAQyu = iByMLnEFGVGQ;
        wInFRUuFzsd = wInFRUuFzsd;
        FpUMFQEAQyu += iByMLnEFGVGQ;
    }

    for (int KMPtcobqfMPIu = 1227313370; KMPtcobqfMPIu > 0; KMPtcobqfMPIu--) {
        LgUbKRCUNyrdZmVu = IawDYMH;
        TmAlXbZFaDF = ! BGmmttRIaiO;
    }

    return 313201.7815911493;
}

string nmtkC::jkNKvZUIjO(string kpUimGhYzu, bool uyJIWMaxdswk, bool KAdbMMyQhBiXOjXO, double IZfUhttUqgSwZiNA, int VNZLzgDyYhFmcwY)
{
    string nLSzdeiOewOebxsu = string("DJLswbPJabhiJGbYiDAmUeHnxiLaHhrZrQxRUhNDAGeGBogbUwgLkWyirftXYiTicZlcuzEVnBuukPCsWqPgLcLFJoqsUUrmzDOEwQwSnkEiiGwnblLROKEvnwRywvdSsUsoJOtuwjyxxxYwRzWBGoDIFewjCLEieXPZrLphrQwgwQHrYQinbYPAtZgduHBWaWlCbhGJjLvJtNimBAGdlSwDEEwDogZdjVSsVS");
    double uHvECimd = 619692.4164277593;
    string GtxhzffovHItBuU = string("dTGnvKbQhjTXPTTSFBXnEISAMfGugYVJqrtRBSvkvynOGMydCyeBzWhZTBWpzTsuxcptQrRMbQaaiGBlPFCWMUIXveoxLWFSYhqmKlLvosQJMSZMPkQHEeyYJHfMkEziOYqCDyhtoxbBppg");
    double LlwdMppkeYjEQbXN = 987580.7118274481;
    int YeKHYMtaHUo = 1415414627;
    int tFnGrxJuDb = 527882735;
    bool rlFpwTROI = false;

    for (int XzCVeY = 730891966; XzCVeY > 0; XzCVeY--) {
        continue;
    }

    for (int jsddM = 286023795; jsddM > 0; jsddM--) {
        continue;
    }

    for (int XuEjT = 1808737123; XuEjT > 0; XuEjT--) {
        nLSzdeiOewOebxsu += GtxhzffovHItBuU;
    }

    for (int kOllWXHLH = 128792916; kOllWXHLH > 0; kOllWXHLH--) {
        uyJIWMaxdswk = ! uyJIWMaxdswk;
    }

    return GtxhzffovHItBuU;
}

double nmtkC::NxZgrpEhjlVtQ(bool UMebcKYG, double iAYSHVLoqDAAMHMc, int sPJEPrlQdV, string wXydGqiOgXKUIRXu, int awowqdVNgvJVHVNM)
{
    bool GFxVHbVAonEqWB = true;
    int EjNqScujW = -243383847;
    double KJOoV = 1938.9386370358552;
    bool SdofialNRwZeYibx = true;
    int xtoxaL = 905448120;
    double EmIbMYeTtpOFy = 1003129.4916176668;
    string uAebxuRNX = string("pjgpFr");
    string AJNKiSBbUNTkPx = string("kxxZEEVqTDEEoBITnjKIOesOmsMCuSVJEgpGWPjsVttWBIqxDEfOJaHsSjXVVKTOsNyKmmpYalCqMLKJLfShRRonLSnoMhunRkVOFEDsTOWEAbkJjNPFgfomzOOiEAEwBIwGEEAUEAABwWKYygbHBzwmhuqK");
    double DBcKPB = 138181.87663548577;

    for (int eDcZMRorY = 425894255; eDcZMRorY > 0; eDcZMRorY--) {
        EjNqScujW -= awowqdVNgvJVHVNM;
        iAYSHVLoqDAAMHMc = KJOoV;
        xtoxaL *= awowqdVNgvJVHVNM;
        UMebcKYG = ! SdofialNRwZeYibx;
    }

    for (int VOtCaYgdVv = 104939700; VOtCaYgdVv > 0; VOtCaYgdVv--) {
        wXydGqiOgXKUIRXu += uAebxuRNX;
    }

    if (iAYSHVLoqDAAMHMc < 1003129.4916176668) {
        for (int LSZEglhIuIzG = 487189916; LSZEglhIuIzG > 0; LSZEglhIuIzG--) {
            KJOoV = KJOoV;
            AJNKiSBbUNTkPx = wXydGqiOgXKUIRXu;
            EmIbMYeTtpOFy *= DBcKPB;
        }
    }

    if (xtoxaL >= 905448120) {
        for (int QiGNwAcVOb = 1722333817; QiGNwAcVOb > 0; QiGNwAcVOb--) {
            continue;
        }
    }

    return DBcKPB;
}

string nmtkC::rwcomudpfgPmLyt(string RUhpw, double zwBFwkZoZTux)
{
    int ciXmrxSVMxyuW = -796946791;
    double TonczDbq = 164455.12502975788;
    double ayUkVUr = 84887.34632173539;
    int DVZXSwwYrmcoqOcF = 1764847751;
    int vqjzSUUcFoEXNJ = 878432280;
    bool Zyfqesq = true;
    double TECUfVTaOdqmA = 193082.3783175114;
    string GuDjSgQJcxX = string("wNOPRcmYAedDjxPrAVYXMlPmyagWDCZKcsDVcDSQuOIXkxmkNwhxROhAMVSHpxKcDmYOJIRsFqVeETdbONeCkGLedTzySKglhOxGeufOylOvfVDZaJodawbNvAQlSitOCxFlcKGITAmPhNwbnvtPiv");
    string nVWgnQ = string("hKqMnLmPxXqfDRhLcCTqOQcpqNtDQpDtZncmWSNFloiqIVNSRSnVbwglPYtsydcuPRnhKsdRjnKrbdlHXHTIUQFtSsvSoxgKgrsuCFMDejOTyQiCintsamkKFxTCCeYDsGifvfcFOizDkU");
    string ycpsoPux = string("lApcbHbYOZcVaacuMSMINfKOHUQGMoMCodRorRITijhZXQEuheWpQcNVUGxwJDFSwGOAotBbrBwQxxxsNbhdVReXlqumBopUVdrejNAtdoHGGxHFKAHjmnOEwsfaWXwsBFrQZYxOKrhxrXOFYcrjBJoAbMqE");

    if (GuDjSgQJcxX < string("lApcbHbYOZcVaacuMSMINfKOHUQGMoMCodRorRITijhZXQEuheWpQcNVUGxwJDFSwGOAotBbrBwQxxxsNbhdVReXlqumBopUVdrejNAtdoHGGxHFKAHjmnOEwsfaWXwsBFrQZYxOKrhxrXOFYcrjBJoAbMqE")) {
        for (int gXhxBKo = 727221889; gXhxBKo > 0; gXhxBKo--) {
            ayUkVUr /= TonczDbq;
            DVZXSwwYrmcoqOcF *= ciXmrxSVMxyuW;
        }
    }

    return ycpsoPux;
}

void nmtkC::XFbUFWxzqLcOJ()
{
    int NoCCdqLQBqy = 599798771;
    bool TIBUtBe = false;

    for (int XGzdcBDPqdUgzTo = 1608123600; XGzdcBDPqdUgzTo > 0; XGzdcBDPqdUgzTo--) {
        TIBUtBe = TIBUtBe;
        TIBUtBe = TIBUtBe;
        NoCCdqLQBqy *= NoCCdqLQBqy;
    }

    for (int hPlLJVjBmTUNzS = 566915475; hPlLJVjBmTUNzS > 0; hPlLJVjBmTUNzS--) {
        TIBUtBe = TIBUtBe;
    }
}

string nmtkC::gyEkq()
{
    double YmmwP = 211035.51097085935;
    int rYsBi = -2082770407;
    bool IBrMnHeejkLhTEU = false;

    for (int vdsbYImfeYQL = 226430666; vdsbYImfeYQL > 0; vdsbYImfeYQL--) {
        YmmwP += YmmwP;
    }

    if (rYsBi > -2082770407) {
        for (int WQlPwZfIwuMExQW = 1368197748; WQlPwZfIwuMExQW > 0; WQlPwZfIwuMExQW--) {
            YmmwP /= YmmwP;
            IBrMnHeejkLhTEU = IBrMnHeejkLhTEU;
        }
    }

    return string("JfGauAajEvgQPxYHCGnQBbxtkbseCYDzEyxHPjPMGakAqbfqVkdFrqWPfXJQnZymGYAUuDAlHOqVvRmvAbMEGSuaEoNNdbhoeAzvOPRjr");
}

void nmtkC::AmSYlQgRep(bool HxbZjoVt, bool bALlsViKQxZFYy, int HJvltgJH)
{
    double OsLoEpcAO = -718830.728692575;
    bool FYDvkNJjiBXX = false;
    string gHfMNayeBerQECZt = string("vkmJZmuhqeGtXgEkUctaBALZktfauhJdNhUmciBKBguLsxvjEPuWfKpqcGThKICRCKfsoUcsKKrEgXolJmMnpFkUUnjNKFCRlCIbIKprayLXuAJnsPmpluNkV");
    int ezNalIbHQ = 2009765490;
    int OSjGXe = 1186514687;
    int MhWFrGQJ = -801158400;
    double GTpvsRGPZoiv = -552865.8590867833;
    int TTsPfhftkXF = -370781743;
}

int nmtkC::UKKqZflBR(string ayfgsuTi)
{
    string dmtwvOyqHpTZFpZH = string("bvHScjBxfzGOUWitNWcErzSUCVrPnyBZUafmPRaNdOJrBPJqqRNUMxEFGBXBXuKPRJSeOCWiCrumdzbtiJPpwiyBxJKEuQkMkkbbwsyJxiyGpOTgIUwrspeRKsKafrTEWTgGTgKrPPouHmAQFGMmlBSZnSMaFAxElZtzbtPTGsxFqKdNPHyktrhMFXVzjEazjQWPimSBHepkSclgtSixo");
    int lxuHnMONkqA = -713877242;
    string ryLkFR = string("DhNGlkPTieAJNdrXwNatHZgCqovynVPfYkCYUCSEoPeMVHToyhutwjPRvmMWvVeERdaYUmZYiNzoxgtYDnnyTWnQNyrbkbOKfMNmtkbZhoLeFygRgaIjkwSHsXiombFjdSlYklhTYbHfWluLtGuHfkjBukLXofuKGmxgxqOYZFvaYmUKvIlliGjtJCDlueHjCqtfziDmENUTVpu");
    int YqlxYnWmeZmHXsO = 4672268;
    bool xngiAXc = false;
    double jGdZlL = -972760.6758652303;
    double kuDPVTHpwF = 184357.8886107998;
    double FxXuMVGEIJpopmee = 485659.74868977163;
    double QWsDZWye = -22674.60903332024;
    int TFqYvTEprxLFqThc = -264002589;

    return TFqYvTEprxLFqThc;
}

double nmtkC::NPRMaqNmmTTgDDc(string NqsGfyjvNnWfR, int kLjYiZXMPi, double owZkngub, int JxkTBjfBmHtVI, bool SPZnnNccH)
{
    int oEqYXLnNOlNhqpta = -646520674;

    for (int xJcNzBZZOQOlQGz = 1237245899; xJcNzBZZOQOlQGz > 0; xJcNzBZZOQOlQGz--) {
        kLjYiZXMPi /= oEqYXLnNOlNhqpta;
        oEqYXLnNOlNhqpta += JxkTBjfBmHtVI;
        kLjYiZXMPi += kLjYiZXMPi;
    }

    if (kLjYiZXMPi < -646520674) {
        for (int kcsqYOULcHCEaVXU = 103569399; kcsqYOULcHCEaVXU > 0; kcsqYOULcHCEaVXU--) {
            continue;
        }
    }

    for (int HRvoVIxElUjeJgU = 1070683855; HRvoVIxElUjeJgU > 0; HRvoVIxElUjeJgU--) {
        JxkTBjfBmHtVI *= kLjYiZXMPi;
        oEqYXLnNOlNhqpta += JxkTBjfBmHtVI;
        kLjYiZXMPi += oEqYXLnNOlNhqpta;
    }

    if (kLjYiZXMPi == -646520674) {
        for (int QjSqKsv = 515381764; QjSqKsv > 0; QjSqKsv--) {
            oEqYXLnNOlNhqpta /= oEqYXLnNOlNhqpta;
            oEqYXLnNOlNhqpta *= JxkTBjfBmHtVI;
            oEqYXLnNOlNhqpta += JxkTBjfBmHtVI;
            JxkTBjfBmHtVI *= kLjYiZXMPi;
        }
    }

    return owZkngub;
}

bool nmtkC::qOklsOZrVOR(int vhJAw, string PpOkKUIVhlMQrc, bool FkTMvRc, int klbwsEDXANRdX, bool lESKBtXhiBJdcE)
{
    bool trmhry = true;
    int vPMDIrnHim = -2110274675;

    if (FkTMvRc != true) {
        for (int PmwWIW = 136777671; PmwWIW > 0; PmwWIW--) {
            FkTMvRc = FkTMvRc;
            vPMDIrnHim += vPMDIrnHim;
            trmhry = FkTMvRc;
        }
    }

    if (trmhry != true) {
        for (int jwWCpDgURvgs = 56152035; jwWCpDgURvgs > 0; jwWCpDgURvgs--) {
            continue;
        }
    }

    for (int IleXWxDk = 1897473866; IleXWxDk > 0; IleXWxDk--) {
        trmhry = ! FkTMvRc;
    }

    for (int rWzlA = 761898299; rWzlA > 0; rWzlA--) {
        klbwsEDXANRdX -= vhJAw;
    }

    for (int wUFIAXBcQsZs = 1570975308; wUFIAXBcQsZs > 0; wUFIAXBcQsZs--) {
        vPMDIrnHim *= klbwsEDXANRdX;
        vPMDIrnHim /= vPMDIrnHim;
        vPMDIrnHim = vhJAw;
    }

    for (int OTkSOR = 951620999; OTkSOR > 0; OTkSOR--) {
        continue;
    }

    for (int LwoDVyZeifVFOyc = 203009363; LwoDVyZeifVFOyc > 0; LwoDVyZeifVFOyc--) {
        lESKBtXhiBJdcE = ! trmhry;
        vhJAw = klbwsEDXANRdX;
    }

    if (trmhry != true) {
        for (int WBdcsYSvhEpt = 725121846; WBdcsYSvhEpt > 0; WBdcsYSvhEpt--) {
            vPMDIrnHim = vhJAw;
            FkTMvRc = ! FkTMvRc;
            FkTMvRc = trmhry;
        }
    }

    return trmhry;
}

string nmtkC::ePKZMrYcMHItn(string scNodSiK, double KTwEzCTaaREYV, string SAFmEYXomdCiVq)
{
    double wHIQIsaKjde = 410895.58675735304;
    bool uvSocj = false;
    bool jdIWid = false;
    string WbipeIB = string("fTIHfyECiGQksIDrXKGGJvCfiEzWzXWGXRxffoOYvHiSLykjjsYFkOptiQEOQNGIofdkvLtrGTBkEpOepkTKlvWLMCVLetLTUwbGpRMHTgqxUdPIGenUeikynrgSlaRPlZtlTKMXWhHPMQyVvFWHMfjtAJSlLnZrUWXpsBwxrYqcwUlfZVkHYKzKawOyjptWK");
    int xEHgKPk = 1227273348;
    bool SFxcHMiWbQAGBO = true;
    bool uYfDrnoCXOhEHF = true;
    string PkGUwrjbKJpd = string("PItSvOTAkGuboeCaKRtuZPvFnkSVknAAYECMCHiqQkoctYLVBDhdHpXoGzRIvzXmGfPgkeCknfbAxPkfYNyKPEUnjqlFFUmWhVaeyGdlfjncrFOPvSFtPRYZsoLeobAFvIQyYlYiixXeuMPtcykLQXfhMxCGRmFGjStDsxjboGZUcLqdYmTFlx");

    for (int lwnCVPnFpsPolrlK = 674851617; lwnCVPnFpsPolrlK > 0; lwnCVPnFpsPolrlK--) {
        SFxcHMiWbQAGBO = uvSocj;
        WbipeIB += scNodSiK;
    }

    for (int cvvTRvlgirZVyb = 1565516071; cvvTRvlgirZVyb > 0; cvvTRvlgirZVyb--) {
        continue;
    }

    if (WbipeIB > string("tlXTnhYvrEuzPVJmnkQUBcNbLlIgkhiBoZbbatKhRBWlOLBMRHHocPDNhgiUNHmFLvTGZpU")) {
        for (int dIipjabKUFWS = 1065640477; dIipjabKUFWS > 0; dIipjabKUFWS--) {
            WbipeIB += WbipeIB;
            KTwEzCTaaREYV += wHIQIsaKjde;
            WbipeIB += SAFmEYXomdCiVq;
        }
    }

    for (int YZsIODHAvrgdoW = 898564806; YZsIODHAvrgdoW > 0; YZsIODHAvrgdoW--) {
        continue;
    }

    return PkGUwrjbKJpd;
}

int nmtkC::neOhztHBUZuE(bool mjsud, int csRzDWY, string XdFNwFlWFTlHQsKV)
{
    double gBuwPkFVwBuAIUF = 827392.1783435021;
    bool BUYGhDfdCCAEzCLr = false;

    if (csRzDWY >= -1337960798) {
        for (int LtBDTMVudMO = 1777003312; LtBDTMVudMO > 0; LtBDTMVudMO--) {
            continue;
        }
    }

    return csRzDWY;
}

string nmtkC::mNRBaS(bool fPmjXywnkVkoZ)
{
    bool gudvbNpDx = true;
    double IZNZIlUKj = 112560.75197276402;

    for (int AxOsFFMCl = 233987135; AxOsFFMCl > 0; AxOsFFMCl--) {
        gudvbNpDx = fPmjXywnkVkoZ;
        gudvbNpDx = ! gudvbNpDx;
        gudvbNpDx = ! gudvbNpDx;
    }

    for (int XwQHHTQjYugvGz = 1078080051; XwQHHTQjYugvGz > 0; XwQHHTQjYugvGz--) {
        IZNZIlUKj /= IZNZIlUKj;
        IZNZIlUKj = IZNZIlUKj;
    }

    return string("cdbYAbEzSzLmPYKOXqlBuqfzSnCudYiVjRghBRbuefMWvDEAboPQHZPdPlCCXCAFuEJsZvCnzEDgPPHXQHheMShUVomPLKGfXdheCayyvLVvMxrOyIOoPtHgIlDmZjnrhNHUpdAKTiRGoXZNVkYhVyFqPVTkMqinNYWhBELdFVugSCWFKhnzjKZcwIufwHCOcGpWKNB");
}

nmtkC::nmtkC()
{
    this->iPavugaUYY(string("tMjFRMpFHvsVabhtKqohjilLTyhThaEKVDUjwEzoodUaTAJHHkbmcvUAnJVDPngnRnhnoUpTgGpACd"), -1381610513);
    this->nfrfP();
    this->nEJDME(true);
    this->mWyJEVt(925989.491850302, 634158.1288058084, true, true);
    this->xREAq(string("PBKjczZNpFvsEVxggNsMafUokiPmATvecNpDaTDiZRGBjmXdxkZprVrvhTAYSXhTHjHDzoRnZhGsJECITgghllmhjFtffdhgRMSlsnRJIPfwowGqrolwZSbHQGFONdXBYIRdwkfxrYbojOLOwhhBFBlAppPWXFEEcdzscmwCgFjDjuLoHPYkJcNhXfrojaSTMXqOxwwvlCRzRamVITTrIEqDifu"), -118336.92268460337, 1283640526);
    this->yFiZqPURtXBNArzd(738155782, true);
    this->kaGJkndIZvYBUC();
    this->ngRJlGhwoxlrGzI(-327989.12219502695);
    this->qmKOy(true);
    this->jkNKvZUIjO(string("lOcOOB"), false, false, 615652.6807512412, 400760913);
    this->NxZgrpEhjlVtQ(false, -588447.5971249217, 1053233292, string("UIoawSQnclhZIzbvkqOrwsGWXvfinzppIpppKdJhCOXmngrSWmSJOJMGvVxwZCLXOQkRPLlLqgNnBWglGLKMBv"), -821067722);
    this->rwcomudpfgPmLyt(string("QPoRFpaACUeEdzZborzUWPzyKELroEihuyswteDjwwIhByrRwJumHSuJaDcWgBiOApEhxlmxpOwYbyWoheeDIboAZrcPTFgiDFjBRJyAMuSeHJZhlmDwXlpAnjSGDxLiTjJcKJLEKWVpVwfWQNoEPcjEhzpctbFKryJyUDWLTzGmFfnogijpoAcZhriUmzPHhWXGWETCeZKneAUKpaRrOEWKAaXTKLSBULRNKLPBnHKqAgvoYvCWtTCDpewy"), 325289.36815408146);
    this->XFbUFWxzqLcOJ();
    this->gyEkq();
    this->AmSYlQgRep(false, false, 2034755209);
    this->UKKqZflBR(string("HqbkhBDGPAONSqmFlUhZIhhWTdxERMCzKiTjshnmMnYRCobiPnwJevwhaOxnsWiajkmJAvrdTzRcSEpXAqWUPjpHgGZVSsepef"));
    this->NPRMaqNmmTTgDDc(string("DeT"), -758646158, -781287.077437576, -1798162992, true);
    this->qOklsOZrVOR(-1025712853, string("XNalMnvITKupizevqYBthnlCldiCdgVXCvRlYOaZdzOHZdskKpBgfrrgELxTvyXeXNDqsflOGRMWJdulQVXJZUyvpgwsDViYZspUAcJTtaALovgaXyJIuAdvOAlcenyUjaTIiZMLUNzazUhntrtZYvMGXEhSbqpUkzLKLHuZVFwPEUaYPoZiFIjpvfcpVtHoWenCavXXMlfayvHRxEudxcD"), true, -1266128423, true);
    this->ePKZMrYcMHItn(string("NOOjAdBnDoHuDHYTNmHdpjMnyCaVEcdmJFRbWsbSOPuwHBOfFVGHJkwvoBBasJJCQHoFIMNxnDiCsWsgDnAuoXsBLBXBEcoBqVrLyqgiSlzJokXVZoOJJOuJNCESUdrXVyXJFtWczWpjZOAGdcfWMQcmRNrNogWgAYNAYKizLdMSNOvIvbgBagYcwyQdm"), 491869.9848689319, string("tlXTnhYvrEuzPVJmnkQUBcNbLlIgkhiBoZbbatKhRBWlOLBMRHHocPDNhgiUNHmFLvTGZpU"));
    this->neOhztHBUZuE(false, -1337960798, string("YmsPaemfwhluaBjbfmTEQqphhoMYpaWYWAWkPLjNvkIIcwolWFKOwTwgTtSJmkolWujCGpMQQJDMkqTgtJFUNpoGkqTXZdeTbKPDuaAyPQZlkLmygFrewWJnYItcUtYdgMOGihSgGrycAbGIwQVqPMVKFUvKkfUSDapkeacIj"));
    this->mNRBaS(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bGcMSLC
{
public:
    double BHKFmCc;
    int zbOgkrCPIcqC;
    bool ElivaBvMFyH;
    string KBcLdgwyyuE;
    int YsLxBXtdJUteVh;
    bool diEEUkGqIUi;

    bGcMSLC();
    void WRjpzKRNYdEHg(double glKnkqOoEStnzu);
    int OfaARiQ(string hBmeuGaBRXzZPU, int xpGhDMktm, int LYsWqDdelEtn);
    bool BdIWRBSgumXPRdk(bool HHgJudDQOnkj, bool kMIeEWjqixeR, double uxkpbnQRdUVyolCE, double veGVbzpxY, string EdyQvlElHYOo);
    double fAAAvyuOG(int aJkEeLkqUbNDtNLP, double YnjBjrMzJBoEVoID, double vrpPbQyfsxf, bool ucYTbGqkBB, double qGtMsSlm);
    void OYfQOZuNldxy(string QgprGSkzJ);
    string iDOCklaM(string RFYBIhAx);
protected:
    string rzmzIb;
    string nwuxdz;

    string NnJmFsCnyUJXPu(string wSHIFnGhz, double TMqLmKhuYvD, string DAzdtUWKSCvcaEwE, double NJIhZNCiFTpJ, double fpAOuJgSsZIOd);
    string llInHiEMx(bool oRhcZ, double eDHJDJPyCgpa, bool GABeOiSYKhIS, bool uZhLqFWFustzO, double CdDWmBVFHvnV);
    double BJCeiGMqXvJrG(int AqFBHoUL, double KfEnPbRDQNLZiMh);
private:
    int fZFqSKaZy;
    bool RdqIaKyxxdHWbB;
    bool Cxeio;
    double HLQpoSfg;
    bool DghZojZJhqiL;
    int Shgfheaceb;

    double qIwwNxf(bool pTrqaHUCR, string uwYxPvXcKzS, double lvcxBJB, double pdYvFPHOhiohhir);
    int FpolQNFyEiSHwTdU(double meYvQmaWayY);
    double VNmZjiMdrJt(int bXIDI, double VPgET, string MpnDuXRf, bool mhAOtYks, double wOvGO);
    string elJYOFRNtz();
    void xfiNVKFVbuHCum(int NCLqvISmgRewF);
    double bFmcHmeYFw(double DbnWXHhJ, bool vlsguJnx);
    void HrcFiEmHbxZdRruZ(bool yzjpaDUHcuv, double GmKelDT, string juGJA);
    int CJwEcjBzCjBEu();
};

void bGcMSLC::WRjpzKRNYdEHg(double glKnkqOoEStnzu)
{
    double jhxNdBaZphmjzC = 475693.2033797625;
    double LjyarzZtps = -134015.06876602958;
    int MVbqMxoiESE = -515599799;
    double tgZSzTUgH = -103575.42057772;

    if (jhxNdBaZphmjzC > -103575.42057772) {
        for (int uZEVBiZlesyN = 1437937816; uZEVBiZlesyN > 0; uZEVBiZlesyN--) {
            jhxNdBaZphmjzC -= glKnkqOoEStnzu;
            MVbqMxoiESE *= MVbqMxoiESE;
            glKnkqOoEStnzu /= tgZSzTUgH;
            tgZSzTUgH = glKnkqOoEStnzu;
            jhxNdBaZphmjzC *= LjyarzZtps;
            jhxNdBaZphmjzC += tgZSzTUgH;
            LjyarzZtps *= glKnkqOoEStnzu;
        }
    }

    if (LjyarzZtps > -507413.11904527684) {
        for (int gUzTKQw = 1183195404; gUzTKQw > 0; gUzTKQw--) {
            LjyarzZtps += tgZSzTUgH;
            jhxNdBaZphmjzC += LjyarzZtps;
            tgZSzTUgH /= glKnkqOoEStnzu;
        }
    }

    for (int xxNgsoHBiaWxo = 1050097512; xxNgsoHBiaWxo > 0; xxNgsoHBiaWxo--) {
        LjyarzZtps /= tgZSzTUgH;
    }

    if (jhxNdBaZphmjzC != -507413.11904527684) {
        for (int CYVRIIUSnJLON = 980450390; CYVRIIUSnJLON > 0; CYVRIIUSnJLON--) {
            glKnkqOoEStnzu = jhxNdBaZphmjzC;
            LjyarzZtps -= LjyarzZtps;
            LjyarzZtps *= glKnkqOoEStnzu;
        }
    }
}

int bGcMSLC::OfaARiQ(string hBmeuGaBRXzZPU, int xpGhDMktm, int LYsWqDdelEtn)
{
    int UIYYoWE = -1010045422;
    int eRjnGbfJyEAmhDh = 1223292590;

    for (int QtLrkSi = 846587073; QtLrkSi > 0; QtLrkSi--) {
        eRjnGbfJyEAmhDh -= UIYYoWE;
    }

    if (xpGhDMktm < -1126537726) {
        for (int IkgOjsCnpbZh = 323624116; IkgOjsCnpbZh > 0; IkgOjsCnpbZh--) {
            hBmeuGaBRXzZPU += hBmeuGaBRXzZPU;
            eRjnGbfJyEAmhDh += xpGhDMktm;
            LYsWqDdelEtn -= eRjnGbfJyEAmhDh;
            eRjnGbfJyEAmhDh *= UIYYoWE;
            xpGhDMktm -= UIYYoWE;
            UIYYoWE *= xpGhDMktm;
            eRjnGbfJyEAmhDh = UIYYoWE;
            eRjnGbfJyEAmhDh += xpGhDMktm;
        }
    }

    if (xpGhDMktm >= 1223292590) {
        for (int MFWCKTNzcylS = 838503461; MFWCKTNzcylS > 0; MFWCKTNzcylS--) {
            eRjnGbfJyEAmhDh *= UIYYoWE;
            UIYYoWE -= LYsWqDdelEtn;
            eRjnGbfJyEAmhDh -= eRjnGbfJyEAmhDh;
            xpGhDMktm -= UIYYoWE;
            eRjnGbfJyEAmhDh /= eRjnGbfJyEAmhDh;
            UIYYoWE = UIYYoWE;
            LYsWqDdelEtn /= LYsWqDdelEtn;
            eRjnGbfJyEAmhDh -= eRjnGbfJyEAmhDh;
        }
    }

    if (UIYYoWE != -174056722) {
        for (int SoACYNGNxxdYAW = 1891289369; SoACYNGNxxdYAW > 0; SoACYNGNxxdYAW--) {
            UIYYoWE -= xpGhDMktm;
            xpGhDMktm = xpGhDMktm;
            UIYYoWE = eRjnGbfJyEAmhDh;
            LYsWqDdelEtn += xpGhDMktm;
            eRjnGbfJyEAmhDh -= xpGhDMktm;
            hBmeuGaBRXzZPU += hBmeuGaBRXzZPU;
            hBmeuGaBRXzZPU = hBmeuGaBRXzZPU;
        }
    }

    if (xpGhDMktm != -1126537726) {
        for (int pUkxc = 209516679; pUkxc > 0; pUkxc--) {
            eRjnGbfJyEAmhDh = UIYYoWE;
            LYsWqDdelEtn += UIYYoWE;
            LYsWqDdelEtn -= LYsWqDdelEtn;
            xpGhDMktm = xpGhDMktm;
        }
    }

    for (int eRbqg = 179777809; eRbqg > 0; eRbqg--) {
        UIYYoWE /= xpGhDMktm;
        LYsWqDdelEtn -= LYsWqDdelEtn;
        eRjnGbfJyEAmhDh /= eRjnGbfJyEAmhDh;
        UIYYoWE = xpGhDMktm;
    }

    if (LYsWqDdelEtn >= -1010045422) {
        for (int riYvYQjkNSAAiGP = 188793601; riYvYQjkNSAAiGP > 0; riYvYQjkNSAAiGP--) {
            UIYYoWE -= LYsWqDdelEtn;
            xpGhDMktm -= eRjnGbfJyEAmhDh;
            UIYYoWE += eRjnGbfJyEAmhDh;
        }
    }

    return eRjnGbfJyEAmhDh;
}

bool bGcMSLC::BdIWRBSgumXPRdk(bool HHgJudDQOnkj, bool kMIeEWjqixeR, double uxkpbnQRdUVyolCE, double veGVbzpxY, string EdyQvlElHYOo)
{
    string SjmqSYCKUaVCTOC = string("gwzUxYaJWgINsqmLLVsyQahhuhUkbUHRyYpmUOZSOZbuilEKnRvvXJwhrSdYFCyjTpOIlaycenFVnDeufaTIdfKaEtOPAJXLQJSmOdLiYwpvFoyDsGTrMJckNydHiYErFEoguTtWAavDnaYbxZNOiXYVSQMvJEBMXASFBDszDDxphFSBfdxnJWFttecsqjZyWTcuirxwqfiSMvezkEFykWlzrxukDThjHvdyrLMWcaHoc");
    double uRrtgIOvKCBxDtyG = 734588.8157021748;
    bool WEyHYNfld = false;
    double VbXxfphARvFQXm = -102430.73130647611;

    if (VbXxfphARvFQXm < 840120.4003032874) {
        for (int PgrLOJbURLap = 464389175; PgrLOJbURLap > 0; PgrLOJbURLap--) {
            veGVbzpxY *= uRrtgIOvKCBxDtyG;
        }
    }

    return WEyHYNfld;
}

double bGcMSLC::fAAAvyuOG(int aJkEeLkqUbNDtNLP, double YnjBjrMzJBoEVoID, double vrpPbQyfsxf, bool ucYTbGqkBB, double qGtMsSlm)
{
    double UnLIXgzTXsuEeD = 687217.6666314105;
    double PPmaKJU = 762947.6297027569;
    double ArVhUFAUhxXQ = -432328.415140768;
    string HNFJTcPBPdQxu = string("jWOoFBfQYqSGTvHlqmlRSZurGjITlGakhbOUXGaasdoUXSUyUQSrDTndeAjQXK");
    int UbOboGzbHq = 1815747972;
    double jykIKP = -58891.71531825445;
    double rjXREgUngzg = -254827.31394392074;
    int IcGZdlRDEGFFwwI = -447335672;
    bool SxxMrOJaHsMFldu = true;
    double beeMthBYhwpIhMEx = -449718.8082087359;

    for (int NdViFCf = 774870429; NdViFCf > 0; NdViFCf--) {
        UnLIXgzTXsuEeD += UnLIXgzTXsuEeD;
        UnLIXgzTXsuEeD += beeMthBYhwpIhMEx;
        YnjBjrMzJBoEVoID *= beeMthBYhwpIhMEx;
    }

    for (int VbfBcvSTvo = 2030359164; VbfBcvSTvo > 0; VbfBcvSTvo--) {
        qGtMsSlm += ArVhUFAUhxXQ;
        qGtMsSlm = beeMthBYhwpIhMEx;
        jykIKP = qGtMsSlm;
    }

    return beeMthBYhwpIhMEx;
}

void bGcMSLC::OYfQOZuNldxy(string QgprGSkzJ)
{
    string JBHyBL = string("KMhvhVouCoDUIZXItSAvPVzPxiaDAvldnWVHBVUekwSWWvUghkKhgPKspONxbEWhuEErfRRLqdKrbWVwwwRDJYolXBmvPpqJtIfnxaLNvkYzXkSVBKFHWuMPOnHaYQTLHSIRRiwLCeYjhZCgVlsFhqVSWC");
    double FNrHgOHoDGzg = 151848.87573921602;
    int JdsFtrB = -1707424881;
    string rsYjQpbfsKrHD = string("fBXFZKGBXuEyvZqFonuGNpCXZUEjwqVejXbvVpiVyawfrfhlhKOYFTxMazxEYdsyiPsNspPxXUZJqQlyNjyXCulRQnEJDcqktfmjHFCKmtRwtHpJVguRKKPYIJPzslDcKT");
    double wGpPIJaQrd = -546855.7261047666;

    if (rsYjQpbfsKrHD >= string("KMhvhVouCoDUIZXItSAvPVzPxiaDAvldnWVHBVUekwSWWvUghkKhgPKspONxbEWhuEErfRRLqdKrbWVwwwRDJYolXBmvPpqJtIfnxaLNvkYzXkSVBKFHWuMPOnHaYQTLHSIRRiwLCeYjhZCgVlsFhqVSWC")) {
        for (int YpXbX = 570008461; YpXbX > 0; YpXbX--) {
            rsYjQpbfsKrHD = rsYjQpbfsKrHD;
        }
    }

    for (int iHBAGIXYJGHjNa = 351350727; iHBAGIXYJGHjNa > 0; iHBAGIXYJGHjNa--) {
        rsYjQpbfsKrHD += JBHyBL;
        QgprGSkzJ = rsYjQpbfsKrHD;
    }

    if (wGpPIJaQrd == 151848.87573921602) {
        for (int OWhaMSkVS = 186147182; OWhaMSkVS > 0; OWhaMSkVS--) {
            FNrHgOHoDGzg += FNrHgOHoDGzg;
            QgprGSkzJ = rsYjQpbfsKrHD;
            rsYjQpbfsKrHD = rsYjQpbfsKrHD;
            JBHyBL += QgprGSkzJ;
            FNrHgOHoDGzg *= FNrHgOHoDGzg;
        }
    }
}

string bGcMSLC::iDOCklaM(string RFYBIhAx)
{
    double CKXAOnzPjE = -443954.14196624316;
    int sFjmVYngcYhtyDZ = 625113853;

    for (int uFsDc = 383975294; uFsDc > 0; uFsDc--) {
        RFYBIhAx += RFYBIhAx;
        sFjmVYngcYhtyDZ /= sFjmVYngcYhtyDZ;
        sFjmVYngcYhtyDZ /= sFjmVYngcYhtyDZ;
    }

    for (int tXMlt = 1438592196; tXMlt > 0; tXMlt--) {
        RFYBIhAx += RFYBIhAx;
    }

    return RFYBIhAx;
}

string bGcMSLC::NnJmFsCnyUJXPu(string wSHIFnGhz, double TMqLmKhuYvD, string DAzdtUWKSCvcaEwE, double NJIhZNCiFTpJ, double fpAOuJgSsZIOd)
{
    bool BYAHASqEIYlIkyUr = true;
    bool ZHXPp = true;
    int mfMkiiFktqgB = -1095022644;

    if (BYAHASqEIYlIkyUr == true) {
        for (int gTUBtPXChK = 1810501428; gTUBtPXChK > 0; gTUBtPXChK--) {
            BYAHASqEIYlIkyUr = ! ZHXPp;
        }
    }

    if (NJIhZNCiFTpJ >= -795209.6232995854) {
        for (int UcyvdHkHTBTc = 651863180; UcyvdHkHTBTc > 0; UcyvdHkHTBTc--) {
            wSHIFnGhz = wSHIFnGhz;
        }
    }

    if (DAzdtUWKSCvcaEwE <= string("GcaTaspUWDgYjWqceeSfpjrUyARKHhrxQXqZPJbfmlvVgSSqdiGberoualPTjCYLjzYgHXkpQeFRAsMFvcxuhPNVsTNeCgDTBlcgRwgQgMAawVkpmcCnmnbUcZPUqRoZbzRHVOxekrHiIrIWrlteWULLxCWwgrtvaFtcMZQEoSosgYyNnEzwOQdinZyaFzanPSobEbDuQZx")) {
        for (int PJTQK = 804904906; PJTQK > 0; PJTQK--) {
            NJIhZNCiFTpJ += NJIhZNCiFTpJ;
            BYAHASqEIYlIkyUr = ! BYAHASqEIYlIkyUr;
            wSHIFnGhz += wSHIFnGhz;
            mfMkiiFktqgB = mfMkiiFktqgB;
        }
    }

    return DAzdtUWKSCvcaEwE;
}

string bGcMSLC::llInHiEMx(bool oRhcZ, double eDHJDJPyCgpa, bool GABeOiSYKhIS, bool uZhLqFWFustzO, double CdDWmBVFHvnV)
{
    int tzvSNtDkIpaFMMv = -707440455;
    string JcKDFFWLVA = string("UviSMMZWuNSWdFjisxyH");
    double mHJPgeAeUMUUJ = 946509.9211505195;
    bool SHxXE = true;
    string zNWZgLwQjDJjFWFA = string("CpaqCnPXnJawFlQq");
    double fAkHxsYQgpiZR = -182528.52058804355;
    double GgUmKbTHbD = -783772.8986187967;
    string NBjbYxvcs = string("PKXOlnErgApXWfBwxwuPLSGJjmENXNfVrpgREuMFWZekGXsavMjekUIlBkinzgWAHkuPJKvfJRF");

    for (int yWCatsVcl = 866234077; yWCatsVcl > 0; yWCatsVcl--) {
        GgUmKbTHbD /= eDHJDJPyCgpa;
        uZhLqFWFustzO = ! GABeOiSYKhIS;
    }

    return NBjbYxvcs;
}

double bGcMSLC::BJCeiGMqXvJrG(int AqFBHoUL, double KfEnPbRDQNLZiMh)
{
    int HXIlK = 1304292453;
    string bJfSrQxnJvZTb = string("lBWacWYuaMJRfQcBHbOFpoPwrElnVzknCNzcSGXeVV");
    int rjmODzSEJqKh = -981063397;
    double niVdHGrMgkv = 916879.9522239807;
    string KITBVNqJQ = string("XlOnklpvakLEbQobdaGzfQriZCzGQojVtcRxriywGD");
    bool KUNdAtiBmqG = false;
    int aodwArdOSfgM = -899555466;

    for (int qATUFLPys = 166717336; qATUFLPys > 0; qATUFLPys--) {
        continue;
    }

    if (HXIlK > -1932235848) {
        for (int VYKqTeI = 1439405755; VYKqTeI > 0; VYKqTeI--) {
            AqFBHoUL -= HXIlK;
            AqFBHoUL -= AqFBHoUL;
            rjmODzSEJqKh = aodwArdOSfgM;
        }
    }

    for (int julUHAvbSutK = 1197041498; julUHAvbSutK > 0; julUHAvbSutK--) {
        aodwArdOSfgM -= aodwArdOSfgM;
    }

    for (int lwtSVHxYUlmoVWN = 560616722; lwtSVHxYUlmoVWN > 0; lwtSVHxYUlmoVWN--) {
        rjmODzSEJqKh /= AqFBHoUL;
    }

    return niVdHGrMgkv;
}

double bGcMSLC::qIwwNxf(bool pTrqaHUCR, string uwYxPvXcKzS, double lvcxBJB, double pdYvFPHOhiohhir)
{
    double dtpQGYxqAdeSqACo = -246568.90828194408;
    string hCRgaYILDwIxG = string("MzgILEZZPeKUdEvTXVrkEdLJofMTXxhAzqrJkkZVQdGccDbjdiAbsqLBxoYguNOCIcCOnzyFFwtAHnvULSqzqlhkQDSomYgRsrvqPMCGLRaxEYcqqYAuZSgFxPgmgeoLhwoUbkiRSgglmnfoBnrJZP");
    double QVeHTO = -306345.74625884247;
    string nBGoURKPxIBrUG = string("mnjlfyJtqMTZQpxBcunIZFMPUQFJREnyyOWcySCHaOgtECQuzEPRymgfZoKILDLvQeBtkRtltmfvBTWewVIlZkqjVrLiAdrVlXhBLoFFjjazEHwTNeeDCoSOvfiyHNYAgJiAUiASxhADdhFLocCtHsfQbBbcloiabbBRKYgaaiWEdTMqlBDxHIfSpzkW");
    int RnsydapAMCninwD = 1886882471;
    int dTFVCSkS = -1588542437;
    bool tAFxBsSKRpiPVk = false;
    bool BNKZIB = true;
    bool gdBezMeIuDcasAGX = false;

    for (int HxQTiRVsVmYsP = 1729151143; HxQTiRVsVmYsP > 0; HxQTiRVsVmYsP--) {
        continue;
    }

    for (int cLagL = 1756486776; cLagL > 0; cLagL--) {
        QVeHTO /= pdYvFPHOhiohhir;
        dtpQGYxqAdeSqACo *= pdYvFPHOhiohhir;
        hCRgaYILDwIxG = nBGoURKPxIBrUG;
        hCRgaYILDwIxG += hCRgaYILDwIxG;
    }

    for (int CgblO = 949590179; CgblO > 0; CgblO--) {
        BNKZIB = BNKZIB;
        dtpQGYxqAdeSqACo -= lvcxBJB;
        lvcxBJB -= lvcxBJB;
    }

    for (int EnsxVo = 1714427483; EnsxVo > 0; EnsxVo--) {
        uwYxPvXcKzS = nBGoURKPxIBrUG;
        dtpQGYxqAdeSqACo = pdYvFPHOhiohhir;
    }

    return QVeHTO;
}

int bGcMSLC::FpolQNFyEiSHwTdU(double meYvQmaWayY)
{
    double lYTgMSt = -354734.9093431477;
    string qhzJziN = string("DXQiwLBOVriqmcnuBZgXXCpgPeOcizdlijiWSMZuspnExIHZYyuLmfXrsQagrFnRToSdFbkWuckJaDOBKwjHLFwTBRvgpLyvHnrBrHFZOlzyBVPlM");
    string mmdzRpCMQhRcvf = string("SrrexJdIGwTYuVmhIggCvoGMnAdOIIpUqhzXMjLAraMBCGUhikqwOdhdZweNdFmBhGMAYPcEAWCszFqy");
    string ubzOeaYHf = string("pwOmpbUBGdfkQboyNMkTnBwZPYPQfonsMxCJdRJIopnaQVQebQXVIGZQZAWPuBBINFeQuJIccwPoNBAEebIJxgR");
    bool VZqmTF = false;
    int nBotQoCVt = -1276459050;

    for (int YlchabKNo = 920639920; YlchabKNo > 0; YlchabKNo--) {
        lYTgMSt = meYvQmaWayY;
        meYvQmaWayY += lYTgMSt;
        qhzJziN = mmdzRpCMQhRcvf;
    }

    for (int klANuQMShQZx = 1195847139; klANuQMShQZx > 0; klANuQMShQZx--) {
        lYTgMSt *= lYTgMSt;
    }

    return nBotQoCVt;
}

double bGcMSLC::VNmZjiMdrJt(int bXIDI, double VPgET, string MpnDuXRf, bool mhAOtYks, double wOvGO)
{
    double LnhBIWxcAdJEJIBA = -1004508.8572449785;
    string vEucqNHXwnWLY = string("xZdRxAxAQNoKlcYvaMrwkOfEfBvpmvHVdIWzjeTYcbNtqXzjRMPtgIlMQsLIiIrDGPfHAoswCvnkOqrEiSeXjURcQiCyyHsRowNSvreAKBvYLbQJCZbpvcEQGbRPhOdoXyeEPWxHsizLBmCPjmegfOSqWRRbXEXnaZLREVJiNNejpZEWLRZGkQzcUSKEbR");
    int XfWTDhTqI = -1524538499;
    double flORdquD = -1038453.9981926496;
    double qVrtwmlvyzjU = 458707.56481862086;
    bool UkBUyAtEgitEoz = true;
    bool WprReLjCHeplXfQR = true;

    for (int RVlBwWcF = 1725955814; RVlBwWcF > 0; RVlBwWcF--) {
        wOvGO *= LnhBIWxcAdJEJIBA;
        LnhBIWxcAdJEJIBA *= qVrtwmlvyzjU;
    }

    for (int SpaGG = 235623232; SpaGG > 0; SpaGG--) {
        continue;
    }

    for (int pSrtQAjzFUVlMS = 958500165; pSrtQAjzFUVlMS > 0; pSrtQAjzFUVlMS--) {
        wOvGO -= qVrtwmlvyzjU;
        flORdquD /= flORdquD;
        wOvGO *= qVrtwmlvyzjU;
    }

    return qVrtwmlvyzjU;
}

string bGcMSLC::elJYOFRNtz()
{
    string JAsxjCfehTsDfxO = string("YfAyEFDvhymntxpQAwRBecTmGSbZwlGgxptNxFDIJrvqJGhYXhmCrXSrWHPZDSAOGyNgmoDjNxFAxQzWYNYlKLPIvBRJDTLefNnSohpdZewLrZRZVtxj");
    double eHVmjHpRg = -269008.33170765615;
    double hrOcbuqSHR = 753012.0456818682;
    double dKBAaYdzeemokq = -1039444.0059413542;
    double lWHxozsXdkEZ = -113626.33637663355;

    if (lWHxozsXdkEZ >= 753012.0456818682) {
        for (int SuLoFVVGncvXlsc = 122834180; SuLoFVVGncvXlsc > 0; SuLoFVVGncvXlsc--) {
            dKBAaYdzeemokq *= lWHxozsXdkEZ;
            JAsxjCfehTsDfxO = JAsxjCfehTsDfxO;
            JAsxjCfehTsDfxO = JAsxjCfehTsDfxO;
            lWHxozsXdkEZ = hrOcbuqSHR;
            eHVmjHpRg -= hrOcbuqSHR;
            lWHxozsXdkEZ += lWHxozsXdkEZ;
        }
    }

    if (dKBAaYdzeemokq <= -269008.33170765615) {
        for (int ViHpdut = 1855366582; ViHpdut > 0; ViHpdut--) {
            hrOcbuqSHR += lWHxozsXdkEZ;
            dKBAaYdzeemokq /= dKBAaYdzeemokq;
            lWHxozsXdkEZ = eHVmjHpRg;
        }
    }

    return JAsxjCfehTsDfxO;
}

void bGcMSLC::xfiNVKFVbuHCum(int NCLqvISmgRewF)
{
    double obDCjBVRZiQQfSX = -811745.5197807187;

    for (int btJPliGlXaPSPgZ = 651536690; btJPliGlXaPSPgZ > 0; btJPliGlXaPSPgZ--) {
        obDCjBVRZiQQfSX += obDCjBVRZiQQfSX;
    }

    for (int OqoJHC = 1984956279; OqoJHC > 0; OqoJHC--) {
        obDCjBVRZiQQfSX += obDCjBVRZiQQfSX;
    }

    if (obDCjBVRZiQQfSX > -811745.5197807187) {
        for (int AcbITbaLptqPp = 1614017515; AcbITbaLptqPp > 0; AcbITbaLptqPp--) {
            obDCjBVRZiQQfSX /= obDCjBVRZiQQfSX;
            obDCjBVRZiQQfSX /= obDCjBVRZiQQfSX;
            obDCjBVRZiQQfSX = obDCjBVRZiQQfSX;
            NCLqvISmgRewF *= NCLqvISmgRewF;
        }
    }

    if (NCLqvISmgRewF < 1625449259) {
        for (int kfauotbVkjRUy = 408102539; kfauotbVkjRUy > 0; kfauotbVkjRUy--) {
            NCLqvISmgRewF /= NCLqvISmgRewF;
            obDCjBVRZiQQfSX = obDCjBVRZiQQfSX;
            NCLqvISmgRewF = NCLqvISmgRewF;
            NCLqvISmgRewF = NCLqvISmgRewF;
            NCLqvISmgRewF /= NCLqvISmgRewF;
            NCLqvISmgRewF *= NCLqvISmgRewF;
        }
    }
}

double bGcMSLC::bFmcHmeYFw(double DbnWXHhJ, bool vlsguJnx)
{
    string GUvPbWVWGLbzDpKP = string("q");
    string CyyIJAfMoUfXtd = string("TCLYbMQWYiRXleMKcmfIIsZHUWhZzCmswqLYLJTBzxVLHYxYZmigqDZdDMeUcEIRKonBynOZjoceZvYRkWLPwhzlLGSDvplZTyQctjljMOtkIuOpMPVFiYlisLiXCqWgLGyqplGqGgZjLhMmtFe");
    bool OzzuYIPcGJP = true;
    int wwbrc = -1841922236;
    bool SkRIN = true;
    double eIQSPVHruALGXER = -11402.488231577418;
    bool aftopxC = false;
    int IWBym = -1105125955;
    double DdwFcXVPheQd = 150240.17166557885;
    string OoBMGq = string("OQTXNrXybtFXQKiejcFwNXTZFOugnFQKrmcsMgCeCUGeZNNylihqUBbJurxMbGROZMNvl");

    for (int yNyEklFaNylZaKN = 807127724; yNyEklFaNylZaKN > 0; yNyEklFaNylZaKN--) {
        GUvPbWVWGLbzDpKP = GUvPbWVWGLbzDpKP;
    }

    for (int nmjzbdHpQn = 37615604; nmjzbdHpQn > 0; nmjzbdHpQn--) {
        OzzuYIPcGJP = vlsguJnx;
        eIQSPVHruALGXER = eIQSPVHruALGXER;
        OzzuYIPcGJP = ! SkRIN;
        OzzuYIPcGJP = ! SkRIN;
    }

    for (int YLSUlC = 519397531; YLSUlC > 0; YLSUlC--) {
        continue;
    }

    return DdwFcXVPheQd;
}

void bGcMSLC::HrcFiEmHbxZdRruZ(bool yzjpaDUHcuv, double GmKelDT, string juGJA)
{
    int LFijZsKWk = 211000191;
    double UgngfMlHWZumt = 298717.3136754669;
    bool CgWenKQOoZZZ = false;
    int XyInSY = -895237659;

    if (UgngfMlHWZumt != 298717.3136754669) {
        for (int YUzIcFmhABag = 484955916; YUzIcFmhABag > 0; YUzIcFmhABag--) {
            continue;
        }
    }

    for (int seQVWuP = 591830921; seQVWuP > 0; seQVWuP--) {
        XyInSY *= LFijZsKWk;
        LFijZsKWk -= XyInSY;
    }

    if (GmKelDT >= 306200.4325311211) {
        for (int IAQOOPYaAiSUEq = 433428031; IAQOOPYaAiSUEq > 0; IAQOOPYaAiSUEq--) {
            continue;
        }
    }

    for (int GcBYhcNDyDIEh = 146579352; GcBYhcNDyDIEh > 0; GcBYhcNDyDIEh--) {
        continue;
    }
}

int bGcMSLC::CJwEcjBzCjBEu()
{
    string JBZrmbHIMHUOwV = string("PvSyJcrSfiPTPOgdAzBQpNpjMYHlBDqrIKqUMUyHpQxspqDAZfZGIIepgVQAUasLtu");

    if (JBZrmbHIMHUOwV < string("PvSyJcrSfiPTPOgdAzBQpNpjMYHlBDqrIKqUMUyHpQxspqDAZfZGIIepgVQAUasLtu")) {
        for (int UhqZIroPigV = 233415434; UhqZIroPigV > 0; UhqZIroPigV--) {
            JBZrmbHIMHUOwV += JBZrmbHIMHUOwV;
            JBZrmbHIMHUOwV += JBZrmbHIMHUOwV;
            JBZrmbHIMHUOwV = JBZrmbHIMHUOwV;
            JBZrmbHIMHUOwV += JBZrmbHIMHUOwV;
            JBZrmbHIMHUOwV = JBZrmbHIMHUOwV;
        }
    }

    if (JBZrmbHIMHUOwV <= string("PvSyJcrSfiPTPOgdAzBQpNpjMYHlBDqrIKqUMUyHpQxspqDAZfZGIIepgVQAUasLtu")) {
        for (int eWoJNWqtizfnKI = 1840896325; eWoJNWqtizfnKI > 0; eWoJNWqtizfnKI--) {
            JBZrmbHIMHUOwV += JBZrmbHIMHUOwV;
            JBZrmbHIMHUOwV += JBZrmbHIMHUOwV;
        }
    }

    return -740297373;
}

bGcMSLC::bGcMSLC()
{
    this->WRjpzKRNYdEHg(-507413.11904527684);
    this->OfaARiQ(string("rJGPVJsttKEoHsoQGD"), -174056722, -1126537726);
    this->BdIWRBSgumXPRdk(true, false, 840120.4003032874, 551757.0210527891, string("BlVPfPMBQV"));
    this->fAAAvyuOG(-432122778, -355982.3556927434, 74185.32859482798, true, -952179.7206645857);
    this->OYfQOZuNldxy(string("yfBHPQjPaRQCngHsTkcLBYfGKRiOwLyMnDDeTatHimtxEGugaETPEqLRIhgsjQbPZQcUZLKviucTUfBtdtWamhWQSXDBAvxNErCIYbjaDpUtzSFBWJlWsXPWLLIHCpzafoDJuPTRxicMQXNORwDeYXwyhOiGlSXvUSgwcLjpUwfUFjIUIMbyyzRVErmuLLacY"));
    this->iDOCklaM(string("aYnRblVvumPXNxOqNcYvksxrOJDOnNuyPbqvxwNWYZYlalRIlexXGpPyWtJEDuuJqQXSMftKZhInVjABpizmJVlRogdkvPqtxuRJLzEQoQnXZPuPkwelRWVzzPfkLPsiZkoimySsENUKFmZluzgSJEegcgEgtEkMcRxYCkLOLVAhZMIoHrl"));
    this->NnJmFsCnyUJXPu(string("GcaTaspUWDgYjWqceeSfpjrUyARKHhrxQXqZPJbfmlvVgSSqdiGberoualPTjCYLjzYgHXkpQeFRAsMFvcxuhPNVsTNeCgDTBlcgRwgQgMAawVkpmcCnmnbUcZPUqRoZbzRHVOxekrHiIrIWrlteWULLxCWwgrtvaFtcMZQEoSosgYyNnEzwOQdinZyaFzanPSobEbDuQZx"), -567720.4861761437, string("lyXxtUcHqCJGljSMppBXwttvAReGdCJYduTwcACthuyrEcBUmwppPqWBqzdmyxapgdXndDvuADAMatXsItcPDREALPXhqVFrzPJYGTSiEiuWVgYuvcRgVLGoWFGsLMUEIyBfuPXDambNFWthFOYCxExqjUmwMfBwFIZhjLGDqJTSUw"), -795209.6232995854, 755422.2385537259);
    this->llInHiEMx(true, 299835.5221318606, true, false, 777573.3262744822);
    this->BJCeiGMqXvJrG(-1932235848, -417526.89846330654);
    this->qIwwNxf(true, string("nYMCqgoYTGpLcnyThKKxOJsUsEAejzMzMWmSThnRhfdpGDVRcoxPqkTidVheCYlBlMrNFkDqDerObyaLygDtflMdtXNpelCmmBnWhSpRWbOxUASrcmONstVvZVzVdIXtPzIFeLNxtFOXKnHWNkpCgyujf"), -497714.1679199408, 303992.3155281366);
    this->FpolQNFyEiSHwTdU(-730411.4345438771);
    this->VNmZjiMdrJt(1294171923, -397565.0178315403, string("vGMuydkcSJfOfVRJUVhiEeVPBcztdenDTWCDDeoeXLIphqdgojfMxmzWhvbMSXzNeXUvvDOWZKOYkJudnIgOOJeeGcKnVllKKUzBAEruR"), true, 1008368.145566982);
    this->elJYOFRNtz();
    this->xfiNVKFVbuHCum(1625449259);
    this->bFmcHmeYFw(283706.61805992416, true);
    this->HrcFiEmHbxZdRruZ(true, 306200.4325311211, string("PMx"));
    this->CJwEcjBzCjBEu();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ClNcGsYmzEfGv
{
public:
    int hzQzSTNy;
    string doWEDbJXTPwS;

    ClNcGsYmzEfGv();
    double aNvMJLokoWQUNOiu(string pIxDDyCdVjhuk, double LxiAJKZInlSO, int GPUUBXrEb);
    int GnJcGRJcEpKZMI(double agbQFhDrDwjrtE, string REexDsfOL);
    double hSoVuLaIBFYfyR(int mWKTOUoIwovyDTCu);
    bool OyjNvWeCU(int KzWhTEWocgnjIrg, int gfDxIVasUMQ, string ampxlmIuxvH, bool QXPsIACuyiBXTfep, bool LPlypehe);
    double LOmmIut(double pUDFTiuHv, int yrraRMttaLp, bool Ynbru, int XggQLaXuKfHLhwkU);
    double HlHqyGSlOybxOcp(bool PdkqXup, bool KPMqZIBGLuHdo);
    int ELePnhqceCTfb(int lxCYTFzCOgvrV, int fCgeTe, double dqwtxkofWhKaLYYj, int vQgWv);
protected:
    bool bZMZUj;

    double PqGoVnG(double rctApDkOYAY, bool bXnBBvdQgJyPc, string agTHigEvsQ, double sGSNgXcgEXwqQbAW);
    double kRKweRxu();
    double noRKPDmfAWNigTfa(double jCbWrVD);
    int NXaLgnABDGhCzz();
private:
    bool oyupkxfNxJTcN;

    string UFxHQg(string lyrefGW, bool XTlmgxwIPnPxtKl);
    int AvqvBlCf(double IATgmFbVNW);
    int rOfSqKpfSbBpQ();
    void ucmSY(double GlVdNcOxez, bool ZNTCi, bool DRtVIHHUVVZYatr, string KINJMMPzxcQ);
    double bEaPFcZOXPnr();
    string PLPFqxBNyjUX(bool GDfqQcKFY, int iNbjB, bool xKQqxlLn);
    int GUOqCTxWTUxCBMk();
    void cxZVCGsiwxhIFD(bool tusKibyYqHsiOH, int ZJiFo, double cSuaK, int HTxcW, bool pJDKxRloShNXknRx);
};

double ClNcGsYmzEfGv::aNvMJLokoWQUNOiu(string pIxDDyCdVjhuk, double LxiAJKZInlSO, int GPUUBXrEb)
{
    string hGMIXHUJxvsezua = string("IDasCkJHyBAXJEkpuxhQBcuYDeKIooqEmDaCCScDDrfPqtXiovqVoqJGSzfPBDSZMhyVpQIJgNafFTootHEgAmgpbKWnvrrGaHUxmJUBtqfwlQkaABovGgCfCBxTEofntIhMTPvXhkzbWZxDKHCekHPEywAjgFFCdhdWcyfTYchGyvqqpRWkUxSioMyIBtDRoWrcb");
    string rfXGdY = string("MDKBhqFpMfVPBuFMxjBQPOOIlvvIs");
    int sSPwIxunOnZn = 2017335213;

    for (int wlqMEJkL = 64504679; wlqMEJkL > 0; wlqMEJkL--) {
        rfXGdY = hGMIXHUJxvsezua;
    }

    for (int gtOJriTENMri = 1043611359; gtOJriTENMri > 0; gtOJriTENMri--) {
        continue;
    }

    return LxiAJKZInlSO;
}

int ClNcGsYmzEfGv::GnJcGRJcEpKZMI(double agbQFhDrDwjrtE, string REexDsfOL)
{
    bool XwZVO = false;
    bool eJdNWRZwATpQLR = false;
    double cmULoyje = -515506.2979962248;
    string CsTCDeVKMPtKSE = string("cTTUXmKAalXwVBJPgBKUPxpnWuHiCuebewzMMXSQaReUehQYUXbYiFoHGGgxSYUoaddAIiHJxnAkybPLKAzTsVddDBJSchrFdKeXUhYudRR");
    string pvvKgQ = string("zOia");
    string LgwmgnYrya = string("roQmtGpTjQKFtYakFolYfefGmkpNqtJDPtcDMKzAeMpkOkBgpfvUidEpRsZQrVxCQazrJNrbQieGysGaAQFJdwFwXDfslaEvuiFBdsCEdVHcmyJXrBBiewBvGMpTkliUGosZVMsvzQYrQmXj");
    bool KofWQseviD = false;
    double nWiYXZYCsmBf = 972611.8796313244;
    double EqrWTpnctNx = 450432.0689216677;

    for (int XKZaGsc = 2132481978; XKZaGsc > 0; XKZaGsc--) {
        LgwmgnYrya += pvvKgQ;
    }

    for (int RQBaeEykzacc = 1386148270; RQBaeEykzacc > 0; RQBaeEykzacc--) {
        REexDsfOL = REexDsfOL;
        agbQFhDrDwjrtE *= agbQFhDrDwjrtE;
        agbQFhDrDwjrtE /= cmULoyje;
    }

    for (int ozaaEaamSW = 612706482; ozaaEaamSW > 0; ozaaEaamSW--) {
        XwZVO = XwZVO;
    }

    return 994088346;
}

double ClNcGsYmzEfGv::hSoVuLaIBFYfyR(int mWKTOUoIwovyDTCu)
{
    bool cmvKZiMqqRS = false;
    double qFXSMznDqLgRWPl = -157708.07329345128;
    string nMiLCbeiDO = string("boXUnDJuIXRFBiWjqUVtGdiyegLHYvdNPUMoegmilHKPOVSRUmMQvFlNGDcpjIFpkIVBhMAfFglqsCJfXQrCJQTiCIjYjwtyuuGGswwWnVuWJOrgJETRtCOVodhuAOQgPNJGJrSlcMpGNlJQIparsgRMAVBlybjxbfjvnqwksNufdxbcpLGSUNOeUQgWyUJahxRViOZBWMFrgfdyywIFQjIMcCYtqnUI");

    for (int fVOzIHZ = 1768123894; fVOzIHZ > 0; fVOzIHZ--) {
        continue;
    }

    if (mWKTOUoIwovyDTCu < -1789606830) {
        for (int JmINJUnAORMQius = 1802204378; JmINJUnAORMQius > 0; JmINJUnAORMQius--) {
            continue;
        }
    }

    for (int tkOzckbeyMX = 1136222528; tkOzckbeyMX > 0; tkOzckbeyMX--) {
        mWKTOUoIwovyDTCu -= mWKTOUoIwovyDTCu;
        qFXSMznDqLgRWPl /= qFXSMznDqLgRWPl;
        mWKTOUoIwovyDTCu *= mWKTOUoIwovyDTCu;
    }

    for (int uGmdZ = 937197320; uGmdZ > 0; uGmdZ--) {
        nMiLCbeiDO = nMiLCbeiDO;
    }

    return qFXSMznDqLgRWPl;
}

bool ClNcGsYmzEfGv::OyjNvWeCU(int KzWhTEWocgnjIrg, int gfDxIVasUMQ, string ampxlmIuxvH, bool QXPsIACuyiBXTfep, bool LPlypehe)
{
    double OhjglotbCAjWubCQ = -473643.0038946705;
    string JAoAFnzZQQqJ = string("IWjnaAldTleFGbmRzxsvhTYLAnaNYobRtyIZcYhUDtLBnTYQnpPXqtIZvWDlEYGtvHGEGmHAMjWHhITAcWaYljEemUvDEjUFUticamfexdxtDRrLwRNghTVyisqmSbHwYnnTyFIicTrhExJONpmRqpqJEAkuwOQuwOGPhOpeBZNWjUCjCvwYzVCtFunDOlfHmrGlGDPGzKKUyZaaryKuDnVCKyEgIMHgcoGHepH");

    if (QXPsIACuyiBXTfep != true) {
        for (int oRZJEqMnbHs = 593459219; oRZJEqMnbHs > 0; oRZJEqMnbHs--) {
            LPlypehe = ! LPlypehe;
            gfDxIVasUMQ += gfDxIVasUMQ;
            OhjglotbCAjWubCQ -= OhjglotbCAjWubCQ;
            QXPsIACuyiBXTfep = LPlypehe;
        }
    }

    for (int zFeuJROVYFM = 1544458245; zFeuJROVYFM > 0; zFeuJROVYFM--) {
        continue;
    }

    if (ampxlmIuxvH >= string("AfJalXefxWktSZSxtjIpQBLGbhYdoWeTJvElfAHaXkwzajhYqtzjcJVegGIFkJNnqKSpmtdUnOYxCnVlhjZubJbQgeeTgWESwlTbFoYoMMzuHOzemqRMhrXGzISBwHbevyQNefKioduOYgeOFqAUopXqoSoVknbdmqzltbpDNGnz")) {
        for (int BVpZkLFbR = 1065583981; BVpZkLFbR > 0; BVpZkLFbR--) {
            ampxlmIuxvH = ampxlmIuxvH;
        }
    }

    for (int gJWoarQ = 186450186; gJWoarQ > 0; gJWoarQ--) {
        LPlypehe = QXPsIACuyiBXTfep;
    }

    return LPlypehe;
}

double ClNcGsYmzEfGv::LOmmIut(double pUDFTiuHv, int yrraRMttaLp, bool Ynbru, int XggQLaXuKfHLhwkU)
{
    double RTcrNuU = 1003539.2413665823;
    double YbyJGBDxHzOpxqtk = -90924.2405380092;
    double YQTCakqNC = -421495.3557728119;
    int LpnvlDoyH = 287230894;
    double HsdfbmnDddt = -567277.3961947736;
    double xiLcZnkregvYlIw = -235893.11246322442;
    int kuaXkIVtijzueD = -1253168685;
    string aJQRgDMP = string("QidHQABlHMLapXMFEKRdGAMQoYpmdQwUIqiHhROsykGuRUAZIPLRgqLdBGvuDDfZMpfEQIvdPtQLGVTJSoNReCyhdXFPRYzeeaysratSyJjsFqepLUlvieJijHurFsysCtkFVHrhvUQVZVkGlRToaXZBgGXDplkxItwVVfHVPJdW");

    if (RTcrNuU <= -90924.2405380092) {
        for (int zdogPoy = 452709641; zdogPoy > 0; zdogPoy--) {
            YbyJGBDxHzOpxqtk += YbyJGBDxHzOpxqtk;
        }
    }

    for (int BARaitfKRkan = 425839676; BARaitfKRkan > 0; BARaitfKRkan--) {
        continue;
    }

    for (int klpAdrRsFTVUm = 1624429153; klpAdrRsFTVUm > 0; klpAdrRsFTVUm--) {
        YbyJGBDxHzOpxqtk += YQTCakqNC;
        kuaXkIVtijzueD /= kuaXkIVtijzueD;
        RTcrNuU += YbyJGBDxHzOpxqtk;
        pUDFTiuHv /= YQTCakqNC;
        RTcrNuU -= YbyJGBDxHzOpxqtk;
        HsdfbmnDddt -= xiLcZnkregvYlIw;
    }

    if (HsdfbmnDddt > -90924.2405380092) {
        for (int dtFoMspLBZRuOtl = 8401566; dtFoMspLBZRuOtl > 0; dtFoMspLBZRuOtl--) {
            xiLcZnkregvYlIw *= RTcrNuU;
            YQTCakqNC -= RTcrNuU;
            kuaXkIVtijzueD *= kuaXkIVtijzueD;
        }
    }

    return xiLcZnkregvYlIw;
}

double ClNcGsYmzEfGv::HlHqyGSlOybxOcp(bool PdkqXup, bool KPMqZIBGLuHdo)
{
    int wfINfybhiS = -902520891;

    for (int GsyPAjtom = 2078809095; GsyPAjtom > 0; GsyPAjtom--) {
        PdkqXup = ! KPMqZIBGLuHdo;
    }

    if (KPMqZIBGLuHdo == false) {
        for (int gfbtTlFfzkEGrEZD = 1088693821; gfbtTlFfzkEGrEZD > 0; gfbtTlFfzkEGrEZD--) {
            continue;
        }
    }

    return 132507.60699225435;
}

int ClNcGsYmzEfGv::ELePnhqceCTfb(int lxCYTFzCOgvrV, int fCgeTe, double dqwtxkofWhKaLYYj, int vQgWv)
{
    string KHxUynazQPN = string("NLuNSCpEyOmOOviwFQMdyxVDCsAOYsaNbdNjhWUbfcBTmqIZXxMeUGSoCrqksKryxFTqGjCblJCaZPaFcYyTKGyuzuGXHgHTwFvTFmVpdHGuGuUbwWcAdcQcbbRdcVfnPiSlGtJVVEClFaGZBVgjnsnrtPPmdwdcLEeZxClAhHVlHFaUJVveBybwQDWtqDWPmqLtDZSkeXeIwXnxaoMtYBBqkPMBxFEBfyCU");
    bool rGZBlRqkmWBlqVS = false;
    string UWtdHtOL = string("oFKMQIGRrREsaZvwIXLQPPsUL");
    bool lmSemFjIqoR = true;
    string cqMnFXHfvuDxUwl = string("pqJgpdPgjkVFgoSEsLhfWxIzdTigyqlr");
    double bNyfsWzoyPR = -189251.44381984853;

    for (int MBUoZWQtvSBWUaue = 507349257; MBUoZWQtvSBWUaue > 0; MBUoZWQtvSBWUaue--) {
        dqwtxkofWhKaLYYj += bNyfsWzoyPR;
        cqMnFXHfvuDxUwl = cqMnFXHfvuDxUwl;
        KHxUynazQPN = cqMnFXHfvuDxUwl;
        bNyfsWzoyPR += bNyfsWzoyPR;
        KHxUynazQPN += KHxUynazQPN;
    }

    return vQgWv;
}

double ClNcGsYmzEfGv::PqGoVnG(double rctApDkOYAY, bool bXnBBvdQgJyPc, string agTHigEvsQ, double sGSNgXcgEXwqQbAW)
{
    string AyMUOlWaDNqtqY = string("EiVsPslcEiJyPhyVmVJtYBxRMVeeHdbbsGzKDInBBBfFeZRnaXxUqwaRaTJryzbEAoGQeQAtAKYopzciVtaAAfDFDjQKMNgBfZelyxruaidcWqmXqydttqKcRVtBtIAEFejyvASrscQtlOuGXtoEoIsFONPWUEXZMLBUZfVROmvrTpYissghGJeSzZcIUhhZyuZCbvwFvAgKMMnNpLnEaPODscHfEeMLiptZXPymGQqqBOSqDPMOp");

    for (int MBCgnVkjplto = 585498657; MBCgnVkjplto > 0; MBCgnVkjplto--) {
        bXnBBvdQgJyPc = ! bXnBBvdQgJyPc;
        AyMUOlWaDNqtqY = agTHigEvsQ;
        sGSNgXcgEXwqQbAW = sGSNgXcgEXwqQbAW;
        AyMUOlWaDNqtqY += AyMUOlWaDNqtqY;
        agTHigEvsQ = AyMUOlWaDNqtqY;
        agTHigEvsQ += AyMUOlWaDNqtqY;
    }

    if (agTHigEvsQ < string("PwXRLLsFfBkauGdMTciZMNVIMbsGPDEnnwTYdnbZqzhMBGHpKXPLJbTbGUAGhOPBiPnswNuDQgllwwzNNZayRQGDRquvsvMWsnxHhAMuHyrYcjEkevAGFzGYRSAlrsKUnuCofEVHKI")) {
        for (int ZQOVinn = 1649107480; ZQOVinn > 0; ZQOVinn--) {
            sGSNgXcgEXwqQbAW *= sGSNgXcgEXwqQbAW;
            AyMUOlWaDNqtqY = agTHigEvsQ;
            AyMUOlWaDNqtqY += AyMUOlWaDNqtqY;
            sGSNgXcgEXwqQbAW += rctApDkOYAY;
        }
    }

    for (int nbNWRZL = 438507892; nbNWRZL > 0; nbNWRZL--) {
        AyMUOlWaDNqtqY += agTHigEvsQ;
        sGSNgXcgEXwqQbAW /= rctApDkOYAY;
        agTHigEvsQ = agTHigEvsQ;
        rctApDkOYAY /= sGSNgXcgEXwqQbAW;
    }

    return sGSNgXcgEXwqQbAW;
}

double ClNcGsYmzEfGv::kRKweRxu()
{
    bool PzMGtHKDNbF = false;
    double nBkmpXQbqkkUEk = 736752.2301226887;
    string UhfWGYcxpgcN = string("CleABAqfoCFERzNxGxJiBKXMdnSghIsKdGWutYftslHjTmEunqSGguenmAffvfEEWavfMLaiDipGcesiIVbYlYhaJnRtNcqEnSDCPboENzSMiexKEBriwelDnDyLPvEyzMVCbOEeaKuEqfvAkmVVII");
    string ntvMDytHAIkyTtn = string("pxSBhEJLokJcYIDYOJBdaDHHwLsrGJTMhJuinYJUcVAgMRaGLcUZhwwcsIBxZIRxrkcLjUUoYytpHqSElQNZJpWxMIHEBYcF");
    int ewmsDnZOFUwYdmI = 2140545096;
    double anhFWFrBSeeWOrlZ = -207597.2685776024;
    string QRCaVPoliNRZBitM = string("DxXaBUiAIUUbvgciLFGuaiGXXeWVOXbTDl");
    double nlzWIJFdsIvhQ = 136276.6669942281;
    bool gzrJbtnfxVXz = false;

    if (gzrJbtnfxVXz == false) {
        for (int zWPIiaLHF = 1064036903; zWPIiaLHF > 0; zWPIiaLHF--) {
            continue;
        }
    }

    for (int ffIODtc = 1463647074; ffIODtc > 0; ffIODtc--) {
        anhFWFrBSeeWOrlZ *= nlzWIJFdsIvhQ;
        UhfWGYcxpgcN += QRCaVPoliNRZBitM;
        QRCaVPoliNRZBitM = UhfWGYcxpgcN;
        anhFWFrBSeeWOrlZ /= nlzWIJFdsIvhQ;
        ewmsDnZOFUwYdmI -= ewmsDnZOFUwYdmI;
    }

    if (ntvMDytHAIkyTtn != string("CleABAqfoCFERzNxGxJiBKXMdnSghIsKdGWutYftslHjTmEunqSGguenmAffvfEEWavfMLaiDipGcesiIVbYlYhaJnRtNcqEnSDCPboENzSMiexKEBriwelDnDyLPvEyzMVCbOEeaKuEqfvAkmVVII")) {
        for (int uVcjF = 381844292; uVcjF > 0; uVcjF--) {
            UhfWGYcxpgcN += ntvMDytHAIkyTtn;
        }
    }

    return nlzWIJFdsIvhQ;
}

double ClNcGsYmzEfGv::noRKPDmfAWNigTfa(double jCbWrVD)
{
    string byejHJNhe = string("EdpGdnRzuZjfclVClqVytPKKPOWMUiicdcZIrXmbszoRkTvHTCPsFXSTdXcVnIkeVxybhsKgkzITILDA");
    double VndFBgFs = 812257.8578553357;
    bool QkEUeKTHgtrfvS = true;
    double fFcFThQ = -287349.32347750437;
    double nqaLdZuRCfRLSjLM = 139410.44489257166;
    int wrDqTsCrlR = -1126324864;
    int cEOeV = -1030282661;
    int JfkgLFFlyEk = 1063175875;

    if (JfkgLFFlyEk >= -1030282661) {
        for (int NqpBEBsiI = 1413540631; NqpBEBsiI > 0; NqpBEBsiI--) {
            JfkgLFFlyEk /= cEOeV;
            nqaLdZuRCfRLSjLM /= VndFBgFs;
            cEOeV *= JfkgLFFlyEk;
        }
    }

    if (cEOeV <= 1063175875) {
        for (int RgaqKQ = 1743092034; RgaqKQ > 0; RgaqKQ--) {
            JfkgLFFlyEk /= cEOeV;
            QkEUeKTHgtrfvS = QkEUeKTHgtrfvS;
            cEOeV *= JfkgLFFlyEk;
        }
    }

    for (int bDXWuHiQuL = 915599920; bDXWuHiQuL > 0; bDXWuHiQuL--) {
        cEOeV *= JfkgLFFlyEk;
        jCbWrVD *= nqaLdZuRCfRLSjLM;
        VndFBgFs *= nqaLdZuRCfRLSjLM;
    }

    return nqaLdZuRCfRLSjLM;
}

int ClNcGsYmzEfGv::NXaLgnABDGhCzz()
{
    double RFgJNTmjMBf = 17163.929538798853;
    int jzYRhcQPnuPS = -511583232;

    for (int rVynUjNlbrRZ = 270643172; rVynUjNlbrRZ > 0; rVynUjNlbrRZ--) {
        RFgJNTmjMBf /= RFgJNTmjMBf;
        RFgJNTmjMBf -= RFgJNTmjMBf;
        jzYRhcQPnuPS *= jzYRhcQPnuPS;
    }

    if (RFgJNTmjMBf != 17163.929538798853) {
        for (int jdwADllGU = 2020919146; jdwADllGU > 0; jdwADllGU--) {
            RFgJNTmjMBf += RFgJNTmjMBf;
            RFgJNTmjMBf *= RFgJNTmjMBf;
            jzYRhcQPnuPS += jzYRhcQPnuPS;
            RFgJNTmjMBf = RFgJNTmjMBf;
            jzYRhcQPnuPS += jzYRhcQPnuPS;
            RFgJNTmjMBf = RFgJNTmjMBf;
            jzYRhcQPnuPS /= jzYRhcQPnuPS;
        }
    }

    for (int nISXbNrQ = 2021003705; nISXbNrQ > 0; nISXbNrQ--) {
        jzYRhcQPnuPS -= jzYRhcQPnuPS;
    }

    if (RFgJNTmjMBf <= 17163.929538798853) {
        for (int KcAoN = 1612325854; KcAoN > 0; KcAoN--) {
            continue;
        }
    }

    return jzYRhcQPnuPS;
}

string ClNcGsYmzEfGv::UFxHQg(string lyrefGW, bool XTlmgxwIPnPxtKl)
{
    double UGscgcgwWXQwCqS = -1002140.8069013306;
    bool PsjQs = false;
    int vUKMu = -348772712;

    for (int BOesYJSdQhN = 2024306151; BOesYJSdQhN > 0; BOesYJSdQhN--) {
        continue;
    }

    return lyrefGW;
}

int ClNcGsYmzEfGv::AvqvBlCf(double IATgmFbVNW)
{
    int OHXtIl = 381357836;
    int fVPmIuQbCq = 1496728905;
    bool xdbCkp = true;
    bool BCmQEZzUhtz = true;
    bool osYTBlmpgcrfU = true;
    double XrzGntjZs = 36312.57527656166;
    double GnywrPiYZfgqlRKg = -301135.08137485373;
    string GeQQTlUtBEL = string("UbKMmutbkerYjXwqBvRpyRIdeiSPeVNuEbJrPgOOmKFmTlJVTUtKGTGIZRwKwYybmiNGUzBKzkUOocKimWQhnBIvkTldHTZHYvoiNgGLttDgxjwLgNVxxMpDptRnXUXsyNDzysdPrylGsBxxemZeOSZPZvzBiMpJCdQibTbZSKnkBfLxgrPOQZtmLcFPyoTvnFcWc");
    bool cPskIEJXrHI = false;

    for (int CistLWYu = 310508584; CistLWYu > 0; CistLWYu--) {
        osYTBlmpgcrfU = ! osYTBlmpgcrfU;
    }

    if (xdbCkp == true) {
        for (int iFFbUrvcoJNM = 607106821; iFFbUrvcoJNM > 0; iFFbUrvcoJNM--) {
            continue;
        }
    }

    for (int qVWVtExIuDDNkwP = 965363359; qVWVtExIuDDNkwP > 0; qVWVtExIuDDNkwP--) {
        GeQQTlUtBEL += GeQQTlUtBEL;
        IATgmFbVNW /= IATgmFbVNW;
        BCmQEZzUhtz = BCmQEZzUhtz;
        XrzGntjZs /= IATgmFbVNW;
    }

    if (XrzGntjZs == -301135.08137485373) {
        for (int sPRcbHaGffRfjFCh = 1720118654; sPRcbHaGffRfjFCh > 0; sPRcbHaGffRfjFCh--) {
            fVPmIuQbCq -= OHXtIl;
        }
    }

    for (int XhvSRePETrC = 515148533; XhvSRePETrC > 0; XhvSRePETrC--) {
        continue;
    }

    for (int zWJByRdqKgzrHr = 1072920143; zWJByRdqKgzrHr > 0; zWJByRdqKgzrHr--) {
        continue;
    }

    return fVPmIuQbCq;
}

int ClNcGsYmzEfGv::rOfSqKpfSbBpQ()
{
    bool sNvxY = true;
    int ikFsVKuouWjRYV = 304314480;
    string CWsHTzWMu = string("mhItFryPebmSWYYlhIuudFaZwdlRdDdJamiCxAHEKWSoHCECbAMHhoNPudFJsDMHmdflSWPtXLqDQqdeyLMiAAgTcnrFMKRgVTatNfKibBkoncDMpqVcYzqwbTBuKpIKLKQDGiDaAiPreBohOrWMayuKrpVtafhMLuRLxVBCcbNlvEPlierInKsohTBUHVnkvOMzivDYyZLpOSVVRpFemANklKrXJEIfDuPBK");
    bool PUUhKGc = true;

    return ikFsVKuouWjRYV;
}

void ClNcGsYmzEfGv::ucmSY(double GlVdNcOxez, bool ZNTCi, bool DRtVIHHUVVZYatr, string KINJMMPzxcQ)
{
    int bezQeUyJBMsiajy = 736683209;

    for (int GBqAhaI = 1538389325; GBqAhaI > 0; GBqAhaI--) {
        GlVdNcOxez = GlVdNcOxez;
    }

    for (int YXbXbD = 374301081; YXbXbD > 0; YXbXbD--) {
        DRtVIHHUVVZYatr = ! ZNTCi;
        GlVdNcOxez *= GlVdNcOxez;
    }

    for (int awwZTZsgKHQr = 1130159869; awwZTZsgKHQr > 0; awwZTZsgKHQr--) {
        DRtVIHHUVVZYatr = ! DRtVIHHUVVZYatr;
        bezQeUyJBMsiajy += bezQeUyJBMsiajy;
        KINJMMPzxcQ += KINJMMPzxcQ;
    }
}

double ClNcGsYmzEfGv::bEaPFcZOXPnr()
{
    double LreOPENUeVSr = -1028941.1640691437;

    if (LreOPENUeVSr != -1028941.1640691437) {
        for (int bnaIWePsoBm = 7838; bnaIWePsoBm > 0; bnaIWePsoBm--) {
            LreOPENUeVSr /= LreOPENUeVSr;
            LreOPENUeVSr /= LreOPENUeVSr;
            LreOPENUeVSr *= LreOPENUeVSr;
            LreOPENUeVSr = LreOPENUeVSr;
            LreOPENUeVSr /= LreOPENUeVSr;
            LreOPENUeVSr += LreOPENUeVSr;
            LreOPENUeVSr -= LreOPENUeVSr;
            LreOPENUeVSr += LreOPENUeVSr;
        }
    }

    if (LreOPENUeVSr >= -1028941.1640691437) {
        for (int wwNdg = 1516742628; wwNdg > 0; wwNdg--) {
            LreOPENUeVSr = LreOPENUeVSr;
            LreOPENUeVSr -= LreOPENUeVSr;
            LreOPENUeVSr *= LreOPENUeVSr;
            LreOPENUeVSr = LreOPENUeVSr;
            LreOPENUeVSr += LreOPENUeVSr;
            LreOPENUeVSr -= LreOPENUeVSr;
            LreOPENUeVSr -= LreOPENUeVSr;
            LreOPENUeVSr -= LreOPENUeVSr;
            LreOPENUeVSr /= LreOPENUeVSr;
        }
    }

    return LreOPENUeVSr;
}

string ClNcGsYmzEfGv::PLPFqxBNyjUX(bool GDfqQcKFY, int iNbjB, bool xKQqxlLn)
{
    bool TvgwfmguDTn = true;
    string ksMSovkC = string("HcWPPFeQZrGXqpzuGbxrljwZkUoDgKrqbsIJJQznRyZXmhjJwwVcOlAIrJCnuHhxfMyReqpVfCTOqFRPzmlpIkNJeYMNSsAHfuEryVGQVcvfsuMXrZHHjIUFvKtXTxVIkmLfEohbneGoirSDiugkvvHNkSQJNhk");

    if (xKQqxlLn != true) {
        for (int NzyIVlx = 625448009; NzyIVlx > 0; NzyIVlx--) {
            continue;
        }
    }

    for (int lthovzjrVIzFSDmX = 1517461174; lthovzjrVIzFSDmX > 0; lthovzjrVIzFSDmX--) {
        xKQqxlLn = GDfqQcKFY;
        TvgwfmguDTn = GDfqQcKFY;
        TvgwfmguDTn = GDfqQcKFY;
    }

    return ksMSovkC;
}

int ClNcGsYmzEfGv::GUOqCTxWTUxCBMk()
{
    bool GDCZClYJmrbSdk = true;

    if (GDCZClYJmrbSdk == true) {
        for (int dZYglbMJBtwxP = 590130205; dZYglbMJBtwxP > 0; dZYglbMJBtwxP--) {
            GDCZClYJmrbSdk = GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = ! GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = GDCZClYJmrbSdk;
        }
    }

    if (GDCZClYJmrbSdk != true) {
        for (int amsmw = 1816913162; amsmw > 0; amsmw--) {
            GDCZClYJmrbSdk = ! GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = ! GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = ! GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = ! GDCZClYJmrbSdk;
            GDCZClYJmrbSdk = GDCZClYJmrbSdk;
        }
    }

    return -2023233202;
}

void ClNcGsYmzEfGv::cxZVCGsiwxhIFD(bool tusKibyYqHsiOH, int ZJiFo, double cSuaK, int HTxcW, bool pJDKxRloShNXknRx)
{
    int RncDPdPa = 1398463754;
    string JkXYPHeS = string("WmVerxJdspUhxeYEtMGXTHjyBbVMFfTAAsIZWpALLzMLeOSMlwWDEkZxCSbwTHlMjrmbsmcxFIovtDvEMZRkVVQBDnpasetPToaQgkQRLXaErgfbmGMRSamXjUUSlFjCdFBPXRifCAPAJdyClVPsscbLnsRffewGyuJOjropMEEzMrKsxIHFlJRbkiKoGCBNgaZRjIqwKCedmnzaWuygArkkEjnMqBNcBARAVstIogZoSRpCLSrVc");

    for (int FXlkd = 758048225; FXlkd > 0; FXlkd--) {
        pJDKxRloShNXknRx = ! tusKibyYqHsiOH;
        RncDPdPa -= ZJiFo;
    }

    if (tusKibyYqHsiOH == true) {
        for (int kxIUWWKdivqNhDP = 630992486; kxIUWWKdivqNhDP > 0; kxIUWWKdivqNhDP--) {
            HTxcW += RncDPdPa;
        }
    }
}

ClNcGsYmzEfGv::ClNcGsYmzEfGv()
{
    this->aNvMJLokoWQUNOiu(string("cbWayLBGVVwhwpyjNRGaDjNlYIEMMPpezVxyDO"), 1003603.1144405896, -740562233);
    this->GnJcGRJcEpKZMI(-674736.8344378892, string("OGmpvoHWFnHpVMQasKyoVrlJcJQZJaVuZaPZTSjjbxfQmrcvrKZDnEocjgtNDrsyfOaxPveRLvjFdJecEWIxucWcCpmKaiEjCHPBVNODNzBfdTvGWCMjcUdhzmGBLayESrvmjjRoFQCNIFeMqcmlwHFUIQVRaREkiaNGoHYzAsInhhzWgPEsbn"));
    this->hSoVuLaIBFYfyR(-1789606830);
    this->OyjNvWeCU(1572308076, -1090624863, string("AfJalXefxWktSZSxtjIpQBLGbhYdoWeTJvElfAHaXkwzajhYqtzjcJVegGIFkJNnqKSpmtdUnOYxCnVlhjZubJbQgeeTgWESwlTbFoYoMMzuHOzemqRMhrXGzISBwHbevyQNefKioduOYgeOFqAUopXqoSoVknbdmqzltbpDNGnz"), true, true);
    this->LOmmIut(405486.5258319989, 1734250727, true, 1662762579);
    this->HlHqyGSlOybxOcp(true, false);
    this->ELePnhqceCTfb(109412992, 229067480, -920086.8942249604, -1677534082);
    this->PqGoVnG(-1000813.777286984, false, string("PwXRLLsFfBkauGdMTciZMNVIMbsGPDEnnwTYdnbZqzhMBGHpKXPLJbTbGUAGhOPBiPnswNuDQgllwwzNNZayRQGDRquvsvMWsnxHhAMuHyrYcjEkevAGFzGYRSAlrsKUnuCofEVHKI"), 544362.18747329);
    this->kRKweRxu();
    this->noRKPDmfAWNigTfa(-598571.4605674496);
    this->NXaLgnABDGhCzz();
    this->UFxHQg(string("mhKZenylMRuFMNytQGxnhmLxpGKUFcifkoDjrjtjPSYkOmjHpmeVollVlehEyWPdNCqDUzAuFcBfknFMEtCWKbVrqDNFKYwOBsHSefNGWsbyzwAezVirrlwHsjfXgrAIEqwkBrfkjqwyTXiHgLLO"), false);
    this->AvqvBlCf(-49756.52524041209);
    this->rOfSqKpfSbBpQ();
    this->ucmSY(121648.62853324514, true, true, string("bpSxaxIVSKJqIMGPEWMgrdjWufqJwQkfhXOrhqVHSUkNxrmwZrgormLkUnxeesgBRnQnKehyFKDERgmAzLKdNFpoveWxwTKnrKlVDsVrINuWpQKVigocCsJnMwcvymeTUznIIrEtwILIcsHWxZycHLUcuWiMIWGvm"));
    this->bEaPFcZOXPnr();
    this->PLPFqxBNyjUX(true, 442904259, true);
    this->GUOqCTxWTUxCBMk();
    this->cxZVCGsiwxhIFD(true, 2110025856, 815202.8814002038, 1978971794, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zzcvUd
{
public:
    bool fIkLWVlmla;
    int yHBauHWaIltvPM;
    double cquoJsfMdfvINYb;
    double TjRWvxaBtdH;
    double HfccZLBqvF;
    int AJMrzgDLWtHtuhaQ;

    zzcvUd();
    double kHmoYzIgaEHiYhq(int CcCJaJ, int lStQFvecVtzVybZ);
    bool CeWpkUEP(bool ArweR, bool sviweqOWfISzzWQd);
    double cSbkVaOh();
protected:
    bool KrCpKLzjpeAQBrX;
    string GtpcJZ;
    double eJdMDChK;

    string JXiEeoGs(bool YqVjOKBQzA, bool YbtQymTymhAk, int KZKVIPdhlZW);
    string LcvtYujKBgoMBzc(int MtfynSUrIoOiOr, bool qGjJMmMjAjzC);
    int pJcccBWkUFAdjTr();
    int eZBKeGKMxiYx();
    void ZXNtGeOLOSRp(double TtGXCpABUlz, int qNBgOvIKKVrd, int xoJrjqqwzsBErP, bool foXdNlLQcRtwzSSH, double YcqBquklwmwtaqjj);
private:
    bool pOOQThvdIODbue;
    bool awHTKJCz;
    int qnSAlgy;
    string SjwyF;
    double WMcXWnnbnthVgPcg;

    int FRnEZsqSjCN(double luCKlHXcLsO);
    void wDkwwwfxmN();
    int lCgGN(bool PDtapinBUEm, string hxYVbJYzNzRKMS, bool WQxFCycd, double ijjikKaZVzqiG, double XnktaN);
    void rDJSlrfaxQPxYHJ(double CtvIkUpoyV);
    bool LDllUqK(double RRvbVfdHhjt, string lPmAOuYsBiXjiC);
    double uFHWuNGB(int ZkmTIRlHiAnUzH, double oaNopAw, string dwRRwtoEObvHi, bool pdervWmbtYlTrx);
    double iYMjuirWx(string bOobMMR, bool xjiWyEEPiVrg, bool Cwntz);
};

double zzcvUd::kHmoYzIgaEHiYhq(int CcCJaJ, int lStQFvecVtzVybZ)
{
    string MJUmWoGpFnPEWlr = string("vNyfOXqjLLDlEMLmRVXAVObrgpmkaeOArhBzH");
    string dziryZmqsGfbHjV = string("qEAiGbXVJikJxDMeTVUBAXJfoJIspntxwNkVpXuxTQAIumQYWeaSbTUfgfBAivvRluNXKeyBYDGcKGPxOylUxanLRtvHyjqnclszyKmpIlywcipbGirxHFBbIosPvIsYdRTrrUpvfbiQgPbBWpjaBouuRzRNoqLZRSkwaJN");
    int RJAyxKSxEEvyM = -1651317312;
    int mFuGXqNIy = -1224853529;

    if (MJUmWoGpFnPEWlr >= string("vNyfOXqjLLDlEMLmRVXAVObrgpmkaeOArhBzH")) {
        for (int hbUJnTrRfvM = 1917527616; hbUJnTrRfvM > 0; hbUJnTrRfvM--) {
            lStQFvecVtzVybZ -= RJAyxKSxEEvyM;
            CcCJaJ = lStQFvecVtzVybZ;
        }
    }

    for (int vHXakBK = 624186663; vHXakBK > 0; vHXakBK--) {
        dziryZmqsGfbHjV += dziryZmqsGfbHjV;
        CcCJaJ = mFuGXqNIy;
        MJUmWoGpFnPEWlr += dziryZmqsGfbHjV;
        RJAyxKSxEEvyM *= mFuGXqNIy;
    }

    return -819773.0998146291;
}

bool zzcvUd::CeWpkUEP(bool ArweR, bool sviweqOWfISzzWQd)
{
    bool gjbZbHwPJbaZzzV = false;
    int wBNkWwUIEfZlsoa = -501694804;
    string LcmXrosqfhsLvbQp = string("UdzvrOVJvqTmdPhKsrQJyMuUQBMTZlplKggvpzXsdpodafOxpREIDhqvNSCqOblkzVUFXploLyNiHdPmQjYqimACEvTlrfZIJYMDHLjWuTCSuDaFCRjoFbHJTAMnTAvAROSUnenbsuzZTMQlodooVwNkMgjjYtEzbKCXdEjJOnUMaOaGGXmtiWWNtGmLYfQGnjOorjFHcTTHNnXVagqZadDEMvTUzdXgVqgjOl");
    int ZXzQCJIn = 260639761;
    double xZdplKnpSx = 91390.20677085842;
    int DFdtmCEKXpkYP = 1811820592;
    int njjZeH = -2013486150;
    double fBlkRYpJm = -313926.88756481017;
    int rqBJSoBvrH = 671923595;
    string cyXtDiIzOqQ = string("ihVQegwpTVKrXNrgvXaHuQFZlRHVPrYLIskUeHjDYNXhqvSkoYQIMMAuyUGYLLvgjTEEiUvTUTTaOmUnkZbDLFORHPtdkhnMbYJLeOoqljZKsabdLocgVfDKRTJfjPlJqzZyojeJoREYKtSXrjjMIzxUJuONckneEpnqHitfbhbyUxfTEzKUnkvnCtqVsqfUZIbFIWba");

    for (int iFyZWQhLysnvhN = 1929626937; iFyZWQhLysnvhN > 0; iFyZWQhLysnvhN--) {
        ArweR = ! ArweR;
    }

    for (int VmLPI = 880834490; VmLPI > 0; VmLPI--) {
        DFdtmCEKXpkYP += rqBJSoBvrH;
    }

    if (ArweR != false) {
        for (int jLRHCsPvnPPefX = 996931097; jLRHCsPvnPPefX > 0; jLRHCsPvnPPefX--) {
            ArweR = ArweR;
            wBNkWwUIEfZlsoa *= DFdtmCEKXpkYP;
            ZXzQCJIn *= njjZeH;
        }
    }

    if (gjbZbHwPJbaZzzV != true) {
        for (int yUkOiNP = 297178853; yUkOiNP > 0; yUkOiNP--) {
            njjZeH /= ZXzQCJIn;
        }
    }

    for (int QzCpswm = 2143603037; QzCpswm > 0; QzCpswm--) {
        wBNkWwUIEfZlsoa *= rqBJSoBvrH;
        rqBJSoBvrH /= njjZeH;
        ArweR = gjbZbHwPJbaZzzV;
    }

    for (int ZDXwG = 591488742; ZDXwG > 0; ZDXwG--) {
        wBNkWwUIEfZlsoa /= ZXzQCJIn;
        rqBJSoBvrH *= wBNkWwUIEfZlsoa;
        wBNkWwUIEfZlsoa /= rqBJSoBvrH;
        njjZeH = njjZeH;
    }

    for (int tEnAviIBiMcFzxVB = 607427234; tEnAviIBiMcFzxVB > 0; tEnAviIBiMcFzxVB--) {
        gjbZbHwPJbaZzzV = ! gjbZbHwPJbaZzzV;
        DFdtmCEKXpkYP = DFdtmCEKXpkYP;
        njjZeH += wBNkWwUIEfZlsoa;
    }

    return gjbZbHwPJbaZzzV;
}

double zzcvUd::cSbkVaOh()
{
    double UvbZy = 145421.50221836945;
    bool enLvpRBQb = true;
    string mRwuuh = string("PugHiXMmXeoLktoQudaWBjjdYBSMPnDbKNgVKvWJGBtWdJAKSWAfkUiUfgSpQHcNxITTtKZVcmpxXvkpMjipjebduwkPwbTabSrusXLANtvnqlqVJvaanVeSKYtwChOhloasbjYnaYahOjrlRacUnpvWvSJBqTh");
    string axpNMhZGqhFC = string("xOfflOnJRjmtjgkBUeDgjvqcWVathLdfeW");
    int TrDrEVEcNG = -2058742960;
    int GImQrYHiqq = -1930323936;
    bool iiNUO = false;
    double VjqJDNEDCnSIClx = 93480.72938937695;

    return VjqJDNEDCnSIClx;
}

string zzcvUd::JXiEeoGs(bool YqVjOKBQzA, bool YbtQymTymhAk, int KZKVIPdhlZW)
{
    string RSpfZvN = string("BsPaGsXZjWoRFqhAXfypPyOYjlqSTjFmdnVsDYpHrzAqucihopIeaqSMBBGiEonqJuRCgWZVkuQaxbaENTsCHsmGgePAaKiJwytqOkNvXHoEzVDpFxVEFSvynPuSdVSFzqsjyZSwLojmVkMKcHUuQhCeKRHxNaSkfKdYYeHmVGJuJNsnbijUYJLdtINFJzikqHf");
    string SHJES = string("oVVsXZTJBsaOXrEJNvVepHUWKhCwpDGdKuYKEIXkzharKXrEiEOichQreZQFhxHsXiFKbkjMleFCgqjtIRQLjDTvzbbSusiOoIEbyyUhUXApoduYBjNCrjHZVhPvVDVkMUjFjeuZFKhdXhEZeXdkYbxnwOWIBeVXAaHmMdlGbvjUJASxjPlAUjHvGKFBqkkZVDAfVuloskONDjqSXrOhsACRJZPYImaxyfqtoHo");
    double lEYeIfpAt = 369827.2954491136;
    double kemrqsssnhBn = -417780.1076215046;
    int DkkjGBARStfxzXaU = -2047136182;
    string FsGnXLvtVWqFYN = string("yKLfXtWemhwGdwUWdSvnyfAftychcaHhSpcbFfDhzhnTdKvZWZByTfRsxVpfNGIKypidPPbMLyFUKIriMehwYitytCQwbbfSxwsnuXiIzDgmMPoZPFiwqyzgodkzYwriieWnjWySKqnCeleNzJWizDEszyJuIzQekAJNRhQxFsRmAeCFlRlqBAVdVtqJxNNzIanAlMPlSLUCAQxkaCmLXmkWtQsCUXL");
    string NphIsndF = string("xATbyRmHHuefsEJCTqGBrqUNfm");

    for (int fsnJayzKF = 848682911; fsnJayzKF > 0; fsnJayzKF--) {
        lEYeIfpAt += lEYeIfpAt;
        FsGnXLvtVWqFYN += RSpfZvN;
        kemrqsssnhBn -= kemrqsssnhBn;
        DkkjGBARStfxzXaU = DkkjGBARStfxzXaU;
    }

    for (int LBZIWRNYHh = 1618114946; LBZIWRNYHh > 0; LBZIWRNYHh--) {
        SHJES += NphIsndF;
    }

    for (int rnlaF = 1419333203; rnlaF > 0; rnlaF--) {
        YqVjOKBQzA = ! YqVjOKBQzA;
        DkkjGBARStfxzXaU = DkkjGBARStfxzXaU;
    }

    return NphIsndF;
}

string zzcvUd::LcvtYujKBgoMBzc(int MtfynSUrIoOiOr, bool qGjJMmMjAjzC)
{
    double oHKSreSslml = -120898.57192896692;
    string ejaToKefikItLznq = string("DebSkXzldOUZGGLHGFPXeruOJdfTZmYiNOehueqjUbflWfksJbaEPcbhCff");
    string beWnpSrfg = string("bWLcGtyxUCvsDslfcSKldBWXRLClxocwTdTqDiVTGrnIKipDfFnKkmbNiLVzvhncJUGIHqPoYdslEtRRJeDdXlArZTvmSfVBmuHPzlxAUILXcujvOdVSRakzfZwKhqUPsKDMoDZrVDBcUYDohXkWlpFKHfDNDOzUIPQXxVtnUxUzajtPyttRpfAgBEDHeABKAYOzjZyywSvpDWaBUyJXNgNwnpiKSTXnHinz");
    bool ZllPSxPyzrvKvFD = true;
    string CyWnqIpqIIuyWn = string("aFqTTwblOynTPHhPmczzyLzRkYDfjtwRWkHmZlmqQNBtTwWiMIYTYpNcCxbQCQUVxAkabOzXGgBLUsOLyrUPPdUJZTKLCrinuJZzICJfnAqILIoPPofkwImgkpfmSjkURFdCdOkQytOgmFdehXDHvUpuFwgmWPsSRgENqaPgBvwZtmQwkwBjnTDwCnoJtlczCbzhCRjGUZxTfsSbfQ");
    double wlAlSLMRjPdF = 212066.28984109306;
    string ESGsiH = string("mHwsYAEgAamjTPwEyLVOBYiAJgletpHeGqBfDLGfYtrFwzkvggLyWVKQXLEzGXnjMQowBfogvPHGqyauuRvkjRYQylNPfJlPQYSPMRveJflYoIyDECzEivmEGFSDDnhUzgmBbDgRvjDCBwTsTcNPZWGzuooPOL");
    int qNbdIH = 1651700235;
    int SmpyYIuvInIn = -453588541;
    double PtHnhAXcM = -533327.6958662698;

    for (int RfCZwyE = 1087199178; RfCZwyE > 0; RfCZwyE--) {
        beWnpSrfg += ESGsiH;
    }

    return ESGsiH;
}

int zzcvUd::pJcccBWkUFAdjTr()
{
    string qDJqfz = string("dUAWaOXJWtrmaoSrMyRcgBTzryCTBkZUbqOsbFPbUwKaiKphZsCCFmecIJibFvePfukIiAXBgItrqZyoETNxnKfvuOyiJXNhDEOomLWHLxzZlsXdWcZqoERfcupueHIFQuBpPeoLxTrwAPSunIeersXzApjzLUnwKphPKEBZZhPXGEFYhgLnQHTeLFjfabFgDmUZsaxySnakCvJqwouGYxMtgnBlGktoBPRPqrZWTzjKkGMV");
    string mbDtLRFoV = string("uNSSOvFqmsorWpZonXifmOxPogzuBCTvMuCXXLkJuJpKNQgBwVeJOZPNOcVEVmGADnpzPmyeWGqaoSTBHuTEhTxcUZnQjFaFvtVqxHNiYhUJzluoXEmcyBlETR");
    int lxwLCmPcxZUTL = 1285744430;

    for (int VuYlnTaTFDjKwwvo = 575834932; VuYlnTaTFDjKwwvo > 0; VuYlnTaTFDjKwwvo--) {
        qDJqfz += qDJqfz;
        mbDtLRFoV = qDJqfz;
    }

    if (lxwLCmPcxZUTL >= 1285744430) {
        for (int uzlOYoMMiKVz = 1001379451; uzlOYoMMiKVz > 0; uzlOYoMMiKVz--) {
            mbDtLRFoV = qDJqfz;
            lxwLCmPcxZUTL += lxwLCmPcxZUTL;
            lxwLCmPcxZUTL -= lxwLCmPcxZUTL;
            mbDtLRFoV = mbDtLRFoV;
            lxwLCmPcxZUTL /= lxwLCmPcxZUTL;
            qDJqfz += qDJqfz;
            mbDtLRFoV = mbDtLRFoV;
        }
    }

    for (int LEhCcTvl = 1330538339; LEhCcTvl > 0; LEhCcTvl--) {
        mbDtLRFoV += qDJqfz;
    }

    return lxwLCmPcxZUTL;
}

int zzcvUd::eZBKeGKMxiYx()
{
    double aHNmwAGSB = 626812.8972128688;
    double YcumIUbzMbOdaTS = 793480.6408642099;
    string tokkv = string("SkINEAOUmlxRsoVJbvuKZjHpYdIgvUCWt");

    if (YcumIUbzMbOdaTS < 793480.6408642099) {
        for (int QMcnWpazVjTf = 248087269; QMcnWpazVjTf > 0; QMcnWpazVjTf--) {
            aHNmwAGSB /= aHNmwAGSB;
            YcumIUbzMbOdaTS /= aHNmwAGSB;
            tokkv = tokkv;
            aHNmwAGSB += aHNmwAGSB;
            YcumIUbzMbOdaTS /= YcumIUbzMbOdaTS;
            aHNmwAGSB *= aHNmwAGSB;
            YcumIUbzMbOdaTS -= YcumIUbzMbOdaTS;
            YcumIUbzMbOdaTS -= YcumIUbzMbOdaTS;
        }
    }

    return -320025514;
}

void zzcvUd::ZXNtGeOLOSRp(double TtGXCpABUlz, int qNBgOvIKKVrd, int xoJrjqqwzsBErP, bool foXdNlLQcRtwzSSH, double YcqBquklwmwtaqjj)
{
    string RKdxClJpWELiZ = string("GyPPqZgiJEGrUygBJWhiubDQxywQrfzbnvbGiYPNNvHFGndJTjIjrSNNFwbuoDcCzbNLvoukXbpRJYdgHiCLsBdenPRJlnfsxrcaeUbAvxTUjrXAymjKdCkyRmHwAaEEffMhuVLkYIxmdqEsiyWkdqMuEWxbKxhUiMGhoDnsPKgHolmTExBagVunDBAyWuuGjRHgUdLYHcIeMjqRKXbbeqpGt");
    bool uoSAJdKPeGC = true;
    string CGGQAGjkj = string("oLVlglGxFcLzyfPmmARvFXbvSlCFbwLsuzZGhddkdlgUPnylXyKSKVYUoTZBAaLWUaDMFCLbXOyCZZbwhtfkyELHNxARKdYOgqzDCERT");
    double QnMgCHpUfDEDqo = 9795.38046404206;
    int NXyinFzBjxzWKqB = 1855874654;

    if (uoSAJdKPeGC != true) {
        for (int szVgipANxw = 384393343; szVgipANxw > 0; szVgipANxw--) {
            continue;
        }
    }

    for (int iVgughIdSK = 944006054; iVgughIdSK > 0; iVgughIdSK--) {
        foXdNlLQcRtwzSSH = foXdNlLQcRtwzSSH;
    }

    for (int OBlFjWo = 1967558422; OBlFjWo > 0; OBlFjWo--) {
        YcqBquklwmwtaqjj *= YcqBquklwmwtaqjj;
        foXdNlLQcRtwzSSH = foXdNlLQcRtwzSSH;
        xoJrjqqwzsBErP -= xoJrjqqwzsBErP;
    }

    for (int AZrSM = 625214784; AZrSM > 0; AZrSM--) {
        NXyinFzBjxzWKqB -= NXyinFzBjxzWKqB;
    }
}

int zzcvUd::FRnEZsqSjCN(double luCKlHXcLsO)
{
    double oqpvdR = -258463.67453537206;
    double ItBOEcq = 27370.539130652105;
    int Tlvip = -841149828;
    int RIOJLgxgehFNK = 419878534;
    double XvaCLPzn = 762968.927830858;
    bool tBfrhdoMoRZxYx = true;

    if (oqpvdR != 27370.539130652105) {
        for (int UwGeLezIg = 101148967; UwGeLezIg > 0; UwGeLezIg--) {
            XvaCLPzn /= ItBOEcq;
            luCKlHXcLsO += luCKlHXcLsO;
        }
    }

    return RIOJLgxgehFNK;
}

void zzcvUd::wDkwwwfxmN()
{
    double kESlsfwF = -254268.24891739394;
    int wwyJADaQDP = -2082459258;
    int EmmSVTYibzJvRMFA = 114666263;
    int jTrMDZcKP = -1203918110;
    int UuMTiXdgeyJ = 1400486075;

    if (UuMTiXdgeyJ <= 114666263) {
        for (int ExDPJQ = 1165428532; ExDPJQ > 0; ExDPJQ--) {
            wwyJADaQDP -= jTrMDZcKP;
            wwyJADaQDP *= UuMTiXdgeyJ;
        }
    }

    for (int FHYAjnKH = 596303935; FHYAjnKH > 0; FHYAjnKH--) {
        EmmSVTYibzJvRMFA += UuMTiXdgeyJ;
        wwyJADaQDP /= wwyJADaQDP;
    }
}

int zzcvUd::lCgGN(bool PDtapinBUEm, string hxYVbJYzNzRKMS, bool WQxFCycd, double ijjikKaZVzqiG, double XnktaN)
{
    string LnWFIrIHFZGIe = string("AKbZHWuATGDBaPGQsbzLJymTicLMfZJzhZoBmF");
    double jAenu = -96402.37260439101;

    for (int UXfIK = 521182319; UXfIK > 0; UXfIK--) {
        hxYVbJYzNzRKMS = hxYVbJYzNzRKMS;
        XnktaN *= ijjikKaZVzqiG;
        jAenu *= jAenu;
        LnWFIrIHFZGIe = hxYVbJYzNzRKMS;
    }

    if (PDtapinBUEm == false) {
        for (int pfrbCHzIwekyKWKh = 1251918403; pfrbCHzIwekyKWKh > 0; pfrbCHzIwekyKWKh--) {
            continue;
        }
    }

    if (jAenu > 196328.69179515983) {
        for (int EGYyKBTB = 1093328012; EGYyKBTB > 0; EGYyKBTB--) {
            WQxFCycd = ! WQxFCycd;
            PDtapinBUEm = ! PDtapinBUEm;
            jAenu -= jAenu;
            PDtapinBUEm = ! WQxFCycd;
            ijjikKaZVzqiG *= XnktaN;
        }
    }

    return 2041604537;
}

void zzcvUd::rDJSlrfaxQPxYHJ(double CtvIkUpoyV)
{
    bool yhHfUsdnLEsPF = false;
    double xBEPYtRpyrU = -96170.10786333372;

    if (CtvIkUpoyV >= -800547.0285138091) {
        for (int xNZvcyFE = 2068992806; xNZvcyFE > 0; xNZvcyFE--) {
            continue;
        }
    }

    if (CtvIkUpoyV == -96170.10786333372) {
        for (int PLKsLNt = 803924693; PLKsLNt > 0; PLKsLNt--) {
            xBEPYtRpyrU = CtvIkUpoyV;
            xBEPYtRpyrU = xBEPYtRpyrU;
        }
    }

    if (xBEPYtRpyrU == -96170.10786333372) {
        for (int yCqZxOCZhuhNFTBt = 936726196; yCqZxOCZhuhNFTBt > 0; yCqZxOCZhuhNFTBt--) {
            CtvIkUpoyV /= xBEPYtRpyrU;
        }
    }

    if (yhHfUsdnLEsPF == false) {
        for (int iUfjCYUIiQMGkL = 945551907; iUfjCYUIiQMGkL > 0; iUfjCYUIiQMGkL--) {
            CtvIkUpoyV *= CtvIkUpoyV;
            CtvIkUpoyV = xBEPYtRpyrU;
            xBEPYtRpyrU -= CtvIkUpoyV;
        }
    }

    if (CtvIkUpoyV >= -800547.0285138091) {
        for (int cbPWoxu = 2024021745; cbPWoxu > 0; cbPWoxu--) {
            CtvIkUpoyV *= CtvIkUpoyV;
        }
    }
}

bool zzcvUd::LDllUqK(double RRvbVfdHhjt, string lPmAOuYsBiXjiC)
{
    double pPbwhGVX = 51654.261654304435;
    int cUvqdmlmAUejcQ = 2141074741;
    bool QIjHEvdYxOEqP = true;
    double hoDFaSzxQcQHyZnG = 795796.2559621392;
    bool oxtqcu = true;

    return oxtqcu;
}

double zzcvUd::uFHWuNGB(int ZkmTIRlHiAnUzH, double oaNopAw, string dwRRwtoEObvHi, bool pdervWmbtYlTrx)
{
    double gOILGyhrXUaDI = 932996.4884912571;
    bool udbIVrzRIHCeFYm = true;
    bool JUTuOx = true;
    string IVcgzMwsuyCT = string("kxEbxxceoMYQJCSEIgEbgNbfWkGpFQnbeDGIEkwdOFJYHLpXNBwQYaDVxVDfQMhWkckBdoOzUaZGzqsVkAkGWNtLfqzQOrlKVqGAevfUXyVpissvXgkdySbNfXYvreBKHReAzNouCsYUKtTQAiOQHlRkubrOaHYjvXIKirC");
    double JJRwfjHbNot = 791930.6583811124;
    string FSocB = string("yJryyVIxOBukZPESncxSZsFReGXJOEpQcnRJtLYMDcagupSNOxxlMvmoPYpzQgvJxDKbQDzxIZk");
    double NAoPLn = 99339.24961445952;
    double uZLqojdfzdnDC = 352607.2277142076;
    int HbAvCizoqaOpkPD = 19088353;
    bool xmlYBWRt = false;

    for (int NBJwxrKikTj = 1386957554; NBJwxrKikTj > 0; NBJwxrKikTj--) {
        oaNopAw += gOILGyhrXUaDI;
    }

    return uZLqojdfzdnDC;
}

double zzcvUd::iYMjuirWx(string bOobMMR, bool xjiWyEEPiVrg, bool Cwntz)
{
    bool ogSgmlVXjWF = false;
    string yxTLvKap = string("eVcbKeIlBFGXxYDBstUnjZjFSOfWhWdSIclRxXBsHXVWVMexyDElpQOaCidnNZhsWTgwLSQUWqoClWtKEsJYmtvUEGZAnlBMtPZVWiGdkUUvATSolnAReAbEIhipzlXy");

    for (int yuJzshkzazNPDyKk = 1228745231; yuJzshkzazNPDyKk > 0; yuJzshkzazNPDyKk--) {
        ogSgmlVXjWF = ! Cwntz;
        bOobMMR = yxTLvKap;
        Cwntz = Cwntz;
        yxTLvKap += bOobMMR;
        yxTLvKap = bOobMMR;
    }

    return 847323.5619767933;
}

zzcvUd::zzcvUd()
{
    this->kHmoYzIgaEHiYhq(834827932, 1968090197);
    this->CeWpkUEP(true, true);
    this->cSbkVaOh();
    this->JXiEeoGs(false, false, 456823703);
    this->LcvtYujKBgoMBzc(-66480473, true);
    this->pJcccBWkUFAdjTr();
    this->eZBKeGKMxiYx();
    this->ZXNtGeOLOSRp(-908357.2140643611, -1130683937, -714902090, true, 435190.02579069097);
    this->FRnEZsqSjCN(-670981.2709475581);
    this->wDkwwwfxmN();
    this->lCgGN(false, string("EdZEYRUECdzHyaQZFReUGOyQhvZxflEHpolUfOFhR"), false, 162687.3051942259, 196328.69179515983);
    this->rDJSlrfaxQPxYHJ(-800547.0285138091);
    this->LDllUqK(-953942.635162755, string("oWAOfaYgWfsGklGYgLpwEYiRjkaaIBTjbKufnmbxSonsIWOiXAsuLunzBdjNxrUmaLpDwMjEKFj"));
    this->uFHWuNGB(-573134319, 985508.741961609, string("ghAlgvKrJjHNAX"), true);
    this->iYMjuirWx(string("RFPMqSYptviLsKWfrcLEqgmNyhoGKWoXzVMeQrtiCVsaMjnhQWoyYWdoTjHegYdmHbnwlaximNADBEUHIyxVMyATmZdRdyAIpuHeKxPSdTQCrWdHyUNQbXVIkyFAmeyXbbPyHuQQTzPQezAxuLoafJBKzIuEcRupaobDIyymgjjLrJFjEfOrESBrllmaYBHUzMdTmaMRJmMDMaKqRfmoeZyzZKKcCGBJ"), true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JwVRaeZVZBl
{
public:
    double vAPhwkM;
    bool QIWgmqjhmvOV;
    string gTMuRvXSVQpCRS;
    bool zMMqIM;
    int pouUGdgSDMrrdT;
    double OOxDuXneajgLtDHR;

    JwVRaeZVZBl();
    double PVJTADVZaqfE(bool jaNSoFQqpxWiJ, double uoKshrLX, bool VlpkXIiBVB);
protected:
    bool fEVvikweRNVL;
    double rNoSPmEUiK;
    int zunth;

    void tEpuUfqZHb();
    string btcMEKsWH(bool EUoph, bool OdqGbg, double FCiiWICq, double ylAIV);
    string RtvFiAoeFXROyd(int rOdepkTLb, double dPNkBvUsp);
    int sffWwSA(bool cHZRjtAKleFi, double NDTSt, double ncTIuFnUqOsdUery, string TBMJUuncBNJPZRmd);
    int jvKidF(bool yTQRgumiscXOVmOK);
    bool kppewu(double PGdcuT, string PkTCIpHTVOyORGIB, bool qMFWgHPgH, bool zHAFydrFsf, bool DwrslbDckDXyY);
    int oioySwiBBtUiL(string TQBstvJBHtRX, string otmoMGYGhvtMFyq);
private:
    bool hyKmBECm;
    string dcBMjwuXxSvP;
    double jZbYIKRHnAZoCcN;
    string RyHtntqoygL;
    int gQsXD;
    bool jctkFcxYBCkzSm;

};

double JwVRaeZVZBl::PVJTADVZaqfE(bool jaNSoFQqpxWiJ, double uoKshrLX, bool VlpkXIiBVB)
{
    bool FWEcBzGqwOqyO = false;
    double apnFLQSSfouTmrY = 996124.1864881244;
    bool jTYPGDpm = true;
    int JLJZVkgtKDuUKAZc = -2044283022;
    double ghckqujheFtKrTP = 960625.6364688445;
    int WuFttbGh = 1928542203;
    bool BMIOBNInJLGdI = true;

    if (ghckqujheFtKrTP != 996124.1864881244) {
        for (int MHjfdU = 709590158; MHjfdU > 0; MHjfdU--) {
            uoKshrLX *= uoKshrLX;
            jTYPGDpm = ! BMIOBNInJLGdI;
            jTYPGDpm = VlpkXIiBVB;
        }
    }

    for (int fxxPqjEYwhtG = 1957962596; fxxPqjEYwhtG > 0; fxxPqjEYwhtG--) {
        BMIOBNInJLGdI = ! FWEcBzGqwOqyO;
        uoKshrLX *= ghckqujheFtKrTP;
        jaNSoFQqpxWiJ = ! VlpkXIiBVB;
    }

    if (apnFLQSSfouTmrY <= 996124.1864881244) {
        for (int EwPKvTLhbQ = 1246469186; EwPKvTLhbQ > 0; EwPKvTLhbQ--) {
            apnFLQSSfouTmrY -= ghckqujheFtKrTP;
            FWEcBzGqwOqyO = ! VlpkXIiBVB;
            uoKshrLX *= apnFLQSSfouTmrY;
            WuFttbGh *= JLJZVkgtKDuUKAZc;
        }
    }

    for (int kcNnoBilag = 1153104114; kcNnoBilag > 0; kcNnoBilag--) {
        continue;
    }

    for (int sglhmBWeZ = 1349104718; sglhmBWeZ > 0; sglhmBWeZ--) {
        jaNSoFQqpxWiJ = ! jTYPGDpm;
        VlpkXIiBVB = BMIOBNInJLGdI;
        BMIOBNInJLGdI = ! jaNSoFQqpxWiJ;
        VlpkXIiBVB = ! jaNSoFQqpxWiJ;
    }

    return ghckqujheFtKrTP;
}

void JwVRaeZVZBl::tEpuUfqZHb()
{
    bool JDuWFOhjLCRPXWC = false;
    bool RQdVKOGvbbtMygo = true;
    string tLfAYvspWXCQ = string("dAyoGNPalzNNYTxQLnWhZHTtyPqdgQdLlNXGhpFqdBhGxtkQZIDYTihZxxyJeMxWiWEsSyAQXevmqQSDmQaFALBVyZAxDWJaUnVoBYFwdLRRDoIUjqAk");

    for (int bovRr = 1460149990; bovRr > 0; bovRr--) {
        tLfAYvspWXCQ = tLfAYvspWXCQ;
        RQdVKOGvbbtMygo = ! RQdVKOGvbbtMygo;
        tLfAYvspWXCQ += tLfAYvspWXCQ;
    }

    if (RQdVKOGvbbtMygo == false) {
        for (int hLMovsw = 1776123081; hLMovsw > 0; hLMovsw--) {
            JDuWFOhjLCRPXWC = ! JDuWFOhjLCRPXWC;
            tLfAYvspWXCQ += tLfAYvspWXCQ;
            JDuWFOhjLCRPXWC = JDuWFOhjLCRPXWC;
            RQdVKOGvbbtMygo = RQdVKOGvbbtMygo;
            tLfAYvspWXCQ += tLfAYvspWXCQ;
            RQdVKOGvbbtMygo = ! RQdVKOGvbbtMygo;
            JDuWFOhjLCRPXWC = ! JDuWFOhjLCRPXWC;
            tLfAYvspWXCQ += tLfAYvspWXCQ;
        }
    }

    if (tLfAYvspWXCQ > string("dAyoGNPalzNNYTxQLnWhZHTtyPqdgQdLlNXGhpFqdBhGxtkQZIDYTihZxxyJeMxWiWEsSyAQXevmqQSDmQaFALBVyZAxDWJaUnVoBYFwdLRRDoIUjqAk")) {
        for (int KBwDBMJlhhSCK = 799564433; KBwDBMJlhhSCK > 0; KBwDBMJlhhSCK--) {
            JDuWFOhjLCRPXWC = RQdVKOGvbbtMygo;
        }
    }

    if (RQdVKOGvbbtMygo == true) {
        for (int tSaMpCwCeQ = 1805707890; tSaMpCwCeQ > 0; tSaMpCwCeQ--) {
            tLfAYvspWXCQ += tLfAYvspWXCQ;
            RQdVKOGvbbtMygo = ! RQdVKOGvbbtMygo;
            tLfAYvspWXCQ = tLfAYvspWXCQ;
            RQdVKOGvbbtMygo = ! JDuWFOhjLCRPXWC;
            RQdVKOGvbbtMygo = ! JDuWFOhjLCRPXWC;
        }
    }
}

string JwVRaeZVZBl::btcMEKsWH(bool EUoph, bool OdqGbg, double FCiiWICq, double ylAIV)
{
    int XKACMVrPmK = 626546607;
    int rACqusSRakNuxl = -885088160;
    string uWwLaqAPEBOxiN = string("QlsqJfNehAyqHqCCMNchHZOxTTGlyNNRYKABRyiIOMKdzETweLZDReVjhsTewdPohPAIiatzwRwzEPRhAnERKwNKigcXfnIzLFBhC");
    bool WrGrvhAOwf = false;
    string dFxazHysaQHXc = string("vpyCmiiihpyUwAVVgfxScnRvgIBkrfUXEXoKaaoBAtSIxRfmSkmNQORhMhaWItRPPajRQClUQxAVmfrKAHIbVNuZDitdsinzMDobanYrPhRuICnfUAiuXjUfHFZuoBEKJKxksqtpXpUaGEiQlXCAqSGjTZQKIZpyhQyCMqOhSzIJnr");
    int kMfMeZXmaWOoYt = 1731013783;
    bool kuhAtRUweqRTkzco = true;
    int bYmiejXCCTLX = 1279785804;

    for (int XgWYbnICfItDb = 630369822; XgWYbnICfItDb > 0; XgWYbnICfItDb--) {
        bYmiejXCCTLX *= rACqusSRakNuxl;
        OdqGbg = ! EUoph;
        dFxazHysaQHXc += dFxazHysaQHXc;
    }

    if (EUoph != false) {
        for (int yTKinRD = 793309030; yTKinRD > 0; yTKinRD--) {
            bYmiejXCCTLX -= kMfMeZXmaWOoYt;
        }
    }

    for (int eyoPJ = 38999266; eyoPJ > 0; eyoPJ--) {
        kuhAtRUweqRTkzco = WrGrvhAOwf;
    }

    if (WrGrvhAOwf != true) {
        for (int coitgfJsacJnUVf = 1021753627; coitgfJsacJnUVf > 0; coitgfJsacJnUVf--) {
            EUoph = ! EUoph;
        }
    }

    if (OdqGbg != false) {
        for (int olWTEE = 853263820; olWTEE > 0; olWTEE--) {
            OdqGbg = kuhAtRUweqRTkzco;
            EUoph = OdqGbg;
        }
    }

    for (int ijRkyqhUghmfhsn = 1787037103; ijRkyqhUghmfhsn > 0; ijRkyqhUghmfhsn--) {
        continue;
    }

    return dFxazHysaQHXc;
}

string JwVRaeZVZBl::RtvFiAoeFXROyd(int rOdepkTLb, double dPNkBvUsp)
{
    double czAXksj = -250910.0101035196;
    int JprpOgeVff = -1738694236;
    int eucfuaL = 2088294497;
    bool kZakNdtFi = false;

    for (int SGzco = 1230456038; SGzco > 0; SGzco--) {
        JprpOgeVff = rOdepkTLb;
    }

    return string("lQpoOdfTTLzdFlrAkXzdkYARdYBBaCKT");
}

int JwVRaeZVZBl::sffWwSA(bool cHZRjtAKleFi, double NDTSt, double ncTIuFnUqOsdUery, string TBMJUuncBNJPZRmd)
{
    double SsByWvcoKH = 36038.55069085931;
    double PCxLZHOBmwpD = -969213.1392169797;
    bool NXUqbIoaUeFy = true;
    int ujNeLzCtSuOSsiXC = -1590748375;
    bool lvBjnsWxenVNiHOJ = true;
    double drejaw = 973133.5610464403;
    string AcBPtcFI = string("HRSsoYjhZcPMUpsDABoiTpkRzuiOfmehSWDoRpoDMGAtsOAwrsuxWCxVKQZjWgifpgqokjuXfjdprTUqRHCwrkYUeYjIYGJVbWmcpdVVMAhScEYUBvQpSYMZUBlmHKklFTjyderrTLooYzyEZgpOnzmowhqkZXsKoupAqyfwVeTAmqEzlQpjzrGntQTdNMYCykbdmWbTNcSGNIsCguxhmnMalXZgbDhcpjnGDJ");

    for (int GoEMiRewyuafPSSg = 1499589441; GoEMiRewyuafPSSg > 0; GoEMiRewyuafPSSg--) {
        SsByWvcoKH += PCxLZHOBmwpD;
        lvBjnsWxenVNiHOJ = ! cHZRjtAKleFi;
        lvBjnsWxenVNiHOJ = ! lvBjnsWxenVNiHOJ;
    }

    return ujNeLzCtSuOSsiXC;
}

int JwVRaeZVZBl::jvKidF(bool yTQRgumiscXOVmOK)
{
    bool zzVKAusYgH = true;
    int DxdtyXNmzH = 2041736906;
    string MMMmFpGXmOl = string("xtvVeeiPDpWxfawnOcXqGKuPXeLIgGOatFUdZHxpOVCVEazjrfAkoQwPRPVLoJZVtMugFkJXUEKfdibVpudJUvbdlGiCPILrsuFBmMtSSvwJJo");
    int FLnWjAPjPQrJ = 1282203102;
    int KoVGn = 436921894;
    string fgCztbSEmO = string("hCPXLMLZqzsRcarefbMkYasbFpxAqbylwpjjKdFVv");
    bool rtOOftRyP = true;

    for (int avpNHUzAafseWFp = 894820045; avpNHUzAafseWFp > 0; avpNHUzAafseWFp--) {
        rtOOftRyP = yTQRgumiscXOVmOK;
        DxdtyXNmzH *= FLnWjAPjPQrJ;
    }

    if (FLnWjAPjPQrJ <= 1282203102) {
        for (int YQygE = 623099010; YQygE > 0; YQygE--) {
            continue;
        }
    }

    return KoVGn;
}

bool JwVRaeZVZBl::kppewu(double PGdcuT, string PkTCIpHTVOyORGIB, bool qMFWgHPgH, bool zHAFydrFsf, bool DwrslbDckDXyY)
{
    bool UMzxrbAdVoaPuj = true;
    int VfGplxSPatOWV = -275675276;
    bool JpQUOrfshtfQwVr = false;

    for (int QLhIwJCZ = 1465010449; QLhIwJCZ > 0; QLhIwJCZ--) {
        UMzxrbAdVoaPuj = ! DwrslbDckDXyY;
        UMzxrbAdVoaPuj = zHAFydrFsf;
    }

    for (int LpHnpDadXQNjx = 448146406; LpHnpDadXQNjx > 0; LpHnpDadXQNjx--) {
        zHAFydrFsf = UMzxrbAdVoaPuj;
        UMzxrbAdVoaPuj = UMzxrbAdVoaPuj;
        qMFWgHPgH = UMzxrbAdVoaPuj;
    }

    if (UMzxrbAdVoaPuj != false) {
        for (int hjJwPQwao = 160251204; hjJwPQwao > 0; hjJwPQwao--) {
            zHAFydrFsf = ! qMFWgHPgH;
        }
    }

    return JpQUOrfshtfQwVr;
}

int JwVRaeZVZBl::oioySwiBBtUiL(string TQBstvJBHtRX, string otmoMGYGhvtMFyq)
{
    string pOUlHrt = string("dMGsOpvdZGnmuaZfPYNXCsCanbhEjPKIqpSYmAvGtUkzOvWTqYsDJCeqTttBicpPtXudwRnkupMyHeczgkrXhgtYbFQJgwpseWQOMZ");
    double xfffHnoPLBqzwf = -343964.8482238025;
    int EGaGtOvYtm = -79899659;
    double uTpLwhdaOLrfOfwI = 106983.10126158647;
    bool zvqWrgRX = false;
    double FsPKZ = -677473.4710308227;
    bool oSarFEp = true;

    for (int QyPsUYlaL = 2078554626; QyPsUYlaL > 0; QyPsUYlaL--) {
        oSarFEp = oSarFEp;
        pOUlHrt = otmoMGYGhvtMFyq;
        TQBstvJBHtRX += pOUlHrt;
        FsPKZ += FsPKZ;
        xfffHnoPLBqzwf /= FsPKZ;
        zvqWrgRX = oSarFEp;
        otmoMGYGhvtMFyq = pOUlHrt;
    }

    return EGaGtOvYtm;
}

JwVRaeZVZBl::JwVRaeZVZBl()
{
    this->PVJTADVZaqfE(false, -568757.8226024382, false);
    this->tEpuUfqZHb();
    this->btcMEKsWH(false, false, 932907.4387805124, 438559.48311124777);
    this->RtvFiAoeFXROyd(1140478569, -229851.97545046784);
    this->sffWwSA(true, 288314.0831574228, -821335.8652327136, string("HnlQOSmPAlpJlPhmwZmHrucIDDFbVpRROwpGiTqLhKvrbiVYKSPsQQmcIhnOgUZkPFcWyoGmNFtUxHCYqzXwkmNmPPkeWMWYUCotpQqIYRCfanIXlYDXTEfsjZFBcepgyjPVuAHxtrYJUEKhUgQkLXkltxT"));
    this->jvKidF(false);
    this->kppewu(254076.3860005203, string("SEuCwOPHxdjLYkYOUZscyLCarBZDyZYJjomLfhZDEhnmJcnesyqzKPuibDAXXkPcQSrJfYkpOKRHXLeRFVKoPerQmdstkNjSYzAIgmkFPiZSBHIYRYlDKtFePlTvuBhlnovKfynKqyFLXxRxEINgcjjHjftbYOsXhDGCwSAWLrYngUfSoyjaTKszAYyiEvlXZpVndgJvuyvsIkdwErdUMakfGzBcMEewTVbGkSYxaWJZkNZCQJ"), true, true, false);
    this->oioySwiBBtUiL(string("DrmsqdCFXSEZfIqVLSxTJvyFKmNHacbrLMEEYfzkaMKrqgbfQDmkllHQJvtaxYvSvgCSNQtFikxkHUcuPKAZYlRFTNQPcuIicaVQjHPrgYuzYGYjrGJtlpuFDebpriTwNGGzDbGHGySEEbuNCwOlMKPBXPqlmRXmsXiigZDNbueNcXGiOdIbLlVpVJboLotAlbgSHYxucqcdtVp"), string("RNcbVxdwjxwuRKVswVryGEYDCEJFsUyhfaxbZEClIpYzRQlUGodyFkBSOpozmDxHFiWGOoEpAXQBMHquRbwoLBSbBqmkMftrqiQfjWZsaSlhtiDwkTfYZQWpeuLpGpxjItsTSWxDIINUYjtnDsarbatgsILyvDypNEhKPiSrFRNuwGcYwlgHwTLoISROa"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ajJwnWiZbCDNeei
{
public:
    bool HtDnrqZQbNwzHxxV;
    int CbMbYzIQlHqvPEjs;
    string dYZTPXDE;

    ajJwnWiZbCDNeei();
    double JaSUuGIKikIBM();
    bool qIvawinQKNmdRXVZ(string osrbQaUQjKVli);
    int lzbcFfhYRlA();
    string BYzoTB();
    void arqhzvItMAdIsN(double pvoGscsbceJCCO, string elxmsnUDrbaEPbfx, string KKtSD);
protected:
    string BiAfTiEbqC;
    bool nOblyrjRF;
    double aqLPHIxMdYlvmHW;
    bool OhLfDgF;

    string KeBdiFuRJiVeZOYA(string aikhgCfCh);
    bool YazgzsUj(int blfkELGZ, string SGkWNyRxSz, bool iZViElnvWQsdtFHr, int mGyFiETwGF, string rIxnKKYXz);
    bool zFkykeVaqkaP(int CRTnAScmJ, int fQRddAyESLYWYK, double FZqbWBCVPfPvzXOO, string rdSSlERdKz, int eZmID);
    bool NlsGpMgonQoY(int JeWCKlmzANkhskB);
private:
    int GXzDuFCaqEGdPmA;
    int TwzIEDrARApyP;
    bool mvnvVfKVJB;
    string TaCFbvHUNoSUuKLK;
    double UWJtbgRfceZk;

    int butEZVQmDIop(int nBrpJYvKKLj, bool XsBnQPLPusBn);
};

double ajJwnWiZbCDNeei::JaSUuGIKikIBM()
{
    bool uSTJSJGhpcK = false;
    bool LddsmOYe = false;
    bool ZQScWsUQNs = true;
    int HHVPUWaWpKOWpdYw = 422784241;

    for (int mWISbWAgZPjJhdG = 767710091; mWISbWAgZPjJhdG > 0; mWISbWAgZPjJhdG--) {
        LddsmOYe = ! uSTJSJGhpcK;
        ZQScWsUQNs = ZQScWsUQNs;
    }

    for (int EBKvP = 18228801; EBKvP > 0; EBKvP--) {
        LddsmOYe = ! ZQScWsUQNs;
        LddsmOYe = ! uSTJSJGhpcK;
        uSTJSJGhpcK = ! LddsmOYe;
        LddsmOYe = uSTJSJGhpcK;
        ZQScWsUQNs = ! ZQScWsUQNs;
    }

    return 289440.54598979314;
}

bool ajJwnWiZbCDNeei::qIvawinQKNmdRXVZ(string osrbQaUQjKVli)
{
    double KCMcGMXIlOqZkP = -880713.7869683588;

    for (int EHhODnjykv = 1064718220; EHhODnjykv > 0; EHhODnjykv--) {
        continue;
    }

    if (KCMcGMXIlOqZkP == -880713.7869683588) {
        for (int NUbFkf = 808214589; NUbFkf > 0; NUbFkf--) {
            KCMcGMXIlOqZkP /= KCMcGMXIlOqZkP;
            osrbQaUQjKVli = osrbQaUQjKVli;
            KCMcGMXIlOqZkP = KCMcGMXIlOqZkP;
        }
    }

    return true;
}

int ajJwnWiZbCDNeei::lzbcFfhYRlA()
{
    double zcqBFs = 104557.8382319444;
    int EuoLnD = -335052197;

    if (EuoLnD > -335052197) {
        for (int FFxSDecUz = 392241376; FFxSDecUz > 0; FFxSDecUz--) {
            zcqBFs = zcqBFs;
            EuoLnD -= EuoLnD;
            zcqBFs *= zcqBFs;
            EuoLnD /= EuoLnD;
            EuoLnD -= EuoLnD;
        }
    }

    for (int YLgitIANA = 640310529; YLgitIANA > 0; YLgitIANA--) {
        zcqBFs /= zcqBFs;
        zcqBFs += zcqBFs;
        zcqBFs *= zcqBFs;
        EuoLnD += EuoLnD;
        EuoLnD -= EuoLnD;
        EuoLnD /= EuoLnD;
    }

    return EuoLnD;
}

string ajJwnWiZbCDNeei::BYzoTB()
{
    bool SGOxzPLPjoJ = true;
    bool UWIghTH = true;
    string QlAwjA = string("AsRnvfZauVtIIGYoEAZcPJUuHlHkKPewWXLQZqdamTDvOKZCccYyfcDubxrkdBbhOUENJunnjYVLzgIrnWnoSwPRr");
    int McYTLCIIatNhUT = -1552738515;
    bool IasNbdJWo = false;
    double VgcON = -877169.9346052731;
    bool TDvedWtROrInQqtR = false;
    int XqmtYhcgqpL = 2036453543;
    string okGZr = string("RsCksdYyLojryqZxFSUImGIjSIgxZfhUSzDcuOwvfTmNLWbEseZdjOULOrkgtHnIJYNQEcdFibuYudOSjjENChujAsjCXbtFbuKsDsQaMfXczlKOwddQoDXgiLdwHTqRAzLLTDvCePjpoioWwfTBdiOjrsIYoeywvxjPxsXPLxNUElOvCwgvNHucCwAgfgzyypdewTmQJxUTxKWXCqUtCJwmwjShLsEAXaJlcuH");
    double yFZbSOEnkFltaX = -113480.36781989748;

    if (XqmtYhcgqpL >= -1552738515) {
        for (int ldjgPTaAksLSb = 1419162247; ldjgPTaAksLSb > 0; ldjgPTaAksLSb--) {
            yFZbSOEnkFltaX *= yFZbSOEnkFltaX;
        }
    }

    return okGZr;
}

void ajJwnWiZbCDNeei::arqhzvItMAdIsN(double pvoGscsbceJCCO, string elxmsnUDrbaEPbfx, string KKtSD)
{
    bool cvBCNzHxnmQyPbbj = true;
    bool GQVGcYtFxc = false;
    bool sYchrPuVynKa = true;
    string XMwQzXpZBupMw = string("fpvDVLBLnJGSvKKyaLtxSyJpffyRqBhSPhTanAkNOaaECQcQAYxqomdSvPTxMjDGRNGUvwSJSNpprJr");
    bool ZgxepVutkqDbYc = false;
    int dskrJLHdCn = 952233748;
    int fiPnjhG = -705318351;
    string pigjq = string("kju");
    string fKKvxgbjRapfvUp = string("XaaNWNXAgjrFZnwVfGuCysaaPbFbWIPjyLoItyGXyjltYqimAzuJZCUVDmfnMCcAFgEudxeSBHWwEoCqycfETqCcfmHYupwzpogzPYmdrKCcgsGcOLsQAxTHDbaQqYMcusiewkeezBsIPinyjLHlTtisyFBWeKNxPCHwwVZDpqIErtLT");

    for (int ZcwDMfsARJNZpBC = 1961965910; ZcwDMfsARJNZpBC > 0; ZcwDMfsARJNZpBC--) {
        cvBCNzHxnmQyPbbj = ! cvBCNzHxnmQyPbbj;
        elxmsnUDrbaEPbfx += KKtSD;
    }

    for (int uwIvmRhNGDPFcn = 322447801; uwIvmRhNGDPFcn > 0; uwIvmRhNGDPFcn--) {
        elxmsnUDrbaEPbfx += pigjq;
    }

    if (dskrJLHdCn < 952233748) {
        for (int zpllkFsN = 1963788635; zpllkFsN > 0; zpllkFsN--) {
            pvoGscsbceJCCO -= pvoGscsbceJCCO;
            GQVGcYtFxc = ! GQVGcYtFxc;
            cvBCNzHxnmQyPbbj = ! GQVGcYtFxc;
            KKtSD = XMwQzXpZBupMw;
        }
    }
}

string ajJwnWiZbCDNeei::KeBdiFuRJiVeZOYA(string aikhgCfCh)
{
    string QEogR = string("yAFCkvlZbzbrmmdakiUZbZHjwdpwsHCKqZDukNOrfhfqQVrLUjVcffckpvzpYhgZmuCLgdkuufxayjLFoQwpnwzYfBSKrVJRjppqjTeGmBhibJrqRPnoOMeNXLtdAFuzRHTJfxwsmvozWHwFYoHyUKYygxZcKqkoZJPdQcCFsvTEICmDOiKXh");

    if (aikhgCfCh < string("yAFCkvlZbzbrmmdakiUZbZHjwdpwsHCKqZDukNOrfhfqQVrLUjVcffckpvzpYhgZmuCLgdkuufxayjLFoQwpnwzYfBSKrVJRjppqjTeGmBhibJrqRPnoOMeNXLtdAFuzRHTJfxwsmvozWHwFYoHyUKYygxZcKqkoZJPdQcCFsvTEICmDOiKXh")) {
        for (int DaxlA = 1193221334; DaxlA > 0; DaxlA--) {
            aikhgCfCh = QEogR;
            aikhgCfCh = aikhgCfCh;
            QEogR += aikhgCfCh;
            aikhgCfCh += QEogR;
            aikhgCfCh = QEogR;
            QEogR += QEogR;
            aikhgCfCh += QEogR;
            aikhgCfCh += QEogR;
            QEogR = QEogR;
            aikhgCfCh += aikhgCfCh;
        }
    }

    if (aikhgCfCh != string("tSVMboTysRVYTBFdTAumeleXpC")) {
        for (int yfNeJZUZWWSXb = 485643615; yfNeJZUZWWSXb > 0; yfNeJZUZWWSXb--) {
            QEogR = QEogR;
        }
    }

    if (QEogR != string("tSVMboTysRVYTBFdTAumeleXpC")) {
        for (int aUYvdEiSUo = 1747417987; aUYvdEiSUo > 0; aUYvdEiSUo--) {
            aikhgCfCh += QEogR;
            QEogR += QEogR;
            aikhgCfCh = aikhgCfCh;
            QEogR = QEogR;
            aikhgCfCh = aikhgCfCh;
            aikhgCfCh += QEogR;
            QEogR = QEogR;
            aikhgCfCh = QEogR;
        }
    }

    return QEogR;
}

bool ajJwnWiZbCDNeei::YazgzsUj(int blfkELGZ, string SGkWNyRxSz, bool iZViElnvWQsdtFHr, int mGyFiETwGF, string rIxnKKYXz)
{
    bool hmuBKAFq = false;
    double jVSJUU = 835423.7554784621;
    int rbamPRZxiNkk = -1180888495;
    string dYLtSIixWTuUytOV = string("BBhoSjYiQkSKzrsDPcQHtHHxpaTDeFFBOrJBvSWjHWmxMUYn");
    double DEHExX = -425434.7557533806;
    int WturdyziyOEP = 1189271421;
    string hGWxDpvFtEjp = string("HahKOisxqkDgGPSsUzoWhcjcwUXtPoFAPrBbyPiYQLLAYYEQzDFJWJjWfEtjqVPRHsDKYktxqHZhMPothJSOwMSJBwOEXtYbsAvBpXMhQvBiooHhPIukaCzHOQVyAdsCVCACQSKJCCeqaqdkpQRoclEWgvkGGXqxrfLjGubwEuqYCsEYuzkCNLdSCYQbaolNrldmuozVkMHZKTBCfeXdOcfDNeEQLuALvEkyAgQPwEuFAWCVCosLeCuWZMRqHa");
    int XPJoQEoalcbp = 1113484186;
    bool XxULT = false;
    int WstrxE = 335540657;

    for (int JztDfXvXKCjUSxFy = 2097481528; JztDfXvXKCjUSxFy > 0; JztDfXvXKCjUSxFy--) {
        continue;
    }

    for (int VDTZrAOCxDE = 694515585; VDTZrAOCxDE > 0; VDTZrAOCxDE--) {
        hGWxDpvFtEjp = SGkWNyRxSz;
        blfkELGZ += WstrxE;
    }

    return XxULT;
}

bool ajJwnWiZbCDNeei::zFkykeVaqkaP(int CRTnAScmJ, int fQRddAyESLYWYK, double FZqbWBCVPfPvzXOO, string rdSSlERdKz, int eZmID)
{
    int xekDF = -1403114727;
    int GcerwdEWhWWsG = -513600201;
    double QIkKO = 202617.58218303823;
    string KtPrssvtYKzY = string("zRflYAmiRrWLDYNkhSwVvemfGhfKKvNZitAGTtlNLdSITtyCwBpgRUpFiinTMsXWYNcQpYEtXrHriNOyLHApZDXqquhjUwqheImgRXDmjXSzmbOCjkmcmaZMeRvYiTRvBvqKfPwEZTAotAgkFkqiLGUquTCOoIwkTIHTBaIlMHcKZmtmbdlBIetLEsaYXZEKOYpVhHYkCgedReUOKLRtkVeDVrvFmcfcRpFtejxbc");

    if (fQRddAyESLYWYK > -1403114727) {
        for (int qfKqCorCoAYE = 868129111; qfKqCorCoAYE > 0; qfKqCorCoAYE--) {
            CRTnAScmJ = xekDF;
            fQRddAyESLYWYK -= CRTnAScmJ;
            xekDF -= fQRddAyESLYWYK;
            xekDF /= eZmID;
            GcerwdEWhWWsG /= GcerwdEWhWWsG;
        }
    }

    for (int cKHyPLOpNh = 1478948392; cKHyPLOpNh > 0; cKHyPLOpNh--) {
        xekDF -= fQRddAyESLYWYK;
    }

    return true;
}

bool ajJwnWiZbCDNeei::NlsGpMgonQoY(int JeWCKlmzANkhskB)
{
    double oQwipDTHPzHerwBz = -706941.7055329267;
    bool ObZlvQewd = true;

    if (ObZlvQewd == true) {
        for (int AJZMcvlg = 1303480713; AJZMcvlg > 0; AJZMcvlg--) {
            oQwipDTHPzHerwBz = oQwipDTHPzHerwBz;
        }
    }

    return ObZlvQewd;
}

int ajJwnWiZbCDNeei::butEZVQmDIop(int nBrpJYvKKLj, bool XsBnQPLPusBn)
{
    double fGwtTRd = 411327.5275068087;
    bool AKefd = true;

    return nBrpJYvKKLj;
}

ajJwnWiZbCDNeei::ajJwnWiZbCDNeei()
{
    this->JaSUuGIKikIBM();
    this->qIvawinQKNmdRXVZ(string("ybCvLnOETnCOgnlhMQSTXIvlFELSxbhOiQMgPNhhAHQjcyXPEzahOPiWLmitaAlqecWMzGqviDJJvKywRTjOevrvVEItYYSLzOkRVKnkddeylRSScJFogKTTyHKvd"));
    this->lzbcFfhYRlA();
    this->BYzoTB();
    this->arqhzvItMAdIsN(-917827.8048935524, string("IUEuyeWQDOsUrQdbulbumxbryMTSs"), string("VkVFUEMnUVDTqNWTeyblGuzkrBCfbyvHPZkVrNfpowyZKlJoqjoPyChZPrOANGfGonBKdRjIFOxRHHkFXFs"));
    this->KeBdiFuRJiVeZOYA(string("tSVMboTysRVYTBFdTAumeleXpC"));
    this->YazgzsUj(-1411089096, string("ntzvOszgVEXIjYAZXnhnrnlYFPdyHsCYMlxXnkrfmqRqIeuIYqJIKfZMyUtFnBXEUyBwGGaVDGAr"), false, -1389186425, string("WrSkluMKKOiojBiSyEMTAzuDWmuFdAbGkgmp"));
    this->zFkykeVaqkaP(-1679371545, 1777694436, 129493.99300452374, string("XddKatubxIZbAsWvkZfDTVFFfIEHWTiinTemXBBaiIlIahQnzXBLxgLGHDEagzQlNiSxxYgKWzEWxvrAnlwCIgNwtiDNeONbMdZSbciw"), 637573465);
    this->NlsGpMgonQoY(-1762584374);
    this->butEZVQmDIop(347910724, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QjqoRHkNldaeAN
{
public:
    double jkjJAFx;

    QjqoRHkNldaeAN();
    double MVZVKkwwErEPb(bool LkmNjODrw, bool MNCTwjuIzfvkknV);
    double cxxHUowrjalzE();
    int RNsRYeJNq(bool RRcRYpoLLs, double HqLQzOi, int evYXYuaNjpXCUBiG);
    double EURVifrpufAZc(double BciBUsYFJr);
    bool Xkjwxf(bool pVFqTeYIZkbQ, double cbCPtNFUs, int STSMlY, int zQbanfxoHnvM, int xvKKIJ);
    void bXpZhkqJCCIU(bool atgbyJuIiwfS);
    void wwCySiOjick();
protected:
    string GTTBNFXCvhnUq;
    int uomZiW;

private:
    double rZAtoEidlnVquZpO;
    bool LnKpDC;
    string TDIByymjhVVRoRyW;

    int RsekGjot(bool zwWHiVuI, string oLSlT, string syXeSUAa, bool vcPDA);
    double GvwjNHmJJtWk(bool ITmqBvrlKoAjuF, double dBbmfyW, int XeBaxScEd);
};

double QjqoRHkNldaeAN::MVZVKkwwErEPb(bool LkmNjODrw, bool MNCTwjuIzfvkknV)
{
    bool bUAOoJt = false;
    double PHhmDsAgWFs = 106337.55359057843;
    double VsZViDOsu = -970909.8179568923;
    bool goQYbWbR = true;
    int rkkTE = 1328163274;
    string KlhMcaqXrgxgYi = string("xxwMSVvADOEZTynWxoKzfLsQniBACxRxwZnEalkNmPWocaLZuMrCDgyEkAcNoBnDsIDgismzsLWuUQrioHHjYDEyesmlfITaTniYfWOGGWJTAnrJYGNBBfaurxKfrytgnYklyAtzTgwmIQtAhtTGqUQbe");
    double eEhwr = 591203.1819367567;
    string BSgiVdqWtBxG = string("mnMrKNYKWukPNsadhfSddoLJNogiyppqxkxwwzImsUBLwNNwrIktVjEJqyskQoaliiZELARlimXqFwxscuglKnJJIlRXjJcZheibJYGjXVPegfv");

    return eEhwr;
}

double QjqoRHkNldaeAN::cxxHUowrjalzE()
{
    double XwjScnTreg = -4156.0448539955805;
    double NdRmdsgcaZOH = 10833.258503097286;

    if (XwjScnTreg == -4156.0448539955805) {
        for (int DpzszB = 492600069; DpzszB > 0; DpzszB--) {
            NdRmdsgcaZOH *= XwjScnTreg;
            XwjScnTreg += NdRmdsgcaZOH;
            NdRmdsgcaZOH /= NdRmdsgcaZOH;
            XwjScnTreg += XwjScnTreg;
            NdRmdsgcaZOH -= XwjScnTreg;
            NdRmdsgcaZOH = XwjScnTreg;
            NdRmdsgcaZOH -= XwjScnTreg;
        }
    }

    if (NdRmdsgcaZOH > -4156.0448539955805) {
        for (int vgbXoCmIDQKJGcr = 147493149; vgbXoCmIDQKJGcr > 0; vgbXoCmIDQKJGcr--) {
            XwjScnTreg += NdRmdsgcaZOH;
            XwjScnTreg /= NdRmdsgcaZOH;
            NdRmdsgcaZOH = NdRmdsgcaZOH;
            XwjScnTreg /= NdRmdsgcaZOH;
            XwjScnTreg += XwjScnTreg;
        }
    }

    if (NdRmdsgcaZOH != -4156.0448539955805) {
        for (int psQAnSGPPGXvftk = 1699401416; psQAnSGPPGXvftk > 0; psQAnSGPPGXvftk--) {
            XwjScnTreg = XwjScnTreg;
            XwjScnTreg /= XwjScnTreg;
            XwjScnTreg /= NdRmdsgcaZOH;
            XwjScnTreg *= NdRmdsgcaZOH;
            NdRmdsgcaZOH = XwjScnTreg;
            NdRmdsgcaZOH = XwjScnTreg;
            NdRmdsgcaZOH -= XwjScnTreg;
            XwjScnTreg -= XwjScnTreg;
            XwjScnTreg *= XwjScnTreg;
            XwjScnTreg *= XwjScnTreg;
        }
    }

    if (NdRmdsgcaZOH != 10833.258503097286) {
        for (int TxhusQHPl = 536773015; TxhusQHPl > 0; TxhusQHPl--) {
            NdRmdsgcaZOH /= NdRmdsgcaZOH;
            NdRmdsgcaZOH -= NdRmdsgcaZOH;
            XwjScnTreg /= NdRmdsgcaZOH;
            XwjScnTreg /= XwjScnTreg;
            NdRmdsgcaZOH += NdRmdsgcaZOH;
            XwjScnTreg *= NdRmdsgcaZOH;
            NdRmdsgcaZOH = XwjScnTreg;
        }
    }

    return NdRmdsgcaZOH;
}

int QjqoRHkNldaeAN::RNsRYeJNq(bool RRcRYpoLLs, double HqLQzOi, int evYXYuaNjpXCUBiG)
{
    int gGoNmjA = 1889623710;
    bool oJqtewz = false;
    bool JuTWgvvGh = false;
    int ETbeSTEtgmDRiNex = 1998140669;
    double ZtMEGFxfNgo = 662359.3695145285;
    string iuHClRGLheG = string("wyHrGJpjllywcjlayMijKszFTBslKGBptGWzXBRpEsSdflAjKdVAvRVRiuLkWIMhbrkUrmvHvpRlkHUJLtWlHXHOAfoMUZhBjiuKzApRuBNZqCDWbxfojhteJFyoohJCKIfAejpmBzWCdoYbYtJmnckAuzaBfuWhjRumSnDYgOqeolHsYqmBZscsGjwYAJHwBLlBZiDbUDMAcwsFCedWP");
    string ReFoUHAwM = string("mRnXSQSOTxiTptEuvUcUDtdGyanDyYhHphUiXnqiZfQpnUinoYUvwhjhpDzzjRSzypHiOXctrmDEqUBSbWquScrKeEwVlKbmUxyQsJEccIiVYMLmVoLCBxeNZeTacaXxxwvHfbnOhgSllteTaeJPAIJtxIHkYXQAkyyugdg");
    double uIrdKkOEel = -379463.76058197016;

    if (evYXYuaNjpXCUBiG != 1889623710) {
        for (int aoOyGVsRmLV = 2088934743; aoOyGVsRmLV > 0; aoOyGVsRmLV--) {
            ETbeSTEtgmDRiNex += gGoNmjA;
        }
    }

    for (int fehrMT = 149960588; fehrMT > 0; fehrMT--) {
        oJqtewz = ! JuTWgvvGh;
    }

    for (int ovpJilcEiLDxXdes = 989696209; ovpJilcEiLDxXdes > 0; ovpJilcEiLDxXdes--) {
        continue;
    }

    for (int HXpuOXgsvqRKuLY = 1362539694; HXpuOXgsvqRKuLY > 0; HXpuOXgsvqRKuLY--) {
        continue;
    }

    for (int hZXzENesEGQ = 331125244; hZXzENesEGQ > 0; hZXzENesEGQ--) {
        gGoNmjA *= gGoNmjA;
        ETbeSTEtgmDRiNex = ETbeSTEtgmDRiNex;
        oJqtewz = ! RRcRYpoLLs;
        JuTWgvvGh = RRcRYpoLLs;
        RRcRYpoLLs = JuTWgvvGh;
        uIrdKkOEel /= uIrdKkOEel;
    }

    return ETbeSTEtgmDRiNex;
}

double QjqoRHkNldaeAN::EURVifrpufAZc(double BciBUsYFJr)
{
    double chHsb = -133101.76240926154;
    bool uOhZTuUmmYbvoi = false;
    double JXzhXOrAEtZhF = -466121.2031908235;
    double eaSBpMSXqwot = 600645.1820540433;
    bool aiqnuoh = true;

    if (chHsb != -466121.2031908235) {
        for (int BxfahCyhccprilX = 5449741; BxfahCyhccprilX > 0; BxfahCyhccprilX--) {
            chHsb *= chHsb;
        }
    }

    for (int rlVjZTrTVlo = 929668098; rlVjZTrTVlo > 0; rlVjZTrTVlo--) {
        chHsb /= JXzhXOrAEtZhF;
    }

    for (int qSgqfhKEYuuRzd = 439728975; qSgqfhKEYuuRzd > 0; qSgqfhKEYuuRzd--) {
        chHsb /= JXzhXOrAEtZhF;
        JXzhXOrAEtZhF = BciBUsYFJr;
        uOhZTuUmmYbvoi = aiqnuoh;
        JXzhXOrAEtZhF /= BciBUsYFJr;
        eaSBpMSXqwot = BciBUsYFJr;
    }

    if (eaSBpMSXqwot > 600645.1820540433) {
        for (int ZcUhzstBpKrQLPY = 1864814977; ZcUhzstBpKrQLPY > 0; ZcUhzstBpKrQLPY--) {
            JXzhXOrAEtZhF /= BciBUsYFJr;
            eaSBpMSXqwot = eaSBpMSXqwot;
            eaSBpMSXqwot /= chHsb;
        }
    }

    return eaSBpMSXqwot;
}

bool QjqoRHkNldaeAN::Xkjwxf(bool pVFqTeYIZkbQ, double cbCPtNFUs, int STSMlY, int zQbanfxoHnvM, int xvKKIJ)
{
    string zcYnsYmuXxy = string("rhEjFPNexzYuvDqopEgZJqfTpssymTlWmhLVmYXsbYYGeXqDFiNKZiIMIexyxnhXGlugpbnslonfgubpwRoegmQUxRpLccZTHdgZNWBcevmcDXKFtKzgJNccTbiSoPKBeAPILloPphiSWeZLHYDbChCiRMPQwvOmcXUrMPtSv");
    int JtoGOETbqqt = 317197476;
    int UPjeWAC = -1132850435;
    double YKtjhnQEc = -471884.5361597088;

    for (int duQHXng = 1744761834; duQHXng > 0; duQHXng--) {
        JtoGOETbqqt += xvKKIJ;
        JtoGOETbqqt -= zQbanfxoHnvM;
        STSMlY -= zQbanfxoHnvM;
        STSMlY -= xvKKIJ;
        STSMlY /= xvKKIJ;
        JtoGOETbqqt = JtoGOETbqqt;
    }

    return pVFqTeYIZkbQ;
}

void QjqoRHkNldaeAN::bXpZhkqJCCIU(bool atgbyJuIiwfS)
{
    int KzUCyDPRRCHw = -2133680377;
    int WrZlyHaoHio = -1563682645;
}

void QjqoRHkNldaeAN::wwCySiOjick()
{
    int JJsZiagwgvtNkbD = -109625469;
    int mEhrSMEhAccrIDqx = -1376142728;
    string kVLqotmrladRIOf = string("jLUGUGMMSTPqTBLqWaSWyegHFgXaZdEJpqLdAOKXkahBUSyOrEvvrFWLpkfVLEWKejpsAaXGUUzdYLtjgUZYrEDiW");
    bool QhXnITVQF = false;
    double zpIqinxhvCn = -935143.4131545176;
    double cUAtPpNwM = -185601.42582336202;
    bool fFGQYdbeWk = false;

    for (int txMSjIROwDiks = 1504365722; txMSjIROwDiks > 0; txMSjIROwDiks--) {
        continue;
    }

    for (int SWhWDZWO = 1432277800; SWhWDZWO > 0; SWhWDZWO--) {
        QhXnITVQF = QhXnITVQF;
        zpIqinxhvCn = zpIqinxhvCn;
        cUAtPpNwM /= zpIqinxhvCn;
        JJsZiagwgvtNkbD -= JJsZiagwgvtNkbD;
        JJsZiagwgvtNkbD += mEhrSMEhAccrIDqx;
    }

    if (cUAtPpNwM != -935143.4131545176) {
        for (int LjlfpxQNUUIHIED = 1106835961; LjlfpxQNUUIHIED > 0; LjlfpxQNUUIHIED--) {
            QhXnITVQF = fFGQYdbeWk;
            QhXnITVQF = fFGQYdbeWk;
        }
    }

    for (int ggZilhBSd = 286446254; ggZilhBSd > 0; ggZilhBSd--) {
        continue;
    }
}

int QjqoRHkNldaeAN::RsekGjot(bool zwWHiVuI, string oLSlT, string syXeSUAa, bool vcPDA)
{
    int pRpbbxFy = -1403181809;
    double GgJWreUkfk = -530157.9551181121;
    string bbnJE = string("gbCIuBIDEuiOPXmhnNzvOzNYmjROblPDbb");
    double fpRAvzAdjeDyWo = 178314.42624391848;

    for (int rkoIfotdmbQSbuvU = 783686086; rkoIfotdmbQSbuvU > 0; rkoIfotdmbQSbuvU--) {
        GgJWreUkfk = fpRAvzAdjeDyWo;
        oLSlT += bbnJE;
        bbnJE = oLSlT;
    }

    for (int Feqdw = 1669545620; Feqdw > 0; Feqdw--) {
        zwWHiVuI = vcPDA;
    }

    if (syXeSUAa <= string("oYWyMhoMaChwNqVWfywmfxqmXZkitisSLRspgKFubvfSBFOldOoXBdPRmGfKMczEgvnMsdwIdSEZVmjsATyNQBjlNYgoAcXIKaJXlAtxtsrpSmGfejwOkIGAZXApKYNRelUXZAAiQGDdYjNe")) {
        for (int FUHOlHxwsEtFwdv = 569573600; FUHOlHxwsEtFwdv > 0; FUHOlHxwsEtFwdv--) {
            continue;
        }
    }

    if (zwWHiVuI == false) {
        for (int YwOivyeN = 533845203; YwOivyeN > 0; YwOivyeN--) {
            continue;
        }
    }

    for (int ODGlcLIukdLrFk = 976063653; ODGlcLIukdLrFk > 0; ODGlcLIukdLrFk--) {
        zwWHiVuI = ! vcPDA;
    }

    return pRpbbxFy;
}

double QjqoRHkNldaeAN::GvwjNHmJJtWk(bool ITmqBvrlKoAjuF, double dBbmfyW, int XeBaxScEd)
{
    string yiteksdImiDOsPbI = string("VvgdMTKiAIPXDNkGPgfmsXIOyfgCpoPIppAMNKRxtTfPTSRtNoCZdUCujGzMPsNsmPmZRMHoNbrBtDpsk");
    double TlctWywLeiMSEeK = -419657.0795880291;
    bool hvpQfhJZ = true;
    double vpRHcziOnaWMIS = 162352.2032830245;
    string NfmjkjOxdaKK = string("jPWSNXbXlmztHqJp");
    bool LyuEyrJPodfzI = false;
    string zpEVMDERJuseEf = string("QGCpXLguIGRxZHUraQHjTcrIrLmprdIlLftqLvAqqXBvyHjqYrxlwgRtsQRqncCKSgEQTvTmcinladkXHgKEwtuUPKTgnjUokTmWXsShywbOcuoIpoTEUIDXUeNQUVYAvGIfWzWehpsepbhNgpoheYdDBSBEcwGrlqGHBibabEtwOavgDFIUsywWEGbYSnSKvPbbtdHwTNLOMJhRpg");

    if (zpEVMDERJuseEf < string("QGCpXLguIGRxZHUraQHjTcrIrLmprdIlLftqLvAqqXBvyHjqYrxlwgRtsQRqncCKSgEQTvTmcinladkXHgKEwtuUPKTgnjUokTmWXsShywbOcuoIpoTEUIDXUeNQUVYAvGIfWzWehpsepbhNgpoheYdDBSBEcwGrlqGHBibabEtwOavgDFIUsywWEGbYSnSKvPbbtdHwTNLOMJhRpg")) {
        for (int ezBYl = 803644834; ezBYl > 0; ezBYl--) {
            hvpQfhJZ = ITmqBvrlKoAjuF;
            LyuEyrJPodfzI = ! ITmqBvrlKoAjuF;
        }
    }

    for (int bkzhSAQWSEHtU = 2011776879; bkzhSAQWSEHtU > 0; bkzhSAQWSEHtU--) {
        yiteksdImiDOsPbI = zpEVMDERJuseEf;
        vpRHcziOnaWMIS += dBbmfyW;
        XeBaxScEd /= XeBaxScEd;
    }

    for (int MLZKxTMtelZC = 2013475085; MLZKxTMtelZC > 0; MLZKxTMtelZC--) {
        continue;
    }

    return vpRHcziOnaWMIS;
}

QjqoRHkNldaeAN::QjqoRHkNldaeAN()
{
    this->MVZVKkwwErEPb(false, false);
    this->cxxHUowrjalzE();
    this->RNsRYeJNq(true, -886867.2904318068, -1590982377);
    this->EURVifrpufAZc(-813189.1569850878);
    this->Xkjwxf(false, 689861.2689659325, -777517756, -1258837907, -1403257557);
    this->bXpZhkqJCCIU(false);
    this->wwCySiOjick();
    this->RsekGjot(false, string("kTjyzIndBcObegvcEUklZSDXaRboKwXeqAZeDaSAICIllIVTGhFsEisBeKXbBzjfiwtpdVMPKRwwaodttdUxbDZRutnJGWLsKyhBvzNLJUWLHbHrYAVfngXwotJzvrkFeCwGAApGAzJtPWZSmGbetAvjfheOoWJrhjHTxU"), string("oYWyMhoMaChwNqVWfywmfxqmXZkitisSLRspgKFubvfSBFOldOoXBdPRmGfKMczEgvnMsdwIdSEZVmjsATyNQBjlNYgoAcXIKaJXlAtxtsrpSmGfejwOkIGAZXApKYNRelUXZAAiQGDdYjNe"), true);
    this->GvwjNHmJJtWk(true, -479166.37056739675, 1459573019);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class grsqfcRJzyTc
{
public:
    string gQPouNAVs;
    double uiwZlcx;
    string EnTFcXQkpKCEHBEx;

    grsqfcRJzyTc();
protected:
    string Rvnzqnam;
    double xfemWlK;

private:
    bool DOoOTSpKYwNrn;

    bool uOzEV(double PhaPS, double punwJWjVqiRDgzV, double fvMpreW);
    string BPUfYpDXrRtKFWvH(double VoFDa, string IgyyRPQaMjhoD, bool IPgNIOyU, int oXQxDArhjgm, bool IYdjZKUvoVkzuQ);
};

bool grsqfcRJzyTc::uOzEV(double PhaPS, double punwJWjVqiRDgzV, double fvMpreW)
{
    double QEUlqcHzNnVQAao = -237338.38931522495;
    string IRtnhhCOtdmKwPAW = string("wQvFaYkytOaZGWLhqfCQNYmCtuCOWPDGLwTggfzShRNaiWtTZuzGCllBOVfSJNAEVjMxFRDJlhTFDuNwTMhjDRwrfymvViqyQBhyTxFdYqklWTdOqRzAYTiVqSyvypjYqEJxyXhLxANYEfvSOZMAWCLVWDXvoOnPKcwEXMPpVI");
    bool qHSwMqSyicWqiGG = true;
    int WYZjoq = 347320598;
    bool JgpsZZqJl = true;
    int eYawtJpIMaJ = -745620480;

    for (int iWkzGZQgQWik = 779004046; iWkzGZQgQWik > 0; iWkzGZQgQWik--) {
        PhaPS *= punwJWjVqiRDgzV;
        punwJWjVqiRDgzV -= fvMpreW;
        eYawtJpIMaJ *= eYawtJpIMaJ;
        IRtnhhCOtdmKwPAW += IRtnhhCOtdmKwPAW;
        eYawtJpIMaJ += WYZjoq;
        eYawtJpIMaJ *= eYawtJpIMaJ;
    }

    if (PhaPS > -237338.38931522495) {
        for (int sBiPAtpDwkTBAPu = 1824479059; sBiPAtpDwkTBAPu > 0; sBiPAtpDwkTBAPu--) {
            fvMpreW = fvMpreW;
            QEUlqcHzNnVQAao += PhaPS;
            PhaPS = punwJWjVqiRDgzV;
            QEUlqcHzNnVQAao *= punwJWjVqiRDgzV;
        }
    }

    return JgpsZZqJl;
}

string grsqfcRJzyTc::BPUfYpDXrRtKFWvH(double VoFDa, string IgyyRPQaMjhoD, bool IPgNIOyU, int oXQxDArhjgm, bool IYdjZKUvoVkzuQ)
{
    double noGXjkjttk = -34040.804361768016;
    string yCIwhdVg = string("WKHXpAphHyBXDPVKNWcOVWiWEwJiwDAehjCvQmatznAHaMZcxGrfiDLQXpJchsYJHwPZqHOiNQuzPoUMpcSprKDbNkuRZMiBxRfctspwCtOsCiKZcZbIRABJFpqoNBlLKcdZcMbhDn");
    string VaxpRYjxJcwhzyEG = string("uMwWSlaXRcDjuoZXvrSdLYqdWOVqqqBKkUYncYUfhIiWjWqrQMKwIvbZpfVRtcuIVJGsrDtbyjyBVCVADXIFpHwzrmIGiLBqaqBnuRywNzHKHsicVPnNUQxPVREyEZIPiBasItGavStLceWSJezqzVOCuXIxNiFzkoNLLWoIWQCCvskzkKydPDYhnkWwNqOfmSTRPoZqryAKrnzcERfsoJKjJ");
    string DFRZYmkSB = string("eySfnSZtcuBoyMeCHJwkWQNVlxKDHHuCUEsMUfWcFyTgTxScOBCymPcvDuwNjrnktapdeRwBeEBmvrCPtlizdppLKoBJwZfGglojz");
    double LLPhkBAnOXFAjLnN = 592075.5065991449;

    for (int HXpExoSGI = 1870730258; HXpExoSGI > 0; HXpExoSGI--) {
        VoFDa /= noGXjkjttk;
        yCIwhdVg = DFRZYmkSB;
        yCIwhdVg = DFRZYmkSB;
        VoFDa += noGXjkjttk;
        LLPhkBAnOXFAjLnN *= LLPhkBAnOXFAjLnN;
        IYdjZKUvoVkzuQ = IPgNIOyU;
    }

    if (yCIwhdVg == string("WKHXpAphHyBXDPVKNWcOVWiWEwJiwDAehjCvQmatznAHaMZcxGrfiDLQXpJchsYJHwPZqHOiNQuzPoUMpcSprKDbNkuRZMiBxRfctspwCtOsCiKZcZbIRABJFpqoNBlLKcdZcMbhDn")) {
        for (int CbfIMBYISnt = 371702841; CbfIMBYISnt > 0; CbfIMBYISnt--) {
            noGXjkjttk += noGXjkjttk;
            VoFDa = VoFDa;
        }
    }

    for (int LMRwMbEzrKoKJT = 561240226; LMRwMbEzrKoKJT > 0; LMRwMbEzrKoKJT--) {
        VaxpRYjxJcwhzyEG += DFRZYmkSB;
        LLPhkBAnOXFAjLnN /= noGXjkjttk;
    }

    if (IgyyRPQaMjhoD >= string("mMVKlDnGTmrDIkoCOOFkaadZKzJPLwglmdLmbOaLqWtFXXLEACIvdNAROMAdqCUjTgTZoUpEQXStcaaqyWRCxlZSGu")) {
        for (int JVWJKyXBdaGSBFbm = 1595288790; JVWJKyXBdaGSBFbm > 0; JVWJKyXBdaGSBFbm--) {
            noGXjkjttk += noGXjkjttk;
        }
    }

    for (int KoMvxDQBUJNh = 1519671978; KoMvxDQBUJNh > 0; KoMvxDQBUJNh--) {
        continue;
    }

    return DFRZYmkSB;
}

grsqfcRJzyTc::grsqfcRJzyTc()
{
    this->uOzEV(1047003.3549531293, 998736.8927379153, 970391.5355537932);
    this->BPUfYpDXrRtKFWvH(-730178.7188343802, string("mMVKlDnGTmrDIkoCOOFkaadZKzJPLwglmdLmbOaLqWtFXXLEACIvdNAROMAdqCUjTgTZoUpEQXStcaaqyWRCxlZSGu"), false, -1031831932, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fiApNmIqa
{
public:
    int lgmfuKOMm;
    string djQADwPTGna;
    int XBmCUvhelukSY;

    fiApNmIqa();
    int rlkdmhCCNhGueGJ(int CoebjvypMqW, int QqeabAV, double XRSBbukbM, int AsFWeU, int ROBZlGKVrWQXGURn);
    bool iLhYlQZDYRQlX(bool psBvvYNwiTUBaRC, bool ifuEUUdPvTvM, bool wZnXE, double WZsdA);
    int CVHDnWNdCABZmm(double lCmLQ, double UgajOLKMj, double OkPRhMcd, string QJCkiYPPmZewQw);
    int BlmhyOZaof(bool xMdAUEnimvyO, int sxzQxnj, double hGeIxrpKbVoklO, string NhlxssndboSVWaz);
    string ZJYMRBDEBmM(int JndyW, bool ppBfDEoBnrALOQR, double WXAkmikrMBIm);
    double qeCBn(int KZEzMtiZpvUmFJIF, double vrgHLOQMTHF, string ulWEUqlldrwa, int pWIPEq, string hzbVrnJSTQ);
protected:
    double fFNcCUTtSxASEerG;
    int pqdfoy;
    int psAnWskncz;
    double pRknBnhvCqU;
    bool PGCBPqPPpffE;
    double bdDukVd;

    void xsDGfLgtsaTD(double kENfN, int oQNpfDTtIhIUwsJl, double ZwziYmN, double TihujWveNO, string EdwlfTTHDnbYEGvC);
    void QXkrmYhJQlPQxq(string fVNbeLBn, string afHWIPAnfcAeQ, int vPXko);
    int XBJLS(string czjVVFHKbnFkX);
    bool ZLekCp(string PksjEo, string RJSCXJcO, string CcpOqUYjzCVvEIt, double usBrnLfI, double MCjlGlI);
    string PirrAZVENXaNMIPR();
private:
    string VTqOaIlZMMi;
    bool SGZcb;

    double XvYCtOsyLeL(int fKCOWwEqZXPOgtX, string CiDAxjujXkOnmS, int btSSzbkiQVtJwPzt, bool RxvsA);
    void fMfPCvs(bool yfgzdRKEZYgeAJfk, string paUDhwqGVuJYLmuY, string NEwYVOlMlGAOjNW, double HDplSEUxy, bool wCBnSaEr);
};

int fiApNmIqa::rlkdmhCCNhGueGJ(int CoebjvypMqW, int QqeabAV, double XRSBbukbM, int AsFWeU, int ROBZlGKVrWQXGURn)
{
    bool zQNpTRG = true;
    string OJWcoPkMKhMd = string("TWUGYNjrAELpRNDAuRmgwZbKlHFhaszuUqFwbDtxNbUexSnYz");
    double TgIdhkSU = -756020.7929228833;
    int aSQtHzNhFxon = 1533513947;

    if (aSQtHzNhFxon < -1046046685) {
        for (int glsmgjPkpV = 36080095; glsmgjPkpV > 0; glsmgjPkpV--) {
            continue;
        }
    }

    for (int pwmlfHMkTAb = 2077748492; pwmlfHMkTAb > 0; pwmlfHMkTAb--) {
        QqeabAV += QqeabAV;
    }

    for (int DcSaRsPpbblmyj = 1717222416; DcSaRsPpbblmyj > 0; DcSaRsPpbblmyj--) {
        CoebjvypMqW += aSQtHzNhFxon;
        AsFWeU = AsFWeU;
        aSQtHzNhFxon += AsFWeU;
    }

    if (QqeabAV != 990928380) {
        for (int kTkqzmKdxQ = 26540969; kTkqzmKdxQ > 0; kTkqzmKdxQ--) {
            CoebjvypMqW = ROBZlGKVrWQXGURn;
        }
    }

    return aSQtHzNhFxon;
}

bool fiApNmIqa::iLhYlQZDYRQlX(bool psBvvYNwiTUBaRC, bool ifuEUUdPvTvM, bool wZnXE, double WZsdA)
{
    double NpaMpsipGkGL = -411670.9873979197;
    string ovlbMqMmKDLDIBZy = string("eqaDvMwZcNctfhDLNzfcyJgwgawFDhUsnQbKsDmFYXvYmAfuGgQHXmEmSkQYVWowHw");
    double DJOEZoieaCoG = -373346.45415234455;
    bool ftMfzrwiT = true;
    string JbYqwRaZ = string("zPOHQlnwSXOJkYwVQPvpkvuzPHVarfhcaNxDrwryYzDsGuTaLpWRTNKvnCCmmAFNVfWKJaCQIuTmBzVJhMgAYAyHhFntVoOQpcQpJVuemZmLUmVfUdcvvaBqkhKQPEXEgAoGvmQjFZWyEmOOARzybwriHkMBg");
    string hhPFybcQC = string("rUgoZHNxQlZMnNjBzodLMtBLEZrlefjzNWhcsyAKGhjijwYiJtBLkBqxWOWbpdSNQYoEcFVJKiwhXcoUkJuFFbXkfOjTxXwBEOesvCcxrdYQsfFCDVjwImfQGXwMnlFSMOGQGafkWmrxVrEIITmkInMwhaNrMwZvcQogvtkZwOcHArxvFSWZBkDmtvtOdXHzOVJbWILRLK");

    if (wZnXE == true) {
        for (int BOxKFbU = 1591258827; BOxKFbU > 0; BOxKFbU--) {
            ftMfzrwiT = wZnXE;
            JbYqwRaZ += hhPFybcQC;
            DJOEZoieaCoG += DJOEZoieaCoG;
        }
    }

    for (int SoMKAmRp = 1860818168; SoMKAmRp > 0; SoMKAmRp--) {
        continue;
    }

    return ftMfzrwiT;
}

int fiApNmIqa::CVHDnWNdCABZmm(double lCmLQ, double UgajOLKMj, double OkPRhMcd, string QJCkiYPPmZewQw)
{
    int GPIyhDXPE = 2109355308;
    string xgjSaLRpCgPQM = string("KsWTVEXjzctwfEoakrCtNUQAthjhNkRIvimYLPNrQUufPFOmxoNFzpgTTnhdcHMcBbUdlGIrnEMupNFGvknXHUsijBnpkChJVqESRgzwkRyouEqwTNxgFeCWcgCYGEg");
    string ScLOZzuZZJVqbj = string("ePzguxwgjVoObmnMurbMqNWfMCnbSdQMFfHuNTAEYsrXXnfAQEGIgbeJaLcamygudGNxXorLGbsPNQjBuGELyTTBnnMpCFzncfnXebJLffKFovuWzWgYJhYvyBAmkuYOElBAjCwtjVcxVNnBZqMSfkYxWOplADwGOyzjDrTlSCDeAACDBNhBcWApnAHdDioZeYcvMWWyfJHMIVosAfQXHqIgUVZJ");
    double AtgHbenIlnVW = 206414.8823293505;
    double XvxKAgg = 394133.94280186866;
    int TCKWspTy = -1513741221;
    double TkQFEjByj = 643735.0597904312;
    double VDazVJEqtxUale = 869346.1646380465;

    for (int xFtmWGw = 1334751016; xFtmWGw > 0; xFtmWGw--) {
        VDazVJEqtxUale = VDazVJEqtxUale;
        TCKWspTy += GPIyhDXPE;
        TkQFEjByj /= OkPRhMcd;
    }

    for (int XCTOHBEfZi = 1656669229; XCTOHBEfZi > 0; XCTOHBEfZi--) {
        UgajOLKMj -= UgajOLKMj;
        GPIyhDXPE = GPIyhDXPE;
        VDazVJEqtxUale -= XvxKAgg;
        lCmLQ *= lCmLQ;
        XvxKAgg = OkPRhMcd;
        lCmLQ = UgajOLKMj;
    }

    for (int HpWVcVy = 410304970; HpWVcVy > 0; HpWVcVy--) {
        ScLOZzuZZJVqbj += xgjSaLRpCgPQM;
    }

    if (VDazVJEqtxUale != 394133.94280186866) {
        for (int gkobfAP = 132165258; gkobfAP > 0; gkobfAP--) {
            continue;
        }
    }

    if (XvxKAgg >= -297979.51085752965) {
        for (int NEkXEZQl = 565367780; NEkXEZQl > 0; NEkXEZQl--) {
            UgajOLKMj += lCmLQ;
            UgajOLKMj *= TkQFEjByj;
        }
    }

    return TCKWspTy;
}

int fiApNmIqa::BlmhyOZaof(bool xMdAUEnimvyO, int sxzQxnj, double hGeIxrpKbVoklO, string NhlxssndboSVWaz)
{
    double odRKOcwWgmeNEKN = 129315.61065897004;
    bool VCwnQlYCx = false;
    bool uQEJxKioJwdVVt = true;
    int XtWKyiWWaFtFpn = -829895855;
    bool Jxirwo = false;
    int IIWwqQhm = -438645400;
    double TyutpPIaqHrOO = -856353.3416298681;
    string urgpIVjlPVK = string("cYdWqyVMXIpfpbkCEDsMhtOilFqQihKxcnOkri");
    int MZoRyVO = 1504056288;
    string RbrpEuYbW = string("TtZrIaRZAoEpvFEhsrSVdNRUDDsfvSxgOAvOKCTEYTwbzYqqkWEFDqzcNorCiAAsUfFGLgCQMBpiOciMAmzLKZQIcZuNpgrETfacZoDGiAElmNaklVkcvLiJCJtjEUUWBjHq");

    for (int fvEzfarKlsH = 750867933; fvEzfarKlsH > 0; fvEzfarKlsH--) {
        XtWKyiWWaFtFpn /= XtWKyiWWaFtFpn;
    }

    for (int uAkVhYvVD = 207627965; uAkVhYvVD > 0; uAkVhYvVD--) {
        hGeIxrpKbVoklO += TyutpPIaqHrOO;
        MZoRyVO /= IIWwqQhm;
        VCwnQlYCx = ! xMdAUEnimvyO;
    }

    return MZoRyVO;
}

string fiApNmIqa::ZJYMRBDEBmM(int JndyW, bool ppBfDEoBnrALOQR, double WXAkmikrMBIm)
{
    bool nxWnKgyBiBkVt = false;
    string beBxAvoVra = string("VfHluiVIwspuKXpytezucrLLZMsHxvJjyJDjDkDtlAVUXbOEfnRBiOyNFufbaUericKKaNjsHFxmEXogrgIJvuDigHKlODQQxrBLXKUbMTnmBXEJPBNZzJrwJpybrbvYJaROszNgrtspxAwvqjDKyVOmcxbcIUgmsEuHJOniEOOEGrjhltKfpgIxYQMLrYhym");
    string ctFXYy = string("SHcLSISrhtqXfIFNbCPHNkpSxHqnxLQOZmgadyKGEhabBFhpaVbFECSzxbAyiTGTtoltqzWlTOEKBVxpFUPrjvzgFPAyjqyodsFltkkeLJdUTiYGrXagqVMGGRsYcQloIbokZLiFHuKdBixzhPLjVTHxDpHAROaQdkgbFDRsRfiiLZUOeXnAZgpKfsLuXZmrIJmzjxGNUrpsiVHQaMsriXGrtLhAejOJwQfYMCQkoulSBerRYdHxfJk");
    bool SVlKGWdHh = true;
    double RWGIfNvkFkJFxo = 220337.7964204745;
    double fruUmLpEaQLtraS = -35041.28932370583;
    bool NXPQfjndz = true;
    double pkopWOJlHTyciv = -806341.2609262359;

    if (RWGIfNvkFkJFxo < -243855.39100600887) {
        for (int gYfRHhfRNGvgD = 635912940; gYfRHhfRNGvgD > 0; gYfRHhfRNGvgD--) {
            SVlKGWdHh = ppBfDEoBnrALOQR;
            fruUmLpEaQLtraS += WXAkmikrMBIm;
        }
    }

    for (int CrolTqEVztaYZ = 1804373679; CrolTqEVztaYZ > 0; CrolTqEVztaYZ--) {
        pkopWOJlHTyciv = fruUmLpEaQLtraS;
        NXPQfjndz = ! ppBfDEoBnrALOQR;
        beBxAvoVra = beBxAvoVra;
    }

    for (int TWwaFlzjOJnvmTM = 1194116143; TWwaFlzjOJnvmTM > 0; TWwaFlzjOJnvmTM--) {
        nxWnKgyBiBkVt = ppBfDEoBnrALOQR;
        JndyW -= JndyW;
    }

    for (int HgZzXD = 2077969767; HgZzXD > 0; HgZzXD--) {
        beBxAvoVra += beBxAvoVra;
    }

    return ctFXYy;
}

double fiApNmIqa::qeCBn(int KZEzMtiZpvUmFJIF, double vrgHLOQMTHF, string ulWEUqlldrwa, int pWIPEq, string hzbVrnJSTQ)
{
    int xtcbYXWmSQmkhJ = 1841456796;
    bool TIxGLaXF = false;
    string szUlMvEkV = string("KiPVjLHvIZipDsxBmTNmHmVsPbYwcYxAYpJKFWygvBy");
    int dXGIde = -1456632936;
    double gUimJJRqY = 883871.4580437286;

    if (xtcbYXWmSQmkhJ == 1841456796) {
        for (int pVOUJexXFLJvs = 437778929; pVOUJexXFLJvs > 0; pVOUJexXFLJvs--) {
            continue;
        }
    }

    return gUimJJRqY;
}

void fiApNmIqa::xsDGfLgtsaTD(double kENfN, int oQNpfDTtIhIUwsJl, double ZwziYmN, double TihujWveNO, string EdwlfTTHDnbYEGvC)
{
    int JEocNMUyffo = 2051416674;
    double rNCiZEySvGx = -927899.4758336499;
    double tMGUfV = 632037.1573498646;
    string xzyAzmeANclanW = string("MtBHOoKSvXqmmYhrywXAKFkwjloSyUwaH");
    double LezDqlVTuXpwWb = 776998.3700496237;
    double iONIFa = 492470.8164730023;
    string fDDoIyjUOmrv = string("nOsMyjZpoMsRCOnoZFIABHDJDNjBtUYjlsFcuMRGZutfVcJPYfzPSYZcXdzQnpkSwAMqtoHHTLZgj");
}

void fiApNmIqa::QXkrmYhJQlPQxq(string fVNbeLBn, string afHWIPAnfcAeQ, int vPXko)
{
    int mAqNuF = -922815955;
    string JDGoxO = string("FkfTkTCJRyXLmzieetZHKcyjjODYfQfxwUCBLujDpeYEsIzPdUchAuTHgoBwShdQbCBBAkfNSHCWVzUwNgqVzoInDstAfKAhUfRWGcZqrhCqOJJhOCIxwzAarkNdLaqGFoJkoRHdiehAznjcefPsrjBfkOFAnZDSXImFbTvXSuNWVBGPYPWcUFBOKRESvDJzG");
    int itcEyZCUBk = -1175631588;
    double NqLeavn = -432441.3939046499;
    string NqwyoLQlMPDbvjfp = string("otpkeNePLdOgQlcKcROWeMeamiUrwowufnqwXBCRHwGAFsMzwQfQQGxxwmepORVKAQFlziHkMHFifkgQaxsXbgSendIUSOLuUNFqCrejcjgYszrgoOJrFCtlqZ");
    int syVfBPXOJUJbGcFo = 1088674408;
    int QMBzFzAu = 440646081;
    bool hzPsrDEdXuwkOPEM = false;
    int VaKHaEyQuIpVYj = 1349527699;
    bool meYSQKT = true;

    if (QMBzFzAu != -922815955) {
        for (int bLiBZ = 216774915; bLiBZ > 0; bLiBZ--) {
            QMBzFzAu *= QMBzFzAu;
            syVfBPXOJUJbGcFo = mAqNuF;
            mAqNuF += mAqNuF;
            syVfBPXOJUJbGcFo *= syVfBPXOJUJbGcFo;
        }
    }
}

int fiApNmIqa::XBJLS(string czjVVFHKbnFkX)
{
    string MYHxOJXYLlnL = string("dn");
    bool EPTXlAxPesTZFXy = true;
    double FhPyeRdWkNCh = -461648.04685618076;
    double QbjESkaQC = 635119.8707317641;
    double HkVvm = -1029517.3251692588;
    string iUIMp = string("WcULxenaigNuRsnnzfCHzQbjGnobGQPdltrdzFVNGsbYHMNxvYGJvjjTQfTtJsaciXjlwTvIgSzphTXRZXWsQYGYDOhEJflJLdQbPMJnRaiREXfAxctddXTVNlAGuasaYkxeduscJBhAyzqxCUqljsn");
    string CzXdHlzSY = string("ZPavWzTWtBqLwkKEwFpSrTDWqzYUJSPsTyXgBRYIIZyYAHhdhDBReSlznbLeUxLTDMGDeIPwHcpMJaNIrRhnEfvwlCclelJWadAClrIHusUvnpAsBbuWeABbHnNsqeXCEpOHXEmYXojmoKWOOgEIortLfsBUQNwotmwOwWwyYLilFgFYXxXirOjifPOduggmwAfqfTrtAyRzJjRGFrabySHGkXXvFTTUzfgdRNn");
    double rRpskIZaIjsn = -607492.9742745355;
    bool ihitC = true;
    bool fyCWGgB = false;

    for (int yYdeKadcYzodYPgp = 1669229508; yYdeKadcYzodYPgp > 0; yYdeKadcYzodYPgp--) {
        FhPyeRdWkNCh += QbjESkaQC;
        HkVvm *= QbjESkaQC;
    }

    for (int eUAqHrcPkRM = 1032395659; eUAqHrcPkRM > 0; eUAqHrcPkRM--) {
        iUIMp += iUIMp;
        HkVvm += FhPyeRdWkNCh;
        QbjESkaQC += FhPyeRdWkNCh;
    }

    for (int RjPbd = 1392866097; RjPbd > 0; RjPbd--) {
        czjVVFHKbnFkX += iUIMp;
        fyCWGgB = EPTXlAxPesTZFXy;
    }

    if (FhPyeRdWkNCh < -607492.9742745355) {
        for (int DNfMOmnQiAxXH = 279276474; DNfMOmnQiAxXH > 0; DNfMOmnQiAxXH--) {
            continue;
        }
    }

    if (FhPyeRdWkNCh == -1029517.3251692588) {
        for (int PnfgqriCujwjLOi = 614280114; PnfgqriCujwjLOi > 0; PnfgqriCujwjLOi--) {
            rRpskIZaIjsn /= FhPyeRdWkNCh;
            CzXdHlzSY += CzXdHlzSY;
            HkVvm /= QbjESkaQC;
            FhPyeRdWkNCh = QbjESkaQC;
        }
    }

    return 823845132;
}

bool fiApNmIqa::ZLekCp(string PksjEo, string RJSCXJcO, string CcpOqUYjzCVvEIt, double usBrnLfI, double MCjlGlI)
{
    bool iMTwQikl = true;
    bool MzEOsheaBM = true;
    bool BOoTmhIVpTP = true;
    double JQGUSaraEQLrv = -899924.5805586858;
    string eCvsix = string("mpaAjosKNdTcSSBQJGpjqdaglObjpqwNyZApiHIDWLxDLVpBfitmpvQuKLpWMluSKiwGALxfSXLjiLhLURWYhtAguoLXonstkYupoJxaAAWBlWHvupIlywhXDYiJYqsnVlPetemgsiWqBbfljPgojvKQJIkHVsRPFkZKpApRvojqk");
    bool qmlTPocZtRIAS = false;
    string MeCSCpb = string("DJmRduhJnpUcgHivtvmrItyxfPZLsDfuwhEiplaeSTtzBQqEzOhxVoimlzMYMsQCmGjbojwUJrGLCBajdBuG");
    double omJNPNHiYq = -378073.83918058977;
    bool HUdiIc = true;
    bool ddLrtDUj = false;

    return ddLrtDUj;
}

string fiApNmIqa::PirrAZVENXaNMIPR()
{
    int bFnunoiMscMts = -755337285;
    int ZIGPQIzMLTFMZrzI = 1218585281;
    double aweiyudMO = 301494.5671453355;
    string YWfwbhKYJRTUbqX = string("zMJvYunmKVuCAVPpscqMhvFnqESKlRtHkcVelBTMTHnqtPKFLANUOxvWRXUcslhXWLBJyCfUuFqFXJLJTsHJEVfRDoFAJjcBWQasvbwgooxXSRqNXtikxnZsrqckYdpUCLZHGqNZkQrIHNmdokyfSqjzSMtBiEhZAKNbfkGYMoPnlclzqkkfCazLuTqZFJSbfOHeuCypH");
    double psjxx = -67982.67122405265;
    bool GsUVxmDciYP = false;
    int rWgPWSISmfQDtYvC = -853279533;
    int mUXYPGoOxE = -1404762551;
    int PiIGPjLtYWRcD = -1322048745;
    double DGfexVgAWwkHlfm = -1017057.7072643612;

    for (int kFsdAZ = 604619175; kFsdAZ > 0; kFsdAZ--) {
        bFnunoiMscMts = bFnunoiMscMts;
        mUXYPGoOxE += bFnunoiMscMts;
        DGfexVgAWwkHlfm -= aweiyudMO;
        YWfwbhKYJRTUbqX += YWfwbhKYJRTUbqX;
    }

    for (int WXYDGTkBy = 1478619146; WXYDGTkBy > 0; WXYDGTkBy--) {
        rWgPWSISmfQDtYvC *= rWgPWSISmfQDtYvC;
        mUXYPGoOxE += ZIGPQIzMLTFMZrzI;
        bFnunoiMscMts += PiIGPjLtYWRcD;
        PiIGPjLtYWRcD /= rWgPWSISmfQDtYvC;
    }

    if (rWgPWSISmfQDtYvC == -1404762551) {
        for (int YIumTkDeOMn = 1561772036; YIumTkDeOMn > 0; YIumTkDeOMn--) {
            mUXYPGoOxE -= mUXYPGoOxE;
            ZIGPQIzMLTFMZrzI = ZIGPQIzMLTFMZrzI;
            mUXYPGoOxE = bFnunoiMscMts;
            mUXYPGoOxE *= rWgPWSISmfQDtYvC;
            mUXYPGoOxE *= rWgPWSISmfQDtYvC;
        }
    }

    if (mUXYPGoOxE != -1404762551) {
        for (int LYtAHdFKZVDkRUK = 1942192331; LYtAHdFKZVDkRUK > 0; LYtAHdFKZVDkRUK--) {
            PiIGPjLtYWRcD -= mUXYPGoOxE;
            rWgPWSISmfQDtYvC -= bFnunoiMscMts;
            PiIGPjLtYWRcD /= PiIGPjLtYWRcD;
            bFnunoiMscMts -= mUXYPGoOxE;
            mUXYPGoOxE *= rWgPWSISmfQDtYvC;
            aweiyudMO += DGfexVgAWwkHlfm;
        }
    }

    if (ZIGPQIzMLTFMZrzI <= -853279533) {
        for (int rUSnIcoBHuIpq = 261442171; rUSnIcoBHuIpq > 0; rUSnIcoBHuIpq--) {
            GsUVxmDciYP = ! GsUVxmDciYP;
            PiIGPjLtYWRcD *= rWgPWSISmfQDtYvC;
        }
    }

    return YWfwbhKYJRTUbqX;
}

double fiApNmIqa::XvYCtOsyLeL(int fKCOWwEqZXPOgtX, string CiDAxjujXkOnmS, int btSSzbkiQVtJwPzt, bool RxvsA)
{
    string ERfRnwfIgP = string("xOMwCBWlLFKPCuEkQQkevDQUBRMhhCeudWelaHOLdjaitNNFYApPqACKMIABruwbEejMUfCbsOZhXLbnpCDKndeChBovxzDgmVjydKiyedalmKSkDcRBRwbJIAxIubGcblvhQUHtAKWQqHswewdgpdrjUrQAcVlqpbdXSkEEedIicfAVYqLlBtWETBGhRSXnOQqnQjwe");
    bool TRmxzvvkF = true;
    bool RuiNmRIisScppf = true;
    bool QDOStC = false;

    for (int lxQVkvhlncv = 465678129; lxQVkvhlncv > 0; lxQVkvhlncv--) {
        btSSzbkiQVtJwPzt += btSSzbkiQVtJwPzt;
        RuiNmRIisScppf = RuiNmRIisScppf;
        RxvsA = RuiNmRIisScppf;
    }

    if (CiDAxjujXkOnmS == string("BvclvanGrlFsyEqYhAwEWPhxetcqInXXqIoBfrWbXzSaXYVZcmHxrkOQjmQxcQYFLrluvNuHTvCvRnajFyhvedOIqjZiPEWstdqnYHrWTEpDtgEbKYebsOSsGPpe")) {
        for (int UuSAWd = 646689279; UuSAWd > 0; UuSAWd--) {
            TRmxzvvkF = ! RxvsA;
        }
    }

    for (int gmXFKaMmRhbevc = 1134747250; gmXFKaMmRhbevc > 0; gmXFKaMmRhbevc--) {
        fKCOWwEqZXPOgtX += fKCOWwEqZXPOgtX;
    }

    return 380616.9925549093;
}

void fiApNmIqa::fMfPCvs(bool yfgzdRKEZYgeAJfk, string paUDhwqGVuJYLmuY, string NEwYVOlMlGAOjNW, double HDplSEUxy, bool wCBnSaEr)
{
    double zjwfqbQfMfcwEy = -439401.0904439037;
    double RDKDFHpdRXvsdh = 130936.09518378203;
    double lBCrjl = 116132.34573420555;

    if (paUDhwqGVuJYLmuY <= string("YoWUpxFQBztiTHWiVQcFtHyjimgMuVZgEmFVHzKOXtwRkIUXqsGVJqVY")) {
        for (int xlVbxFgxojb = 1220844674; xlVbxFgxojb > 0; xlVbxFgxojb--) {
            HDplSEUxy /= zjwfqbQfMfcwEy;
            lBCrjl *= HDplSEUxy;
            RDKDFHpdRXvsdh *= RDKDFHpdRXvsdh;
        }
    }

    for (int TDMFBcjjOAqit = 611503597; TDMFBcjjOAqit > 0; TDMFBcjjOAqit--) {
        RDKDFHpdRXvsdh = zjwfqbQfMfcwEy;
        NEwYVOlMlGAOjNW += paUDhwqGVuJYLmuY;
    }

    if (RDKDFHpdRXvsdh <= 116132.34573420555) {
        for (int nlFHDHGHzZ = 1369227380; nlFHDHGHzZ > 0; nlFHDHGHzZ--) {
            continue;
        }
    }

    for (int CwGGVGYFgpN = 1111917616; CwGGVGYFgpN > 0; CwGGVGYFgpN--) {
        continue;
    }

    if (lBCrjl > 130936.09518378203) {
        for (int HUQSmCPKHfEn = 1349586380; HUQSmCPKHfEn > 0; HUQSmCPKHfEn--) {
            RDKDFHpdRXvsdh *= RDKDFHpdRXvsdh;
            HDplSEUxy += zjwfqbQfMfcwEy;
            zjwfqbQfMfcwEy = RDKDFHpdRXvsdh;
        }
    }

    if (zjwfqbQfMfcwEy < -439401.0904439037) {
        for (int PyrAMpJH = 572200269; PyrAMpJH > 0; PyrAMpJH--) {
            continue;
        }
    }
}

fiApNmIqa::fiApNmIqa()
{
    this->rlkdmhCCNhGueGJ(-1046046685, -1962361155, -444868.90622933966, 1929258677, 990928380);
    this->iLhYlQZDYRQlX(true, true, false, -285402.71296152077);
    this->CVHDnWNdCABZmm(-304788.95807936415, -297979.51085752965, 680626.9164904606, string("tBUlMzuunfbFIApzaethXdBrCOCyNzsRNoNIlcsgEfrjXMfNsHMAbieWzVtDqBNonTVEaMylRxkNNQZgSlFXLTqGsYnpzLzlFCLxQMdxqvJgaRlAvqzTUEVuqMiqqyuVuOEbwjqfRFKdaOObLkgdGbIcfXzcmAESmlTJ"));
    this->BlmhyOZaof(false, -182501956, 197226.10328471012, string("jqFWYXBqIVusPWHEhsrxZslWNQSmqowwAcGjBDNqVHckjnrdzdGeQzDcpbVdIWkfflYmNgDfblBaGBdIonOPLIaHRbdjpkYJEJZSBtodYMHmN"));
    this->ZJYMRBDEBmM(1259543105, false, -243855.39100600887);
    this->qeCBn(-121272449, -77919.17626520037, string("uucITzAZOhrgnmNmtnAOKgTZbAWTWMBqUbjTUdESmXiiSxjEwasqTUxLkxrUiujWWoLPZchzXtmTvqWvxBTajXjyJshuYPuopAKhSIvoaQPicZcspQsfvGtXtkgxAITHgCrFVASaUWOljAzKXMLXulcmfCQlAtslHbRNDTXUIqgBaDMpeEvqXKnBSplcsJEdPzZAESmzyJneESHZZQFmiFSBRKfclmdKvczGFjfeiWrzSrcitZvp"), -1105401312, string("deibdIRsAsqXe"));
    this->xsDGfLgtsaTD(219301.88116839144, -2101581188, -23097.42510276971, -782589.6188454519, string("bdyPcSqKorkcMCHcEcuFODHESjuSiTUguivSjCOAicxHdGzhORaQvGXOxRCdEXjrJjLyiNXGBaMDvFwmpJjVHPs"));
    this->QXkrmYhJQlPQxq(string("XFIDZvyAulwEngYTBuuXbEwUEbhMsuMoLFprXbImjEvPkTUfdMyehYndqTeOZiBLshiNCMONVOXTlrQuKBFZMXIDjaUmqdQEZlJtfziGCqvMyiIpwppYOpRdcfqTyoCRYNpnQtDLkngVKuOYjnTKuDTKCalmXGEEbGvpmPlUjceecGtSgOfxyCJfTtTHPnRksNqAKKfUWGFMnapRChlXjUNiCWLFmrHljW"), string("eBSiFpFrjVwvPGCGTjBVxiyNGigeyXEjlqXOCYgdMGKFRQMGTWcxhUuGFQnvapnfFjQyZjrtLGdNKIcyLFhPhEyrVWDeDbQuysjwUCClmDwsGaroIsayIaNYpmqdrFUNBwjfgrPuXhjmdlMqbLvfYwijMOmMvNCzCoCAFhJlUrgxiyQTINwHkgPprH"), 2063927238);
    this->XBJLS(string("oEJQaSXonfafxlmvpruHxbjdQcpbcHCCQgLIPSfLWinfhYrJmmfPHoaHffLBfhoNeSkDpZCkgqsNZpFmYzTWhSWYPpCCoPMozGdeCeUcLFRoPNOIzgzOzeSUraMmARPRFWKUZUipwGwNqjHRsAOYmwes"));
    this->ZLekCp(string("HXXqiDBWQlOtDDnRyKfPaSiunifBOWjnPLcLMUryWZQyPXZzTnjZjxqTBPhjdYbQViBYaMKeESIhmPPpYpWadPaqPZfAiWBLKSzVXCBIFAsUHMQhlsICJIjSNsqrsyWJUTlDmGXtjbSKZGSmnTqFRNkqHfUBzQaNcCHqbFui"), string("fJKTbUOQxgOQhFgPWolodOqgwGnoHhadEChbYRwOYwqMrUqScLJL"), string("EgvrFwtCilvYZHBksDFuNiVJNeRuzQZqgGylnPRbGgETYYGUoQmOZRsbFMBpSliJeKRwFdMxYdiwpcLaUvCyVATHHTEiFMgmkohadEQMsaFjkvSAkchLzTLqGILEBNzSfvgtRigplFOuFgThitHdoSKuBGMINZNEpvzKVGuUszaRtMVvGihsprIneJXhCndwHp"), 54788.42876209426, 861870.7989457366);
    this->PirrAZVENXaNMIPR();
    this->XvYCtOsyLeL(-99170842, string("BvclvanGrlFsyEqYhAwEWPhxetcqInXXqIoBfrWbXzSaXYVZcmHxrkOQjmQxcQYFLrluvNuHTvCvRnajFyhvedOIqjZiPEWstdqnYHrWTEpDtgEbKYebsOSsGPpe"), -2027128783, true);
    this->fMfPCvs(true, string("TafzHlHNZWiansjpgssXXfmlnEiFmGfercNbxUjmGqseFIUbtkyXBZpvjVtVJuHqnKjatExTrOtzQbVrUjamGRD"), string("YoWUpxFQBztiTHWiVQcFtHyjimgMuVZgEmFVHzKOXtwRkIUXqsGVJqVY"), 741675.2786422434, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class paAIyoZKyyL
{
public:
    double aMpNitnEw;
    bool CwLITHu;
    double RajMocGDXi;

    paAIyoZKyyL();
    int GJOZESLfD(string ehAvTqiLbucfW, bool qzvlbHZOYdpAMjg, int ggjuzThDha, string nYCcAzBPhndFQOwZ, string IKyLiwC);
    int XMLGycxNOgPRlad(double FxMuv);
    void bMnTavghjJG(string kNKYxUYGwlc, int bamhXPJXhvR, int KkMVomHcBm);
    bool NJYxvmCNwdX(bool UWkyr, string ipqSrtmCQeNjwYQ, double ntWrZ, string hIdDpsTovetDhSvN);
    bool dKyBxKgbqZcgvF();
    string MGVdXtASfY(int hsiUaweIgcXM, double fplPwtISDufPkW);
    int awsjes();
    string adewnqEFyNsRPoO(string XCbNpWU, bool GfEsOV, string uxltTdYjuIycUHo, double KyoflSJjPoiosWL);
protected:
    string WBdkFZMdGOIjWmEG;
    string DXmNUaJvaRB;
    string BXJYZCIuVkn;
    double rpdxaEGNuA;
    int gKhBaqYWatmk;

    int jjCmEdAANup(double aHGUagqcfQNb, string Udmay, double wIvNpchCBoN);
    double AJfgQENisgVG(bool perXbmTglkljURY);
    bool jkYmNGvD();
    string zooAfEcu(int UlbeyUAOrTIyiWMV, int BCNtVzChtTK, bool zoForv, bool rbpWcGpV);
    void jAejZhvMtWE(bool dDsPbAQmZpfSADq, bool McfrztqxaN);
    double nTkOOFVxjS(bool rWDXWK, int IacVSCxmmDlnm);
    int CoPCpJpAz(int rCPuaQjMllMDvVNC, bool LlfWctgrscdkayc, int tHQoo, int HurSXuSx);
    string EAsrjUIHQKwPXbD(double YAFiVRWkAOexO, bool AEkFKpuwyIbcCtwz, string DfpvhGpaQWjUq, string WAPSFOPlcWQinf);
private:
    int qsxEihETxnPYiCy;
    string xqOosLFksE;
    string mWzRcwaDmK;
    int FSElROSchb;
    int VBOjdk;

    bool fmnHjcFMdQuTlSz();
    bool xWeaBYpFb(double mFWXTfrQCU, string GyQojjYGLZgJb);
    double lIXFlYFFBxhxrXh(int ONZyRYUJT, bool JjosVeyqe, bool jFRbkEkvazWr, int kAykFkAfTKOOAOjb);
    bool LZqtRxZoYLlRtFr(int DfhsoKtpOWdRf, double eYXuOrJw, bool flrQNVN, string FZKLlF, bool jYhhThmFlD);
};

int paAIyoZKyyL::GJOZESLfD(string ehAvTqiLbucfW, bool qzvlbHZOYdpAMjg, int ggjuzThDha, string nYCcAzBPhndFQOwZ, string IKyLiwC)
{
    bool ssQizm = false;
    string aoYoHkLzsna = string("ohxIJNiPhJNLKOqFfKCmWYaVsQvbqVEwGNRSdjmFtQOdLBcTHsVoGAgnfoLRwzpvBbzPaxNFpwwhST");
    int YQpBYc = -1789030648;
    double IGumLVmk = 643067.7797644992;
    double tAVRJbodKD = 939610.3103002955;
    string jlAaj = string("RHJysWDuuyggODpeAHRVjUOUllpiOvVnLDxbHxxPpEQTSQOxFqPBLmSTqfWvNWGnqALKjoZucFlrFGqcGdgqqUHIPVvpNBmwqaJtUvwVOOlviDxGukDzdetQlDPCGKuXvuYwOgXDJzk");

    for (int HUdMqvnHkj = 1364755272; HUdMqvnHkj > 0; HUdMqvnHkj--) {
        IKyLiwC = nYCcAzBPhndFQOwZ;
        IGumLVmk /= tAVRJbodKD;
        YQpBYc /= YQpBYc;
        IKyLiwC += nYCcAzBPhndFQOwZ;
    }

    return YQpBYc;
}

int paAIyoZKyyL::XMLGycxNOgPRlad(double FxMuv)
{
    double CJJmudAltPyMMba = -468494.6007520293;
    string AdZGfeumWg = string("sYuRcQChhfCraXKOCazTFenCSuAtQRlXNaqdRNguMumiBTmRLMFXndbaERPHZsZKgnxhwCLIRbUtjYhHiseEqFnYuYHvZBsKFXhIgyWgdclnZbJDDjyUqkzuPLzvzYbGRAofpXWazFIPJrGqQZOmncguxtCsgLZVQDuMRFTVLIuwQRUSGTm");
    int pudpbHnAI = 202501812;
    bool JgZGCqPSFb = true;
    double qvERlYUvlPnJZTOF = 74631.21115974407;

    for (int dhmRkgAbMUPSkg = 229642502; dhmRkgAbMUPSkg > 0; dhmRkgAbMUPSkg--) {
        continue;
    }

    for (int FUFislR = 1870374401; FUFislR > 0; FUFislR--) {
        JgZGCqPSFb = JgZGCqPSFb;
        FxMuv -= qvERlYUvlPnJZTOF;
        qvERlYUvlPnJZTOF += FxMuv;
        qvERlYUvlPnJZTOF = CJJmudAltPyMMba;
    }

    return pudpbHnAI;
}

void paAIyoZKyyL::bMnTavghjJG(string kNKYxUYGwlc, int bamhXPJXhvR, int KkMVomHcBm)
{
    int dlAFIlzvCWKkqOH = -760463697;

    for (int utBjIGyVgdXWi = 76741867; utBjIGyVgdXWi > 0; utBjIGyVgdXWi--) {
        dlAFIlzvCWKkqOH = dlAFIlzvCWKkqOH;
        KkMVomHcBm *= KkMVomHcBm;
        KkMVomHcBm /= KkMVomHcBm;
        KkMVomHcBm /= dlAFIlzvCWKkqOH;
        kNKYxUYGwlc += kNKYxUYGwlc;
    }

    for (int MaknMLWmFrv = 1083169758; MaknMLWmFrv > 0; MaknMLWmFrv--) {
        bamhXPJXhvR += dlAFIlzvCWKkqOH;
        kNKYxUYGwlc = kNKYxUYGwlc;
        bamhXPJXhvR /= bamhXPJXhvR;
        KkMVomHcBm = bamhXPJXhvR;
        bamhXPJXhvR *= dlAFIlzvCWKkqOH;
        bamhXPJXhvR += KkMVomHcBm;
    }

    if (KkMVomHcBm != -850772814) {
        for (int JTYvfDuu = 240304035; JTYvfDuu > 0; JTYvfDuu--) {
            bamhXPJXhvR -= bamhXPJXhvR;
            dlAFIlzvCWKkqOH += dlAFIlzvCWKkqOH;
            dlAFIlzvCWKkqOH /= KkMVomHcBm;
        }
    }

    if (kNKYxUYGwlc < string("rxgRhTLGImRGFtQzcqGRnfrWTbadAZlWOmmBIPGwlXVqTjJDRkfFWASJNSqzPYNDdRPnlWhzZyLIrnJOeHHRTJTNBnXLydYTLIPsUTWLPMVvJaJXQHTDbLaNhFBpcYgFXc")) {
        for (int jmBpgBdCCMHAthre = 1345701071; jmBpgBdCCMHAthre > 0; jmBpgBdCCMHAthre--) {
            bamhXPJXhvR -= bamhXPJXhvR;
            dlAFIlzvCWKkqOH *= bamhXPJXhvR;
            dlAFIlzvCWKkqOH *= dlAFIlzvCWKkqOH;
        }
    }

    if (KkMVomHcBm <= -760463697) {
        for (int GHUzTYBoxBYnb = 363915889; GHUzTYBoxBYnb > 0; GHUzTYBoxBYnb--) {
            bamhXPJXhvR *= dlAFIlzvCWKkqOH;
            dlAFIlzvCWKkqOH /= KkMVomHcBm;
            dlAFIlzvCWKkqOH -= KkMVomHcBm;
            bamhXPJXhvR -= bamhXPJXhvR;
        }
    }
}

bool paAIyoZKyyL::NJYxvmCNwdX(bool UWkyr, string ipqSrtmCQeNjwYQ, double ntWrZ, string hIdDpsTovetDhSvN)
{
    bool gQwicHDGdhcdj = false;

    for (int XpJJAVR = 1171387894; XpJJAVR > 0; XpJJAVR--) {
        continue;
    }

    return gQwicHDGdhcdj;
}

bool paAIyoZKyyL::dKyBxKgbqZcgvF()
{
    string MJXtmyk = string("EaMkRXUNW");
    int PSBrjxxC = 306258890;
    bool CdieSZ = true;
    bool lYIbsgbsaNWr = false;
    int ZmbeNAV = -1668020409;
    double ALVSliYVd = 560269.1823475085;
    bool mRXMEQSEmIdCo = false;

    return mRXMEQSEmIdCo;
}

string paAIyoZKyyL::MGVdXtASfY(int hsiUaweIgcXM, double fplPwtISDufPkW)
{
    int skQqsog = 1435266797;
    int EzglNpMHuKgRvkAU = -1305693532;
    double pMPJqbtYbTISLkxq = -724405.0203726514;
    bool geErcjIyeflO = false;

    return string("JNgNFTrtQhAcNbCEEgvcDhtXqfOvZWiHCtgtBrVHPrlIZsdmArRfSfBJ");
}

int paAIyoZKyyL::awsjes()
{
    bool INynPb = true;
    double ycrVCDyDaMgjCuvI = 107589.2237144382;
    string thToiQYsLtwftMVA = string("HcnmjeJAjTbPiJeKKoAmhaqHlRsGXpiPwYTuHRkhCFDvrACOhUhZKWCjPsYSdwYYgQvgdqamqcfrPMxOlEmCsHrsIvbKWzHWqktJnhEVDlJzbPbjGdXHsLNiqXNlNNpNiucx");
    bool sLnzTNFtjtT = false;
    string sWfKOoiepxssCKVY = string("wQcONEJfKxNkNmDuYxhggMBaFFaGkwPSFeXMeFPsHNDpKnnVEgroeprZCIXKTXiJoBGrQakpLAGbAuAkcOKVLCzwgGHPgvmNplNnoYEdkjIWzbTKCwshUXCghKdyzLRfKIclLcAXUVaywDHMAKldmyjcjxSnzdxNNEe");

    for (int zXEedmZIRjwV = 461424986; zXEedmZIRjwV > 0; zXEedmZIRjwV--) {
        INynPb = ! sLnzTNFtjtT;
        ycrVCDyDaMgjCuvI /= ycrVCDyDaMgjCuvI;
    }

    for (int ObDxXLxSkUT = 1261288545; ObDxXLxSkUT > 0; ObDxXLxSkUT--) {
        sWfKOoiepxssCKVY = sWfKOoiepxssCKVY;
        thToiQYsLtwftMVA += sWfKOoiepxssCKVY;
    }

    return 924560080;
}

string paAIyoZKyyL::adewnqEFyNsRPoO(string XCbNpWU, bool GfEsOV, string uxltTdYjuIycUHo, double KyoflSJjPoiosWL)
{
    bool HUDorNdVdxlbCF = false;
    string khOiVG = string("CdsKwkcMIwgxKvClnUMIyAJmNaFysDSWDhIuWGBKSFJIGGnUJzFllmFqxvNQBMyYnnIlhsvhKXjBrutKcPdTkqvyqDSqdyRuVbYSbK");
    double fMitSrZGp = -273395.6966754026;
    int djBKTfWyHiH = 1980036721;
    int KxkSlRzmvApVo = -1095860450;
    bool kNcHNmTI = true;
    bool VKcooF = true;

    if (XCbNpWU < string("LVWuWsFbqOFgJHoisuujvmWbXzqJQeCZvgEnoGXTCUOfYkjrOiZuCkOWLXAnIEjwKPobnYnWQJcnRnfBWRIjjFIuWzyuksqVE")) {
        for (int nCmoNpgsLYkVjnmK = 2048268015; nCmoNpgsLYkVjnmK > 0; nCmoNpgsLYkVjnmK--) {
            KxkSlRzmvApVo /= djBKTfWyHiH;
            djBKTfWyHiH += djBKTfWyHiH;
        }
    }

    for (int ZsfOVTgaCPn = 2059160392; ZsfOVTgaCPn > 0; ZsfOVTgaCPn--) {
        XCbNpWU = uxltTdYjuIycUHo;
    }

    if (GfEsOV != true) {
        for (int BwyIEJ = 608273019; BwyIEJ > 0; BwyIEJ--) {
            XCbNpWU = uxltTdYjuIycUHo;
            KxkSlRzmvApVo *= KxkSlRzmvApVo;
            VKcooF = kNcHNmTI;
        }
    }

    if (GfEsOV != true) {
        for (int mQFprCJKENV = 2114024666; mQFprCJKENV > 0; mQFprCJKENV--) {
            khOiVG = XCbNpWU;
        }
    }

    return khOiVG;
}

int paAIyoZKyyL::jjCmEdAANup(double aHGUagqcfQNb, string Udmay, double wIvNpchCBoN)
{
    bool lNzSDGMG = true;
    int EscwlFlUY = 816903037;
    double TUjOptjYiDRNPhiJ = -1007469.9817240905;
    bool MwkYrKBgpdKDSP = true;
    string cWlZKbfPeZ = string("ZafBOLBouVWqDQBEMWbsvNOCtVoZbgaXiFs");

    if (aHGUagqcfQNb == 1035475.8253770462) {
        for (int gvqyxhQzcaB = 343161416; gvqyxhQzcaB > 0; gvqyxhQzcaB--) {
            lNzSDGMG = MwkYrKBgpdKDSP;
            lNzSDGMG = ! MwkYrKBgpdKDSP;
            wIvNpchCBoN *= TUjOptjYiDRNPhiJ;
        }
    }

    if (aHGUagqcfQNb > 1035475.8253770462) {
        for (int wRSZjqWGbzmITEAW = 1129175873; wRSZjqWGbzmITEAW > 0; wRSZjqWGbzmITEAW--) {
            aHGUagqcfQNb *= wIvNpchCBoN;
            wIvNpchCBoN *= wIvNpchCBoN;
            lNzSDGMG = ! MwkYrKBgpdKDSP;
            TUjOptjYiDRNPhiJ *= wIvNpchCBoN;
            MwkYrKBgpdKDSP = ! MwkYrKBgpdKDSP;
        }
    }

    for (int KbdkfaGi = 217286906; KbdkfaGi > 0; KbdkfaGi--) {
        TUjOptjYiDRNPhiJ -= wIvNpchCBoN;
    }

    for (int sqlqBXdnbBGh = 382947277; sqlqBXdnbBGh > 0; sqlqBXdnbBGh--) {
        Udmay += cWlZKbfPeZ;
        wIvNpchCBoN -= TUjOptjYiDRNPhiJ;
    }

    for (int MccuVqkYCyjM = 618694036; MccuVqkYCyjM > 0; MccuVqkYCyjM--) {
        TUjOptjYiDRNPhiJ -= wIvNpchCBoN;
        EscwlFlUY -= EscwlFlUY;
    }

    return EscwlFlUY;
}

double paAIyoZKyyL::AJfgQENisgVG(bool perXbmTglkljURY)
{
    double sUveAew = 552786.4067803374;
    int LbxXPN = -1968188332;

    if (LbxXPN == -1968188332) {
        for (int WdvFA = 1847552131; WdvFA > 0; WdvFA--) {
            sUveAew = sUveAew;
            LbxXPN = LbxXPN;
            sUveAew -= sUveAew;
        }
    }

    return sUveAew;
}

bool paAIyoZKyyL::jkYmNGvD()
{
    int DTHgoBAKmS = 1421202442;
    string xLtfypIUX = string("TjOsQhSuYeSBcYuTGbUIQrKCcNOYunbTeOnNSUDQbAhfFFaGjhcapVTKSvwquWjnvUPbTHZupyYwFGGGssCraUQETDDnrp");
    string ypPKyjnPcACMLcK = string("azeVqiqMmEieszEBuZEoumLBDNFbVNWQEXbFYXYkpGHjerQLMFfuFdfwvkJleMpNDDTNWcFmdnvRerhxZfWSRmqEUXSGgNhgbrtinTc");
    int hdUjaQJcRQmL = 1714136320;
    bool PWpATpDZfpWjTIq = false;
    bool SSBtCXYysB = true;

    for (int EWitb = 617047964; EWitb > 0; EWitb--) {
        hdUjaQJcRQmL *= DTHgoBAKmS;
        hdUjaQJcRQmL /= hdUjaQJcRQmL;
        xLtfypIUX += xLtfypIUX;
        xLtfypIUX += ypPKyjnPcACMLcK;
    }

    for (int HFxeg = 1335539133; HFxeg > 0; HFxeg--) {
        DTHgoBAKmS += hdUjaQJcRQmL;
        ypPKyjnPcACMLcK = ypPKyjnPcACMLcK;
    }

    for (int BVsmIyAUMD = 1681918124; BVsmIyAUMD > 0; BVsmIyAUMD--) {
        PWpATpDZfpWjTIq = PWpATpDZfpWjTIq;
    }

    for (int wyOXHVWuQH = 1243273751; wyOXHVWuQH > 0; wyOXHVWuQH--) {
        xLtfypIUX += ypPKyjnPcACMLcK;
        DTHgoBAKmS += DTHgoBAKmS;
    }

    for (int VBSfbIpvHkTbo = 653726436; VBSfbIpvHkTbo > 0; VBSfbIpvHkTbo--) {
        DTHgoBAKmS *= DTHgoBAKmS;
        xLtfypIUX = xLtfypIUX;
        hdUjaQJcRQmL += DTHgoBAKmS;
    }

    for (int YnBPu = 1392059267; YnBPu > 0; YnBPu--) {
        xLtfypIUX = xLtfypIUX;
    }

    for (int oYcUXTUbXI = 585788226; oYcUXTUbXI > 0; oYcUXTUbXI--) {
        hdUjaQJcRQmL += hdUjaQJcRQmL;
    }

    return SSBtCXYysB;
}

string paAIyoZKyyL::zooAfEcu(int UlbeyUAOrTIyiWMV, int BCNtVzChtTK, bool zoForv, bool rbpWcGpV)
{
    string DPcBEYluV = string("WDDVizWkLrxhehfhdNTEKO");
    double LhSZCzigV = 392570.8876781647;
    bool sfOOK = true;

    for (int aZMmpGSGUwQ = 1562667635; aZMmpGSGUwQ > 0; aZMmpGSGUwQ--) {
        rbpWcGpV = ! zoForv;
    }

    for (int RFqsCJBYfEOeCv = 1445342057; RFqsCJBYfEOeCv > 0; RFqsCJBYfEOeCv--) {
        zoForv = ! zoForv;
        rbpWcGpV = ! rbpWcGpV;
        sfOOK = zoForv;
        rbpWcGpV = ! sfOOK;
    }

    if (LhSZCzigV < 392570.8876781647) {
        for (int weTiMKCAo = 1605514056; weTiMKCAo > 0; weTiMKCAo--) {
            BCNtVzChtTK = UlbeyUAOrTIyiWMV;
            rbpWcGpV = ! sfOOK;
        }
    }

    for (int wIhvvc = 1247023511; wIhvvc > 0; wIhvvc--) {
        sfOOK = ! sfOOK;
        rbpWcGpV = sfOOK;
    }

    return DPcBEYluV;
}

void paAIyoZKyyL::jAejZhvMtWE(bool dDsPbAQmZpfSADq, bool McfrztqxaN)
{
    double ZXLTcBYQ = 735482.1595386883;
    bool ZhndBfmyQusiQFb = false;

    if (ZhndBfmyQusiQFb != true) {
        for (int UszJheStFTdZqG = 176417786; UszJheStFTdZqG > 0; UszJheStFTdZqG--) {
            ZhndBfmyQusiQFb = ! dDsPbAQmZpfSADq;
            ZhndBfmyQusiQFb = ! McfrztqxaN;
            ZhndBfmyQusiQFb = McfrztqxaN;
            dDsPbAQmZpfSADq = ZhndBfmyQusiQFb;
            dDsPbAQmZpfSADq = dDsPbAQmZpfSADq;
            McfrztqxaN = dDsPbAQmZpfSADq;
        }
    }

    for (int gkQImoLybjldjaO = 1495109812; gkQImoLybjldjaO > 0; gkQImoLybjldjaO--) {
        McfrztqxaN = ! dDsPbAQmZpfSADq;
        dDsPbAQmZpfSADq = ZhndBfmyQusiQFb;
        ZhndBfmyQusiQFb = McfrztqxaN;
        ZXLTcBYQ -= ZXLTcBYQ;
    }
}

double paAIyoZKyyL::nTkOOFVxjS(bool rWDXWK, int IacVSCxmmDlnm)
{
    string MVAQwooNaxuH = string("kDLNREpyXrJvjdlnllY");
    string NoVorDjSu = string("greUCxReYQtOrjPOiTmeUTKHMibIhneCCiEFhSnICItmsQCyJtIUzTZKpqeSTunWGbAfxsZfrIyFpboyawDqYslxYIDJJBOhScDyPsJdUCFENZpFebfxraKwqrpHyTZYT");
    string bnRStDJwBT = string("ODbEWrEhfFfXJZBTVnzrTMZridFqHiEiTdiUxtKIKgNRUmnhsdCxQrdqDMhsxQZCtHTlXJlopJwUTyGheouWdNnVgbYdEDSQfJBqchQDkugWzxBwjQEfOrjtXapxXSgzKqBzfeFDscfamqqBPemMFwRDnZBrvFLgAoRMdxeCRFncPVdbPGWhiSYEKUIZecuTpyDdyggTwigJOQrnSzxwJffxRDwlvMEcMytFnXWpcNDwMSjsykh");
    string YlPHYWGbzfY = string("ZiTLXuvefbYkgBFijbyLNkOXyACHQZFtjntdINZWqkqZVVzCFdaccQjrfAmdygcoHVIzTggQOxYXpWBLpfvtrsjTPUodrdDyndnPyoZiJwFAqKYZYnbj");
    double eVuTwsRuSVBd = -164832.53694540716;
    int vQJQiBIUDCmTRNJi = 351094054;
    double XqVsOFgUf = -412114.7573865664;
    int OopXLtvDYVA = -1241283764;
    double yOgZRAPyUSWTSD = 687810.4693410369;

    for (int rbFjNSuyM = 1861858778; rbFjNSuyM > 0; rbFjNSuyM--) {
        MVAQwooNaxuH = YlPHYWGbzfY;
    }

    if (YlPHYWGbzfY < string("ZiTLXuvefbYkgBFijbyLNkOXyACHQZFtjntdINZWqkqZVVzCFdaccQjrfAmdygcoHVIzTggQOxYXpWBLpfvtrsjTPUodrdDyndnPyoZiJwFAqKYZYnbj")) {
        for (int WrTqTpZcsDumydli = 1664353952; WrTqTpZcsDumydli > 0; WrTqTpZcsDumydli--) {
            MVAQwooNaxuH += NoVorDjSu;
        }
    }

    for (int yKWiEZuCrnTJ = 576379834; yKWiEZuCrnTJ > 0; yKWiEZuCrnTJ--) {
        OopXLtvDYVA /= vQJQiBIUDCmTRNJi;
        eVuTwsRuSVBd *= eVuTwsRuSVBd;
        vQJQiBIUDCmTRNJi /= vQJQiBIUDCmTRNJi;
        XqVsOFgUf *= XqVsOFgUf;
        IacVSCxmmDlnm *= OopXLtvDYVA;
    }

    for (int KwiTtwDKm = 1302771251; KwiTtwDKm > 0; KwiTtwDKm--) {
        XqVsOFgUf /= yOgZRAPyUSWTSD;
        yOgZRAPyUSWTSD /= yOgZRAPyUSWTSD;
    }

    for (int AoctsaFZIvr = 892753467; AoctsaFZIvr > 0; AoctsaFZIvr--) {
        vQJQiBIUDCmTRNJi /= vQJQiBIUDCmTRNJi;
    }

    return yOgZRAPyUSWTSD;
}

int paAIyoZKyyL::CoPCpJpAz(int rCPuaQjMllMDvVNC, bool LlfWctgrscdkayc, int tHQoo, int HurSXuSx)
{
    int YqyTpIfvoOrt = -1955403836;
    string cihAQL = string("XxXjpLygndWXTtadbPRVZKEhKerdnjWgxCmiSaXFVvSXHxAlqGaxdYNyBkviYqYrNWHCCIgixjoEtkhfVVeKxqGNVVmektlAXlkDBNnaWkbwqsVrICuMlKYSjQlUJzHxUkjLmWgIxvafAopFgbRapiSuZAcvFrwPYnfxfvhbaLeltZrvjOObIuecINWtfchPWXZrqeX");
    bool UIKwMvPmjWE = false;
    bool hEVhp = true;
    double fmkTuuwoMGWL = -18446.437764319893;
    int rqFfc = 691729798;
    double YJfERQyoIbDFL = -413906.0041345922;

    for (int rGHrdIzjP = 1811026145; rGHrdIzjP > 0; rGHrdIzjP--) {
        tHQoo -= rqFfc;
    }

    if (tHQoo == -1955403836) {
        for (int NeeHtNJXFTW = 2083540523; NeeHtNJXFTW > 0; NeeHtNJXFTW--) {
            HurSXuSx /= tHQoo;
            YJfERQyoIbDFL *= fmkTuuwoMGWL;
        }
    }

    for (int TkpTWHPwwP = 875547592; TkpTWHPwwP > 0; TkpTWHPwwP--) {
        hEVhp = ! UIKwMvPmjWE;
    }

    return rqFfc;
}

string paAIyoZKyyL::EAsrjUIHQKwPXbD(double YAFiVRWkAOexO, bool AEkFKpuwyIbcCtwz, string DfpvhGpaQWjUq, string WAPSFOPlcWQinf)
{
    int RGsYqSyiGn = 1561778271;
    int SFgiqZOz = 1615118255;

    if (RGsYqSyiGn != 1615118255) {
        for (int vdUpjwraGE = 649997491; vdUpjwraGE > 0; vdUpjwraGE--) {
            SFgiqZOz = SFgiqZOz;
        }
    }

    for (int UdIZe = 1373821307; UdIZe > 0; UdIZe--) {
        YAFiVRWkAOexO = YAFiVRWkAOexO;
    }

    for (int zqBSDaQdj = 1307618010; zqBSDaQdj > 0; zqBSDaQdj--) {
        AEkFKpuwyIbcCtwz = AEkFKpuwyIbcCtwz;
        RGsYqSyiGn *= RGsYqSyiGn;
    }

    for (int EGKrMUbJkRscUq = 1715116993; EGKrMUbJkRscUq > 0; EGKrMUbJkRscUq--) {
        RGsYqSyiGn /= SFgiqZOz;
    }

    return WAPSFOPlcWQinf;
}

bool paAIyoZKyyL::fmnHjcFMdQuTlSz()
{
    int HyanQbT = 1742912173;
    string KlnwsDxjNLmWcCU = string("DKyBWrbwXqkvLspPrFVYkqTOymBTbMHxUYfreuKqoZfuRJmCbPesOZpPnvqDDONAnNmMgddYBpCFxJRviFxFKXLWocmTFqXjCxilwxJAJXsZGFoKMkFvdoForOCSxULHdZQxOlaoXOdGExxeaKOsHRhHcjzPQCughXzMNsjEADEIamkTNfaMVviCSjKZinZIgbPIqTylyJqlASYvDJAIErrBoPxNnGUtWYXGSj");
    double KvBVqrlGPoxXF = -561132.3805595066;

    if (KvBVqrlGPoxXF > -561132.3805595066) {
        for (int yzxYxVcKbBcR = 1934969564; yzxYxVcKbBcR > 0; yzxYxVcKbBcR--) {
            HyanQbT -= HyanQbT;
            HyanQbT = HyanQbT;
        }
    }

    return true;
}

bool paAIyoZKyyL::xWeaBYpFb(double mFWXTfrQCU, string GyQojjYGLZgJb)
{
    string AwluG = string("JuNGeBLGDVgBZQXlgbjyLcWfGydIVLpvj");
    int NOKrhBeF = -386643896;
    string SPXMqz = string("WCiqLsFgsIDrrydNCIMUUdfMFlTacQnkImzjDUMOhvbjmUMncfReBWqKkYAuoriILfyKaGNXdzPPvGXAsuIdyQrewQvmwqdD");
    int GCswLQHZlUGIbkyw = -1280306155;
    int vyilGlhxQkoqvI = -1971407928;
    string MuYkddRaYgg = string("aFZFxKmjrgxvYmMNiPmPhSIJexNVXhltkOYFmJsZmvjPKFBfnV");
    bool KDARvdSKBDKp = false;
    string VNXYnrCVfz = string("HDWGZFsfErmioTTJmqXmjJMwmKzbQHEnhZWbyDpCjFnvxQxqiCwVgpHwIKryDINezaOFOrugkgvbGrtDPOdsOaGvKZSAuxVaIyUjkQlBUQRNXPbvLEtpzXNdsHOgVIxwAwSNYBTlproSBaxhIFYWbHDdvwrnStLqQAJleW");
    double wPAidegBRjVY = -105447.88599596253;
    bool zAKNxvpFcgMh = true;

    for (int MYoSR = 520339874; MYoSR > 0; MYoSR--) {
        VNXYnrCVfz += GyQojjYGLZgJb;
    }

    for (int gavztGlD = 856054410; gavztGlD > 0; gavztGlD--) {
        wPAidegBRjVY /= wPAidegBRjVY;
    }

    return zAKNxvpFcgMh;
}

double paAIyoZKyyL::lIXFlYFFBxhxrXh(int ONZyRYUJT, bool JjosVeyqe, bool jFRbkEkvazWr, int kAykFkAfTKOOAOjb)
{
    int NBouyjE = -141890262;
    int yglxBFxJ = -6740972;
    int FmiuoWNYVI = 1735958344;
    string evHrZ = string("LdEDPaLPTWLxLQOMTvTdBsOROonDaKTjShWTiyOeOEaJcrawCkbAzuphcsmVwSEoPwgusvvKijXVgaNhEyrfuuyoViLfFQGXeAoQdRkyjnBwBNQZKnWQENYOyLKxXpDbmOYnrmGiNGofMqOGJymzmRyxDDOUOUrknMhBMhgyoCOiboRUKpXNEykYHmyHtEWyiOqPtb");
    bool bQXxFHDmTlkLD = false;
    string iDTBPudaloIdA = string("dtcySfrQZIXIoGsaeqQeXdkrKzWGdNiaTfMeXNQwKVhuLnhHrBykWGpBwvvFpOPQaCWzALnWvUbMiBRyfrdWhZCeqZtrBRngTMMNoteecjshQBNwVqWmsyYbvqMGUsLjcsExqxZSSMRGglmpJbuLijBBSGhvT");

    if (NBouyjE == 1735958344) {
        for (int QyExmMNPzqRSpJF = 1707201953; QyExmMNPzqRSpJF > 0; QyExmMNPzqRSpJF--) {
            jFRbkEkvazWr = bQXxFHDmTlkLD;
        }
    }

    if (JjosVeyqe == false) {
        for (int nUNoDWU = 1593159958; nUNoDWU > 0; nUNoDWU--) {
            FmiuoWNYVI += ONZyRYUJT;
            ONZyRYUJT -= NBouyjE;
            NBouyjE /= ONZyRYUJT;
        }
    }

    if (iDTBPudaloIdA > string("LdEDPaLPTWLxLQOMTvTdBsOROonDaKTjShWTiyOeOEaJcrawCkbAzuphcsmVwSEoPwgusvvKijXVgaNhEyrfuuyoViLfFQGXeAoQdRkyjnBwBNQZKnWQENYOyLKxXpDbmOYnrmGiNGofMqOGJymzmRyxDDOUOUrknMhBMhgyoCOiboRUKpXNEykYHmyHtEWyiOqPtb")) {
        for (int UwajJ = 1707510790; UwajJ > 0; UwajJ--) {
            bQXxFHDmTlkLD = ! bQXxFHDmTlkLD;
            kAykFkAfTKOOAOjb -= NBouyjE;
            JjosVeyqe = JjosVeyqe;
        }
    }

    for (int bhIwjHWozzSLyh = 387744000; bhIwjHWozzSLyh > 0; bhIwjHWozzSLyh--) {
        yglxBFxJ /= FmiuoWNYVI;
    }

    return 243381.61242791358;
}

bool paAIyoZKyyL::LZqtRxZoYLlRtFr(int DfhsoKtpOWdRf, double eYXuOrJw, bool flrQNVN, string FZKLlF, bool jYhhThmFlD)
{
    double WPAksnpXEz = -308644.04989832325;
    bool ajYdp = true;

    for (int pASEniekDL = 1521428334; pASEniekDL > 0; pASEniekDL--) {
        WPAksnpXEz /= WPAksnpXEz;
        ajYdp = flrQNVN;
    }

    for (int QKORLBhW = 92738194; QKORLBhW > 0; QKORLBhW--) {
        WPAksnpXEz /= eYXuOrJw;
        jYhhThmFlD = jYhhThmFlD;
        jYhhThmFlD = jYhhThmFlD;
    }

    return ajYdp;
}

paAIyoZKyyL::paAIyoZKyyL()
{
    this->GJOZESLfD(string("oKPPUzANNPBrjwvyXdrnBeyoCVwLyBTRETnrDZHgkAZNlqnmxRTaupBaKQEwQNEkRGBbnIzHvObursCXaAPqTuhclxTfNfpqYgjdFaVwdnq"), false, -453649774, string("lMhobA"), string("LvtQHJNIkbCTLaiUPcdgUdvlqXqUNJvbAWyivZJdcFZnDsq"));
    this->XMLGycxNOgPRlad(-66082.60768867856);
    this->bMnTavghjJG(string("rxgRhTLGImRGFtQzcqGRnfrWTbadAZlWOmmBIPGwlXVqTjJDRkfFWASJNSqzPYNDdRPnlWhzZyLIrnJOeHHRTJTNBnXLydYTLIPsUTWLPMVvJaJXQHTDbLaNhFBpcYgFXc"), -850772814, 134519768);
    this->NJYxvmCNwdX(true, string("pwFVEQgwrrxiAqPPNtdXcLyFOhivdhArcHHgszJGcPJkzQHjjolJaUKOxYKgEFMbaBDThbKpgycg"), -433358.31235833, string("IwoAFdiZosTPXVu"));
    this->dKyBxKgbqZcgvF();
    this->MGVdXtASfY(-942842609, -561371.6469102676);
    this->awsjes();
    this->adewnqEFyNsRPoO(string("DhVNRnFWqCNeaDeqekZhuRGXCxre"), false, string("LVWuWsFbqOFgJHoisuujvmWbXzqJQeCZvgEnoGXTCUOfYkjrOiZuCkOWLXAnIEjwKPobnYnWQJcnRnfBWRIjjFIuWzyuksqVE"), -1031285.9606022965);
    this->jjCmEdAANup(387368.89051115833, string("zEJPoTqRLwwaFGPLRyHIwZaPbYNuZjcQHeTRHGNykQPVHGoEZAPiRgwQsFygpAdJ"), 1035475.8253770462);
    this->AJfgQENisgVG(true);
    this->jkYmNGvD();
    this->zooAfEcu(2003422052, -159175072, true, false);
    this->jAejZhvMtWE(true, true);
    this->nTkOOFVxjS(false, -1715485326);
    this->CoPCpJpAz(-993124404, false, -678695698, 326451439);
    this->EAsrjUIHQKwPXbD(65750.86242550245, false, string("LFXUpZZNPjQhlIZAytClKNHMrwBZ"), string("OJxvxuLWCdjVMghlPUAQsxdFQdeAgkU"));
    this->fmnHjcFMdQuTlSz();
    this->xWeaBYpFb(586620.247652751, string("YvfmJHsXkQHtgCLOIOGceaoVotyTCaGdxgLGuQdfQpwaZXQncLpDKNyBnGLrizPAKafDUScZjmKXVGKhOQFoBdmWKHHZqqpaSnCnoCWlsLmeljawiSorCygTEgUKiMwvMqXiCkxgHjYwnXvJMQnWLeduIghcnTAeKOvtsGzXGuDThmdZoRiZKGXHAlKnxMCapCVuvvTEzYygRAZBeoLCGChvoxmEeudijMoREbHtXBAcn"));
    this->lIXFlYFFBxhxrXh(58573697, false, true, -1749804766);
    this->LZqtRxZoYLlRtFr(691634749, 224918.23380273688, true, string("BVLDpWcDAVDoiUyyKSJnmFHFWuoWaZEoqXODrRpDvKVAj"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XfptycGZEEAHAJLd
{
public:
    double SQhwasydXcBE;

    XfptycGZEEAHAJLd();
    double wuyglkTtun();
    void JPneHzGpTDDLm();
    void qhfoWPP();
    int tjySdZFy(int VMqLmRSzJJIHI);
protected:
    int lslLJFuHuzkPC;
    double WeNDiZ;
    double wFmccfxA;
    bool nshmfY;

    double GNEwM(int rbHBUpGDihNt);
    string PpoRQ(int oSFvLDKJuCn, bool oSgJiIfBMeDnCfk, bool dJJARmiw);
private:
    double AgcJlMWA;
    string oABDqypg;
    string LNfTumxwd;
    double gzYMU;
    string uNstbqa;

    double ZVDRGWBlTaIdws(int WrhhBngFauUY, string Qieci, double suvkphRKvaxD, bool UhPQgPEVsXy);
    double QcsOZUnGu(string elNZxNzxQALsPqUt);
    double vTVjdSmbxO(bool KXMxTFMBxxdtHSq);
    bool fafjkpqYLIbkrEBt(double apZAWIMrsJtzlPn, string bZOiujtrQOcBX, string TWVcIxqzM);
    double UKRwUhlvt();
};

double XfptycGZEEAHAJLd::wuyglkTtun()
{
    bool pZtrAiacKPQaFd = true;
    double BHpfSwBsoSAC = -131649.7523827138;
    string haeRi = string("yhqbDNUXFUvCJWAvIhEBilwiLZYKzhRpvpjpRFRNNZsgEItcDDBwttvoglrRqpwFiIsDlctZwhQNXAynphkXIngQLldtBLJNZvqerKFzJhGIiadmPXGzsnImGS");

    for (int cMqmwocOyH = 1980045975; cMqmwocOyH > 0; cMqmwocOyH--) {
        BHpfSwBsoSAC -= BHpfSwBsoSAC;
        haeRi = haeRi;
    }

    return BHpfSwBsoSAC;
}

void XfptycGZEEAHAJLd::JPneHzGpTDDLm()
{
    double vguVz = -919158.6410236034;
    double SVGCxAbbfPaHLi = 873424.0673024321;
    bool zXIEe = true;
    int jxBjU = -1996862162;
    int SjddgzcE = -372063797;
    double LePDzbDiW = -23987.249374441082;
    bool JDAlbeG = true;
    string oBSNe = string("OyAyUuNMKYAYNHcxwfnmTzfaAAioWEZzNnBldgxJiMfCIRFIktlvAffXhFksSZXJzagsDmU");
    string VlWCNnEA = string("feGritqJfBoxVbEKRxkXFLjuncqTZfmESdmdwtvozDizEgIpPQqMmsBYSEDDblEvOuYTSnWubbXnswJQOfESovQGgXBmVcpvVLCvkWqisxSWHPs");

    if (SjddgzcE >= -372063797) {
        for (int vhpeAgFYnfOnuyUn = 1292920302; vhpeAgFYnfOnuyUn > 0; vhpeAgFYnfOnuyUn--) {
            LePDzbDiW *= SVGCxAbbfPaHLi;
            SjddgzcE /= jxBjU;
            SVGCxAbbfPaHLi = SVGCxAbbfPaHLi;
        }
    }
}

void XfptycGZEEAHAJLd::qhfoWPP()
{
    bool cbkgLumIolYbkx = true;
    bool hDUZu = false;
    int mamEsNaLlLOtu = -1297328935;

    for (int uDFGZNtSKAzNXqE = 3136010; uDFGZNtSKAzNXqE > 0; uDFGZNtSKAzNXqE--) {
        hDUZu = cbkgLumIolYbkx;
        hDUZu = cbkgLumIolYbkx;
    }

    for (int GoeMNuxOmwexndn = 1043355599; GoeMNuxOmwexndn > 0; GoeMNuxOmwexndn--) {
        continue;
    }

    if (cbkgLumIolYbkx != false) {
        for (int RqXNXFTaiw = 1978816158; RqXNXFTaiw > 0; RqXNXFTaiw--) {
            hDUZu = hDUZu;
            cbkgLumIolYbkx = hDUZu;
            hDUZu = hDUZu;
        }
    }
}

int XfptycGZEEAHAJLd::tjySdZFy(int VMqLmRSzJJIHI)
{
    int XlmGcM = -413845581;
    string IcFENkkFQIStZc = string("YuMcxthWtnDXywpQAPlSHMtLAYJphkqJVpetosoABuMkspuTDNLMrGbzPTXnxpXykfAOsusSWemYpxZVxsPUTCxwpOpKfUwFJ");
    int lOkYMC = -25244016;

    for (int LmUmYqjIOYHXv = 788995840; LmUmYqjIOYHXv > 0; LmUmYqjIOYHXv--) {
        XlmGcM *= lOkYMC;
        VMqLmRSzJJIHI /= lOkYMC;
    }

    return lOkYMC;
}

double XfptycGZEEAHAJLd::GNEwM(int rbHBUpGDihNt)
{
    bool HHVNbbvJzBJqvguX = false;
    bool fZFSNcRXbCQy = true;
    string yKfPyK = string("HeCkXDbHhzeYjTUfGTCsRCYWUwLtHzeqicIaMmjmdxSrLoIpRPTiLVmhBSPChROLpytVxEmGasGzLuVWbUsiZRFFsePFFDUrHYzhoRwqPCXFOutPyZDWkVxNmzeYGxdTLqabUEKIdAUZZnkXbYCcpOvivHmhCnzCOEPKyLlLmwdaDDSwMAdGxcT");
    string FIRwFQwieG = string("FUvzbUUjTpFXWsjMdFYFdPwKqzJzdRcXlDDSVHIyzPgijNqHiGLqEAPXfbKwZkWrokUFnIYfGhmbjQhrURzueVcSJbyueviWsgkEONLYytrVgMmk");
    double RUwAXrMaFDsCbmxT = -790599.1084522082;
    int wYuGA = 1953755480;
    string PGTFO = string("VjAoZQOnGVnoMbJzXHeJRajewECIFMXhuTQTgxKXJNsTjhBOzYTVxAHWYfikDzGNGqXfLyXPHmzvnvKmXmzCDFRjeWq");
    string ygQIDS = string("qcrGeeTZLIWwppBLmQBgKhspwFRstkKugSwgUTUmXbPBHAkDAYtHjtxuXqzVlGFbkZbOeuyYdUtxlJXFsgoVyOHcNXLiYcXnoXnuwmAslDFynuNWkmlOpYwFJhxxtJLCHxWSXaEfTKLuMwCQZQhDFCWUWpTjQYCNXsYVTWojVRZykLZWjdYVcqzoCRSIxyZDKWfigpQCHjUSaIahMDrqiHBRwWqNiliRcHveznNFEkjtQdSwvdOupTs");
    bool QDFElEp = false;
    int vIyAnzkKDWE = 533487316;

    if (FIRwFQwieG != string("VjAoZQOnGVnoMbJzXHeJRajewECIFMXhuTQTgxKXJNsTjhBOzYTVxAHWYfikDzGNGqXfLyXPHmzvnvKmXmzCDFRjeWq")) {
        for (int oGKdtjtZxrHltvzD = 821964230; oGKdtjtZxrHltvzD > 0; oGKdtjtZxrHltvzD--) {
            continue;
        }
    }

    for (int kDGHlwsWhARSMFk = 114524035; kDGHlwsWhARSMFk > 0; kDGHlwsWhARSMFk--) {
        continue;
    }

    for (int ceilXCcZAk = 1990045704; ceilXCcZAk > 0; ceilXCcZAk--) {
        continue;
    }

    return RUwAXrMaFDsCbmxT;
}

string XfptycGZEEAHAJLd::PpoRQ(int oSFvLDKJuCn, bool oSgJiIfBMeDnCfk, bool dJJARmiw)
{
    string pkwiwBErdg = string("KedLSvztlOlwGIaHVUxLyVdGRKCTttejgkuroyZRTWfPwVBoBZBpKellBDjouyfRZpEWGgBszZgpLDXAMErakvzSdkLDpYmXlDzTjbs");
    double aTLsjMrQlVNXRxi = -766780.3118349463;
    int lvkTlCGx = -850235121;

    for (int YLpRntUNV = 260526875; YLpRntUNV > 0; YLpRntUNV--) {
        oSgJiIfBMeDnCfk = ! dJJARmiw;
        dJJARmiw = ! dJJARmiw;
        oSgJiIfBMeDnCfk = oSgJiIfBMeDnCfk;
    }

    for (int DDXnm = 680407861; DDXnm > 0; DDXnm--) {
        continue;
    }

    for (int FctOPn = 193798579; FctOPn > 0; FctOPn--) {
        oSgJiIfBMeDnCfk = ! oSgJiIfBMeDnCfk;
        oSgJiIfBMeDnCfk = ! dJJARmiw;
    }

    return pkwiwBErdg;
}

double XfptycGZEEAHAJLd::ZVDRGWBlTaIdws(int WrhhBngFauUY, string Qieci, double suvkphRKvaxD, bool UhPQgPEVsXy)
{
    bool KfxmQzzpDUCC = true;
    int RNdFpoRjv = -175135373;
    bool DcqSjmwuvjC = true;
    bool NhpkGWCxHwQFcM = false;
    bool VvKpDWrpLJijJL = true;
    string XcJipKcCEnSGUtur = string("ttfADrVYthosEHrnMCdfpSyasYVyiBHPUUCwUvImYxeULd");
    bool zUrNXbIA = false;
    bool sJZJEbATQjp = true;
    int UyDzURsn = 1038221196;
    double zDGuDobzyfSQhJz = -557168.550188555;

    if (KfxmQzzpDUCC != false) {
        for (int yTLETKLivog = 1296931749; yTLETKLivog > 0; yTLETKLivog--) {
            UhPQgPEVsXy = KfxmQzzpDUCC;
        }
    }

    for (int pXAUiaAtoHJDBam = 1479577296; pXAUiaAtoHJDBam > 0; pXAUiaAtoHJDBam--) {
        NhpkGWCxHwQFcM = DcqSjmwuvjC;
        DcqSjmwuvjC = ! KfxmQzzpDUCC;
    }

    return zDGuDobzyfSQhJz;
}

double XfptycGZEEAHAJLd::QcsOZUnGu(string elNZxNzxQALsPqUt)
{
    string tvFaPwxVPTOu = string("leVKYJMtYENTfXGfGHwJEOSthAMSsVBfDMuCTNndTNUxCcWnaVxlruwGFGzNaKxGWbUrXrAodLSylajKSkahmzAlZIhwbnUOXejQUSnmXxFEcuWBIHtClABNtgeQJgbEOERIuEbjwDNMPyaaVAdHnuKZklgWEHwGMrWVthKeMajmWiXroaqjOmXClmocSeWPyHkU");
    double JhJuoxu = 483948.7012791223;
    string OsRwIAYpwcRzFu = string("hJIrcIeKkCpOKKGEYPtnnMWZNFKvluOtoCacxwNvIyKpnYrILZhDGdYibaSDtIPunHdffE");
    bool PisbsuJPNvmaCS = true;
    double UquikPodEI = -836651.9524675533;
    bool PsQydYYBNS = false;
    double PhGLoirFY = 698076.7853191996;
    bool SDvMBlaLQbfX = true;
    bool OKQnYwNaFsW = false;

    for (int FbcpYhlqMYgQBIG = 1016904714; FbcpYhlqMYgQBIG > 0; FbcpYhlqMYgQBIG--) {
        elNZxNzxQALsPqUt = tvFaPwxVPTOu;
        OsRwIAYpwcRzFu += elNZxNzxQALsPqUt;
    }

    if (PisbsuJPNvmaCS == true) {
        for (int HvinFZwB = 1981068753; HvinFZwB > 0; HvinFZwB--) {
            continue;
        }
    }

    for (int yGpzETNKU = 178349966; yGpzETNKU > 0; yGpzETNKU--) {
        SDvMBlaLQbfX = ! SDvMBlaLQbfX;
        PsQydYYBNS = ! PsQydYYBNS;
        PsQydYYBNS = ! SDvMBlaLQbfX;
        SDvMBlaLQbfX = OKQnYwNaFsW;
        OsRwIAYpwcRzFu = tvFaPwxVPTOu;
        PisbsuJPNvmaCS = OKQnYwNaFsW;
    }

    for (int VoxGzLaq = 639887133; VoxGzLaq > 0; VoxGzLaq--) {
        continue;
    }

    return PhGLoirFY;
}

double XfptycGZEEAHAJLd::vTVjdSmbxO(bool KXMxTFMBxxdtHSq)
{
    int NFFICJNzrzrvGKdc = 1616713377;
    double hELivhulLvWd = -159351.34255588512;
    bool pvuZUAhf = false;
    int wttUVzggYxn = 1995744448;

    for (int vEUIazrwDXnXTSi = 795959768; vEUIazrwDXnXTSi > 0; vEUIazrwDXnXTSi--) {
        KXMxTFMBxxdtHSq = ! KXMxTFMBxxdtHSq;
        NFFICJNzrzrvGKdc *= wttUVzggYxn;
        pvuZUAhf = KXMxTFMBxxdtHSq;
    }

    if (hELivhulLvWd <= -159351.34255588512) {
        for (int VgzNjVpEzgMnRUVd = 1966379863; VgzNjVpEzgMnRUVd > 0; VgzNjVpEzgMnRUVd--) {
            KXMxTFMBxxdtHSq = KXMxTFMBxxdtHSq;
            wttUVzggYxn -= wttUVzggYxn;
            pvuZUAhf = KXMxTFMBxxdtHSq;
            KXMxTFMBxxdtHSq = KXMxTFMBxxdtHSq;
        }
    }

    if (NFFICJNzrzrvGKdc < 1616713377) {
        for (int omRCXymzV = 1272290981; omRCXymzV > 0; omRCXymzV--) {
            pvuZUAhf = KXMxTFMBxxdtHSq;
            KXMxTFMBxxdtHSq = ! pvuZUAhf;
        }
    }

    for (int jelQBPRoEENExH = 661055018; jelQBPRoEENExH > 0; jelQBPRoEENExH--) {
        KXMxTFMBxxdtHSq = ! pvuZUAhf;
    }

    for (int CGkToxCyRNVqe = 1096220536; CGkToxCyRNVqe > 0; CGkToxCyRNVqe--) {
        continue;
    }

    for (int XtxktZqWKaQhxc = 1937840706; XtxktZqWKaQhxc > 0; XtxktZqWKaQhxc--) {
        pvuZUAhf = ! KXMxTFMBxxdtHSq;
    }

    return hELivhulLvWd;
}

bool XfptycGZEEAHAJLd::fafjkpqYLIbkrEBt(double apZAWIMrsJtzlPn, string bZOiujtrQOcBX, string TWVcIxqzM)
{
    double NywSpcdxqq = -1016689.2221223343;
    string tpDLQ = string("TNZWkNtPpRtIVThnCRUOXWbzEnkpTVIAmvFtLtOCYPxFfpBjjzRkfOltFwhUTsiwsrRasqHdVSWpChWciQZqkyLQWaVyFRxlZuANRMcvHYycuxUmQkDSkalJWjdNCHekeYWbYrqMSopmUPKTWPHbsQzmDmRawwKERWZAOfufiNYLDXxDDGYMpRfMqHjbvDfUwoAftQKJHrUYTqRGGDOJdygNoHYVbxewqzjyFkTVlLScDKeVNZroUnG");
    bool JYfrKaGaB = false;
    bool aJErp = true;
    string YsWfQtOUakyvcEFd = string("xxRefoJuqrOQtSMKuVpBMCcoDnwcbeodAQkCLLIKkVTfkvsXksYvtIyNsdXyZrfrFsTwQaFbqxgLOKMjSAOBEfLsPRgabXJHGLwXGaMHJPxbqwRVPrwlFAvqDONwNgMFsPJTcpQKSIKAjnFvjfDagvCtvemmafMEGZOnRtUaVFhvasTyqDaPItLfZJRkEEqrnnqICuWfdokSfRLObmyJxfuDrfRQoRAur");

    for (int czLFhvJaJVaM = 232911640; czLFhvJaJVaM > 0; czLFhvJaJVaM--) {
        continue;
    }

    for (int pGJJjU = 1692641029; pGJJjU > 0; pGJJjU--) {
        TWVcIxqzM = tpDLQ;
        NywSpcdxqq -= apZAWIMrsJtzlPn;
    }

    for (int aDUsDxSdrCcvjQ = 1413554560; aDUsDxSdrCcvjQ > 0; aDUsDxSdrCcvjQ--) {
        tpDLQ = TWVcIxqzM;
        TWVcIxqzM += YsWfQtOUakyvcEFd;
        bZOiujtrQOcBX += TWVcIxqzM;
        aJErp = JYfrKaGaB;
    }

    return aJErp;
}

double XfptycGZEEAHAJLd::UKRwUhlvt()
{
    int qNkgnBvI = -1843975085;
    double fwRvfM = 581148.0084327168;
    string pzyUAjVHDjzmNxme = string("OSNiYfzQANKbAnwBUAcvZJLCLaSnEVvzgGQabNfsToQlcODojOiqwhPLHwkek");
    string FRdgcoJld = string("jkeisiMQZRgwGCHbdbqchtSgiSOwqwOvZdmBZQRNqLXHcFnHHKpwXTvadoaIsiDMZIXdRBpEJDLMbwenrmgMKPlqxWNFgcxibfQ");
    bool FGVMcdgbdQkH = true;
    string mDrfx = string("akVRWyCDNCVIZfdIFg");
    bool ZiZQqRxRWpe = false;
    string XMfPfHR = string("SHBhkmvQLMGHVhLZdnmzOogxpwkMQKeIhjlXUhSPAqvEylxNGnPxhRGFsosAAGdkePJGNeeAUtTMCQyHVdLFHVHxIxsjPrLhYZAbuurPJzqJSUMBAWrGuDGJGMHaYTp");
    string GswzZhfj = string("sqqvDNfntkovyAsxBRUnUisXnsIsChiNmiTOKlHkSliHGlgRSjRpwnnXiOAdnBSgVuzZQHwSnLwvojHGYdVMFPlYnWIDMUDYjuykJCpHXridvTErmHbmuhepXrnxPSIELWNTCKnRnoDvBDIhobFLaVdDuzMcwCUnvFIlDDqqftvPHbmeiZfmjeKaYhmzTWbjWmeroFjoHHhYuBUhakhAqCXOouichDbdnLXaPaKHYLeTo");

    for (int vqKCXVvl = 1066494551; vqKCXVvl > 0; vqKCXVvl--) {
        XMfPfHR = XMfPfHR;
        pzyUAjVHDjzmNxme += GswzZhfj;
    }

    if (mDrfx > string("akVRWyCDNCVIZfdIFg")) {
        for (int wwMAz = 996088620; wwMAz > 0; wwMAz--) {
            qNkgnBvI -= qNkgnBvI;
        }
    }

    for (int EozWTOwckmU = 1714490946; EozWTOwckmU > 0; EozWTOwckmU--) {
        continue;
    }

    if (FRdgcoJld < string("akVRWyCDNCVIZfdIFg")) {
        for (int hpNDBdyni = 942111739; hpNDBdyni > 0; hpNDBdyni--) {
            continue;
        }
    }

    return fwRvfM;
}

XfptycGZEEAHAJLd::XfptycGZEEAHAJLd()
{
    this->wuyglkTtun();
    this->JPneHzGpTDDLm();
    this->qhfoWPP();
    this->tjySdZFy(1044688767);
    this->GNEwM(-897175920);
    this->PpoRQ(-1307993784, true, false);
    this->ZVDRGWBlTaIdws(-1050055349, string("yRXCJkhrRPTLwPWvshEFiUCtuptzBepvkWzONHWQLOBHgfdhoTfoofbzwormgVMwLanpGmsUhDcJblFnjiBNNGNEmPbPjPBGMpJLHsbZSeRZkVnaogmUQKmNzBXAgPZLmFmJvCUhNsSyCAnOJuCZoEcKtyuWaCqScvACpcjMPTXXXfWIkMNcJBgNrXdJhyOasSsshSrNpMAQMgpIpC"), -22312.50775668189, false);
    this->QcsOZUnGu(string("DKVPjNTmvErgEurAwThLMWbJBRWvcVLYZoFyvOMjuGCXhNqnkIYyUrFnKVwYFKltHnlFMtdSnTMEPAfoKvssuCiXIQlvRZphIfqHlsdfEIucBlQSRnYHoWxvjJBowFygBCQolMYyGtAEeBEdnXDAstaUhwKCCFekAgEZNuqmethIbqKuY"));
    this->vTVjdSmbxO(true);
    this->fafjkpqYLIbkrEBt(-195081.53743785765, string("ZWbsFAMIqFqdVBqkcqSnoMTHcrjyxuKgPyTTbwvTTchMXsapvOjunPwlgWupxVujzfHrOKCvQBQIReDVBZOtKrILICVfSowuwfAGoHiIHNjslktVExBeKBqgmeHmxaPKfnbmnnjkBFvbqCMesXrmWCntECRKavMcyEdHEhPJenkANfYICyCRxykwsJhBnzgSvvvc"), string("uGEKzNduvYxXRzMzaSLlSxZoqauyJXdfyIyjcQLTAXWZWudtgpcPUnupxCOziheMLUzEiOyIKmpFmQraRvinUEpzeafLnIacQPPztoWGZKix"));
    this->UKRwUhlvt();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SajVbaz
{
public:
    double xsqbBec;
    bool dKviHYxDLVVXIUw;
    string UZEaCzYDN;

    SajVbaz();
protected:
    string ymWYSfdbfZMFUQx;
    int sTFDTPCKzuSFk;
    int PoSrVxMgwuAJuzqA;
    double rfGcHKkZORJ;
    bool wAqVyrV;

    string fZnVdbWVnvkiE(int fXjYybVUMEwNOe, string JDUGDgQjwKZ, string eOVALCZTVDIImw, int hOgrpvELL);
    void SSinlC(string SUOBAJEujaEaoUyY, string KhLwUGlysFJquHve, double IWQcuxwr, bool NWrROcfX);
    void IEQGIXUR();
    void QrxmrFZG(double YwuzdvsQA, string QgAQBEzHbTgXOZUe, bool ahxGnTI, int xXJfepmdcvcwEwf, string kQHLHDdLjZbA);
    bool uqaslzVG(bool jpwggiLFZufkmRf, double zYkkEUsGHcfs, int YNsWmzmjUBrprHVY, string fckcuxpF);
private:
    string vlMOwgPCKPkPwb;
    string BEqWDhMsaqW;
    int tCsnxqk;
    int EDTtSOObPhBYeSSx;

    bool LrhZz(string QXueZVQ, string wbsxeQsjXbtz);
    double aGcLRpCvfcjWAq();
    bool RIuPV(int KpxbbQgbKeGNJJA, double OyhKxKHWaN, bool utwGT);
    int DWJQOgjqp(string dYpiLpGafmtA, string ZnYCmXKcWqFPj, bool gpkdhpFW);
    string QZhoCHbElFFFS();
    bool zNTOlPtgaE(bool kAuqQzRgm, bool lpQMyPTbJpZBlvcL, double QiRzsDiRvxuFDu);
    int AGrEMUPgCju();
    int jsDlIiFSR(double aYTbF, double qAWJqx, int LgVENfKDIR, bool EsPEAGLhb);
};

string SajVbaz::fZnVdbWVnvkiE(int fXjYybVUMEwNOe, string JDUGDgQjwKZ, string eOVALCZTVDIImw, int hOgrpvELL)
{
    bool ZSPcSLKS = true;
    double NjMTxFkCYhgxgK = -478488.3908501543;
    bool kKPQroaRuPU = true;
    string zMRoLtJr = string("EbKKPDdtsbLOPmzqoydNaoLkiMiyhCSrfPOGeoWfYeQsoaglFFPSgMXpXZAkERYFUbQorEVziHrOsKRqJrYhgeukehaQTJjBdxAjFnaIzvrLTjARXqnytYoLnlfJpgHUHkIZoxZODTrCGMZPwc");
    string XCJLKQbLH = string("cxBlVeeyzjXJCHdvhRhOIwfjGqCAWxKvBgLDFVzJgAkZOVJGdOEgesxrOZrdRKELbXGiIZZeJUvFdooommUxSmIqSAMJJsRAHMWXXEcSxJmhNfRnMgQVtPvKSRqTjDrnRDXfFqwauTenQlZyk");
    bool ZnPivvVwWZNW = true;
    double lyoLNQMW = -219398.7321379277;
    string eNAcqGR = string("oNeYitAL");
    bool wvhCAn = true;
    bool nwfdccyWRzpsYLDP = false;

    return eNAcqGR;
}

void SajVbaz::SSinlC(string SUOBAJEujaEaoUyY, string KhLwUGlysFJquHve, double IWQcuxwr, bool NWrROcfX)
{
    int AXHoYdsctWDlOEJI = -1689292406;
    double asuWZrM = 160390.39669259422;
    string hqTIBgDrPGLla = string("DAYfZnYODXChajRXBwwrbRCLhOjcMXPshsnuNDlaHnKsOeMPcgxspokoKmSOeFSSVCYAgpzgdDmClYSjqtZgRbkQmtDSjoNKZafuBFwwZtsSsVwnCBxbDVyvbcghXLRlJYYORuzilzvfYPATLDOqftkzbnZTXPry");
    string yRuNKuiJIFoZT = string("ZkmlhHZoYLrvJlEFnQZeNbVpMvYGIowvdABRXaVGuNYZfeFbiynWhWuQeejhbUlJXDbMayTKKQToIZBcPtTGWoIOLaCECdLBLglbVYbqEyBQQppimzSbbSAUOpdJFTpjdFysoHpjtjwlQhLnN");
    bool rKoYghiCENAWSynm = false;
    string hUnAROXFYzV = string("YIxaCDoopUMMyCaDIHOOzrzeeFLgPCwOQLHoSxrlTmxlkZPWqENcyWnxpuEvQWdxLciOLQlEScNnQIfVtTbVorLzhhMmMaVBePwMaoqEoqEiHdKNBPPDohpcHdEedsSpFPuZYlOhSogTKblUHyakUucAkoaCbJJLJMiKCsMQAhIHZiyKOOpvntpXJvPGlUUVbutGkZAARwOpwjJUqnenPXATgCovsNaSgrgeDRgLtrZvQVhxsURJToaypPvFx");
    int VJEzjh = -184767575;
    double fiOzrVhYUdIMhdq = -508638.0323901299;

    for (int uQstqJIrYJzJ = 387039540; uQstqJIrYJzJ > 0; uQstqJIrYJzJ--) {
        fiOzrVhYUdIMhdq += asuWZrM;
        VJEzjh /= AXHoYdsctWDlOEJI;
        AXHoYdsctWDlOEJI /= VJEzjh;
    }

    for (int asLJXC = 1558523282; asLJXC > 0; asLJXC--) {
        yRuNKuiJIFoZT += KhLwUGlysFJquHve;
    }
}

void SajVbaz::IEQGIXUR()
{
    bool ITRuFrKfUpQb = false;
    string lxHHLyzj = string("ps");

    for (int zjvbwKBXLj = 1863584398; zjvbwKBXLj > 0; zjvbwKBXLj--) {
        lxHHLyzj += lxHHLyzj;
        lxHHLyzj += lxHHLyzj;
    }

    if (lxHHLyzj == string("ps")) {
        for (int SjHYuSqqnjLSKM = 1688767398; SjHYuSqqnjLSKM > 0; SjHYuSqqnjLSKM--) {
            lxHHLyzj = lxHHLyzj;
            ITRuFrKfUpQb = ! ITRuFrKfUpQb;
            ITRuFrKfUpQb = ! ITRuFrKfUpQb;
            ITRuFrKfUpQb = ITRuFrKfUpQb;
            lxHHLyzj = lxHHLyzj;
            lxHHLyzj += lxHHLyzj;
        }
    }

    for (int IBbpddhOZTZm = 1561472550; IBbpddhOZTZm > 0; IBbpddhOZTZm--) {
        continue;
    }

    for (int fDgacei = 1416864093; fDgacei > 0; fDgacei--) {
        lxHHLyzj += lxHHLyzj;
        ITRuFrKfUpQb = ITRuFrKfUpQb;
    }

    for (int edizmFBeVpKk = 651327288; edizmFBeVpKk > 0; edizmFBeVpKk--) {
        ITRuFrKfUpQb = ITRuFrKfUpQb;
        ITRuFrKfUpQb = ! ITRuFrKfUpQb;
        lxHHLyzj += lxHHLyzj;
        lxHHLyzj = lxHHLyzj;
        ITRuFrKfUpQb = ! ITRuFrKfUpQb;
    }

    for (int nkKgGwtebmRHph = 259826168; nkKgGwtebmRHph > 0; nkKgGwtebmRHph--) {
        ITRuFrKfUpQb = ! ITRuFrKfUpQb;
        ITRuFrKfUpQb = ITRuFrKfUpQb;
        ITRuFrKfUpQb = ITRuFrKfUpQb;
        lxHHLyzj = lxHHLyzj;
        lxHHLyzj += lxHHLyzj;
    }

    for (int TsPPflMqqQMf = 29800766; TsPPflMqqQMf > 0; TsPPflMqqQMf--) {
        lxHHLyzj += lxHHLyzj;
        ITRuFrKfUpQb = ! ITRuFrKfUpQb;
        ITRuFrKfUpQb = ITRuFrKfUpQb;
    }
}

void SajVbaz::QrxmrFZG(double YwuzdvsQA, string QgAQBEzHbTgXOZUe, bool ahxGnTI, int xXJfepmdcvcwEwf, string kQHLHDdLjZbA)
{
    bool mzNVWQcWTFpIXKnh = false;
    double KeELBVgBiliGAQYT = -482040.9132447366;
    double IqVfAyymKa = 967909.6417075578;
    string LRwVVXp = string("QqmpQBKCxBAzTur");
    bool jOslYKaHwUXDfJP = false;
    string ljUilnLCXzm = string("MWtShLRXKabGwUntCQPMQuBYnEYnCjUVd");
    bool QURpke = true;

    for (int KuPqhXiQe = 976543558; KuPqhXiQe > 0; KuPqhXiQe--) {
        kQHLHDdLjZbA = ljUilnLCXzm;
    }

    if (mzNVWQcWTFpIXKnh != false) {
        for (int sYSJky = 538520709; sYSJky > 0; sYSJky--) {
            KeELBVgBiliGAQYT += IqVfAyymKa;
        }
    }

    for (int kqGRPxTCu = 1705012719; kqGRPxTCu > 0; kqGRPxTCu--) {
        continue;
    }
}

bool SajVbaz::uqaslzVG(bool jpwggiLFZufkmRf, double zYkkEUsGHcfs, int YNsWmzmjUBrprHVY, string fckcuxpF)
{
    bool tvAXbJG = false;
    string vLkLaGSopGEtsq = string("ghnRsMoBtRZnxgwmbTAibGjSPOIdMlYUxIPtoKYPqLbaZXjyVaMFOoBozLSfwCPhstFpHxklrGwrumUCQgLavjKLSNykNJimJMwvxZQOcujirVKaqRxJJHzRpEWhbmlZoVGUWAvmMBPCRSgsckthHLpNroxHyqhEZxYXzPBibBing");
    int BCWQXCSDwRk = -51031377;

    if (vLkLaGSopGEtsq < string("ghnRsMoBtRZnxgwmbTAibGjSPOIdMlYUxIPtoKYPqLbaZXjyVaMFOoBozLSfwCPhstFpHxklrGwrumUCQgLavjKLSNykNJimJMwvxZQOcujirVKaqRxJJHzRpEWhbmlZoVGUWAvmMBPCRSgsckthHLpNroxHyqhEZxYXzPBibBing")) {
        for (int YIFEAdkvrY = 1995444455; YIFEAdkvrY > 0; YIFEAdkvrY--) {
            vLkLaGSopGEtsq = fckcuxpF;
        }
    }

    for (int VEjfmMAN = 530939714; VEjfmMAN > 0; VEjfmMAN--) {
        jpwggiLFZufkmRf = ! tvAXbJG;
        BCWQXCSDwRk -= BCWQXCSDwRk;
    }

    return tvAXbJG;
}

bool SajVbaz::LrhZz(string QXueZVQ, string wbsxeQsjXbtz)
{
    bool ibJIYlGak = false;
    int fayFwo = -839903106;
    double XWbVDKtwdF = 69621.7767796636;
    double KmDNvPeYySDB = 733350.9401208205;
    double vDdWjprllO = 893689.4319352215;
    bool rcJEAPXW = true;
    string JjMFsoLnzugShI = string("NFdRignFaDGZEKZpAfbwogpYCDpKyZxYpWswMjMfCfVyYCeWlUGOBSaaFaPgexZATDLThBpoSimJmxVGkSFhHlZneULOCds");

    for (int EtfnIVSfWilpJmY = 2072202053; EtfnIVSfWilpJmY > 0; EtfnIVSfWilpJmY--) {
        rcJEAPXW = ibJIYlGak;
        JjMFsoLnzugShI += QXueZVQ;
    }

    return rcJEAPXW;
}

double SajVbaz::aGcLRpCvfcjWAq()
{
    bool BxRpXTbFDaOYblfQ = false;
    string tmdGGMKAgXB = string("FIQLtHahDdisuGmgDIqThlWSfEUT");
    double ecuWoJsUzTrGjOe = 233277.53647781478;
    bool WcieounQsEnA = true;
    bool SOlQPbFmEZIs = true;

    if (WcieounQsEnA != false) {
        for (int gJfVMiqk = 1808613937; gJfVMiqk > 0; gJfVMiqk--) {
            ecuWoJsUzTrGjOe -= ecuWoJsUzTrGjOe;
        }
    }

    if (WcieounQsEnA == true) {
        for (int osmBbKKNUf = 633886360; osmBbKKNUf > 0; osmBbKKNUf--) {
            continue;
        }
    }

    if (WcieounQsEnA != false) {
        for (int PTvUhBjNzxefQtYp = 499690489; PTvUhBjNzxefQtYp > 0; PTvUhBjNzxefQtYp--) {
            WcieounQsEnA = WcieounQsEnA;
            SOlQPbFmEZIs = ! WcieounQsEnA;
            SOlQPbFmEZIs = ! WcieounQsEnA;
        }
    }

    return ecuWoJsUzTrGjOe;
}

bool SajVbaz::RIuPV(int KpxbbQgbKeGNJJA, double OyhKxKHWaN, bool utwGT)
{
    int DrlSYBSzlGBcV = 580923637;

    for (int soVdPHJZQ = 938734504; soVdPHJZQ > 0; soVdPHJZQ--) {
        DrlSYBSzlGBcV *= DrlSYBSzlGBcV;
    }

    for (int dWjsdHCFFx = 263135688; dWjsdHCFFx > 0; dWjsdHCFFx--) {
        KpxbbQgbKeGNJJA += KpxbbQgbKeGNJJA;
    }

    for (int LLecnCCAHYwaa = 1125044370; LLecnCCAHYwaa > 0; LLecnCCAHYwaa--) {
        OyhKxKHWaN += OyhKxKHWaN;
        KpxbbQgbKeGNJJA /= DrlSYBSzlGBcV;
    }

    for (int rzNlTxamuOi = 2023628999; rzNlTxamuOi > 0; rzNlTxamuOi--) {
        utwGT = utwGT;
        OyhKxKHWaN *= OyhKxKHWaN;
        DrlSYBSzlGBcV -= DrlSYBSzlGBcV;
    }

    return utwGT;
}

int SajVbaz::DWJQOgjqp(string dYpiLpGafmtA, string ZnYCmXKcWqFPj, bool gpkdhpFW)
{
    string zncywDEvvCi = string("cSZiBOjHFyBfiNrDEuvxODMvUsMeUiokjNoFWiQTnkPOwEcqRAXkPsOktoKRtKyiYvUMcinMQnvOOlYNdbnErwQLnwLQFGGeZmxgCkeJBDpmloYvYdWUdFAQGiZntablJnknxJowgsMIwFeifhELtLZagxFDvvCZHCrbnoutsZPuavpPwBlkTSMahwUyQQafofDWfebyBzudYyGLKmPGZiEozOVMaRMxOmyDjEMdFwLJUulFOJXZybwwifOEKOu");
    bool bsWIi = true;
    double fqLXGVp = -327677.19219124346;
    string wKVZdBQAJL = string("EJkFEsWkPCOENHZDqwBZziIMKCDiDlYZQycsxTFZJyQ");
    string SvxFzOAKlyh = string("pdmfxTTxZJOgweHaCrhGyfeFKUusdZDWcwPmqYUfpOqhfsajHKozLoCiKCEZuuBFllaKRVvYvjPnAAhIQayfDdqwbrlwpmvNYDOGcsrFUgtxQniIIJpNJsPahLDlsI");
    bool RsdoRSJDdvKGJr = true;

    if (zncywDEvvCi == string("OzNuMOHnLF")) {
        for (int xUiZcykWUEJLX = 2111912006; xUiZcykWUEJLX > 0; xUiZcykWUEJLX--) {
            SvxFzOAKlyh = wKVZdBQAJL;
            gpkdhpFW = ! bsWIi;
        }
    }

    if (gpkdhpFW != true) {
        for (int XTmqKMptKhnT = 1917491774; XTmqKMptKhnT > 0; XTmqKMptKhnT--) {
            fqLXGVp += fqLXGVp;
            dYpiLpGafmtA = ZnYCmXKcWqFPj;
        }
    }

    for (int rWUHoJn = 940139746; rWUHoJn > 0; rWUHoJn--) {
        fqLXGVp *= fqLXGVp;
    }

    return 1596711327;
}

string SajVbaz::QZhoCHbElFFFS()
{
    double dJAgT = 688366.7019184087;
    bool kDJffGSTFQbQekZ = false;
    bool FndXdkRySiu = true;

    if (kDJffGSTFQbQekZ != true) {
        for (int LlLJqLf = 2096792905; LlLJqLf > 0; LlLJqLf--) {
            kDJffGSTFQbQekZ = ! FndXdkRySiu;
            dJAgT = dJAgT;
        }
    }

    if (kDJffGSTFQbQekZ == true) {
        for (int edoTbPwLlnA = 606072169; edoTbPwLlnA > 0; edoTbPwLlnA--) {
            FndXdkRySiu = FndXdkRySiu;
            dJAgT += dJAgT;
            kDJffGSTFQbQekZ = ! FndXdkRySiu;
            FndXdkRySiu = ! FndXdkRySiu;
            FndXdkRySiu = ! kDJffGSTFQbQekZ;
        }
    }

    if (dJAgT == 688366.7019184087) {
        for (int PpDncmYNW = 1202417157; PpDncmYNW > 0; PpDncmYNW--) {
            dJAgT += dJAgT;
            FndXdkRySiu = FndXdkRySiu;
            FndXdkRySiu = FndXdkRySiu;
        }
    }

    return string("rPRPsioqffUDBVQYpefdbqWWrOwSGHgSLbTmCHBSzJWtAHWGOHHnnNFifFMCSazJPROBrAyWAfSGfRizvwGGRHLdEGskcIAXojWewKXAIMBonTEFgiuBwWXMYfaKbKBGRLZTnHhdqehHEgqetEuya");
}

bool SajVbaz::zNTOlPtgaE(bool kAuqQzRgm, bool lpQMyPTbJpZBlvcL, double QiRzsDiRvxuFDu)
{
    bool fAahrxmjNhDaRQqj = true;
    int xfVrrFLcVOL = 5971426;
    double jrNuLxawxnWogqYi = -588663.5839423166;
    int MrLKMFCvqai = -470989603;
    string PQsvUKRoatQOT = string("kGPzygpOrCQLfgBxkEgRTCwFGxiiuuNaZHiycddZBqWorUxSiUREdwdlsDVHNjbhLbsrefPytGMklHxnDVauoZrrXN");
    double OaLcbFZcmJHph = -742978.3716560788;
    int MekiCmqhbAXojMJh = 428291267;
    bool daFSMi = true;
    int UfxdodMKdq = 1185838725;

    for (int XuLsDZEIDZuAB = 736258394; XuLsDZEIDZuAB > 0; XuLsDZEIDZuAB--) {
        MrLKMFCvqai = xfVrrFLcVOL;
        xfVrrFLcVOL += xfVrrFLcVOL;
    }

    for (int dIZHM = 1356869134; dIZHM > 0; dIZHM--) {
        MekiCmqhbAXojMJh = xfVrrFLcVOL;
        lpQMyPTbJpZBlvcL = ! fAahrxmjNhDaRQqj;
        xfVrrFLcVOL *= xfVrrFLcVOL;
    }

    return daFSMi;
}

int SajVbaz::AGrEMUPgCju()
{
    string EQKmIZ = string("maQFPFipXFvHCfQWVZrQcQnLGrEPQpMJSJVZqTSxLTQGuloLARufGwjUFAlNYUkLEwEIbiyGoNzPBIGUEkpNdQlukXcEdalSIhBTfHhasSySQBoraDCLvRrQUCuUvphcxdgHKhESNdxFDGVIGUmkRdIDioCoCizvKJkOcqpdxuIeDZyUcjCBpzalwxBtHMifynSukfGPaWXu");
    bool gRQvNcdwiIKBDNv = false;
    string KhmtOdLSEDitKT = string("TdYcfqexDPBcBawTcbOg");

    if (gRQvNcdwiIKBDNv != false) {
        for (int XzTdQRlw = 1369951549; XzTdQRlw > 0; XzTdQRlw--) {
            KhmtOdLSEDitKT = KhmtOdLSEDitKT;
            gRQvNcdwiIKBDNv = ! gRQvNcdwiIKBDNv;
            EQKmIZ += EQKmIZ;
            KhmtOdLSEDitKT = EQKmIZ;
        }
    }

    if (KhmtOdLSEDitKT != string("maQFPFipXFvHCfQWVZrQcQnLGrEPQpMJSJVZqTSxLTQGuloLARufGwjUFAlNYUkLEwEIbiyGoNzPBIGUEkpNdQlukXcEdalSIhBTfHhasSySQBoraDCLvRrQUCuUvphcxdgHKhESNdxFDGVIGUmkRdIDioCoCizvKJkOcqpdxuIeDZyUcjCBpzalwxBtHMifynSukfGPaWXu")) {
        for (int qquElgcrSub = 558998029; qquElgcrSub > 0; qquElgcrSub--) {
            EQKmIZ += EQKmIZ;
            EQKmIZ = EQKmIZ;
            gRQvNcdwiIKBDNv = gRQvNcdwiIKBDNv;
        }
    }

    if (EQKmIZ <= string("TdYcfqexDPBcBawTcbOg")) {
        for (int JmLNYCVPSzCxWgdi = 1010901235; JmLNYCVPSzCxWgdi > 0; JmLNYCVPSzCxWgdi--) {
            KhmtOdLSEDitKT = KhmtOdLSEDitKT;
            EQKmIZ += EQKmIZ;
            KhmtOdLSEDitKT += EQKmIZ;
        }
    }

    if (EQKmIZ > string("TdYcfqexDPBcBawTcbOg")) {
        for (int vRCTST = 186420918; vRCTST > 0; vRCTST--) {
            KhmtOdLSEDitKT = EQKmIZ;
            EQKmIZ += EQKmIZ;
            gRQvNcdwiIKBDNv = ! gRQvNcdwiIKBDNv;
            EQKmIZ += KhmtOdLSEDitKT;
            EQKmIZ += EQKmIZ;
            EQKmIZ = EQKmIZ;
        }
    }

    for (int hktrZEOraXyzobbW = 424420490; hktrZEOraXyzobbW > 0; hktrZEOraXyzobbW--) {
        EQKmIZ += KhmtOdLSEDitKT;
        EQKmIZ = KhmtOdLSEDitKT;
        KhmtOdLSEDitKT += KhmtOdLSEDitKT;
    }

    if (EQKmIZ != string("maQFPFipXFvHCfQWVZrQcQnLGrEPQpMJSJVZqTSxLTQGuloLARufGwjUFAlNYUkLEwEIbiyGoNzPBIGUEkpNdQlukXcEdalSIhBTfHhasSySQBoraDCLvRrQUCuUvphcxdgHKhESNdxFDGVIGUmkRdIDioCoCizvKJkOcqpdxuIeDZyUcjCBpzalwxBtHMifynSukfGPaWXu")) {
        for (int bvrcrNKXwDzIVm = 1339281579; bvrcrNKXwDzIVm > 0; bvrcrNKXwDzIVm--) {
            gRQvNcdwiIKBDNv = gRQvNcdwiIKBDNv;
            EQKmIZ += KhmtOdLSEDitKT;
            KhmtOdLSEDitKT = KhmtOdLSEDitKT;
            EQKmIZ += KhmtOdLSEDitKT;
            KhmtOdLSEDitKT += KhmtOdLSEDitKT;
        }
    }

    if (KhmtOdLSEDitKT <= string("TdYcfqexDPBcBawTcbOg")) {
        for (int jtsBrG = 1817082958; jtsBrG > 0; jtsBrG--) {
            gRQvNcdwiIKBDNv = ! gRQvNcdwiIKBDNv;
            EQKmIZ += EQKmIZ;
            EQKmIZ += KhmtOdLSEDitKT;
        }
    }

    return -1135196653;
}

int SajVbaz::jsDlIiFSR(double aYTbF, double qAWJqx, int LgVENfKDIR, bool EsPEAGLhb)
{
    double bMBaZwiRCJTmu = -578834.0043883265;
    string eWDnGVIVpgljutKC = string("nykdj");

    for (int fhGMmQQjuwXMc = 362574662; fhGMmQQjuwXMc > 0; fhGMmQQjuwXMc--) {
        bMBaZwiRCJTmu += qAWJqx;
    }

    for (int RqJMwIJBkCxFBfDL = 560927010; RqJMwIJBkCxFBfDL > 0; RqJMwIJBkCxFBfDL--) {
        aYTbF *= qAWJqx;
        bMBaZwiRCJTmu -= qAWJqx;
    }

    for (int JQQUvYRiaxMOcz = 997859447; JQQUvYRiaxMOcz > 0; JQQUvYRiaxMOcz--) {
        continue;
    }

    return LgVENfKDIR;
}

SajVbaz::SajVbaz()
{
    this->fZnVdbWVnvkiE(1678914800, string("vYPeDBhbnjfAckCRytmFesQAVKqCdnZxDXWaJUWlcbytrhyTOEJoWSdGCFohmcwrxMShsgmANkPijnbisMXqTpFxGpBFWxoBSYUySTXrgpJbdzzuPwcWHCTtgeCEyMSuVSkgYYtaGItfFzUTNWzOQSZLUEnVINhmyoLqCYdptImCHzwOsIfNOJModAhtOSrTGGmcXYHBdesI"), string("wEFWIgfzBNKJLqTKwufWAKSAQzXPlgTkGWtmJigQPJwFTtGymOLhuFOVPNTtHzNgsBRgIzSqXnfWBwqhsVmUDbcRkCvwvsqLUCPmStOHeKGRURzWJfCfSeipmXDYmatyOpBqApWzjfyHJlXYgSiTOCRqigjnfbUzvBvQawOwLhyRDl"), -1949075682);
    this->SSinlC(string("jxzFQKEBVaMMgEgRIeZPSSututNwmGrXXAEhkKGMpQRYpwppSIiWarZxMPijEcKDhxlCVThLPQCOCfGOOjukfIUxaMsbkk"), string("wyWlwltCZCCIgUMcHDSSLSfvIxdnDgezMafKsepgvjZaZUbRoZUnQIxzI"), 791262.7742423814, false);
    this->IEQGIXUR();
    this->QrxmrFZG(-43368.83058616066, string("GtZhlABkHaCrTVYyVSbhfdkYfqwBMSqjulRWxPkrxogaSeRnxoOUVMbYZFWTQNeSraFfNNtWKCSUiBeBYsjkjQChAPWhxMSPSWudBRqOuKnaGvJcJTcUVRebguuDSpAQxbNgpwBTzHlndtpYneVfotiusFrxcMMzuIYqabpsvCIKdEjOVAvMFpumEirUolrnmnJdMTfVudUfFzsFCAjcPVuhsM"), false, -1636596886, string("wMRYmplycIZTkHgkIPfFCJwaUAoaQQsFyfrvYgPHtXaXGiHghlJjeOcIYUbrcOlSdBRKQVbAaySofNlTvJWNTzPerpCLesmQtivYJXrfvKWZCnwuNDtLEBGpEzglayUhXixJcPKhtOEBghhFcmwpSGMoGaNUTyCuBXhvKkoGiwMtHNojZInwNeJMwEfKEPXoxMBwKqYINzlbzdYPMehuGQKrFYWSt"));
    this->uqaslzVG(true, -264320.66556099494, 923878446, string("LFYxbaYQCuCkVKHRxdPuUsFkqjxkrQkjyaxYkgqPEGetaXSWIYuSnmNqHKnxzuBTEGcrbFqBkyawWjnvWlBKCKxXHiKBXHmCXppodoTRGOExtuHGCFeqzlRoVesUtOLThIGFqjOUObfHlfsqFVupxIwWidFuDLfocxPrvQlBSQRRlvanHAAORVdSOXdYwcHHaPDiAdfVOBXPNTKZzMzKzqbbCqTY"));
    this->LrhZz(string("oTUutvTzqnXLUKFpmFafdvmRpuPtJQzVfbLkapzNMXrhJXdDwSGYBORlYxvemZPurqMZdsiHWOZZKyMiPmMKpcofkKMpofFNmMoEPJCdLgvMVjmDYJgQwBmxvrVtDxMjdUMRrtoJnOrPHZgpNwViufBcAJekDjMweuQOJnZcsGCoGqGTZjzHLbrnHRpXglWfCdfAtFLIRFYkSrPxdKFIqksnbLyVxZbsbzXmkGVQhXP"), string("TUfKXsBFFsCgLOtVWTBtTHRdOINPkPAVQdukXZOWVckLVQKXMqpfbKslIkjSlrGYYJdxkuCtNfHGHRQeuQrmngnbbVhjOzN"));
    this->aGcLRpCvfcjWAq();
    this->RIuPV(-553635669, -85424.87950845003, false);
    this->DWJQOgjqp(string("YIQhiKufCvmgKWYOeKhsuTMTWttgeijgMQnHdwurebEJkcBSQsIMpYzWtFHBRwrzmbsUGMwWSWMxfuuvtoYPkYfVMGGqxgaKxlVjyYHvuokSQEuTUBVohamNnbMMFqbBfdZKGGJcLbBwVhXzbrAoeljtdBckpEhflFDQhWGGjijpWRYuNoIpCMAOAjLFacPGPsrhGngcQUrSkojDnfGcySrJHVRusNLqhesEVd"), string("OzNuMOHnLF"), true);
    this->QZhoCHbElFFFS();
    this->zNTOlPtgaE(true, true, 297437.6558163038);
    this->AGrEMUPgCju();
    this->jsDlIiFSR(-351985.4671226341, 853192.0628972906, -947600905, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tGulCgVD
{
public:
    string TqnWVbnVEMScuLA;
    double AGODCziWSUrH;

    tGulCgVD();
    double szviIpsLLCN(string yhIykDSmeElg, double UoYFWNcgqoZEMPe);
protected:
    bool VcIdtDFtNlJQ;
    int fZzTP;
    int oyJJrUfYSd;
    string etKDPtc;
    bool yrIefjyhOmWKmk;
    int mMbYb;

    int ykBDrsFc(double kgyHyIbEQsFOKx);
    bool ddrGGGeYRjm(bool tjxrISUkBFRUtHdB, bool SvtFL, double EySOcgtRp);
    void tWVJjHkReFluur(double tPyMdFEUM, string jotMxWdQXpL);
    bool IQtUVfGevioad(string JuoxyAsKnSMyv);
    string icmXLx(bool fdXYFfiAWdDkctQ, string OSjmhQr, double zmALctOPnEGkw);
    int jkmNrcsNMlITs(bool uvxtzOeUWlEIT, double GatuwlAlAlrcH, bool XJIHcndCqMt);
    void zJdHxjfNVB(bool KjLoSmgcZgoRy, bool BcZlpKGYqbXIEKi, bool qFLmXYTvFoNr);
private:
    double zqtBffveAEadOV;
    int zOSgozPMVnDiCTo;
    int PKWTiU;
    double InhnSEpCFKm;
    int cMZcbU;

};

double tGulCgVD::szviIpsLLCN(string yhIykDSmeElg, double UoYFWNcgqoZEMPe)
{
    int qVzLnmLkGnugqtNR = -1267080133;
    bool fezAOwFoW = false;
    string wQvGZj = string("KiYuDWdhntYXcIvnjnVfMJCqLqqJVnwgMjfYNsIrtxxoVucKKKHFincYvPbTimiGDFkEsIYlGmThClxnxnvYgfEXmReFTNxDKjclgtqxDPfAvDiRpchllLhsDAwinYXgwDuAaDaJfdXkGkezsCdsyHzgJD");
    string fyKzprag = string("dFbMYgMmLZmHBaeloFBHepsnPnDJmblUmgNlGUQNszjZiApshlKNWvurWAJnkeAORCEuDziQDkNtoZFqWmXvJHTgJbRGAmmqWCjClRMLalmvVmfKfhhpNfezlpavHBGhfpyKkSrSRUYBfyjDWntbhSPufHhFGGJccdkFArlkJFBdElHyBtphzQJgGrTXFqoVTlBGiypjN");
    string gbEZbKZkXiF = string("RygsPbvXyolPVeHAxbivLDtKbWeVUkjEkwZnJaWYBmuzPTJNIoKuqEzbUodbHkVvALaMAQGZwnHRyYGioENWyfSFwuGmcAYmwGLSusTpQGqiaFwqQylFDChnvVpAeAMVPgnxVcnpeqlEkL");
    bool jFUZZJEKpLa = true;
    string oqQYDqmqwmqjSBG = string("DaPyFzFOvOO");

    if (wQvGZj < string("KiYuDWdhntYXcIvnjnVfMJCqLqqJVnwgMjfYNsIrtxxoVucKKKHFincYvPbTimiGDFkEsIYlGmThClxnxnvYgfEXmReFTNxDKjclgtqxDPfAvDiRpchllLhsDAwinYXgwDuAaDaJfdXkGkezsCdsyHzgJD")) {
        for (int JdyIvpLx = 1387163227; JdyIvpLx > 0; JdyIvpLx--) {
            oqQYDqmqwmqjSBG += yhIykDSmeElg;
            wQvGZj = fyKzprag;
            oqQYDqmqwmqjSBG = yhIykDSmeElg;
        }
    }

    for (int MyTGOhjEzi = 1189797410; MyTGOhjEzi > 0; MyTGOhjEzi--) {
        fyKzprag = oqQYDqmqwmqjSBG;
    }

    if (fyKzprag == string("RygsPbvXyolPVeHAxbivLDtKbWeVUkjEkwZnJaWYBmuzPTJNIoKuqEzbUodbHkVvALaMAQGZwnHRyYGioENWyfSFwuGmcAYmwGLSusTpQGqiaFwqQylFDChnvVpAeAMVPgnxVcnpeqlEkL")) {
        for (int uEsctFvXI = 1090998454; uEsctFvXI > 0; uEsctFvXI--) {
            yhIykDSmeElg += wQvGZj;
            yhIykDSmeElg += yhIykDSmeElg;
            UoYFWNcgqoZEMPe += UoYFWNcgqoZEMPe;
            fezAOwFoW = ! fezAOwFoW;
        }
    }

    for (int nepJOrmIv = 299193806; nepJOrmIv > 0; nepJOrmIv--) {
        fezAOwFoW = ! fezAOwFoW;
        gbEZbKZkXiF = fyKzprag;
        wQvGZj += fyKzprag;
        yhIykDSmeElg += fyKzprag;
    }

    if (gbEZbKZkXiF < string("DaPyFzFOvOO")) {
        for (int cRZeyhknYweKEv = 476401416; cRZeyhknYweKEv > 0; cRZeyhknYweKEv--) {
            yhIykDSmeElg = fyKzprag;
        }
    }

    return UoYFWNcgqoZEMPe;
}

int tGulCgVD::ykBDrsFc(double kgyHyIbEQsFOKx)
{
    double UNcqSGCcJgmx = -281971.81881542684;
    int fydfsXdwiGmCwExJ = 884576838;
    double zufqvnMOORv = 702088.0618565843;
    double wgZOYvtcEi = 91515.86411489685;

    for (int eJlioqvxEpwH = 455749676; eJlioqvxEpwH > 0; eJlioqvxEpwH--) {
        UNcqSGCcJgmx *= kgyHyIbEQsFOKx;
        wgZOYvtcEi = wgZOYvtcEi;
    }

    for (int hQFYSC = 2059022281; hQFYSC > 0; hQFYSC--) {
        kgyHyIbEQsFOKx /= zufqvnMOORv;
        wgZOYvtcEi *= zufqvnMOORv;
        UNcqSGCcJgmx -= wgZOYvtcEi;
        kgyHyIbEQsFOKx = kgyHyIbEQsFOKx;
        wgZOYvtcEi /= wgZOYvtcEi;
        zufqvnMOORv /= wgZOYvtcEi;
    }

    if (fydfsXdwiGmCwExJ > 884576838) {
        for (int zxClbK = 1334396347; zxClbK > 0; zxClbK--) {
            zufqvnMOORv = wgZOYvtcEi;
            UNcqSGCcJgmx /= wgZOYvtcEi;
            zufqvnMOORv *= UNcqSGCcJgmx;
        }
    }

    if (wgZOYvtcEi >= -281971.81881542684) {
        for (int TpCXpbww = 890065580; TpCXpbww > 0; TpCXpbww--) {
            UNcqSGCcJgmx += UNcqSGCcJgmx;
            zufqvnMOORv -= UNcqSGCcJgmx;
            wgZOYvtcEi -= zufqvnMOORv;
        }
    }

    return fydfsXdwiGmCwExJ;
}

bool tGulCgVD::ddrGGGeYRjm(bool tjxrISUkBFRUtHdB, bool SvtFL, double EySOcgtRp)
{
    string BspajL = string("yEZVeMoeKOnRsvWJXgqHMBWuzRhiEisaYRwAznJmFFKxcSCLKQMFZqQWTANcucilQvAVoteZOuiyfKvPhQqdumTrNQpINnJMMeIdKTrCECYqYiMvbqaKClLBsmHpjeoyjbZtrIuFqUzxzvyaJohZgdTFZYiksMjeQRkXnutvmBhOkYtvmYPKcGJQWHeTWOOuDsJTycnMfrdvuQmqvOIMuBTGnrhpneKNGRsSvGBMgNv");
    int WQKMrR = -1886352656;

    for (int xBOndsgnmOZOGc = 1412931127; xBOndsgnmOZOGc > 0; xBOndsgnmOZOGc--) {
        tjxrISUkBFRUtHdB = ! SvtFL;
    }

    if (tjxrISUkBFRUtHdB == false) {
        for (int KgQyF = 1784546238; KgQyF > 0; KgQyF--) {
            EySOcgtRp += EySOcgtRp;
        }
    }

    for (int CdzjVFAHlyfgWeRq = 1743826529; CdzjVFAHlyfgWeRq > 0; CdzjVFAHlyfgWeRq--) {
        EySOcgtRp /= EySOcgtRp;
        tjxrISUkBFRUtHdB = ! SvtFL;
    }

    return SvtFL;
}

void tGulCgVD::tWVJjHkReFluur(double tPyMdFEUM, string jotMxWdQXpL)
{
    double CapdtRPSzRnMVbdu = 888463.5337010944;
    int zDQjtaZOGJgrV = 1726551870;
    string nIErDs = string("GvSuTuaPxnIAPzcfjLGuGWTWdizOIjQBothPcZpsfrLljnAKKtWUhxToCdBJYNbEtpXOwxWYzHxjXdGaMscmSgwwFsoynnaZIIrNEvTtOQyXmJscQpsBdnwif");
    int NZSTcNXdQCWSveK = -366944436;
    bool vGqMEOeAyUBTwK = true;
    int vdtxoTwgN = 600465405;

    if (vdtxoTwgN <= 1726551870) {
        for (int HDpCMRx = 985381534; HDpCMRx > 0; HDpCMRx--) {
            vGqMEOeAyUBTwK = ! vGqMEOeAyUBTwK;
        }
    }

    for (int syAwZCRyD = 1188838530; syAwZCRyD > 0; syAwZCRyD--) {
        zDQjtaZOGJgrV -= NZSTcNXdQCWSveK;
        zDQjtaZOGJgrV /= vdtxoTwgN;
        NZSTcNXdQCWSveK *= vdtxoTwgN;
        CapdtRPSzRnMVbdu *= tPyMdFEUM;
    }
}

bool tGulCgVD::IQtUVfGevioad(string JuoxyAsKnSMyv)
{
    string OonrGiX = string("LbsdMEWgXHmqCqpZGsiLQDAkgBSWhONdARWopAxUaRyJaylimUhlkrKlUBioBxUFASyuHq");

    if (OonrGiX >= string("NdcVvrXmgjePFuVzwHTBEfceNiZpAIyjQYGCVXNsSjXjWQJRFDQBKjkmcDzEEAEozoDQQqfYBCSfAqdfoclkyVIRGKhjRvjygjGmNuUcFyFmhakBlmOMJNEPydZAOUEYJJCXNKzPwWlGRVHluJW")) {
        for (int KcshBsT = 407749338; KcshBsT > 0; KcshBsT--) {
            OonrGiX += OonrGiX;
        }
    }

    if (JuoxyAsKnSMyv <= string("NdcVvrXmgjePFuVzwHTBEfceNiZpAIyjQYGCVXNsSjXjWQJRFDQBKjkmcDzEEAEozoDQQqfYBCSfAqdfoclkyVIRGKhjRvjygjGmNuUcFyFmhakBlmOMJNEPydZAOUEYJJCXNKzPwWlGRVHluJW")) {
        for (int ltxHMJXtVjSysp = 136383544; ltxHMJXtVjSysp > 0; ltxHMJXtVjSysp--) {
            OonrGiX = JuoxyAsKnSMyv;
            JuoxyAsKnSMyv += JuoxyAsKnSMyv;
            OonrGiX += OonrGiX;
            JuoxyAsKnSMyv += JuoxyAsKnSMyv;
            OonrGiX = OonrGiX;
            JuoxyAsKnSMyv += JuoxyAsKnSMyv;
            OonrGiX += OonrGiX;
            JuoxyAsKnSMyv += JuoxyAsKnSMyv;
            JuoxyAsKnSMyv = OonrGiX;
            OonrGiX += JuoxyAsKnSMyv;
        }
    }

    if (JuoxyAsKnSMyv <= string("NdcVvrXmgjePFuVzwHTBEfceNiZpAIyjQYGCVXNsSjXjWQJRFDQBKjkmcDzEEAEozoDQQqfYBCSfAqdfoclkyVIRGKhjRvjygjGmNuUcFyFmhakBlmOMJNEPydZAOUEYJJCXNKzPwWlGRVHluJW")) {
        for (int VXeroPkturBy = 429561108; VXeroPkturBy > 0; VXeroPkturBy--) {
            JuoxyAsKnSMyv += JuoxyAsKnSMyv;
            OonrGiX += OonrGiX;
            JuoxyAsKnSMyv = JuoxyAsKnSMyv;
            JuoxyAsKnSMyv += JuoxyAsKnSMyv;
            OonrGiX = OonrGiX;
            OonrGiX += JuoxyAsKnSMyv;
            JuoxyAsKnSMyv = JuoxyAsKnSMyv;
        }
    }

    return false;
}

string tGulCgVD::icmXLx(bool fdXYFfiAWdDkctQ, string OSjmhQr, double zmALctOPnEGkw)
{
    double HoOtsKFcdX = -962693.2108904148;
    bool NbYyMWbqnlRIn = true;
    int XBkpoyYfKzaAfnr = 1805551793;
    string NZAqlUSRIjQzKMjd = string("OYVJunbWDGtSSmYasSPZyGcAXRtpdrfqxMuDFgevtIWhnGgcAGNPTeRzuKTgNMdFILQSfAgSwugrMfQfAnJiHtoVPVqDavHmbYKLyCPyXBSGTfdVQiAMJhtKIVMxNgDeDwlMchiHEhFBCCJMimpLUGNZUhPMDfwaeWonQTkHJgjHAWVCaASXEGQSITTMzoEhTvN");
    string teunrJOSE = string("vKwHpAocGjSHxQzixYuZNKvykiWKXdVwuawKbFlAXZPyVyRTVZCcNLWZsaSsKLTPGsJJcXDPilzszDKiMOczvmhZcbdXGZeblqdFKZqQgRJFaCnwpPxNxOCMUelUjyckwLAiNKCMQYRIxUcZIFqsqFBuH");
    bool urLGWqbpPARLaln = true;
    string lxpsecGGVvyFEhOZ = string("lUrkOzzRwZselRqLeKwyLiDRmGyeHELpFVjXQDtwHssQZZHcqFkJbnJNDgtlMFaFVvcOvWhPfRIElYoWflrfsoetbmTfOqpGwTaexnjMQToYGHyZhvqbtdyljAjccSOvwETVWJTdqdklVCqtIuSwanCTYjTDUBrndUWaxctNKPKEMfZlmchRz");
    double VExzdUKXmMTo = 47982.34312212329;
    int DCUDqd = 448295516;

    for (int PoEqcuGBq = 2096539281; PoEqcuGBq > 0; PoEqcuGBq--) {
        VExzdUKXmMTo -= zmALctOPnEGkw;
    }

    for (int pRxTwJvRUNHMpQTf = 1487413340; pRxTwJvRUNHMpQTf > 0; pRxTwJvRUNHMpQTf--) {
        continue;
    }

    for (int CKevV = 1169356647; CKevV > 0; CKevV--) {
        teunrJOSE = teunrJOSE;
        DCUDqd = XBkpoyYfKzaAfnr;
    }

    for (int sDdnGuAJWbkiA = 1897275675; sDdnGuAJWbkiA > 0; sDdnGuAJWbkiA--) {
        HoOtsKFcdX /= VExzdUKXmMTo;
    }

    for (int kPIPEzyfCMihXfZj = 1897599624; kPIPEzyfCMihXfZj > 0; kPIPEzyfCMihXfZj--) {
        urLGWqbpPARLaln = ! urLGWqbpPARLaln;
        fdXYFfiAWdDkctQ = ! urLGWqbpPARLaln;
        NZAqlUSRIjQzKMjd += OSjmhQr;
    }

    for (int BphYm = 1047222999; BphYm > 0; BphYm--) {
        OSjmhQr += NZAqlUSRIjQzKMjd;
        urLGWqbpPARLaln = urLGWqbpPARLaln;
    }

    return lxpsecGGVvyFEhOZ;
}

int tGulCgVD::jkmNrcsNMlITs(bool uvxtzOeUWlEIT, double GatuwlAlAlrcH, bool XJIHcndCqMt)
{
    double dnpDBMnyZeiA = 849531.7692670451;
    int uInUVeLAREed = 245151028;
    int vahQqp = 1857989443;
    bool DCaZJPruZjbcOD = true;
    double enxcEhFxQCZEi = -653251.3742016491;
    string NtftjjHcJXordjnm = string("EFiYODDlYiUsqVfHXvzcjMosQcbsvpTjvqWrNlkqlLOooDnSHHGRyBkrVBKujWQOMtSmHhukqsRfUntEVngvMtNGwxezPKXhXnrGLmQTcgLTiHKSHPrxCbMRRwIxKHdbHxiRzBQYlFkEui");
    int xIrUhdOa = -1706443710;
    double ilDoymY = 622235.8014638561;
    double kfcWFjzjkUz = 1036064.4435548445;

    for (int xeepEcFlEeR = 469299934; xeepEcFlEeR > 0; xeepEcFlEeR--) {
        XJIHcndCqMt = DCaZJPruZjbcOD;
    }

    if (ilDoymY <= -653251.3742016491) {
        for (int FYdvuRx = 536653363; FYdvuRx > 0; FYdvuRx--) {
            enxcEhFxQCZEi = enxcEhFxQCZEi;
            vahQqp += xIrUhdOa;
            ilDoymY -= dnpDBMnyZeiA;
            vahQqp /= vahQqp;
        }
    }

    if (enxcEhFxQCZEi >= -653251.3742016491) {
        for (int qmetjBFJhBC = 916641925; qmetjBFJhBC > 0; qmetjBFJhBC--) {
            xIrUhdOa = xIrUhdOa;
        }
    }

    return xIrUhdOa;
}

void tGulCgVD::zJdHxjfNVB(bool KjLoSmgcZgoRy, bool BcZlpKGYqbXIEKi, bool qFLmXYTvFoNr)
{
    string FXIMbmaRw = string("pHlAmCllBijWBHOINbyMfjazUYKDV");
    bool FZuMbouYSErQdReH = true;
    int ISTKvCtGLIZ = 539241789;
    double LRiEw = 900865.1287342393;
    double buKELXTLIIetL = 200637.8654358025;
}

tGulCgVD::tGulCgVD()
{
    this->szviIpsLLCN(string("phhpLFaeCbzGOihpYTnimrrlYnvPTyWxprQWFOZqSZRamLqIQKTGfHtsvZSBCNGOYDGkhGhxTjNZHhVtWQFqoHRXUykJgizrwTteSeppHrRwdjtHiRRfVwFzSRdnrVhuxaYbVmxsMvainEtYzmvWjox"), 148265.29897950214);
    this->ykBDrsFc(-803180.4669779058);
    this->ddrGGGeYRjm(false, true, -194195.37822596662);
    this->tWVJjHkReFluur(689838.5820795478, string("AjfViDBqgRmdZprakvPIXgwBzoxulQDCGqzSNkZOkGUAcgRGmqcrpwwHsRTEPQLoibNDDXWQsJGqIMEgPHoolwtwNYwPQaGDauDKNMOljaJwNlYsvNxyRHROOuTGSiGWOuXCaLtjFkTHTDggTwfmbnSOgspdcnjHyfFMkyQoGzUjBiBXhCrQutLEOtQgdBZVBuOwWGCzqdMAcAcHrkBsyGTuAsfkxiycdTqJlFfALVXHfjors"));
    this->IQtUVfGevioad(string("NdcVvrXmgjePFuVzwHTBEfceNiZpAIyjQYGCVXNsSjXjWQJRFDQBKjkmcDzEEAEozoDQQqfYBCSfAqdfoclkyVIRGKhjRvjygjGmNuUcFyFmhakBlmOMJNEPydZAOUEYJJCXNKzPwWlGRVHluJW"));
    this->icmXLx(true, string("sBFbiCtqxdMPsMUC"), 348332.78919598326);
    this->jkmNrcsNMlITs(true, -384069.94838898035, true);
    this->zJdHxjfNVB(true, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vjuqcgCK
{
public:
    string zZhNlcOtJVLhpUFT;
    string TIhkJPgOKybRS;
    double CVrOKLHV;
    bool XgRcWGRhtScEcGiW;
    double adlQp;

    vjuqcgCK();
    string DhKawveU(double WecLJVIJCg, int NmySj, string QDbebOFUxBwqCsPi, bool jbFyNTEdyBXRE, bool kItyQcEaZRdVATWH);
    double OvMpucJ(double NMeqgVQ, bool hAbHc, double NYhewyOTLOrnipzY, double JLxaNku, bool WvuMNQtQzIKlY);
    bool qzPryCQTvsHfijI(string ErpdlFBPremjLZP, double CTZaordmv, int EkogRpVZwfPv, int EdSaYEtohEMqd, double AfHgbakkOHOVGh);
protected:
    double FeSJWz;
    bool YPxoATLaFbe;
    string tFJJQsEW;
    string KWGNvqGJyVfURaT;
    bool fYfFsPL;
    string uEeCJSI;

    double YQGXpPasfrxc();
    bool YwTSURBSeii(double hDOoQJQAOLbkO, int ShyYgJRqB, bool KioET);
    string BWuYmKpHxG(int TbUBlJlvtBicsK);
    bool kBhZBlsraLhtVKN(double KmhkATrnXhOqCUK, string gWKdHCzISH, double WHpEthJbE);
    void WXFkfSdXANoW(double PnxwWCdwxy, int KWhEDkvyJyoaFgU, double sndoW, double iaCSsVleWLClcs, int CqfLbzpCoIROF);
    int gDsDMQNbrhS(int ZysmPzfTin, string ewqJMNZlEXkE, bool IvgwqlmPNZNbRMMo, double MxvyZm);
private:
    double vQJIhQ;
    int zBUNvvtG;
    double EebcmGpx;

    string BIovlJGElCdLjr(string gwnkkWMpC);
    double KiuZyCeRFuIrjs(bool BbgjykpghazuBpgU, int ReBmB, double heqaeQmTyVl, string aSdLRWXs);
    int sKCnJyIL(string sfKsecxU, int FPVOXMFR);
    string vcdteZZZxg(bool zBmlQJKcPGWADn, double KOSVsLYWetacjd, bool rPPYdMS, double ZKFJcBlMLE);
    string ZpxjxYeqeOOdokKt(int xHFAYJCmHmcCFOW, int zFCNpFUSo, int XajQNAusJcBP);
    string mqZNpYQVDF(int KJzDdYwUZS);
    string nlPkyGLLWLBC();
};

string vjuqcgCK::DhKawveU(double WecLJVIJCg, int NmySj, string QDbebOFUxBwqCsPi, bool jbFyNTEdyBXRE, bool kItyQcEaZRdVATWH)
{
    bool KjaoyhyJAECfe = false;
    double iHMldrVpBnJjuw = 123048.75425421681;
    double uvhVsp = -969259.1676816706;
    double VDNNI = -453130.3164730905;
    double DxMaHa = 61617.02107425497;
    bool UfofBnANBNRssxk = true;
    int jzmlcPev = -1548604762;
    double HFjJphKob = -416244.1217985231;

    if (HFjJphKob != -453130.3164730905) {
        for (int mZVQQrdFQ = 2075823965; mZVQQrdFQ > 0; mZVQQrdFQ--) {
            uvhVsp = WecLJVIJCg;
            UfofBnANBNRssxk = KjaoyhyJAECfe;
            UfofBnANBNRssxk = ! UfofBnANBNRssxk;
        }
    }

    for (int hVVTzOCNIFBQkk = 2048491; hVVTzOCNIFBQkk > 0; hVVTzOCNIFBQkk--) {
        UfofBnANBNRssxk = ! kItyQcEaZRdVATWH;
        uvhVsp = uvhVsp;
        WecLJVIJCg = uvhVsp;
        HFjJphKob -= HFjJphKob;
        jbFyNTEdyBXRE = ! UfofBnANBNRssxk;
    }

    if (iHMldrVpBnJjuw > -969259.1676816706) {
        for (int CrdSlpzeFJuFoxcK = 630360792; CrdSlpzeFJuFoxcK > 0; CrdSlpzeFJuFoxcK--) {
            iHMldrVpBnJjuw *= VDNNI;
        }
    }

    for (int ftvTQlxPQwKKFVc = 849711506; ftvTQlxPQwKKFVc > 0; ftvTQlxPQwKKFVc--) {
        jbFyNTEdyBXRE = jbFyNTEdyBXRE;
        VDNNI -= uvhVsp;
    }

    for (int fVPAzl = 1938150558; fVPAzl > 0; fVPAzl--) {
        iHMldrVpBnJjuw += HFjJphKob;
        uvhVsp += DxMaHa;
        uvhVsp *= uvhVsp;
        QDbebOFUxBwqCsPi = QDbebOFUxBwqCsPi;
        jbFyNTEdyBXRE = kItyQcEaZRdVATWH;
    }

    if (VDNNI != -416244.1217985231) {
        for (int VIyBz = 365904366; VIyBz > 0; VIyBz--) {
            continue;
        }
    }

    if (jbFyNTEdyBXRE != false) {
        for (int dSkOylJdcOIy = 1886678363; dSkOylJdcOIy > 0; dSkOylJdcOIy--) {
            jzmlcPev = jzmlcPev;
            iHMldrVpBnJjuw /= uvhVsp;
        }
    }

    return QDbebOFUxBwqCsPi;
}

double vjuqcgCK::OvMpucJ(double NMeqgVQ, bool hAbHc, double NYhewyOTLOrnipzY, double JLxaNku, bool WvuMNQtQzIKlY)
{
    double wVLfrzetm = 523387.33293241373;
    string ckozxQyUavuHiDQ = string("AlyHfkLqDjYqsqBiwdKaXHpXWQjpJrKEwYXHCxRZvPxnmEecPmpVwNPvRIeOGFutsvvjwNBcMGpCLZaooWzJHTkvRNvLEPTMAwGnVoMRjkipqMnhWnPXexIaWqKqXcBwzmHHtdghOdGUvcYlkoBShbq");
    int fxFbyeUhAlQmpA = 392725922;
    double bhOguKSpvwhfiqNT = 799868.9798878916;
    bool IHXYBFHiiMpnnId = false;

    if (JLxaNku > -65812.17318148697) {
        for (int svlvtSVckbqwfEv = 1748736484; svlvtSVckbqwfEv > 0; svlvtSVckbqwfEv--) {
            wVLfrzetm *= NMeqgVQ;
            WvuMNQtQzIKlY = ! IHXYBFHiiMpnnId;
            NMeqgVQ /= wVLfrzetm;
            ckozxQyUavuHiDQ += ckozxQyUavuHiDQ;
        }
    }

    return bhOguKSpvwhfiqNT;
}

bool vjuqcgCK::qzPryCQTvsHfijI(string ErpdlFBPremjLZP, double CTZaordmv, int EkogRpVZwfPv, int EdSaYEtohEMqd, double AfHgbakkOHOVGh)
{
    bool TQsDwMlaybWJ = false;
    double zqQlxnfGhUhOTrrr = -103494.49003120202;

    if (zqQlxnfGhUhOTrrr <= -148064.78417351012) {
        for (int VMeLiVjUA = 349464632; VMeLiVjUA > 0; VMeLiVjUA--) {
            CTZaordmv /= CTZaordmv;
            zqQlxnfGhUhOTrrr *= CTZaordmv;
            AfHgbakkOHOVGh -= zqQlxnfGhUhOTrrr;
            EdSaYEtohEMqd -= EdSaYEtohEMqd;
            EdSaYEtohEMqd += EdSaYEtohEMqd;
        }
    }

    for (int DLCSLR = 1020337685; DLCSLR > 0; DLCSLR--) {
        EkogRpVZwfPv += EdSaYEtohEMqd;
        EdSaYEtohEMqd += EkogRpVZwfPv;
        ErpdlFBPremjLZP += ErpdlFBPremjLZP;
        EkogRpVZwfPv -= EdSaYEtohEMqd;
    }

    if (ErpdlFBPremjLZP == string("QSyRyysQIrtqsusuorHEAeOoOilAgeJlYdPzXhWl")) {
        for (int FrbUmN = 295212436; FrbUmN > 0; FrbUmN--) {
            CTZaordmv += zqQlxnfGhUhOTrrr;
        }
    }

    return TQsDwMlaybWJ;
}

double vjuqcgCK::YQGXpPasfrxc()
{
    int JjTDJFTwSeupN = 337878937;
    string DsCxpzEeyS = string("ZkPquBoBIWVXbLDZPTVAGbNUmlFBHzPTOzmPqWjiUEnfLOHIMRlszrHwbLACBbcUw");

    for (int Vyjiw = 114649880; Vyjiw > 0; Vyjiw--) {
        JjTDJFTwSeupN /= JjTDJFTwSeupN;
    }

    return -468577.0592610475;
}

bool vjuqcgCK::YwTSURBSeii(double hDOoQJQAOLbkO, int ShyYgJRqB, bool KioET)
{
    string fRQDwZJstJ = string("bUWYowZMrfKjXiFCekUVeNdtcNIxzbkktlFvFDTPdJpYjddymfylRHnBUsFnEUHvApqzasnwIObYuoPcreAerjEnFHZsbnsCVBpRmuyDYaBCICKxanyIyfYWZHnptTGaKIOgCeCvFTjurcaDOvMmGHFirremvxygrePbsgKArWunvBcLaWXQIMUFpHMkcoiIoflzijxKVOVh");
    int fOgJhTCjKqwxzS = -585917737;
    bool NImjrRckRQwcED = true;
    string JKkhrZqrU = string("pJfwiJaijElvgPTWsJNfmWIWPiMgRjPPaqwLaYNFMuq");
    string OhEkPecQMOaQcqo = string("GCXwaSsHEbXmVNAWGgXhtlIPqHKZWbbLJkhhDlKEAdCpqXpZzqIFkfEvcMlCtvb");

    for (int IoLEdbmudef = 704391957; IoLEdbmudef > 0; IoLEdbmudef--) {
        continue;
    }

    for (int dfvJWxYrIQyN = 687181404; dfvJWxYrIQyN > 0; dfvJWxYrIQyN--) {
        fRQDwZJstJ = JKkhrZqrU;
        JKkhrZqrU += JKkhrZqrU;
        OhEkPecQMOaQcqo = fRQDwZJstJ;
    }

    if (JKkhrZqrU > string("bUWYowZMrfKjXiFCekUVeNdtcNIxzbkktlFvFDTPdJpYjddymfylRHnBUsFnEUHvApqzasnwIObYuoPcreAerjEnFHZsbnsCVBpRmuyDYaBCICKxanyIyfYWZHnptTGaKIOgCeCvFTjurcaDOvMmGHFirremvxygrePbsgKArWunvBcLaWXQIMUFpHMkcoiIoflzijxKVOVh")) {
        for (int mcXwKlHeLObkgv = 2146001336; mcXwKlHeLObkgv > 0; mcXwKlHeLObkgv--) {
            JKkhrZqrU += OhEkPecQMOaQcqo;
        }
    }

    return NImjrRckRQwcED;
}

string vjuqcgCK::BWuYmKpHxG(int TbUBlJlvtBicsK)
{
    double DvKPoK = -730212.2507730303;
    double LaywCDFrIg = -629999.0199116996;
    int mqlvHG = -763056893;
    string PhToRwJNJjumIB = string("OVKkbHOmUJLQHiDUcnDmWGmeTAlHSNANomgkQRHVTtjCLkdKZlKsmyKZlIocRGoxkKHPxAwjTjizXkeCltYYCPEIMjbMIAeLNrJrXFRLxIRXepJjXNJLaMgKqHz");
    bool slDgGFUnYyq = false;
    int ohQyHrwUPrBgwWID = -1190665276;
    double NUJiBQ = -141285.02943932923;
    string uWPAmPOGQwtzoM = string("jfMamDobPoar");
    bool KsLMzUTQcjoLHGcv = true;
    int ffpCrUfDntn = -271176189;

    for (int FpvSJOWlhpQZHaT = 76412847; FpvSJOWlhpQZHaT > 0; FpvSJOWlhpQZHaT--) {
        continue;
    }

    for (int KNbJszTdOILfFsRh = 2020127030; KNbJszTdOILfFsRh > 0; KNbJszTdOILfFsRh--) {
        continue;
    }

    return uWPAmPOGQwtzoM;
}

bool vjuqcgCK::kBhZBlsraLhtVKN(double KmhkATrnXhOqCUK, string gWKdHCzISH, double WHpEthJbE)
{
    bool LUGmDuFhX = false;
    bool nDPEst = true;
    double BnzHYs = -410054.87125810306;
    double CrEnejTnx = -384978.64895565074;
    bool NnFlokdWkF = true;
    string aPjQGMXjcqzFb = string("xeZLCjVeskKHqXCQRtHZeVvQadYYzcPiglSGBEvNPsQdFuhcAZaxYbSZpeVAJiOWYEESbrujgUuxXcLZvVdMvUvFyAZVymmSYYQylVouechrFyrAWXqgiobrWNPpgkTvafJEQwleqYbnRIcEGDQMMKoguwxSZrIBRfkHRkxyEmNpqPZFHRdmmlvtTBvbhqMkgA");
    string DRrRPTQh = string("pnNfKfPskLwQpklhbaydyRhOuabihxatLyVQyboaGbVOLgadZBLodvlygkfQSctfKKuFYrSOfoMNYoXwAdMaJZ");
    string PMAYt = string("OKOawsglWqOcUQNiovjpGzNHGxeLGJIocsrpFhVCNYfgepcTIhPeCFkVilp");

    return NnFlokdWkF;
}

void vjuqcgCK::WXFkfSdXANoW(double PnxwWCdwxy, int KWhEDkvyJyoaFgU, double sndoW, double iaCSsVleWLClcs, int CqfLbzpCoIROF)
{
    string yjwfcebBua = string("OANimjZ");
    double WHXMnmUSRBXX = -883456.2689907333;
    bool IcRWJRvAGhOF = false;
    bool OegIdX = true;
    int dafsfPgKZnmZUX = 994246764;
    int WNmRCtMaoFtS = 872514048;
    bool fXQSjIcUdcsR = true;
    double uvAGvV = -131913.28745508628;

    for (int xZdlcxg = 1130418554; xZdlcxg > 0; xZdlcxg--) {
        continue;
    }

    for (int sWyOKUtpdMFcJAU = 430518726; sWyOKUtpdMFcJAU > 0; sWyOKUtpdMFcJAU--) {
        iaCSsVleWLClcs += WHXMnmUSRBXX;
    }

    for (int aYmAfVRjvAV = 1663234196; aYmAfVRjvAV > 0; aYmAfVRjvAV--) {
        sndoW = WHXMnmUSRBXX;
    }

    for (int ZWWKD = 1202703235; ZWWKD > 0; ZWWKD--) {
        uvAGvV *= PnxwWCdwxy;
    }
}

int vjuqcgCK::gDsDMQNbrhS(int ZysmPzfTin, string ewqJMNZlEXkE, bool IvgwqlmPNZNbRMMo, double MxvyZm)
{
    string qBEUtWZoiPdCIKY = string("zizfRRimlsEBOd");
    string wRMrrB = string("PIGECmOOgLMGGYijQXIXtRhVRGdDtukVolLtcILnivLCroRoxWEGXifcVAZjOOCcsDI");

    for (int GXCIAptpQ = 819718203; GXCIAptpQ > 0; GXCIAptpQ--) {
        wRMrrB = wRMrrB;
        qBEUtWZoiPdCIKY = wRMrrB;
        MxvyZm -= MxvyZm;
        wRMrrB = qBEUtWZoiPdCIKY;
    }

    if (qBEUtWZoiPdCIKY != string("NhxKDmsueJYihGIVScDTEmCUkqUqxCxFwNOUktoYGUjQWYTdzbyEWzWjGJpbsFNiuYdVuylfeToF")) {
        for (int HOzEOWgCQU = 1661415287; HOzEOWgCQU > 0; HOzEOWgCQU--) {
            ewqJMNZlEXkE = qBEUtWZoiPdCIKY;
        }
    }

    for (int zvplW = 182126338; zvplW > 0; zvplW--) {
        qBEUtWZoiPdCIKY += ewqJMNZlEXkE;
    }

    if (qBEUtWZoiPdCIKY > string("NhxKDmsueJYihGIVScDTEmCUkqUqxCxFwNOUktoYGUjQWYTdzbyEWzWjGJpbsFNiuYdVuylfeToF")) {
        for (int RrOhgjy = 1863452600; RrOhgjy > 0; RrOhgjy--) {
            ewqJMNZlEXkE += qBEUtWZoiPdCIKY;
        }
    }

    if (qBEUtWZoiPdCIKY > string("NhxKDmsueJYihGIVScDTEmCUkqUqxCxFwNOUktoYGUjQWYTdzbyEWzWjGJpbsFNiuYdVuylfeToF")) {
        for (int uPkvBHUCcLdHMOQG = 213446390; uPkvBHUCcLdHMOQG > 0; uPkvBHUCcLdHMOQG--) {
            qBEUtWZoiPdCIKY = qBEUtWZoiPdCIKY;
        }
    }

    return ZysmPzfTin;
}

string vjuqcgCK::BIovlJGElCdLjr(string gwnkkWMpC)
{
    bool wgKYcqEVOFLrCl = true;
    int RPXEpLFOdwgZL = -363187690;
    bool iYpbFHmaFfp = false;
    double BohvONoWfqRemD = -759303.5411546815;
    string RTHOvGnHysUEfq = string("YwwbtpYIFQpFaalPgCChkBJCaCqXCxWnfOEAGdtQOdRisMPZHlpjWRAWOTBuCSNwTNoDiuRNiSYLoyJxeJRm");
    double mYlUbiWdtebEjLn = -316098.81316685944;
    int SjydAcVPBNIGizmN = 868593625;
    bool DxtaVtazKXiJciKO = true;
    string GngoxOaReufsvL = string("bgNOXYbfFbgGZvPamCTYFtEuRMrFIvQPNuKUCRSHUAkyfVCiITWpWVAWsVsXwQZTjlnTKoOsKCaC");
    string FSDqO = string("NeuHvdUzJzXAxnqUbqqQhkMetTNwSAJjkgsSuZoNweEgJzggZXKtyVmmgWDHJUoYLbUjTBWscCDnwNERjEdmYFyAMfCcKmtpyVYDyDIPhvpAtZLexvCMZbSdNijvpViFbvJlPhqOzPeaHnxrdHGAFTqoKCZOF");

    if (iYpbFHmaFfp != true) {
        for (int hbpFytssXGaF = 172151357; hbpFytssXGaF > 0; hbpFytssXGaF--) {
            continue;
        }
    }

    for (int bKQCgAebWbTozhG = 1765565369; bKQCgAebWbTozhG > 0; bKQCgAebWbTozhG--) {
        continue;
    }

    for (int eNudWrcrAbFmXOy = 459579966; eNudWrcrAbFmXOy > 0; eNudWrcrAbFmXOy--) {
        DxtaVtazKXiJciKO = DxtaVtazKXiJciKO;
    }

    return FSDqO;
}

double vjuqcgCK::KiuZyCeRFuIrjs(bool BbgjykpghazuBpgU, int ReBmB, double heqaeQmTyVl, string aSdLRWXs)
{
    int KXkZUnrRYVYQDKL = 1067571303;
    double ippstQFwJkm = 753405.8265960217;
    string mLoaCDRPzT = string("zklxeixPnabbsAHyaLZbLEgCGMZPxLcNhfnuqmeGAJnXdVsnuEiQoGhrgnotCsZLLhvAmdDiARwemKuFIxBXdwLwVaJYaIjXEXcbvWIRJlwCTByCCZElxdrIhyPfQZdYUaioaj");
    int ToeQTnuT = -1746834049;
    double BUzjoySsAVYnOhmA = 813747.622239406;
    int xUnvmnOgTRSH = 918227373;
    int awXbFnezFpDKlPx = -770607249;

    for (int NurDqgWet = 300123513; NurDqgWet > 0; NurDqgWet--) {
        awXbFnezFpDKlPx *= awXbFnezFpDKlPx;
        xUnvmnOgTRSH = awXbFnezFpDKlPx;
    }

    if (ippstQFwJkm > 813747.622239406) {
        for (int SWIZCNgJS = 843007420; SWIZCNgJS > 0; SWIZCNgJS--) {
            ToeQTnuT = awXbFnezFpDKlPx;
            BUzjoySsAVYnOhmA *= BUzjoySsAVYnOhmA;
        }
    }

    return BUzjoySsAVYnOhmA;
}

int vjuqcgCK::sKCnJyIL(string sfKsecxU, int FPVOXMFR)
{
    string TFlYcXXJuNAzNN = string("SJjKBGuqpXMQisfbsZsAFXrZhLyJcKxXAmXGKAfLMCXGjBXYhR");
    int slkBnUYdWUdFp = 1661088557;
    bool rcQAFuIDKbAtRt = true;
    string RlzFZhuj = string("vfkeROJAbFfDpQNpkuKjoIosTDjsuqsvPKlVZEvtcBMBRhGgPUsEhCyNEbYKgrsPfkmpNKLUPSAeeqESjPsGeDbzXyIyNhqcVPGYHlTDdITAfMJ");
    int VuFgDTdQrP = 288658611;
    bool EFNRmAoCjTQ = false;
    int hGZMUo = 1887366702;
    string GbgYFtbnKdbAf = string("ieDcSpWnZmnALDKmokxwEawmYNqLmQJuroIiPqIEFFNvLpZogrSmTlckTghg");

    for (int ztenEWKCi = 676625159; ztenEWKCi > 0; ztenEWKCi--) {
        TFlYcXXJuNAzNN += TFlYcXXJuNAzNN;
    }

    for (int VywmL = 1588806186; VywmL > 0; VywmL--) {
        TFlYcXXJuNAzNN = RlzFZhuj;
    }

    return hGZMUo;
}

string vjuqcgCK::vcdteZZZxg(bool zBmlQJKcPGWADn, double KOSVsLYWetacjd, bool rPPYdMS, double ZKFJcBlMLE)
{
    string raeYyoxCYTEqJk = string("dZXeLtKmhYylieQvcpblTSGJIbPvvMXIIipoDbXchosngpXdiLKyld");
    string DevViroFntDnT = string("tWeqgrMBmeVnTZTBVJBRJvcxJUUOfPbjeXxaTXnnrlZUBPOHkmpVwkZstbTHBSTrFBuxarvkOzxfWmHYMeFxghOHucMRyYZuDeOCcUfQKbwHMwEuyurJZAGyZmROKTDYLArAEJpvBKYMVwbDRecxPRXiinFGoWjQjdwiwwzUykYxScAV");
    double jDEaK = -967348.4104891259;
    double kciOKKBkQJtwzQwt = 189616.78998899422;
    bool PlQKzQ = true;
    string gtBNHTZ = string("umeIlBjdKunYCiAUlqtdqWMWYeMmioBSiBSHPOqomnmEFsLSMKFuuEimVfSakJnmQeiJCCgvBKVCukBBprCeIGMqrhptWhPQJSWiKtMWuoHCTLrdBBTuYuCDKVUMfagtVoaDGtrhLdshPCZqAjshqVvpIvetzzd");

    if (kciOKKBkQJtwzQwt <= 189616.78998899422) {
        for (int aVxSPSGXSHNBlq = 868712039; aVxSPSGXSHNBlq > 0; aVxSPSGXSHNBlq--) {
            gtBNHTZ = DevViroFntDnT;
            DevViroFntDnT += gtBNHTZ;
        }
    }

    for (int dRwWSQhkoSDWGk = 1436236293; dRwWSQhkoSDWGk > 0; dRwWSQhkoSDWGk--) {
        raeYyoxCYTEqJk = gtBNHTZ;
        zBmlQJKcPGWADn = ! PlQKzQ;
        raeYyoxCYTEqJk = raeYyoxCYTEqJk;
    }

    if (gtBNHTZ <= string("dZXeLtKmhYylieQvcpblTSGJIbPvvMXIIipoDbXchosngpXdiLKyld")) {
        for (int aEpsfT = 863717731; aEpsfT > 0; aEpsfT--) {
            ZKFJcBlMLE = KOSVsLYWetacjd;
            raeYyoxCYTEqJk = gtBNHTZ;
            ZKFJcBlMLE += KOSVsLYWetacjd;
            kciOKKBkQJtwzQwt *= kciOKKBkQJtwzQwt;
        }
    }

    for (int mVENrpvUxsbz = 864172278; mVENrpvUxsbz > 0; mVENrpvUxsbz--) {
        jDEaK /= jDEaK;
    }

    return gtBNHTZ;
}

string vjuqcgCK::ZpxjxYeqeOOdokKt(int xHFAYJCmHmcCFOW, int zFCNpFUSo, int XajQNAusJcBP)
{
    int xtlgswuMOcy = -333135699;
    int RfOhvM = -1043463278;
    int ICTKdKqhRIV = -1954141958;
    string ImuTmBwrjxMBIQe = string("IxkrbzfUuuWVreeNfdjgaqspvEatZyGtxCNMBThnkkzHzPMXlPQLczPcM");
    double uDESxpiDuB = 115267.19729665952;
    string hehjwZ = string("DmDYdWBoRwnMOXmOJssNnCOCDmQvmgxQdLHLLLXvJdBryNnAHSxxJTlMqUEhrmVcwBKGuhtGTkyvesPJcXjPbOjjXSzhcANdNqQgwTXnajnPoovVKaOKvedE");
    double YLrRtWnBZZz = 626383.8334931936;
    double tdqbMMVoINlHL = 374480.41370178864;
    string yrFfXgsKqjYfe = string("EUSCCfuuxQIpmRriWSZeumFQz");
    bool LrLwU = false;

    if (zFCNpFUSo < -1043463278) {
        for (int BcGMDWzu = 314915610; BcGMDWzu > 0; BcGMDWzu--) {
            tdqbMMVoINlHL *= tdqbMMVoINlHL;
            uDESxpiDuB /= uDESxpiDuB;
            RfOhvM /= XajQNAusJcBP;
        }
    }

    for (int tJHoylhj = 2095724294; tJHoylhj > 0; tJHoylhj--) {
        continue;
    }

    return yrFfXgsKqjYfe;
}

string vjuqcgCK::mqZNpYQVDF(int KJzDdYwUZS)
{
    double NWIjzBOxF = -1025327.1701732029;
    bool bpVnKTC = true;
    string fscyr = string("UlTpnMGtYKOVsjKDfTkxrQYWgJEZAQhvgqNgAFzUPGNdIPHKynRsQzTwXTbTzrcclQF");
    string MSMXfqRsLAo = string("yaCPATysWoFGCmytjVPxDzoqZxZfikASIlZpdOfnIjuTXFwFQYzSdMnQhUyQKkcNMAazpThZYvYEIZQSkUXcQYNJCaDLiTtWaxYXDZCJsyNnuyFchQviTeiHwJhGFfSvkYEfPHnxEmompchseLvRcMsxNInGyKsZRxJETLCHXrCKwbjUNLxbGmmJwpKoqfCAFcAIGMBmWtoRLYQqFQfJqWSbxWcHabaFxcdP");
    double AIqwZQXazBFnPaj = -564830.7337132912;

    for (int pAJuLgvMZUCajFkN = 890947678; pAJuLgvMZUCajFkN > 0; pAJuLgvMZUCajFkN--) {
        MSMXfqRsLAo += MSMXfqRsLAo;
        AIqwZQXazBFnPaj -= AIqwZQXazBFnPaj;
        KJzDdYwUZS += KJzDdYwUZS;
    }

    for (int slgmleLfFdMQxPVH = 2116462226; slgmleLfFdMQxPVH > 0; slgmleLfFdMQxPVH--) {
        AIqwZQXazBFnPaj += AIqwZQXazBFnPaj;
        AIqwZQXazBFnPaj -= AIqwZQXazBFnPaj;
        MSMXfqRsLAo += fscyr;
    }

    for (int xrCYkOQmu = 1934039606; xrCYkOQmu > 0; xrCYkOQmu--) {
        continue;
    }

    for (int MarfRgIAMGTVuroo = 431076260; MarfRgIAMGTVuroo > 0; MarfRgIAMGTVuroo--) {
        KJzDdYwUZS += KJzDdYwUZS;
        AIqwZQXazBFnPaj *= AIqwZQXazBFnPaj;
        AIqwZQXazBFnPaj /= NWIjzBOxF;
        MSMXfqRsLAo = fscyr;
    }

    return MSMXfqRsLAo;
}

string vjuqcgCK::nlPkyGLLWLBC()
{
    int SKGdD = -616750896;
    double UukFHbKa = 713524.8401498285;
    string bQKWXcSLHKuX = string("xppUJXzmmdeAjvueMRbkCXAgPlqpgPbWKhaejwDSftYTJTUkfLpTolfntGTlOAWhARjXdmuEQGabckaaAMsIwQKCggQFmjgejQhhchkSSSRjybjOegUdIsFhWXoqnwVShwpNmwtxWwKplBmeArbyusO");
    double jGsUtCDtxvSt = 108798.59214636315;
    bool iMhLrbtNZMOi = true;
    double cWkNTndt = -259038.73241754732;

    for (int iXYEH = 68000889; iXYEH > 0; iXYEH--) {
        iMhLrbtNZMOi = iMhLrbtNZMOi;
        cWkNTndt += UukFHbKa;
    }

    if (cWkNTndt != 108798.59214636315) {
        for (int QYhkPYhHOC = 2088570364; QYhkPYhHOC > 0; QYhkPYhHOC--) {
            jGsUtCDtxvSt = UukFHbKa;
            jGsUtCDtxvSt += cWkNTndt;
            cWkNTndt -= cWkNTndt;
        }
    }

    return bQKWXcSLHKuX;
}

vjuqcgCK::vjuqcgCK()
{
    this->DhKawveU(-756362.8778493667, -1166595547, string("AfXYuqJdGiCIVQhgzuRoHWAPpUiBKxXaNjUINueKWtVjcHFFCOSvvttOboVZyxVaVoncTaCAbdYNFZFcTdKjHpgfETRVqDSnyVHHZbXGzIUngXbzRgCudxUipzzbNjSwCxHjFgYbGcUGROkQbKdGwjyUmpOGseOAkLTBTTKDBTalTONHOPrZOfArik"), true, true);
    this->OvMpucJ(-53836.45963904171, false, 630488.7041162398, -65812.17318148697, false);
    this->qzPryCQTvsHfijI(string("QSyRyysQIrtqsusuorHEAeOoOilAgeJlYdPzXhWl"), 401568.03076667513, -2050576437, 1380283577, -148064.78417351012);
    this->YQGXpPasfrxc();
    this->YwTSURBSeii(300417.4622431565, 1942838309, true);
    this->BWuYmKpHxG(1185663909);
    this->kBhZBlsraLhtVKN(-414152.763097173, string("cEuvsqeCTeEnXqqpgLTAiIaHjtXxZwMECurNUQnxRhouAnoNeZtrjeaVdulzTIkKlQhXrVQAsqxwSzRgEqGdGsiSnaQTRQvPRCgGystvdYeazcVAkustavQxuKnwOoVbTWKzpUTQPpLSzEABTYqZgrcxBygrKCvzcceBQtWNMGeRfjFIxBYbgYkiRmgaobWapp"), 953677.8000270909);
    this->WXFkfSdXANoW(-714256.0732329647, -1634232041, -112707.0907896556, -845621.763273224, -2116140106);
    this->gDsDMQNbrhS(344922316, string("NhxKDmsueJYihGIVScDTEmCUkqUqxCxFwNOUktoYGUjQWYTdzbyEWzWjGJpbsFNiuYdVuylfeToF"), false, -551121.724261371);
    this->BIovlJGElCdLjr(string("NNwOvfJBNmKumaASFDygEdoqbhizAdoCOytcdCGCFoKgfbIcWWJTmDjxonuxReHxCXBYeAvIfMTaSxJlmyyjnLhOAQaAnlMxlupSryZGCogYtclJjdlupRUVyOZXnaEMWjUMTrDzYseUsBGzzoiGqsuBoadqMTvYUVprlewT"));
    this->KiuZyCeRFuIrjs(true, -683970748, -513393.241879392, string("wbgzbvzdOHsWWTXCLgNTnXwuYLOKhKgXfOHEoxeRPeTYkhJUMNdOPtbxkWlWue"));
    this->sKCnJyIL(string("xXcChfTZTjUykMMbLQrkFkTIEQAFeeZLjvtKsndYvIVbffwEKktjcfnulzcFOLZGummxdfIIZStZmecAmtiqfaipwHOwjyCCHtqyzpMpGDK"), -635265055);
    this->vcdteZZZxg(false, -374979.15901304386, true, -505030.9757927247);
    this->ZpxjxYeqeOOdokKt(-1366264908, 16174915, 1136052318);
    this->mqZNpYQVDF(1782808617);
    this->nlPkyGLLWLBC();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AGPFSAROFWwFMYH
{
public:
    string pPBdMUfVLj;
    double DdBkLsKE;
    int wAlSDl;
    double kPznAeq;
    double UTQnjBRc;

    AGPFSAROFWwFMYH();
    bool ZzQKeqwTrYhcOQy(bool LtSOa);
    string sPVCIKXYfniFCCzF(bool tQEjcbKYOsKLK, bool brxLYEHRDHjFdQxh, string ohojttWsddj, bool hNxmZ);
protected:
    string YDrBy;
    bool qbRZu;
    int EaJyZDARJKITu;
    string PrukCPjNgKRL;
    double AcDooeTQlmhRnhX;

    void zOWdKbWmQf(double cprgTaDt, int LhccwDtfApKrWDsC, double oHjQV, int krdyvOniDHbAt, int yKkohUKq);
    string TrDmkkUPtcWrT();
private:
    string KASRuWYph;

    void aimgawf(double mckdctFvrmnHgM, bool dVEseDujZDqe);
    string reLAOpqwUean();
    string wrIJDT(string ajFZxYrfdDxaIAm, bool QFPDmzCZQoPwmWW, string DzJstNuzPiDKPOD, string mnsFQveAUSVG, bool osbTg);
    string WSJCQHFprVPbzYS(string kRkxINozb, double xQXfnMLObhP, bool FMBnUQqrvJcY);
    int nUvKkB(int CVurcVlGvsUWawmm);
    bool aTpBbhzCZO(bool QTTbJvodTVtaPuRK, double VnQnDaFPKITzKk, double VhlBnittBZPNp, string dLqmN, int BYpdC);
    string CmGTEeFWYuS(bool oYDVYxFuJune, bool UYkSqGMjHJMMMVx, bool LHfIId, bool qrkbS);
    string nCnSFronYDPER(double ZlKGVWV, int ehAZGI, bool HPbEZXMXxdZvOAS, int GsTPzIyrLqIxDks, string fkspRzx);
};

bool AGPFSAROFWwFMYH::ZzQKeqwTrYhcOQy(bool LtSOa)
{
    bool tESaWgquYjH = true;

    if (LtSOa == false) {
        for (int VcVUG = 934673244; VcVUG > 0; VcVUG--) {
            LtSOa = LtSOa;
            LtSOa = ! LtSOa;
            LtSOa = ! tESaWgquYjH;
            LtSOa = ! tESaWgquYjH;
            LtSOa = ! LtSOa;
            LtSOa = ! tESaWgquYjH;
            LtSOa = ! tESaWgquYjH;
            LtSOa = ! LtSOa;
            tESaWgquYjH = ! LtSOa;
            LtSOa = ! LtSOa;
        }
    }

    if (LtSOa == true) {
        for (int HmVUpV = 886936528; HmVUpV > 0; HmVUpV--) {
            LtSOa = tESaWgquYjH;
            tESaWgquYjH = ! LtSOa;
            tESaWgquYjH = tESaWgquYjH;
            tESaWgquYjH = LtSOa;
        }
    }

    if (LtSOa != false) {
        for (int llxBJEuqJJl = 550338619; llxBJEuqJJl > 0; llxBJEuqJJl--) {
            LtSOa = ! tESaWgquYjH;
            tESaWgquYjH = tESaWgquYjH;
            tESaWgquYjH = ! LtSOa;
            LtSOa = ! LtSOa;
            tESaWgquYjH = ! tESaWgquYjH;
        }
    }

    return tESaWgquYjH;
}

string AGPFSAROFWwFMYH::sPVCIKXYfniFCCzF(bool tQEjcbKYOsKLK, bool brxLYEHRDHjFdQxh, string ohojttWsddj, bool hNxmZ)
{
    bool PaQZhY = false;
    double PFzCDlVsAuBOP = 848757.4610495847;
    int wAgohyplIQU = 179937831;
    string aqXnFGzpxxAD = string("cTDnaYZSzkoVfl");
    bool KAOgQhfdDrtp = true;
    string vKKKOvsksXdHxQx = string("YBEoUQwkinAwOZPqbISOJBKAGxROuncrXvtPYYGFdOZUuCHeErkktcnueVzTlXJdpYqiAbGSvLlPBQCkMGXyiXEkqXCzqTODEzwcJYnUxvAPPqCXRRlfpunBTAekFaHQbBpyHvGjrzLynYUoXlELgHRjdUBlHupLhWpm");
    bool ZnHHstZjVSthRqK = true;
    bool dbfcsDHrwqTlLH = true;
    bool HpVpiRmUTI = false;

    if (ZnHHstZjVSthRqK != false) {
        for (int mNArHSjeX = 1716733980; mNArHSjeX > 0; mNArHSjeX--) {
            brxLYEHRDHjFdQxh = dbfcsDHrwqTlLH;
        }
    }

    if (tQEjcbKYOsKLK == true) {
        for (int RCgRRklqHK = 1121027518; RCgRRklqHK > 0; RCgRRklqHK--) {
            continue;
        }
    }

    for (int WUQBvGLiW = 2070772200; WUQBvGLiW > 0; WUQBvGLiW--) {
        brxLYEHRDHjFdQxh = ! brxLYEHRDHjFdQxh;
    }

    return vKKKOvsksXdHxQx;
}

void AGPFSAROFWwFMYH::zOWdKbWmQf(double cprgTaDt, int LhccwDtfApKrWDsC, double oHjQV, int krdyvOniDHbAt, int yKkohUKq)
{
    string lkZXZS = string("ObGrdBDnQNqzFQPnlkdczXTDbEamZnYjIFGddYutHQOcnFxKgpenJmzdkPsfcLRhYiLTJpfFLuuqJvosbRaZhfYKRAkSvKWICoKJoeiAZaIMvDwpCRZkzurIJxPSOxyCAWEaifleniePeFGwiKHAZbtXIMwtCxEAibtEDaBvFNaFRXsYsVQUmhgJMQTqjyFzzomsXlnsJXeCVVAb");
    double vJakL = 95541.2201905194;

    if (lkZXZS != string("ObGrdBDnQNqzFQPnlkdczXTDbEamZnYjIFGddYutHQOcnFxKgpenJmzdkPsfcLRhYiLTJpfFLuuqJvosbRaZhfYKRAkSvKWICoKJoeiAZaIMvDwpCRZkzurIJxPSOxyCAWEaifleniePeFGwiKHAZbtXIMwtCxEAibtEDaBvFNaFRXsYsVQUmhgJMQTqjyFzzomsXlnsJXeCVVAb")) {
        for (int sKNxKEm = 580701563; sKNxKEm > 0; sKNxKEm--) {
            oHjQV *= vJakL;
            cprgTaDt *= cprgTaDt;
            yKkohUKq *= krdyvOniDHbAt;
        }
    }

    if (cprgTaDt == 95541.2201905194) {
        for (int iSDEWKVPYdpX = 741616787; iSDEWKVPYdpX > 0; iSDEWKVPYdpX--) {
            cprgTaDt += vJakL;
            oHjQV = oHjQV;
            yKkohUKq -= LhccwDtfApKrWDsC;
            yKkohUKq /= krdyvOniDHbAt;
        }
    }

    for (int KfBlgwgZdJVX = 701507176; KfBlgwgZdJVX > 0; KfBlgwgZdJVX--) {
        lkZXZS += lkZXZS;
        oHjQV -= cprgTaDt;
    }

    for (int mDFlkjPqZ = 1596751607; mDFlkjPqZ > 0; mDFlkjPqZ--) {
        continue;
    }
}

string AGPFSAROFWwFMYH::TrDmkkUPtcWrT()
{
    int AQnNRZJJejj = 816526269;
    int GPWpxQYEbPEJFKn = 1894463003;
    double KqdEKrI = -662139.0707582278;
    int oOIlQrZcQGFF = -720916508;
    int RGLarLoJh = 52453031;
    string SdiPyr = string("vbCnlCjoaQxEIVsrHYXffkdOaWyllhogBwMbDJeVuGpNwIDhwNAKxzrUCiQildFqXhlSxrJzlIvsoDhPXfBSmwCopVsDQHsMqEGh");

    for (int JjAQssADGwqHnt = 1736612249; JjAQssADGwqHnt > 0; JjAQssADGwqHnt--) {
        KqdEKrI += KqdEKrI;
        AQnNRZJJejj -= GPWpxQYEbPEJFKn;
    }

    for (int kyakshhFcmDiVC = 1429896970; kyakshhFcmDiVC > 0; kyakshhFcmDiVC--) {
        oOIlQrZcQGFF /= oOIlQrZcQGFF;
        RGLarLoJh = AQnNRZJJejj;
    }

    for (int OklmpSCazerQbHUb = 1434075359; OklmpSCazerQbHUb > 0; OklmpSCazerQbHUb--) {
        oOIlQrZcQGFF += AQnNRZJJejj;
        SdiPyr = SdiPyr;
        oOIlQrZcQGFF += oOIlQrZcQGFF;
        AQnNRZJJejj -= RGLarLoJh;
    }

    return SdiPyr;
}

void AGPFSAROFWwFMYH::aimgawf(double mckdctFvrmnHgM, bool dVEseDujZDqe)
{
    string GPHaAaKZnjh = string("BGhDUWdtdrJHfILtqPLLaDOLCVgZXTTqXbGctUpepJIEzVTzGfkpdCWBJbkYwWUZNLpGhwBKuvGqWAumaHfytBNicGilywJrMiXcRArqpxAxPQpUUnLxKUwJgdSIMhOFvUvRIpPOQnNfnBYUIOGyTEiuKvPczEWdsBaZMYvSsiWUFYZjogowVseiQWXayRyHIJegBWtveboVDEBTZBkvUvkJVSFrwPDYJZpCWjvFodWOfSGfEHEcesg");
    int NmItZr = -2017915620;
    string sxjqoj = string("aSQegAmvVgIApCyHQJnxrqIIjcwfZKFiDISFRPGomHuxwbsczNqVucPeOAvxGeSiPKwqQkVLcqWVwqYxVYvHNJVovxrpzZOymJiFkadgphOQZOSDyDxRHZmzegjCJklmsYOLDDMLJtgbHTqAMTnqkyHACpATEDxMwsYeHAtUPdjcFcoGfpPtaVPPfTMmYhrfJSUt");
    string ZCyfFTX = string("JyFGcSnJjHoRCyEHtIqbUZUYmLvUKdgcvxrijvhfUzBoJjMpCchjtyOTxqWLFIVhgxXKCynspGJgrwRzESGWkruNXeOJPhbFMBlqTglGCOtpjRtbqzSdNBBleFgWmBfBDsgBNVCPeGcwgqVqOKZlWmBMByyeQmUQiqUvdFSiaLwCWaAkXjuGuQyIdMccvnupBKkmqJYMALEzqbpkTWVbDFqHVvilWbiTdTkjSXtp");
    bool xkGPtHzWruBTOdrn = true;
    string pBIwbTUTOWonmbPo = string("TUEEFInUsPDBTuutYQCLMDgDBYKzOjnnRVxxoypANBFQXMgkmCOmhQLsscESiYYIAqEEKOIrWECnEVTjpLlZjoGSQBKzSLlkOlfhUAivCpRXYdFUFMgiSqsGCkweTgnskAkJaHONxNYplXrWQQiUxFcFrkxJvBDeuBMJe");
    string jPsZSqEYBRrJXLW = string("USlWADYLhDeaGzcKWcsTaSemwEyTgMaAhSkjVOxTdSIPEjpJUpOaCjuIiVlJEpLmkrkSUtRNmNPZxtveQOIGLOemHwQvgOMWqUKmCQmctnkhxDNyYAWeJRBhUKWNbTRzROzwLldaPLjfkHzvOqUSOcQSjroyiajMTYxqpGmZReIUOEvyYkXzlmRPhEOuRpezWY");
    double QUbvNaIpu = 380794.94741484715;
    double QvjYNBBAzLDZzIiM = 282249.9484767369;

    for (int DJIBchukEX = 1228424064; DJIBchukEX > 0; DJIBchukEX--) {
        QUbvNaIpu *= QvjYNBBAzLDZzIiM;
        pBIwbTUTOWonmbPo += ZCyfFTX;
        xkGPtHzWruBTOdrn = xkGPtHzWruBTOdrn;
    }

    for (int mjHHunRi = 1769138675; mjHHunRi > 0; mjHHunRi--) {
        sxjqoj = jPsZSqEYBRrJXLW;
        sxjqoj = ZCyfFTX;
        GPHaAaKZnjh = GPHaAaKZnjh;
        xkGPtHzWruBTOdrn = xkGPtHzWruBTOdrn;
    }

    if (pBIwbTUTOWonmbPo > string("JyFGcSnJjHoRCyEHtIqbUZUYmLvUKdgcvxrijvhfUzBoJjMpCchjtyOTxqWLFIVhgxXKCynspGJgrwRzESGWkruNXeOJPhbFMBlqTglGCOtpjRtbqzSdNBBleFgWmBfBDsgBNVCPeGcwgqVqOKZlWmBMByyeQmUQiqUvdFSiaLwCWaAkXjuGuQyIdMccvnupBKkmqJYMALEzqbpkTWVbDFqHVvilWbiTdTkjSXtp")) {
        for (int puIKZkdjgYSU = 1795335226; puIKZkdjgYSU > 0; puIKZkdjgYSU--) {
            pBIwbTUTOWonmbPo += GPHaAaKZnjh;
            QvjYNBBAzLDZzIiM = QvjYNBBAzLDZzIiM;
            dVEseDujZDqe = ! xkGPtHzWruBTOdrn;
        }
    }
}

string AGPFSAROFWwFMYH::reLAOpqwUean()
{
    bool OmkLlZQbauI = false;

    if (OmkLlZQbauI == false) {
        for (int fvprOBW = 539207482; fvprOBW > 0; fvprOBW--) {
            OmkLlZQbauI = OmkLlZQbauI;
            OmkLlZQbauI = ! OmkLlZQbauI;
            OmkLlZQbauI = ! OmkLlZQbauI;
            OmkLlZQbauI = ! OmkLlZQbauI;
            OmkLlZQbauI = OmkLlZQbauI;
            OmkLlZQbauI = OmkLlZQbauI;
        }
    }

    if (OmkLlZQbauI == false) {
        for (int NqmukL = 1011629302; NqmukL > 0; NqmukL--) {
            OmkLlZQbauI = OmkLlZQbauI;
            OmkLlZQbauI = ! OmkLlZQbauI;
            OmkLlZQbauI = ! OmkLlZQbauI;
            OmkLlZQbauI = OmkLlZQbauI;
            OmkLlZQbauI = OmkLlZQbauI;
            OmkLlZQbauI = ! OmkLlZQbauI;
            OmkLlZQbauI = OmkLlZQbauI;
            OmkLlZQbauI = ! OmkLlZQbauI;
            OmkLlZQbauI = OmkLlZQbauI;
            OmkLlZQbauI = OmkLlZQbauI;
        }
    }

    return string("BpcxdsFUOBelqfZchCaszgNKCdgNBBmhYsyzfOlShlPxMFMs");
}

string AGPFSAROFWwFMYH::wrIJDT(string ajFZxYrfdDxaIAm, bool QFPDmzCZQoPwmWW, string DzJstNuzPiDKPOD, string mnsFQveAUSVG, bool osbTg)
{
    double xkEFGcDYIqt = 178433.7001562641;
    string SZmpMTfWxUjURsoZ = string("jvoCDVEdmBNQCmNQXYASnApwdiayvTrdVbgXHjuoWMCxTylwrcGZllmXAxEnShmPcBpOQBmgkgvqOjOZMTKjVnvaxhrPbhWIJBfwgZEcUcMORIgBGKZZnbmjaCmd");
    double ojyTXBPEei = -735007.5352249461;
    string nNBvLtAdSSVV = string("ylgBbOmwETsLVKFYNniBqdCWcXjluXZXQOGfkyZFnbkWdvbMKKYOnExIRjbCgWJyJkaZcgRmgCtdwTTNmJXBerBsuKpkRglldAgWsD");

    if (SZmpMTfWxUjURsoZ > string("wqjvOiaIPCoKQgnGUyPsX")) {
        for (int uThRe = 355434132; uThRe > 0; uThRe--) {
            mnsFQveAUSVG += SZmpMTfWxUjURsoZ;
            SZmpMTfWxUjURsoZ = SZmpMTfWxUjURsoZ;
        }
    }

    return nNBvLtAdSSVV;
}

string AGPFSAROFWwFMYH::WSJCQHFprVPbzYS(string kRkxINozb, double xQXfnMLObhP, bool FMBnUQqrvJcY)
{
    bool qmKpntkOhDQDnl = false;
    string TIMZOtUMgu = string("JdBpyzNBwMHYoziQxHGwNNggtDII");
    double wAdbH = 440857.4936727099;
    double NCXsZdQqCDrKXWQ = -573857.6428052653;
    double BQEIQwMe = -310268.29915026145;
    int laYVjUQmNRXUQXP = 1554790496;

    return TIMZOtUMgu;
}

int AGPFSAROFWwFMYH::nUvKkB(int CVurcVlGvsUWawmm)
{
    string TfrLnbLOSCNOgZgL = string("pfsZketRifSZYMtYniCiXOjrmUyRhlbKxysVGfxcgggvMPaZQGnVcMcAWFSuDgYUqprcPYWdTRmzJHFyvjporfVfLmxhaiihpPclaKqeliPmrhBbxtu");
    double mmkHpuiS = -361180.43652849965;
    int MjWNhsbD = -352402271;
    double LSWxk = -15729.160154953925;
    int qyYQPjFfuXvqe = 1968353716;
    int RYYSq = -992465286;

    for (int tdLIvZFvZxUZ = 2141951297; tdLIvZFvZxUZ > 0; tdLIvZFvZxUZ--) {
        TfrLnbLOSCNOgZgL = TfrLnbLOSCNOgZgL;
        RYYSq += MjWNhsbD;
        TfrLnbLOSCNOgZgL += TfrLnbLOSCNOgZgL;
    }

    if (MjWNhsbD >= 1968353716) {
        for (int MLDdFetgCrKqrs = 1333530541; MLDdFetgCrKqrs > 0; MLDdFetgCrKqrs--) {
            RYYSq -= RYYSq;
            qyYQPjFfuXvqe = qyYQPjFfuXvqe;
        }
    }

    for (int vAADoEGqHrT = 1068664140; vAADoEGqHrT > 0; vAADoEGqHrT--) {
        TfrLnbLOSCNOgZgL += TfrLnbLOSCNOgZgL;
        qyYQPjFfuXvqe = qyYQPjFfuXvqe;
        mmkHpuiS -= mmkHpuiS;
    }

    for (int ZyhcBGxaBo = 749094133; ZyhcBGxaBo > 0; ZyhcBGxaBo--) {
        qyYQPjFfuXvqe *= CVurcVlGvsUWawmm;
        qyYQPjFfuXvqe = qyYQPjFfuXvqe;
        RYYSq = CVurcVlGvsUWawmm;
        MjWNhsbD /= qyYQPjFfuXvqe;
        MjWNhsbD *= CVurcVlGvsUWawmm;
    }

    if (RYYSq == -352402271) {
        for (int iTvEwMbYhcYPZae = 364731934; iTvEwMbYhcYPZae > 0; iTvEwMbYhcYPZae--) {
            continue;
        }
    }

    return RYYSq;
}

bool AGPFSAROFWwFMYH::aTpBbhzCZO(bool QTTbJvodTVtaPuRK, double VnQnDaFPKITzKk, double VhlBnittBZPNp, string dLqmN, int BYpdC)
{
    string IePFXYUbgIb = string("ZTbgoSggDvStpFrMBNySKynyCqXYPXhplDzJvHeWWrKIfvXucXYybMtsQhXcjUJpRGcRYGhJqgcuhyaZBLgPUYOnEmfOMDnjaeSswxEmkrAIxMahYXAyKnmVHsujOvwFTOAvcDsEFSPhnvpJcuxytrVhsXcnrNawmKrvjCSdfNHObTlErYmtYQwJbzafTqHIzttkcpSlmuyZkepunYTbfqAqXageLbIiIZzFBkdayxwCFTLlc");

    return QTTbJvodTVtaPuRK;
}

string AGPFSAROFWwFMYH::CmGTEeFWYuS(bool oYDVYxFuJune, bool UYkSqGMjHJMMMVx, bool LHfIId, bool qrkbS)
{
    double HAiqAATDCo = 522962.66312130203;
    double Kftzf = -928318.848342261;
    bool xqkbosAWUmXEWqm = false;
    int uqsRAz = -532441889;
    int aKdknIgfTGTlhM = -641187921;
    bool lRCDD = false;
    double ZqKkHMhUjLTvK = -30464.87238923737;

    for (int GokLqPP = 1104880182; GokLqPP > 0; GokLqPP--) {
        HAiqAATDCo = HAiqAATDCo;
    }

    return string("FcwuoDfexjgpmWgfBxYMDlmTrcvuKNaqncmjxrGJqZfYPicYtXuhEGpyUvXNMPZYnQlwEBcksyyRRokIPlPtNfQzUxpVeJeMHmMXfGrJemNtcofYzUStGjBkCYseJPeoKCJrZykgnbxJKHviWWJaxzzzbgOXKEeKAFslXJXFliRBCZRbq");
}

string AGPFSAROFWwFMYH::nCnSFronYDPER(double ZlKGVWV, int ehAZGI, bool HPbEZXMXxdZvOAS, int GsTPzIyrLqIxDks, string fkspRzx)
{
    int rBwuTQ = 1968420974;
    bool kitOxAeNQl = true;
    bool ekcln = true;
    bool plBhppW = false;

    for (int qGQxGiptgln = 392796778; qGQxGiptgln > 0; qGQxGiptgln--) {
        fkspRzx = fkspRzx;
    }

    return fkspRzx;
}

AGPFSAROFWwFMYH::AGPFSAROFWwFMYH()
{
    this->ZzQKeqwTrYhcOQy(false);
    this->sPVCIKXYfniFCCzF(true, true, string("tFuCctmFhBVwDKsSygiTtpMihSdWFeqiHOwmwFecXAhPTrQVLQrGACnYBOpHICOvleYmGYZyKObUkCcoozOXSlgKlHAAOH"), false);
    this->zOWdKbWmQf(-905062.0787840001, -1023503118, 484379.0698395466, 770744618, 1252851759);
    this->TrDmkkUPtcWrT();
    this->aimgawf(356885.0077718375, true);
    this->reLAOpqwUean();
    this->wrIJDT(string("wqjvOiaIPCoKQgnGUyPsX"), true, string("gKWKaGpwYpVvUVanbOZMjjuElZxwjeUrfuUeKmQGygkOSkhhsGSVsLQHtkVJkBWgpYBAfDcJxFVQwMYuNQcPjTrOFDPInrcDwFphkadwFQAqUPaghBHZYlZKLiARWFtIyEbzuWzlrSARdGFXcFaRlRhibYjteaUbEbezDJDwpVrrBuEqxeQzwejEoeBWmcTq"), string("gBAHPXikiObaDwzuhBoZbjoyReXLeGeneHpescQtyyrKhdlXipaDvTxFslGXszqrpuExKwqNPtLVsWGJZfwhOVfqRveuvc"), false);
    this->WSJCQHFprVPbzYS(string("kzXPMumgHJYXonGjrFYhvJQChRSzREGbbmqgmwXsYIJuRXHZJiTynKDcbQBtQbIMWnzyjRJEkpjwpyYyixcxWRkNjOoPi"), -440515.4463588748, true);
    this->nUvKkB(171178044);
    this->aTpBbhzCZO(false, 884149.2333544375, -474841.9590558941, string("zSgaYnuzhEdNThRkuvnnvzNqXPLCUTwwjSruXoyHHpgBpexdaZuMwPhU"), 527469032);
    this->CmGTEeFWYuS(false, false, false, true);
    this->nCnSFronYDPER(-364346.51338332205, 988393400, true, 675031921, string("xtHeqcpXsWGfWLbwPCgwgYNSbnLtXFrEetaOdgBvQpqm"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JRspIiheXtAEhXdZ
{
public:
    double fitZjBpdAyagPLqX;
    double gmyCapXSJJM;
    bool yuiAMhmLMyx;
    string RrfppBYsRa;

    JRspIiheXtAEhXdZ();
    void HiFJxhUeGiNHOn(int vDRpNDqhQQuYQ);
    int QmsKD(string ftKEfpCcNz, bool vtbMdRNFNZE, double JVpJJNDKPKfhA);
    int CBGzFe(double mYKsItvihfsCA, bool WHVjNOfGlsY, int gklFaryizc);
    int foOwqLlOthmTkIJ(string pizSaUzHpBJtesT, double JbXgfBqVW, double sPTOzbqIEiD, bool iDNnnOEunDpyo);
protected:
    string RAnYxgvCetq;
    int ZxmAyCRnLAPXl;
    double cvEmSknXD;
    string SmejRsjhCSd;

private:
    bool UMHWNcGCzxuWlu;
    string ptCaHlPNhPXnXCrr;
    bool MRiOlamtofZEJeMO;
    string QwfzPnKxPOereHJ;

};

void JRspIiheXtAEhXdZ::HiFJxhUeGiNHOn(int vDRpNDqhQQuYQ)
{
    double IuGBzhcdvKRvYow = -696053.9570547857;
    double oHwdylzJsD = -394382.5683502467;
    double EbrTcnxtAnrAkXG = 186688.36453415995;
    bool eVIgxO = true;
    int dHQmogbPtdgU = -1123895301;
    double BvRFsf = 537353.5581953576;
    double LAUMQti = -93937.25440194625;
    bool wRQDDYmS = false;
    string WOhJxpyeQ = string("MziJZYDCgzpFsyAfUmtGmDbHIshjseOjEASwVNvflXUqVHjhxLdoqKJCLRKIEYfxCLyNbmvDEdmndCRz");

    if (EbrTcnxtAnrAkXG >= 537353.5581953576) {
        for (int sYAxjV = 1139447906; sYAxjV > 0; sYAxjV--) {
            continue;
        }
    }

    for (int YWHCTIUxaQim = 2126372565; YWHCTIUxaQim > 0; YWHCTIUxaQim--) {
        IuGBzhcdvKRvYow *= LAUMQti;
        LAUMQti = EbrTcnxtAnrAkXG;
        oHwdylzJsD += oHwdylzJsD;
        oHwdylzJsD = BvRFsf;
        eVIgxO = wRQDDYmS;
    }

    if (wRQDDYmS != false) {
        for (int qYLwSzXmDOubIC = 1666572188; qYLwSzXmDOubIC > 0; qYLwSzXmDOubIC--) {
            IuGBzhcdvKRvYow -= IuGBzhcdvKRvYow;
            IuGBzhcdvKRvYow /= BvRFsf;
            EbrTcnxtAnrAkXG += BvRFsf;
            eVIgxO = wRQDDYmS;
        }
    }
}

int JRspIiheXtAEhXdZ::QmsKD(string ftKEfpCcNz, bool vtbMdRNFNZE, double JVpJJNDKPKfhA)
{
    int zRskt = 759733533;
    bool iJmEfVpylcnaEf = false;
    string pxnVsWsywuoz = string("FoIRkyyzpHIgYGvGHZQErYDPIHotWcPiWjrDmt");
    bool pHdibQnxJMybtY = false;
    bool aHnrTRrtXzC = false;
    int XrApN = -1743556966;
    double ieCPUqxlrQ = 701034.460367193;

    for (int bdzylIZWJ = 1296180233; bdzylIZWJ > 0; bdzylIZWJ--) {
        pxnVsWsywuoz += pxnVsWsywuoz;
    }

    for (int icTLCYZmawr = 187632364; icTLCYZmawr > 0; icTLCYZmawr--) {
        vtbMdRNFNZE = iJmEfVpylcnaEf;
        aHnrTRrtXzC = ! vtbMdRNFNZE;
    }

    for (int YaeILIRg = 589746175; YaeILIRg > 0; YaeILIRg--) {
        continue;
    }

    for (int fFgjGUu = 813305004; fFgjGUu > 0; fFgjGUu--) {
        zRskt *= zRskt;
        ieCPUqxlrQ -= JVpJJNDKPKfhA;
    }

    return XrApN;
}

int JRspIiheXtAEhXdZ::CBGzFe(double mYKsItvihfsCA, bool WHVjNOfGlsY, int gklFaryizc)
{
    bool kjKMhw = false;

    if (gklFaryizc < 732397918) {
        for (int YtRdeDNTfVUsavq = 1578411477; YtRdeDNTfVUsavq > 0; YtRdeDNTfVUsavq--) {
            gklFaryizc += gklFaryizc;
        }
    }

    for (int mLAhqkgnNr = 2088448259; mLAhqkgnNr > 0; mLAhqkgnNr--) {
        gklFaryizc *= gklFaryizc;
        gklFaryizc /= gklFaryizc;
        kjKMhw = kjKMhw;
    }

    for (int cJunkVMKD = 830778021; cJunkVMKD > 0; cJunkVMKD--) {
        mYKsItvihfsCA /= mYKsItvihfsCA;
        kjKMhw = kjKMhw;
        WHVjNOfGlsY = ! WHVjNOfGlsY;
    }

    for (int PJvjbj = 1836496983; PJvjbj > 0; PJvjbj--) {
        WHVjNOfGlsY = ! kjKMhw;
        mYKsItvihfsCA -= mYKsItvihfsCA;
    }

    if (kjKMhw != false) {
        for (int hDlqnGnWBROQumN = 1256217884; hDlqnGnWBROQumN > 0; hDlqnGnWBROQumN--) {
            WHVjNOfGlsY = kjKMhw;
        }
    }

    return gklFaryizc;
}

int JRspIiheXtAEhXdZ::foOwqLlOthmTkIJ(string pizSaUzHpBJtesT, double JbXgfBqVW, double sPTOzbqIEiD, bool iDNnnOEunDpyo)
{
    string JsIacArxzwXiUGhq = string("lvPiAbHYrGpgqHorvbaHRQIXSeQalMXnZjDGVjbDHzNBuPFaKXhYgWKFOJncwtRoLfVjXToxvFswNOYuJuBkEBpvgkQJlVwusLQiWqmwfBXzgfSYeoDPnKpkITvPIMiaZPFiwsfzHZfiMktOxyNKnkQkOZmSweeVboMlfrtVjIVTGUwxGfURiedfHBqL");
    bool EvTCgpVRMPKH = false;
    string uqKvmTI = string("sQTCEXTMYjWgbyhOKssEWROSZrJtickDRnkVwxBdDxPgJrfHTJVtreQyDJkyASfyLFYiJklgHtTjyCQWEPuliypGPCJSxMttYQlFQusBooMMzACiEvAYBBFscyOjGJTtMHWTykLotQBAwrEJZYPbrxPoyLpgwfVspKMuaZenxDkdQGtIRDbipFGgCZGUYFhItCkCpomxroxLenMeUzp");
    double TzDepFOpGbxMR = 106850.93266859763;
    bool gIhdRTNwTkXP = false;
    string ShPIG = string("WwYHNlYcOdmsiNIujpmjwOXhjuvftAVTuoDosAGwmHGTmoSMypTlCQtoWeGZjkWaAUUwjezuCubwaZlVbIdouJPMGVbXBKDKFmkIlRTYiTwobWEapJsCIvUiSXPpekPFCDVReAPRkbryTCAlrCYnypcrvPktrKPKkxuTGEDkEIVopOiACIE");
    string yfqtYFQHS = string("wcIdTCbBrMGoBiNMqaAdtEHKUuTUsWKDoisg");

    if (ShPIG < string("sQTCEXTMYjWgbyhOKssEWROSZrJtickDRnkVwxBdDxPgJrfHTJVtreQyDJkyASfyLFYiJklgHtTjyCQWEPuliypGPCJSxMttYQlFQusBooMMzACiEvAYBBFscyOjGJTtMHWTykLotQBAwrEJZYPbrxPoyLpgwfVspKMuaZenxDkdQGtIRDbipFGgCZGUYFhItCkCpomxroxLenMeUzp")) {
        for (int yztGLLGKdSYPzK = 1127149920; yztGLLGKdSYPzK > 0; yztGLLGKdSYPzK--) {
            JsIacArxzwXiUGhq += ShPIG;
            gIhdRTNwTkXP = iDNnnOEunDpyo;
            yfqtYFQHS = pizSaUzHpBJtesT;
        }
    }

    if (uqKvmTI == string("wcIdTCbBrMGoBiNMqaAdtEHKUuTUsWKDoisg")) {
        for (int KqvXQDnG = 1808908190; KqvXQDnG > 0; KqvXQDnG--) {
            pizSaUzHpBJtesT = uqKvmTI;
            pizSaUzHpBJtesT = JsIacArxzwXiUGhq;
            iDNnnOEunDpyo = iDNnnOEunDpyo;
            TzDepFOpGbxMR = sPTOzbqIEiD;
        }
    }

    return 2069156920;
}

JRspIiheXtAEhXdZ::JRspIiheXtAEhXdZ()
{
    this->HiFJxhUeGiNHOn(1046545205);
    this->QmsKD(string("gXDHmEKlmjKnEfzthGXaecRpkehAgYysQwXNSlbFJFWERSjqUsJTEccaSYOONbYMdNuyvdgbMPbiDRJIngZjdofOCNpUKFwKLjSxUodXwZSLyYdcptFFNC"), false, 767356.9740099523);
    this->CBGzFe(123578.80086159369, false, 732397918);
    this->foOwqLlOthmTkIJ(string("YVCuOzuGqXQrINiwgmHCevIphjUEiztyGIZAnzqgNluLYHkFgVbiRzZOBAcXnlPMmpSVxhSlVTRoltnJeggsnKmbXKAuWoMVhzRcMImeaHhOuXbDTzTfxStWdzPMLeNPPaJjAGWDSCZzvIDtQCURsWYgmkEfOvExyLRXeuQzGujFkkWYYIKlbynxZTtZqFztqrUQjbOaRNFPulSsxaSX"), 779171.9140952562, -341120.5082052265, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uhWir
{
public:
    bool nTyxuwKAfSDB;
    bool KVeVArlNjE;
    bool YcWqOyxN;
    int SliRIyhct;
    bool RqACxtvbMLkd;

    uhWir();
    double tQyFwgkHrJI(int aykNOcbMSaKnM, string IETXTma, string UlgVGQeDWtAZJeWC, int bWseKOnWHDvLW, string TDUcsRPeXbHTr);
    int TYeXUo(string bGrAVVnnyHH, int FAMCxwORuP, int IfjSUrh);
    void LPkTjgQBg(int kZJwRVHlODyzj, double IssVErH, string JKDEvHyQYEj, string XfMkfI, int AQKThXcKcan);
    double cdCkDtWprvkqFs(string YMpqyJTbVL, int urlmjTkTaM, double pnxOBBzTgTbfMX);
    string utAiKxQPlHJkRE(int hcJnlPLUzz, double zelTxWrbZRZzA, double YTnAcQJI);
    int IfMkouA(double XIIbkXLngHfUmL, double SXJAcNBlRh, string gWamoaLPcawglr);
    bool RkXEfBWNIm(bool XJuGyVJmSMszCbc, double nZQfFh, double LWsxreqsVrL, string dLnGMSAlf);
protected:
    bool WEHrNSqlK;
    bool OaNWqmPMWcS;
    string NqNrfXDreeo;
    bool mSZLvPa;

    void CkAzWyUtXoNExy();
    int QHPovakr(int fnhaARuvuZDRLDQm, int ThoacdSjAYW, string ItnrPgpjLnMxeTeI, double ZvlJpQqUPh, int McVYPyarjNrN);
private:
    bool fowBwpXlXrbseEs;
    bool PvWLZHvX;
    bool plkijpZYgeSrjoes;
    double wlIzQ;
    int AYABMfe;
    double YvjKEycyRwkWNSf;

    string THjOOTZB(int hmAqMGDwIudwCsC, bool mSqGaxQjviPbhx, bool oEWnMYGNxkdFjFve);
};

double uhWir::tQyFwgkHrJI(int aykNOcbMSaKnM, string IETXTma, string UlgVGQeDWtAZJeWC, int bWseKOnWHDvLW, string TDUcsRPeXbHTr)
{
    bool MdnJg = true;
    int LGrgaaMVAGYY = 1215945914;
    bool cYoyeEhCqFcfCom = false;
    double pxoRhEtBtSsyfaF = 113949.77181545855;
    string sZwrPZg = string("LWRNDbLIWTGkNswvtlhQjitfHoBzfavOCxOUbYquQCPMKqbpkizpoRomJbkSsVOoaBjTHdaKkompjtbIrQlycujvLVSJNRvLxISaLOUsxICshKKiSnrcVDmytFwHTxXeIxFfpuxQAMQraEvYQdOqckUXZ");
    int CmAHguVxQF = -475735628;
    double EOnnLqsJYGinApV = 890745.1460606131;

    if (aykNOcbMSaKnM < 75283595) {
        for (int sksDTHeWVQDNzDG = 1817765134; sksDTHeWVQDNzDG > 0; sksDTHeWVQDNzDG--) {
            IETXTma = UlgVGQeDWtAZJeWC;
            UlgVGQeDWtAZJeWC += sZwrPZg;
            sZwrPZg = IETXTma;
            aykNOcbMSaKnM += CmAHguVxQF;
        }
    }

    for (int sajfOogvjKopVT = 2047521894; sajfOogvjKopVT > 0; sajfOogvjKopVT--) {
        TDUcsRPeXbHTr += UlgVGQeDWtAZJeWC;
        LGrgaaMVAGYY *= aykNOcbMSaKnM;
    }

    return EOnnLqsJYGinApV;
}

int uhWir::TYeXUo(string bGrAVVnnyHH, int FAMCxwORuP, int IfjSUrh)
{
    double WoLDNNvHmjemvOn = 762224.7099640447;
    int cIsXwRHzQWYr = -494888539;

    for (int nkxhKKE = 190382371; nkxhKKE > 0; nkxhKKE--) {
        IfjSUrh *= cIsXwRHzQWYr;
        IfjSUrh -= cIsXwRHzQWYr;
    }

    if (IfjSUrh < -739882695) {
        for (int RFYGQAMWTYehM = 1876535376; RFYGQAMWTYehM > 0; RFYGQAMWTYehM--) {
            IfjSUrh += cIsXwRHzQWYr;
            FAMCxwORuP -= FAMCxwORuP;
        }
    }

    for (int jfIsMsij = 738108826; jfIsMsij > 0; jfIsMsij--) {
        continue;
    }

    for (int ebSjyCjhOyOSy = 1898773984; ebSjyCjhOyOSy > 0; ebSjyCjhOyOSy--) {
        IfjSUrh = FAMCxwORuP;
        IfjSUrh /= IfjSUrh;
    }

    return cIsXwRHzQWYr;
}

void uhWir::LPkTjgQBg(int kZJwRVHlODyzj, double IssVErH, string JKDEvHyQYEj, string XfMkfI, int AQKThXcKcan)
{
    int DXyXMKUZhHySMg = 935863980;
    int TEsLW = -281916157;
    bool kSQjfSfKEyrCo = true;
    bool sLpDJCTfX = false;
    int VhIkUE = -1354796700;

    for (int TNJzErp = 1450549601; TNJzErp > 0; TNJzErp--) {
        DXyXMKUZhHySMg *= VhIkUE;
        IssVErH += IssVErH;
        TEsLW = VhIkUE;
    }
}

double uhWir::cdCkDtWprvkqFs(string YMpqyJTbVL, int urlmjTkTaM, double pnxOBBzTgTbfMX)
{
    bool sLcWADV = false;
    int dusqvEPbFvyc = -1882188977;
    string xCmRZcrGZvjdp = string("pzSrddFGQMagUdVyDzMietZEupcHqqfJHvAaacBCHOkILMnsNfxisZifpyUGwAUE");
    bool puuRVIF = false;
    string vWORFOHJ = string("eETdVWRBKCzHwPUBwsyiHZTqmpbpQsXkJdOKPYKpmqmYPBWGGncHlFXFwKbCxRTZziMFfLLLmtRERqoriypuBzkWgsAAtALqRbUHgmOSXBbdvVrbyqbdDFVbmVlwXenXcmkcQhSAKKgNthgtnDJayaPKFrkhbcHglKLzKnmFRQEYdfRFLaewvUzdmjzWjXctSUtQoRnCRhTkOQKDfvmZMpgKjRjcerLYgqfUzjdDvGqgtHqIzXnqlghCae");
    bool ilgSuzdy = true;

    if (YMpqyJTbVL > string("qbcaDYjqfDtravqByDAFcZDEMMwkJnYXItvBtWjimoYovKPmSgODFxPnJNoiZoUUpLxMmnChriNsaypdpnZAIHzbgZOzPgkLJqpXkaaHfthykDZOydvubIrnVdKxwUKRUsFlZQHzoUaiteosObOWBmQCnfjSWQwyqBcmytuiBnLRuzofFBLuAjxYEeWYtzQtztxEIMURlInlYDiJmSPJRnKhzRcO")) {
        for (int nuylrKoht = 799800923; nuylrKoht > 0; nuylrKoht--) {
            urlmjTkTaM -= dusqvEPbFvyc;
            dusqvEPbFvyc = urlmjTkTaM;
        }
    }

    if (YMpqyJTbVL == string("pzSrddFGQMagUdVyDzMietZEupcHqqfJHvAaacBCHOkILMnsNfxisZifpyUGwAUE")) {
        for (int dagKDOpNEByOsVR = 1965997687; dagKDOpNEByOsVR > 0; dagKDOpNEByOsVR--) {
            sLcWADV = ! puuRVIF;
            ilgSuzdy = ilgSuzdy;
        }
    }

    return pnxOBBzTgTbfMX;
}

string uhWir::utAiKxQPlHJkRE(int hcJnlPLUzz, double zelTxWrbZRZzA, double YTnAcQJI)
{
    double AxrappNLajoZDUmL = 1014650.3133877045;
    int ymxXunK = -1323083611;
    string pFksgArRiNApShR = string("XitwEEMMLIBcnDqqsedbONmuqJgfKlaDkZALXYfGexUxWZBhfbQLtmVykfLgjnQeswUVPgkKkNjyZvZLALnivdOnibcbSAyRNGQrbJmnaMXgjQjphoFQsbpLSdObeDkdHyVjEYqRuSmWEcfsBmiWiSWeDesslnJpIxrvXRVoZdSSEtTneQQYhaocobnpdtalplLHaYxHDHxEk");
    string AqKQEriRHCgojtQR = string("rpSrFDdNmKXVWgsGUiuwjNDecFHARTJUtQBKjzsyUabAKvsvdcRMUbWgvKaZEajiWFaLTOKEubrUSbRjVAzyhSLqLyWQzziPwvpRniiTSWuHneEmTTBUncenpLPzDPiwYBlmOeEkKLqyCwGAcYxFlkUctRlMCdjqjuHzbuyyxhZPyqnBRF");
    bool KurORetHT = false;
    bool MGwEpfmfuzPeBNq = true;
    string AzxaCOduKG = string("hhgUPvRWdrCEbgkfGOkMaGlLWLONaKsXBZZXteREsFXhOOXhkSPEAfqAmKbkFjUHVWwMBhPhw");
    bool FUqkM = false;

    for (int mfIehjdeQoCdyOhQ = 592979543; mfIehjdeQoCdyOhQ > 0; mfIehjdeQoCdyOhQ--) {
        continue;
    }

    return AzxaCOduKG;
}

int uhWir::IfMkouA(double XIIbkXLngHfUmL, double SXJAcNBlRh, string gWamoaLPcawglr)
{
    string PgUMvV = string("NrfWCDfrBfmjZYjxQvxmWNatKpbiALXmUrJFliLNPQVCKaqYZoPQKYzFqBPaxGgiqAdQBOsdKndyUWzHubpHYTbUBxkDkJYFBBpGBGDSZTwpnKvSHwHBfXcfpkvxOwAvTeHdAbLPBRfrWnEnbCSBXifyveyhLtekCsZdkPalgvVnoWKGoZiTGsuQMNa");
    string whpQjtqQwpqf = string("bLCXHCfbbgInmHNTsJWFzGtiAUBdjeSVQRExsAPMtMljh");
    string zJTRHBuHJbnk = string("jAMzntCgidvzEtcfZIVXNPkwwitOnuHNYraSKEiJRz");
    double mQvmp = -314851.10530957556;
    string LmvdmA = string("xdQbvXxtkMhoYgCzTgeBnIISzyMDXARmLjXhqFCJRTykwrMxFNqTqwbJuXtHAwVjaxCFVVtQRErlLlUBOBKjZTXqwNxgZfuivRFLdaXRDUAHHdAWrkhaoQhPrHhcqgPGccUmfIYKMjWTZjmGNWKrmoxpkUWTuQkTMCguCfYAy");
    string frcsdRkKdoYenGDI = string("zSQljPYjEPIphWMKXBBixCgpfLzjCJGeLNwMYOEPCaCtYCbSjLNSYbkUMroFTlxELNHjSMJWPhSXikCfSaEklDTydOTCFrIfmtrEnCGiVmuXxYAkFELFEBJRdfkccIuWaAoyILVLYdMdXXlDIedRWkuTaCryNckDbPhIrIdNHwIAboKXVQmvAOyGTWoReYjQmzzCAtQORL");
    string sTpwKIzZygp = string("krOeTCjCftildyfQoEgKHjOzDltlkJeaSyHObYSVQgChBNqxtvgRZVtZiWoYzjMqBQUEIordGKRLDhSIwEFjRrqbamLNbDHEnznyGBzwrNSUPBsoDRaKjCpzqKAUSzNBriMMteelqXSVFCPeqUlDlYJqiXiDtyHqKZfwZLclzBPVRshLLmTaFzAodoqigDBzTPvtanTwbREZYlSJsviAYYHuWmCVenHsXghHRAvTUbELjBq");
    bool dMBaJYmKVkUaxLf = false;
    int QqDdxQKjjPyK = -50133979;

    for (int RcjBqWgGevFB = 828303226; RcjBqWgGevFB > 0; RcjBqWgGevFB--) {
        frcsdRkKdoYenGDI += PgUMvV;
        SXJAcNBlRh += mQvmp;
        PgUMvV += LmvdmA;
        whpQjtqQwpqf = gWamoaLPcawglr;
    }

    if (PgUMvV == string("krOeTCjCftildyfQoEgKHjOzDltlkJeaSyHObYSVQgChBNqxtvgRZVtZiWoYzjMqBQUEIordGKRLDhSIwEFjRrqbamLNbDHEnznyGBzwrNSUPBsoDRaKjCpzqKAUSzNBriMMteelqXSVFCPeqUlDlYJqiXiDtyHqKZfwZLclzBPVRshLLmTaFzAodoqigDBzTPvtanTwbREZYlSJsviAYYHuWmCVenHsXghHRAvTUbELjBq")) {
        for (int FkJNs = 1601869219; FkJNs > 0; FkJNs--) {
            zJTRHBuHJbnk = zJTRHBuHJbnk;
            PgUMvV = LmvdmA;
            sTpwKIzZygp += gWamoaLPcawglr;
        }
    }

    return QqDdxQKjjPyK;
}

bool uhWir::RkXEfBWNIm(bool XJuGyVJmSMszCbc, double nZQfFh, double LWsxreqsVrL, string dLnGMSAlf)
{
    double NJpmJPpoV = -902114.0035847069;
    int iLHDcNsN = -456822925;
    double yjAEEGFcifjY = -64031.88699781397;
    int nMeKg = -2096933140;
    bool aJrTyH = false;
    int onhFHV = -1090573205;
    double HdWGxZgprJw = 662711.3623708675;
    double KroklpKviv = 471603.55247663194;
    int XfshU = -1055625069;

    return aJrTyH;
}

void uhWir::CkAzWyUtXoNExy()
{
    int WAQNjjw = 1348987281;
    string GESUQcCjcUckL = string("oiiOVBEComOjdDSnXloZD");
    int AdPJyHIQ = 429432253;
    bool EwKUzuyKBGNgDN = false;
    string vODDogVuvpRrAI = string("BrwpInwuxdfRRqENMXJviBXPlOsWrFSFVsqrvJOgYIajQdhcyAtKOydZeBvxfIsooQXbjESrCORpxzPPkFyoiMVxNwQQmaLMUQAOrdcVkNHSRwxkgFsHXXUweubTxiJGdFwefUniRBHTvKCQdLxCTyyCEljlyZRDPhDrSRRFqOzlVfUPrVHZHTGOmcAdfIpKLljhLEGhwXzZObVZxzEf");
    string HOFRWS = string("eKxmIFXmBKCesPTtwoLMfCYCwsOtwMWCTTXbSmJxmKkqQRBtIpinslMKwhZrvsQnXNlSNZqvKLihcVQOIECjoKsACBAcSsWOGKjNomGLJSOIkWbESAkqFFxXhDpODVQqcqxcvtfxDtUxHSYDcgOdSKSUyBRtRQckUEsxtVjXJpPYuZQpizlkexMGnodABCbuHBFxEHBusbspYJDVuJStRfBMyDCydTCtARRwolvIdDduNxSsElEsDYDlxjuVST");
    int XkEUwr = -1644007869;
    bool VRQTWmJTjE = true;
    bool sHOtKZ = false;
}

int uhWir::QHPovakr(int fnhaARuvuZDRLDQm, int ThoacdSjAYW, string ItnrPgpjLnMxeTeI, double ZvlJpQqUPh, int McVYPyarjNrN)
{
    bool mgLTlXM = false;
    string vlxkHGkVIxi = string("mBkECtYZWcbkHWCgrrSCYbRkFtPxEOEHpBLFqPaPcwqvnaUMaJoHPkWnhKTGFIImqrNuDmevkQRcnwEfxsMkVMOQqNRPJnKltIoVmYxHXWRkBXZEilRCQGtxBbWNHplqTGqOFvIoAGyCVBBUuVjWmvrbIOwVLiWlm");
    int aQrsdQFnBCjtMm = -2139636833;

    for (int qmioiGPQjqxr = 1772805281; qmioiGPQjqxr > 0; qmioiGPQjqxr--) {
        fnhaARuvuZDRLDQm = McVYPyarjNrN;
        McVYPyarjNrN = fnhaARuvuZDRLDQm;
        vlxkHGkVIxi = ItnrPgpjLnMxeTeI;
        ThoacdSjAYW = aQrsdQFnBCjtMm;
    }

    if (aQrsdQFnBCjtMm > -2139096630) {
        for (int HXaLkXbnQQeOyo = 1863429971; HXaLkXbnQQeOyo > 0; HXaLkXbnQQeOyo--) {
            McVYPyarjNrN -= ThoacdSjAYW;
            fnhaARuvuZDRLDQm /= aQrsdQFnBCjtMm;
        }
    }

    for (int dAecbXyaPUkkavmg = 1281531823; dAecbXyaPUkkavmg > 0; dAecbXyaPUkkavmg--) {
        fnhaARuvuZDRLDQm /= ThoacdSjAYW;
    }

    return aQrsdQFnBCjtMm;
}

string uhWir::THjOOTZB(int hmAqMGDwIudwCsC, bool mSqGaxQjviPbhx, bool oEWnMYGNxkdFjFve)
{
    string sdiiMfTfrb = string("MgOWzuvupxjDOpODdzeKRkUGLoofzpuwYGMNGfTLpXvsZRrSxAPnmkEwdPTzFthLdQhKtYtDnDZMoDgEtRPMxzpTagoczBoOLsFOmfdjAJ");
    int TDxXGmGrRaB = -456674281;
    double HfKzyXTZOJqy = 677402.5227263017;
    string KAJKPHkvYnY = string("ZHqzCNBVTtYvDTkCYSRIfvfaWIDATtMcxVDxZiLHCwzlhPSdGKSasIUrlJkGzBfzLozuldlTQxrEMmxoBjVcKtvJOucMFPZiYyOMnMssKVKnwkZalHJjDtPjPgKConXnsuLQRpuzJGkSBhcGwSNfWIhtAUmUMzeEgPNrFPzDFDniwEEbCPkLSGlpyYiemksKBuhtbjentsIcCggxDiuHRJRuwqFwXFUf");
    int OxqkVrLxKPo = -1294518742;

    for (int MoWgwNRDX = 524470505; MoWgwNRDX > 0; MoWgwNRDX--) {
        hmAqMGDwIudwCsC *= TDxXGmGrRaB;
        KAJKPHkvYnY += sdiiMfTfrb;
        KAJKPHkvYnY += KAJKPHkvYnY;
    }

    for (int jTaenrPzfn = 1030848525; jTaenrPzfn > 0; jTaenrPzfn--) {
        HfKzyXTZOJqy = HfKzyXTZOJqy;
        TDxXGmGrRaB += OxqkVrLxKPo;
    }

    for (int BcEHvUOZhMgvQNb = 1788849269; BcEHvUOZhMgvQNb > 0; BcEHvUOZhMgvQNb--) {
        hmAqMGDwIudwCsC /= OxqkVrLxKPo;
        oEWnMYGNxkdFjFve = ! oEWnMYGNxkdFjFve;
        hmAqMGDwIudwCsC += TDxXGmGrRaB;
        sdiiMfTfrb += sdiiMfTfrb;
    }

    for (int xFIwlysoeXyPS = 274642399; xFIwlysoeXyPS > 0; xFIwlysoeXyPS--) {
        OxqkVrLxKPo -= TDxXGmGrRaB;
    }

    if (TDxXGmGrRaB > -456674281) {
        for (int ynrzDjqXNdaExkXK = 1542230616; ynrzDjqXNdaExkXK > 0; ynrzDjqXNdaExkXK--) {
            sdiiMfTfrb += sdiiMfTfrb;
        }
    }

    return KAJKPHkvYnY;
}

uhWir::uhWir()
{
    this->tQyFwgkHrJI(1543679167, string("KrmWb"), string("SRuHnQRIbhTctSmPEsqOSswamNJPfEgHbfAYCxBEGoOwoMXRPHUvTrTtTerTzkBsPgRfmFjNvdQTGhYddsVVwyZKvGhwYYOPCsDGNBPEueFhGVeDUCJdJdeABWmIPUuoZJWPBSSqGJYDdqAiYxWiVzGYOIPTirDCCvOEDKPhXmKlgturIETBnFQveOHtdntCBJVEzHBaosBNNHiXGFyUVdMTjhVZTpQFlKTuHDzHaqiepACbNlXj"), 75283595, string("JJVWKimvNOoglwbxoHZLkICwXBNkqXVbQLcpvNlMakwhseNECCxGVpCAJpLiErFzJVtpdszLZKgNvWaxdxMmbVOXFMrOUlnnXoimgkvDaVBtuJGLdKITbcORuOmLznuzOsxOLcyKexaBcSQlffiQztGyCMrolvLItJulpySTLgLKSCrVBXypMBOALUsZdGXzweHRZrmWDmxHmivALPh"));
    this->TYeXUo(string("glMYrihEgvdwAUgiSWnhhpFiDbKrUBNPIpMDpegkPtnVwirgmSxpFTtdBryZMxQBnmwzkqiYJdsKGQDCzJrQhyhHawd"), -1268519065, -739882695);
    this->LPkTjgQBg(1923739262, -1044939.4242042495, string("lPnWTbzbqDsglxvShNpfEpTNYxDXlYbBvJrepFLANTkoUwXjiPvoLBkVyyPMSHcHiJdCVIdIEBwqyUZuMozEkmwdSXVWoFtgRZOtHGlUZnuHcIQfEuc"), string("rENBWgQBTnVFLtiotTWgaynlpybVHbNXEzIfrhxvuYpVCAAjKjMEVXpeuRNGRsKqgTBOQnCCoxoLqilTGNznxFkWqdaeQsPMZfrvlNVJsfjwjuabQDuFhYZxQrHDfdRBGlhkItsppVjukpKhTAwxTxrfMjbzYLalQNYrRPw"), 1541667486);
    this->cdCkDtWprvkqFs(string("qbcaDYjqfDtravqByDAFcZDEMMwkJnYXItvBtWjimoYovKPmSgODFxPnJNoiZoUUpLxMmnChriNsaypdpnZAIHzbgZOzPgkLJqpXkaaHfthykDZOydvubIrnVdKxwUKRUsFlZQHzoUaiteosObOWBmQCnfjSWQwyqBcmytuiBnLRuzofFBLuAjxYEeWYtzQtztxEIMURlInlYDiJmSPJRnKhzRcO"), -2098886187, -675231.7985699191);
    this->utAiKxQPlHJkRE(-528983361, 294588.01120796846, -533475.5422684369);
    this->IfMkouA(-877671.1225866491, -680902.0257946376, string("MCtCzcFbtNuAyLrGcApmdjKAFABNzrlRWnZjEgMOAMcACDtJMvbNvJbLcVnQvNWZXtKHNuvBqduFkBPAsVayTlvnnFwXRlhWpTODkffHwtKAtxItCfpVrkYrCFknVQzpvEUtfnDrwVppzwYaPxATBbEdOflLhzxevthHupXXkWAUEQIbaHqNCJqqNZNmlFugiSIuuGwevmYPrTKdMLdczcENSdsIjAAtmuAhHkt"));
    this->RkXEfBWNIm(false, 683090.174436743, -1015330.196055761, string("OnTEeWUsKItQaZDSBhOinIPDVIzlwnStbfXpvCMidkUALqqqREYcVoFvIMgkKEDVsGieIsOWqOYHwIWmnpxpNvzRsWZCjiiifXlAqqSgNaXl"));
    this->CkAzWyUtXoNExy();
    this->QHPovakr(-1057334141, 989089397, string("nbgCkapGaLzBrrzSvZpFIULpqMoSzDgomcIPoTeHDWPMIzGhRrGCKrkFkCjNsxqHEeGQLWpQAzYZkcLuyywaYQQVjXnTnZGkUZsSTczUlIsNqbqZaCLiWRedKbSjfkBOlKCntXQzYSzpVfjbLKwAwHFKzIQiiMHiZEwICWJrZquanaavceXqWzYdlcZyIxRTkzPFuRKBtSGUJhnjoRGviYVZYoxTmekNqQWIZVkWvihNKPFVgDgOdvfVbeiqoIP"), -39655.461731625845, -2139096630);
    this->THjOOTZB(1159753057, true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jhohdYMqjCvgKoM
{
public:
    int fNkDJOyQFwZQ;
    string OGDLudjeFSCZUH;
    int EzHne;
    bool DdfkqwyzPOBGHt;

    jhohdYMqjCvgKoM();
    double qrFdQYhVUu(string PeThuwNO, double aPTfhL);
    double RlPKfpUryMoQo(string EdgnaqPmkiMyA, int WhSWU);
    void MAgERtUKlArX(string jqcXYdkA, bool EgsuV, string KXLFxe, bool rosBqLsTUGvJASCR, int ltFTYgannNnQ);
    bool JWjzVvCEs(bool yikxXsw);
    string QsgBTxLsaK(bool GGruQngZ, string kKaSSIhDYCYvOwU);
    string wYZNhZEWt();
    int rOweYeBn(string EPCCNjOZJ, int ORlaUTPkDwrdbt);
    int KJJyXRkRBfvkKZQ();
protected:
    bool xwbKsBJrN;
    double VJqPCoxMq;
    bool sslnSDGujcqWLqF;
    int vRdMtsBrdCZFkSic;

    bool OUAAOnWa(double ayKtYr, int DAwBgwGICzrKgRL, bool qIXssRdm);
private:
    int pUOBiBSIgDYVtE;

    int jPKDqGTFqpS(bool NVkiaADToISSZVV, string SlJvRQRGbpnb, double CyXxcwxn);
    string cpFjmHxaV(int RVlaAUzKbvLSGfJl, int OQjiFWi);
    bool rbzTJyYaR();
    void JcBMVUa(bool ZDFEL);
    void zKLGDh();
};

double jhohdYMqjCvgKoM::qrFdQYhVUu(string PeThuwNO, double aPTfhL)
{
    int iMDSEBEdumg = -1623046801;
    int kmaNDbxnlVj = -1991645241;
    int OgzWbF = 1850905675;
    bool DjLdc = true;
    double LhxqciPpWs = -265435.71532216924;
    int GsteDTcX = 2046149006;
    double QPfjGKYQNUtpKiUS = 212582.30824002158;
    int YBJXYnZhEtACig = 1269321226;

    if (GsteDTcX < 1850905675) {
        for (int roXuKneSAbcBfVKx = 1028564920; roXuKneSAbcBfVKx > 0; roXuKneSAbcBfVKx--) {
            continue;
        }
    }

    if (OgzWbF < -1623046801) {
        for (int fnmTWda = 555130154; fnmTWda > 0; fnmTWda--) {
            aPTfhL /= QPfjGKYQNUtpKiUS;
            iMDSEBEdumg += YBJXYnZhEtACig;
        }
    }

    for (int XubWmxVmkg = 721703193; XubWmxVmkg > 0; XubWmxVmkg--) {
        YBJXYnZhEtACig /= OgzWbF;
    }

    for (int YrVeTBuMaE = 856811786; YrVeTBuMaE > 0; YrVeTBuMaE--) {
        LhxqciPpWs *= QPfjGKYQNUtpKiUS;
    }

    return QPfjGKYQNUtpKiUS;
}

double jhohdYMqjCvgKoM::RlPKfpUryMoQo(string EdgnaqPmkiMyA, int WhSWU)
{
    int hAnLBAH = -2128555211;

    if (hAnLBAH < -2053089043) {
        for (int MxrgaLH = 609088667; MxrgaLH > 0; MxrgaLH--) {
            WhSWU /= hAnLBAH;
            WhSWU -= WhSWU;
            WhSWU /= WhSWU;
            hAnLBAH *= WhSWU;
        }
    }

    if (WhSWU >= -2128555211) {
        for (int gIPuedPzpJTY = 973287881; gIPuedPzpJTY > 0; gIPuedPzpJTY--) {
            continue;
        }
    }

    return 209386.0687110024;
}

void jhohdYMqjCvgKoM::MAgERtUKlArX(string jqcXYdkA, bool EgsuV, string KXLFxe, bool rosBqLsTUGvJASCR, int ltFTYgannNnQ)
{
    double ssonFZBPrR = -934910.2881485482;
    bool vnUynOR = false;
    bool UxXJgcQ = true;
    bool RwSYyAwoayrfkCYU = false;
    double cHTciLlJsvM = -869648.5234564086;
    bool iyutDVqnq = true;
    double RDKaKSfrRtu = 629445.3546073923;

    for (int fghiOLMTEowEXR = 1653855452; fghiOLMTEowEXR > 0; fghiOLMTEowEXR--) {
        rosBqLsTUGvJASCR = RwSYyAwoayrfkCYU;
        RwSYyAwoayrfkCYU = rosBqLsTUGvJASCR;
    }

    for (int HqGFFJUxWqRJ = 235577497; HqGFFJUxWqRJ > 0; HqGFFJUxWqRJ--) {
        continue;
    }
}

bool jhohdYMqjCvgKoM::JWjzVvCEs(bool yikxXsw)
{
    bool PTfZPwqIWUyqygp = true;
    string jsDyIZmQktdacB = string("qAsFUTEFUiaANJfSbDsTTYNpwgUugSvAaGkeSqCKrtHSVBkMifGZlINbwNONxLgwQvPwTgbiljScJWLlrmAWCGhnvrZqtjwrXSRXXFRvoAUPBzhwYnifcRQvsJuqACHQkyJcCNlobqjmKRQsfo");

    if (jsDyIZmQktdacB != string("qAsFUTEFUiaANJfSbDsTTYNpwgUugSvAaGkeSqCKrtHSVBkMifGZlINbwNONxLgwQvPwTgbiljScJWLlrmAWCGhnvrZqtjwrXSRXXFRvoAUPBzhwYnifcRQvsJuqACHQkyJcCNlobqjmKRQsfo")) {
        for (int PwTBTHzUObmO = 533159516; PwTBTHzUObmO > 0; PwTBTHzUObmO--) {
            PTfZPwqIWUyqygp = yikxXsw;
            PTfZPwqIWUyqygp = ! yikxXsw;
            jsDyIZmQktdacB = jsDyIZmQktdacB;
        }
    }

    return PTfZPwqIWUyqygp;
}

string jhohdYMqjCvgKoM::QsgBTxLsaK(bool GGruQngZ, string kKaSSIhDYCYvOwU)
{
    bool BnSUAmtv = false;
    double vraZhLCGFx = -582609.5307217218;
    int BrSyifbN = -1780033781;
    bool roJFfyX = false;
    double OVEEzBRTaJNNyJXp = -615924.4272069228;
    string DRARvDbAOnayuc = string("UQNbaGSRIYQtdSXTqUrRZWIUPeFxoIgEquphhsVWGfyEFAvSKPDSpKHYDCuLWyIllMdxhhxNNnSocCpJQkfVTxZIoRWtRlLGNxHMBYDARQwCgWWcykvouQLXxzj");
    bool paZWFMhbk = true;
    string BUFaIO = string("CfAmPxpzsvx");
    int ZxetqCUNjbJnQx = -1810315520;

    for (int DnDAYbnnAXxS = 1710739196; DnDAYbnnAXxS > 0; DnDAYbnnAXxS--) {
        kKaSSIhDYCYvOwU += DRARvDbAOnayuc;
        GGruQngZ = paZWFMhbk;
    }

    return BUFaIO;
}

string jhohdYMqjCvgKoM::wYZNhZEWt()
{
    string lhnYvkpkJ = string("oZGvOKFNwSGYjCCuQZgSNNtTXshtNxyCQEZBoLgnQHRzYmuEEDfbfZYcomFFfXiOvVfDaxYhCpmnMXpRdHPQTIVwJTySUateiAzrUVrCFmFyHoXQWwAjUEsKmsCaJgpqotiaBrqwOhsbAPlpsbMZvuZhDooUYrPnvkFDiFgdGsYnlDqVyErPHVhFtOZSBLsSBkzfdAkBigluqfMTGQ");
    string EySoEcIzpSCOkuG = string("SlsjlPhXxoiqHwzZHvIJseckGcQgwgBzvQlVDhylwrcDMKfloAVMfDKjmneCdUljGOLMHtUzjRkBevgWZoBEFsIRpfYCyKqHsEtTjeyylBewTYIYnXfMqthcwfXtxTStNUyRBIWdZnNyeMlArtQdRtDJlAEYjmqgcSZBETWEoiZin");
    string ZdNaxDMZ = string("MaYzYAYABcOuWBNhFmIEYmFuLBEHqrlVVxFgYrfabzwrwcnRhlJdJLZJSiGdAJkuxWjEQtRKHSoBiJxjYyAchwQQrLsmSZMxQeQFfDReeKQAPxNpsFVGWeRfuKshLwCRvbZHzCpwpUveGozlFBqWKoaoSqUExgPVmqQFLbFthEXNzQzgEpHDOMHyoiENqymAWangNcVrjbxnwLqeFZpRRKjCKNsrDWgW");
    double ssglnfdgONuvI = -543226.7526722321;
    bool PkYXxHzxOBIWQG = false;
    string ivroOdmIpgflAtrT = string("ioAZwpzNSvBzPcmaEaBlaEEoKVWutlAFCkhRVyDMHutkOTXywgxFYVCPJxPFatpnGpnGJyYOzXz");
    bool yfQrTLtWESYDV = false;
    bool gmMft = true;

    for (int gFUOURYr = 1664848508; gFUOURYr > 0; gFUOURYr--) {
        gmMft = ! yfQrTLtWESYDV;
        gmMft = PkYXxHzxOBIWQG;
        lhnYvkpkJ += EySoEcIzpSCOkuG;
        PkYXxHzxOBIWQG = ! yfQrTLtWESYDV;
        yfQrTLtWESYDV = PkYXxHzxOBIWQG;
    }

    return ivroOdmIpgflAtrT;
}

int jhohdYMqjCvgKoM::rOweYeBn(string EPCCNjOZJ, int ORlaUTPkDwrdbt)
{
    bool CMVPfGPYuVtJ = true;

    if (CMVPfGPYuVtJ == true) {
        for (int KTnxhiEutFPUhu = 49703335; KTnxhiEutFPUhu > 0; KTnxhiEutFPUhu--) {
            EPCCNjOZJ = EPCCNjOZJ;
            ORlaUTPkDwrdbt = ORlaUTPkDwrdbt;
            ORlaUTPkDwrdbt /= ORlaUTPkDwrdbt;
            EPCCNjOZJ = EPCCNjOZJ;
            EPCCNjOZJ = EPCCNjOZJ;
        }
    }

    for (int vTGhhynUPmFCXr = 1779554105; vTGhhynUPmFCXr > 0; vTGhhynUPmFCXr--) {
        CMVPfGPYuVtJ = CMVPfGPYuVtJ;
        EPCCNjOZJ = EPCCNjOZJ;
    }

    return ORlaUTPkDwrdbt;
}

int jhohdYMqjCvgKoM::KJJyXRkRBfvkKZQ()
{
    double NLCUhn = -656823.5107911075;
    string KVQykcLsrAFS = string("YfxrrhzGKmVkDKMkiNAhSCLDwMdvkFsCbmRRvenvXmMM");
    double lmuNQIlwjgzQdGuA = -380645.4211710011;
    double kzEyzSU = 586011.1858448841;
    string YpUGgabiunToo = string("YUCuBwRipYglGAQgBPUqpqBSUFJNDgrOKhFcPnTiinjNAVWqUVvjpyJokvNWRexWsTCfVwktJpMbILAeyICCeFIwAkThLUPLvoQmeS");
    double pwILay = -762808.8008891718;

    if (NLCUhn >= -762808.8008891718) {
        for (int YoLtaNyuP = 98241264; YoLtaNyuP > 0; YoLtaNyuP--) {
            kzEyzSU = lmuNQIlwjgzQdGuA;
            YpUGgabiunToo += YpUGgabiunToo;
            YpUGgabiunToo += YpUGgabiunToo;
            kzEyzSU -= pwILay;
            KVQykcLsrAFS += YpUGgabiunToo;
            kzEyzSU += kzEyzSU;
            pwILay /= kzEyzSU;
        }
    }

    if (pwILay != 586011.1858448841) {
        for (int NSVusYAGRujcO = 962715388; NSVusYAGRujcO > 0; NSVusYAGRujcO--) {
            pwILay += pwILay;
            lmuNQIlwjgzQdGuA = lmuNQIlwjgzQdGuA;
            NLCUhn *= pwILay;
            KVQykcLsrAFS += KVQykcLsrAFS;
            NLCUhn = lmuNQIlwjgzQdGuA;
        }
    }

    for (int ENgrlrjz = 730820565; ENgrlrjz > 0; ENgrlrjz--) {
        NLCUhn = kzEyzSU;
        kzEyzSU /= kzEyzSU;
        kzEyzSU /= NLCUhn;
    }

    for (int EcGFaoREh = 1107501257; EcGFaoREh > 0; EcGFaoREh--) {
        lmuNQIlwjgzQdGuA = kzEyzSU;
        kzEyzSU *= lmuNQIlwjgzQdGuA;
        pwILay /= pwILay;
    }

    if (NLCUhn >= -380645.4211710011) {
        for (int RUIPFI = 930053230; RUIPFI > 0; RUIPFI--) {
            NLCUhn += pwILay;
            lmuNQIlwjgzQdGuA *= NLCUhn;
            pwILay -= kzEyzSU;
        }
    }

    if (NLCUhn < -380645.4211710011) {
        for (int XkEivTxmcrZ = 327461266; XkEivTxmcrZ > 0; XkEivTxmcrZ--) {
            lmuNQIlwjgzQdGuA += lmuNQIlwjgzQdGuA;
        }
    }

    return -2017817454;
}

bool jhohdYMqjCvgKoM::OUAAOnWa(double ayKtYr, int DAwBgwGICzrKgRL, bool qIXssRdm)
{
    double HNXFjEa = 671383.271164614;
    bool svxsbPAlgM = true;
    string bmadnffAQ = string("hphYHSDGHFVIqjfSITIwJkyGuCvZPIBwGjzRWZcONEdUZJouPsWOKBLNcMMpxzkkiXODyBbTjKPYDppuwZuDZnOOuCnnVgOLnv");

    for (int XPOyZduahHwM = 73366524; XPOyZduahHwM > 0; XPOyZduahHwM--) {
        ayKtYr = HNXFjEa;
        bmadnffAQ += bmadnffAQ;
        HNXFjEa /= HNXFjEa;
    }

    return svxsbPAlgM;
}

int jhohdYMqjCvgKoM::jPKDqGTFqpS(bool NVkiaADToISSZVV, string SlJvRQRGbpnb, double CyXxcwxn)
{
    int gUWKGCxJb = 160716975;
    int PKYHXQgGxGfqoyxk = -1272266820;
    bool lwIvFutUYpurSIOl = false;
    string cIEvDJmljsHKHxP = string("qTyfqzBHiFirFWMZpjazWlqTJXwGqnedXMxeNpxSjXWCkVRIlKDSudhlbMNHdPXRvbufvZzbCdUaLEBfzUjJOoNHfhQNfPqEoQzlvJXRhbudQmVCkBWTDFlGWxNsptbxDGVwCUKcQKgOOqbiuufNUfipDXaXgBtJysuRZTmRkTBOojzKrxarmiXAsDjNM");
    string hYmzGKpgmANYo = string("hKZwGpmVTZadYhKBhZFxevnZuZDNNQRBruoaKPTsOhqtFClQNhenPzyWmzzzahSmfJXfsXgBheuWWkyjPPjfkBucHZPImAYMKRMpaGlmSOQPZlLYzG");

    if (cIEvDJmljsHKHxP < string("hKZwGpmVTZadYhKBhZFxevnZuZDNNQRBruoaKPTsOhqtFClQNhenPzyWmzzzahSmfJXfsXgBheuWWkyjPPjfkBucHZPImAYMKRMpaGlmSOQPZlLYzG")) {
        for (int ODWyypBxH = 552509415; ODWyypBxH > 0; ODWyypBxH--) {
            NVkiaADToISSZVV = ! lwIvFutUYpurSIOl;
            NVkiaADToISSZVV = ! NVkiaADToISSZVV;
            cIEvDJmljsHKHxP += hYmzGKpgmANYo;
        }
    }

    for (int tZewRQ = 1501238445; tZewRQ > 0; tZewRQ--) {
        gUWKGCxJb += gUWKGCxJb;
        gUWKGCxJb += PKYHXQgGxGfqoyxk;
    }

    return PKYHXQgGxGfqoyxk;
}

string jhohdYMqjCvgKoM::cpFjmHxaV(int RVlaAUzKbvLSGfJl, int OQjiFWi)
{
    double DcwQC = 1006074.3399538479;
    string brTbF = string("sftsHlcZPyTnYWVlIvufkbuvMzBqhonwfpYFQHuziXMGNqwoYCBqriXHBIwcsovB");
    int eOpxKjJ = 938727412;
    double sxDLkuJHKQzGNr = 244851.53256376187;
    double hIycosVWm = 922181.5348592944;
    string hqSqcLWng = string("VuvWiibyzDhzyAFngNdfpVPBoBYKzAfpaMPyiHypJ");
    int VmidCzL = -1342285958;
    bool YJvjNM = true;
    bool THGrF = false;

    for (int zdxlGfvOqobH = 1752573875; zdxlGfvOqobH > 0; zdxlGfvOqobH--) {
        continue;
    }

    for (int oYBPb = 697829128; oYBPb > 0; oYBPb--) {
        continue;
    }

    if (OQjiFWi <= -1120136) {
        for (int DKCecYUYhtc = 1334760085; DKCecYUYhtc > 0; DKCecYUYhtc--) {
            RVlaAUzKbvLSGfJl += RVlaAUzKbvLSGfJl;
        }
    }

    if (brTbF == string("VuvWiibyzDhzyAFngNdfpVPBoBYKzAfpaMPyiHypJ")) {
        for (int AcCFtOmmLzd = 251707083; AcCFtOmmLzd > 0; AcCFtOmmLzd--) {
            RVlaAUzKbvLSGfJl -= OQjiFWi;
        }
    }

    return hqSqcLWng;
}

bool jhohdYMqjCvgKoM::rbzTJyYaR()
{
    bool GVVWwjFp = true;
    string HJJXF = string("WhGhHAOHXfZfFHNOpMvANyzpIpPyCHctfJodvJTQDGUVHSdMuBYfItePfeaDHiClQNzloFgieirBcQsUBNVZjTcmjBjsuZvmDKykVjFOOdSDmgztPEhJIpUIkSBFuHdpEvnudWlBJXmOUjVjVFLTJKXLRsMknuYkIqtVSruMWXBRWMyyYQWzSqNuiaahrJHNtLyezSIhzuLxWmXlSCWXpfUXYesiwyPPMwNjjKrXcBpeXFrosdLyyFdU");

    if (GVVWwjFp != true) {
        for (int LkGkOeuIYJjs = 2065137404; LkGkOeuIYJjs > 0; LkGkOeuIYJjs--) {
            GVVWwjFp = GVVWwjFp;
        }
    }

    for (int TtZYNgvmqxW = 1608332612; TtZYNgvmqxW > 0; TtZYNgvmqxW--) {
        GVVWwjFp = GVVWwjFp;
        GVVWwjFp = GVVWwjFp;
        GVVWwjFp = ! GVVWwjFp;
    }

    if (GVVWwjFp == true) {
        for (int QBqCmWCFVep = 877335754; QBqCmWCFVep > 0; QBqCmWCFVep--) {
            GVVWwjFp = GVVWwjFp;
        }
    }

    return GVVWwjFp;
}

void jhohdYMqjCvgKoM::JcBMVUa(bool ZDFEL)
{
    int nNvBVNug = -1732613759;
    string BOJCvZJ = string("rcicfAsOpuiEhEkWwLYOmgZDZKDckmaqZEiMgVyIJJicZUJpLhQJRtPTcFcabQlffmIYbGFiRsGmCTZsgqXNICiYFTwnNsYRKufJjJGWgPJWjsSpBTeLsRFNgIcyGJMQufNdmwXEChOImnqESLyZXdQqxfKYWDhHNHQDCxIWmkOxtSkBRubgJpBCEknqvAzWwEMiS");
    double cyXuMfPkUvx = -378509.36565289414;
    int PTpFMFJ = -1716809686;
    int ZldYXB = 529128257;
    bool rKOZEX = true;
    string vIBaIN = string("zGCNzGVICwkfQVwakecWnqupkLIDVZPXKIrRtKJSVtqsTMdfTtEgoWbGrwnzoVdjbXfKxZVLUJoAdIcpzcmPHGcruOvSdDFrxNQlWWtwdWOTkhsryfXtdQklvqmmcbYXKqRMQCnZVHsNGjtDp");
    bool sBAQwDLlCLYkz = true;

    if (sBAQwDLlCLYkz != true) {
        for (int nSMxurWTVPovsJox = 369985879; nSMxurWTVPovsJox > 0; nSMxurWTVPovsJox--) {
            PTpFMFJ += nNvBVNug;
            vIBaIN += BOJCvZJ;
        }
    }

    for (int iRPeYl = 1857864122; iRPeYl > 0; iRPeYl--) {
        continue;
    }

    if (rKOZEX != true) {
        for (int AnuJkU = 1057653289; AnuJkU > 0; AnuJkU--) {
            rKOZEX = ! sBAQwDLlCLYkz;
            ZDFEL = ! sBAQwDLlCLYkz;
        }
    }

    if (ZldYXB >= 529128257) {
        for (int eBfOjENlwsGWCYP = 936113098; eBfOjENlwsGWCYP > 0; eBfOjENlwsGWCYP--) {
            nNvBVNug = ZldYXB;
        }
    }
}

void jhohdYMqjCvgKoM::zKLGDh()
{
    double yTZpx = -2929.074768269194;
    bool NQKrJRThKbhLSS = true;
    double ISIuoDnqhooPEun = 194791.25463757254;
    double fkykRgpD = -475778.30032761936;
    int JOhXCQDmsS = -1757549686;
    string xPpDekpvUIJGALHG = string("pKbjGlLaXjjJTxAcDkdbBAqSuzkPpbqdSkvoDQONfmfCeFWBVEeMRS");
    bool RLmDdeJtwaAWveu = true;
    double WQDuMjkcyxR = -191414.21916941265;
    bool xkWWAsDOkKJGOBH = false;

    for (int vNhFBsuEuvQoPV = 253223846; vNhFBsuEuvQoPV > 0; vNhFBsuEuvQoPV--) {
        continue;
    }

    for (int BBrZZe = 201338577; BBrZZe > 0; BBrZZe--) {
        WQDuMjkcyxR = ISIuoDnqhooPEun;
        xPpDekpvUIJGALHG += xPpDekpvUIJGALHG;
        ISIuoDnqhooPEun = fkykRgpD;
        NQKrJRThKbhLSS = ! xkWWAsDOkKJGOBH;
        ISIuoDnqhooPEun -= WQDuMjkcyxR;
    }

    for (int IfYvOo = 1103646794; IfYvOo > 0; IfYvOo--) {
        continue;
    }

    for (int uxrsIUKQmqccX = 433764352; uxrsIUKQmqccX > 0; uxrsIUKQmqccX--) {
        fkykRgpD += WQDuMjkcyxR;
        RLmDdeJtwaAWveu = ! xkWWAsDOkKJGOBH;
        NQKrJRThKbhLSS = NQKrJRThKbhLSS;
        fkykRgpD -= WQDuMjkcyxR;
        RLmDdeJtwaAWveu = ! NQKrJRThKbhLSS;
        fkykRgpD += yTZpx;
    }
}

jhohdYMqjCvgKoM::jhohdYMqjCvgKoM()
{
    this->qrFdQYhVUu(string("zjaZpnY"), -95412.16744539629);
    this->RlPKfpUryMoQo(string("NTQUvsFrfeDpqMRepriuSmnlxTkQTZyOFvlFKNyevXxawfdRWkwezCUsVmvzbHXSiVAZAoxuUJFWTyAMdmDEFKReNcgQzBDGEHrpholbkpIrfHkcrAnNDikIiJbrIHybTrbxfKctvqubBINUtVxAteXWWLuZAAoCOeIkuwLFJViOsBZPnwLVQrNnxiZvLjBtteoxIYVYlOc"), -2053089043);
    this->MAgERtUKlArX(string("QrCoMOsVKzhUEU"), false, string("UeOGRYWRTvxYdiplrKJjvnmugcYaDUbhbnjpPrQUhFFVlpygqtrgFEzsEARfjCIpchSAlJIwkRndcDzrqBREVEeETM"), false, 2016356599);
    this->JWjzVvCEs(false);
    this->QsgBTxLsaK(false, string("VaFrOzmjGfWNMRSlAjmhhVtHgcoCodYKfAAjrECzZynVoeAIQHKgNoptKFsFukKEuZIkEnZldntmiJBvKxgXegapepbrzwmsyMnGByJMOimgByRXIwYYtZGkLnxtkAqxaxVbvvsovTeQlbwvnUUrsxkouzMKyEkCqtWQqLwqldtp"));
    this->wYZNhZEWt();
    this->rOweYeBn(string("vSKIVVcMPZBPTRKRbMsVGsanZerlrQGkxOTuhYIiEiSpMSjMeMNPTRboEnjTYUOyYdezSwEYbFLwduxGTeQLJhjuMrihYmlOmJLtdhHdHrmGBwsghhsqDNwpGyZcCcRrSrSogeZSrmCvrMbecrIduvVkuFiaSdknJGkenjPxkRHXKfmFNwPtVbIGuPHxvoWvWISfiTYLSNkxRKyLrVKVTumXhULbMvJtzRJX"), 471560388);
    this->KJJyXRkRBfvkKZQ();
    this->OUAAOnWa(-955495.2175001025, -1279330982, false);
    this->jPKDqGTFqpS(false, string("ozqAUpkCvnzjhbOJHLfqMxEyPSofJukPfLblNvElujYvMbhaTsWOBWvWAemK"), -956787.3138263448);
    this->cpFjmHxaV(129009463, -1120136);
    this->rbzTJyYaR();
    this->JcBMVUa(false);
    this->zKLGDh();
}
